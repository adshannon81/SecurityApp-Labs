# add-admin.ps1 — Create a named per-person infrastructure administrator
# -----------------------------------------------------------------------------
# Creates one named admin account across all four infrastructure systems:
#   - HashiCorp Vault   (userpass auth, vault-admin policy)
#   - RabbitMQ          (administrator tag, all vhost permissions)
#   - SQL Server        (sysadmin server role)
#   - Keycloak          (master realm admin role)
#
# Usage:
#   .\add-admin.ps1                                       # 'securityapp-admin', auto-generated password
#   .\add-admin.ps1 -AdminName alice                      # named account, auto-generated password
#   .\add-admin.ps1 -AdminName alice -Password "s3cr3t"   # explicit password
#   .\add-admin.ps1 -AdminName alice -CredentialsFile .\credentials.txt   # append to file
#
# Reads all system passwords from docker-compose.override.yml automatically.
# Run after deploy.ps1 completes (containers must be running).
# -----------------------------------------------------------------------------

param(
    [string]$AdminName       = 'securityapp-admin',
    [string]$Password        = '',
    [string]$CredentialsFile = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$Root = $PSScriptRoot

# -- Helpers ------------------------------------------------------------------
function Write-Step([string]$msg) {
    Write-Host "`n  $msg" -ForegroundColor Cyan
}
function Write-OK([string]$msg)   { Write-Host "    [OK]   $msg" -ForegroundColor Green  }
function Write-Warn([string]$msg) { Write-Host "    [WARN] $msg" -ForegroundColor Yellow }
function Write-Fail([string]$msg) { Write-Host "    [FAIL] $msg" -ForegroundColor Red; throw $msg }

function Read-OverrideValue([string]$Key) {
    $f = Join-Path $Root 'docker-compose.override.yml'
    if (-not (Test-Path $f)) { return $null }
    $content = Get-Content $f -Raw
    if ($content -match "(?m)^\s+${Key}:\s+`"([^`"]+)`"") { return $Matches[1] }
    return $null
}

function New-RandomPassword([int]$Length = 24) {
    $upper   = 'ABCDEFGHJKLMNPQRSTUVWXYZ'
    $lower   = 'abcdefghjkmnpqrstuvwxyz'
    $digits  = '23456789'
    $special = '!@#%^*()-_=+[]{}:;<>,.?'
    $all     = $upper + $lower + $digits + $special
    $rng     = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    do {
        $bytes = New-Object byte[] $Length
        $rng.GetBytes($bytes)
        $chars = $bytes | ForEach-Object { $all[$_ % $all.Length] }
        $pwd   = -join $chars
    } until (
        ($pwd -cmatch '[A-Z]') -and ($pwd -cmatch '[a-z]') -and
        ($pwd -match '\d')     -and ($pwd -match '[!@#%^*()\-_=+\[\]{}:;<>,.?]')
    )
    return $pwd
}

# -- Validate environment -----------------------------------------------------
Write-Host ""
Write-Host "+================================================================+" -ForegroundColor Cyan
Write-Host "|      SecurityApp - Add Infrastructure Administrator            |" -ForegroundColor Cyan
Write-Host "+================================================================+" -ForegroundColor Cyan
Write-Host "  Admin name : $AdminName"

if ([string]::IsNullOrWhiteSpace($Password)) {
    $Password = New-RandomPassword
    Write-Host "  Password   : (auto-generated)" -ForegroundColor DarkGray
} else {
    Write-Host "  Password   : (provided)" -ForegroundColor DarkGray
}

# -- Read infrastructure passwords from override file -------------------------
Write-Step "Reading infrastructure credentials from docker-compose.override.yml"

$saPassword     = Read-OverrideValue 'MSSQL_SA_PASSWORD'
if ([string]::IsNullOrWhiteSpace($saPassword)) { $saPassword = Read-OverrideValue 'ADMIN_SA_PASSWORD' }
$rabbitmqPass   = Read-OverrideValue 'RABBITMQ_DEFAULT_PASS'
$kcAdminPass    = Read-OverrideValue 'KC_BOOTSTRAP_ADMIN_PASSWORD'

$missing = @()
if ([string]::IsNullOrWhiteSpace($saPassword))   { $missing += 'SA password (MSSQL_SA_PASSWORD)' }
if ([string]::IsNullOrWhiteSpace($rabbitmqPass))  { $missing += 'RabbitMQ password (RABBITMQ_DEFAULT_PASS)' }
if ([string]::IsNullOrWhiteSpace($kcAdminPass))   { $missing += 'Keycloak admin password (KC_BOOTSTRAP_ADMIN_PASSWORD)' }
if ($missing.Count -gt 0) {
    Write-Fail "docker-compose.override.yml is missing: $($missing -join ', ')`n  Run .\deploy.ps1 first or ensure the file exists."
}
Write-OK "Infrastructure credentials read."

# -- Read Vault root token ----------------------------------------------------
Write-Step "Reading Vault root token"

$vaultInitRaw = docker exec securityapp-vault cat /vault/data/.init.json 2>&1 | Out-String
$vaultRootToken = ''
if ($vaultInitRaw -match '"root_token"\s*:\s*"([^"]+)"') { $vaultRootToken = $Matches[1] }
if ([string]::IsNullOrWhiteSpace($vaultRootToken)) {
    Write-Fail "Could not read Vault root token. Is the vault container running?`n  Run: docker compose up -d vault"
}
Write-OK "Vault root token read."

$vaultBase   = 'http://localhost:8200'
$vaultHdrs   = @{ 'X-Vault-Token' = $vaultRootToken; 'Content-Type' = 'application/json' }

# =============================================================================
# Step 1 — HashiCorp Vault (userpass auth + vault-admin policy)
# =============================================================================
Write-Step "Vault: enabling userpass auth (if needed)"

try {
    $body = (@{ type = 'userpass'; description = 'Named human operator accounts' } | ConvertTo-Json -Compress)
    Invoke-RestMethod -Uri "$vaultBase/v1/sys/auth/userpass" `
        -Method Post -Headers $vaultHdrs -Body $body | Out-Null
    Write-OK "userpass auth method enabled."
} catch {
    $status = $_.Exception.Response.StatusCode.Value__
    if ($status -eq 400) {
        Write-OK "userpass auth method already enabled."
    } else {
        Write-Warn "Could not enable userpass auth: $($_.Exception.Message)"
    }
}

Write-Step "Vault: writing vault-admin policy"

$vaultAdminPolicy = @'
# Full CRUD on all KV secrets (admin can read SA passwords, rotate secrets)
path "secret/*" {
  capabilities = ["create", "read", "update", "delete", "list"]
}
# Inspect database and RabbitMQ engine configuration (read-only - no generating API creds)
path "database/config/*" { capabilities = ["read", "list"] }
path "database/roles/*"  { capabilities = ["read", "list"] }
path "rabbitmq/config/*" { capabilities = ["read", "list"] }
path "rabbitmq/roles/*"  { capabilities = ["read", "list"] }
# Policy management (create/update policies, but cannot grant root)
path "sys/policies/acl/*" { capabilities = ["create", "read", "update", "delete", "list"] }
path "sys/policy/*"        { capabilities = ["create", "read", "update", "delete", "list"] }
# Auth method listing and userpass user management
path "sys/auth"                    { capabilities = ["read", "list"] }
path "auth/userpass/users/*"       { capabilities = ["create", "read", "update", "delete", "list"] }
# View secret engine mounts and audit devices
path "sys/mounts"  { capabilities = ["read", "list"] }
path "sys/audit"   { capabilities = ["read", "list"] }
# Allow renewing and revoking own token
path "auth/token/renew-self"  { capabilities = ["update"] }
path "auth/token/revoke-self" { capabilities = ["update"] }
'@

try {
    $policyBody = @{ policy = $vaultAdminPolicy } | ConvertTo-Json -Compress
    Invoke-RestMethod -Uri "$vaultBase/v1/sys/policies/acl/vault-admin" `
        -Method Put -Headers $vaultHdrs -Body $policyBody | Out-Null
    Write-OK "Policy 'vault-admin' written."
} catch {
    Write-Warn "Could not write vault-admin policy: $($_.Exception.Message)"
}

Write-Step "Vault: creating userpass account '$AdminName'"

try {
    $userBody = @{ password = $Password; policies = 'vault-admin' } | ConvertTo-Json -Compress
    Invoke-RestMethod -Uri "$vaultBase/v1/auth/userpass/users/$AdminName" `
        -Method Post -Headers $vaultHdrs -Body $userBody | Out-Null
    Write-OK "Vault user '$AdminName' created (policy: vault-admin)."
} catch {
    Write-Warn "Could not create Vault user: $($_.Exception.Message)"
}

# =============================================================================
# Step 2 — RabbitMQ management user
# =============================================================================
Write-Step "RabbitMQ: creating administrator account '$AdminName'"

$rmqBase     = 'http://localhost:15673'
$rmqAuthB64  = [Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes("securityapp:$rabbitmqPass"))
$rmqHdrs     = @{ Authorization = "Basic $rmqAuthB64"; 'Content-Type' = 'application/json' }

try {
    $rmqUserBody = @{ password = $Password; tags = 'administrator' } | ConvertTo-Json -Compress
    Invoke-RestMethod -Uri "$rmqBase/api/users/$AdminName" `
        -Method Put -Headers $rmqHdrs -Body $rmqUserBody | Out-Null
    Write-OK "RabbitMQ user '$AdminName' created with administrator tag."
} catch {
    Write-Warn "Could not create RabbitMQ user: $($_.Exception.Message)"
}

try {
    $rmqPermBody = @{ configure = '.*'; write = '.*'; read = '.*' } | ConvertTo-Json -Compress
    Invoke-RestMethod -Uri "$rmqBase/api/permissions/%2F/$AdminName" `
        -Method Put -Headers $rmqHdrs -Body $rmqPermBody | Out-Null
    Write-OK "RabbitMQ: full permissions on vhost '/' granted."
} catch {
    Write-Warn "Could not set RabbitMQ vhost permissions: $($_.Exception.Message)"
}

# =============================================================================
# Step 3 — SQL Server sysadmin login
# =============================================================================
Write-Step "SQL Server: creating sysadmin login '$AdminName'"

# Escape single quotes in the password (T-SQL requires '' for a literal ')
$sqlPassword = $Password -replace "'", "''"
$sqlAdminName = $AdminName -replace "'", "''"   # sanitise name too

$sqlScript = @"
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'${sqlAdminName}')
BEGIN
    CREATE LOGIN [${sqlAdminName}] WITH PASSWORD = '${sqlPassword}', CHECK_POLICY = OFF;
    EXEC sp_addsrvrolemember N'${sqlAdminName}', 'sysadmin';
    PRINT 'Login created.';
END
ELSE
BEGIN
    ALTER LOGIN [${sqlAdminName}] WITH PASSWORD = '${sqlPassword}', CHECK_POLICY = OFF;
    EXEC sp_addsrvrolemember N'${sqlAdminName}', 'sysadmin';
    PRINT 'Login updated.';
END
"@

try {
    # Write SQL to a temp file inside the container to avoid shell quoting issues
    $sqlBytes   = [System.Text.Encoding]::UTF8.GetBytes($sqlScript)
    $sqlB64     = [Convert]::ToBase64String($sqlBytes)
    $decodeCmd  = "echo $sqlB64 | base64 -d > /tmp/add-admin.sql"
    docker exec securityapp-sqlserver bash -c $decodeCmd 2>&1 | Out-Null
    $result = docker exec securityapp-sqlserver `
        /opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P $saPassword `
        -i /tmp/add-admin.sql -b -No 2>&1 | Out-String
    # Clean up
    docker exec securityapp-sqlserver bash -c "rm -f /tmp/add-admin.sql" 2>&1 | Out-Null
    if ($result -match 'Error|error|FAIL|failed') {
        Write-Warn "SQL Server completed with warnings: $($result.Trim())"
    } else {
        Write-OK "SQL Server login '$AdminName' created with sysadmin role."
    }
} catch {
    Write-Warn "Could not create SQL Server login: $($_.Exception.Message)"
}

# =============================================================================
# Step 4 — Keycloak master realm admin user
# =============================================================================
Write-Step "Keycloak: creating master realm admin user '$AdminName'"

$kcBase = 'http://localhost:8180'

try {
    $tokenBody = "grant_type=password&client_id=admin-cli&username=admin&password=$([System.Uri]::EscapeDataString($kcAdminPass))"
    $tokenResp = Invoke-RestMethod -Uri "$kcBase/realms/master/protocol/openid-connect/token" `
        -Method Post -ContentType 'application/x-www-form-urlencoded' -Body $tokenBody
    $kcToken   = $tokenResp.access_token
    $kcHdrs    = @{ Authorization = "Bearer $kcToken"; 'Content-Type' = 'application/json' }

    # Check if user already exists in master realm
    $existing = Invoke-RestMethod -Uri "$kcBase/admin/realms/master/users?username=$([System.Uri]::EscapeDataString($AdminName))&exact=true" `
        -Headers $kcHdrs
    $userId = $null

    if ($existing -and $existing.Count -gt 0) {
        $userId = $existing[0].id
        Write-OK "Keycloak user '$AdminName' already exists - updating password."
    } else {
        # Create user
        $newUserBody = @{
            username  = $AdminName
            enabled   = $true
            email     = "$AdminName@securityapp.local"
            firstName = 'Admin'
            lastName  = $AdminName
        } | ConvertTo-Json -Compress
        try {
            Invoke-RestMethod -Uri "$kcBase/admin/realms/master/users" `
                -Method Post -Headers $kcHdrs -Body $newUserBody | Out-Null
        } catch { }

        # Fetch the newly created user's ID
        $created = Invoke-RestMethod -Uri "$kcBase/admin/realms/master/users?username=$([System.Uri]::EscapeDataString($AdminName))&exact=true" `
            -Headers $kcHdrs
        if ($created -and $created.Count -gt 0) {
            $userId = $created[0].id
            Write-OK "Keycloak user '$AdminName' created in master realm."
        }
    }

    if ($userId) {
        # Set / reset password
        $pwBody = @{ type = 'password'; value = $Password; temporary = $false } | ConvertTo-Json -Compress
        Invoke-RestMethod -Uri "$kcBase/admin/realms/master/users/$userId/reset-password" `
            -Method Put -Headers $kcHdrs -Body $pwBody | Out-Null
        Write-OK "Keycloak password set."

        # Assign the 'admin' realm role (grants full access to master realm + all managed realms)
        try {
            $adminRole = Invoke-RestMethod -Uri "$kcBase/admin/realms/master/roles/admin" -Headers $kcHdrs
            $roleBody  = ConvertTo-Json @(@{ id = $adminRole.id; name = 'admin' }) -Compress
            Invoke-RestMethod -Uri "$kcBase/admin/realms/master/users/$userId/role-mappings/realm" `
                -Method Post -Headers $kcHdrs -Body $roleBody | Out-Null
            Write-OK "Keycloak 'admin' realm role assigned."
        } catch {
            Write-Warn "Could not assign Keycloak admin role (may already be assigned): $($_.Exception.Message)"
        }
    } else {
        Write-Warn "Could not locate Keycloak user after creation."
    }
} catch {
    Write-Warn "Could not configure Keycloak user: $($_.Exception.Message)"
}

# =============================================================================
# Credentials section
# =============================================================================
$line  = "=" * 65
$line2 = "-" * 65
$ts    = Get-Date -Format 'yyyy-MM-dd HH:mm'

$section  = "`n$line`n"
$section += " INFRASTRUCTURE ADMIN: $AdminName`n"
$section += " Created: $ts`n"
$section += " KEEP PRIVATE - one section per admin - do NOT share.`n"
$section += "$line`n"
$section += "`n--- VAULT (http://localhost:8200/ui) ---`n"
$section += "$line2`n"
$section += "  Auth method: Username/Password`n"
$section += "  Username:    $AdminName`n"
$section += "  Password:    $Password`n"
$section += "  Policy:      vault-admin (full secrets management, no root ops)`n"
$section += "`n--- RABBITMQ MANAGEMENT (http://localhost:15673) ---`n"
$section += "$line2`n"
$section += "  Username: $AdminName`n"
$section += "  Password: $Password`n"
$section += "  Tags:     administrator`n"
$section += "  Vhost '/': configure=.* write=.* read=.*`n"
$section += "`n--- SQL SERVER (localhost,1433) ---`n"
$section += "$line2`n"
$section += "  Login:       $AdminName`n"
$section += "  Password:    $Password`n"
$section += "  Server role: sysadmin`n"
$section += "`n--- KEYCLOAK ADMIN CONSOLE (http://localhost:8180/admin) ---`n"
$section += "$line2`n"
$section += "  Realm:    master`n"
$section += "  Username: $AdminName`n"
$section += "  Password: $Password`n"
$section += "  Role:     admin (full access to all realms)`n"
$section += "$line`n"

Write-Host ""
Write-Host $section -ForegroundColor White

# Append to credentials.txt if a path was provided or the file already exists
if ([string]::IsNullOrWhiteSpace($CredentialsFile)) {
    $defaultCreds = Join-Path $Root 'credentials.txt'
    if (Test-Path $defaultCreds) { $CredentialsFile = $defaultCreds }
}

if (-not [string]::IsNullOrWhiteSpace($CredentialsFile)) {
    Add-Content -Path $CredentialsFile -Value $section -Encoding UTF8
    Write-Host "  Appended to: $CredentialsFile" -ForegroundColor Yellow
} else {
    # Standalone run without existing credentials.txt — save to named file
    $outFile = Join-Path $Root "credentials-$AdminName.txt"
    Set-Content -Path $outFile -Value $section -Encoding UTF8
    Write-Host "  Saved to: $outFile" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "+================================================================+" -ForegroundColor Green
Write-Host "|           Admin '$AdminName' created                           |" -ForegroundColor Green
Write-Host "+================================================================+" -ForegroundColor Green
Write-Host ""
