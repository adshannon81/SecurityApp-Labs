-- ====================================================================
-- SecurityApp ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â Complete Schema (SQL Server)
-- Fully idempotent: safe to run on a fresh database OR re-run on an
-- existing one (all CREATE TABLE / CREATE INDEX statements are guarded
-- with IF NOT EXISTS using the exact lowercase object names).
-- Convention: business table names snake_case; ASP.NET Identity PascalCase.
-- ====================================================================

-- Required for filtered indexes and indexed views
SET QUOTED_IDENTIFIER ON;
GO

PRINT 'Creating SecurityApp schema (SQL Server)...';
GO

-- ====================================================================
-- Schema version tracking
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = '__SchemaVersions' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.[__SchemaVersions] (
        id             INT            NOT NULL IDENTITY(1,1) PRIMARY KEY,
        version        NVARCHAR(50)   NOT NULL,
        description    NVARCHAR(MAX)  NOT NULL,
        script_name    NVARCHAR(255)  NOT NULL DEFAULT '',
        applied_on     DATETIME2      NOT NULL DEFAULT GETUTCDATE(),
        applied_by     NVARCHAR(100)  NOT NULL DEFAULT SYSTEM_USER,
        execution_time NVARCHAR(50),
        status         NVARCHAR(20)   NOT NULL DEFAULT 'Success',
        CONSTRAINT UQ__SchemaVersions_version UNIQUE (version)
    );
END
GO

-- ====================================================================
-- ASP.NET Identity tables
-- Column names stay PascalCase ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â owned by the Identity framework.
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'AspNetRoles' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.[AspNetRoles] (
        Id               NVARCHAR(450) NOT NULL PRIMARY KEY,
        Name             NVARCHAR(256),
        NormalizedName   NVARCHAR(256),
        ConcurrencyStamp NVARCHAR(MAX)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'AspNetUsers' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.[AspNetUsers] (
        Id                   NVARCHAR(450) NOT NULL PRIMARY KEY,
        UserName             NVARCHAR(256),
        NormalizedUserName   NVARCHAR(256),
        Email                NVARCHAR(256),
        NormalizedEmail      NVARCHAR(256),
        EmailConfirmed       BIT           NOT NULL,
        PasswordHash         NVARCHAR(MAX),
        SecurityStamp        NVARCHAR(MAX),
        ConcurrencyStamp     NVARCHAR(MAX),
        PhoneNumber          NVARCHAR(MAX),
        PhoneNumberConfirmed BIT           NOT NULL,
        TwoFactorEnabled     BIT           NOT NULL,
        LockoutEnd           DATETIMEOFFSET,
        LockoutEnabled       BIT           NOT NULL,
        AccessFailedCount    INT           NOT NULL
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'AspNetUserRoles' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.[AspNetUserRoles] (
        UserId NVARCHAR(450) NOT NULL,
        RoleId NVARCHAR(450) NOT NULL,
        PRIMARY KEY (UserId, RoleId),
        CONSTRAINT FK_AspNetUserRoles_Users FOREIGN KEY (UserId) REFERENCES dbo.[AspNetUsers] (Id) ON DELETE CASCADE,
        CONSTRAINT FK_AspNetUserRoles_Roles FOREIGN KEY (RoleId) REFERENCES dbo.[AspNetRoles]  (Id) ON DELETE CASCADE
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'AspNetUserClaims' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.[AspNetUserClaims] (
        Id         INT           NOT NULL IDENTITY(1,1) PRIMARY KEY,
        UserId     NVARCHAR(450) NOT NULL,
        ClaimType  NVARCHAR(MAX),
        ClaimValue NVARCHAR(MAX),
        CONSTRAINT FK_AspNetUserClaims_Users FOREIGN KEY (UserId) REFERENCES dbo.[AspNetUsers] (Id) ON DELETE CASCADE
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'AspNetUserLogins' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.[AspNetUserLogins] (
        LoginProvider       NVARCHAR(450) NOT NULL,
        ProviderKey         NVARCHAR(450) NOT NULL,
        ProviderDisplayName NVARCHAR(MAX),
        UserId              NVARCHAR(450) NOT NULL,
        PRIMARY KEY (LoginProvider, ProviderKey),
        CONSTRAINT FK_AspNetUserLogins_Users FOREIGN KEY (UserId) REFERENCES dbo.[AspNetUsers] (Id) ON DELETE CASCADE
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'AspNetUserTokens' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.[AspNetUserTokens] (
        UserId        NVARCHAR(450) NOT NULL,
        LoginProvider NVARCHAR(450) NOT NULL,
        Name          NVARCHAR(450) NOT NULL,
        Value         NVARCHAR(MAX),
        PRIMARY KEY (UserId, LoginProvider, Name),
        CONSTRAINT FK_AspNetUserTokens_Users FOREIGN KEY (UserId) REFERENCES dbo.[AspNetUsers] (Id) ON DELETE CASCADE
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'AspNetRoleClaims' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.[AspNetRoleClaims] (
        Id         INT           NOT NULL IDENTITY(1,1) PRIMARY KEY,
        RoleId     NVARCHAR(450) NOT NULL,
        ClaimType  NVARCHAR(MAX),
        ClaimValue NVARCHAR(MAX),
        CONSTRAINT FK_AspNetRoleClaims_Roles FOREIGN KEY (RoleId) REFERENCES dbo.[AspNetRoles] (Id) ON DELETE CASCADE
    );
END
GO

-- ====================================================================
-- Business tables
-- ====================================================================

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Reference tables (must precede security ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â FK deps) ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'security_status_ref' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.security_status_ref (
        code        VARCHAR(32)   NOT NULL,
        description NVARCHAR(255) NOT NULL,
        CONSTRAINT pk_security_status_ref PRIMARY KEY (code)
    );
END
GO

-- Milestone 7: lifecycle state machine transition rules
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'security_status_transition_ref' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.security_status_transition_ref (
        from_code VARCHAR(32) NOT NULL,
        to_code   VARCHAR(32) NOT NULL,
        CONSTRAINT pk_security_status_transition PRIMARY KEY (from_code, to_code),
        CONSTRAINT fk_sst_from FOREIGN KEY (from_code) REFERENCES dbo.security_status_ref (code),
        CONSTRAINT fk_sst_to   FOREIGN KEY (to_code)   REFERENCES dbo.security_status_ref (code)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'asset_class_ref' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.asset_class_ref (
        code        VARCHAR(32)   NOT NULL,
        name        NVARCHAR(100) NOT NULL,
        description NVARCHAR(255) NULL,
        CONSTRAINT pk_asset_class_ref PRIMARY KEY (code)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'instrument_type_ref' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.instrument_type_ref (
        code             VARCHAR(64)   NOT NULL,
        asset_class_code VARCHAR(32)   NOT NULL,
        description      NVARCHAR(255) NULL,
        CONSTRAINT pk_instrument_type_ref PRIMARY KEY (code),
        CONSTRAINT fk_instrument_type_asset_class
            FOREIGN KEY (asset_class_code) REFERENCES dbo.asset_class_ref(code)
    );
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Issuer (must precede security ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â issuer_id FK dep) ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'issuer' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.issuer (
        id                                    UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        legal_name                            NVARCHAR(255)    NOT NULL,
        display_name                          NVARCHAR(255)    NULL,
        short_name                            NVARCHAR(100)    NULL,
        lei_code                              NVARCHAR(20)     NULL,
        issuer_type                           NVARCHAR(50)     NULL,
        country_alpha2                        NCHAR(2)         NULL,   -- FK ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ dbo.country(alpha2) added after country table
        -- Optional cache columns for fast reads ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â source of truth is issuer_relationship
        direct_accounting_parent_issuer_id   UNIQUEIDENTIFIER NULL,
        ultimate_accounting_parent_issuer_id UNIQUEIDENTIFIER NULL,
        is_active                             BIT              NOT NULL DEFAULT 1,
        -- BaseEntity
        created_at                            DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at                            DATETIME2(3)     NULL,
        -- TemporalEntity
        valid_from                            DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        valid_to                              DATETIME2(3)     NOT NULL DEFAULT '9999-12-31',
        system_from                           DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        system_to                             DATETIME2(3)     NOT NULL DEFAULT '9999-12-31',
        is_current                            BIT              NOT NULL DEFAULT 1,
        is_deleted                            BIT              NOT NULL DEFAULT 0,
        created_by                           NVARCHAR(255),

        last_modified_by                           NVARCHAR(255)    NULL,
        content_hash                          NVARCHAR(64)     NULL,
        CONSTRAINT pk_issuer PRIMARY KEY (id),
        CONSTRAINT fk_issuer_direct_accounting_parent
            FOREIGN KEY (direct_accounting_parent_issuer_id) REFERENCES dbo.issuer(id),
        CONSTRAINT fk_issuer_ultimate_accounting_parent
            FOREIGN KEY (ultimate_accounting_parent_issuer_id) REFERENCES dbo.issuer(id),
        CONSTRAINT ck_issuer_valid_time           CHECK (valid_from  < valid_to),
        CONSTRAINT ck_issuer_system_time          CHECK (system_from < system_to),
        CONSTRAINT ck_issuer_legal_name_not_blank CHECK (LEN(LTRIM(RTRIM(legal_name))) > 0)
    );
END
GO

-- Add cache columns to existing issuer tables (idempotent)
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.issuer') AND name = 'direct_accounting_parent_issuer_id')
BEGIN
    ALTER TABLE dbo.issuer ADD direct_accounting_parent_issuer_id UNIQUEIDENTIFIER NULL;
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.issuer') AND name = 'ultimate_accounting_parent_issuer_id')
BEGIN
    ALTER TABLE dbo.issuer ADD ultimate_accounting_parent_issuer_id UNIQUEIDENTIFIER NULL;
END
GO

-- Migrate existing ultimate_parent_issuer_id ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ direct_accounting_parent_issuer_id (if the old column exists)
-- Uses dynamic SQL to avoid compile-time "invalid column" error when the old column is absent.
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.issuer') AND name = 'ultimate_parent_issuer_id')
BEGIN
    EXEC sp_executesql N'UPDATE dbo.issuer
        SET direct_accounting_parent_issuer_id = ultimate_parent_issuer_id
        WHERE ultimate_parent_issuer_id IS NOT NULL
          AND direct_accounting_parent_issuer_id IS NULL;';
END
GO

-- Add FK constraints for cache columns (idempotent)
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'fk_issuer_direct_accounting_parent' AND parent_object_id = OBJECT_ID('dbo.issuer'))
BEGIN
    ALTER TABLE dbo.issuer
        ADD CONSTRAINT fk_issuer_direct_accounting_parent
            FOREIGN KEY (direct_accounting_parent_issuer_id) REFERENCES dbo.issuer(id);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'fk_issuer_ultimate_accounting_parent' AND parent_object_id = OBJECT_ID('dbo.issuer'))
BEGIN
    ALTER TABLE dbo.issuer
        ADD CONSTRAINT fk_issuer_ultimate_accounting_parent
            FOREIGN KEY (ultimate_accounting_parent_issuer_id) REFERENCES dbo.issuer(id);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_issuer_legal_name_current' AND object_id = OBJECT_ID('dbo.issuer'))
    CREATE UNIQUE INDEX ux_issuer_legal_name_current
        ON dbo.issuer (legal_name)
        WHERE is_current = 1 AND is_deleted = 0;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_issuer_lei_current' AND object_id = OBJECT_ID('dbo.issuer'))
    CREATE UNIQUE INDEX ux_issuer_lei_current
        ON dbo.issuer (lei_code)
        WHERE lei_code IS NOT NULL AND is_current = 1 AND is_deleted = 0;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_issuer_display_name_current' AND object_id = OBJECT_ID('dbo.issuer'))
    CREATE INDEX ix_issuer_display_name_current
        ON dbo.issuer (display_name)
        WHERE is_current = 1 AND is_deleted = 0;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_issuer_country_current' AND object_id = OBJECT_ID('dbo.issuer'))
    CREATE INDEX ix_issuer_country_current
        ON dbo.issuer (country_alpha2)
        WHERE is_current = 1 AND is_deleted = 0;
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ IssuerIdentifiers ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'issuer_identifier' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.issuer_identifier (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        issuer_id        UNIQUEIDENTIFIER NOT NULL,
        identifier_type  NVARCHAR(50)     NOT NULL,
        identifier_value NVARCHAR(100)    NOT NULL,
        source_system    NVARCHAR(50)     NULL,
        is_primary       BIT              NOT NULL DEFAULT 0,
        -- BaseEntity
        created_at       DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at       DATETIME2(3)     NULL,
        -- TemporalEntity
        valid_from       DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        valid_to         DATETIME2(3)     NOT NULL DEFAULT '9999-12-31',
        system_from      DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        system_to        DATETIME2(3)     NOT NULL DEFAULT '9999-12-31',
        is_current       BIT              NOT NULL DEFAULT 1,
        is_deleted       BIT              NOT NULL DEFAULT 0,
        created_by      NVARCHAR(255),

        last_modified_by      NVARCHAR(255)    NULL,
        CONSTRAINT pk_issuer_identifier PRIMARY KEY (id),
        CONSTRAINT fk_issuer_identifier_issuer
            FOREIGN KEY (issuer_id) REFERENCES dbo.issuer(id) ON DELETE CASCADE,
        CONSTRAINT ck_issuer_identifier_valid_time  CHECK (valid_from  < valid_to),
        CONSTRAINT ck_issuer_identifier_system_time CHECK (system_from < system_to)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_issuer_identifier_current' AND object_id = OBJECT_ID('dbo.issuer_identifier'))
    CREATE UNIQUE INDEX ux_issuer_identifier_current
        ON dbo.issuer_identifier (identifier_type, identifier_value, source_system)
        WHERE is_current = 1 AND is_deleted = 0;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_issuer_identifier_issuer_id' AND object_id = OBJECT_ID('dbo.issuer_identifier'))
    CREATE INDEX ix_issuer_identifier_issuer_id ON dbo.issuer_identifier (issuer_id);
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ IssuerRelationship ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
-- Source of truth for issuer ownership/control hierarchy.
-- Replaces the single ultimate_parent_issuer_id self-reference with typed,
-- temporal, multi-source relationship rows.
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'issuer_relationship' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.issuer_relationship (
        id                   UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        child_issuer_id      UNIQUEIDENTIFIER NOT NULL,
        parent_issuer_id     UNIQUEIDENTIFIER NOT NULL,
        relationship_type    NVARCHAR(50)     NOT NULL,
        ownership_percent    DECIMAL(9,6)     NULL,
        control_basis        NVARCHAR(100)    NULL,
        source_system        NVARCHAR(50)     NULL,
        source_reference     NVARCHAR(255)    NULL,
        is_primary           BIT              NOT NULL DEFAULT 0,
        notes                NVARCHAR(1000)   NULL,
        -- BaseEntity
        created_at           DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at           DATETIME2(3)     NULL,
        -- TemporalEntity
        valid_from           DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        valid_to             DATETIME2(3)     NOT NULL DEFAULT '9999-12-31',
        system_from          DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        system_to            DATETIME2(3)     NOT NULL DEFAULT '9999-12-31',
        is_current           BIT              NOT NULL DEFAULT 1,
        is_deleted           BIT              NOT NULL DEFAULT 0,
        created_by          NVARCHAR(255),

        last_modified_by          NVARCHAR(255)    NULL,
        CONSTRAINT pk_issuer_relationship PRIMARY KEY (id),
        CONSTRAINT fk_issuer_relationship_child
            FOREIGN KEY (child_issuer_id)  REFERENCES dbo.issuer(id),
        CONSTRAINT fk_issuer_relationship_parent
            FOREIGN KEY (parent_issuer_id) REFERENCES dbo.issuer(id),
        CONSTRAINT ck_issuer_relationship_not_self
            CHECK (child_issuer_id <> parent_issuer_id),
        CONSTRAINT ck_issuer_relationship_valid_time
            CHECK (valid_from  < valid_to),
        CONSTRAINT ck_issuer_relationship_system_time
            CHECK (system_from < system_to),
        CONSTRAINT ck_issuer_relationship_pct
            CHECK (ownership_percent IS NULL OR (ownership_percent >= 0 AND ownership_percent <= 100)),
        CONSTRAINT ck_issuer_relationship_type
            CHECK (relationship_type IN (
                'ACCOUNTING_DIRECT_PARENT',
                'ACCOUNTING_ULTIMATE_PARENT',
                'OWNERSHIP_PARENT',
                'CONTROL_PARENT',
                'GUARANTOR',
                'SPONSOR',
                'MANAGING_ENTITY'
            ))
    );
END
GO

-- Unique: at most one current accounting direct parent per child
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_issuer_rel_accounting_direct_parent' AND object_id = OBJECT_ID('dbo.issuer_relationship'))
    CREATE UNIQUE INDEX ux_issuer_rel_accounting_direct_parent
        ON dbo.issuer_relationship (child_issuer_id, relationship_type)
        WHERE relationship_type = 'ACCOUNTING_DIRECT_PARENT'
          AND is_current = 1 AND is_deleted = 0;
GO

-- Unique: at most one current accounting ultimate parent per child
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_issuer_rel_accounting_ultimate_parent' AND object_id = OBJECT_ID('dbo.issuer_relationship'))
    CREATE UNIQUE INDEX ux_issuer_rel_accounting_ultimate_parent
        ON dbo.issuer_relationship (child_issuer_id, relationship_type)
        WHERE relationship_type = 'ACCOUNTING_ULTIMATE_PARENT'
          AND is_current = 1 AND is_deleted = 0;
GO

-- Unique: no duplicate current pair (child, parent, type, source)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_issuer_rel_current_pair' AND object_id = OBJECT_ID('dbo.issuer_relationship'))
    CREATE UNIQUE INDEX ux_issuer_rel_current_pair
        ON dbo.issuer_relationship (child_issuer_id, parent_issuer_id, relationship_type, source_system)
        WHERE is_current = 1 AND is_deleted = 0;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_issuer_rel_child_current' AND object_id = OBJECT_ID('dbo.issuer_relationship'))
    CREATE INDEX ix_issuer_rel_child_current
        ON dbo.issuer_relationship (child_issuer_id, relationship_type)
        WHERE is_current = 1 AND is_deleted = 0;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_issuer_rel_parent_current' AND object_id = OBJECT_ID('dbo.issuer_relationship'))
    CREATE INDEX ix_issuer_rel_parent_current
        ON dbo.issuer_relationship (parent_issuer_id, relationship_type)
        WHERE is_current = 1 AND is_deleted = 0;
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Derived accounting hierarchy view ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
-- Returns the full ancestry chain for each issuer via ACCOUNTING_DIRECT_PARENT
-- rows; the deepest depth row per child gives the derived ultimate parent.
IF OBJECT_ID('dbo.vw_issuer_accounting_hierarchy', 'V') IS NOT NULL
    DROP VIEW dbo.vw_issuer_accounting_hierarchy;
GO

CREATE VIEW dbo.vw_issuer_accounting_hierarchy
AS
WITH rel AS (
    SELECT child_issuer_id, parent_issuer_id
    FROM   dbo.issuer_relationship
    WHERE  relationship_type = 'ACCOUNTING_DIRECT_PARENT'
      AND  is_current = 1
      AND  is_deleted = 0
), cte AS (
    SELECT
        r.child_issuer_id,
        r.parent_issuer_id,
        r.parent_issuer_id AS root_parent_id,
        1 AS depth
    FROM rel r
    UNION ALL
    SELECT
        c.child_issuer_id,
        r.parent_issuer_id,
        r.parent_issuer_id AS root_parent_id,
        c.depth + 1
    FROM cte c
    INNER JOIN rel r ON c.parent_issuer_id = r.child_issuer_id
)
SELECT child_issuer_id, parent_issuer_id, depth
FROM   cte;
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Securities ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'security' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.security (
        id                   UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        data_source          NVARCHAR(50)     NOT NULL DEFAULT 'FlatFile',
        type                 NVARCHAR(50)     NOT NULL,
        name                 NVARCHAR(255)    NOT NULL,
        description          NVARCHAR(MAX),
        issuer               NVARCHAR(255),              -- legacy free-text; migrate to issuer_id
        issuer_id            UNIQUEIDENTIFIER NULL,      -- FK ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ dbo.issuer(id)
        currency_code        NVARCHAR(10)     NULL,      -- ISO 4217 FK ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ dbo.currency(code)
        has_open_position    BIT              NOT NULL DEFAULT 0,
        status_code          VARCHAR(32)      NOT NULL DEFAULT 'ACTIVE',
        asset_class_code     VARCHAR(32)      NOT NULL DEFAULT 'OTHER',
        instrument_type_code VARCHAR(64)      NOT NULL DEFAULT 'Other',
        -- BaseEntity
        created_at           DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at           DATETIME2,
        -- TemporalEntity
        valid_from           DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to             DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from          DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to            DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current           BIT              NOT NULL DEFAULT 1,
        is_deleted           BIT              NOT NULL DEFAULT 0,
        created_by          NVARCHAR(255),

        last_modified_by          NVARCHAR(255),
        content_hash         NVARCHAR(64)     NULL,
        row_version          ROWVERSION       NOT NULL,
        CONSTRAINT fk_security_status_ref
            FOREIGN KEY (status_code)          REFERENCES dbo.security_status_ref(code),
        CONSTRAINT fk_security_asset_class_ref
            FOREIGN KEY (asset_class_code)     REFERENCES dbo.asset_class_ref(code),
        CONSTRAINT fk_security_instrument_type_ref
            FOREIGN KEY (instrument_type_code) REFERENCES dbo.instrument_type_ref(code),
        CONSTRAINT fk_security_issuer
            FOREIGN KEY (issuer_id)            REFERENCES dbo.issuer(id),
        CONSTRAINT ck_security_valid_time       CHECK (valid_from  < valid_to),
        CONSTRAINT ck_security_system_time      CHECK (system_from < system_to),
        CONSTRAINT ck_security_name_not_blank   CHECK (LEN(LTRIM(RTRIM(name))) > 0),
        CONSTRAINT ck_security_type_not_blank   CHECK (LEN(LTRIM(RTRIM(CAST(type AS NVARCHAR(50))))) > 0)
    );
END
GO

-- Add issuer_id to existing security tables (idempotent)
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.security') AND name = 'issuer_id')
BEGIN
    ALTER TABLE dbo.security ADD issuer_id UNIQUEIDENTIFIER NULL;
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'fk_security_issuer' AND parent_object_id = OBJECT_ID('dbo.security'))
BEGIN
    ALTER TABLE dbo.security
        ADD CONSTRAINT fk_security_issuer FOREIGN KEY (issuer_id) REFERENCES dbo.issuer(id);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'security_identifier' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.security_identifier (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        security_id      UNIQUEIDENTIFIER NOT NULL,
        identifier_type  NVARCHAR(50)     NOT NULL,
        identifier_value NVARCHAR(100)    NOT NULL,
        source_system    NVARCHAR(50)     NULL,
        is_primary       BIT              NOT NULL DEFAULT 0,
        -- BaseEntity
        created_at       DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at       DATETIME2(3)     NULL,
        -- TemporalEntity
        valid_from       DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        valid_to         DATETIME2(3)     NOT NULL DEFAULT '9999-12-31',
        system_from      DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        system_to        DATETIME2(3)     NOT NULL DEFAULT '9999-12-31',
        is_current       BIT              NOT NULL DEFAULT 1,
        is_deleted       BIT              NOT NULL DEFAULT 0,
        created_by      NVARCHAR(255),

        last_modified_by      NVARCHAR(255)    NULL,
        CONSTRAINT pk_security_identifier PRIMARY KEY (id),
        CONSTRAINT fk_security_identifier_security
            FOREIGN KEY (security_id) REFERENCES dbo.security(id) ON DELETE CASCADE,
        CONSTRAINT ck_security_identifier_valid_time  CHECK (valid_from  < valid_to),
        CONSTRAINT ck_security_identifier_system_time CHECK (system_from < system_to)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_security_identifier_current_value' AND object_id = OBJECT_ID('dbo.security_identifier'))
    CREATE UNIQUE INDEX ux_security_identifier_current_value
        ON dbo.security_identifier (identifier_type, identifier_value, source_system)
        WHERE is_current = 1 AND is_deleted = 0;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_security_identifier_primary_per_type' AND object_id = OBJECT_ID('dbo.security_identifier'))
    CREATE UNIQUE INDEX ux_security_identifier_primary_per_type
        ON dbo.security_identifier (security_id, identifier_type, source_system)
        WHERE is_current = 1 AND is_deleted = 0 AND is_primary = 1;
GO

-- One active identifier of each type per security (prevents two CUSIPs, two ISINs, etc.)
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_security_identifier_one_per_type' AND object_id = OBJECT_ID('dbo.security_identifier'))
    CREATE UNIQUE INDEX ux_security_identifier_one_per_type
        ON dbo.security_identifier (security_id, identifier_type)
        WHERE is_current = 1 AND is_deleted = 0;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_security_identifier_security_id' AND object_id = OBJECT_ID('dbo.security_identifier'))
    CREATE INDEX ix_security_identifier_security_id ON dbo.security_identifier (security_id);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_security_identifier_is_current' AND object_id = OBJECT_ID('dbo.security_identifier'))
    CREATE INDEX ix_security_identifier_is_current
        ON dbo.security_identifier (is_current)
        WHERE is_current = 1 AND is_deleted = 0;
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Prices ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'price' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.price (
        id         UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        security_id UNIQUEIDENTIFIER NOT NULL,
        value      DECIMAL(18,8)    NOT NULL,
        source     NVARCHAR(50)     NOT NULL,
        price_date  DATETIME2        NOT NULL,
        price_type  NVARCHAR(50),
        currency   NVARCHAR(10),
        -- BaseEntity
        created_at  DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at  DATETIME2,
        -- TemporalEntity
        valid_from  DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to    DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to   DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current  BIT              NOT NULL DEFAULT 1,
        is_deleted  BIT              NOT NULL DEFAULT 0,
        created_by NVARCHAR(255),

        last_modified_by NVARCHAR(255),
        CONSTRAINT fk_price_security
            FOREIGN KEY (security_id) REFERENCES dbo.security (id) ON DELETE CASCADE
    );
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ PricingRules ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'pricing_rule' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.pricing_rule (
        id             UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        rule_name       NVARCHAR(255)    NOT NULL,
        security_type   NVARCHAR(50),
        rule_definition_json NVARCHAR(MAX)    NOT NULL,
        created_by      UNIQUEIDENTIFIER,
        description    NVARCHAR(1000),
        -- BaseEntity
        created_at      DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at      DATETIME2,
        -- TemporalEntity
        valid_from      DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to        DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from     DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to       DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current      BIT              NOT NULL DEFAULT 1,
        is_deleted      BIT              NOT NULL DEFAULT 0,
        created_by     NVARCHAR(255),

        last_modified_by     NVARCHAR(255)
    );
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ DerivedPrices ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'derived_price' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.derived_price (
        id                 UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        security_id         UNIQUEIDENTIFIER NOT NULL,
        pricing_rule_id      UNIQUEIDENTIFIER NOT NULL,
        calculated_price    DECIMAL(18,8)    NOT NULL,
        calculated_at       DATETIME2        NOT NULL,
        calculation_details NVARCHAR(MAX),
        -- BaseEntity
        created_at          DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at          DATETIME2,
        -- TemporalEntity
        valid_from          DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to            DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from         DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to           DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current          BIT              NOT NULL DEFAULT 1,
        is_deleted          BIT              NOT NULL DEFAULT 0,
        created_by         NVARCHAR(255),

        last_modified_by         NVARCHAR(255),
        CONSTRAINT fk_derived_price_security
            FOREIGN KEY (security_id)    REFERENCES dbo.security   (id) ON DELETE CASCADE,
        CONSTRAINT fk_derived_price_pricing_rule
            FOREIGN KEY (pricing_rule_id) REFERENCES dbo.pricing_rule (id)
    );
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ SecurityCoreAttributes ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'security_core_attribute' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.security_core_attribute (
        id           UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        security_id  UNIQUEIDENTIFIER NOT NULL,
        coupon_rate  DECIMAL(10,6)    NULL,
        factor_rate  DECIMAL(10,6)    NULL,
        maturity_date DATETIME2(7)   NULL,
        issue_date   DATETIME2(7)    NULL,
        face_value   DECIMAL(18,2)   NULL,
        -- BaseEntity
        created_at   DATETIME2(7)    NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at   DATETIME2(7)    NULL,
        -- TemporalEntity
        valid_from   DATETIME2(7)    NOT NULL DEFAULT GETUTCDATE(),
        valid_to     DATETIME2(7)    NOT NULL DEFAULT '9999-12-31',
        system_from  DATETIME2(7)    NOT NULL DEFAULT GETUTCDATE(),
        system_to    DATETIME2(7)    NOT NULL DEFAULT '9999-12-31',
        is_current   BIT             NOT NULL DEFAULT 1,
        is_deleted   BIT             NOT NULL DEFAULT 0,
        created_by  NVARCHAR(255),

        last_modified_by  NVARCHAR(255)   NULL,
        CONSTRAINT fk_security_core_attribute_security
            FOREIGN KEY (security_id) REFERENCES dbo.security (id) ON DELETE CASCADE,
        CONSTRAINT ck_security_core_attribute_valid_time  CHECK (valid_from  < valid_to),
        CONSTRAINT ck_security_core_attribute_system_time CHECK (system_from < system_to)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_security_core_attribute_current' AND object_id = OBJECT_ID('dbo.security_core_attribute'))
    CREATE UNIQUE INDEX ux_security_core_attribute_current
        ON dbo.security_core_attribute (security_id)
        WHERE is_current = 1 AND is_deleted = 0;
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ SecurityLoanAttributes ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'security_loan_attribute' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.security_loan_attribute (
        id              UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        security_id     UNIQUEIDENTIFIER NOT NULL,
        loan_type       NVARCHAR(50)     NULL,
        collateral_type NVARCHAR(100)    NULL,
        seniority       NVARCHAR(50)     NULL,
        amortization    NVARCHAR(50)     NULL,
        payment_freq    NVARCHAR(20)     NULL,
        day_count       NVARCHAR(20)     NULL,
        margin_bps      DECIMAL(9,4)     NULL,
        reference_index NVARCHAR(50)     NULL,
        maturity_date   DATETIME2(7)     NULL,
        drawdown_limit  DECIMAL(18,2)    NULL,
        -- BaseEntity
        created_at      DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at      DATETIME2(7)     NULL,
        -- TemporalEntity
        valid_from      DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        valid_to        DATETIME2(7)     NOT NULL DEFAULT '9999-12-31',
        system_from     DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        system_to       DATETIME2(7)     NOT NULL DEFAULT '9999-12-31',
        is_current      BIT              NOT NULL DEFAULT 1,
        is_deleted      BIT              NOT NULL DEFAULT 0,
        created_by     NVARCHAR(255),

        last_modified_by     NVARCHAR(255)    NULL,
        CONSTRAINT fk_security_loan_attribute_security
            FOREIGN KEY (security_id) REFERENCES dbo.security (id),
        CONSTRAINT ck_security_loan_attribute_valid_time  CHECK (valid_from  < valid_to),
        CONSTRAINT ck_security_loan_attribute_system_time CHECK (system_from < system_to)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_security_loan_attribute_current' AND object_id = OBJECT_ID('dbo.security_loan_attribute'))
    CREATE UNIQUE INDEX ux_security_loan_attribute_current
        ON dbo.security_loan_attribute (security_id)
        WHERE is_current = 1 AND is_deleted = 0;
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ SecurityDerivativeAttributes ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'security_derivative_attribute' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.security_derivative_attribute (
        id              UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        security_id     UNIQUEIDENTIFIER NOT NULL,
        underlying_type NVARCHAR(50)     NULL,
        underlying_id   UNIQUEIDENTIFIER NULL,
        notional        DECIMAL(28,8)    NULL,
        notional_ccy    NCHAR(3)         NULL,
        strike_price    DECIMAL(28,8)    NULL,
        strike_ccy      NCHAR(3)         NULL,
        option_style    NVARCHAR(20)     NULL,
        option_type     NVARCHAR(10)     NULL,
        expiry_date     DATETIME2(7)     NULL,
        settlement_type NVARCHAR(20)     NULL,
        leg_count       INT              NULL,
        -- BaseEntity
        created_at      DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at      DATETIME2(7)     NULL,
        -- TemporalEntity
        valid_from      DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        valid_to        DATETIME2(7)     NOT NULL DEFAULT '9999-12-31',
        system_from     DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        system_to       DATETIME2(7)     NOT NULL DEFAULT '9999-12-31',
        is_current      BIT              NOT NULL DEFAULT 1,
        is_deleted      BIT              NOT NULL DEFAULT 0,
        created_by     NVARCHAR(255),

        last_modified_by     NVARCHAR(255)    NULL,
        CONSTRAINT fk_security_derivative_attribute_security
            FOREIGN KEY (security_id) REFERENCES dbo.security (id),
        CONSTRAINT ck_security_derivative_attribute_valid_time  CHECK (valid_from  < valid_to),
        CONSTRAINT ck_security_derivative_attribute_system_time CHECK (system_from < system_to)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_security_derivative_attribute_current' AND object_id = OBJECT_ID('dbo.security_derivative_attribute'))
    CREATE UNIQUE INDEX ux_security_derivative_attribute_current
        ON dbo.security_derivative_attribute (security_id)
        WHERE is_current = 1 AND is_deleted = 0;
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ SecuritySecuritizedAttributes ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'security_securitized_attribute' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.security_securitized_attribute (
        id                 UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        security_id        UNIQUEIDENTIFIER NOT NULL,
        pool_id            NVARCHAR(100)    NULL,
        tranche_label      NVARCHAR(50)     NULL,
        tranche_seniority  NVARCHAR(50)     NULL,
        original_balance   DECIMAL(28,8)    NULL,
        current_balance    DECIMAL(28,8)    NULL,
        credit_enhancement DECIMAL(9,4)     NULL,
        callable           BIT              NULL,
        call_date          DATETIME2(7)     NULL,
        -- BaseEntity
        created_at         DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at         DATETIME2(7)     NULL,
        -- TemporalEntity
        valid_from         DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        valid_to           DATETIME2(7)     NOT NULL DEFAULT '9999-12-31',
        system_from        DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        system_to          DATETIME2(7)     NOT NULL DEFAULT '9999-12-31',
        is_current         BIT              NOT NULL DEFAULT 1,
        is_deleted         BIT              NOT NULL DEFAULT 0,
        created_by        NVARCHAR(255),

        last_modified_by        NVARCHAR(255)    NULL,
        CONSTRAINT fk_security_securitized_attribute_security
            FOREIGN KEY (security_id) REFERENCES dbo.security (id),
        CONSTRAINT ck_security_securitized_attribute_valid_time  CHECK (valid_from  < valid_to),
        CONSTRAINT ck_security_securitized_attribute_system_time CHECK (system_from < system_to)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_security_securitized_attribute_current' AND object_id = OBJECT_ID('dbo.security_securitized_attribute'))
    CREATE UNIQUE INDEX ux_security_securitized_attribute_current
        ON dbo.security_securitized_attribute (security_id)
        WHERE is_current = 1 AND is_deleted = 0;
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ SecurityAttributeKv ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'security_attribute_kv' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.security_attribute_kv (
        id             UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        security_id    UNIQUEIDENTIFIER NOT NULL,
        attribute_name NVARCHAR(100)    NOT NULL,
        attribute_type NVARCHAR(20)     NOT NULL,
        value_string   NVARCHAR(4000)   NULL,
        value_decimal  DECIMAL(28,10)   NULL,
        value_int      BIGINT           NULL,
        value_date     DATETIME2(7)     NULL,
        value_bool     BIT              NULL,
        source_system  NVARCHAR(50)     NULL,
        -- BaseEntity
        created_at     DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at     DATETIME2(7)     NULL,
        -- TemporalEntity
        valid_from     DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        valid_to       DATETIME2(7)     NOT NULL DEFAULT '9999-12-31',
        system_from    DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        system_to      DATETIME2(7)     NOT NULL DEFAULT '9999-12-31',
        is_current     BIT              NOT NULL DEFAULT 1,
        is_deleted     BIT              NOT NULL DEFAULT 0,
        created_by    NVARCHAR(255),

        last_modified_by    NVARCHAR(255)    NULL,
        CONSTRAINT fk_security_attribute_kv_security
            FOREIGN KEY (security_id) REFERENCES dbo.security (id),
        CONSTRAINT ck_security_attribute_kv_valid_time  CHECK (valid_from  < valid_to),
        CONSTRAINT ck_security_attribute_kv_system_time CHECK (system_from < system_to),
        CONSTRAINT ck_security_attribute_kv_single_value CHECK (
            (CASE WHEN value_string  IS NOT NULL THEN 1 ELSE 0 END) +
            (CASE WHEN value_decimal IS NOT NULL THEN 1 ELSE 0 END) +
            (CASE WHEN value_int     IS NOT NULL THEN 1 ELSE 0 END) +
            (CASE WHEN value_date    IS NOT NULL THEN 1 ELSE 0 END) +
            (CASE WHEN value_bool    IS NOT NULL THEN 1 ELSE 0 END)
            <= 1
        )
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_security_attribute_kv_current' AND object_id = OBJECT_ID('dbo.security_attribute_kv'))
    CREATE UNIQUE INDEX ux_security_attribute_kv_current
        ON dbo.security_attribute_kv (security_id, attribute_name)
        WHERE is_current = 1 AND is_deleted = 0;
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ AuditLogs ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'audit_log' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.audit_log (
        id             UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        entity_type    NVARCHAR(50)     NOT NULL,
        action         NVARCHAR(50)     NOT NULL,
        user_id        UNIQUEIDENTIFIER,
        user_name      NVARCHAR(255),
        details        NVARCHAR(MAX),
        ip_address     NVARCHAR(45),
        entity_id      UNIQUEIDENTIFIER,
        before_state   NVARCHAR(MAX),
        after_state    NVARCHAR(MAX),
        changed_fields NVARCHAR(MAX),
        correlation_id UNIQUEIDENTIFIER,
        causation_id   UNIQUEIDENTIFIER,
        source         NVARCHAR(50)     NOT NULL DEFAULT 'Http',
        created_at     DATETIME2        NOT NULL DEFAULT GETUTCDATE()
    );
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ IdempotencyKeyStore ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
-- Milestone 1A: prevents duplicate processing of mutating REST/gRPC calls.
-- Rows expire via expires_at; cleaned up by ExecutionHistoryCleanupJob.
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'idempotency_key_store' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.idempotency_key_store (
        [key]          NVARCHAR(200) NOT NULL,
        operation_type NVARCHAR(100) NOT NULL,
        status         NVARCHAR(20)  NOT NULL DEFAULT 'PROCESSING',
        -- PROCESSING | COMPLETED | FAILED
        response_code  INT           NULL,
        response_body  NVARCHAR(MAX) NULL,
        created_at     DATETIME2(3)  NOT NULL DEFAULT GETUTCDATE(),
        expires_at     DATETIME2(3)  NOT NULL,
        CONSTRAINT pk_idempotency_key_store PRIMARY KEY ([key]),
        CONSTRAINT ck_idempotency_status CHECK (status IN ('PROCESSING','COMPLETED','FAILED'))
    );
    CREATE INDEX ix_idempotency_expires_at ON dbo.idempotency_key_store (expires_at);
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ DeadLetterEvent ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
-- Milestone 1B: durable DLQ store for messages that exhausted Wolverine retries.
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'dead_letter_event' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.dead_letter_event (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        event_type       NVARCHAR(100)    NOT NULL,
        correlation_id   UNIQUEIDENTIFIER NOT NULL,
        idempotency_key  NVARCHAR(200)    NULL,
        payload          NVARCHAR(MAX)    NOT NULL,
        failure_reason   NVARCHAR(500)    NOT NULL,
        failure_stage    INT              NOT NULL DEFAULT 0,
        -- 0=unknown 1=schema 2=domain 3=business 4=transport 5=timeout
        retry_count      INT              NOT NULL DEFAULT 0,
        status           NVARCHAR(20)     NOT NULL DEFAULT 'PENDING',
        -- PENDING | IN_REVIEW | REPLAYED | RESOLVED | DISCARDED
        resolved_by      NVARCHAR(255)    NULL,
        resolved_at      DATETIME2(3)     NULL,
        resolution_notes NVARCHAR(500)    NULL,
        created_at       DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at       DATETIME2(3)     NULL,
        created_by      NVARCHAR(255),

        last_modified_by      NVARCHAR(255)    NULL,
        CONSTRAINT pk_dead_letter_event PRIMARY KEY (id),
        CONSTRAINT ck_dead_letter_status CHECK (status IN ('PENDING','IN_REVIEW','REPLAYED','RESOLVED','DISCARDED'))
    );
    CREATE INDEX ix_dle_status         ON dbo.dead_letter_event (status);
    CREATE INDEX ix_dle_event_type     ON dbo.dead_letter_event (event_type);
    CREATE INDEX ix_dle_correlation_id ON dbo.dead_letter_event (correlation_id);
    CREATE INDEX ix_dle_created_at     ON dbo.dead_letter_event (created_at);
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ ImportRequests ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'import_request' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.import_request (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        -- BaseEntity
        created_at        DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at        DATETIME2,
        -- Request fields (stored as string names via EF Core HasConversion<string>())
        request_type      NVARCHAR(50)     NOT NULL,
        source_system     NVARCHAR(50),
        target_system     NVARCHAR(50),
        status           NVARCHAR(50)     NOT NULL DEFAULT 'InProgress',
        user_id           UNIQUEIDENTIFIER,
        user_name         NVARCHAR(255),
        completed_at      DATETIME2,
        error_message     NVARCHAR(MAX),
        request_details   NVARCHAR(MAX),
        total_records     INT,
        processed_records INT,
        failed_records    INT,
        attempt_number    INT              NOT NULL DEFAULT 0,
        skipped_records   INT              NULL
    );
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ CreditRatings ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'credit_rating' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.credit_rating (
        id         UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        security_id UNIQUEIDENTIFIER NOT NULL,
        agency     NVARCHAR(50)     NOT NULL,
        rating     NVARCHAR(20)     NOT NULL,
        rating_type NVARCHAR(30)     NOT NULL DEFAULT 'LongTerm',
        rating_date DATETIME2,
        -- BaseEntity
        created_at  DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at  DATETIME2,
        -- TemporalEntity
        valid_from  DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to    DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to   DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current  BIT              NOT NULL DEFAULT 1,
        is_deleted  BIT              NOT NULL DEFAULT 0,
        created_by NVARCHAR(255),

        last_modified_by NVARCHAR(255),
        content_hash     NVARCHAR(64)     NULL,
        CONSTRAINT fk_credit_rating_security
            FOREIGN KEY (security_id) REFERENCES dbo.security (id) ON DELETE CASCADE
    );
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ DerivedRatings ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'derived_rating' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.derived_rating (
        id                     UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        security_id             UNIQUEIDENTIFIER NOT NULL,
        implied_rating_score     INT,
        vpm_rating_score         INT,
        fundamental_rating_score INT,
        composite_rating_score   INT,
        output_agency           NVARCHAR(30)     NOT NULL DEFAULT 'SP',
        implied_rating          NVARCHAR(20),
        vpm_rating              NVARCHAR(20),
        fundamental_rating      NVARCHAR(20),
        composite_rating        NVARCHAR(20),
        implied_pd              DECIMAL(12,10) NULL,
        model_pd                DECIMAL(12,10) NULL,
        fair_price              DECIMAL(18,6),
        source_hash             NVARCHAR(64)     NOT NULL DEFAULT '',
        last_calculated_utc      DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        -- BaseEntity
        created_at              DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at              DATETIME2,
        -- TemporalEntity
        valid_from              DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to                DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from             DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to               DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current              BIT              NOT NULL DEFAULT 1,
        is_deleted              BIT              NOT NULL DEFAULT 0,
        created_by             NVARCHAR(255),

        last_modified_by             NVARCHAR(255),
        CONSTRAINT fk_derived_rating_security
            FOREIGN KEY (security_id) REFERENCES dbo.security (id) ON DELETE CASCADE
    );
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ VendorRatingMetadata ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'vendor_rating_metadata' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.vendor_rating_metadata (
        id              UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        vendor_name      NVARCHAR(100)    NOT NULL,
        accuracy_score   DECIMAL(5,4)     NOT NULL DEFAULT 0.5,
        stability_score  DECIMAL(5,4)     NOT NULL DEFAULT 0.5,
        timeliness_score DECIMAL(5,4)     NOT NULL DEFAULT 0.5,
        coverage_score   DECIMAL(5,4)     NOT NULL DEFAULT 0.5,
        last_updated_utc  DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        -- BaseEntity
        created_at       DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at       DATETIME2,
        CONSTRAINT uq_vendor_rating_metadata_vendor_name UNIQUE (vendor_name)
    );
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ RatingScaleEntries ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'rating_scale_entry' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.rating_scale_entry (
        id                UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        agency            NVARCHAR(50)     NOT NULL,
        score             INT              NOT NULL,
        label             NVARCHAR(20)     NOT NULL,
        is_investment_grade BIT              NOT NULL DEFAULT 0,
        -- BaseEntity
        created_at         DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at         DATETIME2,
        -- TemporalEntity
        valid_from         DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to           DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from        DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to          DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current         BIT              NOT NULL DEFAULT 1,
        is_deleted         BIT              NOT NULL DEFAULT 0,
        created_by        NVARCHAR(255),

        last_modified_by        NVARCHAR(255)
    );
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ RatingDerivationRules ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'rating_derivation_rule' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.rating_derivation_rule (
        id           UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        model_name    NVARCHAR(50)     NOT NULL,
        security_type NVARCHAR(50),
        config_json   NVARCHAR(MAX)    NOT NULL DEFAULT '{}',
        description  NVARCHAR(500),
        -- BaseEntity
        created_at    DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at    DATETIME2,
        -- TemporalEntity
        valid_from    DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to      DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from   DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to     DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current    BIT              NOT NULL DEFAULT 1,
        is_deleted    BIT              NOT NULL DEFAULT 0,
        created_by   NVARCHAR(255),

        last_modified_by   NVARCHAR(255)
    );
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ FormulaMacros ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'formula_macro' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.formula_macro (
        id          UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        name        NVARCHAR(100)    NOT NULL,
        expression  NVARCHAR(MAX)    NOT NULL,
        description NVARCHAR(500),
        scope       NVARCHAR(50),
        -- BaseEntity
        created_at   DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at   DATETIME2,
        -- TemporalEntity
        valid_from   DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to     DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from  DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to    DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current   BIT              NOT NULL DEFAULT 1,
        is_deleted   BIT              NOT NULL DEFAULT 0,
        created_by  NVARCHAR(255),

        last_modified_by  NVARCHAR(255)
    );
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ ImportProfiles ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'import_profile' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.import_profile (
        id             UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        name           NVARCHAR(100)    NOT NULL,
        description    NVARCHAR(500),
        source_type     NVARCHAR(50)     NOT NULL,
        file_pattern    NVARCHAR(200)    NOT NULL DEFAULT '*.csv',
        folder         NVARCHAR(500),
        delimiter      NVARCHAR(10),
        text_qualifier  NVARCHAR(5),
        has_header      BIT              NOT NULL DEFAULT 1,
        skip_rows       INT              NOT NULL DEFAULT 0,
        records_path    NVARCHAR(500),
        records_x_path   NVARCHAR(500),
        -- Transport
        transport_type             NVARCHAR(20)     NOT NULL DEFAULT 'Local',
        transport_host             NVARCHAR(500),
        transport_port             INT,
        transport_username         NVARCHAR(200),
        transport_password_secret  NVARCHAR(500),
        transport_remote_path      NVARCHAR(500),
        transport_tls_thumbprint   NVARCHAR(100),
        is_active       BIT              NOT NULL DEFAULT 1,
        -- BaseEntity
        created_at      DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at      DATETIME2
    );
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ ImportProfileColumns ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'import_profile_column' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.import_profile_column (
        id           UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        profile_id    UNIQUEIDENTIFIER NOT NULL,
        source_column NVARCHAR(200)    NOT NULL,
        target_field  NVARCHAR(200)    NOT NULL,
        sort_order    INT              NOT NULL DEFAULT 0,
        -- BaseEntity
        created_at    DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at    DATETIME2,
        CONSTRAINT fk__import_profile_column__import_profile
            FOREIGN KEY (profile_id) REFERENCES dbo.import_profile (id)
            ON DELETE CASCADE
    );
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ ImportProfileColumnValidations ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'import_profile_column_validation' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.import_profile_column_validation (
        id           UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        column_id     UNIQUEIDENTIFIER NOT NULL,
        rule_type     NVARCHAR(50)     NOT NULL,
        rule_value    NVARCHAR(500),
        condition    NVARCHAR(1000),
        error_message NVARCHAR(500),
        severity     NVARCHAR(20)     NOT NULL DEFAULT 'Error',
        is_active     BIT              NOT NULL DEFAULT 1,
        -- BaseEntity
        created_at    DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at    DATETIME2,
        CONSTRAINT fk__import_profile_column_validation__import_profile_column
            FOREIGN KEY (column_id) REFERENCES dbo.import_profile_column (id)
            ON DELETE CASCADE
    );
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ ImportProfileRowValidations ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'import_profile_row_validation' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.import_profile_row_validation (
        id           UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        profile_id    UNIQUEIDENTIFIER NOT NULL,
        expression   NVARCHAR(MAX)    NOT NULL,
        error_message NVARCHAR(500)    NOT NULL,
        severity     NVARCHAR(20)     NOT NULL DEFAULT 'Error',
        sort_order    INT              NOT NULL DEFAULT 0,
        is_active     BIT              NOT NULL DEFAULT 1,
        -- BaseEntity
        created_at    DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at    DATETIME2,
        CONSTRAINT fk__import_profile_row_validation__import_profile
            FOREIGN KEY (profile_id) REFERENCES dbo.import_profile (id)
            ON DELETE CASCADE
    );
END
GO

-- ====================================================================
-- Indexes
-- ====================================================================
SET QUOTED_IDENTIFIER ON;
GO

-- Identity
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'user_name_index' AND object_id = OBJECT_ID('dbo.AspNetUsers'))
    CREATE UNIQUE INDEX user_name_index              ON dbo.[AspNetUsers]      (NormalizedUserName) WHERE NormalizedUserName IS NOT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'email_index' AND object_id = OBJECT_ID('dbo.AspNetUsers'))
    CREATE INDEX email_index                        ON dbo.[AspNetUsers]      (NormalizedEmail);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'role_name_index' AND object_id = OBJECT_ID('dbo.AspNetRoles'))
    CREATE UNIQUE INDEX role_name_index              ON dbo.[AspNetRoles]      (NormalizedName) WHERE NormalizedName IS NOT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__asp_net_user_claims__user_id' AND object_id = OBJECT_ID('dbo.AspNetUserClaims'))
    CREATE INDEX ix__asp_net_user_claims__user_id         ON dbo.[AspNetUserClaims] (UserId);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__asp_net_user_logins__user_id' AND object_id = OBJECT_ID('dbo.AspNetUserLogins'))
    CREATE INDEX ix__asp_net_user_logins__user_id         ON dbo.[AspNetUserLogins] (UserId);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__asp_net_user_roles__role_id' AND object_id = OBJECT_ID('dbo.AspNetUserRoles'))
    CREATE INDEX ix__asp_net_user_roles__role_id          ON dbo.[AspNetUserRoles]  (RoleId);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__asp_net_role_claims__role_id' AND object_id = OBJECT_ID('dbo.AspNetRoleClaims'))
    CREATE INDEX ix__asp_net_role_claims__role_id         ON dbo.[AspNetRoleClaims] (RoleId);
GO

-- Securities
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_security_name_current' AND object_id = OBJECT_ID('dbo.security'))
    CREATE INDEX ix_security_name_current
        ON dbo.security (name)
        WHERE is_current = 1 AND is_deleted = 0;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_security_currency_code' AND object_id = OBJECT_ID('dbo.security'))
    CREATE INDEX ix_security_currency_code
        ON dbo.security (currency_code)
        WHERE is_current = 1 AND is_deleted = 0;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security__is_current' AND object_id = OBJECT_ID('dbo.security'))
    CREATE INDEX ix__security__is_current  ON dbo.security (is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security__valid_time' AND object_id = OBJECT_ID('dbo.security'))
    CREATE INDEX ix__security__valid_time  ON dbo.security (valid_from, valid_to);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security__system_time' AND object_id = OBJECT_ID('dbo.security'))
    CREATE INDEX ix__security__system_time ON dbo.security (system_from, system_to);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security__is_deleted' AND object_id = OBJECT_ID('dbo.security'))
    CREATE INDEX ix__security__is_deleted  ON dbo.security (is_deleted);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_security_status_code' AND object_id = OBJECT_ID('dbo.security'))
    CREATE NONCLUSTERED INDEX ix_security_status_code          ON dbo.security (status_code)          WHERE is_deleted = 0;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_security_asset_class_code' AND object_id = OBJECT_ID('dbo.security'))
    CREATE NONCLUSTERED INDEX ix_security_asset_class_code     ON dbo.security (asset_class_code)     WHERE is_deleted = 0;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_security_instrument_type_code' AND object_id = OBJECT_ID('dbo.security'))
    CREATE NONCLUSTERED INDEX ix_security_instrument_type_code ON dbo.security (instrument_type_code) WHERE is_deleted = 0;
GO

-- Prices
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__price__security_id__source__price_date' AND object_id = OBJECT_ID('dbo.price'))
    CREATE INDEX ix__price__security_id__source__price_date ON dbo.price (security_id, source, price_date);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__price__is_current' AND object_id = OBJECT_ID('dbo.price'))
    CREATE INDEX ix__price__is_current  ON dbo.price (is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__price__valid_time' AND object_id = OBJECT_ID('dbo.price'))
    CREATE INDEX ix__price__valid_time  ON dbo.price (valid_from, valid_to);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__price__system_time' AND object_id = OBJECT_ID('dbo.price'))
    CREATE INDEX ix__price__system_time ON dbo.price (system_from, system_to);
GO

-- SecurityCoreAttributes
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_core_attribute__security_id' AND object_id = OBJECT_ID('dbo.security_core_attribute'))
    CREATE INDEX ix__security_core_attribute__security_id ON dbo.security_core_attribute (security_id);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_core_attribute__is_current' AND object_id = OBJECT_ID('dbo.security_core_attribute'))
    CREATE INDEX ix__security_core_attribute__is_current  ON dbo.security_core_attribute (is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_core_attribute__valid_time' AND object_id = OBJECT_ID('dbo.security_core_attribute'))
    CREATE INDEX ix__security_core_attribute__valid_time  ON dbo.security_core_attribute (valid_from, valid_to);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_core_attribute__system_time' AND object_id = OBJECT_ID('dbo.security_core_attribute'))
    CREATE INDEX ix__security_core_attribute__system_time ON dbo.security_core_attribute (system_from, system_to);
GO

-- SecurityLoanAttributes
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_loan_attribute__security_id' AND object_id = OBJECT_ID('dbo.security_loan_attribute'))
    CREATE INDEX ix__security_loan_attribute__security_id ON dbo.security_loan_attribute (security_id);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_loan_attribute__is_current' AND object_id = OBJECT_ID('dbo.security_loan_attribute'))
    CREATE INDEX ix__security_loan_attribute__is_current  ON dbo.security_loan_attribute (is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_loan_attribute__valid_time' AND object_id = OBJECT_ID('dbo.security_loan_attribute'))
    CREATE INDEX ix__security_loan_attribute__valid_time  ON dbo.security_loan_attribute (valid_from, valid_to);
GO

-- SecurityDerivativeAttributes
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_derivative_attribute__security_id' AND object_id = OBJECT_ID('dbo.security_derivative_attribute'))
    CREATE INDEX ix__security_derivative_attribute__security_id ON dbo.security_derivative_attribute (security_id);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_derivative_attribute__is_current' AND object_id = OBJECT_ID('dbo.security_derivative_attribute'))
    CREATE INDEX ix__security_derivative_attribute__is_current  ON dbo.security_derivative_attribute (is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_derivative_attribute__valid_time' AND object_id = OBJECT_ID('dbo.security_derivative_attribute'))
    CREATE INDEX ix__security_derivative_attribute__valid_time  ON dbo.security_derivative_attribute (valid_from, valid_to);
GO

-- SecuritySecuritizedAttributes
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_securitized_attribute__security_id' AND object_id = OBJECT_ID('dbo.security_securitized_attribute'))
    CREATE INDEX ix__security_securitized_attribute__security_id ON dbo.security_securitized_attribute (security_id);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_securitized_attribute__is_current' AND object_id = OBJECT_ID('dbo.security_securitized_attribute'))
    CREATE INDEX ix__security_securitized_attribute__is_current  ON dbo.security_securitized_attribute (is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_securitized_attribute__valid_time' AND object_id = OBJECT_ID('dbo.security_securitized_attribute'))
    CREATE INDEX ix__security_securitized_attribute__valid_time  ON dbo.security_securitized_attribute (valid_from, valid_to);
GO

-- SecurityAttributeKv
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_attribute_kv__security_id' AND object_id = OBJECT_ID('dbo.security_attribute_kv'))
    CREATE INDEX ix__security_attribute_kv__security_id ON dbo.security_attribute_kv (security_id);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_attribute_kv__is_current' AND object_id = OBJECT_ID('dbo.security_attribute_kv'))
    CREATE INDEX ix__security_attribute_kv__is_current  ON dbo.security_attribute_kv (is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security_attribute_kv__valid_time' AND object_id = OBJECT_ID('dbo.security_attribute_kv'))
    CREATE INDEX ix__security_attribute_kv__valid_time  ON dbo.security_attribute_kv (valid_from, valid_to);
GO

-- AuditLogs
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__audit_log__created_at' AND object_id = OBJECT_ID('dbo.audit_log'))
    CREATE INDEX ix__audit_log__created_at ON dbo.audit_log (created_at);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__audit_log__user_id' AND object_id = OBJECT_ID('dbo.audit_log'))
    CREATE INDEX ix__audit_log__user_id    ON dbo.audit_log (user_id);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__audit_log__entity_type_entity_id' AND object_id = OBJECT_ID('dbo.audit_log'))
    CREATE INDEX ix__audit_log__entity_type_entity_id ON dbo.audit_log (entity_type, entity_id);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__audit_log__correlation_id' AND object_id = OBJECT_ID('dbo.audit_log'))
    CREATE INDEX ix__audit_log__correlation_id ON dbo.audit_log (correlation_id);
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ AuditLog archive ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â M22 ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
-- Partition function: monthly RANGE RIGHT on DATETIME2.
-- Seeded 2025-01 ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ 2030-01; auto-extended by AuditArchiveJobPlugin.
IF NOT EXISTS (SELECT 1 FROM sys.partition_functions WHERE name = 'pf_audit_log_monthly')
BEGIN
    CREATE PARTITION FUNCTION pf_audit_log_monthly (DATETIME2)
    AS RANGE RIGHT FOR VALUES (
        '2025-01-01', '2025-02-01', '2025-03-01', '2025-04-01',
        '2025-05-01', '2025-06-01', '2025-07-01', '2025-08-01',
        '2025-09-01', '2025-10-01', '2025-11-01', '2025-12-01',
        '2026-01-01', '2026-02-01', '2026-03-01', '2026-04-01',
        '2026-05-01', '2026-06-01', '2026-07-01', '2026-08-01',
        '2026-09-01', '2026-10-01', '2026-11-01', '2026-12-01',
        '2027-01-01', '2027-02-01', '2027-03-01', '2027-04-01',
        '2027-05-01', '2027-06-01', '2027-07-01', '2027-08-01',
        '2027-09-01', '2027-10-01', '2027-11-01', '2027-12-01',
        '2028-01-01', '2028-02-01', '2028-03-01', '2028-04-01',
        '2028-05-01', '2028-06-01', '2028-07-01', '2028-08-01',
        '2028-09-01', '2028-10-01', '2028-11-01', '2028-12-01',
        '2029-01-01', '2029-02-01', '2029-03-01', '2029-04-01',
        '2029-05-01', '2029-06-01', '2029-07-01', '2029-08-01',
        '2029-09-01', '2029-10-01', '2029-11-01', '2029-12-01',
        '2030-01-01'
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.partition_schemes WHERE name = 'ps_audit_log_monthly')
    CREATE PARTITION SCHEME ps_audit_log_monthly
    AS PARTITION pf_audit_log_monthly ALL TO ([PRIMARY]);
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'audit_log_archive' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.audit_log_archive (
        id             UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
        entity_type    NVARCHAR(50)     NOT NULL,
        action         NVARCHAR(50)     NOT NULL,
        user_id        UNIQUEIDENTIFIER NULL,
        user_name      NVARCHAR(255)    NULL,
        details        NVARCHAR(MAX)    NULL,
        ip_address     NVARCHAR(45)     NULL,
        entity_id      UNIQUEIDENTIFIER NULL,
        before_state   NVARCHAR(MAX)    NULL,
        after_state    NVARCHAR(MAX)    NULL,
        changed_fields NVARCHAR(MAX)    NULL,
        correlation_id UNIQUEIDENTIFIER NULL,
        causation_id   UNIQUEIDENTIFIER NULL,
        source         NVARCHAR(50)     NOT NULL DEFAULT 'Http',
        created_at     DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        archived_at    DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        CONSTRAINT pk_audit_log_archive PRIMARY KEY CLUSTERED (created_at, id)
    ) ON ps_audit_log_monthly(created_at);

    CREATE INDEX ix_ala_entity_type_entity_id
        ON dbo.audit_log_archive (entity_type, entity_id)
        ON ps_audit_log_monthly(created_at);

    CREATE INDEX ix_ala_user_id
        ON dbo.audit_log_archive (user_id)
        ON ps_audit_log_monthly(created_at);

    CREATE INDEX ix_ala_correlation_id
        ON dbo.audit_log_archive (correlation_id)
        WHERE correlation_id IS NOT NULL
        ON ps_audit_log_monthly(created_at);
END
GO

-- ImportRequests
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__import_request__status' AND object_id = OBJECT_ID('dbo.import_request'))
    CREATE INDEX ix__import_request__status     ON dbo.import_request (status);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__import_request__created_at' AND object_id = OBJECT_ID('dbo.import_request'))
    CREATE INDEX ix__import_request__created_at  ON dbo.import_request (created_at DESC);
GO

-- CreditRatings
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__credit_rating__security_id__agency__rating_type__is_current' AND object_id = OBJECT_ID('dbo.credit_rating'))
    CREATE INDEX ix__credit_rating__security_id__agency__rating_type__is_current
        ON dbo.credit_rating (security_id, agency, rating_type, is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__credit_rating__valid_time' AND object_id = OBJECT_ID('dbo.credit_rating'))
    CREATE INDEX ix__credit_rating__valid_time  ON dbo.credit_rating (valid_from, valid_to);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__credit_rating__system_time' AND object_id = OBJECT_ID('dbo.credit_rating'))
    CREATE INDEX ix__credit_rating__system_time ON dbo.credit_rating (system_from, system_to);
GO

-- DerivedRatings
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__derived_rating__security_id' AND object_id = OBJECT_ID('dbo.derived_rating'))
    CREATE INDEX ix__derived_rating__security_id       ON dbo.derived_rating (security_id);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__derived_rating__security__current' AND object_id = OBJECT_ID('dbo.derived_rating'))
    CREATE INDEX ix__derived_rating__security__current ON dbo.derived_rating (security_id, is_current)
        INCLUDE (composite_rating_score, composite_rating, output_agency);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__derived_rating__valid_time' AND object_id = OBJECT_ID('dbo.derived_rating'))
    CREATE INDEX ix__derived_rating__valid_time        ON dbo.derived_rating (valid_from, valid_to);
GO

-- ImportProfiles
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'uix__import_profile__name__source_type' AND object_id = OBJECT_ID('dbo.import_profile'))
    CREATE UNIQUE INDEX uix__import_profile__name__source_type
        ON dbo.import_profile (name, source_type);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__import_profile__source_type__is_active' AND object_id = OBJECT_ID('dbo.import_profile'))
    CREATE INDEX ix__import_profile__source_type__is_active
        ON dbo.import_profile (source_type, is_active);
GO

-- ImportProfileColumns
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__import_profile_column__profile_id' AND object_id = OBJECT_ID('dbo.import_profile_column'))
    CREATE INDEX ix__import_profile_column__profile_id
        ON dbo.import_profile_column (profile_id);
GO

-- ImportProfileColumnValidations
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__import_profile_column_validation__column_id' AND object_id = OBJECT_ID('dbo.import_profile_column_validation'))
    CREATE INDEX ix__import_profile_column_validation__column_id
        ON dbo.import_profile_column_validation (column_id);
GO

-- ImportProfileRowValidations
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__import_profile_row_validation__profile_id' AND object_id = OBJECT_ID('dbo.import_profile_row_validation'))
    CREATE INDEX ix__import_profile_row_validation__profile_id
        ON dbo.import_profile_row_validation (profile_id);
GO

-- RatingScaleEntries
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__rating_scale_entry__agency__score' AND object_id = OBJECT_ID('dbo.rating_scale_entry'))
    CREATE INDEX ix__rating_scale_entry__agency__score
        ON dbo.rating_scale_entry (agency, score, is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__rating_scale_entry__valid_time' AND object_id = OBJECT_ID('dbo.rating_scale_entry'))
    CREATE INDEX ix__rating_scale_entry__valid_time ON dbo.rating_scale_entry (valid_from, valid_to);
GO

-- RatingDerivationRules
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__rating_derivation_rule__model_type' AND object_id = OBJECT_ID('dbo.rating_derivation_rule'))
    CREATE INDEX ix__rating_derivation_rule__model_type
        ON dbo.rating_derivation_rule (model_name, security_type, is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__rating_derivation_rule__valid_time' AND object_id = OBJECT_ID('dbo.rating_derivation_rule'))
    CREATE INDEX ix__rating_derivation_rule__valid_time ON dbo.rating_derivation_rule (valid_from, valid_to);
GO

-- FormulaMacros
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__formula_macro__name__current' AND object_id = OBJECT_ID('dbo.formula_macro'))
    CREATE INDEX ix__formula_macro__name__current ON dbo.formula_macro (name, is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__formula_macro__valid_time' AND object_id = OBJECT_ID('dbo.formula_macro'))
    CREATE INDEX ix__formula_macro__valid_time    ON dbo.formula_macro (valid_from, valid_to);
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
-- Job Scheduling
-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'job_execution_history' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.job_execution_history (
        id               UNIQUEIDENTIFIER NOT NULL,
        job_name         NVARCHAR(200)    NOT NULL,
        job_group        NVARCHAR(200)    NOT NULL,
        triggered_by     NVARCHAR(255)    NOT NULL  DEFAULT 'scheduler',
        started_at       DATETIME2(3)     NOT NULL,
        completed_at     DATETIME2(3)         NULL,
        succeeded        BIT              NOT NULL  DEFAULT 0,
        error_message    NVARCHAR(2000)       NULL,
        error_detail     NVARCHAR(MAX)        NULL,
        skipped_records  INT                  NULL,
        CONSTRAINT pk__job_execution_history PRIMARY KEY (id)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'job_schedule' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.job_schedule (
        id              UNIQUEIDENTIFIER NOT NULL  DEFAULT NEWID(),
        plugin_name     NVARCHAR(200)    NOT NULL,
        job_group       NVARCHAR(200)    NOT NULL,
        cron_expression NVARCHAR(100)        NULL,
        enabled         BIT              NOT NULL  DEFAULT 1,
        time_zone       NVARCHAR(100)    NOT NULL  DEFAULT 'UTC',
        -- BaseEntity
        created_at      DATETIME2        NOT NULL  DEFAULT GETUTCDATE(),
        last_modified_at      DATETIME2            NULL,
        -- TemporalEntity
        valid_from      DATETIME2        NOT NULL  DEFAULT GETUTCDATE(),
        valid_to        DATETIME2        NOT NULL  DEFAULT '9999-12-31',
        system_from     DATETIME2        NOT NULL  DEFAULT GETUTCDATE(),
        system_to       DATETIME2        NOT NULL  DEFAULT '9999-12-31',
        is_current      BIT              NOT NULL  DEFAULT 1,
        is_deleted      BIT              NOT NULL  DEFAULT 0,
        created_by     NVARCHAR(255),

        last_modified_by     NVARCHAR(255)        NULL,
        CONSTRAINT pk__job_schedule PRIMARY KEY (id)
    );
END
GO

-- JobExecutionHistory
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__job_execution_history__job_name' AND object_id = OBJECT_ID('dbo.job_execution_history'))
    CREATE INDEX ix__job_execution_history__job_name       ON dbo.job_execution_history (job_name);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__job_execution_history__started_at' AND object_id = OBJECT_ID('dbo.job_execution_history'))
    CREATE INDEX ix__job_execution_history__started_at ON dbo.job_execution_history (started_at DESC);
GO

-- JobSchedules
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__job_schedule__plugin_name' AND object_id = OBJECT_ID('dbo.job_schedule'))
    CREATE INDEX ix__job_schedule__plugin_name ON dbo.job_schedule (plugin_name);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__job_schedule__is_current' AND object_id = OBJECT_ID('dbo.job_schedule'))
    CREATE INDEX ix__job_schedule__is_current  ON dbo.job_schedule (is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__job_schedule__system_time' AND object_id = OBJECT_ID('dbo.job_schedule'))
    CREATE INDEX ix__job_schedule__system_time ON dbo.job_schedule (system_from, system_to);
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ ApprovalRequests ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'approval_request' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.approval_request (
        id                  UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        type                NVARCHAR(100)    NOT NULL,
        status              NVARCHAR(50)     NOT NULL DEFAULT 'Pending',
        security_ids        NVARCHAR(MAX)    NULL,
        requested_by        NVARCHAR(256)    NOT NULL,
        requested_at        DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        reviewed_by         NVARCHAR(256)    NULL,
        reviewed_at         DATETIME2        NULL,
        expires_at          DATETIME2        NULL,
        notes               NVARCHAR(MAX)    NULL,
        export_request_id   UNIQUEIDENTIFIER NULL,
        -- BaseEntity
        created_at          DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at          DATETIME2        NULL,
        -- TemporalEntity
        valid_from          DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to            DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from         DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to           DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current          BIT              NOT NULL DEFAULT 1,
        is_deleted          BIT              NOT NULL DEFAULT 0,
        created_by         NVARCHAR(255),

        last_modified_by         NVARCHAR(255)    NULL,
        CONSTRAINT pk_approval_request PRIMARY KEY (id)
    );

    CREATE INDEX IX_approval_request_status       ON dbo.approval_request (status);
    CREATE INDEX IX_approval_request_requested_at ON dbo.approval_request (requested_at DESC);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__approval_request__is_current' AND object_id = OBJECT_ID('dbo.approval_request'))
    CREATE INDEX ix__approval_request__is_current  ON dbo.approval_request (is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__approval_request__is_deleted' AND object_id = OBJECT_ID('dbo.approval_request'))
    CREATE INDEX ix__approval_request__is_deleted  ON dbo.approval_request (is_deleted);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__approval_request__valid_time' AND object_id = OBJECT_ID('dbo.approval_request'))
    CREATE INDEX ix__approval_request__valid_time  ON dbo.approval_request (valid_from, valid_to);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__approval_request__system_time' AND object_id = OBJECT_ID('dbo.approval_request'))
    CREATE INDEX ix__approval_request__system_time ON dbo.approval_request (system_from, system_to);
GO

-- ====================================================================
-- Workflow Engine Tables
-- ====================================================================

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ WorkflowDefinitions (TemporalEntity) ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'workflow_definition' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.workflow_definition (
        id              UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        name            NVARCHAR(200)    NOT NULL,
        description     NVARCHAR(1000)   NULL,
        trigger_type    NVARCHAR(50)     NOT NULL,
        is_enabled      BIT              NOT NULL DEFAULT 1,
        condition_json  NVARCHAR(MAX)    NULL,
        -- BaseEntity
        created_at      DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at      DATETIME2        NULL,
        -- TemporalEntity
        valid_from      DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to        DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from     DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to       DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current      BIT              NOT NULL DEFAULT 1,
        is_deleted      BIT              NOT NULL DEFAULT 0,
        created_by     NVARCHAR(255),

        last_modified_by     NVARCHAR(255)    NULL,
        CONSTRAINT pk_workflow_definition PRIMARY KEY (id)
    );

    CREATE INDEX IX_workflow_definition_trigger_type ON dbo.workflow_definition (trigger_type);
    CREATE INDEX IX_workflow_definition_is_enabled   ON dbo.workflow_definition (is_enabled);
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_definition__is_current' AND object_id = OBJECT_ID('dbo.workflow_definition'))
    CREATE INDEX ix__workflow_definition__is_current  ON dbo.workflow_definition (is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_definition__is_deleted' AND object_id = OBJECT_ID('dbo.workflow_definition'))
    CREATE INDEX ix__workflow_definition__is_deleted  ON dbo.workflow_definition (is_deleted);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_definition__valid_time' AND object_id = OBJECT_ID('dbo.workflow_definition'))
    CREATE INDEX ix__workflow_definition__valid_time  ON dbo.workflow_definition (valid_from, valid_to);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_definition__system_time' AND object_id = OBJECT_ID('dbo.workflow_definition'))
    CREATE INDEX ix__workflow_definition__system_time ON dbo.workflow_definition (system_from, system_to);
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ WorkflowDefinitionSteps (BaseEntity) ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'workflow_definition_step' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.workflow_definition_step (
        id                      UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        definition_id           UNIQUEIDENTIFIER NOT NULL,
        step_order              INT              NOT NULL,
        name                    NVARCHAR(200)    NOT NULL,
        description             NVARCHAR(500)    NULL,
        step_type               NVARCHAR(50)     NOT NULL,
        required_role           NVARCHAR(100)    NULL,
        required_approvals      INT              NOT NULL DEFAULT 1,
        timeout_hours           INT              NOT NULL DEFAULT 48,
        timeout_action          NVARCHAR(50)     NOT NULL DEFAULT 'Expire',
        escalate_to_role        NVARCHAR(100)    NULL,
        on_approved_goto_step   INT              NULL,
        on_rejected_goto_step   INT              NULL,
        on_timeout_goto_step    INT              NULL,
        action_config_json      NVARCHAR(MAX)    NULL,
        -- BaseEntity
        created_at              DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at        DATETIME2        NULL,
        created_by              NVARCHAR(255)    NULL,
        last_modified_by        NVARCHAR(255)    NULL,
        CONSTRAINT pk_workflow_definition_step PRIMARY KEY (id),
        CONSTRAINT fk_workflow_definition_step_definition FOREIGN KEY (definition_id) REFERENCES dbo.workflow_definition (id)
    );

    CREATE INDEX IX_workflow_definition_step_definition_id    ON dbo.workflow_definition_step (definition_id);
    CREATE INDEX IX_workflow_definition_step_definition_order ON dbo.workflow_definition_step (definition_id, step_order);
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ WorkflowInstances (TemporalEntity) ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'workflow_instance' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.workflow_instance (
        id                  UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        definition_id       UNIQUEIDENTIFIER NULL,
        trigger_type        NVARCHAR(50)     NOT NULL,
        entity_type         NVARCHAR(100)    NOT NULL,
        entity_id           UNIQUEIDENTIFIER NOT NULL,
        status              NVARCHAR(50)     NOT NULL DEFAULT 'Pending',
        current_step_order  INT              NOT NULL DEFAULT 1,
        triggered_by        NVARCHAR(255)    NOT NULL,
        triggered_at        DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        completed_at        DATETIME2        NULL,
        payload_json        NVARCHAR(MAX)    NULL,
        -- BaseEntity
        created_at          DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at          DATETIME2        NULL,
        -- TemporalEntity
        valid_from          DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to            DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from         DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to           DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current          BIT              NOT NULL DEFAULT 1,
        is_deleted          BIT              NOT NULL DEFAULT 0,
        created_by         NVARCHAR(255),

        last_modified_by         NVARCHAR(255)    NULL,
        CONSTRAINT pk_workflow_instance PRIMARY KEY (id)
    );

    CREATE INDEX IX_workflow_instance_status         ON dbo.workflow_instance (status);
    CREATE INDEX IX_workflow_instance_entity_id      ON dbo.workflow_instance (entity_id);
    CREATE INDEX IX_workflow_instance_trigger_entity ON dbo.workflow_instance (trigger_type, entity_id);
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_instance__is_current' AND object_id = OBJECT_ID('dbo.workflow_instance'))
    CREATE INDEX ix__workflow_instance__is_current  ON dbo.workflow_instance (is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_instance__is_deleted' AND object_id = OBJECT_ID('dbo.workflow_instance'))
    CREATE INDEX ix__workflow_instance__is_deleted  ON dbo.workflow_instance (is_deleted);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_instance__valid_time' AND object_id = OBJECT_ID('dbo.workflow_instance'))
    CREATE INDEX ix__workflow_instance__valid_time  ON dbo.workflow_instance (valid_from, valid_to);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_instance__system_time' AND object_id = OBJECT_ID('dbo.workflow_instance'))
    CREATE INDEX ix__workflow_instance__system_time ON dbo.workflow_instance (system_from, system_to);
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ WorkflowStepInstances (TemporalEntity) ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'workflow_step_instance' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.workflow_step_instance (
        id                  UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        instance_id         UNIQUEIDENTIFIER NOT NULL,
        step_order          INT              NOT NULL,
        step_type           NVARCHAR(50)     NOT NULL,
        required_role       NVARCHAR(100)    NULL,
        required_approvals  INT              NOT NULL DEFAULT 1,
        received_approvals  INT              NOT NULL DEFAULT 0,
        status              NVARCHAR(50)     NOT NULL DEFAULT 'Waiting',
        timeout_at          DATETIME2        NULL,
        reviewed_by         NVARCHAR(255)    NULL,
        reviewed_at         DATETIME2        NULL,
        notes               NVARCHAR(MAX)    NULL,
        -- BaseEntity
        created_at          DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at          DATETIME2        NULL,
        -- TemporalEntity
        valid_from          DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to            DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from         DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to           DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current          BIT              NOT NULL DEFAULT 1,
        is_deleted          BIT              NOT NULL DEFAULT 0,
        created_by         NVARCHAR(255),

        last_modified_by         NVARCHAR(255)    NULL,
        CONSTRAINT pk_workflow_step_instance PRIMARY KEY (id),
        CONSTRAINT fk_workflow_step_instance_instance FOREIGN KEY (instance_id) REFERENCES dbo.workflow_instance (id)
    );

    CREATE INDEX IX_workflow_step_instance_instance_id ON dbo.workflow_step_instance (instance_id);
    CREATE INDEX IX_workflow_step_instance_status      ON dbo.workflow_step_instance (status);
    CREATE INDEX IX_workflow_step_instance_role_status ON dbo.workflow_step_instance (required_role, status);
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_step_instance__is_current' AND object_id = OBJECT_ID('dbo.workflow_step_instance'))
    CREATE INDEX ix__workflow_step_instance__is_current  ON dbo.workflow_step_instance (is_current);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_step_instance__is_deleted' AND object_id = OBJECT_ID('dbo.workflow_step_instance'))
    CREATE INDEX ix__workflow_step_instance__is_deleted  ON dbo.workflow_step_instance (is_deleted);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_step_instance__valid_time' AND object_id = OBJECT_ID('dbo.workflow_step_instance'))
    CREATE INDEX ix__workflow_step_instance__valid_time  ON dbo.workflow_step_instance (valid_from, valid_to);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_step_instance__system_time' AND object_id = OBJECT_ID('dbo.workflow_step_instance'))
    CREATE INDEX ix__workflow_step_instance__system_time ON dbo.workflow_step_instance (system_from, system_to);
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ WorkflowStepApprovals (BaseEntity ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â append-only audit log) ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'workflow_step_approval' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.workflow_step_approval (
        id                  UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        instance_id         UNIQUEIDENTIFIER NOT NULL,
        step_instance_id    UNIQUEIDENTIFIER NULL,
        from_step_order     INT              NOT NULL,
        target_step_order   INT              NULL,
        decision            NVARCHAR(50)     NOT NULL,
        decision_by         NVARCHAR(255)    NOT NULL,
        decision_at         DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        notes               NVARCHAR(MAX)    NULL,
        -- BaseEntity
        created_at          DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at          DATETIME2        NULL,
        CONSTRAINT pk_workflow_step_approval PRIMARY KEY (id),
        CONSTRAINT fk_workflow_step_approval_instance FOREIGN KEY (instance_id) REFERENCES dbo.workflow_instance (id)
    );

    CREATE INDEX IX_workflow_step_approval_instance_id ON dbo.workflow_step_approval (instance_id);
    CREATE INDEX IX_workflow_step_approval_decision_at ON dbo.workflow_step_approval (decision_at DESC);
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Clients ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'client' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.client (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
        name             NVARCHAR(255)    NOT NULL,
        code             NVARCHAR(50)     NOT NULL,
        is_active        BIT              NOT NULL DEFAULT 1,
        created_at       DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at DATETIME2        NULL,
        valid_from       DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to         DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from      DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to        DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current       BIT              NOT NULL DEFAULT 1,
        is_deleted       BIT              NOT NULL DEFAULT 0,
        created_by       NVARCHAR(255)    NULL,
        last_modified_by NVARCHAR(255)    NULL,
        CONSTRAINT pk_client PRIMARY KEY (id)
    );
    CREATE UNIQUE INDEX ux_client_code_current ON dbo.client (code) WHERE is_current = 1 AND is_deleted = 0;
    CREATE INDEX ix_client_is_current  ON dbo.client (is_current);
    CREATE INDEX ix_client_is_deleted  ON dbo.client (is_deleted);
    CREATE INDEX ix_client_valid_time  ON dbo.client (valid_from, valid_to);
    CREATE INDEX ix_client_system_time ON dbo.client (system_from, system_to);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'client_contact' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.client_contact (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
        client_id        UNIQUEIDENTIFIER NOT NULL,
        contact_name     NVARCHAR(255)    NOT NULL,
        role             NVARCHAR(100)    NULL,
        email            NVARCHAR(255)    NULL,
        phone            NVARCHAR(100)    NULL,
        is_primary       BIT              NOT NULL DEFAULT 0,
        is_active        BIT              NOT NULL DEFAULT 1,
        created_at       DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at DATETIME2        NULL,
        valid_from       DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to         DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from      DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to        DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current       BIT              NOT NULL DEFAULT 1,
        is_deleted       BIT              NOT NULL DEFAULT 0,
        created_by       NVARCHAR(255)    NULL,
        last_modified_by NVARCHAR(255)    NULL,
        CONSTRAINT pk_client_contact    PRIMARY KEY (id),
        CONSTRAINT fk_client_contact_client FOREIGN KEY (client_id) REFERENCES dbo.client(id) ON DELETE CASCADE
    );
    CREATE INDEX ix_client_contact_client_id  ON dbo.client_contact (client_id);
    CREATE INDEX ix_client_contact_is_current ON dbo.client_contact (is_current);
    CREATE INDEX ix_client_contact_is_deleted ON dbo.client_contact (is_deleted);
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Portfolios ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'portfolio' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.portfolio (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
        client_id        UNIQUEIDENTIFIER NOT NULL,
        name             NVARCHAR(255)    NOT NULL,
        code             NVARCHAR(50)     NOT NULL,
        currency         NVARCHAR(10)     NOT NULL DEFAULT 'USD',
        is_active        BIT              NOT NULL DEFAULT 1,
        created_at       DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at DATETIME2        NULL,
        valid_from       DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to         DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from      DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to        DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current       BIT              NOT NULL DEFAULT 1,
        is_deleted       BIT              NOT NULL DEFAULT 0,
        created_by       NVARCHAR(255)    NULL,
        last_modified_by NVARCHAR(255)    NULL,
        CONSTRAINT pk_portfolio         PRIMARY KEY (id),
        CONSTRAINT fk_portfolio_client  FOREIGN KEY (client_id) REFERENCES dbo.client(id)
    );
    CREATE UNIQUE INDEX ux_portfolio_code_current ON dbo.portfolio (code) WHERE is_current = 1 AND is_deleted = 0;
    CREATE INDEX ix_portfolio_client_id  ON dbo.portfolio (client_id);
    CREATE INDEX ix_portfolio_is_current ON dbo.portfolio (is_current);
    CREATE INDEX ix_portfolio_is_deleted ON dbo.portfolio (is_deleted);
    CREATE INDEX ix_portfolio_valid_time  ON dbo.portfolio (valid_from, valid_to);
    CREATE INDEX ix_portfolio_system_time ON dbo.portfolio (system_from, system_to);
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Positions ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'position' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.position (
        id            UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID() PRIMARY KEY,
        portfolio_id  UNIQUEIDENTIFIER NOT NULL,
        security_id   UNIQUEIDENTIFIER NOT NULL,
        quantity      DECIMAL(28,8)    NOT NULL,
        as_of_date    DATE             NOT NULL,
        market_value  DECIMAL(28,8)    NULL,
        book_value    DECIMAL(28,8)    NULL,
        currency_code CHAR(3)          NOT NULL,
        source_system NVARCHAR(50)     NOT NULL,
        -- BaseEntity
        created_at    DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at    DATETIME2        NULL,
        -- TemporalEntity
        valid_from    DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to      DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from   DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to     DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current    BIT              NOT NULL DEFAULT 1,
        is_deleted    BIT              NOT NULL DEFAULT 0,
        created_by   NVARCHAR(255),

        last_modified_by   NVARCHAR(255),
        CONSTRAINT fk_position_portfolio FOREIGN KEY (portfolio_id) REFERENCES dbo.portfolio(id),
        CONSTRAINT fk_position_security  FOREIGN KEY (security_id)  REFERENCES dbo.security(id)
    );
    CREATE INDEX ix_position_portfolio_id                ON dbo.position (portfolio_id);
    CREATE INDEX ix_position_security_id                 ON dbo.position (security_id);
    CREATE INDEX ix_position_portfolio_security_asofdate ON dbo.position (portfolio_id, security_id, as_of_date);
    CREATE INDEX ix_position_is_current                  ON dbo.position (is_current);
    CREATE INDEX ix_position_valid_from_to               ON dbo.position (valid_from, valid_to);
    CREATE INDEX ix_position_system_from_to              ON dbo.position (system_from, system_to);
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Field Visibility ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
-- field_visibility_entity: catalog of entities whose fields can be governed
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'field_visibility_entity' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.field_visibility_entity (
        id            UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        entity_type   NVARCHAR(200)    NOT NULL,
        display_name  NVARCHAR(200)    NOT NULL,
        description   NVARCHAR(1000)   NULL,
        is_active     BIT              NOT NULL CONSTRAINT df_fve_is_active     DEFAULT 1,
        -- BaseEntity
        created_at    DATETIME2        NOT NULL CONSTRAINT df_fve_created_at    DEFAULT GETUTCDATE(),
        last_modified_at    DATETIME2        NULL,
        -- TemporalEntity
        valid_from    DATETIME2        NOT NULL CONSTRAINT df_fve_valid_from    DEFAULT GETUTCDATE(),
        valid_to      DATETIME2        NOT NULL CONSTRAINT df_fve_valid_to      DEFAULT '9999-12-31',
        system_from   DATETIME2        NOT NULL CONSTRAINT df_fve_system_from   DEFAULT GETUTCDATE(),
        system_to     DATETIME2        NOT NULL CONSTRAINT df_fve_system_to     DEFAULT '9999-12-31',
        is_current    BIT              NOT NULL CONSTRAINT df_fve_is_current    DEFAULT 1,
        is_deleted    BIT              NOT NULL CONSTRAINT df_fve_is_deleted    DEFAULT 0,
        created_by   NVARCHAR(255),

        last_modified_by   NVARCHAR(255)    NULL,
        CONSTRAINT pk_field_visibility_entity PRIMARY KEY (id),
        CONSTRAINT uq_field_visibility_entity_entity_type UNIQUE (entity_type)
    );
    CREATE INDEX ix_field_visibility_entity_is_active  ON dbo.field_visibility_entity (is_active);
    CREATE INDEX ix_field_visibility_entity_is_current ON dbo.field_visibility_entity (is_current);
END
GO

-- field_visibility_field: individual fields within a field_visibility_entity
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'field_visibility_field' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.field_visibility_field (
        id                         UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        field_visibility_entity_id UNIQUEIDENTIFIER NOT NULL,
        field_name                 NVARCHAR(200)    NOT NULL,
        display_name               NVARCHAR(200)    NOT NULL,
        data_type                  NVARCHAR(100)    NULL,
        sensitivity_level          NVARCHAR(100)    NULL,
        default_visibility_state   NVARCHAR(20)     NOT NULL CONSTRAINT df_fvf_default_visibility_state  DEFAULT 'VISIBLE',
        default_obfuscation_type   NVARCHAR(30)     NOT NULL CONSTRAINT df_fvf_default_obfuscation_type DEFAULT 'NONE',
        sort_order                 INT              NOT NULL CONSTRAINT df_fvf_sort_order                DEFAULT 0,
        is_active                  BIT              NOT NULL CONSTRAINT df_fvf_is_active                 DEFAULT 1,
        -- BaseEntity
        created_at                 DATETIME2        NOT NULL CONSTRAINT df_fvf_created_at                DEFAULT GETUTCDATE(),
        last_modified_at                 DATETIME2        NULL,
        -- TemporalEntity
        valid_from                 DATETIME2        NOT NULL CONSTRAINT df_fvf_valid_from                DEFAULT GETUTCDATE(),
        valid_to                   DATETIME2        NOT NULL CONSTRAINT df_fvf_valid_to                  DEFAULT '9999-12-31',
        system_from                DATETIME2        NOT NULL CONSTRAINT df_fvf_system_from               DEFAULT GETUTCDATE(),
        system_to                  DATETIME2        NOT NULL CONSTRAINT df_fvf_system_to                 DEFAULT '9999-12-31',
        is_current                 BIT              NOT NULL CONSTRAINT df_fvf_is_current                DEFAULT 1,
        is_deleted                 BIT              NOT NULL CONSTRAINT df_fvf_is_deleted                DEFAULT 0,
        created_by                NVARCHAR(255),

        last_modified_by                NVARCHAR(255)    NULL,
        CONSTRAINT pk_field_visibility_field PRIMARY KEY (id),
        CONSTRAINT uq_field_visibility_field_entity_field
            UNIQUE (field_visibility_entity_id, field_name),
        CONSTRAINT fk_field_visibility_field_entity
            FOREIGN KEY (field_visibility_entity_id)
            REFERENCES dbo.field_visibility_entity (id) ON DELETE CASCADE,
        CONSTRAINT ck_fvf_default_visibility_state
            CHECK (default_visibility_state IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED')),
        CONSTRAINT ck_fvf_default_obfuscation_type
            CHECK (default_obfuscation_type IN ('NONE','TEXT','EMAIL','NAME','DATE','NUMBER','CUSTOM'))
    );
    CREATE INDEX ix_field_visibility_field_entity_id  ON dbo.field_visibility_field (field_visibility_entity_id);
    CREATE INDEX ix_field_visibility_field_is_active  ON dbo.field_visibility_field (is_active);
    CREATE INDEX ix_field_visibility_field_is_current ON dbo.field_visibility_field (is_current);
END
GO

-- field_visibility_rule: per-permission rule for a specific field
-- permission_definition_id is the required FK (required_permission free-text column removed in QW3/20260426).
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'field_visibility_rule' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.field_visibility_rule (
        id                          UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        field_visibility_field_id   UNIQUEIDENTIFIER NOT NULL,
        permission_definition_id    UNIQUEIDENTIFIER NOT NULL,  -- FK ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ permission_definition; added as deferred FK below
        visibility_state            NVARCHAR(20)     NOT NULL,
        obfuscation_type            NVARCHAR(30)     NOT NULL CONSTRAINT df_fvr_obfuscation_type DEFAULT 'NONE',
        priority                    INT              NOT NULL CONSTRAINT df_fvr_priority          DEFAULT 10,
        is_active                   BIT              NOT NULL CONSTRAINT df_fvr_is_active         DEFAULT 1,
        effective_from              DATETIME2        NULL,
        effective_to                DATETIME2        NULL,
        created_by                  NVARCHAR(150)    NOT NULL,
        updated_by                  NVARCHAR(150)    NULL,
        -- BaseEntity
        created_at                  DATETIME2        NOT NULL CONSTRAINT df_fvr_created_at        DEFAULT GETUTCDATE(),
        last_modified_at                  DATETIME2        NULL,
        -- TemporalEntity
        valid_from                  DATETIME2        NOT NULL CONSTRAINT df_fvr_valid_from        DEFAULT GETUTCDATE(),
        valid_to                    DATETIME2        NOT NULL CONSTRAINT df_fvr_valid_to          DEFAULT '9999-12-31',
        system_from                 DATETIME2        NOT NULL CONSTRAINT df_fvr_system_from       DEFAULT GETUTCDATE(),
        system_to                   DATETIME2        NOT NULL CONSTRAINT df_fvr_system_to         DEFAULT '9999-12-31',
        is_current                  BIT              NOT NULL CONSTRAINT df_fvr_is_current        DEFAULT 1,
        is_deleted                  BIT              NOT NULL CONSTRAINT df_fvr_is_deleted        DEFAULT 0,
        created_by                 NVARCHAR(255),

        last_modified_by                 NVARCHAR(255)    NULL,
        CONSTRAINT pk_field_visibility_rule PRIMARY KEY (id),
        CONSTRAINT fk_field_visibility_rule_field
            FOREIGN KEY (field_visibility_field_id)
            REFERENCES dbo.field_visibility_field (id) ON DELETE CASCADE,
        CONSTRAINT ck_fvr_visibility_state
            CHECK (visibility_state IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED')),
        CONSTRAINT ck_fvr_obfuscation_type
            CHECK (obfuscation_type IN ('NONE','TEXT','EMAIL','NAME','DATE','NUMBER','CUSTOM'))
    );
    CREATE UNIQUE INDEX uq_field_visibility_rule_field_permission
        ON dbo.field_visibility_rule (field_visibility_field_id, permission_definition_id)
        WHERE is_current = 1 AND is_deleted = 0;
    CREATE INDEX ix_field_visibility_rule_field_id       ON dbo.field_visibility_rule (field_visibility_field_id);
    CREATE INDEX ix_field_visibility_rule_permission_def ON dbo.field_visibility_rule (permission_definition_id);
    CREATE INDEX ix_field_visibility_rule_is_current     ON dbo.field_visibility_rule (is_current);
    CREATE INDEX ix_field_visibility_rule_is_deleted     ON dbo.field_visibility_rule (is_deleted);
    CREATE INDEX ix_field_visibility_rule_valid_time     ON dbo.field_visibility_rule (valid_from, valid_to);
END
GO

-- field_group: named grouping of fields within a field_visibility_entity
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'field_group' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.field_group (
        id                          UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID()
                                        CONSTRAINT pk_field_group PRIMARY KEY,
        field_visibility_entity_id  UNIQUEIDENTIFIER NOT NULL,
        group_key                   NVARCHAR(100)    NOT NULL,
        display_name                NVARCHAR(200)    NOT NULL,
        description                 NVARCHAR(MAX)    NULL,
        sort_order                  INT              NOT NULL DEFAULT 0,
        is_active                   BIT              NOT NULL DEFAULT 1,
        -- BaseEntity
        created_by                  NVARCHAR(200)    NULL,
        created_at                  DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        updated_by                  NVARCHAR(200)    NULL,
        last_modified_at                  DATETIME2        NULL,
        -- TemporalEntity
        valid_from                  DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        valid_to                    DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from                 DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        system_to                   DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current                  BIT              NOT NULL DEFAULT 1,
        is_deleted                  BIT              NOT NULL DEFAULT 0,
        last_modified_by                 NVARCHAR(200)    NULL,
        CONSTRAINT fk_field_group_entity FOREIGN KEY (field_visibility_entity_id)
            REFERENCES dbo.field_visibility_entity (id)
    );
    CREATE UNIQUE INDEX uq_field_group_key ON dbo.field_group (group_key)
        WHERE is_current = 1 AND is_deleted = 0;
    CREATE INDEX ix_field_group_entity_id  ON dbo.field_group (field_visibility_entity_id);
    CREATE INDEX ix_field_group_is_current ON dbo.field_group (is_current);
END
GO

-- field_group_member: association of a field_visibility_field to a field_group
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'field_group_member' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.field_group_member (
        id                          UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID()
                                        CONSTRAINT pk_field_group_member PRIMARY KEY,
        field_group_id              UNIQUEIDENTIFIER NOT NULL,
        field_visibility_field_id   UNIQUEIDENTIFIER NOT NULL,
        -- BaseEntity
        created_by                  NVARCHAR(200)    NULL,
        created_at                  DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        updated_by                  NVARCHAR(200)    NULL,
        last_modified_at                  DATETIME2        NULL,
        -- TemporalEntity
        valid_from                  DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        valid_to                    DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from                 DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        system_to                   DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current                  BIT              NOT NULL DEFAULT 1,
        is_deleted                  BIT              NOT NULL DEFAULT 0,
        last_modified_by                 NVARCHAR(200)    NULL,
        CONSTRAINT fk_field_group_member_group FOREIGN KEY (field_group_id)
            REFERENCES dbo.field_group (id),
        CONSTRAINT fk_field_group_member_field FOREIGN KEY (field_visibility_field_id)
            REFERENCES dbo.field_visibility_field (id)
    );
    CREATE UNIQUE INDEX uq_field_group_member ON dbo.field_group_member (field_group_id, field_visibility_field_id)
        WHERE is_current = 1 AND is_deleted = 0;
    CREATE INDEX ix_field_group_member_group_id ON dbo.field_group_member (field_group_id);
    CREATE INDEX ix_field_group_member_field_id ON dbo.field_group_member (field_visibility_field_id);
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ App Resource Authorization ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬

-- app_resource: individual navigable/actionable resources (menus, routes, actions, tabs, sections)
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'app_resource' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.app_resource (
        id                       UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        resource_type            NVARCHAR(30)     NOT NULL,  -- MENU_GROUP|MENU_ITEM|ROUTE|ACTION|TAB|SECTION
        resource_key             NVARCHAR(300)    NOT NULL,
        parent_app_resource_id   UNIQUEIDENTIFIER NULL,
        display_name             NVARCHAR(200)    NOT NULL,
        route_path               NVARCHAR(300)    NULL,
        icon_name                NVARCHAR(100)    NULL,
        description              NVARCHAR(1000)   NULL,
        default_visibility_state NVARCHAR(20)     NOT NULL CONSTRAINT df_ar_default_visibility DEFAULT 'VISIBLE',
        default_execution_state  NVARCHAR(20)     NOT NULL CONSTRAINT df_ar_default_execution  DEFAULT 'ALLOW',
        is_security_sensitive    BIT              NOT NULL CONSTRAINT df_ar_is_security_sensitive DEFAULT 0,
        sort_order               INT              NOT NULL CONSTRAINT df_ar_sort_order            DEFAULT 0,
        is_active                BIT              NOT NULL CONSTRAINT df_ar_is_active              DEFAULT 1,
        -- BaseEntity
        created_at               DATETIME2        NOT NULL CONSTRAINT df_ar_created_at             DEFAULT GETUTCDATE(),
        last_modified_at               DATETIME2        NULL,
        -- TemporalEntity
        valid_from               DATETIME2        NOT NULL CONSTRAINT df_ar_valid_from             DEFAULT GETUTCDATE(),
        valid_to                 DATETIME2        NOT NULL CONSTRAINT df_ar_valid_to               DEFAULT '9999-12-31',
        system_from              DATETIME2        NOT NULL CONSTRAINT df_ar_system_from            DEFAULT GETUTCDATE(),
        system_to                DATETIME2        NOT NULL CONSTRAINT df_ar_system_to              DEFAULT '9999-12-31',
        is_current               BIT              NOT NULL CONSTRAINT df_ar_is_current             DEFAULT 1,
        is_deleted               BIT              NOT NULL CONSTRAINT df_ar_is_deleted             DEFAULT 0,
        created_by              NVARCHAR(255),

        last_modified_by              NVARCHAR(255)    NULL,
        CONSTRAINT pk_app_resource PRIMARY KEY (id),
        CONSTRAINT fk_app_resource_parent
            FOREIGN KEY (parent_app_resource_id)
            REFERENCES dbo.app_resource (id),
        CONSTRAINT ck_app_resource_type
            CHECK (resource_type IN ('MENU_GROUP','MENU_ITEM','ROUTE','ACTION','TAB','SECTION')),
        CONSTRAINT ck_app_resource_visibility_state
            CHECK (default_visibility_state IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED')),
        CONSTRAINT ck_app_resource_execution_state
            CHECK (default_execution_state IN ('ALLOW','DENY','NOT_APPLICABLE'))
    );
    CREATE INDEX ix_app_resource_parent_id  ON dbo.app_resource (parent_app_resource_id);
    CREATE INDEX ix_app_resource_is_active  ON dbo.app_resource (is_active);
    CREATE INDEX ix_app_resource_is_current ON dbo.app_resource (is_current);
    CREATE UNIQUE INDEX uq_app_resource_resource_key ON dbo.app_resource (resource_key) WHERE is_current = 1;
END
GO

-- entity_screen: maps a named screen / view to an app_resource for permission-gating
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'entity_screen' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.entity_screen (
        id              UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID()
                            CONSTRAINT pk_entity_screen PRIMARY KEY,
        screen_key      NVARCHAR(200)    NOT NULL,
        display_name    NVARCHAR(200)    NOT NULL,
        entity_type     NVARCHAR(200)    NULL,
        app_resource_id UNIQUEIDENTIFIER NULL,
        description     NVARCHAR(MAX)    NULL,
        sort_order      INT              NOT NULL DEFAULT 0,
        is_active       BIT              NOT NULL DEFAULT 1,
        -- BaseEntity
        created_by      NVARCHAR(200)    NULL,
        created_at      DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        updated_by      NVARCHAR(200)    NULL,
        last_modified_at      DATETIME2        NULL,
        -- TemporalEntity
        valid_from      DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        valid_to        DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from     DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        system_to       DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current      BIT              NOT NULL DEFAULT 1,
        is_deleted      BIT              NOT NULL DEFAULT 0,
        last_modified_by     NVARCHAR(200)    NULL,
        CONSTRAINT fk_entity_screen_app_resource FOREIGN KEY (app_resource_id)
            REFERENCES dbo.app_resource (id)
    );
    CREATE UNIQUE INDEX uq_entity_screen_key ON dbo.entity_screen (screen_key)
        WHERE is_current = 1 AND is_deleted = 0;
    CREATE INDEX ix_entity_screen_app_resource_id ON dbo.entity_screen (app_resource_id);
    CREATE INDEX ix_entity_screen_is_current      ON dbo.entity_screen (is_current);
END
GO

-- permission_bundle
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'permission_bundle' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.permission_bundle (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID()
                             CONSTRAINT pk_permission_bundle PRIMARY KEY,
        bundle_key       NVARCHAR(200)    NOT NULL,
        display_name     NVARCHAR(200)    NOT NULL,
        description      NVARCHAR(1000)   NULL,
        is_active        BIT              NOT NULL DEFAULT 1,
        created_at       DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        last_modified_at DATETIME2        NULL,
        created_by       NVARCHAR(255)    NULL,
        last_modified_by NVARCHAR(255)    NULL,
        valid_from       DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        valid_to         DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from      DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        system_to        DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current       BIT              NOT NULL DEFAULT 1,
        is_deleted       BIT              NOT NULL DEFAULT 0
    );
    CREATE UNIQUE INDEX uq_permission_bundle_key ON dbo.permission_bundle (bundle_key)
        WHERE is_current = 1 AND is_deleted = 0;
    CREATE INDEX ix_permission_bundle_is_current ON dbo.permission_bundle (is_current);
END
GO

-- permission_bundle_member
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'permission_bundle_member' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.permission_bundle_member (
        id                       UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID()
                                     CONSTRAINT pk_permission_bundle_member PRIMARY KEY,
        permission_bundle_id     UNIQUEIDENTIFIER NOT NULL,
        permission_definition_id UNIQUEIDENTIFIER NOT NULL,
        created_at               DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        last_modified_at         DATETIME2        NULL,
        created_by               NVARCHAR(255)    NULL,
        last_modified_by         NVARCHAR(255)    NULL,
        CONSTRAINT uq_permission_bundle_member
            UNIQUE (permission_bundle_id, permission_definition_id),
        CONSTRAINT fk_pbm_bundle
            FOREIGN KEY (permission_bundle_id) REFERENCES dbo.permission_bundle (id) ON DELETE CASCADE,
        CONSTRAINT fk_pbm_definition
            FOREIGN KEY (permission_definition_id) REFERENCES dbo.permission_definition (id)
    );
    CREATE INDEX ix_pbm_bundle_id ON dbo.permission_bundle_member (permission_bundle_id);
END
GO

-- policy_template
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'policy_template' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.policy_template (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID()
                             CONSTRAINT pk_policy_template PRIMARY KEY,
        template_key     NVARCHAR(200)    NOT NULL,
        template_name    NVARCHAR(200)    NOT NULL,
        target_type      NVARCHAR(100)    NOT NULL,
        description      NVARCHAR(1000)   NULL,
        template_json    NVARCHAR(MAX)    NOT NULL DEFAULT '{}',
        is_active        BIT              NOT NULL DEFAULT 1,
        created_at       DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        last_modified_at DATETIME2        NULL,
        created_by       NVARCHAR(255)    NULL,
        last_modified_by NVARCHAR(255)    NULL,
        valid_from       DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        valid_to         DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from      DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        system_to        DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current       BIT              NOT NULL DEFAULT 1,
        is_deleted       BIT              NOT NULL DEFAULT 0
    );
    CREATE UNIQUE INDEX uq_policy_template_key ON dbo.policy_template (template_key)
        WHERE is_current = 1 AND is_deleted = 0;
    CREATE INDEX ix_policy_template_is_current ON dbo.policy_template (is_current);
END
GO

-- app_resource_rule: per-permission access rule for an app_resource
-- permission_definition_id is the required FK (required_permission free-text column removed in QW3/20260426).
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'app_resource_rule' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.app_resource_rule (
        id                       UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        app_resource_id          UNIQUEIDENTIFIER NOT NULL,
        permission_definition_id UNIQUEIDENTIFIER NOT NULL,  -- FK ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ permission_definition; added as deferred FK below
        visibility_state         NVARCHAR(20)     NOT NULL,
        execution_state          NVARCHAR(20)     NOT NULL,
        priority                 INT              NOT NULL CONSTRAINT df_arr_priority       DEFAULT 100,
        is_active                BIT              NOT NULL CONSTRAINT df_arr_is_active      DEFAULT 1,
        effective_from           DATETIME2        NULL,
        effective_to             DATETIME2        NULL,
        created_by               NVARCHAR(150)    NOT NULL,
        updated_by               NVARCHAR(150)    NULL,
        -- BaseEntity
        created_at               DATETIME2        NOT NULL CONSTRAINT df_arr_created_at     DEFAULT GETUTCDATE(),
        last_modified_at               DATETIME2        NULL,
        -- TemporalEntity
        valid_from               DATETIME2        NOT NULL CONSTRAINT df_arr_valid_from     DEFAULT GETUTCDATE(),
        valid_to                 DATETIME2        NOT NULL CONSTRAINT df_arr_valid_to       DEFAULT '9999-12-31',
        system_from              DATETIME2        NOT NULL CONSTRAINT df_arr_system_from    DEFAULT GETUTCDATE(),
        system_to                DATETIME2        NOT NULL CONSTRAINT df_arr_system_to      DEFAULT '9999-12-31',
        is_current               BIT              NOT NULL CONSTRAINT df_arr_is_current     DEFAULT 1,
        is_deleted               BIT              NOT NULL CONSTRAINT df_arr_is_deleted     DEFAULT 0,
        created_by              NVARCHAR(255),

        last_modified_by              NVARCHAR(255)    NULL,
        CONSTRAINT pk_app_resource_rule PRIMARY KEY (id),
        CONSTRAINT fk_app_resource_rule_resource
            FOREIGN KEY (app_resource_id)
            REFERENCES dbo.app_resource (id) ON DELETE CASCADE,
        CONSTRAINT ck_app_resource_rule_visibility
            CHECK (visibility_state IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED')),
        CONSTRAINT ck_app_resource_rule_execution
            CHECK (execution_state IN ('ALLOW','DENY','NOT_APPLICABLE'))
    );
    CREATE UNIQUE INDEX uq_app_resource_rule_resource_permission
        ON dbo.app_resource_rule (app_resource_id, permission_definition_id)
        WHERE is_current = 1 AND is_deleted = 0;
    CREATE INDEX ix_app_resource_rule_resource_id     ON dbo.app_resource_rule (app_resource_id);
    CREATE INDEX ix_app_resource_rule_permission_def  ON dbo.app_resource_rule (permission_definition_id);
    CREATE INDEX ix_app_resource_rule_is_current      ON dbo.app_resource_rule (is_current);
    CREATE INDEX ix_app_resource_rule_is_deleted      ON dbo.app_resource_rule (is_deleted);
    CREATE INDEX ix_app_resource_rule_valid_time      ON dbo.app_resource_rule (valid_from, valid_to);
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Currency (ISO 4217 + crypto) ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'currency' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.currency (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
        code             NVARCHAR(10)     NOT NULL,  -- natural key; e.g. 'USD', 'BTC'
        numeric_code     NVARCHAR(3)      NULL,       -- ISO 4217 numeric; NULL for crypto
        name             NVARCHAR(150)    NOT NULL,
        symbol           NVARCHAR(10)     NULL,
        decimals         TINYINT          NOT NULL DEFAULT 2,  -- storage precision
        display_decimals TINYINT          NOT NULL DEFAULT 2,  -- UI display places (>= decimals or 2)
        currency_type    NVARCHAR(10)     NOT NULL DEFAULT 'FIAT', -- FIAT | CRYPTO | COMMODITY | OTHER
        is_active        BIT              NOT NULL DEFAULT 1,
        -- BaseEntity
        created_at       DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at       DATETIME2        NULL,
        -- TemporalEntity
        valid_from       DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to         DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from      DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to        DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current       BIT              NOT NULL DEFAULT 1,
        is_deleted       BIT              NOT NULL DEFAULT 0,
        created_by      NVARCHAR(255),

        last_modified_by      NVARCHAR(255)    NULL,
        CONSTRAINT pk_currency PRIMARY KEY (id),
        CONSTRAINT uq_currency_code UNIQUE (code),
        CONSTRAINT chk_currency_type CHECK (currency_type IN ('FIAT','CRYPTO','COMMODITY','OTHER'))
    );

    CREATE INDEX ix_currency_currency_type ON dbo.currency (currency_type);
    CREATE INDEX ix_currency_is_active      ON dbo.currency (is_active);
    CREATE INDEX ix_currency_is_current     ON dbo.currency (is_current);
    CREATE INDEX ix_currency_is_deleted     ON dbo.currency (is_deleted);
END
GO

-- FK: security.currency_code ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ currency.code (added after currency table exists)
IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = 'fk_security_currency_code'
)
    ALTER TABLE dbo.security
        ADD CONSTRAINT fk_security_currency_code
            FOREIGN KEY (currency_code) REFERENCES dbo.currency(code);
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Country (ISO 3166-1) ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'country' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.country (
        id           UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
        alpha2       NCHAR(2)         NOT NULL,  -- natural key; e.g. 'US'
        alpha3       NCHAR(3)         NOT NULL,
        numeric_code NCHAR(3)         NOT NULL,
        name         NVARCHAR(200)    NOT NULL,
        tld          NVARCHAR(10)     NULL,
        is_active    BIT              NOT NULL DEFAULT 1,
        -- BaseEntity
        created_at   DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at   DATETIME2        NULL,
        -- TemporalEntity
        valid_from   DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to     DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from  DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to    DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current   BIT              NOT NULL DEFAULT 1,
        is_deleted   BIT              NOT NULL DEFAULT 0,
        created_by  NVARCHAR(255),

        last_modified_by  NVARCHAR(255)    NULL,
        CONSTRAINT pk_country PRIMARY KEY (id),
        CONSTRAINT uq_country_alpha2 UNIQUE (alpha2)
    );

    CREATE UNIQUE INDEX ux_country_alpha3  ON dbo.country (alpha3);
    CREATE UNIQUE INDEX ux_country_numeric ON dbo.country (numeric_code);
    CREATE INDEX ix_country_is_current     ON dbo.country (is_current);
    CREATE INDEX ix_country_is_deleted     ON dbo.country (is_deleted);
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ CountryÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Å“Currency link ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'country_currency' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.country_currency (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
        country_alpha2   NCHAR(2)         NOT NULL,  -- FK ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ country.alpha2
        currency_code    NVARCHAR(10)     NOT NULL,  -- FK ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ currency.code
        is_primary       BIT              NOT NULL DEFAULT 0,  -- primary/official currency
        is_legal_tender  BIT              NOT NULL DEFAULT 1,  -- recognised legal tender
        is_operational   BIT              NOT NULL DEFAULT 1,  -- used in day-to-day transactions
        -- BaseEntity
        created_at       DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at       DATETIME2        NULL,
        -- TemporalEntity
        valid_from       DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to         DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from      DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to        DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current       BIT              NOT NULL DEFAULT 1,
        is_deleted       BIT              NOT NULL DEFAULT 0,
        created_by      NVARCHAR(255),

        last_modified_by      NVARCHAR(255)    NULL,
        CONSTRAINT pk_country_currency PRIMARY KEY (id),
        CONSTRAINT uq_country_currency_pair UNIQUE (country_alpha2, currency_code),
        CONSTRAINT fk_country_currency_country  FOREIGN KEY (country_alpha2) REFERENCES dbo.country  (alpha2),
        CONSTRAINT fk_country_currency_currency FOREIGN KEY (currency_code)  REFERENCES dbo.currency (code)
    );

    CREATE INDEX ix_country_currency_alpha2  ON dbo.country_currency (country_alpha2);
    CREATE INDEX ix_country_currency_code    ON dbo.country_currency (currency_code);
    CREATE INDEX ix_country_currency_primary ON dbo.country_currency (country_alpha2, is_primary) WHERE is_primary = 1;
    CREATE INDEX ix_country_currency_current ON dbo.country_currency (is_current);
END
GO

-- ====================================================================
-- currency_external_code ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â one-to-many: one currency, many external codes
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'currency_external_code' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.currency_external_code (
        id            UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
        currency_code NVARCHAR(10)     NOT NULL,                -- FK ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ currency.code
        system_name   NVARCHAR(100)    NOT NULL,                -- e.g. 'Bloomberg', 'Reuters', 'ISIN'
        external_code NVARCHAR(100)    NOT NULL,                -- the code as known by that system
        -- BaseEntity
        created_at    DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at    DATETIME2(7)     NULL,
        -- TemporalEntity
        valid_from    DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        valid_to      DATETIME2(7)     NOT NULL DEFAULT '9999-12-31',
        system_from   DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        system_to     DATETIME2(7)     NOT NULL DEFAULT '9999-12-31',
        is_current    BIT              NOT NULL DEFAULT 1,
        is_deleted    BIT              NOT NULL DEFAULT 0,
        created_by   NVARCHAR(255),

        last_modified_by   NVARCHAR(255)    NULL,
        CONSTRAINT pk_currency_external_code             PRIMARY KEY (id),
        CONSTRAINT uq_currency_external_code_system      UNIQUE      (currency_code, system_name),
        CONSTRAINT fk_currency_external_code_currency    FOREIGN KEY (currency_code) REFERENCES dbo.currency (code)
    );
    CREATE INDEX ix_currency_external_code_currency_code ON dbo.currency_external_code (currency_code);
    CREATE INDEX ix_currency_external_code_system_name   ON dbo.currency_external_code (system_name);
    CREATE INDEX ix_currency_external_code_is_current    ON dbo.currency_external_code (is_current);
END
GO

-- ====================================================================
-- currency_pair ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â a tradeable base/quote pair (e.g. EUR/USD, BTC/USDT)
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'currency_pair' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.currency_pair (
        id                  UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
        base_currency_code  NVARCHAR(10)     NOT NULL,  -- FK ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ currency.code
        quote_currency_code NVARCHAR(10)     NOT NULL,  -- FK ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ currency.code
        -- BaseEntity
        created_at          DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at          DATETIME2(7)     NULL,
        -- TemporalEntity
        valid_from          DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        valid_to            DATETIME2(7)     NOT NULL DEFAULT '9999-12-31',
        system_from         DATETIME2(7)     NOT NULL DEFAULT GETUTCDATE(),
        system_to           DATETIME2(7)     NOT NULL DEFAULT '9999-12-31',
        is_current          BIT              NOT NULL DEFAULT 1,
        is_deleted          BIT              NOT NULL DEFAULT 0,
        created_by         NVARCHAR(255),

        last_modified_by         NVARCHAR(255)    NULL,
        CONSTRAINT pk_currency_pair                    PRIMARY KEY (id),
        CONSTRAINT uq_currency_pair_base_quote         UNIQUE      (base_currency_code, quote_currency_code),
        CONSTRAINT fk_currency_pair_base_currency      FOREIGN KEY (base_currency_code)  REFERENCES dbo.currency (code),
        CONSTRAINT fk_currency_pair_quote_currency     FOREIGN KEY (quote_currency_code) REFERENCES dbo.currency (code),
        CONSTRAINT chk_currency_pair_not_self          CHECK       (base_currency_code <> quote_currency_code)
    );
    CREATE INDEX ix_currency_pair_base_code    ON dbo.currency_pair (base_currency_code);
    CREATE INDEX ix_currency_pair_quote_code   ON dbo.currency_pair (quote_currency_code);
    CREATE INDEX ix_currency_pair_is_current   ON dbo.currency_pair (is_current);
END
GO

-- ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ Permission Catalog & Policy Tables ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬ÃƒÂ¢Ã¢â‚¬ÂÃ¢â€šÂ¬

-- permission_definition: master catalog of every assignable permission key
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'permission_definition' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.permission_definition (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        permission_key   NVARCHAR(200)    NOT NULL,
        display_name     NVARCHAR(200)    NOT NULL,
        permission_group NVARCHAR(100)    NOT NULL,
        description      NVARCHAR(1000)   NULL,
        is_assignable    BIT              NOT NULL CONSTRAINT df_pd_is_assignable DEFAULT 1,
        is_system        BIT              NOT NULL CONSTRAINT df_pd_is_system     DEFAULT 0,
        sort_order       INT              NOT NULL CONSTRAINT df_pd_sort_order    DEFAULT 0,
        is_active        BIT              NOT NULL CONSTRAINT df_pd_is_active     DEFAULT 1,
        -- BaseEntity
        created_at       DATETIME2        NOT NULL CONSTRAINT df_pd_created_at   DEFAULT GETUTCDATE(),
        last_modified_at       DATETIME2        NULL,
        -- TemporalEntity
        valid_from       DATETIME2        NOT NULL CONSTRAINT df_pd_valid_from   DEFAULT GETUTCDATE(),
        valid_to         DATETIME2        NOT NULL CONSTRAINT df_pd_valid_to     DEFAULT '9999-12-31',
        system_from      DATETIME2        NOT NULL CONSTRAINT df_pd_system_from  DEFAULT GETUTCDATE(),
        system_to        DATETIME2        NOT NULL CONSTRAINT df_pd_system_to    DEFAULT '9999-12-31',
        is_current       BIT              NOT NULL CONSTRAINT df_pd_is_current   DEFAULT 1,
        is_deleted       BIT              NOT NULL CONSTRAINT df_pd_is_deleted   DEFAULT 0,
        created_by      NVARCHAR(255),

        last_modified_by      NVARCHAR(255)    NULL,
        CONSTRAINT pk_permission_definition PRIMARY KEY (id),
        CONSTRAINT uq_permission_definition_key UNIQUE (permission_key)
    );
    CREATE INDEX ix_permission_definition_group      ON dbo.permission_definition (permission_group);
    CREATE INDEX ix_permission_definition_is_current ON dbo.permission_definition (is_current);
    CREATE INDEX ix_permission_definition_is_deleted ON dbo.permission_definition (is_deleted);
END
GO

-- Deferred FK: issuer.country_alpha2 ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ country.alpha2 (country table is defined after issuer)
IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys WHERE name = 'fk_issuer_country' AND parent_object_id = OBJECT_ID('dbo.issuer')
)
    ALTER TABLE dbo.issuer
        ADD CONSTRAINT fk_issuer_country
            FOREIGN KEY (country_alpha2) REFERENCES dbo.country(alpha2);
GO

-- Deferred FKs: field_visibility_rule and app_resource_rule ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢ permission_definition
-- (permission_definition must exist before these constraints can be added)
IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys
    WHERE name = 'fk_fvr_permission_definition' AND parent_object_id = OBJECT_ID('dbo.field_visibility_rule')
)
    ALTER TABLE dbo.field_visibility_rule
        ADD CONSTRAINT fk_fvr_permission_definition
            FOREIGN KEY (permission_definition_id)
            REFERENCES dbo.permission_definition (id) ON DELETE NO ACTION;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys
    WHERE name = 'fk_arr_permission_definition' AND parent_object_id = OBJECT_ID('dbo.app_resource_rule')
)
    ALTER TABLE dbo.app_resource_rule
        ADD CONSTRAINT fk_arr_permission_definition
            FOREIGN KEY (permission_definition_id)
            REFERENCES dbo.permission_definition (id) ON DELETE NO ACTION;
GO

-- ====================================================================
-- Issuer migration: seed issuer records from existing security.issuer strings
-- ====================================================================

-- Step 1: create issuer records from distinct security.issuer values
INSERT INTO dbo.issuer (legal_name, display_name, created_at, valid_from, system_from, is_current, is_deleted)
SELECT DISTINCT
    LTRIM(RTRIM(s.issuer)) AS legal_name,
    LTRIM(RTRIM(s.issuer)) AS display_name,
    GETUTCDATE(), GETUTCDATE(), GETUTCDATE(), 1, 0
FROM dbo.security s
WHERE s.issuer IS NOT NULL
  AND LTRIM(RTRIM(s.issuer)) <> ''
  AND NOT EXISTS (
      SELECT 1 FROM dbo.issuer i
      WHERE i.legal_name = LTRIM(RTRIM(s.issuer))
        AND i.is_current = 1 AND i.is_deleted = 0
  );
GO

-- Step 2: backfill security.issuer_id from the newly-created issuer records
UPDATE s
SET    issuer_id = i.id
FROM   dbo.security s
INNER JOIN dbo.issuer i
    ON i.legal_name = LTRIM(RTRIM(s.issuer))
   AND i.is_current = 1 AND i.is_deleted = 0
WHERE s.issuer IS NOT NULL
  AND s.issuer_id IS NULL;
GO

-- ====================================================================
-- Vendor Source Tables (Milestone 10)
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'vendor_source' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.vendor_source (
        id                        UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        code                      NVARCHAR(50)     NOT NULL,
        display_name              NVARCHAR(100)    NOT NULL,
        global_priority           INT              NOT NULL DEFAULT 100,
        staleness_threshold_hours INT              NOT NULL DEFAULT 24,
        is_active                 BIT              NOT NULL DEFAULT 1,
        created_at  DATETIME2(3) NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at  DATETIME2(3) NULL,
        created_by NVARCHAR(255),

        last_modified_by NVARCHAR(255) NULL,
        valid_from  DATETIME2(3) NOT NULL DEFAULT GETUTCDATE(),
        valid_to    DATETIME2(3) NOT NULL DEFAULT '9999-12-31',
        system_from DATETIME2(3) NOT NULL DEFAULT GETUTCDATE(),
        system_to   DATETIME2(3) NOT NULL DEFAULT '9999-12-31',
        is_current  BIT          NOT NULL DEFAULT 1,
        is_deleted  BIT          NOT NULL DEFAULT 0,
        CONSTRAINT pk_vendor_source PRIMARY KEY (id),
        CONSTRAINT uq_vendor_source_code UNIQUE (code),
        CONSTRAINT ck_vendor_source_valid_time  CHECK (valid_from  < valid_to),
        CONSTRAINT ck_vendor_source_system_time CHECK (system_from < system_to)
    );
    CREATE INDEX ix_vendor_source_is_active  ON dbo.vendor_source (is_active);
    CREATE INDEX ix_vendor_source_is_current ON dbo.vendor_source (is_current);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'vendor_field_priority' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.vendor_field_priority (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        vendor_source_id UNIQUEIDENTIFIER NOT NULL,
        field_name       NVARCHAR(100)    NOT NULL,
        asset_class_code NVARCHAR(50)     NULL,
        priority         INT              NOT NULL DEFAULT 100,
        is_active        BIT              NOT NULL DEFAULT 1,
        created_at  DATETIME2(3) NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at  DATETIME2(3) NULL,
        created_by NVARCHAR(255),

        last_modified_by NVARCHAR(255) NULL,
        valid_from  DATETIME2(3) NOT NULL DEFAULT GETUTCDATE(),
        valid_to    DATETIME2(3) NOT NULL DEFAULT '9999-12-31',
        system_from DATETIME2(3) NOT NULL DEFAULT GETUTCDATE(),
        system_to   DATETIME2(3) NOT NULL DEFAULT '9999-12-31',
        is_current  BIT          NOT NULL DEFAULT 1,
        is_deleted  BIT          NOT NULL DEFAULT 0,
        CONSTRAINT pk_vendor_field_priority PRIMARY KEY (id),
        CONSTRAINT fk_vendor_field_priority_vendor FOREIGN KEY (vendor_source_id) REFERENCES dbo.vendor_source (id),
        CONSTRAINT uq_vendor_field_priority_key UNIQUE (vendor_source_id, field_name, asset_class_code),
        CONSTRAINT ck_vendor_field_priority_valid_time  CHECK (valid_from  < valid_to),
        CONSTRAINT ck_vendor_field_priority_system_time CHECK (system_from < system_to)
    );
    CREATE INDEX ix_vendor_field_priority_vendor_id  ON dbo.vendor_field_priority (vendor_source_id);
    CREATE INDEX ix_vendor_field_priority_field_name ON dbo.vendor_field_priority (field_name);
    CREATE INDEX ix_vendor_field_priority_is_current ON dbo.vendor_field_priority (is_current);
END
GO

-- ====================================================================
-- M11: Security Vendor Data Snapshot (append-only raw feed rows)
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'security_vendor_data' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.security_vendor_data (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        security_id      UNIQUEIDENTIFIER NOT NULL,
        vendor_source_id UNIQUEIDENTIFIER NOT NULL,
        field_name       NVARCHAR(100)    NOT NULL,
        raw_value        NVARCHAR(500)    NULL,
        feed_batch_id    NVARCHAR(200)    NULL,
        received_at      DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        created_at       DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        -- No TemporalEntity columns ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â each row is an immutable raw snapshot
        CONSTRAINT pk_security_vendor_data PRIMARY KEY (id),
        CONSTRAINT fk_svd_security      FOREIGN KEY (security_id)      REFERENCES dbo.security      (id),
        CONSTRAINT fk_svd_vendor_source FOREIGN KEY (vendor_source_id) REFERENCES dbo.vendor_source (id)
    );
    CREATE INDEX ix_svd_security_id           ON dbo.security_vendor_data (security_id);
    CREATE INDEX ix_svd_vendor_source_id      ON dbo.security_vendor_data (vendor_source_id);
    CREATE INDEX ix_svd_feed_batch_id         ON dbo.security_vendor_data (feed_batch_id) WHERE feed_batch_id IS NOT NULL;
    CREATE INDEX ix_svd_security_vendor_field ON dbo.security_vendor_data (security_id, vendor_source_id, field_name, received_at DESC);
END
GO

-- ====================================================================
-- data_lineage_event  (M14 ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Å“ golden source resolver lineage)
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'data_lineage_event' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.data_lineage_event (
        id                  UNIQUEIDENTIFIER    NOT NULL DEFAULT NEWSEQUENTIALID(),
        security_id         UNIQUEIDENTIFIER    NOT NULL,
        field_name          NVARCHAR(100)       NOT NULL,
        field_value         NVARCHAR(500)       NULL,
        source_type         NVARCHAR(30)        NOT NULL,  -- VENDOR | MANUAL_OVERRIDE | SYSTEM_DEFAULT | DERIVED
        vendor_source_id    UNIQUEIDENTIFIER    NULL,
        feed_batch_id       NVARCHAR(100)       NULL,
        resolution_rule     NVARCHAR(500)       NULL,
        runner_up_vendor_id UNIQUEIDENTIFIER    NULL,
        runner_up_value     NVARCHAR(500)       NULL,
        override_user_id    NVARCHAR(100)       NULL,
        override_reason     NVARCHAR(1000)      NULL,
        resolved_at         DATETIME2(7)        NOT NULL DEFAULT SYSUTCDATETIME(),
        created_at          DATETIME2(7)        NOT NULL DEFAULT SYSUTCDATETIME(),

        CONSTRAINT pk_data_lineage_event PRIMARY KEY (id),
        CONSTRAINT ck_dle_source_type CHECK (source_type IN ('VENDOR','MANUAL_OVERRIDE','SYSTEM_DEFAULT','DERIVED')),
        CONSTRAINT fk_dle_security      FOREIGN KEY (security_id)      REFERENCES dbo.security      (id),
        CONSTRAINT fk_dle_vendor_source FOREIGN KEY (vendor_source_id) REFERENCES dbo.vendor_source (id),
        CONSTRAINT fk_dle_runner_up     FOREIGN KEY (runner_up_vendor_id) REFERENCES dbo.vendor_source (id)
    );
    CREATE INDEX ix_dle_security_id         ON dbo.data_lineage_event (security_id);
    CREATE INDEX ix_dle_source_type         ON dbo.data_lineage_event (source_type);
    CREATE INDEX ix_dle_security_field_date ON dbo.data_lineage_event (security_id, field_name, resolved_at DESC);
END
GO

-- ====================================================================
-- M15 ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Å“ golden-source columns on price
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.price') AND name = 'is_golden')
BEGIN
    ALTER TABLE dbo.price ADD
        is_golden        BIT              NOT NULL DEFAULT 0,
        is_stale         BIT              NOT NULL DEFAULT 0,
        is_override      BIT              NOT NULL DEFAULT 0,
        override_reason  NVARCHAR(500)    NULL,
        vendor_source_id UNIQUEIDENTIFIER NULL;
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'fk_price_vendor_source')
    ALTER TABLE dbo.price
        ADD CONSTRAINT fk_price_vendor_source
            FOREIGN KEY (vendor_source_id) REFERENCES dbo.vendor_source (id);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_price_is_golden' AND object_id = OBJECT_ID('dbo.price'))
    CREATE INDEX ix_price_is_golden
        ON dbo.price (security_id, price_date DESC)
        WHERE is_golden = 1 AND is_deleted = 0;
GO

-- ====================================================================
-- user_cache  (populated automatically from JWT claims on every request)
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'user_cache' AND schema_id = SCHEMA_ID('dbo'))
CREATE TABLE dbo.user_cache (
    id           NVARCHAR(36)  NOT NULL,
    display_name NVARCHAR(255) NOT NULL,
    last_seen    DATETIME2     NOT NULL DEFAULT GETUTCDATE(),
    CONSTRAINT pk_user_cache PRIMARY KEY (id)
);
GO

-- ====================================================================
-- app_resource_group
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'app_resource_group' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.app_resource_group (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        group_key        NVARCHAR(200)    NOT NULL,
        display_name     NVARCHAR(200)    NOT NULL,
        description      NVARCHAR(1000)   NULL,
        icon_name        NVARCHAR(100)    NULL,
        sort_order       INT              NOT NULL DEFAULT 0,
        is_active        BIT              NOT NULL DEFAULT 1,
        -- BaseEntity
        created_at       DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        last_modified_at DATETIME2        NULL,
        created_by       NVARCHAR(255)    NULL,
        last_modified_by NVARCHAR(255)    NULL,
        -- TemporalEntity
        valid_from       DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        valid_to         DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from      DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        system_to        DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current       BIT              NOT NULL DEFAULT 1,
        is_deleted       BIT              NOT NULL DEFAULT 0,
        CONSTRAINT pk_app_resource_group PRIMARY KEY (id)
    );
    CREATE UNIQUE INDEX uq_app_resource_group_key ON dbo.app_resource_group (group_key) WHERE is_current = 1 AND is_deleted = 0;
    CREATE INDEX ix_arg_is_current ON dbo.app_resource_group (is_current);
END
GO

-- ====================================================================
-- Record this script
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM dbo.[__SchemaVersions] WHERE version = '1.0-schema')
BEGIN
    INSERT INTO dbo.[__SchemaVersions] (version, description, script_name)
    VALUES ('1.0-schema', 'Initial schema ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â all tables and indexes (snake_case columns)', 'CreateSchema_SqlServer.sql');
END
GO

PRINT 'SecurityApp schema created successfully.';
GO