﻿-- ====================================================================
-- SecurityApp â€” Seed Data (SQL Server)
-- Populates initial reference data required for the rating model.
-- Run AFTER CreateSchema_SqlServer.sql.
-- All inserts are idempotent (IF NOT EXISTS guards).
-- ====================================================================

-- Required for DML against tables with filtered indexes
SET QUOTED_IDENTIFIER ON;
GO

PRINT 'Seeding SecurityApp reference data (SQL Server)...';
GO

-- ====================================================================
-- Reference tables
-- ====================================================================

-- security_status_ref (Milestone 7: full lifecycle statuses)
MERGE dbo.security_status_ref AS t
USING (VALUES
    ('DRAFT',            'Created but not yet submitted'),
    ('PENDING_APPROVAL', 'Awaiting Compliance approval'),
    ('ACTIVE',           'Approved and operational'),
    ('SUSPENDED',        'Temporarily disabled; still reportable'),
    ('CALLED',           'Issuer has called the instrument'),
    ('MATURED',          'Reached maturity date'),
    ('DEFAULTED',        'Issuer has defaulted'),
    ('RESTRUCTURED',     'Terms restructured post-default'),
    ('RETIRED',          'Removed from active universe'),
    ('CANCELLED',        'Cancelled before or at issuance')
) AS s (code, description)
ON t.code = s.code
WHEN NOT MATCHED THEN INSERT (code, description) VALUES (s.code, s.description)
WHEN MATCHED THEN UPDATE SET t.description = s.description;
GO

-- security_status_transition_ref (Milestone 7: valid state transitions)
INSERT INTO dbo.security_status_transition_ref (from_code, to_code)
SELECT v.f, v.t FROM (VALUES
    ('DRAFT',            'PENDING_APPROVAL'),
    ('DRAFT',            'CANCELLED'),
    ('PENDING_APPROVAL', 'ACTIVE'),
    ('PENDING_APPROVAL', 'DRAFT'),
    ('PENDING_APPROVAL', 'CANCELLED'),
    ('ACTIVE',           'SUSPENDED'),
    ('ACTIVE',           'CALLED'),
    ('ACTIVE',           'MATURED'),
    ('ACTIVE',           'DEFAULTED'),
    ('ACTIVE',           'RETIRED'),
    ('SUSPENDED',        'ACTIVE'),
    ('SUSPENDED',        'CALLED'),
    ('SUSPENDED',        'MATURED'),
    ('SUSPENDED',        'DEFAULTED'),
    ('SUSPENDED',        'RETIRED'),
    ('DEFAULTED',        'RESTRUCTURED'),
    ('DEFAULTED',        'RETIRED'),
    ('RESTRUCTURED',     'ACTIVE'),
    ('RESTRUCTURED',     'RETIRED'),
    ('CALLED',           'RETIRED'),
    ('MATURED',          'RETIRED')
) AS v(f, t)
WHERE NOT EXISTS (
    SELECT 1 FROM dbo.security_status_transition_ref
    WHERE from_code = v.f AND to_code = v.t
);
GO

-- asset_class_ref
MERGE dbo.asset_class_ref AS t
USING (VALUES
    ('EQUITY',       'Equity',                      NULL),
    ('BOND',         'Bond / Fixed Income',          NULL),
    ('LOAN',         'Loan',                         NULL),
    ('MONEY_MARKET', 'Money Market',                 NULL),
    ('FUND',         'Fund / Collective Investment', NULL),
    ('DERIVATIVE',   'Derivative',                   NULL),
    ('SECURITIZED',  'Securitized / Structured',     NULL),
    ('FX',           'Foreign Exchange',             NULL),
    ('COMMODITY',    'Commodity',                    NULL),
    ('OTHER',        'Other / Misc',                 NULL)
) AS s (code, name, description)
ON t.code = s.code
WHEN NOT MATCHED THEN INSERT (code, name, description) VALUES (s.code, s.name, s.description);
GO

-- instrument_type_ref
MERGE dbo.instrument_type_ref AS t
USING (VALUES
    -- BOND
    ('TreasuryBond',           'BOND',        'Government treasury bond'),
    ('SovereignBond',          'BOND',        'Non-treasury sovereign issues'),
    ('AgencyBond',             'BOND',        'Supranational / agency bond'),
    ('CorporateBond',          'BOND',        'Vanilla corporate bond'),
    ('MunicipalBond',          'BOND',        'Municipal / local government bond'),
    ('SubordinatedBond',       'BOND',        'Subordinated debt'),
    ('InflationLinkedBond',    'BOND',        'Inflation-linked government or corporate bond'),
    ('PerpetualBond',          'BOND',        'Bond with no fixed maturity'),
    ('CommercialPaper',        'BOND',        'Short-term unsecured note'),
    ('CertificateOfDeposit',   'BOND',        'Certificate of deposit / time deposit'),
    ('ConvertibleBond',        'BOND',        'Bond convertible into equity'),
    -- LOAN
    ('TermLoan',               'LOAN',        'Amortising or bullet term loan'),
    ('RevolvingLoan',          'LOAN',        'Revolving credit facility'),
    ('SyndicatedLoan',         'LOAN',        'Syndicated term / revolver'),
    ('MortgageLoan',           'LOAN',        'Mortgage loan'),
    ('ConsumerLoan',           'LOAN',        'Retail / consumer loan'),
    -- SECURITIZED
    ('ABS',                    'SECURITIZED', 'Asset-backed security (non-mortgage)'),
    ('MBS',                    'SECURITIZED', 'Mortgage-backed security (generic)'),
    ('RMBS',                   'SECURITIZED', 'Residential mortgage-backed security'),
    ('CMBS',                   'SECURITIZED', 'Commercial mortgage-backed security'),
    ('CLO',                    'SECURITIZED', 'Collateralised loan obligation'),
    ('CDO',                    'SECURITIZED', 'Collateralised debt obligation'),
    ('CoveredBond',            'SECURITIZED', 'Covered bond'),
    -- DERIVATIVE
    ('Future',                 'DERIVATIVE',  'Exchange-traded future (generic)'),
    ('InterestRateFuture',     'DERIVATIVE',  'Interest rate future'),
    ('EquityFuture',           'DERIVATIVE',  'Equity or index future'),
    ('Option',                 'DERIVATIVE',  'Generic option'),
    ('EquityOption',           'DERIVATIVE',  'Option on single stock or index'),
    ('BondOption',             'DERIVATIVE',  'Option on bond or future'),
    ('FXOption',               'DERIVATIVE',  'FX option'),
    ('Swap',                   'DERIVATIVE',  'Generic swap'),
    ('InterestRateSwap',       'DERIVATIVE',  'Fixed-float interest rate swap'),
    ('BasisSwap',              'DERIVATIVE',  'Float-float basis swap'),
    ('CrossCurrencySwap',      'DERIVATIVE',  'Cross-currency swap'),
    ('CDS',                    'DERIVATIVE',  'Credit default swap'),
    ('TotalReturnSwap',        'DERIVATIVE',  'Total return swap'),
    ('FXSwap',                 'DERIVATIVE',  'FX swap / forward-forward'),
    ('Forward',                'DERIVATIVE',  'Generic forward (non-listed)'),
    -- EQUITY
    ('Equity',                 'EQUITY',      'Common stock'),
    ('PreferredEquity',        'EQUITY',      'Preferred / preference shares'),
    ('DepositaryReceipt',      'EQUITY',      'ADR / GDR'),
    ('Warrant',                'EQUITY',      'Equity warrant'),
    ('Right',                  'EQUITY',      'Subscription right'),
    -- FUND
    ('MutualFund',             'FUND',        'Open-ended fund'),
    ('ExchangeTradedFund',     'FUND',        'Exchange-traded fund (ETF)'),
    ('HedgeFund',              'FUND',        'Hedge fund share class'),
    ('PooledVehicle',          'FUND',        'Other pooled investment vehicle'),
    -- MONEY_MARKET
    ('MoneyMarketFund',        'MONEY_MARKET','Money market fund share'),
    ('TreasuryBill',           'MONEY_MARKET','T-bill / short-dated sovereign note'),
    ('Repo',                   'MONEY_MARKET','Repurchase agreement'),
    ('Deposit',                'MONEY_MARKET','Term or call deposit'),
    -- FX
    ('FXSpot',                 'FX',          'FX spot'),
    ('FXForward',              'FX',          'FX forward'),
    ('FXNDF',                  'FX',          'Non-deliverable FX forward'),
    -- COMMODITY
    ('CommoditySpot',          'COMMODITY',   'Physical commodity spot'),
    ('CommodityFuture',        'COMMODITY',   'Commodity future'),
    ('CommoditySwap',          'COMMODITY',   'Swap on commodity index or price'),
    -- OTHER
    ('Index',                  'OTHER',       'Benchmark index (non-tradable)'),
    ('CustomStructuredProduct','OTHER',       'Bank-issued structured note / product'),
    ('Other',                  'OTHER',       'Catch-all for unclassified types')
) AS s (code, asset_class_code, description)
ON t.code = s.code
WHEN NOT MATCHED THEN INSERT (code, asset_class_code, description)
    VALUES (s.code, s.asset_class_code, s.description);
GO

-- ====================================================================
-- FormulaMacros
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM dbo.formula_macro WHERE name = 'DebtScore' AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.formula_macro (id, name, expression, description, scope, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES (NEWID(), 'DebtScore',
        'Normalize(debt_to_equity, 0.0, 8.0, 1.0, 21.0)',
        'Scores debt burden: lower D/E â†’ lower (better) score',
        'Fundamental',
        GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.formula_macro WHERE name = 'CoverageScore' AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.formula_macro (id, name, expression, description, scope, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES (NEWID(), 'CoverageScore',
        'Normalize(interest_coverage_ratio, 15.0, 0.5, 1.0, 21.0)',
        'Scores interest coverage: higher coverage â†’ lower (better) score',
        'Fundamental',
        GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.formula_macro WHERE name = 'VendorQualityWeight' AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.formula_macro (id, name, expression, description, scope, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES (NEWID(), 'VendorQualityWeight',
        'quality * Normalize(price_deviation, 0.0, 0.1, 1.0, 0.1)',
        'Weights vendor price by quality score and deviation band',
        'VPM',
        GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.formula_macro WHERE name = 'SpreadConfidence' AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.formula_macro (id, name, expression, description, scope, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES (NEWID(), 'SpreadConfidence',
        'Normalize((ask - bid) / mid, 0.0, 0.10, 1.0, 0.0)',
        'Measures bid/ask spread as a confidence proxy; tighter â†’ more confident',
        'MICR',
        GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.formula_macro WHERE name = 'MacroRiskScore' AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.formula_macro (id, name, expression, description, scope, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES (NEWID(), 'MacroRiskScore',
        'Normalize(RecessionRisk(gdp_growth, unemployment_rate), -5.0, 5.0, 1.0, 21.0)',
        'Combines GDP growth and unemployment into a macro risk score',
        'Macro',
        GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

-- ====================================================================
-- RatingScaleEntries
-- ====================================================================

-- S&P
IF NOT EXISTS (SELECT 1 FROM dbo.rating_scale_entry WHERE agency = 'SP' AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.rating_scale_entry (id, agency, score, label, is_investment_grade, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES
        (NEWID(), 'SP',  1, 'AAA',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP',  2, 'AA+',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP',  3, 'AA',   1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP',  4, 'AA-',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP',  5, 'A+',   1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP',  6, 'A',    1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP',  7, 'A-',   1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP',  8, 'BBB+', 1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP',  9, 'BBB',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP', 10, 'BBB-', 1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP', 11, 'BB+',  0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP', 12, 'BB',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP', 13, 'BB-',  0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP', 14, 'B+',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP', 15, 'B',    0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP', 16, 'B-',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP', 17, 'CCC+', 0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP', 18, 'CCC',  0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP', 19, 'CCC-', 0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP', 20, 'CC',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'SP', 21, 'D',    0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

-- Moody's
IF NOT EXISTS (SELECT 1 FROM dbo.rating_scale_entry WHERE agency = 'Moodys' AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.rating_scale_entry (id, agency, score, label, is_investment_grade, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES
        (NEWID(), 'Moodys',  1, 'Aaa',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys',  2, 'Aa1',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys',  3, 'Aa2',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys',  4, 'Aa3',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys',  5, 'A1',   1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys',  6, 'A2',   1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys',  7, 'A3',   1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys',  8, 'Baa1', 1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys',  9, 'Baa2', 1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys', 10, 'Baa3', 1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys', 11, 'Ba1',  0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys', 12, 'Ba2',  0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys', 13, 'Ba3',  0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys', 14, 'B1',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys', 15, 'B2',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys', 16, 'B3',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys', 17, 'Caa1', 0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys', 18, 'Caa2', 0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys', 19, 'Caa3', 0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys', 20, 'Ca',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Moodys', 21, 'C',    0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

-- Fitch
IF NOT EXISTS (SELECT 1 FROM dbo.rating_scale_entry WHERE agency = 'Fitch' AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.rating_scale_entry (id, agency, score, label, is_investment_grade, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES
        (NEWID(), 'Fitch',  1, 'AAA',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch',  2, 'AA+',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch',  3, 'AA',   1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch',  4, 'AA-',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch',  5, 'A+',   1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch',  6, 'A',    1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch',  7, 'A-',   1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch',  8, 'BBB+', 1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch',  9, 'BBB',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch', 10, 'BBB-', 1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch', 11, 'BB+',  0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch', 12, 'BB',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch', 13, 'BB-',  0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch', 14, 'B+',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch', 15, 'B',    0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch', 16, 'B-',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch', 17, 'CCC',  0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch', 18, 'CC',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch', 19, 'C',    0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch', 20, 'RD',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Fitch', 21, 'D',    0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

-- DBRS
IF NOT EXISTS (SELECT 1 FROM dbo.rating_scale_entry WHERE agency = 'DBRS' AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.rating_scale_entry (id, agency, score, label, is_investment_grade, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES
        (NEWID(), 'DBRS',  1, 'AAA',     1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS',  2, 'AA (h)',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS',  3, 'AA',      1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS',  4, 'AA (l)',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS',  5, 'A (h)',   1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS',  6, 'A',       1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS',  7, 'A (l)',   1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS',  8, 'BBB (h)', 1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS',  9, 'BBB',     1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS', 10, 'BBB (l)', 1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS', 11, 'BB (h)',  0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS', 12, 'BB',      0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS', 13, 'BB (l)',  0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS', 14, 'B (h)',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS', 15, 'B',       0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS', 16, 'B (l)',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS', 17, 'CCC (h)', 0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS', 18, 'CCC',     0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS', 19, 'CCC (l)', 0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS', 20, 'CC',      0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'DBRS', 21, 'D',       0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

-- Kroll
IF NOT EXISTS (SELECT 1 FROM dbo.rating_scale_entry WHERE agency = 'Kroll' AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.rating_scale_entry (id, agency, score, label, is_investment_grade, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES
        (NEWID(), 'Kroll',  1, 'AAA',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll',  2, 'AA+',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll',  3, 'AA',   1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll',  4, 'AA-',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll',  5, 'A+',   1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll',  6, 'A',    1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll',  7, 'A-',   1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll',  8, 'BBB+', 1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll',  9, 'BBB',  1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll', 10, 'BBB-', 1, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll', 11, 'BB+',  0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll', 12, 'BB',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll', 13, 'BB-',  0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll', 14, 'B+',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll', 15, 'B',    0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll', 16, 'B-',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll', 17, 'CCC+', 0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll', 18, 'CCC',  0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll', 19, 'CCC-', 0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll', 20, 'CC',   0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0),
        (NEWID(), 'Kroll', 21, 'D',    0, GETUTCDATE(), GETUTCDATE(), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

-- ====================================================================
-- RatingDerivationRules
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM dbo.rating_derivation_rule WHERE model_name = 'micr' AND security_type IS NULL AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.rating_derivation_rule (id, model_name, security_type, config_json, description, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES (NEWID(), 'micr', NULL, '{}',
        'Market-Implied Credit Rating: derives score from observed market spread',
        GETUTCDATE(), CAST('2000-01-01' AS DATETIME2), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.rating_derivation_rule WHERE model_name = 'vpm' AND security_type IS NULL AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.rating_derivation_rule (id, model_name, security_type, config_json, description, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES (NEWID(), 'vpm', NULL, '{}',
        'Vendor Price Model: aggregates weighted vendor prices into a composite rating',
        GETUTCDATE(), CAST('2000-01-01' AS DATETIME2), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.rating_derivation_rule WHERE model_name = 'fundamental' AND security_type IS NULL AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.rating_derivation_rule (id, model_name, security_type, config_json, description, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES (NEWID(), 'fundamental', NULL, '{}',
        'Fundamental Model: derives rating from balance-sheet and income-statement ratios',
        GETUTCDATE(), CAST('2000-01-01' AS DATETIME2), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.rating_derivation_rule WHERE model_name = 'composite' AND security_type IS NULL AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.rating_derivation_rule (id, model_name, security_type, config_json, description, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES (NEWID(), 'composite', NULL, '{}',
        'Composite Model: blends MICR, VPM, and fundamental scores with equal weights',
        GETUTCDATE(), CAST('2024-01-01' AS DATETIME2), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.rating_derivation_rule WHERE model_name = 'composite' AND security_type = 'Bond' AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.rating_derivation_rule (id, model_name, security_type, config_json, description, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES (NEWID(), 'composite', 'Bond', '{}',
        'Composite Model for plain bonds: applies bond-specific blending weights',
        GETUTCDATE(), CAST('2026-01-01' AS DATETIME2), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.rating_derivation_rule WHERE model_name = 'composite' AND security_type = 'CorporateBond' AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.rating_derivation_rule (id, model_name, security_type, config_json, description, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
    VALUES (NEWID(), 'composite', 'CorporateBond', '{}',
        'Composite Model for corporate bonds: applies credit-spread and leverage adjustments',
        GETUTCDATE(), CAST('2026-01-01' AS DATETIME2), '9999-12-31', GETUTCDATE(), '9999-12-31', 1, 0);
END
GO

-- ====================================================================
-- Record this script
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM dbo.[__SchemaVersions] WHERE version = '1.0-seed')
BEGIN
    INSERT INTO dbo.[__SchemaVersions] (version, description, script_name, applied_on, applied_by, status)
    VALUES ('1.0-seed', 'Initial seed data â€” FormulaMacros, RatingScaleEntries, RatingDerivationRules',
            'SeedData_SqlServer.sql', GETUTCDATE(), SYSTEM_USER, 'Success');
END
GO

-- ====================================================================
-- Import Profiles seed data
-- Provides three ready-to-use profiles that mirror the appsettings.json
-- examples so the platform works out-of-the-box without any config.
-- ====================================================================
PRINT 'Seeding ImportProfiles...';

-- â”€â”€ 1. Default CSV profile (FlatFile) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
DECLARE @FlatFileDefaultId UNIQUEIDENTIFIER;
SELECT @FlatFileDefaultId = id FROM dbo.import_profile
    WHERE name = 'Default' AND source_type = 'FlatFile';

IF @FlatFileDefaultId IS NULL
BEGIN
    SET @FlatFileDefaultId = NEWID();
    INSERT INTO dbo.import_profile
        (id, name, description, source_type, file_pattern, folder,
         delimiter, text_qualifier, has_header, skip_rows, is_active, created_at)
    VALUES
        (@FlatFileDefaultId,
         'Default', 'Catch-all CSV profile; matches any *.csv not claimed by a named profile.',
         'FlatFile', '*.csv', '',
         ',', '"', 1, 0, 1, GETUTCDATE());

    -- Column mappings (standard header names â†’ canonical target fields)
    INSERT INTO dbo.import_profile_column
        (id, profile_id, source_column, target_field, sort_order, created_at)
    VALUES
        (NEWID(), @FlatFileDefaultId, 'Symbol',         'symbol',          0,  GETUTCDATE()),
        (NEWID(), @FlatFileDefaultId, 'Name',           'name',            1,  GETUTCDATE()),
        (NEWID(), @FlatFileDefaultId, 'SecurityType',   'securitytype',    2,  GETUTCDATE()),
        (NEWID(), @FlatFileDefaultId, 'ISIN',           'identifiervalue', 3,  GETUTCDATE()),
        (NEWID(), @FlatFileDefaultId, 'CUSIP',          'cusip',           4,  GETUTCDATE()),
        (NEWID(), @FlatFileDefaultId, 'Currency',       'currency',        5,  GETUTCDATE()),
        (NEWID(), @FlatFileDefaultId, 'CouponRate',     'couponrate',      6,  GETUTCDATE()),
        (NEWID(), @FlatFileDefaultId, 'MaturityDate',   'maturitydate',    7,  GETUTCDATE()),
        (NEWID(), @FlatFileDefaultId, 'IssuerName',     'issuername',      8,  GETUTCDATE()),
        (NEWID(), @FlatFileDefaultId, 'Country',        'country',         9,  GETUTCDATE()),
        (NEWID(), @FlatFileDefaultId, 'Exchange',       'exchange',        10, GETUTCDATE()),
        (NEWID(), @FlatFileDefaultId, 'Sector',         'sector',          11, GETUTCDATE()),
        (NEWID(), @FlatFileDefaultId, 'IdentifierType', 'identifiertype',  12, GETUTCDATE()),
        (NEWID(), @FlatFileDefaultId, 'DataSource',     'datasource',      13, GETUTCDATE());

    -- Column validations
    DECLARE @SymbolColId   UNIQUEIDENTIFIER = (SELECT TOP 1 id FROM dbo.import_profile_column WHERE profile_id = @FlatFileDefaultId AND target_field = 'symbol');
    DECLARE @SecTypeColId  UNIQUEIDENTIFIER = (SELECT TOP 1 id FROM dbo.import_profile_column WHERE profile_id = @FlatFileDefaultId AND target_field = 'securitytype');
    DECLARE @CouponColId   UNIQUEIDENTIFIER = (SELECT TOP 1 id FROM dbo.import_profile_column WHERE profile_id = @FlatFileDefaultId AND target_field = 'couponrate');
    DECLARE @MaturityColId UNIQUEIDENTIFIER = (SELECT TOP 1 id FROM dbo.import_profile_column WHERE profile_id = @FlatFileDefaultId AND target_field = 'maturitydate');
    DECLARE @IsinColId     UNIQUEIDENTIFIER = (SELECT TOP 1 id FROM dbo.import_profile_column WHERE profile_id = @FlatFileDefaultId AND target_field = 'identifiervalue');

    -- Symbol: required
    INSERT INTO dbo.import_profile_column_validation
        (id, column_id, rule_type, rule_value, condition, error_message, severity, is_active, created_at)
    VALUES
        (NEWID(), @SymbolColId, 'Required', NULL, NULL, 'Symbol is required.', 'Error', 1, GETUTCDATE());

    -- SecurityType: required + allowed values
    INSERT INTO dbo.import_profile_column_validation
        (id, column_id, rule_type, rule_value, condition, error_message, severity, is_active, created_at)
    VALUES
        (NEWID(), @SecTypeColId, 'Required',      NULL,
         NULL, 'SecurityType is required.', 'Error', 1, GETUTCDATE()),
        (NEWID(), @SecTypeColId, 'AllowedValues', 'Equity,Bond,CorporateBond,GovernmentBond,MunicipalBond,ETF,MutualFund,Derivative,Future,Option,Swap,Other',
         NULL, 'Unknown SecurityType value.', 'Warning', 1, GETUTCDATE());

    -- CouponRate: numeric, only validated when SecurityType is a bond type
    INSERT INTO dbo.import_profile_column_validation
        (id, column_id, rule_type, rule_value, condition, error_message, severity, is_active, created_at)
    VALUES
        (NEWID(), @CouponColId, 'MinValue', '0',
         'securitytype == ''Bond'' or securitytype == ''CorporateBond'' or securitytype == ''GovernmentBond''',
         'CouponRate must be >= 0 for bond instruments.', 'Warning', 1, GETUTCDATE()),
        (NEWID(), @CouponColId, 'MaxValue', '100',
         'securitytype == ''Bond'' or securitytype == ''CorporateBond'' or securitytype == ''GovernmentBond''',
         'CouponRate > 100 is unusual â€” please verify.', 'Warning', 1, GETUTCDATE());

    -- MaturityDate: date format, only for bonds
    INSERT INTO dbo.import_profile_column_validation
        (id, column_id, rule_type, rule_value, condition, error_message, severity, is_active, created_at)
    VALUES
        (NEWID(), @MaturityColId, 'DateFormat', 'yyyy-MM-dd',
         'securitytype == ''Bond'' or securitytype == ''CorporateBond'' or securitytype == ''GovernmentBond''',
         'MaturityDate must be in yyyy-MM-dd format for bond instruments.', 'Warning', 1, GETUTCDATE());

    -- ISIN: regex for standard ISIN format (2-letter country code + 10 alphanumeric)
    INSERT INTO dbo.import_profile_column_validation
        (id, column_id, rule_type, rule_value, condition, error_message, severity, is_active, created_at)
    VALUES
        (NEWID(), @IsinColId, 'Regex', '^[A-Z]{2}[A-Z0-9]{10}$',
         NULL, 'ISIN does not match the standard format (e.g. US0231351067).', 'Warning', 1, GETUTCDATE());

    -- Row-level validation: bonds must have a MaturityDate
    INSERT INTO dbo.import_profile_row_validation
        (id, profile_id, expression, error_message, severity, sort_order, is_active, created_at)
    VALUES
        (NEWID(), @FlatFileDefaultId,
         'not (securitytype == ''Bond'' or securitytype == ''CorporateBond'' or securitytype == ''GovernmentBond'') or not string.IsNullOrEmpty(maturitydate)',
         'Bond instruments must have a MaturityDate.',
         'Warning', 0, 1, GETUTCDATE()),
        (NEWID(), @FlatFileDefaultId,
         'symbol != ''''',
         'Symbol must not be blank.',
         'Error', 1, 1, GETUTCDATE());

    PRINT '  Inserted: FlatFile/Default profile';
END
ELSE
    PRINT '  Skipped:  FlatFile/Default profile (already exists)';
GO

-- â”€â”€ 2. Default JSON profile â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
DECLARE @JsonFileDefaultId UNIQUEIDENTIFIER;
SELECT @JsonFileDefaultId = id FROM dbo.import_profile
    WHERE name = 'Default' AND source_type = 'JsonFile';

IF @JsonFileDefaultId IS NULL
BEGIN
    SET @JsonFileDefaultId = NEWID();
    INSERT INTO dbo.import_profile
        (id, name, description, source_type, file_pattern, folder,
         records_path, is_active, created_at)
    VALUES
        (@JsonFileDefaultId,
         'Default', 'Default JSON import profile; reads a root-level array ($[*]).',
         'JsonFile', '*.json', '',
         '$[*]', 1, GETUTCDATE());

    INSERT INTO dbo.import_profile_column
        (id, profile_id, source_column, target_field, sort_order, created_at)
    VALUES
        (NEWID(), @JsonFileDefaultId, 'symbol',         'symbol',          0,  GETUTCDATE()),
        (NEWID(), @JsonFileDefaultId, 'name',           'name',            1,  GETUTCDATE()),
        (NEWID(), @JsonFileDefaultId, 'securityType',   'securitytype',    2,  GETUTCDATE()),
        (NEWID(), @JsonFileDefaultId, 'isin',           'identifiervalue', 3,  GETUTCDATE()),
        (NEWID(), @JsonFileDefaultId, 'currency',       'currency',        4,  GETUTCDATE()),
        (NEWID(), @JsonFileDefaultId, 'couponRate',     'couponrate',      5,  GETUTCDATE()),
        (NEWID(), @JsonFileDefaultId, 'maturityDate',   'maturitydate',    6,  GETUTCDATE()),
        (NEWID(), @JsonFileDefaultId, 'issuerName',     'issuername',      7,  GETUTCDATE()),
        (NEWID(), @JsonFileDefaultId, 'identifierType', 'identifiertype',  8,  GETUTCDATE());

    DECLARE @JsonSymColId UNIQUEIDENTIFIER = (SELECT TOP 1 id FROM dbo.import_profile_column WHERE profile_id = @JsonFileDefaultId AND target_field = 'symbol');
    INSERT INTO dbo.import_profile_column_validation
        (id, column_id, rule_type, rule_value, condition, error_message, severity, is_active, created_at)
    VALUES
        (NEWID(), @JsonSymColId, 'Required', NULL, NULL, 'Symbol is required.', 'Error', 1, GETUTCDATE());

    PRINT '  Inserted: JsonFile/Default profile';
END
ELSE
    PRINT '  Skipped:  JsonFile/Default profile (already exists)';
GO

-- â”€â”€ 3. Default XML profile â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
DECLARE @XmlFileDefaultId UNIQUEIDENTIFIER;
SELECT @XmlFileDefaultId = id FROM dbo.import_profile
    WHERE name = 'Default' AND source_type = 'XmlFile';

IF @XmlFileDefaultId IS NULL
BEGIN
    SET @XmlFileDefaultId = NEWID();
    INSERT INTO dbo.import_profile
        (id, name, description, source_type, file_pattern, folder,
         records_x_path, is_active, created_at)
    VALUES
        (@XmlFileDefaultId,
         'Default', 'Default XML import profile; selects //Security elements.',
         'XmlFile', '*.xml', '',
         '//Security', 1, GETUTCDATE());

    INSERT INTO dbo.import_profile_column
        (id, profile_id, source_column, target_field, sort_order, created_at)
    VALUES
        (NEWID(), @XmlFileDefaultId, 'Symbol',         'symbol',          0,  GETUTCDATE()),
        (NEWID(), @XmlFileDefaultId, 'Name',           'name',            1,  GETUTCDATE()),
        (NEWID(), @XmlFileDefaultId, 'SecurityType',   'securitytype',    2,  GETUTCDATE()),
        (NEWID(), @XmlFileDefaultId, 'ISIN',           'identifiervalue', 3,  GETUTCDATE()),
        (NEWID(), @XmlFileDefaultId, 'Currency',       'currency',        4,  GETUTCDATE()),
        (NEWID(), @XmlFileDefaultId, 'CouponRate',     'couponrate',      5,  GETUTCDATE()),
        (NEWID(), @XmlFileDefaultId, 'MaturityDate',   'maturitydate',    6,  GETUTCDATE()),
        (NEWID(), @XmlFileDefaultId, 'IdentifierType', 'identifiertype',  7,  GETUTCDATE());

    DECLARE @XmlSymColId UNIQUEIDENTIFIER = (SELECT TOP 1 id FROM dbo.import_profile_column WHERE profile_id = @XmlFileDefaultId AND target_field = 'symbol');
    INSERT INTO dbo.import_profile_column_validation
        (id, column_id, rule_type, rule_value, condition, error_message, severity, is_active, created_at)
    VALUES
        (NEWID(), @XmlSymColId, 'Required', NULL, NULL, 'Symbol is required.', 'Error', 1, GETUTCDATE());

    PRINT '  Inserted: XmlFile/Default profile';
END
ELSE
    PRINT '  Skipped:  XmlFile/Default profile (already exists)';
GO

PRINT 'ImportProfiles seed data loaded successfully.';
GO

IF NOT EXISTS (SELECT 1 FROM dbo.[__SchemaVersions] WHERE version = '1.1-seed')
BEGIN
    INSERT INTO dbo.[__SchemaVersions] (version, description, script_name, applied_on, applied_by, status)
    VALUES ('1.1-seed', 'ImportProfile seed data â€” Default profiles for FlatFile, JsonFile, XmlFile',
            'SeedData_SqlServer.sql', GETUTCDATE(), SYSTEM_USER, 'Success');
END
GO

-- ====================================================================
-- Currencies â€” ISO 4217 active codes + common crypto
-- ====================================================================
PRINT 'Seeding currencies...';
GO

-- ISO 4217 fiat currencies (active)
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'AED') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AED','784','UAE Dirham','Ø¯.Ø¥',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'AFN') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AFN','971','Afghan Afghani','Ø‹',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'ALL') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ALL','008','Albanian Lek','L',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'AMD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AMD','051','Armenian Dram','Ö',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'ANG') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ANG','532','Netherlands Antillean Guilder','Æ’',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'AOA') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AOA','973','Angolan Kwanza','Kz',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'ARS') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ARS','032','Argentine Peso','$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'AUD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AUD','036','Australian Dollar','A$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'AWG') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AWG','533','Aruban Florin','Æ’',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'AZN') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AZN','944','Azerbaijani Manat','â‚¼',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BAM') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BAM','977','Bosnia-Herzegovina Convertible Mark','KM',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BBD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BBD','052','Barbadian Dollar','Bds$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BDT') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BDT','050','Bangladeshi Taka','à§³',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BGN') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BGN','975','Bulgarian Lev','Ð»Ð²',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BHD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BHD','048','Bahraini Dinar','BD',3,3,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BIF') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BIF','108','Burundian Franc','Fr',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BMD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BMD','060','Bermudian Dollar','BD$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BND') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BND','096','Brunei Dollar','B$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BOB') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BOB','068','Bolivian Boliviano','Bs.',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BRL') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BRL','986','Brazilian Real','R$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BSD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BSD','044','Bahamian Dollar','B$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BTN') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BTN','064','Bhutanese Ngultrum','Nu',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BWP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BWP','072','Botswanan Pula','P',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BYN') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BYN','933','Belarusian Ruble','Br',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BZD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BZD','084','Belize Dollar','BZ$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'CAD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CAD','124','Canadian Dollar','CA$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'CDF') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CDF','976','Congolese Franc','FC',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'CHF') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CHF','756','Swiss Franc','Fr',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'CLP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CLP','152','Chilean Peso','CLP$',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'CNY') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CNY','156','Chinese Yuan','Â¥',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'COP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('COP','170','Colombian Peso','COL$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'CRC') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CRC','188','Costa Rican ColÃ³n','â‚¡',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'CUP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CUP','192','Cuban Peso','â‚±',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'CVE') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CVE','132','Cape Verdean Escudo','$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'CZK') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CZK','203','Czech Koruna','KÄ',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'DJF') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('DJF','262','Djiboutian Franc','Fdj',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'DKK') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('DKK','208','Danish Krone','kr',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'DOP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('DOP','214','Dominican Peso','RD$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'DZD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('DZD','012','Algerian Dinar','Ø¯Ø¬',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'EGP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('EGP','818','Egyptian Pound','EÂ£',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'ERN') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ERN','232','Eritrean Nakfa','Nfk',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'ETB') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ETB','230','Ethiopian Birr','Br',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'EUR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('EUR','978','Euro','â‚¬',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'FJD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('FJD','242','Fijian Dollar','FJ$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'FKP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('FKP','238','Falkland Islands Pound','Â£',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'GBP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GBP','826','British Pound Sterling','Â£',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'GEL') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GEL','981','Georgian Lari','â‚¾',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'GHS') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GHS','936','Ghanaian Cedi','â‚µ',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'GIP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GIP','292','Gibraltar Pound','Â£',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'GMD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GMD','270','Gambian Dalasi','D',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'GNF') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GNF','324','Guinean Franc','FG',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'GTQ') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GTQ','320','Guatemalan Quetzal','Q',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'GYD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GYD','328','Guyanaese Dollar','G$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'HKD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('HKD','344','Hong Kong Dollar','HK$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'HNL') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('HNL','340','Honduran Lempira','L',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'HTG') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('HTG','332','Haitian Gourde','G',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'HUF') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('HUF','348','Hungarian Forint','Ft',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'IDR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('IDR','360','Indonesian Rupiah','Rp',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'ILS') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ILS','376','Israeli New Shekel','â‚ª',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'INR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('INR','356','Indian Rupee','â‚¹',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'IQD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('IQD','368','Iraqi Dinar','Ø¹.Ø¯',3,3,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'IRR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('IRR','364','Iranian Rial','ï·¼',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'ISK') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ISK','352','Icelandic KrÃ³na','kr',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'JMD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('JMD','388','Jamaican Dollar','J$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'JOD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('JOD','400','Jordanian Dinar','JD',3,3,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'JPY') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('JPY','392','Japanese Yen','Â¥',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'KES') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KES','404','Kenyan Shilling','KSh',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'KGS') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KGS','417','Kyrgystani Som','Ð»Ð²',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'KHR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KHR','116','Cambodian Riel','áŸ›',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'KMF') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KMF','174','Comorian Franc','CF',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'KPW') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KPW','408','North Korean Won','â‚©',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'KRW') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KRW','410','South Korean Won','â‚©',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'KWD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KWD','414','Kuwaiti Dinar','KD',3,3,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'KYD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KYD','136','Cayman Islands Dollar','CI$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'KZT') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KZT','398','Kazakhstani Tenge','â‚¸',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'LAK') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('LAK','418','Laotian Kip','â‚­',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'LBP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('LBP','422','Lebanese Pound','Ù„.Ù„',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'LKR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('LKR','144','Sri Lankan Rupee','Rs',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'LRD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('LRD','430','Liberian Dollar','L$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'LSL') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('LSL','426','Lesotho Loti','L',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'LYD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('LYD','434','Libyan Dinar','LD',3,3,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'MAD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MAD','504','Moroccan Dirham','MAD',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'MDL') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MDL','498','Moldovan Leu','L',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'MGA') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MGA','969','Malagasy Ariary','Ar',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'MKD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MKD','807','Macedonian Denar','Ð´ÐµÐ½',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'MMK') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MMK','104','Myanmar Kyat','K',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'MNT') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MNT','496','Mongolian TÃ¶grÃ¶g','â‚®',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'MOP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MOP','446','Macanese Pataca','P',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'MRU') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MRU','929','Mauritanian Ouguiya','UM',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'MUR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MUR','480','Mauritian Rupee','Rs',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'MVR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MVR','462','Maldivian Rufiyaa','Rf',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'MWK') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MWK','454','Malawian Kwacha','MK',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'MXN') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MXN','484','Mexican Peso','Mex$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'MYR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MYR','458','Malaysian Ringgit','RM',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'MZN') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MZN','943','Mozambican Metical','MT',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'NAD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('NAD','516','Namibian Dollar','N$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'NGN') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('NGN','566','Nigerian Naira','â‚¦',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'NIO') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('NIO','558','Nicaraguan CÃ³rdoba','C$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'NOK') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('NOK','578','Norwegian Krone','kr',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'NPR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('NPR','524','Nepalese Rupee','Rs',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'NZD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('NZD','554','New Zealand Dollar','NZ$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'OMR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('OMR','512','Omani Rial','Ø±.Ø¹.',3,3,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'PAB') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('PAB','590','Panamanian Balboa','B/.',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'PEN') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('PEN','604','Peruvian Sol','S/.',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'PGK') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('PGK','598','Papua New Guinean Kina','K',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'PHP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('PHP','608','Philippine Peso','â‚±',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'PKR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('PKR','586','Pakistani Rupee','Rs',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'PLN') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('PLN','985','Polish Zloty','zÅ‚',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'PYG') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('PYG','600','Paraguayan Guarani','â‚²',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'QAR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('QAR','634','Qatari Riyal','QR',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'RON') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('RON','946','Romanian Leu','lei',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'RSD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('RSD','941','Serbian Dinar','din',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'RUB') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('RUB','643','Russian Ruble','â‚½',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'RWF') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('RWF','646','Rwandan Franc','RF',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'SAR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SAR','682','Saudi Riyal','SR',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'SBD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SBD','090','Solomon Islands Dollar','SI$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'SCR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SCR','690','Seychellois Rupee','Rs',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'SDG') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SDG','938','Sudanese Pound','Ø¬.Ø³.',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'SEK') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SEK','752','Swedish Krona','kr',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'SGD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SGD','702','Singapore Dollar','S$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'SHP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SHP','654','Saint Helena Pound','Â£',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'SLE') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SLE','925','Sierra Leonean Leone','Le',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'SOS') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SOS','706','Somali Shilling','Sh',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'SRD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SRD','968','Surinamese Dollar','$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'SSP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SSP','728','South Sudanese Pound','Â£',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'STN') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('STN','930','SÃ£o TomÃ© and PrÃ­ncipe Dobra','Db',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'SVC') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SVC','222','Salvadoran ColÃ³n','â‚¡',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'SYP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SYP','760','Syrian Pound','Â£S',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'SZL') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SZL','748','Swazi Lilangeni','L',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'THB') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('THB','764','Thai Baht','à¸¿',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'TJS') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TJS','972','Tajikistani Somoni','SM',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'TMT') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TMT','934','Turkmenistani Manat','T',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'TND') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TND','788','Tunisian Dinar','DT',3,3,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'TOP') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TOP','776','Tongan PaÊ»anga','T$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'TRY') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TRY','949','Turkish Lira','â‚º',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'TTD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TTD','780','Trinidad and Tobago Dollar','TT$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'TWD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TWD','901','New Taiwan Dollar','NT$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'TZS') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TZS','834','Tanzanian Shilling','Sh',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'UAH') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('UAH','980','Ukrainian Hryvnia','â‚´',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'UGX') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('UGX','800','Ugandan Shilling','USh',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'USD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('USD','840','US Dollar','$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'UYU') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('UYU','858','Uruguayan Peso','$U',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'UZS') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('UZS','860','Uzbekistani Sum','Ð»Ð²',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'VES') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('VES','928','Venezuelan BolÃ­var Soberano','Bs.S',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'VND') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('VND','704','Vietnamese Dong','â‚«',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'VUV') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('VUV','548','Vanuatu Vatu','VT',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'WST') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('WST','882','Samoan Tala','T',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'XAF') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XAF','950','Central African CFA Franc','Fr',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'XCD') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XCD','951','East Caribbean Dollar','EC$',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'XOF') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XOF','952','West African CFA Franc','Fr',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'XPF') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XPF','953','CFP Franc','Fr',0,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'YER') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('YER','886','Yemeni Rial','ï·¼',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'ZAR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ZAR','710','South African Rand','R',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'ZMW') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ZMW','967','Zambian Kwacha','ZK',2,2,'FIAT',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'ZWG') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ZWG','924','Zimbabwe Gold','ZiG',2,2,'FIAT',1);
-- Non-decimal / special
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'XDR') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XDR','960','IMF Special Drawing Rights','SDR',0,2,'OTHER',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'XAU') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XAU','959','Gold (troy ounce)','XAU',4,4,'COMMODITY',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'XAG') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XAG','961','Silver (troy ounce)','XAG',4,4,'COMMODITY',1);
-- Crypto currencies
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BTC')  INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BTC', NULL,'Bitcoin','â‚¿',8,8,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'ETH')  INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ETH', NULL,'Ethereum','Îž',18,8,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'USDT') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('USDT',NULL,'Tether','â‚®',6,6,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'BNB')  INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BNB', NULL,'BNB','BNB',8,8,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'SOL')  INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SOL', NULL,'Solana','SOL',9,8,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'USDC') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('USDC',NULL,'USD Coin','USDC',6,6,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'XRP')  INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XRP', NULL,'XRP','XRP',6,6,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'DOGE') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('DOGE',NULL,'Dogecoin','Ã',8,8,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'ADA')  INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ADA', NULL,'Cardano','ADA',6,6,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'AVAX') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AVAX',NULL,'Avalanche','AVAX',18,8,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'TRX')  INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TRX', NULL,'TRON','TRX',6,6,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'DOT')  INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('DOT', NULL,'Polkadot','DOT',10,8,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'LINK') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('LINK',NULL,'Chainlink','LINK',18,8,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'MATIC') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MATIC',NULL,'Polygon','MATIC',18,8,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'LTC')  INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('LTC', NULL,'Litecoin','Å',8,8,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'XLM')  INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XLM', NULL,'Stellar Lumens','XLM',7,7,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'XMR')  INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XMR', NULL,'Monero','XMR',12,8,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'ALGO') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ALGO',NULL,'Algorand','ALGO',6,6,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'ATOM') INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ATOM',NULL,'Cosmos','ATOM',6,6,'CRYPTO',1);
IF NOT EXISTS (SELECT 1 FROM dbo.currency WHERE code = 'UNI')  INSERT INTO dbo.currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('UNI', NULL,'Uniswap','UNI',18,8,'CRYPTO',1);
GO

PRINT 'Currencies seeded.';
GO

-- ====================================================================
-- Countries â€” ISO 3166-1
-- ====================================================================
PRINT 'Seeding countries...';
GO

IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AF') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AF','AFG','004','Afghanistan','.af');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AX') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AX','ALA','248','Ã…land Islands','.ax');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AL') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AL','ALB','008','Albania','.al');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'DZ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('DZ','DZA','012','Algeria','.dz');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AS') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AS','ASM','016','American Samoa','.as');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AD') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AD','AND','020','Andorra','.ad');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AO') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AO','AGO','024','Angola','.ao');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AI') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AI','AIA','660','Anguilla','.ai');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AQ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AQ','ATA','010','Antarctica','.aq');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AG') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AG','ATG','028','Antigua and Barbuda','.ag');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AR') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AR','ARG','032','Argentina','.ar');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AM','ARM','051','Armenia','.am');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AW') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AW','ABW','533','Aruba','.aw');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AU') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AU','AUS','036','Australia','.au');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AT') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AT','AUT','040','Austria','.at');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AZ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AZ','AZE','031','Azerbaijan','.az');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BS') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BS','BHS','044','Bahamas','.bs');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BH') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BH','BHR','048','Bahrain','.bh');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BD') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BD','BGD','050','Bangladesh','.bd');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BB') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BB','BRB','052','Barbados','.bb');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BY') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BY','BLR','112','Belarus','.by');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BE') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BE','BEL','056','Belgium','.be');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BZ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BZ','BLZ','084','Belize','.bz');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BJ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BJ','BEN','204','Benin','.bj');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BM','BMU','060','Bermuda','.bm');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BT') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BT','BTN','064','Bhutan','.bt');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BO') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BO','BOL','068','Bolivia','.bo');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BQ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BQ','BES','535','Bonaire, Sint Eustatius and Saba','.bq');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BA') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BA','BIH','070','Bosnia and Herzegovina','.ba');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BW') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BW','BWA','072','Botswana','.bw');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BV') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BV','BVT','074','Bouvet Island',NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BR') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BR','BRA','076','Brazil','.br');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'IO') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IO','IOT','086','British Indian Ocean Territory','.io');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BN') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BN','BRN','096','Brunei Darussalam','.bn');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BG') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BG','BGR','100','Bulgaria','.bg');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BF') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BF','BFA','854','Burkina Faso','.bf');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BI') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BI','BDI','108','Burundi','.bi');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CV') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CV','CPV','132','Cabo Verde','.cv');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'KH') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KH','KHM','116','Cambodia','.kh');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CM','CMR','120','Cameroon','.cm');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CA') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CA','CAN','124','Canada','.ca');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'KY') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KY','CYM','136','Cayman Islands','.ky');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CF') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CF','CAF','140','Central African Republic','.cf');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TD') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TD','TCD','148','Chad','.td');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CL') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CL','CHL','152','Chile','.cl');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CN') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CN','CHN','156','China','.cn');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CX') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CX','CXR','162','Christmas Island','.cx');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CC') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CC','CCK','166','Cocos (Keeling) Islands','.cc');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CO') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CO','COL','170','Colombia','.co');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'KM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KM','COM','174','Comoros','.km');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CD') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CD','COD','180','Congo, Democratic Republic of the','.cd');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CG') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CG','COG','178','Congo','.cg');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CK') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CK','COK','184','Cook Islands','.ck');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CR') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CR','CRI','188','Costa Rica','.cr');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CI') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CI','CIV','384','CÃ´te d''Ivoire','.ci');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'HR') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('HR','HRV','191','Croatia','.hr');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CU') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CU','CUB','192','Cuba','.cu');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CW') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CW','CUW','531','CuraÃ§ao','.cw');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CY') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CY','CYP','196','Cyprus','.cy');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CZ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CZ','CZE','203','Czechia','.cz');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'DK') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('DK','DNK','208','Denmark','.dk');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'DJ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('DJ','DJI','262','Djibouti','.dj');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'DM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('DM','DMA','212','Dominica','.dm');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'DO') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('DO','DOM','214','Dominican Republic','.do');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'EC') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('EC','ECU','218','Ecuador','.ec');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'EG') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('EG','EGY','818','Egypt','.eg');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SV') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SV','SLV','222','El Salvador','.sv');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GQ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GQ','GNQ','226','Equatorial Guinea','.gq');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'ER') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ER','ERI','232','Eritrea','.er');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'EE') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('EE','EST','233','Estonia','.ee');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SZ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SZ','SWZ','748','Eswatini','.sz');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'ET') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ET','ETH','231','Ethiopia','.et');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'FK') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('FK','FLK','238','Falkland Islands','.fk');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'FO') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('FO','FRO','234','Faroe Islands','.fo');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'FJ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('FJ','FJI','242','Fiji','.fj');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'FI') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('FI','FIN','246','Finland','.fi');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'FR') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('FR','FRA','250','France','.fr');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GF') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GF','GUF','254','French Guiana','.gf');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'PF') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PF','PYF','258','French Polynesia','.pf');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TF') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TF','ATF','260','French Southern Territories','.tf');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GA') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GA','GAB','266','Gabon','.ga');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GM','GMB','270','Gambia','.gm');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GE') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GE','GEO','268','Georgia','.ge');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'DE') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('DE','DEU','276','Germany','.de');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GH') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GH','GHA','288','Ghana','.gh');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GI') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GI','GIB','292','Gibraltar','.gi');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GR') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GR','GRC','300','Greece','.gr');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GL') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GL','GRL','304','Greenland','.gl');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GD') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GD','GRD','308','Grenada','.gd');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GP') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GP','GLP','312','Guadeloupe','.gp');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GU') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GU','GUM','316','Guam','.gu');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GT') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GT','GTM','320','Guatemala','.gt');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GG') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GG','GGY','831','Guernsey','.gg');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GN') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GN','GIN','324','Guinea','.gn');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GW') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GW','GNB','624','Guinea-Bissau','.gw');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GY') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GY','GUY','328','Guyana','.gy');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'HT') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('HT','HTI','332','Haiti','.ht');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'HM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('HM','HMD','334','Heard Island and McDonald Islands','.hm');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'VA') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('VA','VAT','336','Holy See','.va');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'HN') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('HN','HND','340','Honduras','.hn');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'HK') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('HK','HKG','344','Hong Kong','.hk');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'HU') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('HU','HUN','348','Hungary','.hu');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'IS') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IS','ISL','352','Iceland','.is');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'IN') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IN','IND','356','India','.in');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'ID') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ID','IDN','360','Indonesia','.id');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'IR') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IR','IRN','364','Iran','.ir');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'IQ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IQ','IRQ','368','Iraq','.iq');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'IE') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IE','IRL','372','Ireland','.ie');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'IM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IM','IMN','833','Isle of Man','.im');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'IL') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IL','ISR','376','Israel','.il');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'IT') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IT','ITA','380','Italy','.it');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'JM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('JM','JAM','388','Jamaica','.jm');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'JP') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('JP','JPN','392','Japan','.jp');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'JE') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('JE','JEY','832','Jersey','.je');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'JO') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('JO','JOR','400','Jordan','.jo');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'KZ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KZ','KAZ','398','Kazakhstan','.kz');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'KE') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KE','KEN','404','Kenya','.ke');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'KI') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KI','KIR','296','Kiribati','.ki');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'KP') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KP','PRK','408','Korea, Democratic People''s Republic of','.kp');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'KR') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KR','KOR','410','Korea, Republic of','.kr');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'KW') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KW','KWT','414','Kuwait','.kw');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'KG') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KG','KGZ','417','Kyrgyzstan','.kg');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'LA') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LA','LAO','418','Lao People''s Democratic Republic','.la');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'LV') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LV','LVA','428','Latvia','.lv');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'LB') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LB','LBN','422','Lebanon','.lb');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'LS') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LS','LSO','426','Lesotho','.ls');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'LR') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LR','LBR','430','Liberia','.lr');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'LY') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LY','LBY','434','Libya','.ly');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'LI') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LI','LIE','438','Liechtenstein','.li');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'LT') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LT','LTU','440','Lithuania','.lt');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'LU') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LU','LUX','442','Luxembourg','.lu');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MO') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MO','MAC','446','Macao','.mo');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MG') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MG','MDG','450','Madagascar','.mg');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MW') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MW','MWI','454','Malawi','.mw');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MY') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MY','MYS','458','Malaysia','.my');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MV') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MV','MDV','462','Maldives','.mv');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'ML') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ML','MLI','466','Mali','.ml');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MT') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MT','MLT','470','Malta','.mt');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MH') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MH','MHL','584','Marshall Islands','.mh');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MQ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MQ','MTQ','474','Martinique','.mq');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MR') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MR','MRT','478','Mauritania','.mr');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MU') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MU','MUS','480','Mauritius','.mu');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'YT') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('YT','MYT','175','Mayotte','.yt');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MX') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MX','MEX','484','Mexico','.mx');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'FM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('FM','FSM','583','Micronesia','.fm');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MD') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MD','MDA','498','Moldova','.md');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MC') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MC','MCO','492','Monaco','.mc');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MN') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MN','MNG','496','Mongolia','.mn');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'ME') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ME','MNE','499','Montenegro','.me');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MS') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MS','MSR','500','Montserrat','.ms');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MA') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MA','MAR','504','Morocco','.ma');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MZ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MZ','MOZ','508','Mozambique','.mz');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MM','MMR','104','Myanmar','.mm');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'NA') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NA','NAM','516','Namibia','.na');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'NR') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NR','NRU','520','Nauru','.nr');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'NP') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NP','NPL','524','Nepal','.np');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'NL') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NL','NLD','528','Netherlands','.nl');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'NC') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NC','NCL','540','New Caledonia','.nc');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'NZ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NZ','NZL','554','New Zealand','.nz');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'NI') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NI','NIC','558','Nicaragua','.ni');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'NE') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NE','NER','562','Niger','.ne');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'NG') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NG','NGA','566','Nigeria','.ng');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'NU') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NU','NIU','570','Niue','.nu');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'NF') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NF','NFK','574','Norfolk Island','.nf');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MK') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MK','MKD','807','North Macedonia','.mk');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MP') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MP','MNP','580','Northern Mariana Islands','.mp');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'NO') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NO','NOR','578','Norway','.no');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'OM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('OM','OMN','512','Oman','.om');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'PK') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PK','PAK','586','Pakistan','.pk');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'PW') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PW','PLW','585','Palau','.pw');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'PS') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PS','PSE','275','Palestine, State of','.ps');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'PA') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PA','PAN','591','Panama','.pa');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'PG') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PG','PNG','598','Papua New Guinea','.pg');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'PY') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PY','PRY','600','Paraguay','.py');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'PE') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PE','PER','604','Peru','.pe');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'PH') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PH','PHL','608','Philippines','.ph');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'PN') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PN','PCN','612','Pitcairn','.pn');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'PL') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PL','POL','616','Poland','.pl');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'PT') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PT','PRT','620','Portugal','.pt');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'PR') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PR','PRI','630','Puerto Rico','.pr');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'QA') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('QA','QAT','634','Qatar','.qa');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'RE') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('RE','REU','638','RÃ©union','.re');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'RO') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('RO','ROU','642','Romania','.ro');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'RU') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('RU','RUS','643','Russian Federation','.ru');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'RW') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('RW','RWA','646','Rwanda','.rw');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'BL') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BL','BLM','652','Saint BarthÃ©lemy','.bl');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SH') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SH','SHN','654','Saint Helena, Ascension and Tristan da Cunha','.sh');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'KN') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KN','KNA','659','Saint Kitts and Nevis','.kn');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'LC') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LC','LCA','662','Saint Lucia','.lc');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'MF') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MF','MAF','663','Saint Martin (French part)','.mf');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'PM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PM','SPM','666','Saint Pierre and Miquelon','.pm');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'VC') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('VC','VCT','670','Saint Vincent and the Grenadines','.vc');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'WS') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('WS','WSM','882','Samoa','.ws');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SM','SMR','674','San Marino','.sm');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'ST') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ST','STP','678','Sao Tome and Principe','.st');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SA') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SA','SAU','682','Saudi Arabia','.sa');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SN') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SN','SEN','686','Senegal','.sn');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'RS') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('RS','SRB','688','Serbia','.rs');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SC') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SC','SYC','690','Seychelles','.sc');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SL') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SL','SLE','694','Sierra Leone','.sl');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SG') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SG','SGP','702','Singapore','.sg');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SX') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SX','SXM','534','Sint Maarten (Dutch part)','.sx');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SK') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SK','SVK','703','Slovakia','.sk');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SI') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SI','SVN','705','Slovenia','.si');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SB') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SB','SLB','090','Solomon Islands','.sb');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SO') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SO','SOM','706','Somalia','.so');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'ZA') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ZA','ZAF','710','South Africa','.za');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GS') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GS','SGS','239','South Georgia and the South Sandwich Islands','.gs');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SS') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SS','SSD','728','South Sudan','.ss');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'ES') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ES','ESP','724','Spain','.es');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'LK') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LK','LKA','144','Sri Lanka','.lk');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SD') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SD','SDN','729','Sudan','.sd');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SR') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SR','SUR','740','Suriname','.sr');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SJ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SJ','SJM','744','Svalbard and Jan Mayen',NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SE') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SE','SWE','752','Sweden','.se');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'CH') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CH','CHE','756','Switzerland','.ch');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'SY') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SY','SYR','760','Syrian Arab Republic','.sy');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TW') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TW','TWN','158','Taiwan, Province of China','.tw');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TJ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TJ','TJK','762','Tajikistan','.tj');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TZ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TZ','TZA','834','Tanzania, United Republic of','.tz');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TH') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TH','THA','764','Thailand','.th');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TL') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TL','TLS','626','Timor-Leste','.tl');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TG') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TG','TGO','768','Togo','.tg');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TK') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TK','TKL','772','Tokelau','.tk');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TO') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TO','TON','776','Tonga','.to');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TT') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TT','TTO','780','Trinidad and Tobago','.tt');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TN') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TN','TUN','788','Tunisia','.tn');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TR') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TR','TUR','792','TÃ¼rkiye','.tr');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TM','TKM','795','Turkmenistan','.tm');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TC') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TC','TCA','796','Turks and Caicos Islands','.tc');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'TV') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TV','TUV','798','Tuvalu','.tv');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'UG') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('UG','UGA','800','Uganda','.ug');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'UA') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('UA','UKR','804','Ukraine','.ua');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'AE') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AE','ARE','784','United Arab Emirates','.ae');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'GB') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GB','GBR','826','United Kingdom','.uk');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'UM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('UM','UMI','581','United States Minor Outlying Islands',NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'US') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('US','USA','840','United States of America','.us');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'UY') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('UY','URY','858','Uruguay','.uy');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'UZ') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('UZ','UZB','860','Uzbekistan','.uz');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'VU') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('VU','VUT','548','Vanuatu','.vu');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'VE') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('VE','VEN','862','Venezuela','.ve');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'VN') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('VN','VNM','704','Viet Nam','.vn');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'VG') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('VG','VGB','092','Virgin Islands, British','.vg');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'VI') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('VI','VIR','850','Virgin Islands, U.S.','.vi');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'WF') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('WF','WLF','876','Wallis and Futuna','.wf');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'EH') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('EH','ESH','732','Western Sahara',NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'YE') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('YE','YEM','887','Yemen','.ye');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'ZM') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ZM','ZMB','894','Zambia','.zm');
IF NOT EXISTS (SELECT 1 FROM dbo.country WHERE alpha2 = 'ZW') INSERT INTO dbo.country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ZW','ZWE','716','Zimbabwe','.zw');
GO

PRINT 'Countries seeded.';
GO

-- ====================================================================
-- Countryâ€“Currency associations
-- ====================================================================
PRINT 'Seeding country_currency links...';
GO

-- Helper: only insert if the pair doesn't already exist
-- Columns: country_alpha2, currency_code, is_primary, is_legal_tender, is_operational

-- â”€â”€ United States
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='US' AND currency_code='USD') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('US','USD',1,1,1);
-- â”€â”€ United Kingdom
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='GB' AND currency_code='GBP') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('GB','GBP',1,1,1);
-- â”€â”€ Japan
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='JP' AND currency_code='JPY') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('JP','JPY',1,1,1);
-- â”€â”€ Switzerland
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='CH' AND currency_code='CHF') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('CH','CHF',1,1,1);
-- â”€â”€ Australia
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='AU' AND currency_code='AUD') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('AU','AUD',1,1,1);
-- â”€â”€ Canada
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='CA' AND currency_code='CAD') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('CA','CAD',1,1,1);
-- â”€â”€ New Zealand
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='NZ' AND currency_code='NZD') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('NZ','NZD',1,1,1);
-- â”€â”€ Hong Kong
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='HK' AND currency_code='HKD') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('HK','HKD',1,1,1);
-- â”€â”€ Singapore
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='SG' AND currency_code='SGD') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('SG','SGD',1,1,1);
-- â”€â”€ China
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='CN' AND currency_code='CNY') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('CN','CNY',1,1,1);
-- â”€â”€ India
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='IN' AND currency_code='INR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('IN','INR',1,1,1);
-- â”€â”€ Brazil
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='BR' AND currency_code='BRL') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('BR','BRL',1,1,1);
-- â”€â”€ Mexico
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='MX' AND currency_code='MXN') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('MX','MXN',1,1,1);
-- â”€â”€ South Africa
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='ZA' AND currency_code='ZAR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('ZA','ZAR',1,1,1);
-- â”€â”€ Russia
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='RU' AND currency_code='RUB') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('RU','RUB',1,1,1);
-- â”€â”€ Turkey
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='TR' AND currency_code='TRY') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('TR','TRY',1,1,1);
-- â”€â”€ South Korea
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='KR' AND currency_code='KRW') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('KR','KRW',1,1,1);
-- â”€â”€ Indonesia
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='ID' AND currency_code='IDR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('ID','IDR',1,1,1);
-- â”€â”€ Malaysia
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='MY' AND currency_code='MYR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('MY','MYR',1,1,1);
-- â”€â”€ Thailand
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='TH' AND currency_code='THB') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('TH','THB',1,1,1);
-- â”€â”€ Philippines
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='PH' AND currency_code='PHP') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('PH','PHP',1,1,1);
-- â”€â”€ Poland
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='PL' AND currency_code='PLN') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('PL','PLN',1,1,1);
-- â”€â”€ Czechia
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='CZ' AND currency_code='CZK') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('CZ','CZK',1,1,1);
-- â”€â”€ Hungary
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='HU' AND currency_code='HUF') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('HU','HUF',1,1,1);
-- â”€â”€ Romania
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='RO' AND currency_code='RON') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('RO','RON',1,1,1);
-- â”€â”€ Bulgaria
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='BG' AND currency_code='BGN') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('BG','BGN',1,1,1);
-- â”€â”€ Iceland
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='IS' AND currency_code='ISK') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('IS','ISK',1,1,1);
-- â”€â”€ Israel
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='IL' AND currency_code='ILS') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('IL','ILS',1,1,1);
-- â”€â”€ UAE
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='AE' AND currency_code='AED') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('AE','AED',1,1,1);
-- â”€â”€ Saudi Arabia
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='SA' AND currency_code='SAR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('SA','SAR',1,1,1);
-- â”€â”€ Qatar
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='QA' AND currency_code='QAR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('QA','QAR',1,1,1);
-- â”€â”€ Kuwait
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='KW' AND currency_code='KWD') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('KW','KWD',1,1,1);
-- â”€â”€ Bahrain
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='BH' AND currency_code='BHD') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('BH','BHD',1,1,1);
-- â”€â”€ Oman
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='OM' AND currency_code='OMR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('OM','OMR',1,1,1);
-- â”€â”€ Jordan
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='JO' AND currency_code='JOD') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('JO','JOD',1,1,1);
-- â”€â”€ Egypt
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='EG' AND currency_code='EGP') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('EG','EGP',1,1,1);
-- â”€â”€ Morocco
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='MA' AND currency_code='MAD') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('MA','MAD',1,1,1);
-- â”€â”€ Nigeria
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='NG' AND currency_code='NGN') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('NG','NGN',1,1,1);
-- â”€â”€ Kenya
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='KE' AND currency_code='KES') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('KE','KES',1,1,1);
-- â”€â”€ Tanzania
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='TZ' AND currency_code='TZS') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('TZ','TZS',1,1,1);
-- â”€â”€ Uganda
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='UG' AND currency_code='UGX') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('UG','UGX',1,1,1);
-- â”€â”€ Ghana
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='GH' AND currency_code='GHS') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('GH','GHS',1,1,1);
-- â”€â”€ Zambia
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='ZM' AND currency_code='ZMW') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('ZM','ZMW',1,1,1);
-- â”€â”€ Ethiopia
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='ET' AND currency_code='ETB') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('ET','ETB',1,1,1);
-- â”€â”€ Algeria
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='DZ' AND currency_code='DZD') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('DZ','DZD',1,1,1);
-- â”€â”€ Ukraine
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='UA' AND currency_code='UAH') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('UA','UAH',1,1,1);
-- â”€â”€ Belarus
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='BY' AND currency_code='BYN') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('BY','BYN',1,1,1);
-- â”€â”€ Norway
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='NO' AND currency_code='NOK') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('NO','NOK',1,1,1);
-- â”€â”€ Sweden
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='SE' AND currency_code='SEK') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('SE','SEK',1,1,1);
-- â”€â”€ Denmark
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='DK' AND currency_code='DKK') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('DK','DKK',1,1,1);
-- â”€â”€ Eurozone members (EUR as primary)
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='AT' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('AT','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='BE' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('BE','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='CY' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('CY','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='EE' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('EE','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='FI' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('FI','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='FR' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('FR','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='DE' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('DE','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='GR' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('GR','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='IE' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('IE','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='IT' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('IT','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='LV' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('LV','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='LT' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('LT','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='LU' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('LU','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='MT' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('MT','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='NL' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('NL','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='PT' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('PT','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='SK' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('SK','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='SI' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('SI','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='ES' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('ES','EUR',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='HR' AND currency_code='EUR') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('HR','EUR',1,1,1);
-- â”€â”€ Panama: primary PAB, USD also legal tender/operational
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='PA' AND currency_code='PAB') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('PA','PAB',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='PA' AND currency_code='USD') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('PA','USD',0,1,1);
-- â”€â”€ El Salvador: USD primary + SVC coexist
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='SV' AND currency_code='USD') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('SV','USD',1,1,1);
IF NOT EXISTS (SELECT 1 FROM dbo.country_currency WHERE country_alpha2='SV' AND currency_code='SVC') INSERT INTO dbo.country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('SV','SVC',0,1,1);
GO

PRINT 'Countryâ€“currency links seeded.';
GO

IF NOT EXISTS (SELECT 1 FROM dbo.[__SchemaVersions] WHERE version = '1.2-ref-data')
BEGIN
    INSERT INTO dbo.[__SchemaVersions] (version, description, script_name, applied_on, applied_by, status)
    VALUES ('1.2-ref-data', 'ISO 4217 currencies (fiat + crypto), ISO 3166-1 countries, and country_currency links',
            'SeedData_SqlServer.sql', GETUTCDATE(), SYSTEM_USER, 'Success');
END
GO

PRINT 'SecurityApp seed data loaded successfully.';
GO

-- â”€â”€ Permission Catalog (idempotent) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
-- Seeds the master permission_definition table from Keycloak client roles.
-- Also creates 3 standard permission bundles (admin, contributor, viewer).
-- â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

IF NOT EXISTS (SELECT 1 FROM dbo.permission_definition WHERE permission_key = 'securities:read')
BEGIN
    INSERT INTO dbo.permission_definition
        (id, permission_key, display_name, permission_group, description, is_assignable, is_system, sort_order, is_active)
    VALUES
        -- Securities
        (NEWID(), 'securities:read',          'View Securities',               'Securities', 'View securities master data',                            1, 0, 10, 1),
        (NEWID(), 'securities:write',         'Create/Update Securities',      'Securities', 'Create and update securities',                           1, 0, 20, 1),
        (NEWID(), 'securities:delete',        'Delete Securities',             'Securities', 'Delete securities',                                      1, 0, 30, 1),
        (NEWID(), 'securities:view-internal', 'View Internal Fields',          'Securities', 'View internal/sensitive fields e.g. ModifiedBy',         1, 0, 40, 1),
        -- Ratings
        (NEWID(), 'ratings:read',             'View Ratings',                  'Ratings',    'View ratings and audit trail',                           1, 0, 50, 1),
        (NEWID(), 'ratings:write',            'Trigger Rating Calculations',   'Ratings',    'Trigger rating calculations',                            1, 0, 60, 1),
        (NEWID(), 'ratings:manage',           'Manage Rating Models',          'Ratings',    'Manage rating models, rules, and scales',                1, 0, 70, 1),
        -- Pricing
        (NEWID(), 'pricing:read',             'View Prices',                   'Pricing',    'View prices and pricing rules',                          1, 0, 80, 1),
        (NEWID(), 'pricing:write',            'Import Prices',                 'Pricing',    'Import prices and run derivations',                      1, 0, 90, 1),
        (NEWID(), 'pricing:manage',           'Manage Pricing Rules',          'Pricing',    'Create, update, and delete pricing rules',               1, 0, 100, 1),
        -- Imports
        (NEWID(), 'imports:read',             'View Imports',                  'Imports',    'View import requests and profiles',                      1, 0, 110, 1),
        (NEWID(), 'imports:run',              'Trigger Imports',               'Imports',    'Trigger imports',                                        1, 0, 120, 1),
        (NEWID(), 'imports:manage',           'Manage Import Profiles',        'Imports',    'Manage import profiles and retry failed imports',        1, 0, 130, 1),
        -- Exports
        (NEWID(), 'exports:run',              'Export Data',                   'Exports',    'Export securities data',                                 1, 0, 140, 1),
        -- Workflows
        (NEWID(), 'workflows:read',           'View Workflows',                'Workflows',  'View workflow instances',                                1, 0, 150, 1),
        (NEWID(), 'workflows:use',            'Submit Workflow Decisions',     'Workflows',  'Submit workflow step decisions',                         1, 0, 160, 1),
        (NEWID(), 'workflows:manage',         'Manage Workflows',              'Workflows',  'Create, cancel, and delete workflow definitions',        1, 0, 170, 1),
        -- Jobs
        (NEWID(), 'jobs:read',                'View Jobs',                     'Jobs',       'View job status and history',                            1, 0, 180, 1),
        (NEWID(), 'jobs:manage',              'Manage Jobs',                   'Jobs',       'Trigger, pause, resume, and schedule jobs',              1, 0, 190, 1),
        -- Audit
        (NEWID(), 'audit:read',               'View Audit Logs',               'Audit',      'View audit logs',                                        1, 0, 200, 1),
        -- Portfolios
        (NEWID(), 'portfolios:read',          'View Portfolios',               'Portfolios', 'View clients, portfolios and positions',                 1, 0, 210, 1),
        (NEWID(), 'portfolios:write',         'Manage Portfolios',             'Portfolios', 'Create and manage clients, portfolios and positions',    1, 0, 220, 1),
        -- Admin
        (NEWID(), 'admin:field-visibility',   'Manage Field Visibility',       'Admin',         'Manage dynamic field visibility rules',                              1, 0, 230, 1),
        (NEWID(), 'admin:ui-resources',       'Manage UI Resources',           'Admin',         'Manage UI resource catalog, visibility rules, and execution rules',  1, 0, 240, 1),
        (NEWID(), 'system:manage',            'Manage System',                 'System',        'Manage plugins and system settings',                                1, 1, 250, 1),
        -- Issuers
        (NEWID(), 'issuers:read',              'View Issuers',                  'Issuers',       'View issuers and their relationships',                              1, 0, 260, 1),
        (NEWID(), 'issuers:write',             'Create/Update Issuers',         'Issuers',       'Create, update, and delete issuers and their relationships',         1, 0, 270, 1),
        -- Administrator (platform-wide admin)
        (NEWID(), 'admin:manage-permissions',  'Manage Permission Definitions', 'Administrator', 'Create, update, and delete permission definitions and rules',      1, 0, 310, 1),
        (NEWID(), 'admin:manage-authorization','Manage Authorization Config',   'Administrator', 'Full access to field visibility and resource authorization config', 1, 0, 320, 1),
        (NEWID(), 'admin:manage-users',        'Manage User Assignments',       'Administrator', 'Assign permissions and roles to users via Keycloak integration',    1, 0, 330, 1),
        (NEWID(), 'admin:super',               'Superuser / Full Admin Access', 'Administrator', 'Unrestricted administrative access across the entire platform',     1, 1, 340, 1);
END
GO

PRINT 'Permission catalog seed data loaded.';
GO

-- ── Issuer permissions (idempotent top-up — added after initial seed) ─────────
IF NOT EXISTS (SELECT 1 FROM dbo.permission_definition WHERE permission_key = 'issuers:read')
BEGIN
    INSERT INTO dbo.permission_definition
        (id, permission_key, display_name, permission_group, description, is_assignable, is_system, sort_order, is_active)
    VALUES
        (NEWID(), 'issuers:read',  'View Issuers',          'Issuers', 'View issuers and their relationships',                              1, 0, 260, 1),
        (NEWID(), 'issuers:write', 'Create/Update Issuers', 'Issuers', 'Create, update, and delete issuers and their relationships',         1, 0, 270, 1);
END
GO
-- â”€â”€ Field Visibility seed (idempotent) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
-- Entities â†’ Fields â†’ Rules (FK-based; replaces old string entity_type/field_name).
-- Mirrors the old [FieldPermission] attribute behaviour for SecurityDto.
-- Add, edit, or remove rows through the admin UI at runtime.
-- â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

IF NOT EXISTS (SELECT 1 FROM dbo.field_visibility_entity WHERE entity_type = 'SecurityDto')
BEGIN
    -- 1. Seed the entity
    DECLARE @fveId UNIQUEIDENTIFIER = NEWID();
    INSERT INTO dbo.field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (@fveId, 'SecurityDto', 'Security', 'Security master DTO fields', 1);

    -- 2. Seed fields for SecurityDto
    INSERT INTO dbo.field_visibility_field
        (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level, default_visibility_state, sort_order, is_active)
    VALUES
        (NEWID(), @fveId, 'IdentifierType',  'Identifier Type',  'string',   'Public',   'VISIBLE', 10, 1),
        (NEWID(), @fveId, 'IdentifierValue', 'Identifier Value', 'string',   'Public',   'VISIBLE', 20, 1),
        (NEWID(), @fveId, 'Name',            'Name',             'string',   'Public',   'VISIBLE', 30, 1),
        (NEWID(), @fveId, 'Type',            'Type',             'string',   'Public',   'VISIBLE', 40, 1),
        (NEWID(), @fveId, 'IsActive',        'Is Active',        'boolean',  'Public',   'VISIBLE', 50, 1),
        (NEWID(), @fveId, 'Description',     'Description',      'string',   'Public',   'VISIBLE', 60, 1),
        (NEWID(), @fveId, 'Issuer',          'Issuer',           'string',   'Public',   'VISIBLE', 70, 1),
        (NEWID(), @fveId, 'Currency',        'Currency',         'string',   'Public',   'VISIBLE', 80, 1),
        (NEWID(), @fveId, 'CreatedAt',       'Created At',       'datetime', 'Public',   'VISIBLE', 90, 1),
        (NEWID(), @fveId, 'UpdatedAt',       'Updated At',       'datetime', 'Public',   'VISIBLE', 100, 1),
        (NEWID(), @fveId, 'Attributes',      'Attributes',       'object',   'Public',   'VISIBLE', 110, 1),
        (NEWID(), @fveId, 'CreditRatings',   'Credit Ratings',   'object',   'Public',   'VISIBLE', 120, 1),
        (NEWID(), @fveId, 'ModifiedBy',      'Modified By',      'string',   'Internal', 'HIDDEN',  130, 1),
        (NEWID(), @fveId, 'ContentHash',     'Content Hash',     'string',   'Internal', 'HIDDEN',  140, 1);

    -- 3. Seed rules using FK to fields
    -- Public fields: securities:read â†’ Full
    INSERT INTO dbo.field_visibility_rule
        (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, (SELECT id FROM dbo.permission_definition WHERE permission_key = 'securities:read'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM   dbo.field_visibility_field f
    WHERE  f.field_visibility_entity_id = @fveId
      AND  f.field_name IN (
           'IdentifierType','IdentifierValue','Name','Type','IsActive',
           'Description','Issuer','Currency','CreatedAt','UpdatedAt','Attributes','CreditRatings');

    -- Internal fields: securities:view-internal â†’ Hidden
    INSERT INTO dbo.field_visibility_rule
        (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, (SELECT id FROM dbo.permission_definition WHERE permission_key = 'securities:view-internal'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM   dbo.field_visibility_field f
    WHERE  f.field_visibility_entity_id = @fveId
      AND  f.field_name IN ('ModifiedBy','ContentHash');
END
GO

-- ── Field Visibility — DerivedRatingDto ────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM dbo.field_visibility_entity WHERE entity_type = 'DerivedRatingDto')
BEGIN
    DECLARE @fveRating UNIQUEIDENTIFIER = NEWID();
    INSERT INTO dbo.field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (@fveRating, 'DerivedRatingDto', 'Derived Rating', 'Derived and composite rating scores for a security', 1);

    INSERT INTO dbo.field_visibility_field
        (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level, default_visibility_state, sort_order, is_active)
    VALUES
        (NEWID(), @fveRating, 'SecurityId',                 'Security ID',                   'guid',     'Public',   'VISIBLE', 10,  1),
        (NEWID(), @fveRating, 'ImpliedRatingScore',         'Implied Rating Score',          'int',      'Public',   'VISIBLE', 20,  1),
        (NEWID(), @fveRating, 'VpmRatingScore',             'VPM Rating Score',              'int',      'Public',   'VISIBLE', 30,  1),
        (NEWID(), @fveRating, 'FundamentalRatingScore',     'Fundamental Rating Score',      'int',      'Public',   'VISIBLE', 40,  1),
        (NEWID(), @fveRating, 'CompositeRatingScore',       'Composite Rating Score',        'int',      'Public',   'VISIBLE', 50,  1),
        (NEWID(), @fveRating, 'CompositeRatingsByAgency',   'Composite Ratings by Agency',   'object',   'Public',   'VISIBLE', 60,  1),
        (NEWID(), @fveRating, 'ImpliedRatingsByAgency',     'Implied Ratings by Agency',     'object',   'Public',   'VISIBLE', 70,  1),
        (NEWID(), @fveRating, 'VpmRatingsByAgency',         'VPM Ratings by Agency',         'object',   'Public',   'VISIBLE', 80,  1),
        (NEWID(), @fveRating, 'FundamentalRatingsByAgency', 'Fundamental Ratings by Agency', 'object',   'Public',   'VISIBLE', 90,  1),
        (NEWID(), @fveRating, 'IsInvestmentGrade',          'Investment Grade',              'boolean',  'Public',   'VISIBLE', 100, 1),
        (NEWID(), @fveRating, 'LastCalculatedUtc',          'Last Calculated',               'datetime', 'Public',   'VISIBLE', 110, 1),
        (NEWID(), @fveRating, 'OutputAgency',               'Output Agency',                 'string',   'Public',   'VISIBLE', 120, 1),
        (NEWID(), @fveRating, 'ImpliedPd',                  'Implied Probability of Default','decimal',  'Internal', 'HIDDEN',  130, 1),
        (NEWID(), @fveRating, 'ModelPd',                    'Model Probability of Default',  'decimal',  'Internal', 'HIDDEN',  140, 1),
        (NEWID(), @fveRating, 'FairPrice',                  'Fair (Model) Price',            'decimal',  'Internal', 'HIDDEN',  150, 1);

    INSERT INTO dbo.field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, (SELECT id FROM dbo.permission_definition WHERE permission_key = 'ratings:read'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM   dbo.field_visibility_field f WHERE f.field_visibility_entity_id = @fveRating AND f.sensitivity_level = 'Public';

    INSERT INTO dbo.field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, (SELECT id FROM dbo.permission_definition WHERE permission_key = 'ratings:write'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM   dbo.field_visibility_field f WHERE f.field_visibility_entity_id = @fveRating AND f.sensitivity_level = 'Internal';
END
GO

-- ── Field Visibility — PricingRuleDto ──────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM dbo.field_visibility_entity WHERE entity_type = 'PricingRuleDto')
BEGIN
    DECLARE @fvePricing UNIQUEIDENTIFIER = NEWID();
    INSERT INTO dbo.field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (@fvePricing, 'PricingRuleDto', 'Pricing Rule', 'Pricing rule definitions, parameters, and derivation formulas', 1);

    INSERT INTO dbo.field_visibility_field
        (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level, default_visibility_state, sort_order, is_active)
    VALUES
        (NEWID(), @fvePricing, 'Id',           'ID',                 'guid',     'Public',   'VISIBLE', 10,  1),
        (NEWID(), @fvePricing, 'RuleName',     'Rule Name',          'string',   'Public',   'VISIBLE', 20,  1),
        (NEWID(), @fvePricing, 'SecurityType', 'Security Type',      'string',   'Public',   'VISIBLE', 30,  1),
        (NEWID(), @fvePricing, 'Source',       'Source',             'string',   'Public',   'VISIBLE', 40,  1),
        (NEWID(), @fvePricing, 'PriceType',    'Price Type',         'string',   'Public',   'VISIBLE', 50,  1),
        (NEWID(), @fvePricing, 'Description',  'Description',        'string',   'Public',   'VISIBLE', 60,  1),
        (NEWID(), @fvePricing, 'IsActive',     'Is Active',          'boolean',  'Public',   'VISIBLE', 70,  1),
        (NEWID(), @fvePricing, 'CreatedAt',    'Created At',         'datetime', 'Public',   'VISIBLE', 80,  1),
        (NEWID(), @fvePricing, 'UpdatedAt',    'Updated At',         'datetime', 'Public',   'VISIBLE', 90,  1),
        (NEWID(), @fvePricing, 'Formula',      'Derivation Formula', 'string',   'Internal', 'HIDDEN',  100, 1);

    INSERT INTO dbo.field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, (SELECT id FROM dbo.permission_definition WHERE permission_key = 'pricing:read'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM   dbo.field_visibility_field f WHERE f.field_visibility_entity_id = @fvePricing AND f.sensitivity_level = 'Public';

    INSERT INTO dbo.field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, (SELECT id FROM dbo.permission_definition WHERE permission_key = 'pricing:write'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM   dbo.field_visibility_field f WHERE f.field_visibility_entity_id = @fvePricing AND f.sensitivity_level = 'Internal';
END
GO

-- ── Field Visibility — ImportRequestDto ────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM dbo.field_visibility_entity WHERE entity_type = 'ImportRequestDto')
BEGIN
    DECLARE @fveImport UNIQUEIDENTIFIER = NEWID();
    INSERT INTO dbo.field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (@fveImport, 'ImportRequestDto', 'Import Request', 'Import job request status, record counts, and error details', 1);

    INSERT INTO dbo.field_visibility_field
        (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level, default_visibility_state, sort_order, is_active)
    VALUES
        (NEWID(), @fveImport, 'Id',               'ID',                'guid',     'Public',   'VISIBLE', 10,  1),
        (NEWID(), @fveImport, 'RequestType',      'Request Type',      'string',   'Public',   'VISIBLE', 20,  1),
        (NEWID(), @fveImport, 'SourceSystem',     'Source System',     'string',   'Public',   'VISIBLE', 30,  1),
        (NEWID(), @fveImport, 'TargetSystem',     'Target System',     'string',   'Public',   'VISIBLE', 40,  1),
        (NEWID(), @fveImport, 'Status',           'Status',            'string',   'Public',   'VISIBLE', 50,  1),
        (NEWID(), @fveImport, 'TotalRecords',     'Total Records',     'int',      'Public',   'VISIBLE', 60,  1),
        (NEWID(), @fveImport, 'ProcessedRecords', 'Processed Records', 'int',      'Public',   'VISIBLE', 70,  1),
        (NEWID(), @fveImport, 'FailedRecords',    'Failed Records',    'int',      'Public',   'VISIBLE', 80,  1),
        (NEWID(), @fveImport, 'CreatedAt',        'Created At',        'datetime', 'Public',   'VISIBLE', 90,  1),
        (NEWID(), @fveImport, 'CompletedAt',      'Completed At',      'datetime', 'Public',   'VISIBLE', 100, 1),
        (NEWID(), @fveImport, 'ErrorMessage',     'Error Message',     'string',   'Internal', 'HIDDEN',  110, 1);

    INSERT INTO dbo.field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, (SELECT id FROM dbo.permission_definition WHERE permission_key = 'imports:read'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM   dbo.field_visibility_field f WHERE f.field_visibility_entity_id = @fveImport AND f.sensitivity_level = 'Public';

    INSERT INTO dbo.field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, (SELECT id FROM dbo.permission_definition WHERE permission_key = 'imports:run'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM   dbo.field_visibility_field f WHERE f.field_visibility_entity_id = @fveImport AND f.sensitivity_level = 'Internal';
END
GO

-- ── Field Visibility — JobHistoryDto ───────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM dbo.field_visibility_entity WHERE entity_type = 'JobHistoryDto')
BEGIN
    DECLARE @fveJob UNIQUEIDENTIFIER = NEWID();
    INSERT INTO dbo.field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (@fveJob, 'JobHistoryDto', 'Job History', 'Background job execution history, timing, and failure details', 1);

    INSERT INTO dbo.field_visibility_field
        (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level, default_visibility_state, sort_order, is_active)
    VALUES
        (NEWID(), @fveJob, 'JobId',            'Job ID',            'string',   'Public',   'VISIBLE', 10, 1),
        (NEWID(), @fveJob, 'JobName',          'Job Name',          'string',   'Public',   'VISIBLE', 20, 1),
        (NEWID(), @fveJob, 'State',            'State',             'string',   'Public',   'VISIBLE', 30, 1),
        (NEWID(), @fveJob, 'EnqueuedAt',       'Enqueued At',       'datetime', 'Public',   'VISIBLE', 40, 1),
        (NEWID(), @fveJob, 'SucceededAt',      'Succeeded At',      'datetime', 'Public',   'VISIBLE', 50, 1),
        (NEWID(), @fveJob, 'ExceptionMessage', 'Exception Message', 'string',   'Internal', 'HIDDEN',  60, 1);

    INSERT INTO dbo.field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, (SELECT id FROM dbo.permission_definition WHERE permission_key = 'jobs:read'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM   dbo.field_visibility_field f WHERE f.field_visibility_entity_id = @fveJob AND f.sensitivity_level = 'Public';
END
GO

-- ── Field Visibility — WorkflowInstanceDto ─────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM dbo.field_visibility_entity WHERE entity_type = 'WorkflowInstanceDto')
BEGIN
    DECLARE @fveWf UNIQUEIDENTIFIER = NEWID();
    INSERT INTO dbo.field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (@fveWf, 'WorkflowInstanceDto', 'Workflow Instance', 'Workflow instance state, steps, and assignment details', 1);

    INSERT INTO dbo.field_visibility_field
        (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level, default_visibility_state, sort_order, is_active)
    VALUES
        (NEWID(), @fveWf, 'Id',              'ID',                 'guid',     'Public',   'VISIBLE', 10,  1),
        (NEWID(), @fveWf, 'WorkflowType',    'Workflow Type',      'string',   'Public',   'VISIBLE', 20,  1),
        (NEWID(), @fveWf, 'Status',          'Status',             'string',   'Public',   'VISIBLE', 30,  1),
        (NEWID(), @fveWf, 'CurrentStep',     'Current Step',       'string',   'Public',   'VISIBLE', 40,  1),
        (NEWID(), @fveWf, 'SecurityId',      'Security ID',        'guid',     'Public',   'VISIBLE', 50,  1),
        (NEWID(), @fveWf, 'InitiatedBy',     'Initiated By',       'string',   'Public',   'VISIBLE', 60,  1),
        (NEWID(), @fveWf, 'CurrentAssignee', 'Current Assignee',   'string',   'Public',   'VISIBLE', 70,  1),
        (NEWID(), @fveWf, 'CreatedAt',       'Created At',         'datetime', 'Public',   'VISIBLE', 80,  1),
        (NEWID(), @fveWf, 'UpdatedAt',       'Updated At',         'datetime', 'Public',   'VISIBLE', 90,  1),
        (NEWID(), @fveWf, 'Notes',           'Notes',              'string',   'Public',   'VISIBLE', 100, 1),
        (NEWID(), @fveWf, 'DefinitionJson',  'Workflow Definition','string',   'Internal', 'HIDDEN',  110, 1),
        (NEWID(), @fveWf, 'StateJson',       'State Snapshot',     'string',   'Internal', 'HIDDEN',  120, 1);

    INSERT INTO dbo.field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, (SELECT id FROM dbo.permission_definition WHERE permission_key = 'workflows:read'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM   dbo.field_visibility_field f WHERE f.field_visibility_entity_id = @fveWf AND f.sensitivity_level = 'Public';

    INSERT INTO dbo.field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, (SELECT id FROM dbo.permission_definition WHERE permission_key = 'workflows:use'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM   dbo.field_visibility_field f WHERE f.field_visibility_entity_id = @fveWf AND f.sensitivity_level = 'Internal';
END
GO

PRINT 'Field Visibility seed data loaded.';

-- ====================================================================
-- Field Groups seed (idempotent)
-- One "All Fields" group per entity; every field added as a member.
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM dbo.field_group WHERE is_current = 1 AND is_deleted = 0)
   AND EXISTS  (SELECT 1 FROM dbo.field_visibility_entity WHERE entity_type = 'SecurityDto')
BEGIN
    INSERT INTO dbo.field_group
        (id, field_visibility_entity_id, group_key, display_name, description, sort_order, created_by)
    SELECT
        NEWID(),
        fve.id,
        LOWER(REPLACE(fve.entity_type, 'Dto', '')) + '-all-fields',
        'All Fields',
        'Default group containing all ' + fve.display_name + ' fields',
        10,
        'seed'
    FROM dbo.field_visibility_entity fve
    WHERE fve.is_current = 1 AND fve.is_deleted = 0;

    PRINT 'Field Groups inserted.';
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.field_group_member WHERE is_current = 1 AND is_deleted = 0)
   AND EXISTS  (SELECT 1 FROM dbo.field_group WHERE is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.field_group_member
        (id, field_group_id, field_visibility_field_id, created_by)
    SELECT NEWID(), fg.id, fvf.id, 'seed'
    FROM dbo.field_visibility_field fvf
    JOIN dbo.field_group fg
      ON fg.field_visibility_entity_id = fvf.field_visibility_entity_id
     AND fg.is_current = 1 AND fg.is_deleted = 0
    WHERE fvf.is_current = 1 AND fvf.is_deleted = 0;

    PRINT 'Field Group Members inserted.';
END
GO

PRINT 'Field Groups seed data loaded.';
GO
GO

-- â”€â”€ App Resource Authorization seed (idempotent) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
-- Groups â†’ Resources â†’ Rules.
-- Keycloak 'securities:read' is the base permission held by all authenticated users.
-- â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

IF NOT EXISTS (SELECT 1 FROM dbo.app_resource WHERE resource_key = 'nav.dashboard')
BEGIN
    -- â”€â”€ IDs â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    DECLARE @rDash      UNIQUEIDENTIFIER = NEWID();
    DECLARE @rSec       UNIQUEIDENTIFIER = NEWID();
    DECLARE @rIssuers   UNIQUEIDENTIFIER = NEWID();
    DECLARE @rWork      UNIQUEIDENTIFIER = NEWID();
    DECLARE @rHist      UNIQUEIDENTIFIER = NEWID();
    DECLARE @rPricing   UNIQUEIDENTIFIER = NEWID();
    DECLARE @rImports   UNIQUEIDENTIFIER = NEWID();
    DECLARE @rJobs      UNIQUEIDENTIFIER = NEWID();

    -- Ratings group + children
    DECLARE @rRatings       UNIQUEIDENTIFIER = NEWID();
    DECLARE @rRatingsConfig UNIQUEIDENTIFIER = NEWID();
    DECLARE @rRatingRules   UNIQUEIDENTIFIER = NEWID();
    DECLARE @rRatingScales  UNIQUEIDENTIFIER = NEWID();

    -- Portfolios group + children
    DECLARE @rPortfolios UNIQUEIDENTIFIER = NEWID();
    DECLARE @rPortfSec   UNIQUEIDENTIFIER = NEWID();
    DECLARE @rPortfList  UNIQUEIDENTIFIER = NEWID();
    DECLARE @rPortfCli   UNIQUEIDENTIFIER = NEWID();

    -- Admin group + sections + children
    DECLARE @rAdmin        UNIQUEIDENTIFIER = NEWID();
    DECLARE @rFvSection    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rArSection    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rPermSection  UNIQUEIDENTIFIER = NEWID();
    DECLARE @rSysSection   UNIQUEIDENTIFIER = NEWID();
    DECLARE @rFvEntities   UNIQUEIDENTIFIER = NEWID();
    DECLARE @rFvFields     UNIQUEIDENTIFIER = NEWID();
    DECLARE @rFvRules      UNIQUEIDENTIFIER = NEWID();
    DECLARE @rFvMatrix     UNIQUEIDENTIFIER = NEWID();
    DECLARE @rFvGroups     UNIQUEIDENTIFIER = NEWID();
    DECLARE @rArResources  UNIQUEIDENTIFIER = NEWID();
    DECLARE @rArRules      UNIQUEIDENTIFIER = NEWID();
    DECLARE @rArGroups     UNIQUEIDENTIFIER = NEWID();
    DECLARE @rArMatrix     UNIQUEIDENTIFIER = NEWID();
    DECLARE @rPermCatalog  UNIQUEIDENTIFIER = NEWID();
    DECLARE @rPermBundles  UNIQUEIDENTIFIER = NEWID();
    DECLARE @rPermTemplates UNIQUEIDENTIFIER = NEWID();
    DECLARE @rPermEntScr   UNIQUEIDENTIFIER = NEWID();
    DECLARE @rWorkflows    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rVendorSrc    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rDeadLetters  UNIQUEIDENTIFIER = NEWID();
    DECLARE @rAuthPreview  UNIQUEIDENTIFIER = NEWID();
    DECLARE @rAuditHist    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rMenuOrder    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtMenuOrder   UNIQUEIDENTIFIER = NEWID();

    -- Routes
    DECLARE @rtDash         UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtSec          UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtIssuers      UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtWork         UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtHist         UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtRatings      UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtRatingCalc   UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtPricing      UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtPricingRules UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtImports      UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtImportNew    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtImportProfs  UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtJobsList     UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtJobDetail    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtPortfolios      UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtPortfClients    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtPortfPositions  UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdmin          UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminFvEntities  UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminFvFields    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminFvRules     UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminFvMatrix    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminFvGroups    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminArResources UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminArRules     UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminArGroups    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminArMatrix    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminPermCatalog   UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminPermBundles   UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminPermTemplates UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminPermEntScr    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminAuthPreview   UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminAuditHistory  UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminDeadLetters   UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminWorkflows     UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminVendorSrc     UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminRatingRules   UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtAdminRatingScales  UNIQUEIDENTIFIER = NEWID();

    -- Actions
    DECLARE @actCreate        UNIQUEIDENTIFIER = NEWID();
    DECLARE @actEdit          UNIQUEIDENTIFIER = NEWID();
    DECLARE @actDelete        UNIQUEIDENTIFIER = NEWID();
    DECLARE @actExport        UNIQUEIDENTIFIER = NEWID();
    DECLARE @actRatingTrigger UNIQUEIDENTIFIER = NEWID();
    DECLARE @actPricingImport UNIQUEIDENTIFIER = NEWID();
    DECLARE @actImportRun     UNIQUEIDENTIFIER = NEWID();
    DECLARE @actWfSubmit      UNIQUEIDENTIFIER = NEWID();

    -- â”€â”€ Top-level flat MENU_ITEMs (no parent) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    INSERT INTO dbo.app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (@rDash,     'MENU_ITEM', 'nav.dashboard',  'Dashboard',  'dashboard',       '/dashboard',  NULL, 10,  'VISIBLE', 'ALLOW', 0, 1),
        (@rSec,      'MENU_ITEM', 'nav.securities', 'Securities', 'security',        '/securities', NULL, 20,  'VISIBLE', 'ALLOW', 0, 1),
        (@rIssuers,  'MENU_ITEM', 'nav.issuers',    'Issuers',    'account_balance', '/issuers',    NULL, 30,  'HIDDEN',  'DENY',  0, 1),
        (@rPricing,  'MENU_ITEM', 'nav.pricing',    'Pricing',    'attach_money',    '/pricing',    NULL, 50,  'HIDDEN',  'DENY',  0, 1),
        (@rImports,  'MENU_ITEM', 'nav.imports',    'Imports',    'upload_file',     '/imports',    NULL, 60,  'HIDDEN',  'DENY',  0, 1),
        (@rJobs,     'MENU_ITEM', 'nav.jobs',       'Jobs',       'schedule',        '/jobs',       NULL, 70,  'HIDDEN',  'DENY',  0, 1),
        (@rWork,     'MENU_ITEM', 'nav.workflows',  'Workflows',  'account_tree',    '/workflows',  NULL, 80,  'HIDDEN',  'DENY',  0, 1),
        (@rHist,     'MENU_ITEM', 'nav.history',    'History',    'history',         '/history',    NULL, 90,  'VISIBLE', 'ALLOW', 0, 1);

    -- â”€â”€ Ratings MENU_GROUP (sort_order=40, between Issuers and Pricing) â”€â”€
    INSERT INTO dbo.app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (@rRatings, 'MENU_GROUP', 'nav.ratings', 'Ratings', 'star_rate', NULL, NULL, 40, 'VISIBLE', 'ALLOW', 0, 1);

    -- Ratings section
    INSERT INTO dbo.app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (@rRatingsConfig, 'SECTION', 'nav.ratings.config', 'Configuration', NULL, NULL, @rRatings, 10, 'VISIBLE', 'ALLOW', 0, 1);

    -- Ratings leaf children
    INSERT INTO dbo.app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (@rRatingRules,  'MENU_ITEM', 'nav.ratings.rules',  'Derivation Rules', NULL, '/ratings/rules',  @rRatingsConfig, 10, 'VISIBLE', 'ALLOW', 0, 1),
        (@rRatingScales, 'MENU_ITEM', 'nav.ratings.scales', 'Rating Scales',    NULL, '/ratings/scales', @rRatingsConfig, 20, 'VISIBLE', 'ALLOW', 0, 1);

    -- â”€â”€ Portfolios MENU_GROUP (sort_order=45) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    INSERT INTO dbo.app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (@rPortfolios, 'MENU_GROUP', 'nav.portfolios', 'Portfolios', 'account_balance_wallet', NULL, NULL, 45, 'HIDDEN', 'DENY', 0, 1);

    INSERT INTO dbo.app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (@rPortfSec, 'SECTION', 'nav.portfolios.main', 'Portfolios', NULL, NULL, @rPortfolios, 10, 'HIDDEN', 'DENY', 0, 1);

    INSERT INTO dbo.app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (@rPortfList, 'MENU_ITEM', 'nav.portfolios.list',    'Portfolios', NULL, '/portfolios',         @rPortfSec, 10, 'HIDDEN', 'DENY', 0, 1),
        (@rPortfCli,  'MENU_ITEM', 'nav.portfolios.clients', 'Clients',    NULL, '/portfolios/clients', @rPortfSec, 20, 'HIDDEN', 'DENY', 0, 1);

    -- â”€â”€ Admin MENU_GROUP (sort_order=200, hidden â€” shown via topbar gear) â”€
    INSERT INTO dbo.app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (@rAdmin, 'MENU_GROUP', 'nav.admin', 'Admin', 'admin_panel_settings', NULL, NULL, 200, 'HIDDEN', 'DENY', 1, 1);

    -- Admin sections
    INSERT INTO dbo.app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (@rFvSection,   'SECTION', 'nav.admin.fv',     'Field Visibility', NULL, NULL, @rAdmin, 10, 'HIDDEN', 'DENY', 1, 1),
        (@rArSection,   'SECTION', 'nav.admin.ar',     'App Resources',    NULL, NULL, @rAdmin, 20, 'HIDDEN', 'DENY', 1, 1),
        (@rPermSection, 'SECTION', 'nav.admin.perm',   'Permissions',      NULL, NULL, @rAdmin, 30, 'HIDDEN', 'DENY', 1, 1),
        (@rSysSection,  'SECTION', 'nav.admin.system', 'System',           NULL, NULL, @rAdmin, 40, 'HIDDEN', 'DENY', 1, 1);

    -- Admin leaf children
    INSERT INTO dbo.app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (@rFvEntities,    'MENU_ITEM', 'nav.admin.fv.entities',          'Entities',            NULL, '/admin/fv/entities',                 @rFvSection,   10, 'HIDDEN', 'DENY', 1, 1),
        (@rFvFields,      'MENU_ITEM', 'nav.admin.fv.fields',             'Fields',              NULL, '/admin/fv/fields',                   @rFvSection,   20, 'HIDDEN', 'DENY', 1, 1),
        (@rFvRules,       'MENU_ITEM', 'nav.admin.fv.rules',              'Field Rules',         NULL, '/admin/fv/rules',                    @rFvSection,   30, 'HIDDEN', 'DENY', 1, 1),
        (@rFvMatrix,      'MENU_ITEM', 'nav.admin.fv.matrix',             'FV Matrix',           NULL, '/admin/fv/matrix',                   @rFvSection,   40, 'HIDDEN', 'DENY', 1, 1),
        (@rFvGroups,      'MENU_ITEM', 'nav.admin.fv.groups',             'Field Groups',        NULL, '/admin/fv/groups',                   @rFvSection,   50, 'HIDDEN', 'DENY', 1, 1),
        (@rArResources,   'MENU_ITEM', 'nav.admin.ar.resources',          'Resources',           NULL, '/admin/ar/resources',                @rArSection,   10, 'HIDDEN', 'DENY', 1, 1),
        (@rArRules,       'MENU_ITEM', 'nav.admin.ar.rules',              'Resource Rules',      NULL, '/admin/ar/rules',                    @rArSection,   20, 'HIDDEN', 'DENY', 1, 1),
        (@rArGroups,      'MENU_ITEM', 'nav.admin.ar.groups',             'Resource Groups',     NULL, '/admin/ar/groups',                   @rArSection,   30, 'HIDDEN', 'DENY', 1, 1),
        (@rArMatrix,      'MENU_ITEM', 'nav.admin.ar.matrix',             'AR Matrix',           NULL, '/admin/ar/matrix',                   @rArSection,   40, 'HIDDEN', 'DENY', 1, 1),
        (@rPermCatalog,   'MENU_ITEM', 'nav.admin.perm.catalog',          'Permission Catalog',  NULL, '/admin/permissions/catalog',         @rPermSection, 10, 'HIDDEN', 'DENY', 1, 1),
        (@rPermBundles,   'MENU_ITEM', 'nav.admin.perm.bundles',          'Bundles',             NULL, '/admin/permissions/bundles',         @rPermSection, 20, 'HIDDEN', 'DENY', 1, 1),
        (@rPermTemplates, 'MENU_ITEM', 'nav.admin.perm.templates',        'Policy Templates',    NULL, '/admin/permissions/templates',       @rPermSection, 30, 'HIDDEN', 'DENY', 1, 1),
        (@rPermEntScr,    'MENU_ITEM', 'nav.admin.perm.entity-screens',   'Entity Screens',      NULL, '/admin/permissions/entity-screens',  @rPermSection, 40, 'HIDDEN', 'DENY', 1, 1),
        (@rWorkflows,     'MENU_ITEM', 'nav.admin.workflows',             'Workflow Definitions',NULL, '/admin/workflows',                   @rSysSection,  10, 'HIDDEN', 'DENY', 1, 1),
        (@rVendorSrc,     'MENU_ITEM', 'nav.admin.vendor-sources',        'Vendor Sources',      NULL, '/admin/vendor-sources',              @rSysSection,  20, 'HIDDEN', 'DENY', 1, 1),
        (@rDeadLetters,   'MENU_ITEM', 'nav.admin.dead-letters',          'Dead Letters',        NULL, '/admin/dead-letters',                @rSysSection,  30, 'HIDDEN', 'DENY', 1, 1),
        (@rAuthPreview,   'MENU_ITEM', 'nav.admin.auth-preview',          'Auth Preview',        NULL, '/admin/auth-preview',                @rAdmin,       80, 'HIDDEN', 'DENY', 1, 1),
        (@rAuditHist,     'MENU_ITEM', 'nav.admin.audit-history',         'Audit History',       NULL, '/admin/audit-history',               @rAdmin,       90, 'HIDDEN', 'DENY', 1, 1),
        (@rMenuOrder,     'MENU_ITEM', 'nav.admin.menu-order',            'Menu Order',          NULL, '/admin/nav/menu-order',              @rAdmin,       70, 'HIDDEN', 'DENY', 1, 1);

    INSERT INTO dbo.app_resource
        (id, resource_type, resource_key, display_name, route_path, parent_app_resource_id, sort_order, default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (@rtMenuOrder, 'ROUTE', 'route./admin/nav/menu-order', 'Menu Order Route', '/admin/nav/menu-order', NULL, 71, 'HIDDEN', 'DENY', 1, 1);

    -- â”€â”€ Routes (parented to NULL â€” no nav group needed) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    INSERT INTO dbo.app_resource
        (id, resource_type, resource_key, display_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (@rtDash,         'ROUTE', 'route./dashboard',               'Dashboard Route',           '/dashboard',               NULL, 10,  'VISIBLE', 'ALLOW', 0, 1),
        (@rtSec,          'ROUTE', 'route./securities',              'Securities Route',          '/securities',              NULL, 20,  'VISIBLE', 'ALLOW', 0, 1),
        (@rtIssuers,      'ROUTE', 'route./issuers',                 'Issuers Route',             '/issuers',                 NULL, 30,  'HIDDEN',  'DENY',  0, 1),
        (@rtWork,         'ROUTE', 'route./workflows',               'Workflows Route',           '/workflows',               NULL, 80,  'HIDDEN',  'DENY',  0, 1),
        (@rtHist,         'ROUTE', 'route./history',                 'History Route',             '/history',                 NULL, 90,  'VISIBLE', 'ALLOW', 0, 1),
        (@rtRatings,      'ROUTE', 'route./ratings',                 'Ratings Route',             '/ratings',                 NULL, 40,  'HIDDEN',  'DENY',  0, 1),
        (@rtRatingCalc,   'ROUTE', 'route./ratings/new-calculation', 'Trigger Calculation Route', '/ratings/new-calculation', NULL, 41,  'HIDDEN',  'DENY',  1, 1),
        (@rtPricing,      'ROUTE', 'route./pricing',                 'Pricing Route',             '/pricing',                 NULL, 50,  'HIDDEN',  'DENY',  0, 1),
        (@rtPricingRules, 'ROUTE', 'route./pricing/rules',           'Pricing Rules Route',       '/pricing/rules',           NULL, 51,  'HIDDEN',  'DENY',  0, 1),
        (@rtImports,      'ROUTE', 'route./imports',                 'Imports Route',             '/imports',                 NULL, 60,  'HIDDEN',  'DENY',  0, 1),
        (@rtImportNew,    'ROUTE', 'route./imports/new',             'Trigger Import Route',      '/imports/new',             NULL, 61,  'HIDDEN',  'DENY',  1, 1),
        (@rtImportProfs,  'ROUTE', 'route./imports/profiles',        'Import Profiles Route',     '/imports/profiles',        NULL, 62,  'HIDDEN',  'DENY',  0, 1),
        (@rtJobsList,     'ROUTE', 'route./jobs',                    'Jobs Route',                '/jobs',                    NULL, 70,  'HIDDEN',  'DENY',  0, 1),
        (@rtJobDetail,    'ROUTE', 'route./jobs/detail',             'Job Detail Route',          '/jobs/:id',                NULL, 71,  'HIDDEN',  'DENY',  0, 1),
        (@rtPortfolios,     'ROUTE', 'route./portfolios',           'Portfolios Route',          '/portfolios',               NULL, 45,  'HIDDEN',  'DENY',  0, 1),
        (@rtPortfClients,   'ROUTE', 'route./portfolios/clients',   'Clients Route',             '/portfolios/clients',       NULL, 46,  'HIDDEN',  'DENY',  0, 1),
        (@rtPortfPositions, 'ROUTE', 'route./portfolios/positions', 'Positions Route',           '/portfolios/:id/positions', NULL, 47,  'HIDDEN',  'DENY',  0, 1),
        (@rtAdmin,              'ROUTE', 'route./admin',                       'Admin',                      '/admin',                          NULL, 200, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminFvEntities,    'ROUTE', 'route./admin/fv/entities',           'Admin FV Entities',          '/admin/fv/entities',              NULL, 201, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminFvFields,      'ROUTE', 'route./admin/fv/fields',             'Admin FV Fields',            '/admin/fv/fields',                NULL, 202, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminFvRules,       'ROUTE', 'route./admin/fv/rules',              'Admin FV Rules',             '/admin/fv/rules',                 NULL, 203, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminFvMatrix,      'ROUTE', 'route./admin/fv/matrix',             'Admin FV Matrix',            '/admin/fv/matrix',                NULL, 204, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminFvGroups,      'ROUTE', 'route./admin/fv/groups',             'Admin FV Groups',            '/admin/fv/groups',                NULL, 205, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminArResources,   'ROUTE', 'route./admin/ar/resources',          'Admin AR Resources',         '/admin/ar/resources',             NULL, 210, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminArRules,       'ROUTE', 'route./admin/ar/rules',              'Admin AR Rules',             '/admin/ar/rules',                 NULL, 211, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminArGroups,      'ROUTE', 'route./admin/ar/groups',             'Admin AR Groups',            '/admin/ar/groups',                NULL, 212, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminArMatrix,      'ROUTE', 'route./admin/ar/matrix',             'Admin AR Matrix',            '/admin/ar/matrix',                NULL, 213, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminPermCatalog,   'ROUTE', 'route./admin/permissions/catalog',   'Admin Perm Catalog',         '/admin/permissions/catalog',      NULL, 220, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminPermBundles,   'ROUTE', 'route./admin/permissions/bundles',   'Admin Perm Bundles',         '/admin/permissions/bundles',      NULL, 221, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminPermTemplates, 'ROUTE', 'route./admin/permissions/templates', 'Admin Perm Templates',       '/admin/permissions/templates',    NULL, 222, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminPermEntScr,    'ROUTE', 'route./admin/permissions/entity-screens','Admin Perm Entity Screens','/admin/permissions/entity-screens',NULL,223,'HIDDEN','DENY',1, 1),
        (@rtAdminAuthPreview,   'ROUTE', 'route./admin/auth-preview',          'Admin Auth Preview',         '/admin/auth-preview',             NULL, 230, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminAuditHistory,  'ROUTE', 'route./admin/audit-history',         'Admin Audit History',        '/admin/audit-history',            NULL, 231, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminDeadLetters,   'ROUTE', 'route./admin/dead-letters',          'Admin Dead Letters',         '/admin/dead-letters',             NULL, 232, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminWorkflows,     'ROUTE', 'route./admin/workflows',             'Admin Workflow Definitions', '/admin/workflows',                NULL, 233, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminVendorSrc,     'ROUTE', 'route./admin/vendor-sources',        'Admin Vendor Sources',       '/admin/vendor-sources',           NULL, 234, 'HIDDEN', 'DENY', 1, 1),
        (@rtAdminRatingRules,   'ROUTE', 'route./ratings/rules',         'Rating Rules',         '/ratings/rules',            NULL, 240, 'HIDDEN', 'DENY', 0, 1),
        (@rtAdminRatingScales,  'ROUTE', 'route./ratings/scales',        'Rating Scales',        '/ratings/scales',           NULL, 241, 'HIDDEN', 'DENY', 0, 1);

    -- â”€â”€ Actions â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    INSERT INTO dbo.app_resource
        (id, resource_type, resource_key, display_name,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (@actCreate,        'ACTION', 'security.create',       'Create Security',            NULL, 110, 'HIDDEN', 'DENY', 1, 1),
        (@actEdit,          'ACTION', 'security.edit',         'Edit Security',              NULL, 120, 'HIDDEN', 'DENY', 1, 1),
        (@actDelete,        'ACTION', 'security.delete',       'Delete Security',            NULL, 130, 'HIDDEN', 'DENY', 1, 1),
        (@actExport,        'ACTION', 'security.export',       'Export Securities',          NULL, 140, 'HIDDEN', 'DENY', 1, 1),
        (@actRatingTrigger, 'ACTION', 'ratings.trigger',       'Trigger Rating Calculation', NULL, 260, 'HIDDEN', 'DENY', 1, 1),
        (@actPricingImport, 'ACTION', 'pricing.import-prices', 'Import / Re-derive Prices',  NULL, 272, 'HIDDEN', 'DENY', 1, 1),
        (@actImportRun,     'ACTION', 'imports.run',           'Run Import',                 NULL, 283, 'HIDDEN', 'DENY', 1, 1),
        (@actWfSubmit,      'ACTION', 'workflows.submit',      'Submit Workflow Decision',   NULL, 310, 'HIDDEN', 'DENY', 0, 1);

    -- â”€â”€ App Resource Rules â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    INSERT INTO dbo.app_resource_rule
        (id, app_resource_id, permission_definition_id, visibility_state, execution_state, priority, created_by)
    SELECT NEWID(), v.rid, pd.id, v.vs, v.es, v.pri, 'seed'
    FROM (VALUES
        -- Public (securities:read = base permission for all authenticated users)
        (@rDash,            'securities:read',            'VISIBLE', 'ALLOW', 100),
        (@rSec,             'securities:read',            'VISIBLE', 'ALLOW', 100),
        (@rHist,            'securities:read',            'VISIBLE', 'ALLOW', 100),
        (@rtDash,           'securities:read',            'VISIBLE', 'ALLOW', 100),
        (@rtSec,            'securities:read',            'VISIBLE', 'ALLOW', 100),
        (@rtHist,           'securities:read',            'VISIBLE', 'ALLOW', 100),
        -- Issuers
        (@rIssuers,         'issuers:read',               'VISIBLE', 'ALLOW', 100),
        (@rtIssuers,        'issuers:read',               'VISIBLE', 'ALLOW', 100),
        -- Workflows
        (@rWork,            'workflows:read',             'VISIBLE', 'ALLOW', 100),
        (@rtWork,           'workflows:read',             'VISIBLE', 'ALLOW', 100),
        -- Ratings (ratings:read sees the group + children)
        (@rRatings,         'ratings:read',               'VISIBLE', 'ALLOW', 100),
        (@rRatingsConfig,   'ratings:read',               'VISIBLE', 'ALLOW', 100),
        (@rRatingRules,     'ratings:read',               'VISIBLE', 'ALLOW', 100),
        (@rRatingScales,    'ratings:read',               'VISIBLE', 'ALLOW', 100),
        (@rtRatings,        'ratings:read',               'VISIBLE', 'ALLOW', 100),
        (@rtRatingCalc,     'ratings:write',              'VISIBLE', 'ALLOW', 100),
        (@actRatingTrigger, 'ratings:write',              'VISIBLE', 'ALLOW', 100),
        -- Pricing
        (@rPricing,         'pricing:read',               'VISIBLE', 'ALLOW', 100),
        (@rtPricing,        'pricing:read',               'VISIBLE', 'ALLOW', 100),
        (@rtPricingRules,   'pricing:read',               'VISIBLE', 'ALLOW', 100),
        (@actPricingImport, 'pricing:write',              'VISIBLE', 'ALLOW', 100),
        -- Imports
        (@rImports,         'imports:read',               'VISIBLE', 'ALLOW', 100),
        (@rtImports,        'imports:read',               'VISIBLE', 'ALLOW', 100),
        (@rtImportProfs,    'imports:read',               'VISIBLE', 'ALLOW', 100),
        (@rtImportNew,      'imports:run',                'VISIBLE', 'ALLOW', 100),
        (@actImportRun,     'imports:run',                'VISIBLE', 'ALLOW', 100),
        -- Workflows:use
        (@actWfSubmit,      'workflows:use',              'VISIBLE', 'ALLOW', 100),
        -- Jobs
        (@rJobs,            'jobs:read',                  'VISIBLE', 'ALLOW', 100),
        (@rtJobsList,       'jobs:read',                  'VISIBLE', 'ALLOW', 100),
        (@rtJobDetail,      'jobs:read',                  'VISIBLE', 'ALLOW', 100),
        -- Portfolios
        (@rPortfolios,      'portfolios:read',            'VISIBLE', 'ALLOW', 100),
        (@rPortfList,       'portfolios:read',            'VISIBLE', 'ALLOW', 100),
        (@rPortfCli,        'portfolios:read',            'VISIBLE', 'ALLOW', 100),
        (@rtPortfolios,     'portfolios:read',            'VISIBLE', 'ALLOW', 100),
        (@rtPortfClients,   'portfolios:read',            'VISIBLE', 'ALLOW', 100),
        (@rtPortfPositions, 'portfolios:read',            'VISIBLE', 'ALLOW', 100),
        (@rtPortfolios,     'admin:super',                'VISIBLE', 'ALLOW', 100),
        (@rtPortfClients,   'admin:super',                'VISIBLE', 'ALLOW', 100),
        (@rtPortfPositions, 'admin:super',                'VISIBLE', 'ALLOW', 100),
        (@rPortfolios,      'admin:super',                'VISIBLE', 'ALLOW', 100),
        (@rPortfList,       'admin:super',                'VISIBLE', 'ALLOW', 100),
        (@rPortfCli,        'admin:super',                'VISIBLE', 'ALLOW', 100),
        -- Security actions
        (@actCreate,        'securities:write',           'VISIBLE', 'ALLOW', 100),
        (@actEdit,          'securities:write',           'VISIBLE', 'ALLOW', 100),
        (@actDelete,        'securities:delete',          'VISIBLE', 'ALLOW', 100),
        (@actExport,        'exports:run',                'VISIBLE', 'ALLOW', 100),
        -- Admin (admin:manage-authorization sees the full admin group)
        (@rAdmin,           'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        (@rFvEntities,      'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        (@rFvFields,        'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        (@rFvRules,         'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        (@rArResources,     'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        (@rArRules,         'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        (@rPermCatalog,     'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
        (@rAuthPreview,     'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        (@rAuditHist,       'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        (@rMenuOrder,       'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        (@rtMenuOrder,      'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        -- Admin ROUTE resources — all gated on admin:manage-authorization
        (@rtAdmin,              'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        (@rtAdminFvEntities,    'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        (@rtAdminFvFields,      'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        (@rtAdminFvRules,       'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        (@rtAdminFvMatrix,      'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        (@rtAdminFvGroups,      'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        (@rtAdminArResources,   'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        (@rtAdminArRules,       'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        (@rtAdminArGroups,      'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        (@rtAdminArMatrix,      'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        (@rtAdminPermCatalog,   'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
        (@rtAdminPermBundles,   'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
        (@rtAdminPermTemplates, 'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
        (@rtAdminPermEntScr,    'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
        (@rtAdminAuthPreview,   'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        (@rtAdminAuditHistory,  'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        (@rtAdminDeadLetters,   'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        (@rtAdminWorkflows,     'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        (@rtAdminVendorSrc,     'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        (@rtAdminRatingRules,   'ratings:manage',             'VISIBLE', 'ALLOW', 100),
        (@rtAdminRatingScales,  'ratings:manage',             'VISIBLE', 'ALLOW', 100),
        (@rtAdminRatingRules,   'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        (@rtAdminRatingScales,  'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        -- Sections need their own rules so the nav handler includes them
        (@rFvSection,       'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        (@rFvSection,       'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        (@rArSection,       'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        (@rArSection,       'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        (@rPermSection,     'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
        (@rPermSection,     'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        (@rPortfSec,        'portfolios:read',            'VISIBLE', 'ALLOW', 100),
        (@rPortfSec,        'admin:super',                'VISIBLE', 'ALLOW', 100)
    ) AS v(rid, pkey, vs, es, pri)
    JOIN dbo.permission_definition pd ON pd.permission_key = v.pkey;

    PRINT 'App Resource Authorization seed data loaded.';
END
ELSE
    PRINT 'App Resource Authorization seed data already loaded.';
GO

-- Idempotent catch-up: insert rules using resource_key lookups.
-- Runs independently so a partial-insert scenario is recovered.
IF NOT EXISTS (SELECT 1 FROM dbo.app_resource_rule WHERE created_by = 'seed')
    AND EXISTS  (SELECT 1 FROM dbo.app_resource WHERE resource_key = 'nav.dashboard')
BEGIN
    INSERT INTO dbo.app_resource_rule
        (id, app_resource_id, permission_definition_id, visibility_state, execution_state, priority, created_by)
    SELECT NEWID(), ar.id, pd.id, v.vs, v.es, v.pri, 'seed'
    FROM (VALUES
        ('nav.dashboard',                  'securities:read',            'VISIBLE', 'ALLOW', 100),
        ('nav.securities',                 'securities:read',            'VISIBLE', 'ALLOW', 100),
        ('nav.history',                    'securities:read',            'VISIBLE', 'ALLOW', 100),
        ('route./dashboard',               'securities:read',            'VISIBLE', 'ALLOW', 100),
        ('route./securities',              'securities:read',            'VISIBLE', 'ALLOW', 100),
        ('route./history',                 'securities:read',            'VISIBLE', 'ALLOW', 100),
        ('nav.issuers',                    'issuers:read',               'VISIBLE', 'ALLOW', 100),
        ('route./issuers',                 'issuers:read',               'VISIBLE', 'ALLOW', 100),
        ('nav.workflows',                  'workflows:read',             'VISIBLE', 'ALLOW', 100),
        ('route./workflows',               'workflows:read',             'VISIBLE', 'ALLOW', 100),
        ('nav.ratings',                    'ratings:read',               'VISIBLE', 'ALLOW', 100),
        ('nav.ratings.config',             'ratings:read',               'VISIBLE', 'ALLOW', 100),
        ('nav.ratings.rules',              'ratings:read',               'VISIBLE', 'ALLOW', 100),
        ('nav.ratings.scales',             'ratings:read',               'VISIBLE', 'ALLOW', 100),
        ('route./ratings',                 'ratings:read',               'VISIBLE', 'ALLOW', 100),
        ('route./ratings/new-calculation', 'ratings:write',              'VISIBLE', 'ALLOW', 100),
        ('ratings.trigger',                'ratings:write',              'VISIBLE', 'ALLOW', 100),
        ('nav.pricing',                    'pricing:read',               'VISIBLE', 'ALLOW', 100),
        ('route./pricing',                 'pricing:read',               'VISIBLE', 'ALLOW', 100),
        ('route./pricing/rules',           'pricing:read',               'VISIBLE', 'ALLOW', 100),
        ('pricing.import-prices',          'pricing:write',              'VISIBLE', 'ALLOW', 100),
        ('nav.imports',                    'imports:read',               'VISIBLE', 'ALLOW', 100),
        ('route./imports',                 'imports:read',               'VISIBLE', 'ALLOW', 100),
        ('route./imports/profiles',        'imports:read',               'VISIBLE', 'ALLOW', 100),
        ('route./imports/new',             'imports:run',                'VISIBLE', 'ALLOW', 100),
        ('imports.run',                    'imports:run',                'VISIBLE', 'ALLOW', 100),
        ('workflows.submit',               'workflows:use',              'VISIBLE', 'ALLOW', 100),
        ('nav.jobs',                       'jobs:read',                  'VISIBLE', 'ALLOW', 100),
        ('route./jobs',                    'jobs:read',                  'VISIBLE', 'ALLOW', 100),
        ('route./jobs/detail',             'jobs:read',                  'VISIBLE', 'ALLOW', 100),
        ('route./portfolios',              'portfolios:read',            'VISIBLE', 'ALLOW', 100),
        ('route./portfolios/clients',      'portfolios:read',            'VISIBLE', 'ALLOW', 100),
        ('route./portfolios/positions',    'portfolios:read',            'VISIBLE', 'ALLOW', 100),
        ('route./portfolios',              'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./portfolios/clients',      'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./portfolios/positions',    'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.portfolios',                 'portfolios:read',            'VISIBLE', 'ALLOW', 100),
        ('nav.portfolios.list',            'portfolios:read',            'VISIBLE', 'ALLOW', 100),
        ('nav.portfolios.clients',         'portfolios:read',            'VISIBLE', 'ALLOW', 100),
        ('nav.portfolios',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.portfolios.list',            'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.portfolios.clients',         'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('security.create',                'securities:write',           'VISIBLE', 'ALLOW', 100),
        ('security.edit',                  'securities:write',           'VISIBLE', 'ALLOW', 100),
        ('security.delete',                'securities:delete',          'VISIBLE', 'ALLOW', 100),
        ('security.export',                'exports:run',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin',                      'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('nav.admin.fv.entities',          'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        ('nav.admin.fv.fields',            'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        ('nav.admin.fv.rules',              'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        ('nav.admin.fv.matrix',             'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        ('nav.admin.fv.groups',             'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        ('nav.admin.ar.resources',          'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        ('nav.admin.ar.rules',              'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        ('nav.admin.ar.groups',             'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        ('nav.admin.ar.matrix',             'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        ('nav.admin.perm.catalog',          'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
        ('nav.admin.perm.bundles',          'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
        ('nav.admin.perm.templates',        'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
        ('nav.admin.perm.entity-screens',   'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
        ('nav.admin.workflows',             'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('nav.admin.vendor-sources',        'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('nav.admin.dead-letters',          'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('nav.admin.auth-preview',          'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('nav.admin.audit-history',        'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('nav.admin.menu-order',           'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('route./admin/nav/menu-order',    'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('route./admin',                              'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('route./admin/fv/entities',                  'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        ('route./admin/fv/fields',                    'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        ('route./admin/fv/rules',                     'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        ('route./admin/fv/matrix',                    'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        ('route./admin/fv/groups',                    'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        ('route./admin/ar/resources',                 'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        ('route./admin/ar/rules',                     'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        ('route./admin/ar/groups',                    'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        ('route./admin/ar/matrix',                    'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        ('route./admin/permissions/catalog',          'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
        ('route./admin/permissions/bundles',          'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
        ('route./admin/permissions/templates',        'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
        ('route./admin/permissions/entity-screens',   'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
        ('route./admin/auth-preview',                 'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('route./admin/audit-history',                'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('route./admin/dead-letters',                 'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('route./admin/workflows',                    'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('route./admin/vendor-sources',               'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('route./ratings/rules',                'ratings:manage',             'VISIBLE', 'ALLOW', 100),
        ('route./ratings/scales',               'ratings:manage',             'VISIBLE', 'ALLOW', 100),
        ('route./ratings/rules',                'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('route./ratings/scales',               'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        -- Section-level rules (handler filters sections before their children)
        ('nav.admin.fv',                   'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
        ('nav.admin.fv',                   'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('nav.admin.ar',                   'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
        ('nav.admin.ar',                   'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('nav.admin.perm',                 'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
        ('nav.admin.perm',                 'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('nav.admin.system',               'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
        ('nav.portfolios.main',            'portfolios:read',            'VISIBLE', 'ALLOW', 100),
        ('nav.portfolios.main',            'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.ratings.config',             'ratings:read',               'VISIBLE', 'ALLOW', 100),
        -- Admin resources also visible to admin:super (so admin@securityapp.local sees everything)
        ('group.admin',                            'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin',                              'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.fv',                           'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.fv.entities',                  'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.fv.fields',                    'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.fv.rules',                     'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.fv.matrix',                    'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.fv.groups',                    'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.ar',                           'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.ar.resources',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.ar.rules',                     'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.ar.groups',                    'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.ar.matrix',                    'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.perm',                         'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.perm.catalog',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.perm.bundles',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.perm.templates',               'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.perm.entity-screens',          'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.system',                       'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.workflows',                    'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.vendor-sources',               'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.dead-letters',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.auth-preview',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.audit-history',                'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('nav.admin.menu-order',                   'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/nav/menu-order',            'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin',                           'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/fv/entities',               'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/fv/fields',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/fv/rules',                  'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/fv/matrix',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/fv/groups',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/ar/resources',              'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/ar/rules',                  'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/ar/groups',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/ar/matrix',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/permissions/catalog',       'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/permissions/bundles',       'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/permissions/templates',     'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/permissions/entity-screens','admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/auth-preview',              'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/audit-history',             'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/dead-letters',              'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/workflows',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
        ('route./admin/vendor-sources',            'admin:super',                'VISIBLE', 'ALLOW', 100)
    ) AS v(rkey, pkey, vs, es, pri)
    JOIN dbo.app_resource       ar ON ar.resource_key    = v.rkey
    JOIN dbo.permission_definition pd ON pd.permission_key = v.pkey;

    PRINT 'App Resource Rules patched (idempotent catch-up).';
END
GO

-- ====================================================================
-- App Resource Groups (idempotent)
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM dbo.app_resource_group WHERE group_key = 'nav-main' AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.app_resource_group
        (id, group_key, display_name, description, icon_name, sort_order, created_by)
    VALUES
        (NEWID(), 'nav-main',         'Main Navigation',   'Top-level navigation visible to all users',         'menu',                  10, 'seed'),
        (NEWID(), 'nav-admin',        'Admin Navigation',  'Navigation items within the administration area',   'admin_panel_settings',  20, 'seed'),
        (NEWID(), 'routes-feature',   'Feature Routes',    'User-facing application page routes',               'route',                 30, 'seed'),
        (NEWID(), 'routes-admin',     'Admin Routes',      'Administration page routes',                        'settings',              40, 'seed'),
        (NEWID(), 'actions-security', 'Security Actions',  'CRUD and export actions on securities',             'shield',                50, 'seed'),
        (NEWID(), 'actions-feature',  'Feature Actions',   'Operational actions: ratings, pricing, imports',    'bolt',                  60, 'seed');

    PRINT 'App Resource Groups seed data loaded.';
END
GO

-- ====================================================================
-- Entity Screens (idempotent)
-- ====================================================================
IF NOT EXISTS (SELECT 1 FROM dbo.entity_screen WHERE screen_key = 'screen.dashboard' AND is_current = 1 AND is_deleted = 0)
BEGIN
    INSERT INTO dbo.entity_screen
        (id, screen_key, display_name, description, app_resource_id, sort_order, created_by)
    SELECT NEWID(), v.screen_key, v.display_name, v.description, ar.id, v.sort_order, 'seed'
    FROM (VALUES
        ('screen.dashboard',         'Dashboard',                'Main dashboard overview',                   'route./dashboard',                  10),
        ('screen.securities',        'Securities',               'Securities list and management',             'route./securities',                 20),
        ('screen.issuers',           'Issuers',                  'Issuers list and management',                'route./issuers',                    30),
        ('screen.ratings',           'Ratings',                  'Ratings overview and calculations',          'route./ratings',                    40),
        ('screen.pricing',           'Pricing',                  'Pricing overview and rules',                 'route./pricing',                    50),
        ('screen.portfolios',        'Portfolios',               'Portfolio management',                       'route./portfolios',                 60),
        ('screen.imports',           'Imports',                  'Data import management',                     'route./imports',                    70),
        ('screen.jobs',              'Jobs',                     'Background job monitoring',                  'route./jobs',                       80),
        ('screen.workflows',         'Workflows',                'Workflow instance management',               'route./workflows',                  90),
        ('screen.history',           'History',                  'Audit and change history',                   'route./history',                    100),
        ('screen.admin',             'Admin',                    'Administration landing page',                'route./admin',                      200),
        ('screen.admin.fv',          'Admin - Field Visibility', 'Field visibility configuration',             'route./admin/fv/entities',          210),
        ('screen.admin.ar',          'Admin - App Resources',    'App resource and rule management',           'route./admin/ar/resources',         220),
        ('screen.admin.permissions', 'Admin - Permissions',      'Permission catalog, bundles and templates',  'route./admin/permissions/catalog',  230),
        ('screen.admin.monitoring',  'Admin - Monitoring',       'Audit history, dead letters and system',     'route./admin/audit-history',        240)
    ) AS v(screen_key, display_name, description, resource_key, sort_order)
    JOIN dbo.app_resource ar ON ar.resource_key = v.resource_key AND ar.is_current = 1 AND ar.is_deleted = 0;

    PRINT 'Entity Screens seed data loaded.';
END
GO
-- Seeds: Demo Securities (idempotent)
IF NOT EXISTS (SELECT 1 FROM dbo.security_identifier WHERE identifier_type = 'Ticker' AND identifier_value = 'AAPL')
BEGIN
    DECLARE @sAapl      UNIQUEIDENTIFIER = 'A0000001-5EED-0000-0000-000000000001';
    DECLARE @sMsft      UNIQUEIDENTIFIER = 'A0000001-5EED-0000-0000-000000000002';
    DECLARE @sAaplIsin  UNIQUEIDENTIFIER = 'A0000001-5EED-0000-0000-000000000003';
    DECLARE @sTsla      UNIQUEIDENTIFIER = 'A0000001-5EED-0000-0000-000000000004';
    DECLARE @sJpm       UNIQUEIDENTIFIER = 'A0000001-5EED-0000-0000-000000000005';
    DECLARE @sAppleBond UNIQUEIDENTIFIER = 'A0000001-5EED-0000-0000-000000000006';
    DECLARE @sMsftBond  UNIQUEIDENTIFIER = 'A0000001-5EED-0000-0000-000000000007';
    DECLARE @sJpmBond   UNIQUEIDENTIFIER = 'A0000001-5EED-0000-0000-000000000008';
    DECLARE @sDbBond    UNIQUEIDENTIFIER = 'A0000001-5EED-0000-0000-000000000009';
    DECLARE @sTbond51   UNIQUEIDENTIFIER = 'A0000001-5EED-0000-0000-000000000010';
    DECLARE @sTbond24   UNIQUEIDENTIFIER = 'A0000001-5EED-0000-0000-000000000011';
    DECLARE @sCaBond    UNIQUEIDENTIFIER = 'A0000001-5EED-0000-0000-000000000012';
    DECLARE @sMtaBond   UNIQUEIDENTIFIER = 'A0000001-5EED-0000-0000-000000000013';
    DECLARE @sLoan      UNIQUEIDENTIFIER = 'A0000001-5EED-0000-0000-000000000014';
    DECLARE @sOption    UNIQUEIDENTIFIER = 'A0000001-5EED-0000-0000-000000000015';

    INSERT INTO dbo.security
        (id, data_source, type, name, description, issuer, currency_code, modified_by)
    VALUES
      -- Equities
      (@sAapl,      'Manual', 'Equity',        'Apple Inc.',                          'Consumer electronics and software company',         'Apple Inc.',                    'USD', 'seed'),
      (@sMsft,      'Manual', 'Equity',        'Microsoft Corporation',               'Cloud computing and enterprise software company',   'Microsoft Corporation',          'USD', 'seed'),
      (@sAaplIsin,  'Manual', 'Equity',        'Apple Inc. (ISIN)',                   'Same issuer, ISIN identifier variant',              'Apple Inc.',                    'USD', 'seed'),
      (@sTsla,      'Manual', 'Equity',        'Tesla Inc.',                          'Electric vehicles and energy storage company',      'Tesla Inc.',                    'USD', 'seed'),
      (@sJpm,       'Manual', 'Equity',        'JPMorgan Chase & Co.',                'Global financial services and investment bank',     'JPMorgan Chase & Co.',          'USD', 'seed'),
      -- Corporate Bonds
      (@sAppleBond, 'Manual', 'CorporateBond', 'Apple 3.85% 2046',                    'Apple senior unsecured bond maturing 2046',         'Apple Inc.',                    'USD', 'seed'),
      (@sMsftBond,  'Manual', 'CorporateBond', 'Microsoft 3.30% 2027',                'Microsoft medium-term note',                        'Microsoft Corporation',          'USD', 'seed'),
      (@sJpmBond,   'Manual', 'CorporateBond', 'JPMorgan 4.20% 2047',                 'JPMorgan Chase senior bond',                        'JPMorgan Chase & Co.',          'USD', 'seed'),
      (@sDbBond,    'Manual', 'CorporateBond', 'Deutsche Bank 2.75% 2030',            'Deutsche Bank AG senior unsecured EUR bond',        'Deutsche Bank AG',              'EUR', 'seed'),
      -- Treasury Bonds
      (@sTbond51,   'Manual', 'TreasuryBond',  'US Treasury 1.875% 2051',             '30-year US Treasury bond',                         'US Department of the Treasury', 'USD', 'seed'),
      (@sTbond24,   'Manual', 'TreasuryBond',  'US Treasury 2.375% 2024',             '10-year US Treasury note',                         'US Department of the Treasury', 'USD', 'seed'),
      -- Municipal Bonds
      (@sCaBond,    'Manual', 'MunicipalBond', 'California GO Bond 5.0% 2032',        'California general obligation bond',                'State of California',           'USD', 'seed'),
      (@sMtaBond,   'Manual', 'MunicipalBond', 'New York MTA Revenue Bond 4.5% 2035', 'New York MTA revenue bond',                        'New York MTA',                  'USD', 'seed'),
      -- Loan
      (@sLoan,      'Manual', 'Loan',          'Leveraged Term Loan A - TechCo 2028', 'Senior secured TLA facility',                      'TechCo Holdings LLC',           'USD', 'seed'),
      -- Derivative
      (@sOption,    'Manual', 'Derivative',    'AAPL 200 Call Option',                'Call option on Apple common stock at 200 strike',  'Apple Inc.',                    'USD', 'seed');

    INSERT INTO dbo.security_identifier
        (id, security_id, identifier_type, identifier_value, source_system, is_primary, modified_by)
    VALUES
      (NEWID(), @sAapl,      'Ticker',    'AAPL',                'Manual', 1, 'seed'),
      (NEWID(), @sMsft,      'Ticker',    'MSFT',                'Manual', 1, 'seed'),
      (NEWID(), @sAaplIsin,  'ISIN',      'US0378331005',        'Manual', 1, 'seed'),
      (NEWID(), @sTsla,      'Ticker',    'TSLA',                'Manual', 1, 'seed'),
      (NEWID(), @sJpm,       'Ticker',    'JPM',                 'Manual', 1, 'seed'),
      (NEWID(), @sAppleBond, 'CUSIP',     '037833100',           'Manual', 1, 'seed'),
      (NEWID(), @sMsftBond,  'CUSIP',     '594918BW8',           'Manual', 1, 'seed'),
      (NEWID(), @sJpmBond,   'ISIN',      'US46625HJF27',        'Manual', 1, 'seed'),
      (NEWID(), @sDbBond,    'ISIN',      'XS2345678901',        'Manual', 1, 'seed'),
      (NEWID(), @sTbond51,   'CUSIP',     '912828ZT0',           'Manual', 1, 'seed'),
      (NEWID(), @sTbond24,   'CUSIP',     '9128284S6',           'Manual', 1, 'seed'),
      (NEWID(), @sCaBond,    'CUSIP',     '130161TS8',           'Manual', 1, 'seed'),
      (NEWID(), @sMtaBond,   'CUSIP',     '64966EZH3',           'Manual', 1, 'seed'),
      (NEWID(), @sLoan,      'Internal',  'LOAN-001',            'Manual', 1, 'seed'),
      (NEWID(), @sOption,    'Bloomberg', 'AAPL US C200 Equity', 'Manual', 1, 'seed');

    PRINT 'Securities seed data loaded.';
    PRINT 'Inserted security_identifier rows for demo securities.';
END
ELSE
    PRINT 'Securities seed data already loaded.';
GO

-- â”€â”€ Security Core Attributes seed (idempotent) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
-- Bonds / loans get financial attributes (coupon, face value, dates, factor rate).
-- Each INSERT is guarded so re-running the script is safe.

-- Apple 3.85% 2046
IF NOT EXISTS (SELECT 1 FROM dbo.security_core_attribute sa JOIN dbo.security_identifier si ON sa.security_id = si.security_id WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '037833100' AND si.is_current = 1 AND si.is_deleted = 0)
    INSERT INTO dbo.security_core_attribute (id, security_id, coupon_rate, face_value, issue_date, maturity_date)
    SELECT NEWID(), si.security_id, 3.85, 1000.00, '2016-05-05', '2046-05-05'
    FROM dbo.security_identifier si WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '037833100' AND si.is_current = 1 AND si.is_deleted = 0;

-- Microsoft 3.30% 2027
IF NOT EXISTS (SELECT 1 FROM dbo.security_core_attribute sa JOIN dbo.security_identifier si ON sa.security_id = si.security_id WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '594918BW8' AND si.is_current = 1 AND si.is_deleted = 0)
    INSERT INTO dbo.security_core_attribute (id, security_id, coupon_rate, face_value, issue_date, maturity_date)
    SELECT NEWID(), si.security_id, 3.30, 1000.00, '2017-02-08', '2027-02-08'
    FROM dbo.security_identifier si WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '594918BW8' AND si.is_current = 1 AND si.is_deleted = 0;

-- JPMorgan 4.20% 2047
IF NOT EXISTS (SELECT 1 FROM dbo.security_core_attribute sa JOIN dbo.security_identifier si ON sa.security_id = si.security_id WHERE si.identifier_type = 'ISIN' AND si.identifier_value = 'US46625HJF27' AND si.is_current = 1 AND si.is_deleted = 0)
    INSERT INTO dbo.security_core_attribute (id, security_id, coupon_rate, face_value, issue_date, maturity_date)
    SELECT NEWID(), si.security_id, 4.20, 1000.00, '2017-07-23', '2047-07-23'
    FROM dbo.security_identifier si WHERE si.identifier_type = 'ISIN' AND si.identifier_value = 'US46625HJF27' AND si.is_current = 1 AND si.is_deleted = 0;

-- Deutsche Bank 2.75% 2030
IF NOT EXISTS (SELECT 1 FROM dbo.security_core_attribute sa JOIN dbo.security_identifier si ON sa.security_id = si.security_id WHERE si.identifier_type = 'ISIN' AND si.identifier_value = 'XS2345678901' AND si.is_current = 1 AND si.is_deleted = 0)
    INSERT INTO dbo.security_core_attribute (id, security_id, coupon_rate, face_value, issue_date, maturity_date)
    SELECT NEWID(), si.security_id, 2.75, 1000.00, '2021-03-15', '2030-03-15'
    FROM dbo.security_identifier si WHERE si.identifier_type = 'ISIN' AND si.identifier_value = 'XS2345678901' AND si.is_current = 1 AND si.is_deleted = 0;

-- US Treasury 1.875% 2051
IF NOT EXISTS (SELECT 1 FROM dbo.security_core_attribute sa JOIN dbo.security_identifier si ON sa.security_id = si.security_id WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '912828ZT0' AND si.is_current = 1 AND si.is_deleted = 0)
    INSERT INTO dbo.security_core_attribute (id, security_id, coupon_rate, face_value, issue_date, maturity_date)
    SELECT NEWID(), si.security_id, 1.875, 1000.00, '2021-02-15', '2051-02-15'
    FROM dbo.security_identifier si WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '912828ZT0' AND si.is_current = 1 AND si.is_deleted = 0;

-- US Treasury 2.375% 2024
IF NOT EXISTS (SELECT 1 FROM dbo.security_core_attribute sa JOIN dbo.security_identifier si ON sa.security_id = si.security_id WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '9128284S6' AND si.is_current = 1 AND si.is_deleted = 0)
    INSERT INTO dbo.security_core_attribute (id, security_id, coupon_rate, face_value, issue_date, maturity_date)
    SELECT NEWID(), si.security_id, 2.375, 1000.00, '2014-02-18', '2024-02-15'
    FROM dbo.security_identifier si WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '9128284S6' AND si.is_current = 1 AND si.is_deleted = 0;

-- California GO Bond 5.0% 2032
IF NOT EXISTS (SELECT 1 FROM dbo.security_core_attribute sa JOIN dbo.security_identifier si ON sa.security_id = si.security_id WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '130161TS8' AND si.is_current = 1 AND si.is_deleted = 0)
    INSERT INTO dbo.security_core_attribute (id, security_id, coupon_rate, face_value, issue_date, maturity_date)
    SELECT NEWID(), si.security_id, 5.00, 5000.00, '2012-06-01', '2032-10-01'
    FROM dbo.security_identifier si WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '130161TS8' AND si.is_current = 1 AND si.is_deleted = 0;

-- New York MTA Revenue Bond 4.5% 2035
IF NOT EXISTS (SELECT 1 FROM dbo.security_core_attribute sa JOIN dbo.security_identifier si ON sa.security_id = si.security_id WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '64966EZH3' AND si.is_current = 1 AND si.is_deleted = 0)
    INSERT INTO dbo.security_core_attribute (id, security_id, coupon_rate, face_value, issue_date, maturity_date)
    SELECT NEWID(), si.security_id, 4.50, 5000.00, '2015-11-01', '2035-11-15'
    FROM dbo.security_identifier si WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '64966EZH3' AND si.is_current = 1 AND si.is_deleted = 0;

-- Leveraged Term Loan A â€” TechCo 2028 (factor_rate = 1.0 for a performing loan)
IF NOT EXISTS (SELECT 1 FROM dbo.security_core_attribute sa JOIN dbo.security_identifier si ON sa.security_id = si.security_id WHERE si.identifier_type = 'Internal' AND si.identifier_value = 'LOAN-001' AND si.is_current = 1 AND si.is_deleted = 0)
    INSERT INTO dbo.security_core_attribute (id, security_id, coupon_rate, factor_rate, face_value, issue_date, maturity_date)
    SELECT NEWID(), si.security_id, 5.75, 1.00, 10000000.00, '2022-01-15', '2028-01-15'
    FROM dbo.security_identifier si WHERE si.identifier_type = 'Internal' AND si.identifier_value = 'LOAN-001' AND si.is_current = 1 AND si.is_deleted = 0;
GO

-- â”€â”€ Security Loan Attributes seed (idempotent) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
-- LOAN-001: Leveraged Term Loan A â€” TechCo 2028
IF NOT EXISTS (SELECT 1 FROM dbo.security_loan_attribute sla JOIN dbo.security_identifier si ON sla.security_id = si.security_id WHERE si.identifier_type = 'Internal' AND si.identifier_value = 'LOAN-001' AND si.is_current = 1 AND si.is_deleted = 0)
    INSERT INTO dbo.security_loan_attribute (id, security_id, loan_type, seniority, amortization, payment_freq, day_count, margin_bps, reference_index, maturity_date)
    SELECT NEWID(), si.security_id, 'TermLoan', 'Senior', 'Amortising', 'Quarterly', 'ACT/360', 275.00, 'SOFR', '2028-01-15'
    FROM dbo.security_identifier si WHERE si.identifier_type = 'Internal' AND si.identifier_value = 'LOAN-001' AND si.is_current = 1 AND si.is_deleted = 0;
GO

PRINT 'Security core attributes and loan attributes seed data loaded.';
GO

-- â”€â”€ Clients / Portfolios / Positions seed (idempotent) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
IF NOT EXISTS (SELECT 1 FROM dbo.client WHERE code = 'ACME')
BEGIN
    -- Clients
    DECLARE @clientAcme  UNIQUEIDENTIFIER = NEWID();
    DECLARE @clientAlpha UNIQUEIDENTIFIER = NEWID();
    DECLARE @clientBeta  UNIQUEIDENTIFIER = NEWID();

    INSERT INTO dbo.client (id, name, code, email, is_active)
    VALUES
      (@clientAcme,  'Acme Capital Management', 'ACME',  'ops@acmecapital.example',  1),
      (@clientAlpha, 'Alpha Wealth Partners',   'ALPHA', 'ops@alphawealth.example',   1),
      (@clientBeta,  'Beta Pension Fund',        'BETA',  'ops@betapension.example',   1);

    -- Portfolios
    DECLARE @pfAcmeGrowth    UNIQUEIDENTIFIER = NEWID();
    DECLARE @pfAcmeIncome    UNIQUEIDENTIFIER = NEWID();
    DECLARE @pfAlphaCore     UNIQUEIDENTIFIER = NEWID();
    DECLARE @pfBetaBalanced  UNIQUEIDENTIFIER = NEWID();

    INSERT INTO dbo.portfolio (id, client_id, name, code, currency, is_active)
    VALUES
      (@pfAcmeGrowth,   @clientAcme,  'Acme Growth Fund',       'ACME-GROWTH',    'USD', 1),
      (@pfAcmeIncome,   @clientAcme,  'Acme Income Fund',        'ACME-INCOME',    'USD', 1),
      (@pfAlphaCore,    @clientAlpha, 'Alpha Core Equity',       'ALPHA-CORE',     'USD', 1),
      (@pfBetaBalanced, @clientBeta,  'Beta Balanced Portfolio', 'BETA-BALANCED',  'USD', 1);

    -- Positions â€” link seed securities by identifier
    -- AAPL equity â†’ Acme Growth, Alpha Core
    -- MSFT equity â†’ Acme Growth
    -- Apple 3.85% 2046 bond â†’ Acme Income, Beta Balanced
    -- US Treasury 1.875% 2051 â†’ Beta Balanced
    DECLARE @secAapl  UNIQUEIDENTIFIER = (SELECT TOP 1 si.security_id FROM dbo.security_identifier si WHERE si.identifier_type = 'Ticker' AND si.identifier_value = 'AAPL' AND si.is_current = 1 AND si.is_deleted = 0);
    DECLARE @secMsft  UNIQUEIDENTIFIER = (SELECT TOP 1 si.security_id FROM dbo.security_identifier si WHERE si.identifier_type = 'Ticker' AND si.identifier_value = 'MSFT' AND si.is_current = 1 AND si.is_deleted = 0);
    DECLARE @secTsla  UNIQUEIDENTIFIER = (SELECT TOP 1 si.security_id FROM dbo.security_identifier si WHERE si.identifier_type = 'Ticker' AND si.identifier_value = 'TSLA' AND si.is_current = 1 AND si.is_deleted = 0);
    DECLARE @secJpm   UNIQUEIDENTIFIER = (SELECT TOP 1 si.security_id FROM dbo.security_identifier si WHERE si.identifier_type = 'Ticker' AND si.identifier_value = 'JPM' AND si.is_current = 1 AND si.is_deleted = 0);
    DECLARE @secAppleBond UNIQUEIDENTIFIER = (SELECT TOP 1 si.security_id FROM dbo.security_identifier si WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '037833100' AND si.is_current = 1 AND si.is_deleted = 0);
    DECLARE @secTbond     UNIQUEIDENTIFIER = (SELECT TOP 1 si.security_id FROM dbo.security_identifier si WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '912828ZT0' AND si.is_current = 1 AND si.is_deleted = 0);

    INSERT INTO dbo.position (id, portfolio_id, security_id, quantity, as_of_date, currency_code, source_system)
    VALUES
      (NEWID(), @pfAcmeGrowth,   @secAapl,      1500.00000000,    CAST(GETUTCDATE() AS DATE), 'USD', 'Seed'),
      (NEWID(), @pfAcmeGrowth,   @secMsft,       800.00000000,    CAST(GETUTCDATE() AS DATE), 'USD', 'Seed'),
      (NEWID(), @pfAcmeGrowth,   @secTsla,       500.00000000,    CAST(GETUTCDATE() AS DATE), 'USD', 'Seed'),
      (NEWID(), @pfAcmeIncome,   @secAppleBond, 2000000.00000000, CAST(GETUTCDATE() AS DATE), 'USD', 'Seed'),
      (NEWID(), @pfAlphaCore,    @secAapl,       750.00000000,    CAST(GETUTCDATE() AS DATE), 'USD', 'Seed'),
      (NEWID(), @pfAlphaCore,    @secJpm,        600.00000000,    CAST(GETUTCDATE() AS DATE), 'USD', 'Seed'),
      (NEWID(), @pfBetaBalanced, @secAppleBond, 1000000.00000000, CAST(GETUTCDATE() AS DATE), 'USD', 'Seed'),
      (NEWID(), @pfBetaBalanced, @secTbond,     5000000.00000000, CAST(GETUTCDATE() AS DATE), 'USD', 'Seed');

    -- Set has_open_position = true for all securities with at least one position
    UPDATE s
    SET    s.has_open_position = 1, s.updated_at = GETUTCDATE()
    FROM   dbo.security s
    WHERE  EXISTS (
        SELECT 1 FROM dbo.position p
        WHERE  p.security_id = s.id AND p.is_current = 1 AND p.is_deleted = 0
    );
END
GO
PRINT 'Clients / Portfolios / Positions seed data loaded.';
GO

-- â”€â”€ Open-position flag for Hangfire nightly-job integration tests â”€â”€â”€
-- (Already set via position seed above; this is a fallback for manual test setups)
UPDATE TOP (3) dbo.security
SET    has_open_position = 1
WHERE  is_current = 1
  AND  is_deleted = 0
  AND  has_open_position = 0;
GO


-- ============================================================================
PRINT 'Seeding issuers...';
GO

DECLARE @now   DATETIME2 = GETUTCDATE();
DECLARE @sentinel DATETIME2 = '9999-12-31 23:59:59';

-- ── 1. Insert issuers ────────────────────────────────────────────────────────

-- Apple Inc.
IF NOT EXISTS (SELECT 1 FROM dbo.issuer WHERE lei_code = 'HWUPKR0MPOU8FGXBT394')
    INSERT INTO dbo.issuer (id, legal_name, display_name, short_name, lei_code, issuer_type, country_alpha2,
        direct_accounting_parent_issuer_id, ultimate_accounting_parent_issuer_id,
        is_active, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), 'Apple Inc.', 'Apple', 'AAPL', 'HWUPKR0MPOU8FGXBT394', 'Corporate', 'US',
        NULL, NULL, 1, @now, @now, @sentinel, @now, @sentinel, 1, 0, 'seed');

-- Microsoft Corporation
IF NOT EXISTS (SELECT 1 FROM dbo.issuer WHERE lei_code = 'INR2EJN1ERAN0W5ZP974')
    INSERT INTO dbo.issuer (id, legal_name, display_name, short_name, lei_code, issuer_type, country_alpha2,
        direct_accounting_parent_issuer_id, ultimate_accounting_parent_issuer_id,
        is_active, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), 'Microsoft Corporation', 'Microsoft', 'MSFT', 'INR2EJN1ERAN0W5ZP974', 'Corporate', 'US',
        NULL, NULL, 1, @now, @now, @sentinel, @now, @sentinel, 1, 0, 'seed');

-- Tesla Inc.
IF NOT EXISTS (SELECT 1 FROM dbo.issuer WHERE lei_code = '54930043XZGB27CTOV49')
    INSERT INTO dbo.issuer (id, legal_name, display_name, short_name, lei_code, issuer_type, country_alpha2,
        direct_accounting_parent_issuer_id, ultimate_accounting_parent_issuer_id,
        is_active, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), 'Tesla Inc.', 'Tesla', 'TSLA', '54930043XZGB27CTOV49', 'Corporate', 'US',
        NULL, NULL, 1, @now, @now, @sentinel, @now, @sentinel, 1, 0, 'seed');

-- JPMorgan Chase & Co.  (ultimate parent)
IF NOT EXISTS (SELECT 1 FROM dbo.issuer WHERE lei_code = '8I5DZWZKVSZI1NUHU748')
    INSERT INTO dbo.issuer (id, legal_name, display_name, short_name, lei_code, issuer_type, country_alpha2,
        direct_accounting_parent_issuer_id, ultimate_accounting_parent_issuer_id,
        is_active, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), 'JPMorgan Chase & Co.', 'JPMorgan', 'JPM', '8I5DZWZKVSZI1NUHU748', 'Corporate', 'US',
        NULL, NULL, 1, @now, @now, @sentinel, @now, @sentinel, 1, 0, 'seed');

-- JPMorgan Chase Bank, N.A.  (direct child of JPMorgan Chase & Co.)
IF NOT EXISTS (SELECT 1 FROM dbo.issuer WHERE lei_code = '7H6GLXDRUGQFU57RNE97')
    INSERT INTO dbo.issuer (id, legal_name, display_name, short_name, lei_code, issuer_type, country_alpha2,
        direct_accounting_parent_issuer_id, ultimate_accounting_parent_issuer_id,
        is_active, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), 'JPMorgan Chase Bank, N.A.', 'JPMorgan Chase Bank', 'JPMCB', '7H6GLXDRUGQFU57RNE97', 'Corporate', 'US',
        (SELECT id FROM dbo.issuer WHERE lei_code = '8I5DZWZKVSZI1NUHU748'),
        (SELECT id FROM dbo.issuer WHERE lei_code = '8I5DZWZKVSZI1NUHU748'),
        1, @now, @now, @sentinel, @now, @sentinel, 1, 0, 'seed');

-- Deutsche Bank AG
IF NOT EXISTS (SELECT 1 FROM dbo.issuer WHERE lei_code = '7LTWFZYICNSX8D621K86')
    INSERT INTO dbo.issuer (id, legal_name, display_name, short_name, lei_code, issuer_type, country_alpha2,
        direct_accounting_parent_issuer_id, ultimate_accounting_parent_issuer_id,
        is_active, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), 'Deutsche Bank AG', 'Deutsche Bank', 'DBK', '7LTWFZYICNSX8D621K86', 'Corporate', 'DE',
        NULL, NULL, 1, @now, @now, @sentinel, @now, @sentinel, 1, 0, 'seed');

-- US Department of the Treasury
IF NOT EXISTS (SELECT 1 FROM dbo.issuer WHERE legal_name = 'US Department of the Treasury' AND is_current = 1)
    INSERT INTO dbo.issuer (id, legal_name, display_name, short_name, lei_code, issuer_type, country_alpha2,
        direct_accounting_parent_issuer_id, ultimate_accounting_parent_issuer_id,
        is_active, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), 'US Department of the Treasury', 'US Treasury', 'UST', NULL, 'Government', 'US',
        NULL, NULL, 1, @now, @now, @sentinel, @now, @sentinel, 1, 0, 'seed');

-- State of California
IF NOT EXISTS (SELECT 1 FROM dbo.issuer WHERE legal_name = 'State of California' AND is_current = 1)
    INSERT INTO dbo.issuer (id, legal_name, display_name, short_name, lei_code, issuer_type, country_alpha2,
        direct_accounting_parent_issuer_id, ultimate_accounting_parent_issuer_id,
        is_active, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), 'State of California', 'California', 'CA', NULL, 'Government', 'US',
        NULL, NULL, 1, @now, @now, @sentinel, @now, @sentinel, 1, 0, 'seed');

-- New York Metropolitan Transportation Authority
IF NOT EXISTS (SELECT 1 FROM dbo.issuer WHERE legal_name = 'New York Metropolitan Transportation Authority' AND is_current = 1)
    INSERT INTO dbo.issuer (id, legal_name, display_name, short_name, lei_code, issuer_type, country_alpha2,
        direct_accounting_parent_issuer_id, ultimate_accounting_parent_issuer_id,
        is_active, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), 'New York Metropolitan Transportation Authority', 'NY MTA', 'NYMTA', NULL, 'Government', 'US',
        NULL, NULL, 1, @now, @now, @sentinel, @now, @sentinel, 1, 0, 'seed');

-- TechCo Holdings LLC
IF NOT EXISTS (SELECT 1 FROM dbo.issuer WHERE legal_name = 'TechCo Holdings LLC' AND is_current = 1)
    INSERT INTO dbo.issuer (id, legal_name, display_name, short_name, lei_code, issuer_type, country_alpha2,
        direct_accounting_parent_issuer_id, ultimate_accounting_parent_issuer_id,
        is_active, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), 'TechCo Holdings LLC', 'TechCo Holdings', 'TECHCO', NULL, 'Corporate', 'US',
        NULL, NULL, 1, @now, @now, @sentinel, @now, @sentinel, 1, 0, 'seed');

GO

-- ── 2. Insert issuer identifiers ─────────────────────────────────────────────

DECLARE @now2      DATETIME2 = GETUTCDATE();
DECLARE @sentinel2 DATETIME2 = '9999-12-31 23:59:59';

DECLARE @issApple   UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE lei_code = 'HWUPKR0MPOU8FGXBT394' AND is_current = 1);
DECLARE @issMsft    UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE lei_code = 'INR2EJN1ERAN0W5ZP974' AND is_current = 1);
DECLARE @issTsla    UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE lei_code = '54930043XZGB27CTOV49' AND is_current = 1);
DECLARE @issJpm     UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE lei_code = '8I5DZWZKVSZI1NUHU748' AND is_current = 1);
DECLARE @issJpmcb   UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE lei_code = '7H6GLXDRUGQFU57RNE97' AND is_current = 1);
DECLARE @issDb      UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE lei_code = '7LTWFZYICNSX8D621K86' AND is_current = 1);
DECLARE @issUst     UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE legal_name = 'US Department of the Treasury' AND is_current = 1);
DECLARE @issCa      UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE legal_name = 'State of California' AND is_current = 1);
DECLARE @issMta     UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE legal_name = 'New York Metropolitan Transportation Authority' AND is_current = 1);
DECLARE @issTechco  UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE legal_name = 'TechCo Holdings LLC' AND is_current = 1);

-- Apple identifiers
IF NOT EXISTS (SELECT 1 FROM dbo.issuer_identifier WHERE issuer_id = @issApple AND identifier_type = 'Ticker' AND identifier_value = 'AAPL' AND is_current = 1)
    INSERT INTO dbo.issuer_identifier (id, issuer_id, identifier_type, identifier_value, source_system, is_primary, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), @issApple, 'Ticker', 'AAPL', 'Manual', 1, @now2, @now2, @sentinel2, @now2, @sentinel2, 1, 0, 'seed');

IF NOT EXISTS (SELECT 1 FROM dbo.issuer_identifier WHERE issuer_id = @issApple AND identifier_type = 'CUSIP' AND identifier_value = '037833100' AND is_current = 1)
    INSERT INTO dbo.issuer_identifier (id, issuer_id, identifier_type, identifier_value, source_system, is_primary, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), @issApple, 'CUSIP', '037833100', 'Manual', 0, @now2, @now2, @sentinel2, @now2, @sentinel2, 1, 0, 'seed');

-- Microsoft identifiers
IF NOT EXISTS (SELECT 1 FROM dbo.issuer_identifier WHERE issuer_id = @issMsft AND identifier_type = 'Ticker' AND identifier_value = 'MSFT' AND is_current = 1)
    INSERT INTO dbo.issuer_identifier (id, issuer_id, identifier_type, identifier_value, source_system, is_primary, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), @issMsft, 'Ticker', 'MSFT', 'Manual', 1, @now2, @now2, @sentinel2, @now2, @sentinel2, 1, 0, 'seed');

-- Tesla identifiers
IF NOT EXISTS (SELECT 1 FROM dbo.issuer_identifier WHERE issuer_id = @issTsla AND identifier_type = 'Ticker' AND identifier_value = 'TSLA' AND is_current = 1)
    INSERT INTO dbo.issuer_identifier (id, issuer_id, identifier_type, identifier_value, source_system, is_primary, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), @issTsla, 'Ticker', 'TSLA', 'Manual', 1, @now2, @now2, @sentinel2, @now2, @sentinel2, 1, 0, 'seed');

-- JPMorgan identifiers
IF NOT EXISTS (SELECT 1 FROM dbo.issuer_identifier WHERE issuer_id = @issJpm AND identifier_type = 'Ticker' AND identifier_value = 'JPM' AND is_current = 1)
    INSERT INTO dbo.issuer_identifier (id, issuer_id, identifier_type, identifier_value, source_system, is_primary, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), @issJpm, 'Ticker', 'JPM', 'Manual', 1, @now2, @now2, @sentinel2, @now2, @sentinel2, 1, 0, 'seed');

-- Deutsche Bank identifiers
IF NOT EXISTS (SELECT 1 FROM dbo.issuer_identifier WHERE issuer_id = @issDb AND identifier_type = 'Ticker' AND identifier_value = 'DBK' AND is_current = 1)
    INSERT INTO dbo.issuer_identifier (id, issuer_id, identifier_type, identifier_value, source_system, is_primary, created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), @issDb, 'Ticker', 'DBK', 'Manual', 1, @now2, @now2, @sentinel2, @now2, @sentinel2, 1, 0, 'seed');

GO

-- ── 3. Insert issuer relationships ───────────────────────────────────────────

DECLARE @now3      DATETIME2 = GETUTCDATE();
DECLARE @sentinel3 DATETIME2 = '9999-12-31 23:59:59';

DECLARE @issJpm3   UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE lei_code = '8I5DZWZKVSZI1NUHU748' AND is_current = 1);
DECLARE @issJpmcb3 UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE lei_code = '7H6GLXDRUGQFU57RNE97' AND is_current = 1);

-- JPMorgan Chase Bank, N.A. → JPMorgan Chase & Co. (accounting direct parent)
IF NOT EXISTS (
    SELECT 1 FROM dbo.issuer_relationship
    WHERE child_issuer_id = @issJpmcb3
      AND parent_issuer_id = @issJpm3
      AND relationship_type = 'ACCOUNTING_DIRECT_PARENT'
      AND is_current = 1
)
    INSERT INTO dbo.issuer_relationship (id, child_issuer_id, parent_issuer_id, relationship_type,
        ownership_percent, is_primary, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), @issJpmcb3, @issJpm3, 'ACCOUNTING_DIRECT_PARENT',
        100.00, 1, @now3, @sentinel3, @now3, @sentinel3, 1, 0, 'seed');

-- JPMorgan Chase Bank, N.A. → JPMorgan Chase & Co. (ultimate parent)
IF NOT EXISTS (
    SELECT 1 FROM dbo.issuer_relationship
    WHERE child_issuer_id = @issJpmcb3
      AND parent_issuer_id = @issJpm3
      AND relationship_type = 'ACCOUNTING_ULTIMATE_PARENT'
      AND is_current = 1
)
    INSERT INTO dbo.issuer_relationship (id, child_issuer_id, parent_issuer_id, relationship_type,
        ownership_percent, is_primary, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), @issJpmcb3, @issJpm3, 'ACCOUNTING_ULTIMATE_PARENT',
        100.00, 1, @now3, @sentinel3, @now3, @sentinel3, 1, 0, 'seed');

-- JPMorgan Chase Bank, N.A. → JPMorgan Chase & Co. (ownership)
IF NOT EXISTS (
    SELECT 1 FROM dbo.issuer_relationship
    WHERE child_issuer_id = @issJpmcb3
      AND parent_issuer_id = @issJpm3
      AND relationship_type = 'OWNERSHIP_PARENT'
      AND is_current = 1
)
    INSERT INTO dbo.issuer_relationship (id, child_issuer_id, parent_issuer_id, relationship_type,
        ownership_percent, is_primary, valid_from, valid_to, system_from, system_to, is_current, is_deleted, modified_by)
    VALUES (NEWID(), @issJpmcb3, @issJpm3, 'OWNERSHIP_PARENT',
        100.00, 1, @now3, @sentinel3, @now3, @sentinel3, 1, 0, 'seed');

GO

-- ── 4. Link existing securities to issuers ───────────────────────────────────

DECLARE @issApple4 UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE lei_code = 'HWUPKR0MPOU8FGXBT394' AND is_current = 1);
DECLARE @issMsft4  UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE lei_code = 'INR2EJN1ERAN0W5ZP974' AND is_current = 1);
DECLARE @issTsla4  UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE lei_code = '54930043XZGB27CTOV49' AND is_current = 1);
DECLARE @issJpm4   UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE lei_code = '8I5DZWZKVSZI1NUHU748' AND is_current = 1);
DECLARE @issJpmcb4 UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE lei_code = '7H6GLXDRUGQFU57RNE97' AND is_current = 1);
DECLARE @issDb4    UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE lei_code = '7LTWFZYICNSX8D621K86' AND is_current = 1);
DECLARE @issUst4   UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE legal_name = 'US Department of the Treasury' AND is_current = 1);
DECLARE @issCa4    UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE legal_name = 'State of California' AND is_current = 1);
DECLARE @issMta4   UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE legal_name = 'New York Metropolitan Transportation Authority' AND is_current = 1);
DECLARE @issTechco4 UNIQUEIDENTIFIER = (SELECT id FROM dbo.issuer WHERE legal_name = 'TechCo Holdings LLC' AND is_current = 1);

-- Apple securities
UPDATE dbo.security SET issuer_id = @issApple4
WHERE issuer = 'Apple Inc.' AND (issuer_id IS NULL OR issuer_id <> @issApple4);

-- Microsoft securities
UPDATE dbo.security SET issuer_id = @issMsft4
WHERE issuer = 'Microsoft Corporation' AND (issuer_id IS NULL OR issuer_id <> @issMsft4);

-- Tesla securities
UPDATE dbo.security SET issuer_id = @issTsla4
WHERE issuer = 'Tesla Inc.' AND (issuer_id IS NULL OR issuer_id <> @issTsla4);

-- JPMorgan securities
UPDATE dbo.security SET issuer_id = @issJpm4
WHERE issuer IN ('JPMorgan Chase & Co.', 'JPMorgan Chase') AND (issuer_id IS NULL OR issuer_id <> @issJpm4);

UPDATE dbo.security SET issuer_id = @issJpmcb4
WHERE issuer = 'JPMorgan Chase Bank, N.A.' AND (issuer_id IS NULL OR issuer_id <> @issJpmcb4);

-- Deutsche Bank securities
UPDATE dbo.security SET issuer_id = @issDb4
WHERE issuer = 'Deutsche Bank AG' AND (issuer_id IS NULL OR issuer_id <> @issDb4);

-- US Treasury securities
UPDATE dbo.security SET issuer_id = @issUst4
WHERE issuer IN ('US Treasury', 'US Department of the Treasury', 'United States Treasury')
  AND (issuer_id IS NULL OR issuer_id <> @issUst4);

-- California muni securities
UPDATE dbo.security SET issuer_id = @issCa4
WHERE issuer IN ('State of California', 'California') AND (issuer_id IS NULL OR issuer_id <> @issCa4);

-- NY MTA securities
UPDATE dbo.security SET issuer_id = @issMta4
WHERE issuer IN ('New York MTA', 'New York Metropolitan Transportation Authority', 'MTA')
  AND (issuer_id IS NULL OR issuer_id <> @issMta4);

-- TechCo securities
UPDATE dbo.security SET issuer_id = @issTechco4
WHERE issuer = 'TechCo Holdings LLC' AND (issuer_id IS NULL OR issuer_id <> @issTechco4);

GO

PRINT 'Issuer seed data loaded.';
GO

-- ====================================================================
-- Vendor Source Seed Data (Milestone 10)
-- ====================================================================
MERGE dbo.vendor_source AS tgt
USING (VALUES
    ('BLOOMBERG',    'Bloomberg B-PIPE',        1,  24),
    ('REFINITIV',    'Refinitiv / LSEG',        2,  24),
    ('ICE',          'ICE Data Services',        3,  24),
    ('ALPHAVANTAGE', 'Alpha Vantage',            10, 48),
    ('FLAT_FILE',    'Flat File / SFTP Import',  20, 72),
    ('INTERNAL',     'Internal / Manual',        50, 0)
) AS src (code, display_name, global_priority, staleness_threshold_hours)
ON tgt.code = src.code AND tgt.is_current = 1 AND tgt.is_deleted = 0
WHEN NOT MATCHED THEN
    INSERT (code, display_name, global_priority, staleness_threshold_hours)
    VALUES (src.code, src.display_name, src.global_priority, src.staleness_threshold_hours)
WHEN MATCHED THEN
    UPDATE SET
        tgt.display_name              = src.display_name,
        tgt.global_priority           = src.global_priority,
        tgt.staleness_threshold_hours = src.staleness_threshold_hours,
        tgt.updated_at                = GETUTCDATE();
GO

PRINT 'Vendor source seed data loaded.';
GO

