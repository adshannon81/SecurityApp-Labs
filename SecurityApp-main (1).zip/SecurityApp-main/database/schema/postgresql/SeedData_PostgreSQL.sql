﻿-- ====================================================================
-- SecurityApp — Seed Data (PostgreSQL)
-- Populates initial reference data required for the rating model.
-- Run AFTER CreateSchema_PostgreSQL.sql.
-- All inserts are idempotent (WHERE NOT EXISTS guards).
-- ====================================================================

\echo 'Seeding SecurityApp reference data (PostgreSQL)...';

-- ====================================================================
-- Reference tables
-- ====================================================================

-- security_status_ref
INSERT INTO security_status_ref (code, description)
SELECT v.code, v.description
FROM (VALUES
    ('DRAFT',            'Created but not yet submitted'),
    ('PENDING_APPROVAL', 'Awaiting Compliance approval'),
    ('ACTIVE',           'Approved and operational'),
    ('SUSPENDED',        'Temporarily disabled; still reportable'),
    ('CALLED',           'Issuer has called the instrument'),
    ('MATURED',          'Reached maturity date'),
    ('DEFAULTED',        'Issuer has defaulted'),
    ('RESTRUCTURED',     'Terms restructured post-default'),
    ('RETIRED',          'Removed from active universe'),
    ('CANCELLED',        'Cancelled before or at issuance')
) AS v(code, description)
WHERE NOT EXISTS (SELECT 1 FROM security_status_ref WHERE code = v.code)
ON CONFLICT (code) DO UPDATE SET description = EXCLUDED.description;

-- security_status_transition_ref
INSERT INTO security_status_transition_ref (from_code, to_code)
SELECT v.f, v.t FROM (VALUES
    ('DRAFT',            'PENDING_APPROVAL'),
    ('DRAFT',            'CANCELLED'),
    ('PENDING_APPROVAL', 'ACTIVE'),
    ('PENDING_APPROVAL', 'DRAFT'),
    ('PENDING_APPROVAL', 'CANCELLED'),
    ('ACTIVE',           'SUSPENDED'),
    ('ACTIVE',           'CALLED'),
    ('ACTIVE',           'MATURED'),
    ('ACTIVE',           'DEFAULTED'),
    ('ACTIVE',           'RETIRED'),
    ('SUSPENDED',        'ACTIVE'),
    ('SUSPENDED',        'CALLED'),
    ('SUSPENDED',        'MATURED'),
    ('SUSPENDED',        'DEFAULTED'),
    ('SUSPENDED',        'RETIRED'),
    ('DEFAULTED',        'RESTRUCTURED'),
    ('DEFAULTED',        'RETIRED'),
    ('RESTRUCTURED',     'ACTIVE'),
    ('RESTRUCTURED',     'RETIRED'),
    ('CALLED',           'RETIRED'),
    ('MATURED',          'RETIRED')
) AS v(f, t)
WHERE NOT EXISTS (
    SELECT 1 FROM security_status_transition_ref
    WHERE from_code = v.f AND to_code = v.t
);

-- asset_class_ref
INSERT INTO asset_class_ref (code, name, description)
SELECT v.code, v.name, v.description
FROM (VALUES
    ('EQUITY',       'Equity',                      NULL),
    ('BOND',         'Bond / Fixed Income',          NULL),
    ('LOAN',         'Loan',                         NULL),
    ('MONEY_MARKET', 'Money Market',                 NULL),
    ('FUND',         'Fund / Collective Investment', NULL),
    ('DERIVATIVE',   'Derivative',                   NULL),
    ('SECURITIZED',  'Securitized / Structured',     NULL),
    ('FX',           'Foreign Exchange',             NULL),
    ('COMMODITY',    'Commodity',                    NULL),
    ('OTHER',        'Other / Misc',                 NULL)
) AS v(code, name, description)
WHERE NOT EXISTS (SELECT 1 FROM asset_class_ref WHERE code = v.code)
ON CONFLICT (code) DO UPDATE SET name = EXCLUDED.name;

-- instrument_type_ref
INSERT INTO instrument_type_ref (code, asset_class_code, description)
SELECT v.code, v.asset_class_code, v.description
FROM (VALUES
    -- BOND
    ('TreasuryBond',            'BOND',        'Government treasury bond'),
    ('SovereignBond',           'BOND',        'Non-treasury sovereign issues'),
    ('AgencyBond',              'BOND',        'Supranational / agency bond'),
    ('CorporateBond',           'BOND',        'Vanilla corporate bond'),
    ('MunicipalBond',           'BOND',        'Municipal / local government bond'),
    ('SubordinatedBond',        'BOND',        'Subordinated debt'),
    ('InflationLinkedBond',     'BOND',        'Inflation-linked government or corporate bond'),
    ('PerpetualBond',           'BOND',        'Bond with no fixed maturity'),
    ('CommercialPaper',         'BOND',        'Short-term unsecured note'),
    ('CertificateOfDeposit',    'BOND',        'Certificate of deposit / time deposit'),
    ('ConvertibleBond',         'BOND',        'Bond convertible into equity'),
    -- LOAN
    ('TermLoan',                'LOAN',        'Amortising or bullet term loan'),
    ('RevolvingLoan',           'LOAN',        'Revolving credit facility'),
    ('SyndicatedLoan',          'LOAN',        'Syndicated term / revolver'),
    ('MortgageLoan',            'LOAN',        'Mortgage loan'),
    ('ConsumerLoan',            'LOAN',        'Retail / consumer loan'),
    -- SECURITIZED
    ('ABS',                     'SECURITIZED', 'Asset-backed security (non-mortgage)'),
    ('MBS',                     'SECURITIZED', 'Mortgage-backed security (generic)'),
    ('RMBS',                    'SECURITIZED', 'Residential mortgage-backed security'),
    ('CMBS',                    'SECURITIZED', 'Commercial mortgage-backed security'),
    ('CLO',                     'SECURITIZED', 'Collateralised loan obligation'),
    ('CDO',                     'SECURITIZED', 'Collateralised debt obligation'),
    ('CoveredBond',             'SECURITIZED', 'Covered bond'),
    -- DERIVATIVE
    ('Future',                  'DERIVATIVE',  'Exchange-traded future (generic)'),
    ('InterestRateFuture',      'DERIVATIVE',  'Interest rate future'),
    ('EquityFuture',            'DERIVATIVE',  'Equity or index future'),
    ('Option',                  'DERIVATIVE',  'Generic option'),
    ('EquityOption',            'DERIVATIVE',  'Option on single stock or index'),
    ('BondOption',              'DERIVATIVE',  'Option on bond or future'),
    ('FXOption',                'DERIVATIVE',  'FX option'),
    ('Swap',                    'DERIVATIVE',  'Generic swap'),
    ('InterestRateSwap',        'DERIVATIVE',  'Fixed-float interest rate swap'),
    ('BasisSwap',               'DERIVATIVE',  'Float-float basis swap'),
    ('CrossCurrencySwap',       'DERIVATIVE',  'Cross-currency swap'),
    ('CDS',                     'DERIVATIVE',  'Credit default swap'),
    ('TotalReturnSwap',         'DERIVATIVE',  'Total return swap'),
    ('FXSwap',                  'DERIVATIVE',  'FX swap / forward-forward'),
    ('Forward',                 'DERIVATIVE',  'Generic forward (non-listed)'),
    -- EQUITY
    ('Equity',                  'EQUITY',      'Common stock'),
    ('PreferredEquity',         'EQUITY',      'Preferred / preference shares'),
    ('DepositaryReceipt',       'EQUITY',      'ADR / GDR'),
    ('Warrant',                 'EQUITY',      'Equity warrant'),
    ('Right',                   'EQUITY',      'Subscription right'),
    -- FUND
    ('MutualFund',              'FUND',        'Open-ended fund'),
    ('ExchangeTradedFund',      'FUND',        'Exchange-traded fund (ETF)'),
    ('HedgeFund',               'FUND',        'Hedge fund share class'),
    ('PooledVehicle',           'FUND',        'Other pooled investment vehicle'),
    -- MONEY_MARKET
    ('MoneyMarketFund',         'MONEY_MARKET','Money market fund share'),
    ('TreasuryBill',            'MONEY_MARKET','T-bill / short-dated sovereign note'),
    ('Repo',                    'MONEY_MARKET','Repurchase agreement'),
    ('Deposit',                 'MONEY_MARKET','Term or call deposit'),
    -- FX
    ('FXSpot',                  'FX',          'FX spot'),
    ('FXForward',               'FX',          'FX forward'),
    ('FXNDF',                   'FX',          'Non-deliverable FX forward'),
    -- COMMODITY
    ('CommoditySpot',           'COMMODITY',   'Physical commodity spot'),
    ('CommodityFuture',         'COMMODITY',   'Commodity future'),
    ('CommoditySwap',           'COMMODITY',   'Swap on commodity index or price'),
    -- OTHER
    ('Index',                   'OTHER',       'Benchmark index (non-tradable)'),
    ('CustomStructuredProduct', 'OTHER',       'Bank-issued structured note / product'),
    ('Other',                   'OTHER',       'Catch-all for unclassified types')
) AS v(code, asset_class_code, description)
WHERE NOT EXISTS (SELECT 1 FROM instrument_type_ref WHERE code = v.code)
ON CONFLICT (code) DO UPDATE SET description = EXCLUDED.description;

-- ====================================================================
-- FormulaMacros
-- ====================================================================
INSERT INTO formula_macro (id, name, expression, description, scope,
    created_at, valid_from, valid_to, system_from, system_to,
    is_current, is_deleted)
SELECT
    gen_random_uuid(),
    v.name, v.expression, v.description, v.scope,
    NOW(), NOW(), '9999-12-31', NOW(), '9999-12-31', TRUE, FALSE
FROM (VALUES
    ('DebtScore',
     'Normalize([debtToEquity], 0.0, 8.0, 1.0, 21.0)',
     'Scores debt burden: lower D/E → lower (better) score',
     'Fundamental'),
    ('CoverageScore',
     'Normalize([interestCoverageRatio], 15.0, 0.5, 1.0, 21.0)',
     'Scores interest coverage: higher coverage → lower (better) score',
     'Fundamental'),
    ('VendorQualityWeight',
     '[quality] * Normalize([priceDeviation], 0.0, 0.1, 1.0, 0.1)',
     'Weights vendor price by quality score and deviation band',
     'VPM'),
    ('SpreadConfidence',
     'Normalize(([ask] - [bid]) / [mid], 0.0, 0.10, 1.0, 0.0)',
     'Measures bid/ask spread as a confidence proxy; tighter → more confident',
     'MICR'),
    ('MacroRiskScore',
     'Normalize(RecessionRisk([gdpGrowth], [unemploymentRate]), -5.0, 5.0, 1.0, 21.0)',
     'Combines GDP growth and unemployment into a macro risk score',
     'Macro')
) AS v(name, expression, description, scope)
WHERE NOT EXISTS (
    SELECT 1 FROM formula_macro WHERE name = v.name AND is_current = TRUE AND is_deleted = FALSE
);

-- ====================================================================
-- RatingScaleEntries  (5 agencies × 21 scores = 105 rows)
-- Score 1 = highest credit quality; Score 21 = lowest (default/distress).
-- ====================================================================

-- S&P
INSERT INTO rating_scale_entry (id, agency, score, label, is_investment_grade,
    created_at, valid_from, valid_to, system_from, system_to,
    is_current, is_deleted)
SELECT gen_random_uuid(), v.agency, v.score, v.label, v.is_ig,
    NOW(), NOW(), '9999-12-31', NOW(), '9999-12-31', TRUE, FALSE
FROM (VALUES
    ('SP',  1, 'AAA',  TRUE ),
    ('SP',  2, 'AA+',  TRUE ),
    ('SP',  3, 'AA',   TRUE ),
    ('SP',  4, 'AA-',  TRUE ),
    ('SP',  5, 'A+',   TRUE ),
    ('SP',  6, 'A',    TRUE ),
    ('SP',  7, 'A-',   TRUE ),
    ('SP',  8, 'BBB+', TRUE ),
    ('SP',  9, 'BBB',  TRUE ),
    ('SP', 10, 'BBB-', TRUE ),
    ('SP', 11, 'BB+',  FALSE),
    ('SP', 12, 'BB',   FALSE),
    ('SP', 13, 'BB-',  FALSE),
    ('SP', 14, 'B+',   FALSE),
    ('SP', 15, 'B',    FALSE),
    ('SP', 16, 'B-',   FALSE),
    ('SP', 17, 'CCC+', FALSE),
    ('SP', 18, 'CCC',  FALSE),
    ('SP', 19, 'CCC-', FALSE),
    ('SP', 20, 'CC',   FALSE),
    ('SP', 21, 'D',    FALSE)
) AS v(agency, score, label, is_ig)
WHERE NOT EXISTS (
    SELECT 1 FROM rating_scale_entry
    WHERE agency = v.agency AND score = v.score AND is_current = TRUE AND is_deleted = FALSE
);

-- Moody's
INSERT INTO rating_scale_entry (id, agency, score, label, is_investment_grade,
    created_at, valid_from, valid_to, system_from, system_to,
    is_current, is_deleted)
SELECT gen_random_uuid(), v.agency, v.score, v.label, v.is_ig,
    NOW(), NOW(), '9999-12-31', NOW(), '9999-12-31', TRUE, FALSE
FROM (VALUES
    ('Moodys',  1, 'Aaa',  TRUE ),
    ('Moodys',  2, 'Aa1',  TRUE ),
    ('Moodys',  3, 'Aa2',  TRUE ),
    ('Moodys',  4, 'Aa3',  TRUE ),
    ('Moodys',  5, 'A1',   TRUE ),
    ('Moodys',  6, 'A2',   TRUE ),
    ('Moodys',  7, 'A3',   TRUE ),
    ('Moodys',  8, 'Baa1', TRUE ),
    ('Moodys',  9, 'Baa2', TRUE ),
    ('Moodys', 10, 'Baa3', TRUE ),
    ('Moodys', 11, 'Ba1',  FALSE),
    ('Moodys', 12, 'Ba2',  FALSE),
    ('Moodys', 13, 'Ba3',  FALSE),
    ('Moodys', 14, 'B1',   FALSE),
    ('Moodys', 15, 'B2',   FALSE),
    ('Moodys', 16, 'B3',   FALSE),
    ('Moodys', 17, 'Caa1', FALSE),
    ('Moodys', 18, 'Caa2', FALSE),
    ('Moodys', 19, 'Caa3', FALSE),
    ('Moodys', 20, 'Ca',   FALSE),
    ('Moodys', 21, 'C',    FALSE)
) AS v(agency, score, label, is_ig)
WHERE NOT EXISTS (
    SELECT 1 FROM rating_scale_entry
    WHERE agency = v.agency AND score = v.score AND is_current = TRUE AND is_deleted = FALSE
);

-- Fitch
INSERT INTO rating_scale_entry (id, agency, score, label, is_investment_grade,
    created_at, valid_from, valid_to, system_from, system_to,
    is_current, is_deleted)
SELECT gen_random_uuid(), v.agency, v.score, v.label, v.is_ig,
    NOW(), NOW(), '9999-12-31', NOW(), '9999-12-31', TRUE, FALSE
FROM (VALUES
    ('Fitch',  1, 'AAA',  TRUE ),
    ('Fitch',  2, 'AA+',  TRUE ),
    ('Fitch',  3, 'AA',   TRUE ),
    ('Fitch',  4, 'AA-',  TRUE ),
    ('Fitch',  5, 'A+',   TRUE ),
    ('Fitch',  6, 'A',    TRUE ),
    ('Fitch',  7, 'A-',   TRUE ),
    ('Fitch',  8, 'BBB+', TRUE ),
    ('Fitch',  9, 'BBB',  TRUE ),
    ('Fitch', 10, 'BBB-', TRUE ),
    ('Fitch', 11, 'BB+',  FALSE),
    ('Fitch', 12, 'BB',   FALSE),
    ('Fitch', 13, 'BB-',  FALSE),
    ('Fitch', 14, 'B+',   FALSE),
    ('Fitch', 15, 'B',    FALSE),
    ('Fitch', 16, 'B-',   FALSE),
    ('Fitch', 17, 'CCC',  FALSE),
    ('Fitch', 18, 'CC',   FALSE),
    ('Fitch', 19, 'C',    FALSE),
    ('Fitch', 20, 'RD',   FALSE),
    ('Fitch', 21, 'D',    FALSE)
) AS v(agency, score, label, is_ig)
WHERE NOT EXISTS (
    SELECT 1 FROM rating_scale_entry
    WHERE agency = v.agency AND score = v.score AND is_current = TRUE AND is_deleted = FALSE
);

-- DBRS
INSERT INTO rating_scale_entry (id, agency, score, label, is_investment_grade,
    created_at, valid_from, valid_to, system_from, system_to,
    is_current, is_deleted)
SELECT gen_random_uuid(), v.agency, v.score, v.label, v.is_ig,
    NOW(), NOW(), '9999-12-31', NOW(), '9999-12-31', TRUE, FALSE
FROM (VALUES
    ('DBRS',  1, 'AAA',     TRUE ),
    ('DBRS',  2, 'AA (h)',  TRUE ),
    ('DBRS',  3, 'AA',      TRUE ),
    ('DBRS',  4, 'AA (l)',  TRUE ),
    ('DBRS',  5, 'A (h)',   TRUE ),
    ('DBRS',  6, 'A',       TRUE ),
    ('DBRS',  7, 'A (l)',   TRUE ),
    ('DBRS',  8, 'BBB (h)', TRUE ),
    ('DBRS',  9, 'BBB',     TRUE ),
    ('DBRS', 10, 'BBB (l)', TRUE ),
    ('DBRS', 11, 'BB (h)',  FALSE),
    ('DBRS', 12, 'BB',      FALSE),
    ('DBRS', 13, 'BB (l)',  FALSE),
    ('DBRS', 14, 'B (h)',   FALSE),
    ('DBRS', 15, 'B',       FALSE),
    ('DBRS', 16, 'B (l)',   FALSE),
    ('DBRS', 17, 'CCC (h)', FALSE),
    ('DBRS', 18, 'CCC',     FALSE),
    ('DBRS', 19, 'CCC (l)', FALSE),
    ('DBRS', 20, 'CC',      FALSE),
    ('DBRS', 21, 'D',       FALSE)
) AS v(agency, score, label, is_ig)
WHERE NOT EXISTS (
    SELECT 1 FROM rating_scale_entry
    WHERE agency = v.agency AND score = v.score AND is_current = TRUE AND is_deleted = FALSE
);

-- Kroll
INSERT INTO rating_scale_entry (id, agency, score, label, is_investment_grade,
    created_at, valid_from, valid_to, system_from, system_to,
    is_current, is_deleted)
SELECT gen_random_uuid(), v.agency, v.score, v.label, v.is_ig,
    NOW(), NOW(), '9999-12-31', NOW(), '9999-12-31', TRUE, FALSE
FROM (VALUES
    ('Kroll',  1, 'AAA',  TRUE ),
    ('Kroll',  2, 'AA+',  TRUE ),
    ('Kroll',  3, 'AA',   TRUE ),
    ('Kroll',  4, 'AA-',  TRUE ),
    ('Kroll',  5, 'A+',   TRUE ),
    ('Kroll',  6, 'A',    TRUE ),
    ('Kroll',  7, 'A-',   TRUE ),
    ('Kroll',  8, 'BBB+', TRUE ),
    ('Kroll',  9, 'BBB',  TRUE ),
    ('Kroll', 10, 'BBB-', TRUE ),
    ('Kroll', 11, 'BB+',  FALSE),
    ('Kroll', 12, 'BB',   FALSE),
    ('Kroll', 13, 'BB-',  FALSE),
    ('Kroll', 14, 'B+',   FALSE),
    ('Kroll', 15, 'B',    FALSE),
    ('Kroll', 16, 'B-',   FALSE),
    ('Kroll', 17, 'CCC+', FALSE),
    ('Kroll', 18, 'CCC',  FALSE),
    ('Kroll', 19, 'CCC-', FALSE),
    ('Kroll', 20, 'CC',   FALSE),
    ('Kroll', 21, 'D',    FALSE)
) AS v(agency, score, label, is_ig)
WHERE NOT EXISTS (
    SELECT 1 FROM rating_scale_entry
    WHERE agency = v.agency AND score = v.score AND is_current = TRUE AND is_deleted = FALSE
);

-- ====================================================================
-- RatingDerivationRules  (6 rows)
-- ====================================================================
INSERT INTO rating_derivation_rule (id, model_name, security_type, config_json,
    description, created_at, valid_from, valid_to, system_from, system_to,
    is_current, is_deleted)
SELECT
    gen_random_uuid(), v.model_name, v.security_type, v.config_json,
    v.description,
    NOW(), v.valid_from::TIMESTAMPTZ, '9999-12-31', NOW(), '9999-12-31', TRUE, FALSE
FROM (VALUES
    ('micr', NULL, '{}',
     'Market-Implied Credit Rating: derives score from observed market spread',
     '2000-01-01'),
    ('vpm', NULL, '{}',
     'Vendor Price Model: aggregates weighted vendor prices into a composite rating',
     '2000-01-01'),
    ('fundamental', NULL, '{}',
     'Fundamental Model: derives rating from balance-sheet and income-statement ratios',
     '2000-01-01'),
    ('composite', NULL, '{}',
     'Composite Model: blends MICR, VPM, and fundamental scores with equal weights',
     '2024-01-01'),
    ('composite', 'Bond', '{}',
     'Composite Model for plain bonds: applies bond-specific blending weights',
     '2026-01-01'),
    ('composite', 'CorporateBond', '{}',
     'Composite Model for corporate bonds: applies credit-spread and leverage adjustments',
     '2026-01-01')
) AS v(model_name, security_type, config_json, description, valid_from)
WHERE NOT EXISTS (
    SELECT 1 FROM rating_derivation_rule
    WHERE model_name    = v.model_name
      AND (security_type = v.security_type OR (security_type IS NULL AND v.security_type IS NULL))
      AND is_current = TRUE
      AND is_deleted = FALSE
);

-- ====================================================================
-- Record this script
-- ====================================================================
INSERT INTO "__SchemaVersions" (version, description, script_name, applied_on, applied_by, status)
VALUES ('1.0-seed', 'Initial seed data — FormulaMacros, RatingScaleEntries, RatingDerivationRules',
        'SeedData_PostgreSQL.sql', NOW() AT TIME ZONE 'UTC', CURRENT_USER, 'Success')
ON CONFLICT (version) DO NOTHING;

-- ====================================================================
-- Import Profiles seed data
-- ====================================================================

-- ── 1. Default CSV profile (FlatFile) ────────────────────────────────
DO $$
DECLARE
    v_profile_id UUID;
    v_sym_col    UUID;
    v_sectype_col UUID;
    v_coupon_col  UUID;
    v_maturity_col UUID;
    v_isin_col    UUID;
BEGIN
    SELECT id INTO v_profile_id FROM import_profile
        WHERE name = 'Default' AND source_type = 'FlatFile';

    IF v_profile_id IS NULL THEN
        v_profile_id := gen_random_uuid();
        INSERT INTO import_profile
            (id, name, description, source_type, file_pattern, folder,
             delimiter, text_qualifier, has_header, skip_rows, is_active, created_at)
        VALUES
            (v_profile_id,
             'Default', 'Catch-all CSV profile; matches any *.csv not claimed by a named profile.',
             'FlatFile', '*.csv', '', ',', '"', TRUE, 0, TRUE, NOW());

        INSERT INTO import_profile_column
            (id, profile_id, source_column, target_field, sort_order, created_at)
        VALUES
            (gen_random_uuid(), v_profile_id, 'Symbol',         'symbol',          0,  NOW()),
            (gen_random_uuid(), v_profile_id, 'Name',           'name',            1,  NOW()),
            (gen_random_uuid(), v_profile_id, 'SecurityType',   'securitytype',    2,  NOW()),
            (gen_random_uuid(), v_profile_id, 'ISIN',           'identifiervalue', 3,  NOW()),
            (gen_random_uuid(), v_profile_id, 'CUSIP',          'cusip',           4,  NOW()),
            (gen_random_uuid(), v_profile_id, 'Currency',       'currency',        5,  NOW()),
            (gen_random_uuid(), v_profile_id, 'CouponRate',     'couponrate',      6,  NOW()),
            (gen_random_uuid(), v_profile_id, 'MaturityDate',   'maturitydate',    7,  NOW()),
            (gen_random_uuid(), v_profile_id, 'IssuerName',     'issuername',      8,  NOW()),
            (gen_random_uuid(), v_profile_id, 'Country',        'country',         9,  NOW()),
            (gen_random_uuid(), v_profile_id, 'Exchange',       'exchange',        10, NOW()),
            (gen_random_uuid(), v_profile_id, 'Sector',         'sector',          11, NOW()),
            (gen_random_uuid(), v_profile_id, 'IdentifierType', 'identifiertype',  12, NOW()),
            (gen_random_uuid(), v_profile_id, 'DataSource',     'datasource',      13, NOW());

        SELECT id INTO v_sym_col     FROM import_profile_column WHERE profile_id = v_profile_id AND target_field = 'symbol'          LIMIT 1;
        SELECT id INTO v_sectype_col FROM import_profile_column WHERE profile_id = v_profile_id AND target_field = 'securitytype'    LIMIT 1;
        SELECT id INTO v_coupon_col  FROM import_profile_column WHERE profile_id = v_profile_id AND target_field = 'couponrate'      LIMIT 1;
        SELECT id INTO v_maturity_col FROM import_profile_column WHERE profile_id = v_profile_id AND target_field = 'maturitydate'   LIMIT 1;
        SELECT id INTO v_isin_col    FROM import_profile_column WHERE profile_id = v_profile_id AND target_field = 'identifiervalue' LIMIT 1;

        INSERT INTO import_profile_column_validation
            (id, column_id, rule_type, rule_value, condition, error_message, severity, is_active, created_at)
        VALUES
            (gen_random_uuid(), v_sym_col,     'Required',      NULL, NULL, 'Symbol is required.', 'Error', TRUE, NOW()),
            (gen_random_uuid(), v_sectype_col, 'Required',      NULL, NULL, 'SecurityType is required.', 'Error', TRUE, NOW()),
            (gen_random_uuid(), v_sectype_col, 'AllowedValues', 'Equity,Bond,CorporateBond,GovernmentBond,MunicipalBond,ETF,MutualFund,Derivative,Future,Option,Swap,Other',
             NULL, 'Unknown SecurityType value.', 'Warning', TRUE, NOW()),
            (gen_random_uuid(), v_coupon_col,  'MinValue', '0',
             '[securitytype] == ''Bond'' or [securitytype] == ''CorporateBond'' or [securitytype] == ''GovernmentBond''',
             'CouponRate must be >= 0 for bond instruments.', 'Warning', TRUE, NOW()),
            (gen_random_uuid(), v_coupon_col,  'MaxValue', '100',
             '[securitytype] == ''Bond'' or [securitytype] == ''CorporateBond'' or [securitytype] == ''GovernmentBond''',
             'CouponRate > 100 is unusual — please verify.', 'Warning', TRUE, NOW()),
            (gen_random_uuid(), v_maturity_col, 'DateFormat', 'yyyy-MM-dd',
             '[securitytype] == ''Bond'' or [securitytype] == ''CorporateBond'' or [securitytype] == ''GovernmentBond''',
             'MaturityDate must be in yyyy-MM-dd format for bond instruments.', 'Warning', TRUE, NOW()),
            (gen_random_uuid(), v_isin_col,    'Regex', '^[A-Z]{2}[A-Z0-9]{10}$',
             NULL, 'ISIN does not match the standard format (e.g. US0231351067).', 'Warning', TRUE, NOW());

        INSERT INTO import_profile_row_validation
            (id, profile_id, expression, error_message, severity, sort_order, is_active, created_at)
        VALUES
            (gen_random_uuid(), v_profile_id,
             'not ([securitytype] == ''Bond'' or [securitytype] == ''CorporateBond'' or [securitytype] == ''GovernmentBond'') or not string.IsNullOrEmpty([maturitydate])',
             'Bond instruments must have a MaturityDate.', 'Warning', 0, TRUE, NOW()),
            (gen_random_uuid(), v_profile_id,
             '[symbol] != ''''',
             'Symbol must not be blank.', 'Error', 1, TRUE, NOW());

        RAISE NOTICE 'Inserted: FlatFile/Default profile';
    ELSE
        RAISE NOTICE 'Skipped:  FlatFile/Default profile (already exists)';
    END IF;
END $$;

-- ── 2. Default JSON profile ───────────────────────────────────────────
DO $$
DECLARE
    v_profile_id UUID;
    v_sym_col    UUID;
BEGIN
    SELECT id INTO v_profile_id FROM import_profile
        WHERE name = 'Default' AND source_type = 'JsonFile';

    IF v_profile_id IS NULL THEN
        v_profile_id := gen_random_uuid();
        INSERT INTO import_profile
            (id, name, description, source_type, file_pattern, folder,
             records_path, is_active, created_at)
        VALUES
            (v_profile_id,
             'Default', 'Default JSON import profile; reads a root-level array ($[*]).',
             'JsonFile', '*.json', '', '$[*]', TRUE, NOW());

        INSERT INTO import_profile_column
            (id, profile_id, source_column, target_field, sort_order, created_at)
        VALUES
            (gen_random_uuid(), v_profile_id, 'symbol',         'symbol',          0,  NOW()),
            (gen_random_uuid(), v_profile_id, 'name',           'name',            1,  NOW()),
            (gen_random_uuid(), v_profile_id, 'securityType',   'securitytype',    2,  NOW()),
            (gen_random_uuid(), v_profile_id, 'isin',           'identifiervalue', 3,  NOW()),
            (gen_random_uuid(), v_profile_id, 'currency',       'currency',        4,  NOW()),
            (gen_random_uuid(), v_profile_id, 'couponRate',     'couponrate',      5,  NOW()),
            (gen_random_uuid(), v_profile_id, 'maturityDate',   'maturitydate',    6,  NOW()),
            (gen_random_uuid(), v_profile_id, 'issuerName',     'issuername',      7,  NOW()),
            (gen_random_uuid(), v_profile_id, 'identifierType', 'identifiertype',  8,  NOW());

        SELECT id INTO v_sym_col FROM import_profile_column WHERE profile_id = v_profile_id AND target_field = 'symbol' LIMIT 1;
        INSERT INTO import_profile_column_validation
            (id, column_id, rule_type, rule_value, condition, error_message, severity, is_active, created_at)
        VALUES
            (gen_random_uuid(), v_sym_col, 'Required', NULL, NULL, 'Symbol is required.', 'Error', TRUE, NOW());

        RAISE NOTICE 'Inserted: JsonFile/Default profile';
    ELSE
        RAISE NOTICE 'Skipped:  JsonFile/Default profile (already exists)';
    END IF;
END $$;

-- ── 3. Default XML profile ────────────────────────────────────────────
DO $$
DECLARE
    v_profile_id UUID;
    v_sym_col    UUID;
BEGIN
    SELECT id INTO v_profile_id FROM import_profile
        WHERE name = 'Default' AND source_type = 'XmlFile';

    IF v_profile_id IS NULL THEN
        v_profile_id := gen_random_uuid();
        INSERT INTO import_profile
            (id, name, description, source_type, file_pattern, folder,
             records_x_path, is_active, created_at)
        VALUES
            (v_profile_id,
             'Default', 'Default XML import profile; selects //Security elements.',
             'XmlFile', '*.xml', '', '//Security', TRUE, NOW());

        INSERT INTO import_profile_column
            (id, profile_id, source_column, target_field, sort_order, created_at)
        VALUES
            (gen_random_uuid(), v_profile_id, 'Symbol',         'symbol',          0,  NOW()),
            (gen_random_uuid(), v_profile_id, 'Name',           'name',            1,  NOW()),
            (gen_random_uuid(), v_profile_id, 'SecurityType',   'securitytype',    2,  NOW()),
            (gen_random_uuid(), v_profile_id, 'ISIN',           'identifiervalue', 3,  NOW()),
            (gen_random_uuid(), v_profile_id, 'Currency',       'currency',        4,  NOW()),
            (gen_random_uuid(), v_profile_id, 'CouponRate',     'couponrate',      5,  NOW()),
            (gen_random_uuid(), v_profile_id, 'MaturityDate',   'maturitydate',    6,  NOW()),
            (gen_random_uuid(), v_profile_id, 'IdentifierType', 'identifiertype',  7,  NOW());

        SELECT id INTO v_sym_col FROM import_profile_column WHERE profile_id = v_profile_id AND target_field = 'symbol' LIMIT 1;
        INSERT INTO import_profile_column_validation
            (id, column_id, rule_type, rule_value, condition, error_message, severity, is_active, created_at)
        VALUES
            (gen_random_uuid(), v_sym_col, 'Required', NULL, NULL, 'Symbol is required.', 'Error', TRUE, NOW());

        RAISE NOTICE 'Inserted: XmlFile/Default profile';
    ELSE
        RAISE NOTICE 'Skipped:  XmlFile/Default profile (already exists)';
    END IF;
END $$;

INSERT INTO "__SchemaVersions" (version, description, script_name, applied_on, applied_by, status)
VALUES ('1.1-seed', 'ImportProfile seed data — Default profiles for FlatFile, JsonFile, XmlFile',
        'SeedData_PostgreSQL.sql', NOW() AT TIME ZONE 'UTC', CURRENT_USER, 'Success')
ON CONFLICT (version) DO NOTHING;

\echo 'SecurityApp seed data loaded successfully.';

-- ── Open-position flag for Hangfire nightly-job integration tests ───
UPDATE security
SET    has_open_position = TRUE
WHERE  id IN (
    SELECT id FROM security WHERE is_current = TRUE AND is_deleted = FALSE LIMIT 2
);

-- ====================================================================
-- Currencies -- ISO 4217 active codes + common crypto
-- ====================================================================
\echo 'Seeding currencies...';
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AED','784',$$UAE Dirham$$,'Ø¯.Ø¥',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AFN','971',$$Afghan Afghani$$,'Ø‹',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ALL','008',$$Albanian Lek$$,'L',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AMD','051',$$Armenian Dram$$,'Ö',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ANG','532',$$Netherlands Antillean Guilder$$,'Æ’',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AOA','973',$$Angolan Kwanza$$,'Kz',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ARS','032',$$Argentine Peso$$,'$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AUD','036',$$Australian Dollar$$,'A$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AWG','533',$$Aruban Florin$$,'Æ’',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AZN','944',$$Azerbaijani Manat$$,'â‚¼',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BAM','977',$$Bosnia-Herzegovina Convertible Mark$$,'KM',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BBD','052',$$Barbadian Dollar$$,'Bds$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BDT','050',$$Bangladeshi Taka$$,'à§³',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BGN','975',$$Bulgarian Lev$$,'Ð»Ð²',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BHD','048',$$Bahraini Dinar$$,'BD',3,3,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BIF','108',$$Burundian Franc$$,'Fr',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BMD','060',$$Bermudian Dollar$$,'BD$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BND','096',$$Brunei Dollar$$,'B$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BOB','068',$$Bolivian Boliviano$$,'Bs.',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BRL','986',$$Brazilian Real$$,'R$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BSD','044',$$Bahamian Dollar$$,'B$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BTN','064',$$Bhutanese Ngultrum$$,'Nu',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BWP','072',$$Botswanan Pula$$,'P',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BYN','933',$$Belarusian Ruble$$,'Br',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('BZD','084',$$Belize Dollar$$,'BZ$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CAD','124',$$Canadian Dollar$$,'CA$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CDF','976',$$Congolese Franc$$,'FC',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CHF','756',$$Swiss Franc$$,'Fr',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CLP','152',$$Chilean Peso$$,'CLP$',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CNY','156',$$Chinese Yuan$$,'Â¥',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('COP','170',$$Colombian Peso$$,'COL$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CRC','188',$$Costa Rican ColÃ³n$$,'â‚¡',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CUP','192',$$Cuban Peso$$,'â‚±',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CVE','132',$$Cape Verdean Escudo$$,'$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('CZK','203',$$Czech Koruna$$,'KÄ',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('DJF','262',$$Djiboutian Franc$$,'Fdj',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('DKK','208',$$Danish Krone$$,'kr',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('DOP','214',$$Dominican Peso$$,'RD$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('DZD','012',$$Algerian Dinar$$,'Ø¯Ø¬',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('EGP','818',$$Egyptian Pound$$,'EÂ£',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ERN','232',$$Eritrean Nakfa$$,'Nfk',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ETB','230',$$Ethiopian Birr$$,'Br',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('EUR','978',$$Euro$$,'â‚¬',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('FJD','242',$$Fijian Dollar$$,'FJ$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('FKP','238',$$Falkland Islands Pound$$,'Â£',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GBP','826',$$British Pound Sterling$$,'Â£',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GEL','981',$$Georgian Lari$$,'â‚¾',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GHS','936',$$Ghanaian Cedi$$,'â‚µ',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GIP','292',$$Gibraltar Pound$$,'Â£',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GMD','270',$$Gambian Dalasi$$,'D',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GNF','324',$$Guinean Franc$$,'FG',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GTQ','320',$$Guatemalan Quetzal$$,'Q',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('GYD','328',$$Guyanaese Dollar$$,'G$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('HKD','344',$$Hong Kong Dollar$$,'HK$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('HNL','340',$$Honduran Lempira$$,'L',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('HTG','332',$$Haitian Gourde$$,'G',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('HUF','348',$$Hungarian Forint$$,'Ft',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('IDR','360',$$Indonesian Rupiah$$,'Rp',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ILS','376',$$Israeli New Shekel$$,'â‚ª',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('INR','356',$$Indian Rupee$$,'â‚¹',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('IQD','368',$$Iraqi Dinar$$,'Ø¹.Ø¯',3,3,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('IRR','364',$$Iranian Rial$$,'ï·¼',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ISK','352',$$Icelandic KrÃ³na$$,'kr',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('JMD','388',$$Jamaican Dollar$$,'J$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('JOD','400',$$Jordanian Dinar$$,'JD',3,3,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('JPY','392',$$Japanese Yen$$,'Â¥',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KES','404',$$Kenyan Shilling$$,'KSh',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KGS','417',$$Kyrgystani Som$$,'Ð»Ð²',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KHR','116',$$Cambodian Riel$$,'áŸ›',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KMF','174',$$Comorian Franc$$,'CF',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KPW','408',$$North Korean Won$$,'â‚©',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KRW','410',$$South Korean Won$$,'â‚©',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KWD','414',$$Kuwaiti Dinar$$,'KD',3,3,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KYD','136',$$Cayman Islands Dollar$$,'CI$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('KZT','398',$$Kazakhstani Tenge$$,'â‚¸',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('LAK','418',$$Laotian Kip$$,'â‚­',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('LBP','422',$$Lebanese Pound$$,'Ù„.Ù„',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('LKR','144',$$Sri Lankan Rupee$$,'Rs',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('LRD','430',$$Liberian Dollar$$,'L$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('LSL','426',$$Lesotho Loti$$,'L',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('LYD','434',$$Libyan Dinar$$,'LD',3,3,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MAD','504',$$Moroccan Dirham$$,'MAD',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MDL','498',$$Moldovan Leu$$,'L',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MGA','969',$$Malagasy Ariary$$,'Ar',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MKD','807',$$Macedonian Denar$$,'Ð´ÐµÐ½',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MMK','104',$$Myanmar Kyat$$,'K',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MNT','496',$$Mongolian TÃ¶grÃ¶g$$,'â‚®',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MOP','446',$$Macanese Pataca$$,'P',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MRU','929',$$Mauritanian Ouguiya$$,'UM',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MUR','480',$$Mauritian Rupee$$,'Rs',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MVR','462',$$Maldivian Rufiyaa$$,'Rf',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MWK','454',$$Malawian Kwacha$$,'MK',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MXN','484',$$Mexican Peso$$,'Mex$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MYR','458',$$Malaysian Ringgit$$,'RM',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MZN','943',$$Mozambican Metical$$,'MT',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('NAD','516',$$Namibian Dollar$$,'N$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('NGN','566',$$Nigerian Naira$$,'â‚¦',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('NIO','558',$$Nicaraguan CÃ³rdoba$$,'C$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('NOK','578',$$Norwegian Krone$$,'kr',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('NPR','524',$$Nepalese Rupee$$,'Rs',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('NZD','554',$$New Zealand Dollar$$,'NZ$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('OMR','512',$$Omani Rial$$,'Ø±.Ø¹.',3,3,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('PAB','590',$$Panamanian Balboa$$,'B/.',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('PEN','604',$$Peruvian Sol$$,'S/.',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('PGK','598',$$Papua New Guinean Kina$$,'K',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('PHP','608',$$Philippine Peso$$,'â‚±',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('PKR','586',$$Pakistani Rupee$$,'Rs',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('PLN','985',$$Polish Zloty$$,'zÅ‚',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('PYG','600',$$Paraguayan Guarani$$,'â‚²',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('QAR','634',$$Qatari Riyal$$,'QR',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('RON','946',$$Romanian Leu$$,'lei',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('RSD','941',$$Serbian Dinar$$,'din',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('RUB','643',$$Russian Ruble$$,'â‚½',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('RWF','646',$$Rwandan Franc$$,'RF',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SAR','682',$$Saudi Riyal$$,'SR',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SBD','090',$$Solomon Islands Dollar$$,'SI$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SCR','690',$$Seychellois Rupee$$,'Rs',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SDG','938',$$Sudanese Pound$$,'Ø¬.Ø³.',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SEK','752',$$Swedish Krona$$,'kr',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SGD','702',$$Singapore Dollar$$,'S$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SHP','654',$$Saint Helena Pound$$,'Â£',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SLE','925',$$Sierra Leonean Leone$$,'Le',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SOS','706',$$Somali Shilling$$,'Sh',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SRD','968',$$Surinamese Dollar$$,'$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SSP','728',$$South Sudanese Pound$$,'Â£',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('STN','930',$$SÃ£o TomÃ© and PrÃ­ncipe Dobra$$,'Db',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SVC','222',$$Salvadoran ColÃ³n$$,'â‚¡',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SYP','760',$$Syrian Pound$$,'Â£S',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('SZL','748',$$Swazi Lilangeni$$,'L',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('THB','764',$$Thai Baht$$,'à¸¿',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TJS','972',$$Tajikistani Somoni$$,'SM',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TMT','934',$$Turkmenistani Manat$$,'T',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TND','788',$$Tunisian Dinar$$,'DT',3,3,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TOP','776',$$Tongan PaÊ»anga$$,'T$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TRY','949',$$Turkish Lira$$,'â‚º',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TTD','780',$$Trinidad and Tobago Dollar$$,'TT$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TWD','901',$$New Taiwan Dollar$$,'NT$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('TZS','834',$$Tanzanian Shilling$$,'Sh',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('UAH','980',$$Ukrainian Hryvnia$$,'â‚´',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('UGX','800',$$Ugandan Shilling$$,'USh',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('USD','840',$$US Dollar$$,'$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('UYU','858',$$Uruguayan Peso$$,'$U',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('UZS','860',$$Uzbekistani Sum$$,'Ð»Ð²',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('VES','928',$$Venezuelan BolÃ­var Soberano$$,'Bs.S',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('VND','704',$$Vietnamese Dong$$,'â‚«',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('VUV','548',$$Vanuatu Vatu$$,'VT',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('WST','882',$$Samoan Tala$$,'T',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XAF','950',$$Central African CFA Franc$$,'Fr',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XCD','951',$$East Caribbean Dollar$$,'EC$',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XOF','952',$$West African CFA Franc$$,'Fr',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XPF','953',$$CFP Franc$$,'Fr',0,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('YER','886',$$Yemeni Rial$$,'ï·¼',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ZAR','710',$$South African Rand$$,'R',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ZMW','967',$$Zambian Kwacha$$,'ZK',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ZWG','924',$$Zimbabwe Gold$$,'ZiG',2,2,'FIAT',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XDR','960',$$IMF Special Drawing Rights$$,'SDR',0,2,'OTHER',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XAU','959',$$Gold (troy ounce)$$,'XAU',4,4,'COMMODITY',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('XAG','961',$$Silver (troy ounce)$$,'XAG',4,4,'COMMODITY',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('USDT',NULL,$$Tether$$,'â‚®',6,6,'CRYPTO',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('USDC',NULL,$$USD Coin$$,'USDC',6,6,'CRYPTO',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('DOGE',NULL,$$Dogecoin$$,'Ã',8,8,'CRYPTO',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('AVAX',NULL,$$Avalanche$$,'AVAX',18,8,'CRYPTO',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('LINK',NULL,$$Chainlink$$,'LINK',18,8,'CRYPTO',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('MATIC',NULL,$$Polygon$$,'MATIC',18,8,'CRYPTO',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ALGO',NULL,$$Algorand$$,'ALGO',6,6,'CRYPTO',TRUE) ON CONFLICT (code) DO NOTHING;
INSERT INTO currency (code,numeric_code,name,symbol,decimals,display_decimals,currency_type,is_active) VALUES ('ATOM',NULL,$$Cosmos$$,'ATOM',6,6,'CRYPTO',TRUE) ON CONFLICT (code) DO NOTHING;
\echo 'Currencies seeded.';

-- ====================================================================
-- Countries -- ISO 3166-1
-- ====================================================================
\echo 'Seeding countries...';
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AF','AFG','004',$$Afghanistan$$,'.af') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AX','ALA','248',$$Ã…land Islands$$,'.ax') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AL','ALB','008',$$Albania$$,'.al') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('DZ','DZA','012',$$Algeria$$,'.dz') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AS','ASM','016',$$American Samoa$$,'.as') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AD','AND','020',$$Andorra$$,'.ad') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AO','AGO','024',$$Angola$$,'.ao') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AI','AIA','660',$$Anguilla$$,'.ai') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AQ','ATA','010',$$Antarctica$$,'.aq') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AG','ATG','028',$$Antigua and Barbuda$$,'.ag') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AR','ARG','032',$$Argentina$$,'.ar') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AM','ARM','051',$$Armenia$$,'.am') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AW','ABW','533',$$Aruba$$,'.aw') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AU','AUS','036',$$Australia$$,'.au') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AT','AUT','040',$$Austria$$,'.at') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AZ','AZE','031',$$Azerbaijan$$,'.az') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BS','BHS','044',$$Bahamas$$,'.bs') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BH','BHR','048',$$Bahrain$$,'.bh') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BD','BGD','050',$$Bangladesh$$,'.bd') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BB','BRB','052',$$Barbados$$,'.bb') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BY','BLR','112',$$Belarus$$,'.by') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BE','BEL','056',$$Belgium$$,'.be') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BZ','BLZ','084',$$Belize$$,'.bz') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BJ','BEN','204',$$Benin$$,'.bj') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BM','BMU','060',$$Bermuda$$,'.bm') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BT','BTN','064',$$Bhutan$$,'.bt') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BO','BOL','068',$$Bolivia$$,'.bo') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BQ','BES','535',$$Bonaire, Sint Eustatius and Saba$$,'.bq') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BA','BIH','070',$$Bosnia and Herzegovina$$,'.ba') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BW','BWA','072',$$Botswana$$,'.bw') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BV','BVT','074',$$Bouvet Island$$,NULL) ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BR','BRA','076',$$Brazil$$,'.br') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IO','IOT','086',$$British Indian Ocean Territory$$,'.io') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BN','BRN','096',$$Brunei Darussalam$$,'.bn') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BG','BGR','100',$$Bulgaria$$,'.bg') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BF','BFA','854',$$Burkina Faso$$,'.bf') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BI','BDI','108',$$Burundi$$,'.bi') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CV','CPV','132',$$Cabo Verde$$,'.cv') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KH','KHM','116',$$Cambodia$$,'.kh') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CM','CMR','120',$$Cameroon$$,'.cm') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CA','CAN','124',$$Canada$$,'.ca') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KY','CYM','136',$$Cayman Islands$$,'.ky') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CF','CAF','140',$$Central African Republic$$,'.cf') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TD','TCD','148',$$Chad$$,'.td') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CL','CHL','152',$$Chile$$,'.cl') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CN','CHN','156',$$China$$,'.cn') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CX','CXR','162',$$Christmas Island$$,'.cx') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CC','CCK','166',$$Cocos (Keeling) Islands$$,'.cc') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CO','COL','170',$$Colombia$$,'.co') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KM','COM','174',$$Comoros$$,'.km') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CD','COD','180',$$Congo, Democratic Republic of the$$,'.cd') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CG','COG','178',$$Congo$$,'.cg') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CK','COK','184',$$Cook Islands$$,'.ck') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CR','CRI','188',$$Costa Rica$$,'.cr') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('HR','HRV','191',$$Croatia$$,'.hr') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CU','CUB','192',$$Cuba$$,'.cu') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CW','CUW','531',$$CuraÃ§ao$$,'.cw') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CY','CYP','196',$$Cyprus$$,'.cy') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CZ','CZE','203',$$Czechia$$,'.cz') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('DK','DNK','208',$$Denmark$$,'.dk') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('DJ','DJI','262',$$Djibouti$$,'.dj') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('DM','DMA','212',$$Dominica$$,'.dm') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('DO','DOM','214',$$Dominican Republic$$,'.do') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('EC','ECU','218',$$Ecuador$$,'.ec') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('EG','EGY','818',$$Egypt$$,'.eg') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SV','SLV','222',$$El Salvador$$,'.sv') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GQ','GNQ','226',$$Equatorial Guinea$$,'.gq') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ER','ERI','232',$$Eritrea$$,'.er') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('EE','EST','233',$$Estonia$$,'.ee') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SZ','SWZ','748',$$Eswatini$$,'.sz') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ET','ETH','231',$$Ethiopia$$,'.et') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('FK','FLK','238',$$Falkland Islands$$,'.fk') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('FO','FRO','234',$$Faroe Islands$$,'.fo') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('FJ','FJI','242',$$Fiji$$,'.fj') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('FI','FIN','246',$$Finland$$,'.fi') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('FR','FRA','250',$$France$$,'.fr') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GF','GUF','254',$$French Guiana$$,'.gf') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PF','PYF','258',$$French Polynesia$$,'.pf') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TF','ATF','260',$$French Southern Territories$$,'.tf') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GA','GAB','266',$$Gabon$$,'.ga') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GM','GMB','270',$$Gambia$$,'.gm') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GE','GEO','268',$$Georgia$$,'.ge') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('DE','DEU','276',$$Germany$$,'.de') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GH','GHA','288',$$Ghana$$,'.gh') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GI','GIB','292',$$Gibraltar$$,'.gi') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GR','GRC','300',$$Greece$$,'.gr') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GL','GRL','304',$$Greenland$$,'.gl') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GD','GRD','308',$$Grenada$$,'.gd') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GP','GLP','312',$$Guadeloupe$$,'.gp') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GU','GUM','316',$$Guam$$,'.gu') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GT','GTM','320',$$Guatemala$$,'.gt') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GG','GGY','831',$$Guernsey$$,'.gg') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GN','GIN','324',$$Guinea$$,'.gn') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GW','GNB','624',$$Guinea-Bissau$$,'.gw') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GY','GUY','328',$$Guyana$$,'.gy') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('HT','HTI','332',$$Haiti$$,'.ht') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('HM','HMD','334',$$Heard Island and McDonald Islands$$,'.hm') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('VA','VAT','336',$$Holy See$$,'.va') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('HN','HND','340',$$Honduras$$,'.hn') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('HK','HKG','344',$$Hong Kong$$,'.hk') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('HU','HUN','348',$$Hungary$$,'.hu') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IS','ISL','352',$$Iceland$$,'.is') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IN','IND','356',$$India$$,'.in') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ID','IDN','360',$$Indonesia$$,'.id') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IR','IRN','364',$$Iran$$,'.ir') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IQ','IRQ','368',$$Iraq$$,'.iq') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IE','IRL','372',$$Ireland$$,'.ie') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IM','IMN','833',$$Isle of Man$$,'.im') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IL','ISR','376',$$Israel$$,'.il') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('IT','ITA','380',$$Italy$$,'.it') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('JM','JAM','388',$$Jamaica$$,'.jm') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('JP','JPN','392',$$Japan$$,'.jp') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('JE','JEY','832',$$Jersey$$,'.je') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('JO','JOR','400',$$Jordan$$,'.jo') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KZ','KAZ','398',$$Kazakhstan$$,'.kz') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KE','KEN','404',$$Kenya$$,'.ke') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KI','KIR','296',$$Kiribati$$,'.ki') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KR','KOR','410',$$Korea, Republic of$$,'.kr') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KW','KWT','414',$$Kuwait$$,'.kw') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KG','KGZ','417',$$Kyrgyzstan$$,'.kg') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LV','LVA','428',$$Latvia$$,'.lv') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LB','LBN','422',$$Lebanon$$,'.lb') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LS','LSO','426',$$Lesotho$$,'.ls') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LR','LBR','430',$$Liberia$$,'.lr') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LY','LBY','434',$$Libya$$,'.ly') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LI','LIE','438',$$Liechtenstein$$,'.li') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LT','LTU','440',$$Lithuania$$,'.lt') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LU','LUX','442',$$Luxembourg$$,'.lu') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MO','MAC','446',$$Macao$$,'.mo') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MG','MDG','450',$$Madagascar$$,'.mg') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MW','MWI','454',$$Malawi$$,'.mw') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MY','MYS','458',$$Malaysia$$,'.my') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MV','MDV','462',$$Maldives$$,'.mv') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ML','MLI','466',$$Mali$$,'.ml') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MT','MLT','470',$$Malta$$,'.mt') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MH','MHL','584',$$Marshall Islands$$,'.mh') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MQ','MTQ','474',$$Martinique$$,'.mq') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MR','MRT','478',$$Mauritania$$,'.mr') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MU','MUS','480',$$Mauritius$$,'.mu') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('YT','MYT','175',$$Mayotte$$,'.yt') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MX','MEX','484',$$Mexico$$,'.mx') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('FM','FSM','583',$$Micronesia$$,'.fm') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MD','MDA','498',$$Moldova$$,'.md') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MC','MCO','492',$$Monaco$$,'.mc') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MN','MNG','496',$$Mongolia$$,'.mn') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ME','MNE','499',$$Montenegro$$,'.me') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MS','MSR','500',$$Montserrat$$,'.ms') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MA','MAR','504',$$Morocco$$,'.ma') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MZ','MOZ','508',$$Mozambique$$,'.mz') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MM','MMR','104',$$Myanmar$$,'.mm') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NA','NAM','516',$$Namibia$$,'.na') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NR','NRU','520',$$Nauru$$,'.nr') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NP','NPL','524',$$Nepal$$,'.np') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NL','NLD','528',$$Netherlands$$,'.nl') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NC','NCL','540',$$New Caledonia$$,'.nc') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NZ','NZL','554',$$New Zealand$$,'.nz') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NI','NIC','558',$$Nicaragua$$,'.ni') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NE','NER','562',$$Niger$$,'.ne') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NG','NGA','566',$$Nigeria$$,'.ng') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NU','NIU','570',$$Niue$$,'.nu') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NF','NFK','574',$$Norfolk Island$$,'.nf') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MK','MKD','807',$$North Macedonia$$,'.mk') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MP','MNP','580',$$Northern Mariana Islands$$,'.mp') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('NO','NOR','578',$$Norway$$,'.no') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('OM','OMN','512',$$Oman$$,'.om') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PK','PAK','586',$$Pakistan$$,'.pk') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PW','PLW','585',$$Palau$$,'.pw') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PS','PSE','275',$$Palestine, State of$$,'.ps') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PA','PAN','591',$$Panama$$,'.pa') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PG','PNG','598',$$Papua New Guinea$$,'.pg') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PY','PRY','600',$$Paraguay$$,'.py') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PE','PER','604',$$Peru$$,'.pe') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PH','PHL','608',$$Philippines$$,'.ph') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PN','PCN','612',$$Pitcairn$$,'.pn') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PL','POL','616',$$Poland$$,'.pl') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PT','PRT','620',$$Portugal$$,'.pt') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PR','PRI','630',$$Puerto Rico$$,'.pr') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('QA','QAT','634',$$Qatar$$,'.qa') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('RE','REU','638',$$RÃ©union$$,'.re') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('RO','ROU','642',$$Romania$$,'.ro') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('RU','RUS','643',$$Russian Federation$$,'.ru') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('RW','RWA','646',$$Rwanda$$,'.rw') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('BL','BLM','652',$$Saint BarthÃ©lemy$$,'.bl') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SH','SHN','654',$$Saint Helena, Ascension and Tristan da Cunha$$,'.sh') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('KN','KNA','659',$$Saint Kitts and Nevis$$,'.kn') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LC','LCA','662',$$Saint Lucia$$,'.lc') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('MF','MAF','663',$$Saint Martin (French part)$$,'.mf') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('PM','SPM','666',$$Saint Pierre and Miquelon$$,'.pm') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('VC','VCT','670',$$Saint Vincent and the Grenadines$$,'.vc') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('WS','WSM','882',$$Samoa$$,'.ws') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SM','SMR','674',$$San Marino$$,'.sm') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ST','STP','678',$$Sao Tome and Principe$$,'.st') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SA','SAU','682',$$Saudi Arabia$$,'.sa') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SN','SEN','686',$$Senegal$$,'.sn') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('RS','SRB','688',$$Serbia$$,'.rs') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SC','SYC','690',$$Seychelles$$,'.sc') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SL','SLE','694',$$Sierra Leone$$,'.sl') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SG','SGP','702',$$Singapore$$,'.sg') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SX','SXM','534',$$Sint Maarten (Dutch part)$$,'.sx') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SK','SVK','703',$$Slovakia$$,'.sk') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SI','SVN','705',$$Slovenia$$,'.si') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SB','SLB','090',$$Solomon Islands$$,'.sb') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SO','SOM','706',$$Somalia$$,'.so') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ZA','ZAF','710',$$South Africa$$,'.za') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GS','SGS','239',$$South Georgia and the South Sandwich Islands$$,'.gs') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SS','SSD','728',$$South Sudan$$,'.ss') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ES','ESP','724',$$Spain$$,'.es') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('LK','LKA','144',$$Sri Lanka$$,'.lk') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SD','SDN','729',$$Sudan$$,'.sd') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SR','SUR','740',$$Suriname$$,'.sr') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SJ','SJM','744',$$Svalbard and Jan Mayen$$,NULL) ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SE','SWE','752',$$Sweden$$,'.se') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('CH','CHE','756',$$Switzerland$$,'.ch') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('SY','SYR','760',$$Syrian Arab Republic$$,'.sy') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TW','TWN','158',$$Taiwan, Province of China$$,'.tw') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TJ','TJK','762',$$Tajikistan$$,'.tj') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TZ','TZA','834',$$Tanzania, United Republic of$$,'.tz') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TH','THA','764',$$Thailand$$,'.th') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TL','TLS','626',$$Timor-Leste$$,'.tl') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TG','TGO','768',$$Togo$$,'.tg') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TK','TKL','772',$$Tokelau$$,'.tk') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TO','TON','776',$$Tonga$$,'.to') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TT','TTO','780',$$Trinidad and Tobago$$,'.tt') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TN','TUN','788',$$Tunisia$$,'.tn') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TR','TUR','792',$$TÃ¼rkiye$$,'.tr') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TM','TKM','795',$$Turkmenistan$$,'.tm') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TC','TCA','796',$$Turks and Caicos Islands$$,'.tc') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('TV','TUV','798',$$Tuvalu$$,'.tv') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('UG','UGA','800',$$Uganda$$,'.ug') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('UA','UKR','804',$$Ukraine$$,'.ua') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('AE','ARE','784',$$United Arab Emirates$$,'.ae') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('GB','GBR','826',$$United Kingdom$$,'.uk') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('UM','UMI','581',$$United States Minor Outlying Islands$$,NULL) ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('US','USA','840',$$United States of America$$,'.us') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('UY','URY','858',$$Uruguay$$,'.uy') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('UZ','UZB','860',$$Uzbekistan$$,'.uz') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('VU','VUT','548',$$Vanuatu$$,'.vu') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('VE','VEN','862',$$Venezuela$$,'.ve') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('VN','VNM','704',$$Viet Nam$$,'.vn') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('VG','VGB','092',$$Virgin Islands, British$$,'.vg') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('VI','VIR','850',$$Virgin Islands, U.S.$$,'.vi') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('WF','WLF','876',$$Wallis and Futuna$$,'.wf') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('EH','ESH','732',$$Western Sahara$$,NULL) ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('YE','YEM','887',$$Yemen$$,'.ye') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ZM','ZMB','894',$$Zambia$$,'.zm') ON CONFLICT (alpha2) DO NOTHING;
INSERT INTO country (alpha2,alpha3,numeric_code,name,tld) VALUES ('ZW','ZWE','716',$$Zimbabwe$$,'.zw') ON CONFLICT (alpha2) DO NOTHING;
\echo 'Countries seeded.';

-- ====================================================================
-- Country-Currency associations
-- ====================================================================
\echo 'Seeding country_currency links...';
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('US','USD',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('GB','GBP',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('JP','JPY',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('CH','CHF',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('AU','AUD',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('CA','CAD',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('NZ','NZD',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('HK','HKD',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('SG','SGD',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('CN','CNY',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('IN','INR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('BR','BRL',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('MX','MXN',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('ZA','ZAR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('RU','RUB',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('TR','TRY',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('KR','KRW',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('ID','IDR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('MY','MYR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('TH','THB',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('PH','PHP',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('PL','PLN',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('CZ','CZK',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('HU','HUF',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('RO','RON',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('BG','BGN',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('IS','ISK',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('IL','ILS',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('AE','AED',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('SA','SAR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('QA','QAR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('KW','KWD',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('BH','BHD',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('OM','OMR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('JO','JOD',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('EG','EGP',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('MA','MAD',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('NG','NGN',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('KE','KES',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('TZ','TZS',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('UG','UGX',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('GH','GHS',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('ZM','ZMW',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('ET','ETB',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('DZ','DZD',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('UA','UAH',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('BY','BYN',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('NO','NOK',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('SE','SEK',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('DK','DKK',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('AT','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('BE','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('CY','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('EE','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('FI','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('FR','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('DE','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('GR','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('IE','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('IT','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('LV','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('LT','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('LU','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('MT','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('NL','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('PT','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('SK','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('SI','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('ES','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('HR','EUR',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('PA','PAB',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('PA','USD',FALSE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('SV','USD',TRUE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
INSERT INTO country_currency (country_alpha2,currency_code,is_primary,is_legal_tender,is_operational) VALUES ('SV','SVC',FALSE,TRUE,TRUE) ON CONFLICT (country_alpha2,currency_code) DO NOTHING;
\echo 'Country-currency links seeded.';

-- ====================================================================
-- Permission Catalog (idempotent)
-- ====================================================================
INSERT INTO permission_definition (id, permission_key, display_name, permission_group, description, is_assignable, is_system, sort_order, is_active)
SELECT gen_random_uuid(), v.k, v.d, v.g, v."desc", v.asgn, v.sys, v.srt, TRUE
FROM (VALUES
    ('securities:read',          'View Securities',               'Securities', 'View securities master data',                            TRUE,  FALSE, 10),
    ('securities:write',         'Create/Update Securities',      'Securities', 'Create and update securities',                           TRUE,  FALSE, 20),
    ('securities:delete',        'Delete Securities',             'Securities', 'Delete securities',                                      TRUE,  FALSE, 30),
    ('securities:view-internal', 'View Internal Fields',          'Securities', 'View internal/sensitive fields e.g. ModifiedBy',         TRUE,  FALSE, 40),
    ('ratings:read',             'View Ratings',                  'Ratings',    'View ratings and audit trail',                           TRUE,  FALSE, 50),
    ('ratings:write',            'Trigger Rating Calculations',   'Ratings',    'Trigger rating calculations',                            TRUE,  FALSE, 60),
    ('ratings:manage',           'Manage Rating Models',          'Ratings',    'Manage rating models, rules, and scales',                TRUE,  FALSE, 70),
    ('pricing:read',             'View Prices',                   'Pricing',    'View prices and pricing rules',                          TRUE,  FALSE, 80),
    ('pricing:write',            'Import Prices',                 'Pricing',    'Import prices and run derivations',                      TRUE,  FALSE, 90),
    ('pricing:manage',           'Manage Pricing Rules',          'Pricing',    'Create, update, and delete pricing rules',               TRUE,  FALSE, 100),
    ('imports:read',             'View Imports',                  'Imports',    'View import requests and profiles',                      TRUE,  FALSE, 110),
    ('imports:run',              'Trigger Imports',               'Imports',    'Trigger imports',                                        TRUE,  FALSE, 120),
    ('imports:manage',           'Manage Import Profiles',        'Imports',    'Manage import profiles and retry failed imports',        TRUE,  FALSE, 130),
    ('exports:run',              'Export Data',                   'Exports',    'Export securities data',                                 TRUE,  FALSE, 140),
    ('workflows:read',           'View Workflows',                'Workflows',  'View workflow instances',                                TRUE,  FALSE, 150),
    ('workflows:use',            'Submit Workflow Decisions',     'Workflows',  'Submit workflow step decisions',                         TRUE,  FALSE, 160),
    ('workflows:manage',         'Manage Workflows',              'Workflows',  'Create, cancel, and delete workflow definitions',        TRUE,  FALSE, 170),
    ('jobs:read',                'View Jobs',                     'Jobs',       'View job status and history',                            TRUE,  FALSE, 180),
    ('jobs:manage',              'Manage Jobs',                   'Jobs',       'Trigger, pause, resume, and schedule jobs',              TRUE,  FALSE, 190),
    ('audit:read',               'View Audit Logs',               'Audit',      'View audit logs',                                        TRUE,  FALSE, 200),
    ('portfolios:read',          'View Portfolios',               'Portfolios', 'View clients, portfolios and positions',                 TRUE,  FALSE, 210),
    ('portfolios:write',         'Manage Portfolios',             'Portfolios', 'Create and manage clients, portfolios and positions',    TRUE,  FALSE, 220),
    ('admin:field-visibility',   'Manage Field Visibility',       'Admin',      'Manage dynamic field visibility rules',                  TRUE,  FALSE, 230),
    ('admin:ui-resources',       'Manage UI Resources',           'Admin',      'Manage UI resource catalog, visibility and exec rules',  TRUE,  FALSE, 240),
    ('system:manage',            'Manage System',                 'System',     'Manage plugins and system settings',                     TRUE,  TRUE,  250),
    ('issuers:read',             'View Issuers',                  'Issuers',    'View issuers and their relationships',                   TRUE,  FALSE, 260),
    ('issuers:write',            'Create/Update Issuers',         'Issuers',    'Create, update, and delete issuers and relationships',   TRUE,  FALSE, 270),
    ('admin:manage-permissions', 'Manage Permission Definitions', 'Administrator','Create, update, and delete permission definitions',    TRUE,  FALSE, 310),
    ('admin:manage-authorization','Manage Authorization Config',  'Administrator','Full access to field visibility and resource auth',    TRUE,  FALSE, 320),
    ('admin:manage-users',       'Manage User Assignments',       'Administrator','Assign permissions and roles to users via Keycloak',   TRUE,  FALSE, 330),
    ('admin:super',              'Superuser / Full Admin Access', 'Administrator','Unrestricted administrative access across platform',   TRUE,  TRUE,  340)
) AS v(k, d, g, "desc", asgn, sys, srt)
WHERE NOT EXISTS (SELECT 1 FROM permission_definition WHERE permission_key = v.k);

\echo 'Permission catalog seed data loaded.';

-- ====================================================================
-- Field Visibility seed (idempotent)
-- ====================================================================
\echo 'Seeding field visibility...';

-- SecurityDto
DO $$ DECLARE v_fve UUID;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM field_visibility_entity WHERE entity_type = 'SecurityDto') THEN
    v_fve := gen_random_uuid();
    INSERT INTO field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (v_fve, 'SecurityDto', 'Security', 'Security master DTO fields', TRUE);

    INSERT INTO field_visibility_field (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level, default_visibility_state, sort_order, is_active) VALUES
      (gen_random_uuid(), v_fve, 'IdentifierType',  'Identifier Type',  'string',   'Public',   'VISIBLE', 10,  TRUE),
      (gen_random_uuid(), v_fve, 'IdentifierValue', 'Identifier Value', 'string',   'Public',   'VISIBLE', 20,  TRUE),
      (gen_random_uuid(), v_fve, 'Name',            'Name',             'string',   'Public',   'VISIBLE', 30,  TRUE),
      (gen_random_uuid(), v_fve, 'Type',            'Type',             'string',   'Public',   'VISIBLE', 40,  TRUE),
      (gen_random_uuid(), v_fve, 'IsActive',        'Is Active',        'boolean',  'Public',   'VISIBLE', 50,  TRUE),
      (gen_random_uuid(), v_fve, 'Description',     'Description',      'string',   'Public',   'VISIBLE', 60,  TRUE),
      (gen_random_uuid(), v_fve, 'Issuer',          'Issuer',           'string',   'Public',   'VISIBLE', 70,  TRUE),
      (gen_random_uuid(), v_fve, 'Currency',        'Currency',         'string',   'Public',   'VISIBLE', 80,  TRUE),
      (gen_random_uuid(), v_fve, 'CreatedAt',       'Created At',       'datetime', 'Public',   'VISIBLE', 90,  TRUE),
      (gen_random_uuid(), v_fve, 'UpdatedAt',       'Updated At',       'datetime', 'Public',   'VISIBLE', 100, TRUE),
      (gen_random_uuid(), v_fve, 'Attributes',      'Attributes',       'object',   'Public',   'VISIBLE', 110, TRUE),
      (gen_random_uuid(), v_fve, 'CreditRatings',   'Credit Ratings',   'object',   'Public',   'VISIBLE', 120, TRUE),
      (gen_random_uuid(), v_fve, 'ModifiedBy',      'Modified By',      'string',   'Internal', 'HIDDEN',  130, TRUE),
      (gen_random_uuid(), v_fve, 'ContentHash',     'Content Hash',     'string',   'Internal', 'HIDDEN',  140, TRUE);

    INSERT INTO field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT gen_random_uuid(), f.id, (SELECT id FROM permission_definition WHERE permission_key = 'securities:read'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM field_visibility_field f WHERE f.field_visibility_entity_id = v_fve AND f.sensitivity_level = 'Public';

    INSERT INTO field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT gen_random_uuid(), f.id, (SELECT id FROM permission_definition WHERE permission_key = 'securities:view-internal'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM field_visibility_field f WHERE f.field_visibility_entity_id = v_fve AND f.sensitivity_level = 'Internal';
  END IF;
END $$;

-- DerivedRatingDto
DO $$ DECLARE v_fve UUID;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM field_visibility_entity WHERE entity_type = 'DerivedRatingDto') THEN
    v_fve := gen_random_uuid();
    INSERT INTO field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (v_fve, 'DerivedRatingDto', 'Derived Rating', 'Derived and composite rating scores for a security', TRUE);

    INSERT INTO field_visibility_field (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level, default_visibility_state, sort_order, is_active) VALUES
      (gen_random_uuid(), v_fve, 'SecurityId',                 'Security ID',                   'guid',     'Public',   'VISIBLE', 10,  TRUE),
      (gen_random_uuid(), v_fve, 'ImpliedRatingScore',         'Implied Rating Score',          'int',      'Public',   'VISIBLE', 20,  TRUE),
      (gen_random_uuid(), v_fve, 'VpmRatingScore',             'VPM Rating Score',              'int',      'Public',   'VISIBLE', 30,  TRUE),
      (gen_random_uuid(), v_fve, 'FundamentalRatingScore',     'Fundamental Rating Score',      'int',      'Public',   'VISIBLE', 40,  TRUE),
      (gen_random_uuid(), v_fve, 'CompositeRatingScore',       'Composite Rating Score',        'int',      'Public',   'VISIBLE', 50,  TRUE),
      (gen_random_uuid(), v_fve, 'CompositeRatingsByAgency',   'Composite Ratings by Agency',   'object',   'Public',   'VISIBLE', 60,  TRUE),
      (gen_random_uuid(), v_fve, 'ImpliedRatingsByAgency',     'Implied Ratings by Agency',     'object',   'Public',   'VISIBLE', 70,  TRUE),
      (gen_random_uuid(), v_fve, 'VpmRatingsByAgency',         'VPM Ratings by Agency',         'object',   'Public',   'VISIBLE', 80,  TRUE),
      (gen_random_uuid(), v_fve, 'FundamentalRatingsByAgency', 'Fundamental Ratings by Agency', 'object',   'Public',   'VISIBLE', 90,  TRUE),
      (gen_random_uuid(), v_fve, 'IsInvestmentGrade',          'Investment Grade',              'boolean',  'Public',   'VISIBLE', 100, TRUE),
      (gen_random_uuid(), v_fve, 'LastCalculatedUtc',          'Last Calculated',               'datetime', 'Public',   'VISIBLE', 110, TRUE),
      (gen_random_uuid(), v_fve, 'OutputAgency',               'Output Agency',                 'string',   'Public',   'VISIBLE', 120, TRUE),
      (gen_random_uuid(), v_fve, 'ImpliedPd',                  'Implied Probability of Default','decimal',  'Internal', 'HIDDEN',  130, TRUE),
      (gen_random_uuid(), v_fve, 'ModelPd',                    'Model Probability of Default',  'decimal',  'Internal', 'HIDDEN',  140, TRUE),
      (gen_random_uuid(), v_fve, 'FairPrice',                  'Fair (Model) Price',            'decimal',  'Internal', 'HIDDEN',  150, TRUE);

    INSERT INTO field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT gen_random_uuid(), f.id, (SELECT id FROM permission_definition WHERE permission_key = 'ratings:read'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM field_visibility_field f WHERE f.field_visibility_entity_id = v_fve AND f.sensitivity_level = 'Public';

    INSERT INTO field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT gen_random_uuid(), f.id, (SELECT id FROM permission_definition WHERE permission_key = 'ratings:write'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM field_visibility_field f WHERE f.field_visibility_entity_id = v_fve AND f.sensitivity_level = 'Internal';
  END IF;
END $$;

-- PricingRuleDto
DO $$ DECLARE v_fve UUID;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM field_visibility_entity WHERE entity_type = 'PricingRuleDto') THEN
    v_fve := gen_random_uuid();
    INSERT INTO field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (v_fve, 'PricingRuleDto', 'Pricing Rule', 'Pricing rule definitions, parameters, and derivation formulas', TRUE);

    INSERT INTO field_visibility_field (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level, default_visibility_state, sort_order, is_active) VALUES
      (gen_random_uuid(), v_fve, 'Id',           'ID',                 'guid',     'Public',   'VISIBLE', 10,  TRUE),
      (gen_random_uuid(), v_fve, 'RuleName',     'Rule Name',          'string',   'Public',   'VISIBLE', 20,  TRUE),
      (gen_random_uuid(), v_fve, 'SecurityType', 'Security Type',      'string',   'Public',   'VISIBLE', 30,  TRUE),
      (gen_random_uuid(), v_fve, 'Source',       'Source',             'string',   'Public',   'VISIBLE', 40,  TRUE),
      (gen_random_uuid(), v_fve, 'PriceType',    'Price Type',         'string',   'Public',   'VISIBLE', 50,  TRUE),
      (gen_random_uuid(), v_fve, 'Description',  'Description',        'string',   'Public',   'VISIBLE', 60,  TRUE),
      (gen_random_uuid(), v_fve, 'IsActive',     'Is Active',          'boolean',  'Public',   'VISIBLE', 70,  TRUE),
      (gen_random_uuid(), v_fve, 'CreatedAt',    'Created At',         'datetime', 'Public',   'VISIBLE', 80,  TRUE),
      (gen_random_uuid(), v_fve, 'UpdatedAt',    'Updated At',         'datetime', 'Public',   'VISIBLE', 90,  TRUE),
      (gen_random_uuid(), v_fve, 'Formula',      'Derivation Formula', 'string',   'Internal', 'HIDDEN',  100, TRUE);

    INSERT INTO field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT gen_random_uuid(), f.id, (SELECT id FROM permission_definition WHERE permission_key = 'pricing:read'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM field_visibility_field f WHERE f.field_visibility_entity_id = v_fve AND f.sensitivity_level = 'Public';

    INSERT INTO field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT gen_random_uuid(), f.id, (SELECT id FROM permission_definition WHERE permission_key = 'pricing:write'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM field_visibility_field f WHERE f.field_visibility_entity_id = v_fve AND f.sensitivity_level = 'Internal';
  END IF;
END $$;

-- ImportRequestDto
DO $$ DECLARE v_fve UUID;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM field_visibility_entity WHERE entity_type = 'ImportRequestDto') THEN
    v_fve := gen_random_uuid();
    INSERT INTO field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (v_fve, 'ImportRequestDto', 'Import Request', 'Import job request status, record counts, and error details', TRUE);

    INSERT INTO field_visibility_field (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level, default_visibility_state, sort_order, is_active) VALUES
      (gen_random_uuid(), v_fve, 'Id',               'ID',                'guid',     'Public',   'VISIBLE', 10,  TRUE),
      (gen_random_uuid(), v_fve, 'RequestType',      'Request Type',      'string',   'Public',   'VISIBLE', 20,  TRUE),
      (gen_random_uuid(), v_fve, 'SourceSystem',     'Source System',     'string',   'Public',   'VISIBLE', 30,  TRUE),
      (gen_random_uuid(), v_fve, 'TargetSystem',     'Target System',     'string',   'Public',   'VISIBLE', 40,  TRUE),
      (gen_random_uuid(), v_fve, 'Status',           'Status',            'string',   'Public',   'VISIBLE', 50,  TRUE),
      (gen_random_uuid(), v_fve, 'TotalRecords',     'Total Records',     'int',      'Public',   'VISIBLE', 60,  TRUE),
      (gen_random_uuid(), v_fve, 'ProcessedRecords', 'Processed Records', 'int',      'Public',   'VISIBLE', 70,  TRUE),
      (gen_random_uuid(), v_fve, 'FailedRecords',    'Failed Records',    'int',      'Public',   'VISIBLE', 80,  TRUE),
      (gen_random_uuid(), v_fve, 'CreatedAt',        'Created At',        'datetime', 'Public',   'VISIBLE', 90,  TRUE),
      (gen_random_uuid(), v_fve, 'CompletedAt',      'Completed At',      'datetime', 'Public',   'VISIBLE', 100, TRUE),
      (gen_random_uuid(), v_fve, 'ErrorMessage',     'Error Message',     'string',   'Internal', 'HIDDEN',  110, TRUE);

    INSERT INTO field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT gen_random_uuid(), f.id, (SELECT id FROM permission_definition WHERE permission_key = 'imports:read'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM field_visibility_field f WHERE f.field_visibility_entity_id = v_fve AND f.sensitivity_level = 'Public';

    INSERT INTO field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT gen_random_uuid(), f.id, (SELECT id FROM permission_definition WHERE permission_key = 'imports:run'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM field_visibility_field f WHERE f.field_visibility_entity_id = v_fve AND f.sensitivity_level = 'Internal';
  END IF;
END $$;

-- JobHistoryDto
DO $$ DECLARE v_fve UUID;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM field_visibility_entity WHERE entity_type = 'JobHistoryDto') THEN
    v_fve := gen_random_uuid();
    INSERT INTO field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (v_fve, 'JobHistoryDto', 'Job History', 'Background job execution history, timing, and failure details', TRUE);

    INSERT INTO field_visibility_field (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level, default_visibility_state, sort_order, is_active) VALUES
      (gen_random_uuid(), v_fve, 'JobId',            'Job ID',            'string',   'Public',   'VISIBLE', 10, TRUE),
      (gen_random_uuid(), v_fve, 'JobName',          'Job Name',          'string',   'Public',   'VISIBLE', 20, TRUE),
      (gen_random_uuid(), v_fve, 'State',            'State',             'string',   'Public',   'VISIBLE', 30, TRUE),
      (gen_random_uuid(), v_fve, 'EnqueuedAt',       'Enqueued At',       'datetime', 'Public',   'VISIBLE', 40, TRUE),
      (gen_random_uuid(), v_fve, 'SucceededAt',      'Succeeded At',      'datetime', 'Public',   'VISIBLE', 50, TRUE),
      (gen_random_uuid(), v_fve, 'ExceptionMessage', 'Exception Message', 'string',   'Internal', 'HIDDEN',  60, TRUE);

    INSERT INTO field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT gen_random_uuid(), f.id, (SELECT id FROM permission_definition WHERE permission_key = 'jobs:read'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM field_visibility_field f WHERE f.field_visibility_entity_id = v_fve AND f.sensitivity_level = 'Public';
  END IF;
END $$;

-- WorkflowInstanceDto
DO $$ DECLARE v_fve UUID;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM field_visibility_entity WHERE entity_type = 'WorkflowInstanceDto') THEN
    v_fve := gen_random_uuid();
    INSERT INTO field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (v_fve, 'WorkflowInstanceDto', 'Workflow Instance', 'Workflow instance state, steps, and assignment details', TRUE);

    INSERT INTO field_visibility_field (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level, default_visibility_state, sort_order, is_active) VALUES
      (gen_random_uuid(), v_fve, 'Id',              'ID',                 'guid',     'Public',   'VISIBLE', 10,  TRUE),
      (gen_random_uuid(), v_fve, 'WorkflowType',    'Workflow Type',      'string',   'Public',   'VISIBLE', 20,  TRUE),
      (gen_random_uuid(), v_fve, 'Status',          'Status',             'string',   'Public',   'VISIBLE', 30,  TRUE),
      (gen_random_uuid(), v_fve, 'CurrentStep',     'Current Step',       'string',   'Public',   'VISIBLE', 40,  TRUE),
      (gen_random_uuid(), v_fve, 'SecurityId',      'Security ID',        'guid',     'Public',   'VISIBLE', 50,  TRUE),
      (gen_random_uuid(), v_fve, 'InitiatedBy',     'Initiated By',       'string',   'Public',   'VISIBLE', 60,  TRUE),
      (gen_random_uuid(), v_fve, 'CurrentAssignee', 'Current Assignee',   'string',   'Public',   'VISIBLE', 70,  TRUE),
      (gen_random_uuid(), v_fve, 'CreatedAt',       'Created At',         'datetime', 'Public',   'VISIBLE', 80,  TRUE),
      (gen_random_uuid(), v_fve, 'UpdatedAt',       'Updated At',         'datetime', 'Public',   'VISIBLE', 90,  TRUE),
      (gen_random_uuid(), v_fve, 'Notes',           'Notes',              'string',   'Public',   'VISIBLE', 100, TRUE),
      (gen_random_uuid(), v_fve, 'DefinitionJson',  'Workflow Definition','string',   'Internal', 'HIDDEN',  110, TRUE),
      (gen_random_uuid(), v_fve, 'StateJson',       'State Snapshot',     'string',   'Internal', 'HIDDEN',  120, TRUE);

    INSERT INTO field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT gen_random_uuid(), f.id, (SELECT id FROM permission_definition WHERE permission_key = 'workflows:read'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM field_visibility_field f WHERE f.field_visibility_entity_id = v_fve AND f.sensitivity_level = 'Public';

    INSERT INTO field_visibility_rule (id, field_visibility_field_id, permission_definition_id, visibility_state, obfuscation_type, priority, created_by)
    SELECT gen_random_uuid(), f.id, (SELECT id FROM permission_definition WHERE permission_key = 'workflows:use'), 'VISIBLE', 'NONE', 10, 'seed'
    FROM field_visibility_field f WHERE f.field_visibility_entity_id = v_fve AND f.sensitivity_level = 'Internal';
  END IF;
END $$;

\echo 'Field Visibility seed data loaded.';

-- ====================================================================
-- Field Groups seed (idempotent)
-- One "All Fields" group per entity; every field added as a member.
-- ====================================================================
INSERT INTO field_group (field_visibility_entity_id, group_key, display_name, description, sort_order, created_by)
SELECT fve.id,
       regexp_replace(lower(fve.entity_type), 'dto$', '') || '-all-fields',
       'All Fields',
       'Default group containing all ' || fve.display_name || ' fields',
       10,
       'seed'
FROM field_visibility_entity fve
WHERE fve.is_current AND NOT fve.is_deleted
  AND NOT EXISTS (
    SELECT 1 FROM field_group g
    WHERE g.field_visibility_entity_id = fve.id
      AND g.is_current AND NOT g.is_deleted
  );

INSERT INTO field_group_member (field_group_id, field_visibility_field_id, created_by)
SELECT fg.id, fvf.id, 'seed'
FROM field_visibility_field fvf
JOIN field_group fg
  ON fg.field_visibility_entity_id = fvf.field_visibility_entity_id
 AND fg.is_current AND NOT fg.is_deleted
WHERE fvf.is_current AND NOT fvf.is_deleted
  AND NOT EXISTS (
    SELECT 1 FROM field_group_member m
    WHERE m.field_group_id            = fg.id
      AND m.field_visibility_field_id = fvf.id
      AND m.is_current AND NOT m.is_deleted
  );

\echo 'Field Groups seed data loaded.';

-- ====================================================================
-- App Resource Authorization seed (idempotent)
-- ====================================================================
DO $$ DECLARE
    -- Legacy nav groups (kept for backward compat; nav handler excludes them)
    grpMain  UUID; grpAdmin UUID;
    -- Top-level flat MENU_ITEMs
    rDash UUID; rSec UUID; rIssuers UUID; rWork UUID; rHist UUID;
    rPricing UUID; rImports UUID; rJobs UUID;
    -- Ratings group + children
    rRatings UUID; rRatingsConfig UUID; rRatingRules UUID; rRatingScales UUID;
    -- Portfolios group + children
    rPortfolios UUID; rPortfSec UUID; rPortfList UUID; rPortfCli UUID;
    -- Admin group + sections + children
    rAdmin UUID;
    rFvSection UUID; rArSection UUID; rPermSection UUID; rSysSection UUID;
    rFvEntities UUID; rFvFields UUID; rFvRules UUID; rFvMatrix UUID; rFvGroups UUID;
    rArResources UUID; rArRules UUID; rArGroups UUID; rArMatrix UUID;
    rPermCatalog UUID; rPermBundles UUID; rPermTemplates UUID; rPermEntScr UUID;
    rAuthPreview UUID; rAuditHist UUID; rMenuOrder UUID;
    rWorkflows UUID; rVendorSrc UUID; rDeadLetters UUID;
    -- Routes
    rtMenuOrder UUID;
    rtDash UUID; rtSec UUID; rtIssuers UUID; rtWork UUID; rtHist UUID;
    rtRatings UUID; rtRatingCalc UUID;
    rtPricing UUID; rtPricingRules UUID;
    rtImports UUID; rtImportNew UUID; rtImportProfs UUID;
    rtJobsList UUID; rtJobDetail UUID;
    rtPortfolios UUID; rtPortfClients UUID; rtPortfPositions UUID;
    rtAdmin UUID;
    rtAdminFvEntities UUID; rtAdminFvFields UUID; rtAdminFvRules UUID;
    rtAdminFvMatrix UUID; rtAdminFvGroups UUID;
    rtAdminArResources UUID; rtAdminArRules UUID; rtAdminArGroups UUID; rtAdminArMatrix UUID;
    rtAdminPermCatalog UUID; rtAdminPermBundles UUID; rtAdminPermTemplates UUID; rtAdminPermEntScr UUID;
    rtAdminAuthPreview UUID; rtAdminAuditHistory UUID;
    rtAdminDeadLetters UUID; rtAdminWorkflows UUID; rtAdminVendorSrc UUID;
    rtAdminRatingRules UUID; rtAdminRatingScales UUID;
    -- Actions
    actCreate UUID; actEdit UUID; actDelete UUID; actExport UUID;
    actRatingTrigger UUID; actPricingImport UUID; actImportRun UUID; actWfSubmit UUID;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM app_resource WHERE resource_key = 'nav.dashboard') THEN

    -- ── Legacy nav groups (nav handler skips group.main / group.admin) ─────────
    grpMain  := gen_random_uuid();
    grpAdmin := gen_random_uuid();
    INSERT INTO app_resource (id, resource_type, resource_key, display_name, description, icon_name,
                               default_visibility_state, default_execution_state, is_security_sensitive, sort_order)
    VALUES
        (grpMain,  'MENU_GROUP', 'group.main',  'Main Navigation', 'Primary application navigation items', 'menu',                 'VISIBLE', 'ALLOW', FALSE, 10),
        (grpAdmin, 'MENU_GROUP', 'group.admin', 'Administration',  'Admin-only management screens',        'admin_panel_settings', 'HIDDEN',  'DENY',  TRUE,  90);

    -- ── Top-level flat MENU_ITEMs (parent_app_resource_id = NULL) ──────────────
    rDash    := gen_random_uuid(); rSec     := gen_random_uuid(); rIssuers := gen_random_uuid();
    rWork    := gen_random_uuid(); rHist    := gen_random_uuid();
    rPricing := gen_random_uuid(); rImports := gen_random_uuid(); rJobs    := gen_random_uuid();
    INSERT INTO app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (rDash,    'MENU_ITEM', 'nav.dashboard',  'Dashboard',  'dashboard',       '/dashboard',  NULL, 10, 'VISIBLE', 'ALLOW', FALSE, TRUE),
        (rSec,     'MENU_ITEM', 'nav.securities', 'Securities', 'security',        '/securities', NULL, 20, 'VISIBLE', 'ALLOW', FALSE, TRUE),
        (rIssuers, 'MENU_ITEM', 'nav.issuers',    'Issuers',    'account_balance', '/issuers',    NULL, 30, 'HIDDEN',  'DENY',  FALSE, TRUE),
        (rPricing, 'MENU_ITEM', 'nav.pricing',    'Pricing',    'attach_money',    '/pricing',    NULL, 50, 'HIDDEN',  'DENY',  FALSE, TRUE),
        (rImports, 'MENU_ITEM', 'nav.imports',    'Imports',    'upload_file',     '/imports',    NULL, 60, 'HIDDEN',  'DENY',  FALSE, TRUE),
        (rJobs,    'MENU_ITEM', 'nav.jobs',       'Jobs',       'schedule',        '/jobs',       NULL, 70, 'HIDDEN',  'DENY',  FALSE, TRUE),
        (rWork,    'MENU_ITEM', 'nav.workflows',  'Workflows',  'account_tree',    '/workflows',  NULL, 80, 'HIDDEN',  'DENY',  FALSE, TRUE),
        (rHist,    'MENU_ITEM', 'nav.history',    'History',    'history',         '/history',    NULL, 90, 'VISIBLE', 'ALLOW', FALSE, TRUE);

    -- ── Ratings MENU_GROUP (sort_order=40) ─────────────────────────────────────
    rRatings := gen_random_uuid();
    INSERT INTO app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (rRatings, 'MENU_GROUP', 'nav.ratings', 'Ratings', 'star_rate', NULL, NULL, 40, 'VISIBLE', 'ALLOW', FALSE, TRUE);

    rRatingsConfig := gen_random_uuid();
    INSERT INTO app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (rRatingsConfig, 'SECTION', 'nav.ratings.config', 'Configuration', NULL, NULL, rRatings, 10, 'VISIBLE', 'ALLOW', FALSE, TRUE);

    rRatingRules := gen_random_uuid(); rRatingScales := gen_random_uuid();
    INSERT INTO app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (rRatingRules,  'MENU_ITEM', 'nav.ratings.rules',  'Derivation Rules', NULL, '/ratings/rules',  rRatingsConfig, 10, 'VISIBLE', 'ALLOW', FALSE, TRUE),
        (rRatingScales, 'MENU_ITEM', 'nav.ratings.scales', 'Rating Scales',    NULL, '/ratings/scales', rRatingsConfig, 20, 'VISIBLE', 'ALLOW', FALSE, TRUE);

    -- ── Portfolios MENU_GROUP (sort_order=45) ──────────────────────────────────
    rPortfolios := gen_random_uuid();
    INSERT INTO app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (rPortfolios, 'MENU_GROUP', 'nav.portfolios', 'Portfolios', 'account_balance_wallet', NULL, NULL, 45, 'HIDDEN', 'DENY', FALSE, TRUE);

    rPortfSec := gen_random_uuid();
    INSERT INTO app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (rPortfSec, 'SECTION', 'nav.portfolios.main', 'Portfolios', NULL, NULL, rPortfolios, 10, 'HIDDEN', 'DENY', FALSE, TRUE);

    rPortfList := gen_random_uuid(); rPortfCli := gen_random_uuid();
    INSERT INTO app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (rPortfList, 'MENU_ITEM', 'nav.portfolios.list',    'Portfolios', NULL, '/portfolios',         rPortfSec, 10, 'HIDDEN', 'DENY', FALSE, TRUE),
        (rPortfCli,  'MENU_ITEM', 'nav.portfolios.clients', 'Clients',    NULL, '/portfolios/clients', rPortfSec, 20, 'HIDDEN', 'DENY', FALSE, TRUE);

    -- ── Admin MENU_GROUP (sort_order=200) ──────────────────────────────────────
    rAdmin := gen_random_uuid();
    INSERT INTO app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (rAdmin, 'MENU_GROUP', 'nav.admin', 'Admin', 'admin_panel_settings', NULL, NULL, 200, 'HIDDEN', 'DENY', TRUE, TRUE);

    rFvSection := gen_random_uuid(); rArSection := gen_random_uuid(); rPermSection := gen_random_uuid(); rSysSection := gen_random_uuid();
    INSERT INTO app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (rFvSection,   'SECTION', 'nav.admin.fv',     'Field Visibility', NULL, NULL, rAdmin, 10, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rArSection,   'SECTION', 'nav.admin.ar',     'App Resources',    NULL, NULL, rAdmin, 20, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rPermSection, 'SECTION', 'nav.admin.perm',   'Permissions',      NULL, NULL, rAdmin, 30, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rSysSection,  'SECTION', 'nav.admin.system', 'System',           NULL, NULL, rAdmin, 40, 'HIDDEN', 'DENY', TRUE, TRUE);

    rFvEntities    := gen_random_uuid(); rFvFields      := gen_random_uuid(); rFvRules      := gen_random_uuid();
    rFvMatrix      := gen_random_uuid(); rFvGroups      := gen_random_uuid();
    rArResources   := gen_random_uuid(); rArRules       := gen_random_uuid();
    rArGroups      := gen_random_uuid(); rArMatrix      := gen_random_uuid();
    rPermCatalog   := gen_random_uuid(); rPermBundles   := gen_random_uuid();
    rPermTemplates := gen_random_uuid(); rPermEntScr    := gen_random_uuid();
    rAuthPreview   := gen_random_uuid();
    rAuditHist     := gen_random_uuid(); rMenuOrder     := gen_random_uuid();
    rWorkflows     := gen_random_uuid(); rVendorSrc     := gen_random_uuid(); rDeadLetters := gen_random_uuid();
    INSERT INTO app_resource
        (id, resource_type, resource_key, display_name, icon_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (rFvEntities,    'MENU_ITEM', 'nav.admin.fv.entities',         'Entities',            NULL, '/admin/fv/entities',                  rFvSection,   10, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rFvFields,      'MENU_ITEM', 'nav.admin.fv.fields',           'Fields',              NULL, '/admin/fv/fields',                    rFvSection,   20, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rFvRules,       'MENU_ITEM', 'nav.admin.fv.rules',            'Field Rules',         NULL, '/admin/fv/rules',                     rFvSection,   30, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rFvMatrix,      'MENU_ITEM', 'nav.admin.fv.matrix',           'FV Matrix',           NULL, '/admin/fv/matrix',                    rFvSection,   40, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rFvGroups,      'MENU_ITEM', 'nav.admin.fv.groups',           'Field Groups',        NULL, '/admin/fv/groups',                    rFvSection,   50, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rArResources,   'MENU_ITEM', 'nav.admin.ar.resources',        'Resources',           NULL, '/admin/ar/resources',                 rArSection,   10, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rArRules,       'MENU_ITEM', 'nav.admin.ar.rules',            'Resource Rules',      NULL, '/admin/ar/rules',                     rArSection,   20, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rArGroups,      'MENU_ITEM', 'nav.admin.ar.groups',           'Resource Groups',     NULL, '/admin/ar/groups',                    rArSection,   30, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rArMatrix,      'MENU_ITEM', 'nav.admin.ar.matrix',           'AR Matrix',           NULL, '/admin/ar/matrix',                    rArSection,   40, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rPermCatalog,   'MENU_ITEM', 'nav.admin.perm.catalog',        'Permission Catalog',  NULL, '/admin/permissions/catalog',          rPermSection, 10, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rPermBundles,   'MENU_ITEM', 'nav.admin.perm.bundles',        'Bundles',             NULL, '/admin/permissions/bundles',          rPermSection, 20, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rPermTemplates, 'MENU_ITEM', 'nav.admin.perm.templates',      'Policy Templates',    NULL, '/admin/permissions/templates',        rPermSection, 30, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rPermEntScr,    'MENU_ITEM', 'nav.admin.perm.entity-screens', 'Entity Screens',      NULL, '/admin/permissions/entity-screens',   rPermSection, 40, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rWorkflows,     'MENU_ITEM', 'nav.admin.workflows',           'Workflow Definitions',NULL, '/admin/workflows',                    rSysSection,  10, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rVendorSrc,     'MENU_ITEM', 'nav.admin.vendor-sources',      'Vendor Sources',      NULL, '/admin/vendor-sources',               rSysSection,  20, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rDeadLetters,   'MENU_ITEM', 'nav.admin.dead-letters',        'Dead Letters',        NULL, '/admin/dead-letters',                 rSysSection,  30, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rAuthPreview,   'MENU_ITEM', 'nav.admin.auth-preview',        'Auth Preview',        NULL, '/admin/auth-preview',                 rAdmin,       80, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rAuditHist,     'MENU_ITEM', 'nav.admin.audit-history',       'Audit History',       NULL, '/admin/audit-history',                rAdmin,       90, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rMenuOrder,     'MENU_ITEM', 'nav.admin.menu-order',          'Menu Order',          NULL, '/admin/nav/menu-order',               rAdmin,       70, 'HIDDEN', 'DENY', TRUE, TRUE);

    -- ── Routes ─────────────────────────────────────────────────────────────────
    rtMenuOrder := gen_random_uuid();
    INSERT INTO app_resource
        (id, resource_type, resource_key, display_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (rtMenuOrder, 'ROUTE', 'route./admin/nav/menu-order', 'Menu Order Route', '/admin/nav/menu-order', NULL, 71, 'HIDDEN', 'DENY', TRUE, TRUE);

    rtDash           := gen_random_uuid(); rtSec            := gen_random_uuid(); rtIssuers        := gen_random_uuid();
    rtWork           := gen_random_uuid(); rtHist           := gen_random_uuid();
    rtRatings        := gen_random_uuid(); rtRatingCalc     := gen_random_uuid();
    rtPricing        := gen_random_uuid(); rtPricingRules   := gen_random_uuid();
    rtImports        := gen_random_uuid(); rtImportNew      := gen_random_uuid(); rtImportProfs    := gen_random_uuid();
    rtJobsList       := gen_random_uuid(); rtJobDetail      := gen_random_uuid();
    rtPortfolios     := gen_random_uuid(); rtPortfClients   := gen_random_uuid(); rtPortfPositions := gen_random_uuid();
    rtAdmin              := gen_random_uuid();
    rtAdminFvEntities    := gen_random_uuid(); rtAdminFvFields    := gen_random_uuid(); rtAdminFvRules    := gen_random_uuid();
    rtAdminFvMatrix      := gen_random_uuid(); rtAdminFvGroups    := gen_random_uuid();
    rtAdminArResources   := gen_random_uuid(); rtAdminArRules     := gen_random_uuid();
    rtAdminArGroups      := gen_random_uuid(); rtAdminArMatrix    := gen_random_uuid();
    rtAdminPermCatalog   := gen_random_uuid(); rtAdminPermBundles := gen_random_uuid();
    rtAdminPermTemplates := gen_random_uuid(); rtAdminPermEntScr  := gen_random_uuid();
    rtAdminAuthPreview   := gen_random_uuid(); rtAdminAuditHistory := gen_random_uuid();
    rtAdminDeadLetters   := gen_random_uuid(); rtAdminWorkflows   := gen_random_uuid();
    rtAdminVendorSrc     := gen_random_uuid();
    rtAdminRatingRules   := gen_random_uuid(); rtAdminRatingScales := gen_random_uuid();

    INSERT INTO app_resource
        (id, resource_type, resource_key, display_name, route_path,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (rtDash,             'ROUTE', 'route./dashboard',               'Dashboard Route',           '/dashboard',               NULL, 10,  'VISIBLE', 'ALLOW', FALSE, TRUE),
        (rtSec,              'ROUTE', 'route./securities',              'Securities Route',          '/securities',              NULL, 20,  'VISIBLE', 'ALLOW', FALSE, TRUE),
        (rtIssuers,          'ROUTE', 'route./issuers',                 'Issuers Route',             '/issuers',                 NULL, 30,  'HIDDEN',  'DENY',  FALSE, TRUE),
        (rtWork,             'ROUTE', 'route./workflows',               'Workflows Route',           '/workflows',               NULL, 80,  'HIDDEN',  'DENY',  FALSE, TRUE),
        (rtHist,             'ROUTE', 'route./history',                 'History Route',             '/history',                 NULL, 90,  'VISIBLE', 'ALLOW', FALSE, TRUE),
        (rtRatings,          'ROUTE', 'route./ratings',                 'Ratings Route',             '/ratings',                 NULL, 40,  'HIDDEN',  'DENY',  FALSE, TRUE),
        (rtRatingCalc,       'ROUTE', 'route./ratings/new-calculation', 'Trigger Calculation Route', '/ratings/new-calculation', NULL, 41,  'HIDDEN',  'DENY',  TRUE,  TRUE),
        (rtPricing,          'ROUTE', 'route./pricing',                 'Pricing Route',             '/pricing',                 NULL, 50,  'HIDDEN',  'DENY',  FALSE, TRUE),
        (rtPricingRules,     'ROUTE', 'route./pricing/rules',           'Pricing Rules Route',       '/pricing/rules',           NULL, 51,  'HIDDEN',  'DENY',  FALSE, TRUE),
        (rtImports,          'ROUTE', 'route./imports',                 'Imports Route',             '/imports',                 NULL, 60,  'HIDDEN',  'DENY',  FALSE, TRUE),
        (rtImportNew,        'ROUTE', 'route./imports/new',             'Trigger Import Route',      '/imports/new',             NULL, 61,  'HIDDEN',  'DENY',  TRUE,  TRUE),
        (rtImportProfs,      'ROUTE', 'route./imports/profiles',        'Import Profiles Route',     '/imports/profiles',        NULL, 62,  'HIDDEN',  'DENY',  FALSE, TRUE),
        (rtJobsList,         'ROUTE', 'route./jobs',                    'Jobs Route',                '/jobs',                    NULL, 70,  'HIDDEN',  'DENY',  FALSE, TRUE),
        (rtJobDetail,        'ROUTE', 'route./jobs/detail',             'Job Detail Route',          '/jobs/:id',                NULL, 71,  'HIDDEN',  'DENY',  FALSE, TRUE),
        (rtPortfolios,       'ROUTE', 'route./portfolios',              'Portfolios Route',          '/portfolios',              NULL, 45,  'HIDDEN',  'DENY',  FALSE, TRUE),
        (rtPortfClients,     'ROUTE', 'route./portfolios/clients',      'Clients Route',             '/portfolios/clients',      NULL, 46,  'HIDDEN',  'DENY',  FALSE, TRUE),
        (rtPortfPositions,   'ROUTE', 'route./portfolios/positions',    'Positions Route',           '/portfolios/:id/positions',NULL, 47,  'HIDDEN',  'DENY',  FALSE, TRUE),
        (rtAdmin,            'ROUTE', 'route./admin',                              'Admin',                       '/admin',                          NULL, 200, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminFvEntities,  'ROUTE', 'route./admin/fv/entities',                  'Admin FV Entities',           '/admin/fv/entities',              NULL, 201, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminFvFields,    'ROUTE', 'route./admin/fv/fields',                    'Admin FV Fields',             '/admin/fv/fields',                NULL, 202, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminFvRules,     'ROUTE', 'route./admin/fv/rules',                     'Admin FV Rules',              '/admin/fv/rules',                 NULL, 203, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminFvMatrix,    'ROUTE', 'route./admin/fv/matrix',                    'Admin FV Matrix',             '/admin/fv/matrix',                NULL, 204, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminFvGroups,    'ROUTE', 'route./admin/fv/groups',                    'Admin FV Groups',             '/admin/fv/groups',                NULL, 205, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminArResources, 'ROUTE', 'route./admin/ar/resources',                 'Admin AR Resources',          '/admin/ar/resources',             NULL, 210, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminArRules,     'ROUTE', 'route./admin/ar/rules',                     'Admin AR Rules',              '/admin/ar/rules',                 NULL, 211, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminArGroups,    'ROUTE', 'route./admin/ar/groups',                    'Admin AR Groups',             '/admin/ar/groups',                NULL, 212, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminArMatrix,    'ROUTE', 'route./admin/ar/matrix',                    'Admin AR Matrix',             '/admin/ar/matrix',                NULL, 213, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminPermCatalog, 'ROUTE', 'route./admin/permissions/catalog',          'Admin Perm Catalog',          '/admin/permissions/catalog',      NULL, 220, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminPermBundles, 'ROUTE', 'route./admin/permissions/bundles',          'Admin Perm Bundles',          '/admin/permissions/bundles',      NULL, 221, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminPermTemplates,'ROUTE','route./admin/permissions/templates',        'Admin Perm Templates',        '/admin/permissions/templates',    NULL, 222, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminPermEntScr,  'ROUTE', 'route./admin/permissions/entity-screens',   'Admin Perm Entity Screens',   '/admin/permissions/entity-screens',NULL,223, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminAuthPreview, 'ROUTE', 'route./admin/auth-preview',                 'Admin Auth Preview',          '/admin/auth-preview',             NULL, 230, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminAuditHistory,'ROUTE', 'route./admin/audit-history',                'Admin Audit History',         '/admin/audit-history',            NULL, 231, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminDeadLetters, 'ROUTE', 'route./admin/dead-letters',                 'Admin Dead Letters',          '/admin/dead-letters',             NULL, 232, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminWorkflows,   'ROUTE', 'route./admin/workflows',                    'Admin Workflow Definitions',  '/admin/workflows',                NULL, 233, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminVendorSrc,   'ROUTE', 'route./admin/vendor-sources',               'Admin Vendor Sources',        '/admin/vendor-sources',           NULL, 234, 'HIDDEN', 'DENY', TRUE, TRUE),
        (rtAdminRatingRules, 'ROUTE', 'route./ratings/rules',                      'Rating Rules',                '/ratings/rules',                  NULL, 240, 'HIDDEN', 'DENY', FALSE, TRUE),
        (rtAdminRatingScales,'ROUTE', 'route./ratings/scales',                     'Rating Scales',               '/ratings/scales',                 NULL, 241, 'HIDDEN', 'DENY', FALSE, TRUE);

    -- ── Actions ────────────────────────────────────────────────────────────────
    actCreate := gen_random_uuid(); actEdit   := gen_random_uuid();
    actDelete := gen_random_uuid(); actExport := gen_random_uuid();
    actRatingTrigger := gen_random_uuid(); actPricingImport := gen_random_uuid();
    actImportRun     := gen_random_uuid(); actWfSubmit      := gen_random_uuid();
    INSERT INTO app_resource
        (id, resource_type, resource_key, display_name,
         parent_app_resource_id, sort_order,
         default_visibility_state, default_execution_state, is_security_sensitive, is_active)
    VALUES
        (actCreate,        'ACTION', 'security.create',       'Create Security',            NULL, 110, 'HIDDEN', 'DENY', TRUE, TRUE),
        (actEdit,          'ACTION', 'security.edit',         'Edit Security',              NULL, 120, 'HIDDEN', 'DENY', TRUE, TRUE),
        (actDelete,        'ACTION', 'security.delete',       'Delete Security',            NULL, 130, 'HIDDEN', 'DENY', TRUE, TRUE),
        (actExport,        'ACTION', 'security.export',       'Export Securities',          NULL, 140, 'HIDDEN', 'DENY', TRUE, TRUE),
        (actRatingTrigger, 'ACTION', 'ratings.trigger',       'Trigger Rating Calculation', NULL, 260, 'HIDDEN', 'DENY', TRUE, TRUE),
        (actPricingImport, 'ACTION', 'pricing.import-prices', 'Import / Re-derive Prices',  NULL, 272, 'HIDDEN', 'DENY', TRUE, TRUE),
        (actImportRun,     'ACTION', 'imports.run',           'Run Import',                 NULL, 283, 'HIDDEN', 'DENY', TRUE, TRUE),
        (actWfSubmit,      'ACTION', 'workflows.submit',      'Submit Workflow Decision',   NULL, 310, 'HIDDEN', 'DENY', FALSE, TRUE);

  END IF;
END $$;

-- ── App Resource Rules (idempotent, resource_key JOIN — safe outside DO block) ──
-- Mirrors the SQL Server idempotent catch-up pattern exactly.
INSERT INTO app_resource_rule
    (id, app_resource_id, permission_definition_id, visibility_state, execution_state, priority, created_by)
SELECT gen_random_uuid(), ar.id, pd.id, v.vs, v.es, v.pri, 'seed'
FROM (VALUES
    -- Public (securities:read is the base permission for all authenticated users)
    ('nav.dashboard',                          'securities:read',            'VISIBLE', 'ALLOW', 100),
    ('nav.securities',                         'securities:read',            'VISIBLE', 'ALLOW', 100),
    ('nav.history',                            'securities:read',            'VISIBLE', 'ALLOW', 100),
    ('route./dashboard',                       'securities:read',            'VISIBLE', 'ALLOW', 100),
    ('route./securities',                      'securities:read',            'VISIBLE', 'ALLOW', 100),
    ('route./history',                         'securities:read',            'VISIBLE', 'ALLOW', 100),
    -- Issuers
    ('nav.issuers',                            'issuers:read',               'VISIBLE', 'ALLOW', 100),
    ('route./issuers',                         'issuers:read',               'VISIBLE', 'ALLOW', 100),
    -- Workflows
    ('nav.workflows',                          'workflows:read',             'VISIBLE', 'ALLOW', 100),
    ('route./workflows',                       'workflows:read',             'VISIBLE', 'ALLOW', 100),
    -- Ratings
    ('nav.ratings',                            'ratings:read',               'VISIBLE', 'ALLOW', 100),
    ('nav.ratings.config',                     'ratings:read',               'VISIBLE', 'ALLOW', 100),
    ('nav.ratings.rules',                      'ratings:read',               'VISIBLE', 'ALLOW', 100),
    ('nav.ratings.scales',                     'ratings:read',               'VISIBLE', 'ALLOW', 100),
    ('route./ratings',                         'ratings:read',               'VISIBLE', 'ALLOW', 100),
    ('route./ratings/rules',                   'ratings:read',               'VISIBLE', 'ALLOW', 100),
    ('route./ratings/scales',                  'ratings:read',               'VISIBLE', 'ALLOW', 100),
    ('route./ratings/new-calculation',         'ratings:write',              'VISIBLE', 'ALLOW', 100),
    ('ratings.trigger',                        'ratings:write',              'VISIBLE', 'ALLOW', 100),
    -- Pricing
    ('nav.pricing',                            'pricing:read',               'VISIBLE', 'ALLOW', 100),
    ('route./pricing',                         'pricing:read',               'VISIBLE', 'ALLOW', 100),
    ('route./pricing/rules',                   'pricing:read',               'VISIBLE', 'ALLOW', 100),
    ('pricing.import-prices',                  'pricing:write',              'VISIBLE', 'ALLOW', 100),
    -- Imports
    ('nav.imports',                            'imports:read',               'VISIBLE', 'ALLOW', 100),
    ('route./imports',                         'imports:read',               'VISIBLE', 'ALLOW', 100),
    ('route./imports/profiles',                'imports:read',               'VISIBLE', 'ALLOW', 100),
    ('route./imports/new',                     'imports:run',                'VISIBLE', 'ALLOW', 100),
    ('imports.run',                            'imports:run',                'VISIBLE', 'ALLOW', 100),
    -- Workflows:use
    ('workflows.submit',                       'workflows:use',              'VISIBLE', 'ALLOW', 100),
    -- Jobs
    ('nav.jobs',                               'jobs:read',                  'VISIBLE', 'ALLOW', 100),
    ('route./jobs',                            'jobs:read',                  'VISIBLE', 'ALLOW', 100),
    ('route./jobs/detail',                     'jobs:read',                  'VISIBLE', 'ALLOW', 100),
    -- Portfolios (portfolios:read)
    ('nav.portfolios',                         'portfolios:read',            'VISIBLE', 'ALLOW', 100),
    ('nav.portfolios.main',                    'portfolios:read',            'VISIBLE', 'ALLOW', 100),
    ('nav.portfolios.list',                    'portfolios:read',            'VISIBLE', 'ALLOW', 100),
    ('nav.portfolios.clients',                 'portfolios:read',            'VISIBLE', 'ALLOW', 100),
    ('route./portfolios',                      'portfolios:read',            'VISIBLE', 'ALLOW', 100),
    ('route./portfolios/clients',              'portfolios:read',            'VISIBLE', 'ALLOW', 100),
    ('route./portfolios/positions',            'portfolios:read',            'VISIBLE', 'ALLOW', 100),
    -- Portfolios (admin:super)
    ('nav.portfolios',                         'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.portfolios.main',                    'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.portfolios.list',                    'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.portfolios.clients',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./portfolios',                      'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./portfolios/clients',              'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./portfolios/positions',            'admin:super',                'VISIBLE', 'ALLOW', 100),
    -- Security actions
    ('security.create',                        'securities:write',           'VISIBLE', 'ALLOW', 100),
    ('security.edit',                          'securities:write',           'VISIBLE', 'ALLOW', 100),
    ('security.delete',                        'securities:delete',          'VISIBLE', 'ALLOW', 100),
    ('security.export',                        'exports:run',                'VISIBLE', 'ALLOW', 100),
    -- Admin group and menu items
    ('nav.admin',                              'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('nav.admin.fv.entities',                  'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
    ('nav.admin.fv.fields',                    'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
    ('nav.admin.fv.rules',                     'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
    ('nav.admin.fv.matrix',                    'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
    ('nav.admin.fv.groups',                    'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
    ('nav.admin.ar.resources',                 'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
    ('nav.admin.ar.rules',                     'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
    ('nav.admin.ar.groups',                    'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
    ('nav.admin.ar.matrix',                    'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
    ('nav.admin.perm.catalog',                 'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
    ('nav.admin.perm.bundles',                 'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
    ('nav.admin.perm.templates',               'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
    ('nav.admin.perm.entity-screens',          'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
    ('nav.admin.workflows',                    'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('nav.admin.vendor-sources',               'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('nav.admin.dead-letters',                 'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('nav.admin.auth-preview',                 'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('nav.admin.audit-history',                'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('nav.admin.menu-order',                   'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('route./admin/nav/menu-order',            'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    -- Admin routes
    ('route./admin',                           'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('route./admin/fv/entities',               'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
    ('route./admin/fv/fields',                 'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
    ('route./admin/fv/rules',                  'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
    ('route./admin/fv/matrix',                 'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
    ('route./admin/fv/groups',                 'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
    ('route./admin/ar/resources',              'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
    ('route./admin/ar/rules',                  'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
    ('route./admin/ar/groups',                 'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
    ('route./admin/ar/matrix',                 'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
    ('route./admin/permissions/catalog',       'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
    ('route./admin/permissions/bundles',       'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
    ('route./admin/permissions/templates',     'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
    ('route./admin/permissions/entity-screens','admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
    ('route./admin/auth-preview',              'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('route./admin/audit-history',             'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('route./admin/dead-letters',              'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('route./admin/workflows',                 'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('route./admin/vendor-sources',            'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('route./ratings/rules',                  'ratings:manage',             'VISIBLE', 'ALLOW', 100),
    ('route./ratings/scales',                  'ratings:manage',             'VISIBLE', 'ALLOW', 100),
    -- Sections need rules so the nav handler includes them
    ('nav.admin.fv',                           'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
    ('nav.admin.fv',                           'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('nav.admin.ar',                           'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
    ('nav.admin.ar',                           'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('nav.admin.perm',                         'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
    ('nav.admin.perm',                         'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('nav.admin.system',                       'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('nav.portfolios.main',                    'portfolios:read',            'VISIBLE', 'ALLOW', 100),
    ('nav.portfolios.main',                    'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.ratings.config',                     'ratings:read',               'VISIBLE', 'ALLOW', 100),
    -- Admin resources also visible to admin:super (so admin@securityapp.local sees everything)
    ('group.admin',                            'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin',                              'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.fv',                           'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.fv.entities',                  'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.fv.fields',                    'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.fv.rules',                     'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.fv.matrix',                    'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.fv.groups',                    'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.ar',                           'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.ar.resources',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.ar.rules',                     'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.ar.groups',                    'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.ar.matrix',                    'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.perm',                         'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.perm.catalog',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.perm.bundles',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.perm.templates',               'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.perm.entity-screens',          'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.system',                       'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.workflows',                    'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.vendor-sources',               'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.dead-letters',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.auth-preview',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.audit-history',                'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('nav.admin.menu-order',                   'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/nav/menu-order',            'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin',                           'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/fv/entities',               'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/fv/fields',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/fv/rules',                  'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/fv/matrix',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/fv/groups',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/ar/resources',              'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/ar/rules',                  'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/ar/groups',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/ar/matrix',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/permissions/catalog',       'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/permissions/bundles',       'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/permissions/templates',     'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/permissions/entity-screens','admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/auth-preview',              'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/audit-history',             'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/dead-letters',              'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/workflows',                 'admin:super',                'VISIBLE', 'ALLOW', 100),
    ('route./admin/vendor-sources',            'admin:super',                'VISIBLE', 'ALLOW', 100)
) AS v(rkey, pkey, vs, es, pri)
JOIN app_resource        ar ON ar.resource_key    = v.rkey AND ar.is_current = TRUE AND ar.is_deleted = FALSE
JOIN permission_definition pd ON pd.permission_key = v.pkey
WHERE NOT EXISTS (
    SELECT 1 FROM app_resource_rule
    WHERE app_resource_id        = ar.id
      AND permission_definition_id = pd.id
      AND is_current = TRUE AND is_deleted = FALSE
);

\echo 'App Resource Authorization seed data loaded.';

-- ====================================================================
-- App Resource Groups (idempotent)
-- ====================================================================
INSERT INTO app_resource_group
    (group_key, display_name, description, icon_name, sort_order, created_by)
SELECT v.group_key, v.display_name, v.description, v.icon_name, v.sort_order, 'seed'
FROM (VALUES
    ('nav-main',         'Main Navigation',   'Top-level navigation visible to all users',         'menu',                  10),
    ('nav-admin',        'Admin Navigation',  'Navigation items within the administration area',   'admin_panel_settings',  20),
    ('routes-feature',   'Feature Routes',    'User-facing application page routes',               'route',                 30),
    ('routes-admin',     'Admin Routes',      'Administration page routes',                        'settings',              40),
    ('actions-security', 'Security Actions',  'CRUD and export actions on securities',             'shield',                50),
    ('actions-feature',  'Feature Actions',   'Operational actions: ratings, pricing, imports',    'bolt',                  60)
) AS v(group_key, display_name, description, icon_name, sort_order)
WHERE NOT EXISTS (
    SELECT 1 FROM app_resource_group g
    WHERE g.group_key = v.group_key AND g.is_current = TRUE AND g.is_deleted = FALSE
);

\echo 'App Resource Groups seed data loaded.';

-- ====================================================================
-- Entity Screens (idempotent)
-- ====================================================================
INSERT INTO entity_screen
    (screen_key, display_name, description, app_resource_id, sort_order, created_by)
SELECT v.screen_key, v.display_name, v.description, ar.id, v.sort_order, 'seed'
FROM (VALUES
    ('screen.dashboard',         'Dashboard',                'Main dashboard overview',                   'route./dashboard',                  10),
    ('screen.securities',        'Securities',               'Securities list and management',             'route./securities',                 20),
    ('screen.issuers',           'Issuers',                  'Issuers list and management',                'route./issuers',                    30),
    ('screen.ratings',           'Ratings',                  'Ratings overview and calculations',          'route./ratings',                    40),
    ('screen.pricing',           'Pricing',                  'Pricing overview and rules',                 'route./pricing',                    50),
    ('screen.portfolios',        'Portfolios',               'Portfolio management',                       'route./portfolios',                 60),
    ('screen.imports',           'Imports',                  'Data import management',                     'route./imports',                    70),
    ('screen.jobs',              'Jobs',                     'Background job monitoring',                  'route./jobs',                       80),
    ('screen.workflows',         'Workflows',                'Workflow instance management',               'route./workflows',                  90),
    ('screen.history',           'History',                  'Audit and change history',                   'route./history',                    100),
    ('screen.admin',             'Admin',                    'Administration landing page',                'route./admin',                      200),
    ('screen.admin.fv',          'Admin - Field Visibility', 'Field visibility configuration',             'route./admin/fv/entities',          210),
    ('screen.admin.ar',          'Admin - App Resources',    'App resource and rule management',           'route./admin/ar/resources',         220),
    ('screen.admin.permissions', 'Admin - Permissions',      'Permission catalog, bundles and templates',  'route./admin/permissions/catalog',  230),
    ('screen.admin.monitoring',  'Admin - Monitoring',       'Audit history, dead letters and system',     'route./admin/audit-history',        240)
) AS v(screen_key, display_name, description, resource_key, sort_order)
JOIN app_resource ar ON ar.resource_key = v.resource_key AND ar.is_current = TRUE AND ar.is_deleted = FALSE
WHERE NOT EXISTS (
    SELECT 1 FROM entity_screen es
    WHERE es.screen_key = v.screen_key AND es.is_current = TRUE AND es.is_deleted = FALSE
);

\echo 'Entity Screens seed data loaded.';

-- ====================================================================
-- Demo Securities seed (idempotent)
-- ====================================================================

DO $$
DECLARE
    sAapl      UUID := 'a0000001-5eed-0000-0000-000000000001';
    sMsft      UUID := 'a0000001-5eed-0000-0000-000000000002';
    sAaplIsin  UUID := 'a0000001-5eed-0000-0000-000000000003';
    sTsla      UUID := 'a0000001-5eed-0000-0000-000000000004';
    sJpm       UUID := 'a0000001-5eed-0000-0000-000000000005';
    sAppleBond UUID := 'a0000001-5eed-0000-0000-000000000006';
    sMsftBond  UUID := 'a0000001-5eed-0000-0000-000000000007';
    sJpmBond   UUID := 'a0000001-5eed-0000-0000-000000000008';
    sDbBond    UUID := 'a0000001-5eed-0000-0000-000000000009';
    sTbond51   UUID := 'a0000001-5eed-0000-0000-000000000010';
    sTbond24   UUID := 'a0000001-5eed-0000-0000-000000000011';
    sCaBond    UUID := 'a0000001-5eed-0000-0000-000000000012';
    sMtaBond   UUID := 'a0000001-5eed-0000-0000-000000000013';
    sLoan      UUID := 'a0000001-5eed-0000-0000-000000000014';
    sOption    UUID := 'a0000001-5eed-0000-0000-000000000015';
BEGIN
    IF NOT EXISTS (SELECT 1 FROM security_identifier WHERE identifier_type = 'Ticker' AND identifier_value = 'AAPL') THEN

        INSERT INTO security
            (id, data_source, type, name, description, issuer, currency_code, asset_class_code, instrument_type_code, modified_by)
        VALUES
            -- Equities
            (sAapl,      'Manual', 'Equity',        'Apple Inc.',                           'Consumer electronics and software company',        'Apple Inc.',                    'USD', 'EQUITY',     'Equity',        'seed'),
            (sMsft,      'Manual', 'Equity',        'Microsoft Corporation',                'Cloud computing and enterprise software company',  'Microsoft Corporation',          'USD', 'EQUITY',     'Equity',        'seed'),
            (sAaplIsin,  'Manual', 'Equity',        'Apple Inc. (ISIN)',                    'Same issuer, ISIN identifier variant',             'Apple Inc.',                    'USD', 'EQUITY',     'Equity',        'seed'),
            (sTsla,      'Manual', 'Equity',        'Tesla Inc.',                           'Electric vehicles and energy storage company',     'Tesla Inc.',                    'USD', 'EQUITY',     'Equity',        'seed'),
            (sJpm,       'Manual', 'Equity',        'JPMorgan Chase & Co.',                 'Global financial services and investment bank',    'JPMorgan Chase & Co.',          'USD', 'EQUITY',     'Equity',        'seed'),
            -- Corporate Bonds
            (sAppleBond, 'Manual', 'CorporateBond', 'Apple 3.85% 2046',                    'Apple senior unsecured bond maturing 2046',        'Apple Inc.',                    'USD', 'BOND',       'CorporateBond', 'seed'),
            (sMsftBond,  'Manual', 'CorporateBond', 'Microsoft 3.30% 2027',                'Microsoft medium-term note',                       'Microsoft Corporation',          'USD', 'BOND',       'CorporateBond', 'seed'),
            (sJpmBond,   'Manual', 'CorporateBond', 'JPMorgan 4.20% 2047',                 'JPMorgan Chase senior bond',                       'JPMorgan Chase & Co.',          'USD', 'BOND',       'CorporateBond', 'seed'),
            (sDbBond,    'Manual', 'CorporateBond', 'Deutsche Bank 2.75% 2030',            'Deutsche Bank AG senior unsecured EUR bond',       'Deutsche Bank AG',              'EUR', 'BOND',       'CorporateBond', 'seed'),
            -- Treasury Bonds
            (sTbond51,   'Manual', 'TreasuryBond',  'US Treasury 1.875% 2051',             '30-year US Treasury bond',                        'US Department of the Treasury', 'USD', 'BOND',       'TreasuryBond',  'seed'),
            (sTbond24,   'Manual', 'TreasuryBond',  'US Treasury 2.375% 2024',             '10-year US Treasury note',                        'US Department of the Treasury', 'USD', 'BOND',       'TreasuryBond',  'seed'),
            -- Municipal Bonds
            (sCaBond,    'Manual', 'MunicipalBond', 'California GO Bond 5.0% 2032',        'California general obligation bond',               'State of California',           'USD', 'BOND',       'MunicipalBond', 'seed'),
            (sMtaBond,   'Manual', 'MunicipalBond', 'New York MTA Revenue Bond 4.5% 2035', 'New York MTA revenue bond',                       'New York MTA',                  'USD', 'BOND',       'MunicipalBond', 'seed'),
            -- Loan
            (sLoan,      'Manual', 'Loan',          'Leveraged Term Loan A - TechCo 2028', 'Senior secured TLA facility',                     'TechCo Holdings LLC',           'USD', 'LOAN',       'TermLoan',      'seed'),
            -- Derivative
            (sOption,    'Manual', 'Derivative',    'AAPL 200 Call Option',                'Call option on Apple common stock at 200 strike', 'Apple Inc.',                    'USD', 'DERIVATIVE', 'EquityOption',  'seed');

        INSERT INTO security_identifier
            (id, security_id, identifier_type, identifier_value, source_system, is_primary, modified_by)
        VALUES
            (gen_random_uuid(), sAapl,      'Ticker',    'AAPL',                'Manual', TRUE, 'seed'),
            (gen_random_uuid(), sMsft,      'Ticker',    'MSFT',                'Manual', TRUE, 'seed'),
            (gen_random_uuid(), sAaplIsin,  'ISIN',      'US0378331005',        'Manual', TRUE, 'seed'),
            (gen_random_uuid(), sTsla,      'Ticker',    'TSLA',                'Manual', TRUE, 'seed'),
            (gen_random_uuid(), sJpm,       'Ticker',    'JPM',                 'Manual', TRUE, 'seed'),
            (gen_random_uuid(), sAppleBond, 'CUSIP',     '037833100',           'Manual', TRUE, 'seed'),
            (gen_random_uuid(), sMsftBond,  'CUSIP',     '594918BW8',           'Manual', TRUE, 'seed'),
            (gen_random_uuid(), sJpmBond,   'ISIN',      'US46625HJF27',        'Manual', TRUE, 'seed'),
            (gen_random_uuid(), sDbBond,    'ISIN',      'XS2345678901',        'Manual', TRUE, 'seed'),
            (gen_random_uuid(), sTbond51,   'CUSIP',     '912828ZT0',           'Manual', TRUE, 'seed'),
            (gen_random_uuid(), sTbond24,   'CUSIP',     '9128284S6',           'Manual', TRUE, 'seed'),
            (gen_random_uuid(), sCaBond,    'CUSIP',     '130161TS8',           'Manual', TRUE, 'seed'),
            (gen_random_uuid(), sMtaBond,   'CUSIP',     '64966EZH3',           'Manual', TRUE, 'seed'),
            (gen_random_uuid(), sLoan,      'Internal',  'LOAN-001',            'Manual', TRUE, 'seed'),
            (gen_random_uuid(), sOption,    'Bloomberg', 'AAPL US C200 Equity', 'Manual', TRUE, 'seed');

        RAISE NOTICE 'Demo securities seeded.';
    ELSE
        RAISE NOTICE 'Demo securities already seeded, skipping.';
    END IF;
END $$;

-- Security Core Attributes — bonds (idempotent)
INSERT INTO security_core_attribute (id, security_id, coupon_rate, face_value, issue_date, maturity_date, modified_by)
SELECT gen_random_uuid(), si.security_id, v.cr, v.fv, v.idate::TIMESTAMPTZ, v.mdate::TIMESTAMPTZ, 'seed'
FROM (VALUES
    ('CUSIP', '037833100',    3.85::NUMERIC,  1000.00::NUMERIC, '2016-05-05', '2046-05-05'),
    ('CUSIP', '594918BW8',    3.30::NUMERIC,  1000.00::NUMERIC, '2017-02-08', '2027-02-08'),
    ('ISIN',  'US46625HJF27', 4.20::NUMERIC,  1000.00::NUMERIC, '2017-07-23', '2047-07-23'),
    ('ISIN',  'XS2345678901', 2.75::NUMERIC,  1000.00::NUMERIC, '2021-03-15', '2030-03-15'),
    ('CUSIP', '912828ZT0',    1.875::NUMERIC, 1000.00::NUMERIC, '2021-02-15', '2051-02-15'),
    ('CUSIP', '9128284S6',    2.375::NUMERIC, 1000.00::NUMERIC, '2014-02-18', '2024-02-15'),
    ('CUSIP', '130161TS8',    5.00::NUMERIC,  5000.00::NUMERIC, '2012-06-01', '2032-10-01'),
    ('CUSIP', '64966EZH3',    4.50::NUMERIC,  5000.00::NUMERIC, '2015-11-01', '2035-11-15')
) AS v(itype, ival, cr, fv, idate, mdate)
JOIN security_identifier si ON si.identifier_type = v.itype AND si.identifier_value = v.ival
    AND si.is_current = TRUE AND si.is_deleted = FALSE
WHERE NOT EXISTS (
    SELECT 1 FROM security_core_attribute
    WHERE security_id = si.security_id AND is_current = TRUE AND is_deleted = FALSE
);

-- Security Core Attributes — loan (includes factor_rate)
INSERT INTO security_core_attribute (id, security_id, coupon_rate, factor_rate, face_value, issue_date, maturity_date, modified_by)
SELECT gen_random_uuid(), si.security_id, 5.75, 1.00, 10000000.00, '2022-01-15'::TIMESTAMPTZ, '2028-01-15'::TIMESTAMPTZ, 'seed'
FROM security_identifier si
WHERE si.identifier_type = 'Internal' AND si.identifier_value = 'LOAN-001'
  AND si.is_current = TRUE AND si.is_deleted = FALSE
  AND NOT EXISTS (
      SELECT 1 FROM security_core_attribute
      WHERE security_id = si.security_id AND is_current = TRUE AND is_deleted = FALSE
  );

-- Security Loan Attributes (idempotent)
INSERT INTO security_loan_attribute (id, security_id, loan_type, seniority, amortization, payment_freq, day_count, margin_bps, reference_index, maturity_date, modified_by)
SELECT gen_random_uuid(), si.security_id, 'TermLoan', 'Senior', 'Amortising', 'Quarterly', 'ACT/360', 275.00, 'SOFR', '2028-01-15'::TIMESTAMPTZ, 'seed'
FROM security_identifier si
WHERE si.identifier_type = 'Internal' AND si.identifier_value = 'LOAN-001'
  AND si.is_current = TRUE AND si.is_deleted = FALSE
  AND NOT EXISTS (
      SELECT 1 FROM security_loan_attribute
      WHERE security_id = si.security_id AND is_current = TRUE AND is_deleted = FALSE
  );

-- ====================================================================
-- Clients / Portfolios / Positions seed (idempotent)
-- ====================================================================

DO $$
DECLARE
    clientAcme      UUID;
    clientAlpha     UUID;
    clientBeta      UUID;
    pfAcmeGrowth    UUID;
    pfAcmeIncome    UUID;
    pfAlphaCore     UUID;
    pfBetaBalanced  UUID;
    secAapl         UUID;
    secMsft         UUID;
    secTsla         UUID;
    secJpm          UUID;
    secAppleBond    UUID;
    secTbond        UUID;
BEGIN
    IF NOT EXISTS (SELECT 1 FROM client WHERE code = 'ACME') THEN
        clientAcme  := gen_random_uuid();
        clientAlpha := gen_random_uuid();
        clientBeta  := gen_random_uuid();

        INSERT INTO client (id, name, code, email, is_active)
        VALUES
            (clientAcme,  'Acme Capital Management', 'ACME',  'ops@acmecapital.example', TRUE),
            (clientAlpha, 'Alpha Wealth Partners',   'ALPHA', 'ops@alphawealth.example',  TRUE),
            (clientBeta,  'Beta Pension Fund',       'BETA',  'ops@betapension.example',  TRUE);

        pfAcmeGrowth   := gen_random_uuid();
        pfAcmeIncome   := gen_random_uuid();
        pfAlphaCore    := gen_random_uuid();
        pfBetaBalanced := gen_random_uuid();

        INSERT INTO portfolio (id, client_id, name, code, currency, is_active)
        VALUES
            (pfAcmeGrowth,   clientAcme,  'Acme Growth Fund',       'ACME-GROWTH',   'USD', TRUE),
            (pfAcmeIncome,   clientAcme,  'Acme Income Fund',       'ACME-INCOME',   'USD', TRUE),
            (pfAlphaCore,    clientAlpha, 'Alpha Core Equity',      'ALPHA-CORE',    'USD', TRUE),
            (pfBetaBalanced, clientBeta,  'Beta Balanced Portfolio', 'BETA-BALANCED', 'USD', TRUE);

        SELECT si.security_id INTO secAapl
        FROM security_identifier si
        WHERE si.identifier_type = 'Ticker' AND si.identifier_value = 'AAPL'
          AND si.is_current = TRUE AND si.is_deleted = FALSE LIMIT 1;

        SELECT si.security_id INTO secMsft
        FROM security_identifier si
        WHERE si.identifier_type = 'Ticker' AND si.identifier_value = 'MSFT'
          AND si.is_current = TRUE AND si.is_deleted = FALSE LIMIT 1;

        SELECT si.security_id INTO secTsla
        FROM security_identifier si
        WHERE si.identifier_type = 'Ticker' AND si.identifier_value = 'TSLA'
          AND si.is_current = TRUE AND si.is_deleted = FALSE LIMIT 1;

        SELECT si.security_id INTO secJpm
        FROM security_identifier si
        WHERE si.identifier_type = 'Ticker' AND si.identifier_value = 'JPM'
          AND si.is_current = TRUE AND si.is_deleted = FALSE LIMIT 1;

        SELECT si.security_id INTO secAppleBond
        FROM security_identifier si
        WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '037833100'
          AND si.is_current = TRUE AND si.is_deleted = FALSE LIMIT 1;

        SELECT si.security_id INTO secTbond
        FROM security_identifier si
        WHERE si.identifier_type = 'CUSIP' AND si.identifier_value = '912828ZT0'
          AND si.is_current = TRUE AND si.is_deleted = FALSE LIMIT 1;

        INSERT INTO position (id, portfolio_id, security_id, quantity, as_of_date, currency_code, source_system)
        VALUES
            (gen_random_uuid(), pfAcmeGrowth,   secAapl,        1500.00000000,    CURRENT_DATE, 'USD', 'Seed'),
            (gen_random_uuid(), pfAcmeGrowth,   secMsft,         800.00000000,    CURRENT_DATE, 'USD', 'Seed'),
            (gen_random_uuid(), pfAcmeGrowth,   secTsla,         500.00000000,    CURRENT_DATE, 'USD', 'Seed'),
            (gen_random_uuid(), pfAcmeIncome,   secAppleBond, 2000000.00000000,   CURRENT_DATE, 'USD', 'Seed'),
            (gen_random_uuid(), pfAlphaCore,    secAapl,         750.00000000,    CURRENT_DATE, 'USD', 'Seed'),
            (gen_random_uuid(), pfAlphaCore,    secJpm,          600.00000000,    CURRENT_DATE, 'USD', 'Seed'),
            (gen_random_uuid(), pfBetaBalanced, secAppleBond, 1000000.00000000,   CURRENT_DATE, 'USD', 'Seed'),
            (gen_random_uuid(), pfBetaBalanced, secTbond,     5000000.00000000,   CURRENT_DATE, 'USD', 'Seed');

        -- Mark securities that now have open positions
        UPDATE security SET has_open_position = TRUE, updated_at = NOW()
        WHERE EXISTS (
            SELECT 1 FROM position p
            WHERE p.security_id = security.id AND p.is_current = TRUE AND p.is_deleted = FALSE
        );

        RAISE NOTICE 'Clients / Portfolios / Positions seeded.';
    ELSE
        RAISE NOTICE 'Clients / Portfolios / Positions already seeded, skipping.';
    END IF;
END $$;

-- ====================================================================
-- Issuers seed (idempotent)
-- ====================================================================
\echo 'Seeding issuers...';

INSERT INTO issuer (id, legal_name, display_name, short_name, lei_code, issuer_type, country_alpha2, is_active, modified_by)
SELECT gen_random_uuid(), v.ln, v.dn, v.sn, v.lei, v.itype, v.c2, TRUE, 'seed'
FROM (VALUES
    ('Apple Inc.',                                    'Apple',              'AAPL',   'HWUPKR0MPOU8FGXBT394', 'Corporate',  'US'),
    ('Microsoft Corporation',                         'Microsoft',          'MSFT',   'INR2EJN1ERAN0W5ZP974', 'Corporate',  'US'),
    ('Tesla Inc.',                                    'Tesla',              'TSLA',   '54930043XZGB27CTOV49', 'Corporate',  'US'),
    ('JPMorgan Chase & Co.',                          'JPMorgan',           'JPM',    '8I5DZWZKVSZI1NUHU748', 'Corporate',  'US'),
    ('JPMorgan Chase Bank, N.A.',                     'JPMorgan Chase Bank','JPMCB',  '7H6GLXDRUGQFU57RNE97', 'Corporate',  'US'),
    ('Deutsche Bank AG',                              'Deutsche Bank',      'DBK',    '7LTWFZYICNSX8D621K86', 'Corporate',  'DE'),
    ('US Department of the Treasury',                 'US Treasury',        'UST',    NULL,                   'Government', 'US'),
    ('State of California',                           'California',         'CA',     NULL,                   'Government', 'US'),
    ('New York Metropolitan Transportation Authority','NY MTA',             'NYMTA',  NULL,                   'Government', 'US'),
    ('TechCo Holdings LLC',                           'TechCo Holdings',    'TECHCO', NULL,                   'Corporate',  'US')
) AS v(ln, dn, sn, lei, itype, c2)
WHERE NOT EXISTS (
    SELECT 1 FROM issuer WHERE (v.lei IS NOT NULL AND lei_code = v.lei AND is_current = TRUE)
       OR (v.lei IS NULL AND legal_name = v.ln AND is_current = TRUE)
);

-- Set parent links for JPMorgan Chase Bank, N.A.
DO $$ DECLARE v_parent UUID; v_child UUID;
BEGIN
    v_parent := (SELECT id FROM issuer WHERE lei_code = '8I5DZWZKVSZI1NUHU748' AND is_current = TRUE LIMIT 1);
    v_child  := (SELECT id FROM issuer WHERE lei_code = '7H6GLXDRUGQFU57RNE97' AND is_current = TRUE LIMIT 1);
    IF v_parent IS NOT NULL AND v_child IS NOT NULL THEN
        UPDATE issuer SET direct_accounting_parent_issuer_id = v_parent,
                          ultimate_accounting_parent_issuer_id = v_parent
        WHERE id = v_child
          AND (direct_accounting_parent_issuer_id IS NULL OR direct_accounting_parent_issuer_id <> v_parent);
    END IF;
END $$;

-- Issuer identifiers
INSERT INTO issuer_identifier (id, issuer_id, identifier_type, identifier_value, source_system, is_primary, modified_by)
SELECT gen_random_uuid(), iss.id, v.itype, v.ival, 'Manual', v.prim, 'seed'
FROM (VALUES
    ('HWUPKR0MPOU8FGXBT394', 'Ticker', 'AAPL',          TRUE),
    ('HWUPKR0MPOU8FGXBT394', 'CUSIP',  '037833100',     FALSE),
    ('INR2EJN1ERAN0W5ZP974', 'Ticker', 'MSFT',          TRUE),
    ('54930043XZGB27CTOV49', 'Ticker', 'TSLA',          TRUE),
    ('8I5DZWZKVSZI1NUHU748', 'Ticker', 'JPM',           TRUE),
    ('7LTWFZYICNSX8D621K86', 'Ticker', 'DBK',           TRUE)
) AS v(lei, itype, ival, prim)
JOIN issuer iss ON iss.lei_code = v.lei AND iss.is_current = TRUE
WHERE NOT EXISTS (
    SELECT 1 FROM issuer_identifier
    WHERE issuer_id = iss.id AND identifier_type = v.itype AND identifier_value = v.ival AND is_current = TRUE
);

-- Issuer relationships
INSERT INTO issuer_relationship (id, child_issuer_id, parent_issuer_id, relationship_type, ownership_percent, is_primary, modified_by)
SELECT gen_random_uuid(), child.id, parent.id, v.rtype, 100.00, TRUE, 'seed'
FROM (VALUES
    ('7H6GLXDRUGQFU57RNE97', '8I5DZWZKVSZI1NUHU748', 'ACCOUNTING_DIRECT_PARENT'),
    ('7H6GLXDRUGQFU57RNE97', '8I5DZWZKVSZI1NUHU748', 'ACCOUNTING_ULTIMATE_PARENT'),
    ('7H6GLXDRUGQFU57RNE97', '8I5DZWZKVSZI1NUHU748', 'OWNERSHIP_PARENT')
) AS v(clei, plei, rtype)
JOIN issuer child  ON child.lei_code  = v.clei AND child.is_current  = TRUE
JOIN issuer parent ON parent.lei_code = v.plei AND parent.is_current = TRUE
WHERE NOT EXISTS (
    SELECT 1 FROM issuer_relationship
    WHERE child_issuer_id = child.id AND parent_issuer_id = parent.id AND relationship_type = v.rtype AND is_current = TRUE
);

-- Link securities to issuers
UPDATE security SET issuer_id = (SELECT id FROM issuer WHERE lei_code = 'HWUPKR0MPOU8FGXBT394' AND is_current = TRUE LIMIT 1)
WHERE issuer = 'Apple Inc.' AND (issuer_id IS NULL OR issuer_id <> (SELECT id FROM issuer WHERE lei_code = 'HWUPKR0MPOU8FGXBT394' AND is_current = TRUE LIMIT 1));

UPDATE security SET issuer_id = (SELECT id FROM issuer WHERE lei_code = 'INR2EJN1ERAN0W5ZP974' AND is_current = TRUE LIMIT 1)
WHERE issuer = 'Microsoft Corporation' AND (issuer_id IS NULL OR issuer_id <> (SELECT id FROM issuer WHERE lei_code = 'INR2EJN1ERAN0W5ZP974' AND is_current = TRUE LIMIT 1));

UPDATE security SET issuer_id = (SELECT id FROM issuer WHERE lei_code = '54930043XZGB27CTOV49' AND is_current = TRUE LIMIT 1)
WHERE issuer = 'Tesla Inc.' AND (issuer_id IS NULL OR issuer_id <> (SELECT id FROM issuer WHERE lei_code = '54930043XZGB27CTOV49' AND is_current = TRUE LIMIT 1));

UPDATE security SET issuer_id = (SELECT id FROM issuer WHERE lei_code = '8I5DZWZKVSZI1NUHU748' AND is_current = TRUE LIMIT 1)
WHERE issuer IN ('JPMorgan Chase & Co.', 'JPMorgan Chase') AND (issuer_id IS NULL OR issuer_id <> (SELECT id FROM issuer WHERE lei_code = '8I5DZWZKVSZI1NUHU748' AND is_current = TRUE LIMIT 1));

UPDATE security SET issuer_id = (SELECT id FROM issuer WHERE lei_code = '7LTWFZYICNSX8D621K86' AND is_current = TRUE LIMIT 1)
WHERE issuer = 'Deutsche Bank AG' AND (issuer_id IS NULL OR issuer_id <> (SELECT id FROM issuer WHERE lei_code = '7LTWFZYICNSX8D621K86' AND is_current = TRUE LIMIT 1));

UPDATE security SET issuer_id = (SELECT id FROM issuer WHERE legal_name = 'US Department of the Treasury' AND is_current = TRUE LIMIT 1)
WHERE issuer IN ('US Treasury', 'US Department of the Treasury', 'United States Treasury') AND issuer_id IS NULL;

UPDATE security SET issuer_id = (SELECT id FROM issuer WHERE legal_name = 'State of California' AND is_current = TRUE LIMIT 1)
WHERE issuer IN ('State of California', 'California') AND issuer_id IS NULL;

UPDATE security SET issuer_id = (SELECT id FROM issuer WHERE legal_name = 'New York Metropolitan Transportation Authority' AND is_current = TRUE LIMIT 1)
WHERE issuer IN ('New York MTA', 'New York Metropolitan Transportation Authority', 'MTA') AND issuer_id IS NULL;

UPDATE security SET issuer_id = (SELECT id FROM issuer WHERE legal_name = 'TechCo Holdings LLC' AND is_current = TRUE LIMIT 1)
WHERE issuer = 'TechCo Holdings LLC' AND issuer_id IS NULL;

\echo 'Issuer seed data loaded.';

-- ====================================================================
-- Vendor Source seed
-- ====================================================================
INSERT INTO vendor_source (code, display_name, global_priority, staleness_threshold_hours)
SELECT v.code, v.display_name, v.global_priority, v.staleness_threshold_hours
FROM (VALUES
    ('BLOOMBERG',    'Bloomberg B-PIPE',        1,  24),
    ('REFINITIV',    'Refinitiv / LSEG',        2,  24),
    ('ICE',          'ICE Data Services',       3,  24),
    ('ALPHAVANTAGE', 'Alpha Vantage',            10, 48),
    ('FLAT_FILE',    'Flat File / SFTP Import',  20, 72),
    ('INTERNAL',     'Internal / Manual',        50, 0)
) AS v(code, display_name, global_priority, staleness_threshold_hours)
WHERE NOT EXISTS (SELECT 1 FROM vendor_source WHERE code = v.code AND is_current = TRUE AND is_deleted = FALSE)
ON CONFLICT DO NOTHING;

\echo 'Vendor source seed data loaded.';

INSERT INTO "__SchemaVersions" (version, description, script_name, applied_on, applied_by, status)
VALUES ('1.2-ref-data', 'Currencies, countries, field visibility, permissions, issuers, vendor sources',
        'SeedData_PostgreSQL.sql', NOW() AT TIME ZONE 'UTC', CURRENT_USER, 'Success')
ON CONFLICT (version) DO NOTHING;

\echo 'SecurityApp extended seed data loaded successfully.';
