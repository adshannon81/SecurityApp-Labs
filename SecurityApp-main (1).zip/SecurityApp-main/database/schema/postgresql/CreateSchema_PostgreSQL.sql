-- ====================================================================
-- SecurityApp - Complete Schema (PostgreSQL)
-- Fully idempotent. All CREATE TABLE / INDEX use IF NOT EXISTS.
-- Type map from SQL Server:
--   UNIQUEIDENTIFIER  -> UUID, DEFAULT gen_random_uuid()
--   NVARCHAR(n)       -> VARCHAR(n), MAX -> TEXT
--   NCHAR(n)          -> CHAR(n)
--   DATETIME2         -> TIMESTAMPTZ
--   BIT               -> BOOLEAN
--   ROWVERSION        -> omitted
--   IDENTITY          -> SERIAL
--   DECIMAL(x,y)      -> NUMERIC(x,y)
--   Filtered indexes  -> partial indexes (WHERE clause)
-- ====================================================================

\echo 'Creating SecurityApp schema (PostgreSQL)...';

CREATE TABLE IF NOT EXISTS "__SchemaVersions" (
    id             SERIAL        PRIMARY KEY,
    version        VARCHAR(50)   NOT NULL,
    description    TEXT          NOT NULL,
    script_name    VARCHAR(255)  NOT NULL DEFAULT '',
    applied_on     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    applied_by     VARCHAR(100)  NOT NULL DEFAULT CURRENT_USER,
    execution_time VARCHAR(50),
    status         VARCHAR(20)   NOT NULL DEFAULT 'Success',
    CONSTRAINT uq__schema_versions__version UNIQUE (version)
);

-- ====================================================================
-- ASP.NET Identity tables (PascalCase)
-- ====================================================================
CREATE TABLE IF NOT EXISTS "AspNetRoles" (
    "Id"               TEXT         NOT NULL PRIMARY KEY,
    "Name"             VARCHAR(256),
    "NormalizedName"   VARCHAR(256),
    "ConcurrencyStamp" TEXT
);

CREATE TABLE IF NOT EXISTS "AspNetUsers" (
    "Id"                   TEXT         NOT NULL PRIMARY KEY,
    "UserName"             VARCHAR(256),
    "NormalizedUserName"   VARCHAR(256),
    "Email"                VARCHAR(256),
    "NormalizedEmail"      VARCHAR(256),
    "EmailConfirmed"       BOOLEAN      NOT NULL,
    "PasswordHash"         TEXT,
    "SecurityStamp"        TEXT,
    "ConcurrencyStamp"     TEXT,
    "PhoneNumber"          TEXT,
    "PhoneNumberConfirmed" BOOLEAN      NOT NULL,
    "TwoFactorEnabled"     BOOLEAN      NOT NULL,
    "LockoutEnd"           TIMESTAMPTZ,
    "LockoutEnabled"       BOOLEAN      NOT NULL,
    "AccessFailedCount"    INTEGER      NOT NULL
);

CREATE TABLE IF NOT EXISTS "AspNetUserRoles" (
    "UserId" TEXT NOT NULL,
    "RoleId" TEXT NOT NULL,
    PRIMARY KEY ("UserId", "RoleId"),
    FOREIGN KEY ("UserId") REFERENCES "AspNetUsers" ("Id") ON DELETE CASCADE,
    FOREIGN KEY ("RoleId") REFERENCES "AspNetRoles"  ("Id") ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS "AspNetUserClaims" (
    "Id"         SERIAL PRIMARY KEY,
    "UserId"     TEXT NOT NULL,
    "ClaimType"  TEXT,
    "ClaimValue" TEXT,
    FOREIGN KEY ("UserId") REFERENCES "AspNetUsers" ("Id") ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS "AspNetUserLogins" (
    "LoginProvider"       TEXT NOT NULL,
    "ProviderKey"         TEXT NOT NULL,
    "ProviderDisplayName" TEXT,
    "UserId"              TEXT NOT NULL,
    PRIMARY KEY ("LoginProvider", "ProviderKey"),
    FOREIGN KEY ("UserId") REFERENCES "AspNetUsers" ("Id") ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS "AspNetUserTokens" (
    "UserId"        TEXT NOT NULL,
    "LoginProvider" TEXT NOT NULL,
    "Name"          TEXT NOT NULL,
    "Value"         TEXT,
    PRIMARY KEY ("UserId", "LoginProvider", "Name"),
    FOREIGN KEY ("UserId") REFERENCES "AspNetUsers" ("Id") ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS "AspNetRoleClaims" (
    "Id"         SERIAL PRIMARY KEY,
    "RoleId"     TEXT NOT NULL,
    "ClaimType"  TEXT,
    "ClaimValue" TEXT,
    FOREIGN KEY ("RoleId") REFERENCES "AspNetRoles" ("Id") ON DELETE CASCADE
);

-- ====================================================================
-- Reference tables
-- ====================================================================
CREATE TABLE IF NOT EXISTS security_status_ref (
    code        VARCHAR(32)  NOT NULL,
    description VARCHAR(255) NOT NULL,
    CONSTRAINT pk_security_status_ref PRIMARY KEY (code)
);

CREATE TABLE IF NOT EXISTS security_status_transition_ref (
    from_code VARCHAR(32) NOT NULL,
    to_code   VARCHAR(32) NOT NULL,
    CONSTRAINT pk_security_status_transition PRIMARY KEY (from_code, to_code),
    CONSTRAINT fk_sst_from FOREIGN KEY (from_code) REFERENCES security_status_ref(code),
    CONSTRAINT fk_sst_to   FOREIGN KEY (to_code)   REFERENCES security_status_ref(code)
);

CREATE TABLE IF NOT EXISTS asset_class_ref (
    code        VARCHAR(32)  NOT NULL,
    name        VARCHAR(100) NOT NULL,
    description VARCHAR(255),
    CONSTRAINT pk_asset_class_ref PRIMARY KEY (code)
);

CREATE TABLE IF NOT EXISTS instrument_type_ref (
    code             VARCHAR(64)  NOT NULL,
    asset_class_code VARCHAR(32)  NOT NULL,
    description      VARCHAR(255),
    CONSTRAINT pk_instrument_type_ref PRIMARY KEY (code),
    CONSTRAINT fk_instrument_type_asset_class FOREIGN KEY (asset_class_code) REFERENCES asset_class_ref(code)
);

-- ====================================================================
-- Currency
-- ====================================================================
CREATE TABLE IF NOT EXISTS currency (
    id               UUID         NOT NULL DEFAULT gen_random_uuid(),
    code             VARCHAR(10)  NOT NULL,
    numeric_code     VARCHAR(3),
    name             VARCHAR(150) NOT NULL,
    symbol           VARCHAR(10),
    decimals         SMALLINT     NOT NULL DEFAULT 2,
    display_decimals SMALLINT     NOT NULL DEFAULT 2,
    currency_type    VARCHAR(10)  NOT NULL DEFAULT 'FIAT',
    is_active        BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at       TIMESTAMPTZ,
    valid_from       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to         TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to        TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current       BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by      VARCHAR(255),

    last_modified_by      VARCHAR(255),
    CONSTRAINT pk_currency PRIMARY KEY (id),
    CONSTRAINT uq_currency_code UNIQUE (code),
    CONSTRAINT chk_currency_type CHECK (currency_type IN ('FIAT','CRYPTO','COMMODITY','OTHER'))
);
CREATE INDEX IF NOT EXISTS ix_currency_currency_type ON currency(currency_type);
CREATE INDEX IF NOT EXISTS ix_currency_is_active     ON currency(is_active);
CREATE INDEX IF NOT EXISTS ix_currency_is_current    ON currency(is_current);

-- ====================================================================
-- Country
-- ====================================================================
CREATE TABLE IF NOT EXISTS country (
    id           UUID        NOT NULL DEFAULT gen_random_uuid(),
    alpha2       CHAR(2)     NOT NULL,
    alpha3       CHAR(3)     NOT NULL,
    numeric_code CHAR(3)     NOT NULL,
    name         VARCHAR(200) NOT NULL,
    tld          VARCHAR(10),
    is_active    BOOLEAN     NOT NULL DEFAULT TRUE,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_modified_at   TIMESTAMPTZ,
    valid_from   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    valid_to     TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31',
    system_from  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    system_to    TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31',
    is_current   BOOLEAN     NOT NULL DEFAULT TRUE,
    is_deleted   BOOLEAN     NOT NULL DEFAULT FALSE,
    created_by  VARCHAR(255),

    last_modified_by  VARCHAR(255),
    CONSTRAINT pk_country PRIMARY KEY (id),
    CONSTRAINT uq_country_alpha2 UNIQUE (alpha2)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_country_alpha3  ON country(alpha3);
CREATE UNIQUE INDEX IF NOT EXISTS ux_country_numeric ON country(numeric_code);
CREATE INDEX IF NOT EXISTS ix_country_is_current     ON country(is_current);

-- ====================================================================
-- country_currency
-- ====================================================================
CREATE TABLE IF NOT EXISTS country_currency (
    id              UUID        NOT NULL DEFAULT gen_random_uuid(),
    country_alpha2  CHAR(2)     NOT NULL,
    currency_code   VARCHAR(10) NOT NULL,
    is_primary      BOOLEAN     NOT NULL DEFAULT FALSE,
    is_legal_tender BOOLEAN     NOT NULL DEFAULT TRUE,
    is_operational  BOOLEAN     NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_modified_at      TIMESTAMPTZ,
    valid_from      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    valid_to        TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31',
    system_from     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    system_to       TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31',
    is_current      BOOLEAN     NOT NULL DEFAULT TRUE,
    is_deleted      BOOLEAN     NOT NULL DEFAULT FALSE,
    created_by     VARCHAR(255),

    last_modified_by     VARCHAR(255),
    CONSTRAINT pk_country_currency PRIMARY KEY (id),
    CONSTRAINT uq_country_currency_pair UNIQUE (country_alpha2, currency_code),
    CONSTRAINT fk_country_currency_country  FOREIGN KEY (country_alpha2) REFERENCES country(alpha2),
    CONSTRAINT fk_country_currency_currency FOREIGN KEY (currency_code)  REFERENCES currency(code)
);
CREATE INDEX IF NOT EXISTS ix_country_currency_alpha2  ON country_currency(country_alpha2);
CREATE INDEX IF NOT EXISTS ix_country_currency_code    ON country_currency(currency_code);
CREATE INDEX IF NOT EXISTS ix_country_currency_current ON country_currency(is_current);

-- ====================================================================
-- currency_external_code
-- ====================================================================
CREATE TABLE IF NOT EXISTS currency_external_code (
    id            UUID         NOT NULL DEFAULT gen_random_uuid(),
    currency_code VARCHAR(10)  NOT NULL,
    system_name   VARCHAR(100) NOT NULL,
    external_code VARCHAR(100) NOT NULL,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at    TIMESTAMPTZ,
    valid_from    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to      TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to     TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current    BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted    BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by   VARCHAR(255),

    last_modified_by   VARCHAR(255),
    CONSTRAINT pk_currency_external_code PRIMARY KEY (id),
    CONSTRAINT uq_currency_external_code_system UNIQUE (currency_code, system_name),
    CONSTRAINT fk_currency_external_code_currency FOREIGN KEY (currency_code) REFERENCES currency(code)
);
CREATE INDEX IF NOT EXISTS ix_currency_external_code_currency_code ON currency_external_code(currency_code);
CREATE INDEX IF NOT EXISTS ix_currency_external_code_system_name   ON currency_external_code(system_name);
CREATE INDEX IF NOT EXISTS ix_currency_external_code_is_current    ON currency_external_code(is_current);

-- ====================================================================
-- currency_pair
-- ====================================================================
CREATE TABLE IF NOT EXISTS currency_pair (
    id                  UUID        NOT NULL DEFAULT gen_random_uuid(),
    base_currency_code  VARCHAR(10) NOT NULL,
    quote_currency_code VARCHAR(10) NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_modified_at          TIMESTAMPTZ,
    valid_from          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    valid_to            TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31',
    system_from         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    system_to           TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31',
    is_current          BOOLEAN     NOT NULL DEFAULT TRUE,
    is_deleted          BOOLEAN     NOT NULL DEFAULT FALSE,
    created_by         VARCHAR(255),

    last_modified_by         VARCHAR(255),
    CONSTRAINT pk_currency_pair PRIMARY KEY (id),
    CONSTRAINT uq_currency_pair_base_quote UNIQUE (base_currency_code, quote_currency_code),
    CONSTRAINT fk_currency_pair_base  FOREIGN KEY (base_currency_code)  REFERENCES currency(code),
    CONSTRAINT fk_currency_pair_quote FOREIGN KEY (quote_currency_code) REFERENCES currency(code),
    CONSTRAINT chk_currency_pair_not_self CHECK (base_currency_code <> quote_currency_code)
);
CREATE INDEX IF NOT EXISTS ix_currency_pair_base_code  ON currency_pair(base_currency_code);
CREATE INDEX IF NOT EXISTS ix_currency_pair_quote_code ON currency_pair(quote_currency_code);
CREATE INDEX IF NOT EXISTS ix_currency_pair_is_current ON currency_pair(is_current);

-- ====================================================================
-- issuer
-- ====================================================================
CREATE TABLE IF NOT EXISTS issuer (
    id                                   UUID         NOT NULL DEFAULT gen_random_uuid(),
    legal_name                           VARCHAR(255) NOT NULL,
    display_name                         VARCHAR(255),
    short_name                           VARCHAR(100),
    lei_code                             VARCHAR(20),
    issuer_type                          VARCHAR(50),
    country_alpha2                       CHAR(2),
    direct_accounting_parent_issuer_id   UUID,
    ultimate_accounting_parent_issuer_id UUID,
    is_active                            BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at                           TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at                           TIMESTAMPTZ,
    valid_from                           TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to                             TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from                          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to                            TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current                           BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted                           BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by                          VARCHAR(255),

    last_modified_by                          VARCHAR(255),
    content_hash                         VARCHAR(64),
    CONSTRAINT pk_issuer PRIMARY KEY (id),
    CONSTRAINT fk_issuer_direct_parent   FOREIGN KEY (direct_accounting_parent_issuer_id)   REFERENCES issuer(id),
    CONSTRAINT fk_issuer_ultimate_parent FOREIGN KEY (ultimate_accounting_parent_issuer_id) REFERENCES issuer(id)
);
CREATE INDEX IF NOT EXISTS ix_issuer_legal_name ON issuer(legal_name);
CREATE INDEX IF NOT EXISTS ix_issuer_lei_code   ON issuer(lei_code);
CREATE INDEX IF NOT EXISTS ix_issuer_country    ON issuer(country_alpha2);
CREATE INDEX IF NOT EXISTS ix_issuer_is_current ON issuer(is_current);

-- ====================================================================
-- issuer_identifier
-- ====================================================================
CREATE TABLE IF NOT EXISTS issuer_identifier (
    id               UUID         NOT NULL DEFAULT gen_random_uuid(),
    issuer_id        UUID         NOT NULL,
    identifier_type  VARCHAR(50)  NOT NULL,
    identifier_value VARCHAR(100) NOT NULL,
    source_system    VARCHAR(50),
    is_primary       BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at       TIMESTAMPTZ,
    valid_from       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to         TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to        TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current       BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by      VARCHAR(255),

    last_modified_by      VARCHAR(255),
    CONSTRAINT pk_issuer_identifier PRIMARY KEY (id),
    CONSTRAINT fk_issuer_identifier_issuer FOREIGN KEY (issuer_id) REFERENCES issuer(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_issuer_identifier_issuer_id   ON issuer_identifier(issuer_id);
CREATE INDEX IF NOT EXISTS ix_issuer_identifier_type_value  ON issuer_identifier(identifier_type, identifier_value, source_system);

-- ====================================================================
-- issuer_relationship
-- ====================================================================
CREATE TABLE IF NOT EXISTS issuer_relationship (
    id                UUID          NOT NULL DEFAULT gen_random_uuid(),
    child_issuer_id   UUID          NOT NULL,
    parent_issuer_id  UUID          NOT NULL,
    relationship_type VARCHAR(50)   NOT NULL,
    ownership_percent NUMERIC(9,6),
    control_basis     VARCHAR(100),
    source_system     VARCHAR(50),
    source_reference  VARCHAR(255),
    is_primary        BOOLEAN       NOT NULL DEFAULT FALSE,
    notes             VARCHAR(1000),
    created_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at        TIMESTAMPTZ,
    valid_from        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to          TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from       TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to         TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current        BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted        BOOLEAN       NOT NULL DEFAULT FALSE,
    created_by       VARCHAR(255),

    last_modified_by       VARCHAR(255),
    CONSTRAINT pk_issuer_relationship PRIMARY KEY (id),
    CONSTRAINT fk_issuer_rel_child  FOREIGN KEY (child_issuer_id)  REFERENCES issuer(id),
    CONSTRAINT fk_issuer_rel_parent FOREIGN KEY (parent_issuer_id) REFERENCES issuer(id),
    CONSTRAINT chk_issuer_rel_not_self CHECK (child_issuer_id <> parent_issuer_id)
);
CREATE INDEX IF NOT EXISTS ix_issuer_rel_child_type  ON issuer_relationship(child_issuer_id, relationship_type);
CREATE INDEX IF NOT EXISTS ix_issuer_rel_parent_type ON issuer_relationship(parent_issuer_id, relationship_type);
CREATE INDEX IF NOT EXISTS ix_issuer_rel_is_current  ON issuer_relationship(is_current);

-- ====================================================================
-- security
-- ====================================================================
CREATE TABLE IF NOT EXISTS security (
    id                   UUID         NOT NULL DEFAULT gen_random_uuid(),
    data_source          VARCHAR(50)  NOT NULL DEFAULT 'FlatFile',
    type                 VARCHAR(50)  NOT NULL,
    name                 VARCHAR(255) NOT NULL,
    description          TEXT,
    issuer               VARCHAR(255),
    issuer_id            UUID,
    currency_code        VARCHAR(10),
    has_open_position    BOOLEAN      NOT NULL DEFAULT FALSE,
    status_code          VARCHAR(32)  NOT NULL DEFAULT 'ACTIVE',
    asset_class_code     VARCHAR(32)  NOT NULL DEFAULT 'OTHER',
    instrument_type_code VARCHAR(64)  NOT NULL DEFAULT 'Other',
    content_hash         VARCHAR(64),
    created_at           TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at           TIMESTAMPTZ,
    valid_from           TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to             TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from          TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to            TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current           BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted           BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by          VARCHAR(255),

    last_modified_by          VARCHAR(255),
    CONSTRAINT pk_security PRIMARY KEY (id),
    CONSTRAINT fk_security_status_ref      FOREIGN KEY (status_code)          REFERENCES security_status_ref(code),
    CONSTRAINT fk_security_asset_class_ref FOREIGN KEY (asset_class_code)     REFERENCES asset_class_ref(code),
    CONSTRAINT fk_security_instrument_type FOREIGN KEY (instrument_type_code) REFERENCES instrument_type_ref(code),
    CONSTRAINT fk_security_issuer          FOREIGN KEY (issuer_id)            REFERENCES issuer(id),
    CONSTRAINT fk_security_currency_code   FOREIGN KEY (currency_code)        REFERENCES currency(code)
);
CREATE INDEX IF NOT EXISTS ix_security_name        ON security(name);
CREATE INDEX IF NOT EXISTS ix_security_currency    ON security(currency_code);
CREATE INDEX IF NOT EXISTS ix_security_is_current  ON security(is_current);
CREATE INDEX IF NOT EXISTS ix_security_valid_time  ON security(valid_from, valid_to);
CREATE INDEX IF NOT EXISTS ix_security_system_time ON security(system_from, system_to);
CREATE INDEX IF NOT EXISTS ix_security_is_deleted  ON security(is_deleted) WHERE is_deleted = FALSE;
CREATE INDEX IF NOT EXISTS ix_security_status_code ON security(status_code);
CREATE INDEX IF NOT EXISTS ix_security_asset_class ON security(asset_class_code);
CREATE INDEX IF NOT EXISTS ix_security_instr_type  ON security(instrument_type_code);

-- ====================================================================
-- security_identifier
-- ====================================================================
CREATE TABLE IF NOT EXISTS security_identifier (
    id               UUID         NOT NULL DEFAULT gen_random_uuid(),
    security_id      UUID         NOT NULL,
    identifier_type  VARCHAR(50)  NOT NULL,
    identifier_value VARCHAR(100) NOT NULL,
    source_system    VARCHAR(50),
    is_primary       BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at       TIMESTAMPTZ,
    valid_from       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to         TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to        TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current       BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by      VARCHAR(255),

    last_modified_by      VARCHAR(255),
    CONSTRAINT pk_security_identifier PRIMARY KEY (id),
    CONSTRAINT fk_si_security FOREIGN KEY (security_id) REFERENCES security(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_si_security_id       ON security_identifier(security_id);
CREATE INDEX IF NOT EXISTS ix_si_type_value_source ON security_identifier(identifier_type, identifier_value, source_system);
CREATE INDEX IF NOT EXISTS ix_si_is_current        ON security_identifier(is_current);

-- ====================================================================
-- price
-- ====================================================================
CREATE TABLE IF NOT EXISTS price (
    id               UUID          NOT NULL DEFAULT gen_random_uuid(),
    security_id      UUID          NOT NULL,
    value            NUMERIC(18,8) NOT NULL,
    source           VARCHAR(50)   NOT NULL,
    price_date       TIMESTAMPTZ   NOT NULL,
    price_type       VARCHAR(50),
    currency         VARCHAR(10),
    is_golden        BOOLEAN       NOT NULL DEFAULT FALSE,
    is_stale         BOOLEAN       NOT NULL DEFAULT FALSE,
    is_override      BOOLEAN       NOT NULL DEFAULT FALSE,
    override_reason  VARCHAR(500),
    vendor_source_id UUID,
    created_at       TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at       TIMESTAMPTZ,
    valid_from       TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to         TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to        TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current       BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN       NOT NULL DEFAULT FALSE,
    created_by      VARCHAR(255),

    last_modified_by      VARCHAR(255),
    CONSTRAINT pk_price PRIMARY KEY (id),
    CONSTRAINT fk_price_security FOREIGN KEY (security_id) REFERENCES security(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_price_sec_src_date ON price(security_id, source, price_date);
CREATE INDEX IF NOT EXISTS ix_price_is_current   ON price(is_current);
CREATE INDEX IF NOT EXISTS ix_price_valid_time   ON price(valid_from, valid_to);
CREATE INDEX IF NOT EXISTS ix_price_system_time  ON price(system_from, system_to);
CREATE INDEX IF NOT EXISTS ix_price_is_golden    ON price(security_id, price_date);

-- ====================================================================
-- pricing_rule
-- ====================================================================
CREATE TABLE IF NOT EXISTS pricing_rule (
    id                   UUID          NOT NULL DEFAULT gen_random_uuid(),
    rule_name            VARCHAR(255)  NOT NULL,
    security_type        VARCHAR(50),
    rule_definition_json TEXT          NOT NULL,
    created_by_user_id   UUID,
    description          VARCHAR(1000),
    created_at           TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at           TIMESTAMPTZ,
    valid_from           TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to             TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to            TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current           BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted           BOOLEAN       NOT NULL DEFAULT FALSE,
    created_by          VARCHAR(255),

    last_modified_by          VARCHAR(255),
    CONSTRAINT pk_pricing_rule PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS ix_pricing_rule_is_current ON pricing_rule(is_current);
CREATE INDEX IF NOT EXISTS ix_pricing_rule_valid_time ON pricing_rule(valid_from, valid_to);

-- ====================================================================
-- derived_price
-- ====================================================================
CREATE TABLE IF NOT EXISTS derived_price (
    id                  UUID          NOT NULL DEFAULT gen_random_uuid(),
    security_id         UUID          NOT NULL,
    pricing_rule_id     UUID          NOT NULL,
    calculated_price    NUMERIC(18,8) NOT NULL,
    calculated_at       TIMESTAMPTZ   NOT NULL,
    calculation_details TEXT,
    created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at          TIMESTAMPTZ,
    valid_from          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to            TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from         TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to           TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current          BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted          BOOLEAN       NOT NULL DEFAULT FALSE,
    created_by         VARCHAR(255),

    last_modified_by         VARCHAR(255),
    CONSTRAINT pk_derived_price   PRIMARY KEY (id),
    CONSTRAINT fk_dp_security     FOREIGN KEY (security_id)     REFERENCES security(id) ON DELETE CASCADE,
    CONSTRAINT fk_dp_pricing_rule FOREIGN KEY (pricing_rule_id) REFERENCES pricing_rule(id)
);
CREATE INDEX IF NOT EXISTS ix_dp_security_id ON derived_price(security_id);
CREATE INDEX IF NOT EXISTS ix_dp_rule_id     ON derived_price(pricing_rule_id);
CREATE INDEX IF NOT EXISTS ix_dp_is_current  ON derived_price(is_current);

-- ====================================================================
-- security_core_attribute
-- ====================================================================
CREATE TABLE IF NOT EXISTS security_core_attribute (
    id            UUID          NOT NULL DEFAULT gen_random_uuid(),
    security_id   UUID          NOT NULL,
    coupon_rate   NUMERIC(10,6),
    factor_rate   NUMERIC(10,6),
    maturity_date TIMESTAMPTZ,
    issue_date    TIMESTAMPTZ,
    face_value    NUMERIC(18,2),
    created_at    TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at    TIMESTAMPTZ,
    valid_from    TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to      TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from   TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to     TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current    BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted    BOOLEAN       NOT NULL DEFAULT FALSE,
    created_by   VARCHAR(255),

    last_modified_by   VARCHAR(255),
    CONSTRAINT pk_security_core_attribute PRIMARY KEY (id),
    CONSTRAINT fk_sca_security FOREIGN KEY (security_id) REFERENCES security(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_sca_security_id ON security_core_attribute(security_id);
CREATE INDEX IF NOT EXISTS ix_sca_is_current  ON security_core_attribute(is_current);

-- ====================================================================
-- security_loan_attribute
-- ====================================================================
CREATE TABLE IF NOT EXISTS security_loan_attribute (
    id              UUID          NOT NULL DEFAULT gen_random_uuid(),
    security_id     UUID          NOT NULL,
    loan_type       VARCHAR(50),
    collateral_type VARCHAR(100),
    seniority       VARCHAR(50),
    amortization    VARCHAR(50),
    payment_freq    VARCHAR(20),
    day_count       VARCHAR(20),
    margin_bps      NUMERIC(9,4),
    reference_index VARCHAR(50),
    maturity_date   TIMESTAMPTZ,
    drawdown_limit  NUMERIC(18,2),
    created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at      TIMESTAMPTZ,
    valid_from      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to        TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to       TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current      BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted      BOOLEAN       NOT NULL DEFAULT FALSE,
    created_by     VARCHAR(255),

    last_modified_by     VARCHAR(255),
    CONSTRAINT pk_security_loan_attribute PRIMARY KEY (id),
    CONSTRAINT fk_sla_security FOREIGN KEY (security_id) REFERENCES security(id)
);
CREATE INDEX IF NOT EXISTS ix_sla_security_id ON security_loan_attribute(security_id);
CREATE INDEX IF NOT EXISTS ix_sla_is_current  ON security_loan_attribute(is_current);

-- ====================================================================
-- security_derivative_attribute
-- ====================================================================
CREATE TABLE IF NOT EXISTS security_derivative_attribute (
    id              UUID          NOT NULL DEFAULT gen_random_uuid(),
    security_id     UUID          NOT NULL,
    underlying_type VARCHAR(50),
    underlying_id   UUID,
    notional        NUMERIC(28,8),
    notional_ccy    CHAR(3),
    strike_price    NUMERIC(28,8),
    strike_ccy      CHAR(3),
    option_style    VARCHAR(20),
    option_type     VARCHAR(10),
    expiry_date     TIMESTAMPTZ,
    settlement_type VARCHAR(20),
    leg_count       INTEGER,
    created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at      TIMESTAMPTZ,
    valid_from      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to        TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to       TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current      BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted      BOOLEAN       NOT NULL DEFAULT FALSE,
    created_by     VARCHAR(255),

    last_modified_by     VARCHAR(255),
    CONSTRAINT pk_security_derivative_attribute PRIMARY KEY (id),
    CONSTRAINT fk_sda_security FOREIGN KEY (security_id) REFERENCES security(id)
);
CREATE INDEX IF NOT EXISTS ix_sda_security_id ON security_derivative_attribute(security_id);
CREATE INDEX IF NOT EXISTS ix_sda_is_current  ON security_derivative_attribute(is_current);

-- ====================================================================
-- security_securitized_attribute
-- ====================================================================
CREATE TABLE IF NOT EXISTS security_securitized_attribute (
    id                 UUID          NOT NULL DEFAULT gen_random_uuid(),
    security_id        UUID          NOT NULL,
    pool_id            VARCHAR(100),
    tranche_label      VARCHAR(50),
    tranche_seniority  VARCHAR(50),
    original_balance   NUMERIC(28,8),
    current_balance    NUMERIC(28,8),
    credit_enhancement NUMERIC(9,4),
    callable           BOOLEAN,
    call_date          TIMESTAMPTZ,
    created_at         TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at         TIMESTAMPTZ,
    valid_from         TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to           TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to          TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current         BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted         BOOLEAN       NOT NULL DEFAULT FALSE,
    created_by        VARCHAR(255),

    last_modified_by        VARCHAR(255),
    CONSTRAINT pk_security_securitized_attribute PRIMARY KEY (id),
    CONSTRAINT fk_ssa_security FOREIGN KEY (security_id) REFERENCES security(id)
);
CREATE INDEX IF NOT EXISTS ix_ssa_security_id ON security_securitized_attribute(security_id);
CREATE INDEX IF NOT EXISTS ix_ssa_is_current  ON security_securitized_attribute(is_current);

-- ====================================================================
-- security_attribute_kv
-- ====================================================================
CREATE TABLE IF NOT EXISTS security_attribute_kv (
    id             UUID          NOT NULL DEFAULT gen_random_uuid(),
    security_id    UUID          NOT NULL,
    attribute_name VARCHAR(100)  NOT NULL,
    attribute_type VARCHAR(20)   NOT NULL,
    value_string   VARCHAR(4000),
    value_decimal  NUMERIC(28,10),
    value_int      BIGINT,
    value_date     TIMESTAMPTZ,
    value_bool     BOOLEAN,
    source_system  VARCHAR(50),
    created_at     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at     TIMESTAMPTZ,
    valid_from     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to       TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from    TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to      TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current     BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted     BOOLEAN       NOT NULL DEFAULT FALSE,
    created_by    VARCHAR(255),

    last_modified_by    VARCHAR(255),
    CONSTRAINT pk_security_attribute_kv PRIMARY KEY (id),
    CONSTRAINT fk_sakv_security FOREIGN KEY (security_id) REFERENCES security(id)
);
CREATE INDEX IF NOT EXISTS ix_sakv_security_id  ON security_attribute_kv(security_id);
CREATE INDEX IF NOT EXISTS ix_sakv_name_current ON security_attribute_kv(security_id, attribute_name, is_current);
CREATE INDEX IF NOT EXISTS ix_sakv_is_current   ON security_attribute_kv(is_current);

-- ====================================================================
-- audit_log  (range-partitioned by created_at)
-- ====================================================================
CREATE TABLE IF NOT EXISTS audit_log (
    id             UUID        NOT NULL DEFAULT gen_random_uuid(),
    entity_type    VARCHAR(50) NOT NULL,
    action         VARCHAR(50) NOT NULL,
    user_id        UUID,
    user_name      VARCHAR(255),
    details        TEXT,
    ip_address     VARCHAR(45),
    entity_id      UUID,
    before_state   TEXT,
    after_state    TEXT,
    changed_fields TEXT,
    correlation_id UUID,
    causation_id   UUID,
    source         VARCHAR(50) NOT NULL DEFAULT 'Http',
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
) PARTITION BY RANGE (created_at);

CREATE TABLE IF NOT EXISTS audit_log_y2024 PARTITION OF audit_log
    FOR VALUES FROM ('2024-01-01') TO ('2025-01-01');
CREATE TABLE IF NOT EXISTS audit_log_y2025 PARTITION OF audit_log
    FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');
CREATE TABLE IF NOT EXISTS audit_log_y2026 PARTITION OF audit_log
    FOR VALUES FROM ('2026-01-01') TO ('2027-01-01');
CREATE TABLE IF NOT EXISTS audit_log_default PARTITION OF audit_log DEFAULT;

CREATE INDEX IF NOT EXISTS ix_audit_log_created_at     ON audit_log(created_at);
CREATE INDEX IF NOT EXISTS ix_audit_log_user_id        ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS ix_audit_log_entity         ON audit_log(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS ix_audit_log_correlation_id ON audit_log(correlation_id);

-- ====================================================================
-- audit_log_archive
-- ====================================================================
CREATE TABLE IF NOT EXISTS audit_log_archive (
    id             UUID        NOT NULL DEFAULT gen_random_uuid(),
    entity_type    VARCHAR(50) NOT NULL,
    action         VARCHAR(50) NOT NULL,
    user_id        UUID,
    user_name      VARCHAR(255),
    details        TEXT,
    ip_address     VARCHAR(45),
    entity_id      UUID,
    before_state   TEXT,
    after_state    TEXT,
    changed_fields TEXT,
    correlation_id UUID,
    causation_id   UUID,
    source         VARCHAR(50) NOT NULL DEFAULT 'Http',
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    archived_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT pk_audit_log_archive PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS ix_ala_entity         ON audit_log_archive(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS ix_ala_user_id        ON audit_log_archive(user_id);
CREATE INDEX IF NOT EXISTS ix_ala_correlation_id ON audit_log_archive(correlation_id);

-- ====================================================================
-- idempotency_key_store
-- ====================================================================
CREATE TABLE IF NOT EXISTS idempotency_key_store (
    key            VARCHAR(200) NOT NULL,
    operation_type VARCHAR(100) NOT NULL,
    status         VARCHAR(20)  NOT NULL DEFAULT 'PROCESSING',
    response_code  INTEGER,
    response_body  TEXT,
    created_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    expires_at     TIMESTAMPTZ  NOT NULL,
    CONSTRAINT pk_idempotency_key_store PRIMARY KEY (key),
    CONSTRAINT chk_idempotency_status CHECK (status IN ('PROCESSING','COMPLETED','FAILED'))
);
CREATE INDEX IF NOT EXISTS ix_idempotency_expires_at ON idempotency_key_store(expires_at);

-- ====================================================================
-- dead_letter_event
-- ====================================================================
CREATE TABLE IF NOT EXISTS dead_letter_event (
    id               UUID         NOT NULL DEFAULT gen_random_uuid(),
    event_type       VARCHAR(100) NOT NULL,
    correlation_id   UUID         NOT NULL,
    idempotency_key  VARCHAR(200),
    payload          TEXT         NOT NULL,
    failure_reason   VARCHAR(500) NOT NULL,
    failure_stage    INTEGER      NOT NULL DEFAULT 0,
    retry_count      INTEGER      NOT NULL DEFAULT 0,
    status           VARCHAR(20)  NOT NULL DEFAULT 'PENDING',
    resolved_by      VARCHAR(255),
    resolved_at      TIMESTAMPTZ,
    resolution_notes VARCHAR(500),
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at       TIMESTAMPTZ,
    created_by      VARCHAR(255),

    last_modified_by      VARCHAR(255),
    CONSTRAINT pk_dead_letter_event PRIMARY KEY (id),
    CONSTRAINT chk_dead_letter_status CHECK (status IN ('PENDING','IN_REVIEW','REPLAYED','RESOLVED','DISCARDED'))
);
CREATE INDEX IF NOT EXISTS ix_dle_status         ON dead_letter_event(status);
CREATE INDEX IF NOT EXISTS ix_dle_event_type     ON dead_letter_event(event_type);
CREATE INDEX IF NOT EXISTS ix_dle_correlation_id ON dead_letter_event(correlation_id);
CREATE INDEX IF NOT EXISTS ix_dle_created_at     ON dead_letter_event(created_at);

-- ====================================================================
-- import_request
-- ====================================================================
CREATE TABLE IF NOT EXISTS import_request (
    id                UUID        NOT NULL DEFAULT gen_random_uuid(),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_modified_at        TIMESTAMPTZ,
    request_type      VARCHAR(50) NOT NULL,
    source_system     VARCHAR(50),
    target_system     VARCHAR(50),
    status            VARCHAR(50) NOT NULL DEFAULT 'InProgress',
    user_id           UUID,
    user_name         VARCHAR(255),
    completed_at      TIMESTAMPTZ,
    error_message     TEXT,
    request_details   TEXT,
    total_records     INTEGER,
    processed_records INTEGER,
    failed_records    INTEGER,
    attempt_number    INTEGER     NOT NULL DEFAULT 0,
    skipped_records   INTEGER,
    CONSTRAINT pk_import_request PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS ix_import_request_status     ON import_request(status);
CREATE INDEX IF NOT EXISTS ix_import_request_created_at ON import_request(created_at);

-- ====================================================================
-- credit_rating
-- ====================================================================
CREATE TABLE IF NOT EXISTS credit_rating (
    id          UUID        NOT NULL DEFAULT gen_random_uuid(),
    security_id UUID        NOT NULL,
    agency      VARCHAR(50) NOT NULL,
    rating      VARCHAR(20) NOT NULL,
    rating_type VARCHAR(30) NOT NULL DEFAULT 'LongTerm',
    rating_date TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_modified_at  TIMESTAMPTZ,
    valid_from  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    valid_to    TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31',
    system_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    system_to   TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31',
    is_current  BOOLEAN     NOT NULL DEFAULT TRUE,
    is_deleted  BOOLEAN     NOT NULL DEFAULT FALSE,
    created_by VARCHAR(255),

    last_modified_by VARCHAR(255),
    content_hash VARCHAR(64),
    CONSTRAINT pk_credit_rating PRIMARY KEY (id),
    CONSTRAINT fk_credit_rating_security FOREIGN KEY (security_id) REFERENCES security(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_credit_rating_security_agency ON credit_rating(security_id, agency, rating_type, is_current);
CREATE INDEX IF NOT EXISTS ix_credit_rating_valid_time      ON credit_rating(valid_from, valid_to);

-- ====================================================================
-- derived_rating
-- ====================================================================
CREATE TABLE IF NOT EXISTS derived_rating (
    id                       UUID           NOT NULL DEFAULT gen_random_uuid(),
    security_id              UUID           NOT NULL,
    implied_rating_score     INTEGER,
    vpm_rating_score         INTEGER,
    fundamental_rating_score INTEGER,
    composite_rating_score   INTEGER,
    output_agency            VARCHAR(30)    NOT NULL DEFAULT 'SP',
    implied_rating           VARCHAR(20),
    vpm_rating               VARCHAR(20),
    fundamental_rating       VARCHAR(20),
    composite_rating         VARCHAR(20),
    implied_pd               NUMERIC(12,10),
    model_pd                 NUMERIC(12,10),
    fair_price               NUMERIC(18,6),
    source_hash              VARCHAR(64)    NOT NULL DEFAULT '',
    last_calculated_utc      TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    created_at               TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    last_modified_at               TIMESTAMPTZ,
    valid_from               TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    valid_to                 TIMESTAMPTZ    NOT NULL DEFAULT '9999-12-31',
    system_from              TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    system_to                TIMESTAMPTZ    NOT NULL DEFAULT '9999-12-31',
    is_current               BOOLEAN        NOT NULL DEFAULT TRUE,
    is_deleted               BOOLEAN        NOT NULL DEFAULT FALSE,
    created_by              VARCHAR(255),

    last_modified_by              VARCHAR(255),
    CONSTRAINT pk_derived_rating PRIMARY KEY (id),
    CONSTRAINT fk_derived_rating_security FOREIGN KEY (security_id) REFERENCES security(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_derived_rating_security_id      ON derived_rating(security_id);
CREATE INDEX IF NOT EXISTS ix_derived_rating_security_current ON derived_rating(security_id, is_current);
CREATE INDEX IF NOT EXISTS ix_derived_rating_valid_time       ON derived_rating(valid_from, valid_to);

-- ====================================================================
-- vendor_rating_metadata
-- ====================================================================
CREATE TABLE IF NOT EXISTS vendor_rating_metadata (
    id               UUID         NOT NULL DEFAULT gen_random_uuid(),
    vendor_name      VARCHAR(100) NOT NULL,
    accuracy_score   NUMERIC(5,4) NOT NULL DEFAULT 0.5,
    stability_score  NUMERIC(5,4) NOT NULL DEFAULT 0.5,
    timeliness_score NUMERIC(5,4) NOT NULL DEFAULT 0.5,
    coverage_score   NUMERIC(5,4) NOT NULL DEFAULT 0.5,
    last_updated_utc TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at       TIMESTAMPTZ,
    CONSTRAINT pk_vendor_rating_metadata PRIMARY KEY (id),
    CONSTRAINT uq_vendor_rating_metadata_vendor_name UNIQUE (vendor_name)
);

-- ====================================================================
-- rating_scale_entry
-- ====================================================================
CREATE TABLE IF NOT EXISTS rating_scale_entry (
    id                  UUID        NOT NULL DEFAULT gen_random_uuid(),
    agency              VARCHAR(50) NOT NULL,
    score               INTEGER     NOT NULL,
    label               VARCHAR(20) NOT NULL,
    is_investment_grade BOOLEAN     NOT NULL DEFAULT FALSE,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_modified_at          TIMESTAMPTZ,
    valid_from          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    valid_to            TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31',
    system_from         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    system_to           TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31',
    is_current          BOOLEAN     NOT NULL DEFAULT TRUE,
    is_deleted          BOOLEAN     NOT NULL DEFAULT FALSE,
    created_by         VARCHAR(255),

    last_modified_by         VARCHAR(255),
    CONSTRAINT pk_rating_scale_entry PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS ix_rating_scale_entry_agency_score ON rating_scale_entry(agency, score, is_current);
CREATE INDEX IF NOT EXISTS ix_rating_scale_entry_valid_time   ON rating_scale_entry(valid_from, valid_to);

-- ====================================================================
-- rating_derivation_rule
-- ====================================================================
CREATE TABLE IF NOT EXISTS rating_derivation_rule (
    id            UUID         NOT NULL DEFAULT gen_random_uuid(),
    model_name    VARCHAR(50)  NOT NULL,
    security_type VARCHAR(50),
    config_json   TEXT         NOT NULL,
    description   VARCHAR(500),
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at    TIMESTAMPTZ,
    valid_from    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to      TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to     TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current    BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted    BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by   VARCHAR(255),

    last_modified_by   VARCHAR(255),
    CONSTRAINT pk_rating_derivation_rule PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS ix_rating_derivation_rule_model_type ON rating_derivation_rule(model_name, security_type, is_current);
CREATE INDEX IF NOT EXISTS ix_rating_derivation_rule_valid_time ON rating_derivation_rule(valid_from, valid_to);

-- ====================================================================
-- formula_macro
-- ====================================================================
CREATE TABLE IF NOT EXISTS formula_macro (
    id          UUID         NOT NULL DEFAULT gen_random_uuid(),
    name        VARCHAR(100) NOT NULL,
    expression  TEXT         NOT NULL,
    description VARCHAR(500),
    scope       VARCHAR(50),
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at  TIMESTAMPTZ,
    valid_from  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to    TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to   TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current  BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted  BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by VARCHAR(255),

    last_modified_by VARCHAR(255),
    CONSTRAINT pk_formula_macro PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS ix_formula_macro_name_current ON formula_macro(name, is_current);
CREATE INDEX IF NOT EXISTS ix_formula_macro_valid_time   ON formula_macro(valid_from, valid_to);

-- ====================================================================
-- import_profile
-- ====================================================================
CREATE TABLE IF NOT EXISTS import_profile (
    id                        UUID         NOT NULL DEFAULT gen_random_uuid(),
    name                      VARCHAR(100) NOT NULL,
    description               VARCHAR(500),
    source_type               VARCHAR(50)  NOT NULL,
    file_pattern              VARCHAR(200) NOT NULL DEFAULT '*.csv',
    folder                    VARCHAR(500),
    delimiter                 VARCHAR(10),
    text_qualifier            VARCHAR(5),
    has_header                BOOLEAN      NOT NULL DEFAULT TRUE,
    skip_rows                 INTEGER      NOT NULL DEFAULT 0,
    records_path              VARCHAR(500),
    records_x_path            VARCHAR(500),
    transport_type            VARCHAR(20)  NOT NULL DEFAULT 'Local',
    transport_host            VARCHAR(500),
    transport_port            INTEGER,
    transport_username        VARCHAR(200),
    transport_password_secret VARCHAR(500),
    transport_remote_path     VARCHAR(500),
    transport_tls_thumbprint  VARCHAR(100),
    is_active                 BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at                TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at                TIMESTAMPTZ,
    CONSTRAINT pk_import_profile PRIMARY KEY (id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uix_import_profile_name_source ON import_profile(name, source_type);
CREATE INDEX IF NOT EXISTS ix_import_profile_source_active       ON import_profile(source_type, is_active);

-- ====================================================================
-- import_profile_column
-- ====================================================================
CREATE TABLE IF NOT EXISTS import_profile_column (
    id            UUID         NOT NULL DEFAULT gen_random_uuid(),
    profile_id    UUID         NOT NULL,
    source_column VARCHAR(200) NOT NULL,
    target_field  VARCHAR(200) NOT NULL,
    sort_order    INTEGER      NOT NULL DEFAULT 0,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at    TIMESTAMPTZ,
    CONSTRAINT pk_import_profile_column PRIMARY KEY (id),
    CONSTRAINT fk_ipc_profile FOREIGN KEY (profile_id) REFERENCES import_profile(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_import_profile_column_profile_id ON import_profile_column(profile_id);

-- ====================================================================
-- import_profile_column_validation
-- ====================================================================
CREATE TABLE IF NOT EXISTS import_profile_column_validation (
    id            UUID         NOT NULL DEFAULT gen_random_uuid(),
    column_id     UUID         NOT NULL,
    rule_type     VARCHAR(50)  NOT NULL,
    rule_value    VARCHAR(500),
    condition     VARCHAR(1000),
    error_message VARCHAR(500),
    severity      VARCHAR(20)  NOT NULL DEFAULT 'Error',
    is_active     BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at    TIMESTAMPTZ,
    CONSTRAINT pk_import_profile_column_validation PRIMARY KEY (id),
    CONSTRAINT fk_ipcv_column FOREIGN KEY (column_id) REFERENCES import_profile_column(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_ipcv_column_id ON import_profile_column_validation(column_id);

-- ====================================================================
-- import_profile_row_validation
-- ====================================================================
CREATE TABLE IF NOT EXISTS import_profile_row_validation (
    id            UUID        NOT NULL DEFAULT gen_random_uuid(),
    profile_id    UUID        NOT NULL,
    expression    TEXT        NOT NULL,
    error_message VARCHAR(500) NOT NULL,
    severity      VARCHAR(20) NOT NULL DEFAULT 'Error',
    sort_order    INTEGER     NOT NULL DEFAULT 0,
    is_active     BOOLEAN     NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_modified_at    TIMESTAMPTZ,
    CONSTRAINT pk_import_profile_row_validation PRIMARY KEY (id),
    CONSTRAINT fk_iprv_profile FOREIGN KEY (profile_id) REFERENCES import_profile(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_iprv_profile_id ON import_profile_row_validation(profile_id);

-- ====================================================================
-- job_execution_history
-- ====================================================================
CREATE TABLE IF NOT EXISTS job_execution_history (
    id              UUID          NOT NULL,
    job_name        VARCHAR(200)  NOT NULL,
    job_group       VARCHAR(200)  NOT NULL,
    triggered_by    VARCHAR(255)  NOT NULL DEFAULT 'scheduler',
    started_at      TIMESTAMPTZ   NOT NULL,
    completed_at    TIMESTAMPTZ,
    succeeded       BOOLEAN       NOT NULL DEFAULT FALSE,
    error_message   VARCHAR(2000),
    error_detail    TEXT,
    skipped_records INTEGER,
    CONSTRAINT pk_job_execution_history PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS ix_job_execution_history_job_name   ON job_execution_history(job_name);
CREATE INDEX IF NOT EXISTS ix_job_execution_history_started_at ON job_execution_history(started_at);

-- ====================================================================
-- job_schedule
-- ====================================================================
CREATE TABLE IF NOT EXISTS job_schedule (
    id              UUID         NOT NULL DEFAULT gen_random_uuid(),
    plugin_name     VARCHAR(200) NOT NULL,
    job_group       VARCHAR(200) NOT NULL,
    cron_expression VARCHAR(100),
    enabled         BOOLEAN      NOT NULL DEFAULT TRUE,
    time_zone       VARCHAR(100) NOT NULL DEFAULT 'UTC',
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at      TIMESTAMPTZ,
    valid_from      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to        TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to       TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current      BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted      BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by     VARCHAR(255),

    last_modified_by     VARCHAR(255),
    CONSTRAINT pk_job_schedule PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS ix_job_schedule_plugin_name ON job_schedule(plugin_name);
CREATE INDEX IF NOT EXISTS ix_job_schedule_is_current  ON job_schedule(is_current);
CREATE INDEX IF NOT EXISTS ix_job_schedule_system_time ON job_schedule(system_from, system_to);

-- ====================================================================
-- approval_request
-- ====================================================================
CREATE TABLE IF NOT EXISTS approval_request (
    id                UUID         NOT NULL DEFAULT gen_random_uuid(),
    type              VARCHAR(100) NOT NULL,
    status            VARCHAR(50)  NOT NULL DEFAULT 'Pending',
    security_ids      TEXT,
    requested_by      VARCHAR(256) NOT NULL,
    requested_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    reviewed_by       VARCHAR(256),
    reviewed_at       TIMESTAMPTZ,
    expires_at        TIMESTAMPTZ,
    notes             TEXT,
    export_request_id UUID,
    created_at        TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at        TIMESTAMPTZ,
    valid_from        TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to          TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to         TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current        BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted        BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by       VARCHAR(255),

    last_modified_by       VARCHAR(255),
    CONSTRAINT pk_approval_request PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS ix_approval_request_status       ON approval_request(status);
CREATE INDEX IF NOT EXISTS ix_approval_request_requested_at ON approval_request(requested_at);
CREATE INDEX IF NOT EXISTS ix_approval_request_is_current   ON approval_request(is_current);

-- ====================================================================
-- workflow_definition
-- ====================================================================
CREATE TABLE IF NOT EXISTS workflow_definition (
    id             UUID          NOT NULL DEFAULT gen_random_uuid(),
    name           VARCHAR(200)  NOT NULL,
    description    VARCHAR(1000),
    trigger_type   VARCHAR(50)   NOT NULL,
    is_enabled     BOOLEAN       NOT NULL DEFAULT TRUE,
    condition_json TEXT,
    created_at     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at     TIMESTAMPTZ,
    valid_from     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to       TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from    TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to      TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current     BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted     BOOLEAN       NOT NULL DEFAULT FALSE,
    created_by    VARCHAR(255),

    last_modified_by    VARCHAR(255),
    CONSTRAINT pk_workflow_definition PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS ix_wf_def_trigger_type ON workflow_definition(trigger_type);
CREATE INDEX IF NOT EXISTS ix_wf_def_is_enabled   ON workflow_definition(is_enabled);
CREATE INDEX IF NOT EXISTS ix_wf_def_is_current   ON workflow_definition(is_current);

-- ====================================================================
-- workflow_definition_step
-- ====================================================================
CREATE TABLE IF NOT EXISTS workflow_definition_step (
    id                    UUID         NOT NULL DEFAULT gen_random_uuid(),
    definition_id         UUID         NOT NULL,
    step_order            INTEGER      NOT NULL,
    name                  VARCHAR(200) NOT NULL,
    description           VARCHAR(500),
    step_type             VARCHAR(50)  NOT NULL,
    required_role         VARCHAR(100),
    required_approvals    INTEGER      NOT NULL DEFAULT 1,
    timeout_hours         INTEGER      NOT NULL DEFAULT 48,
    timeout_action        VARCHAR(50)  NOT NULL DEFAULT 'Expire',
    escalate_to_role      VARCHAR(100),
    on_approved_goto_step INTEGER,
    on_rejected_goto_step INTEGER,
    on_timeout_goto_step  INTEGER,
    action_config_json    TEXT,
    created_at            TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at      TIMESTAMPTZ,
    created_by            VARCHAR(255),
    last_modified_by      VARCHAR(255),
    CONSTRAINT pk_workflow_definition_step PRIMARY KEY (id),
    CONSTRAINT fk_wf_step_definition FOREIGN KEY (definition_id) REFERENCES workflow_definition(id)
);
CREATE INDEX IF NOT EXISTS ix_wf_step_definition_id    ON workflow_definition_step(definition_id);
CREATE INDEX IF NOT EXISTS ix_wf_step_definition_order ON workflow_definition_step(definition_id, step_order);

-- ====================================================================
-- workflow_instance
-- ====================================================================
CREATE TABLE IF NOT EXISTS workflow_instance (
    id                 UUID         NOT NULL DEFAULT gen_random_uuid(),
    definition_id      UUID,
    trigger_type       VARCHAR(50)  NOT NULL,
    entity_type        VARCHAR(100) NOT NULL,
    entity_id          UUID         NOT NULL,
    status             VARCHAR(50)  NOT NULL DEFAULT 'Pending',
    current_step_order INTEGER      NOT NULL DEFAULT 1,
    triggered_by       VARCHAR(255) NOT NULL,
    triggered_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    completed_at       TIMESTAMPTZ,
    payload_json       TEXT,
    created_at         TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at         TIMESTAMPTZ,
    valid_from         TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to           TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from        TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to          TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current         BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted         BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by        VARCHAR(255),

    last_modified_by        VARCHAR(255),
    CONSTRAINT pk_workflow_instance PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS ix_wf_inst_status         ON workflow_instance(status);
CREATE INDEX IF NOT EXISTS ix_wf_inst_entity_id      ON workflow_instance(entity_id);
CREATE INDEX IF NOT EXISTS ix_wf_inst_trigger_entity ON workflow_instance(trigger_type, entity_id);
CREATE INDEX IF NOT EXISTS ix_wf_inst_is_current     ON workflow_instance(is_current);

-- ====================================================================
-- workflow_step_instance
-- ====================================================================
CREATE TABLE IF NOT EXISTS workflow_step_instance (
    id                 UUID         NOT NULL DEFAULT gen_random_uuid(),
    instance_id        UUID         NOT NULL,
    step_order         INTEGER      NOT NULL,
    step_type          VARCHAR(50)  NOT NULL,
    required_role      VARCHAR(100),
    required_approvals INTEGER      NOT NULL DEFAULT 1,
    received_approvals INTEGER      NOT NULL DEFAULT 0,
    status             VARCHAR(50)  NOT NULL DEFAULT 'Waiting',
    timeout_at         TIMESTAMPTZ,
    reviewed_by        VARCHAR(255),
    reviewed_at        TIMESTAMPTZ,
    notes              TEXT,
    created_at         TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at         TIMESTAMPTZ,
    valid_from         TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to           TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from        TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to          TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current         BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted         BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by        VARCHAR(255),

    last_modified_by        VARCHAR(255),
    CONSTRAINT pk_workflow_step_instance PRIMARY KEY (id),
    CONSTRAINT fk_wf_step_inst_instance FOREIGN KEY (instance_id) REFERENCES workflow_instance(id)
);
CREATE INDEX IF NOT EXISTS ix_wf_step_inst_instance_id ON workflow_step_instance(instance_id);
CREATE INDEX IF NOT EXISTS ix_wf_step_inst_status      ON workflow_step_instance(status);
CREATE INDEX IF NOT EXISTS ix_wf_step_inst_role_status ON workflow_step_instance(required_role, status);
CREATE INDEX IF NOT EXISTS ix_wf_step_inst_is_current  ON workflow_step_instance(is_current);

-- ====================================================================
-- workflow_step_approval
-- ====================================================================
CREATE TABLE IF NOT EXISTS workflow_step_approval (
    id                UUID         NOT NULL DEFAULT gen_random_uuid(),
    instance_id       UUID         NOT NULL,
    step_instance_id  UUID,
    from_step_order   INTEGER      NOT NULL,
    target_step_order INTEGER,
    decision          VARCHAR(50)  NOT NULL,
    decision_by       VARCHAR(255) NOT NULL,
    decision_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    notes             TEXT,
    created_at        TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at        TIMESTAMPTZ,
    CONSTRAINT pk_workflow_step_approval PRIMARY KEY (id),
    CONSTRAINT fk_wf_approval_instance FOREIGN KEY (instance_id) REFERENCES workflow_instance(id)
);
CREATE INDEX IF NOT EXISTS ix_wf_approval_instance_id ON workflow_step_approval(instance_id);
CREATE INDEX IF NOT EXISTS ix_wf_approval_decision_at ON workflow_step_approval(decision_at);

-- ====================================================================
-- client
-- ====================================================================
CREATE TABLE IF NOT EXISTS client (
    id               UUID         NOT NULL DEFAULT gen_random_uuid(),
    name             VARCHAR(255) NOT NULL,
    code             VARCHAR(50)  NOT NULL,
    is_active        BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at TIMESTAMPTZ,
    valid_from       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to         TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31 23:59:59+00',
    system_from      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to        TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31 23:59:59+00',
    is_current       BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by       VARCHAR(255),
    last_modified_by VARCHAR(255),
    CONSTRAINT pk_client   PRIMARY KEY (id)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_client_code_current
    ON client(code) WHERE is_current = true AND is_deleted = false;
CREATE INDEX IF NOT EXISTS ix_client_is_current  ON client(is_current);
CREATE INDEX IF NOT EXISTS ix_client_is_deleted  ON client(is_deleted);
CREATE INDEX IF NOT EXISTS ix_client_valid_time  ON client(valid_from, valid_to);
CREATE INDEX IF NOT EXISTS ix_client_system_time ON client(system_from, system_to);

-- ====================================================================
-- client_contact
-- ====================================================================
CREATE TABLE IF NOT EXISTS client_contact (
    id               UUID         NOT NULL DEFAULT gen_random_uuid(),
    client_id        UUID         NOT NULL,
    contact_name     VARCHAR(255) NOT NULL,
    role             VARCHAR(100),
    email            VARCHAR(255),
    phone            VARCHAR(100),
    is_primary       BOOLEAN      NOT NULL DEFAULT FALSE,
    is_active        BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at TIMESTAMPTZ,
    valid_from       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to         TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31 23:59:59+00',
    system_from      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to        TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31 23:59:59+00',
    is_current       BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by       VARCHAR(255),
    last_modified_by VARCHAR(255),
    CONSTRAINT pk_client_contact PRIMARY KEY (id),
    CONSTRAINT fk_client_contact_client FOREIGN KEY (client_id) REFERENCES client(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS ix_client_contact_client_id  ON client_contact(client_id);
CREATE INDEX IF NOT EXISTS ix_client_contact_is_current ON client_contact(is_current);
CREATE INDEX IF NOT EXISTS ix_client_contact_is_deleted ON client_contact(is_deleted);

-- ====================================================================
-- portfolio
-- ====================================================================
CREATE TABLE IF NOT EXISTS portfolio (
    id               UUID         NOT NULL DEFAULT gen_random_uuid(),
    client_id        UUID         NOT NULL,
    name             VARCHAR(255) NOT NULL,
    code             VARCHAR(50)  NOT NULL,
    currency         VARCHAR(10)  NOT NULL DEFAULT 'USD',
    is_active        BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at TIMESTAMPTZ,
    valid_from       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to         TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31 23:59:59+00',
    system_from      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to        TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31 23:59:59+00',
    is_current       BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by       VARCHAR(255),
    last_modified_by VARCHAR(255),
    CONSTRAINT pk_portfolio PRIMARY KEY (id),
    CONSTRAINT fk_portfolio_client FOREIGN KEY (client_id) REFERENCES client(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_portfolio_code_current
    ON portfolio(code) WHERE is_current = true AND is_deleted = false;
CREATE INDEX IF NOT EXISTS ix_portfolio_client_id   ON portfolio(client_id);
CREATE INDEX IF NOT EXISTS ix_portfolio_is_current  ON portfolio(is_current);
CREATE INDEX IF NOT EXISTS ix_portfolio_is_deleted  ON portfolio(is_deleted);
CREATE INDEX IF NOT EXISTS ix_portfolio_valid_time  ON portfolio(valid_from, valid_to);
CREATE INDEX IF NOT EXISTS ix_portfolio_system_time ON portfolio(system_from, system_to);

-- ====================================================================
-- position
-- ====================================================================
CREATE TABLE IF NOT EXISTS position (
    id            UUID          NOT NULL DEFAULT gen_random_uuid(),
    portfolio_id  UUID          NOT NULL,
    security_id   UUID          NOT NULL,
    quantity      NUMERIC(28,8) NOT NULL,
    as_of_date    DATE          NOT NULL,
    market_value  NUMERIC(28,8),
    book_value    NUMERIC(28,8),
    currency_code CHAR(3)       NOT NULL,
    source_system VARCHAR(50)   NOT NULL,
    created_at    TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at    TIMESTAMPTZ,
    valid_from    TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to      TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from   TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to     TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current    BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted    BOOLEAN       NOT NULL DEFAULT FALSE,
    created_by   VARCHAR(255),

    last_modified_by   VARCHAR(255),
    CONSTRAINT pk_position PRIMARY KEY (id),
    CONSTRAINT fk_position_portfolio FOREIGN KEY (portfolio_id) REFERENCES portfolio(id),
    CONSTRAINT fk_position_security  FOREIGN KEY (security_id)  REFERENCES security(id)
);
CREATE INDEX IF NOT EXISTS ix_position_portfolio_id                ON position(portfolio_id);
CREATE INDEX IF NOT EXISTS ix_position_security_id                 ON position(security_id);
CREATE INDEX IF NOT EXISTS ix_position_portfolio_security_asofdate ON position(portfolio_id, security_id, as_of_date);
CREATE INDEX IF NOT EXISTS ix_position_is_current                  ON position(is_current);

-- ====================================================================
-- field_visibility_entity
-- ====================================================================
CREATE TABLE IF NOT EXISTS field_visibility_entity (
    id           UUID          NOT NULL DEFAULT gen_random_uuid(),
    entity_type  VARCHAR(200)  NOT NULL,
    display_name VARCHAR(200)  NOT NULL,
    description  VARCHAR(1000),
    is_active    BOOLEAN       NOT NULL DEFAULT TRUE,
    created_at   TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at   TIMESTAMPTZ,
    valid_from   TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to     TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from  TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to    TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current   BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted   BOOLEAN       NOT NULL DEFAULT FALSE,
    created_by  VARCHAR(255),

    last_modified_by  VARCHAR(255),
    CONSTRAINT pk_field_visibility_entity PRIMARY KEY (id),
    CONSTRAINT uq_field_visibility_entity_type UNIQUE (entity_type)
);
CREATE INDEX IF NOT EXISTS ix_fve_is_active  ON field_visibility_entity(is_active);
CREATE INDEX IF NOT EXISTS ix_fve_is_current ON field_visibility_entity(is_current);

-- ====================================================================
-- field_visibility_field
-- ====================================================================
CREATE TABLE IF NOT EXISTS field_visibility_field (
    id                         UUID         NOT NULL DEFAULT gen_random_uuid(),
    field_visibility_entity_id UUID         NOT NULL,
    field_name                 VARCHAR(200) NOT NULL,
    display_name               VARCHAR(200) NOT NULL,
    data_type                  VARCHAR(100),
    sensitivity_level          VARCHAR(100),
    default_visibility_state   VARCHAR(20)  NOT NULL DEFAULT 'VISIBLE',
    default_obfuscation_type   VARCHAR(30)  NOT NULL DEFAULT 'NONE',
    sort_order                 INTEGER      NOT NULL DEFAULT 0,
    is_active                  BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at                 TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at                 TIMESTAMPTZ,
    valid_from                 TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to                   TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from                TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to                  TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current                 BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted                 BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by                VARCHAR(255),

    last_modified_by                VARCHAR(255),
    CONSTRAINT pk_field_visibility_field PRIMARY KEY (id),
    CONSTRAINT uq_fvf_entity_field UNIQUE (field_visibility_entity_id, field_name),
    CONSTRAINT fk_fvf_entity FOREIGN KEY (field_visibility_entity_id) REFERENCES field_visibility_entity(id) ON DELETE CASCADE,
    CONSTRAINT chk_fvf_default_visibility_state CHECK (default_visibility_state IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED')),
    CONSTRAINT chk_fvf_default_obfuscation_type CHECK (default_obfuscation_type IN ('NONE','TEXT','EMAIL','NAME','DATE','NUMBER','CUSTOM'))
);
CREATE INDEX IF NOT EXISTS ix_fvf_entity_id  ON field_visibility_field(field_visibility_entity_id);
CREATE INDEX IF NOT EXISTS ix_fvf_is_active  ON field_visibility_field(is_active);
CREATE INDEX IF NOT EXISTS ix_fvf_is_current ON field_visibility_field(is_current);

-- ====================================================================
-- field_group
-- ====================================================================
CREATE TABLE IF NOT EXISTS field_group (
    id                          UUID         NOT NULL DEFAULT gen_random_uuid(),
    field_visibility_entity_id  UUID         NOT NULL,
    group_key                   VARCHAR(100) NOT NULL,
    display_name                VARCHAR(200) NOT NULL,
    description                 TEXT,
    sort_order                  INTEGER      NOT NULL DEFAULT 0,
    is_active                   BOOLEAN      NOT NULL DEFAULT TRUE,
    -- BaseEntity
    created_by                  VARCHAR(200),
    created_at                  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_by                  VARCHAR(200),
    last_modified_at                  TIMESTAMPTZ,
    -- TemporalEntity
    valid_from                  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to                    TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from                 TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to                   TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current                  BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted                  BOOLEAN      NOT NULL DEFAULT FALSE,
    last_modified_by                 VARCHAR(200),
    CONSTRAINT pk_field_group PRIMARY KEY (id),
    CONSTRAINT fk_field_group_entity FOREIGN KEY (field_visibility_entity_id) REFERENCES field_visibility_entity(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_field_group_key ON field_group(group_key) WHERE is_current = TRUE AND is_deleted = FALSE;
CREATE INDEX IF NOT EXISTS ix_field_group_entity_id  ON field_group(field_visibility_entity_id);
CREATE INDEX IF NOT EXISTS ix_field_group_is_current ON field_group(is_current);

-- ====================================================================
-- field_group_member
-- ====================================================================
CREATE TABLE IF NOT EXISTS field_group_member (
    id                          UUID        NOT NULL DEFAULT gen_random_uuid(),
    field_group_id              UUID        NOT NULL,
    field_visibility_field_id   UUID        NOT NULL,
    -- BaseEntity
    created_by                  VARCHAR(200),
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_by                  VARCHAR(200),
    last_modified_at                  TIMESTAMPTZ,
    -- TemporalEntity
    valid_from                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    valid_to                    TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31',
    system_from                 TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    system_to                   TIMESTAMPTZ NOT NULL DEFAULT '9999-12-31',
    is_current                  BOOLEAN     NOT NULL DEFAULT TRUE,
    is_deleted                  BOOLEAN     NOT NULL DEFAULT FALSE,
    last_modified_by                 VARCHAR(200),
    CONSTRAINT pk_field_group_member PRIMARY KEY (id),
    CONSTRAINT fk_field_group_member_group FOREIGN KEY (field_group_id)            REFERENCES field_group(id),
    CONSTRAINT fk_field_group_member_field FOREIGN KEY (field_visibility_field_id) REFERENCES field_visibility_field(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_field_group_member ON field_group_member(field_group_id, field_visibility_field_id) WHERE is_current = TRUE AND is_deleted = FALSE;
CREATE INDEX IF NOT EXISTS ix_field_group_member_group_id ON field_group_member(field_group_id);
CREATE INDEX IF NOT EXISTS ix_field_group_member_field_id ON field_group_member(field_visibility_field_id);

-- ====================================================================
-- permission_definition
-- ====================================================================
CREATE TABLE IF NOT EXISTS permission_definition (
    id               UUID          NOT NULL DEFAULT gen_random_uuid(),
    permission_key   VARCHAR(200)  NOT NULL,
    display_name     VARCHAR(200)  NOT NULL,
    permission_group VARCHAR(100)  NOT NULL,
    description      VARCHAR(1000),
    is_assignable    BOOLEAN       NOT NULL DEFAULT TRUE,
    is_system        BOOLEAN       NOT NULL DEFAULT FALSE,
    sort_order       INTEGER       NOT NULL DEFAULT 0,
    is_active        BOOLEAN       NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at       TIMESTAMPTZ,
    valid_from       TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to         TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to        TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current       BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN       NOT NULL DEFAULT FALSE,
    created_by      VARCHAR(255),

    last_modified_by      VARCHAR(255),
    CONSTRAINT pk_permission_definition PRIMARY KEY (id),
    CONSTRAINT uq_permission_definition_key UNIQUE (permission_key)
);
CREATE INDEX IF NOT EXISTS ix_pd_group      ON permission_definition(permission_group);
CREATE INDEX IF NOT EXISTS ix_pd_is_current ON permission_definition(is_current);

-- ====================================================================
-- field_visibility_rule
-- ====================================================================
CREATE TABLE IF NOT EXISTS field_visibility_rule (
    id                        UUID         NOT NULL DEFAULT gen_random_uuid(),
    field_visibility_field_id UUID         NOT NULL,
    permission_definition_id  UUID         NOT NULL,
    visibility_state          VARCHAR(20)  NOT NULL,
    obfuscation_type          VARCHAR(30)  NOT NULL DEFAULT 'NONE',
    priority                  INTEGER      NOT NULL DEFAULT 10,
    is_active                 BOOLEAN      NOT NULL DEFAULT TRUE,
    effective_from            TIMESTAMPTZ,
    effective_to              TIMESTAMPTZ,
    created_by                VARCHAR(150) NOT NULL,
    updated_by                VARCHAR(150),
    created_at                TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at                TIMESTAMPTZ,
    valid_from                TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to                  TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from               TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to                 TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current                BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted                BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by               VARCHAR(255),

    last_modified_by               VARCHAR(255),
    CONSTRAINT pk_field_visibility_rule PRIMARY KEY (id),
    CONSTRAINT fk_fvr_field      FOREIGN KEY (field_visibility_field_id) REFERENCES field_visibility_field(id) ON DELETE CASCADE,
    CONSTRAINT fk_fvr_permission FOREIGN KEY (permission_definition_id)  REFERENCES permission_definition(id),
    CONSTRAINT chk_fvr_visibility_state CHECK (visibility_state IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED')),
    CONSTRAINT chk_fvr_obfuscation_type CHECK (obfuscation_type IN ('NONE','TEXT','EMAIL','NAME','DATE','NUMBER','CUSTOM'))
);
CREATE INDEX IF NOT EXISTS ix_fvr_field_id       ON field_visibility_rule(field_visibility_field_id);
CREATE INDEX IF NOT EXISTS ix_fvr_permission_def ON field_visibility_rule(permission_definition_id);
CREATE INDEX IF NOT EXISTS ix_fvr_is_current     ON field_visibility_rule(is_current);

-- ====================================================================
-- app_resource
-- ====================================================================
CREATE TABLE IF NOT EXISTS app_resource (
    id                       UUID          NOT NULL DEFAULT gen_random_uuid(),
    resource_type            VARCHAR(30)   NOT NULL,
    resource_key             VARCHAR(300)  NOT NULL,
    parent_app_resource_id   UUID,
    display_name             VARCHAR(200)  NOT NULL,
    route_path               VARCHAR(300),
    icon_name                VARCHAR(100),
    description              VARCHAR(1000),
    default_visibility_state VARCHAR(20)   NOT NULL DEFAULT 'VISIBLE',
    default_execution_state  VARCHAR(20)   NOT NULL DEFAULT 'ALLOW',
    is_security_sensitive    BOOLEAN       NOT NULL DEFAULT FALSE,
    sort_order               INTEGER       NOT NULL DEFAULT 0,
    is_active                BOOLEAN       NOT NULL DEFAULT TRUE,
    created_at               TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at               TIMESTAMPTZ,
    valid_from               TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to                 TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from              TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to                TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current               BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted               BOOLEAN       NOT NULL DEFAULT FALSE,
    created_by              VARCHAR(255),

    last_modified_by              VARCHAR(255),
    CONSTRAINT pk_app_resource PRIMARY KEY (id),
    CONSTRAINT fk_app_resource_parent FOREIGN KEY (parent_app_resource_id) REFERENCES app_resource(id),
    CONSTRAINT chk_app_resource_type             CHECK (resource_type IN ('MENU_GROUP','MENU_ITEM','ROUTE','ACTION','TAB','SECTION')),
    CONSTRAINT chk_app_resource_visibility_state CHECK (default_visibility_state IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED')),
    CONSTRAINT chk_app_resource_execution_state  CHECK (default_execution_state  IN ('ALLOW','DENY','NOT_APPLICABLE'))
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_app_resource_key ON app_resource(resource_key) WHERE is_current = true;
CREATE INDEX IF NOT EXISTS ix_ar_parent_id  ON app_resource(parent_app_resource_id);
CREATE INDEX IF NOT EXISTS ix_ar_is_active  ON app_resource(is_active);
CREATE INDEX IF NOT EXISTS ix_ar_is_current ON app_resource(is_current);

-- ====================================================================
-- entity_screen
-- ====================================================================
CREATE TABLE IF NOT EXISTS entity_screen (
    id              UUID         NOT NULL DEFAULT gen_random_uuid(),
    screen_key      VARCHAR(200) NOT NULL,
    display_name    VARCHAR(200) NOT NULL,
    entity_type     VARCHAR(200),
    app_resource_id UUID,
    description     TEXT,
    sort_order      INTEGER      NOT NULL DEFAULT 0,
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
    -- BaseEntity
    created_by      VARCHAR(200),
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_by      VARCHAR(200),
    last_modified_at      TIMESTAMPTZ,
    -- TemporalEntity
    valid_from      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to        TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to       TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current      BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted      BOOLEAN      NOT NULL DEFAULT FALSE,
    last_modified_by     VARCHAR(200),
    CONSTRAINT pk_entity_screen PRIMARY KEY (id),
    CONSTRAINT fk_entity_screen_app_resource FOREIGN KEY (app_resource_id) REFERENCES app_resource(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_entity_screen_key ON entity_screen(screen_key) WHERE is_current = TRUE AND is_deleted = FALSE;
CREATE INDEX IF NOT EXISTS ix_entity_screen_app_resource_id ON entity_screen(app_resource_id);
CREATE INDEX IF NOT EXISTS ix_entity_screen_is_current      ON entity_screen(is_current);

-- ====================================================================
-- permission_bundle
-- ====================================================================
CREATE TABLE IF NOT EXISTS permission_bundle (
    id               UUID          NOT NULL DEFAULT gen_random_uuid(),
    bundle_key       VARCHAR(200)  NOT NULL,
    display_name     VARCHAR(200)  NOT NULL,
    description      VARCHAR(1000),
    is_active        BOOLEAN       NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at TIMESTAMPTZ,
    created_by       VARCHAR(255),
    last_modified_by VARCHAR(255),
    valid_from       TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to         TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to        TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current       BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN       NOT NULL DEFAULT FALSE,
    CONSTRAINT pk_permission_bundle PRIMARY KEY (id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_permission_bundle_key ON permission_bundle(bundle_key) WHERE is_current = TRUE AND is_deleted = FALSE;
CREATE INDEX IF NOT EXISTS ix_permission_bundle_is_current ON permission_bundle(is_current);

-- ====================================================================
-- permission_bundle_member
-- ====================================================================
CREATE TABLE IF NOT EXISTS permission_bundle_member (
    id                       UUID         NOT NULL DEFAULT gen_random_uuid(),
    permission_bundle_id     UUID         NOT NULL,
    permission_definition_id UUID         NOT NULL,
    created_at               TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at         TIMESTAMPTZ,
    created_by               VARCHAR(255),
    last_modified_by         VARCHAR(255),
    CONSTRAINT pk_permission_bundle_member PRIMARY KEY (id),
    CONSTRAINT uq_permission_bundle_member UNIQUE (permission_bundle_id, permission_definition_id),
    CONSTRAINT fk_pbm_bundle     FOREIGN KEY (permission_bundle_id)     REFERENCES permission_bundle(id)     ON DELETE CASCADE,
    CONSTRAINT fk_pbm_definition FOREIGN KEY (permission_definition_id) REFERENCES permission_definition(id) ON DELETE RESTRICT
);
CREATE INDEX IF NOT EXISTS ix_pbm_bundle_id ON permission_bundle_member(permission_bundle_id);

-- ====================================================================
-- policy_template
-- ====================================================================
CREATE TABLE IF NOT EXISTS policy_template (
    id               UUID          NOT NULL DEFAULT gen_random_uuid(),
    template_key     VARCHAR(200)  NOT NULL,
    template_name    VARCHAR(200)  NOT NULL,
    target_type      VARCHAR(100)  NOT NULL,
    description      VARCHAR(1000),
    template_json    TEXT          NOT NULL DEFAULT '{}',
    is_active        BOOLEAN       NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    last_modified_at TIMESTAMPTZ,
    created_by       VARCHAR(255),
    last_modified_by VARCHAR(255),
    valid_from       TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    valid_to         TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    system_from      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    system_to        TIMESTAMPTZ   NOT NULL DEFAULT '9999-12-31',
    is_current       BOOLEAN       NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN       NOT NULL DEFAULT FALSE,
    CONSTRAINT pk_policy_template PRIMARY KEY (id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_policy_template_key ON policy_template(template_key) WHERE is_current = TRUE AND is_deleted = FALSE;
CREATE INDEX IF NOT EXISTS ix_policy_template_is_current ON policy_template(is_current);

-- ====================================================================
-- app_resource_rule
-- ====================================================================
CREATE TABLE IF NOT EXISTS app_resource_rule (
    id                       UUID         NOT NULL DEFAULT gen_random_uuid(),
    app_resource_id          UUID         NOT NULL,
    permission_definition_id UUID         NOT NULL,
    visibility_state         VARCHAR(20)  NOT NULL,
    execution_state          VARCHAR(20)  NOT NULL,
    priority                 INTEGER      NOT NULL DEFAULT 100,
    is_active                BOOLEAN      NOT NULL DEFAULT TRUE,
    effective_from           TIMESTAMPTZ,
    effective_to             TIMESTAMPTZ,
    created_by               VARCHAR(150) NOT NULL,
    updated_by               VARCHAR(150),
    created_at               TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at               TIMESTAMPTZ,
    valid_from               TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to                 TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from              TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to                TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current               BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted               BOOLEAN      NOT NULL DEFAULT FALSE,
    created_by              VARCHAR(255),

    last_modified_by              VARCHAR(255),
    CONSTRAINT pk_app_resource_rule PRIMARY KEY (id),
    CONSTRAINT fk_arr_resource   FOREIGN KEY (app_resource_id)          REFERENCES app_resource(id) ON DELETE CASCADE,
    CONSTRAINT fk_arr_permission FOREIGN KEY (permission_definition_id) REFERENCES permission_definition(id),
    CONSTRAINT chk_arr_visibility CHECK (visibility_state IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED')),
    CONSTRAINT chk_arr_execution  CHECK (execution_state  IN ('ALLOW','DENY','NOT_APPLICABLE'))
);
CREATE INDEX IF NOT EXISTS ix_arr_resource_id    ON app_resource_rule(app_resource_id);
CREATE INDEX IF NOT EXISTS ix_arr_permission_def ON app_resource_rule(permission_definition_id);
CREATE INDEX IF NOT EXISTS ix_arr_is_current     ON app_resource_rule(is_current);

-- ====================================================================
-- vendor_source
-- ====================================================================
CREATE TABLE IF NOT EXISTS vendor_source (
    id                        UUID         NOT NULL DEFAULT gen_random_uuid(),
    code                      VARCHAR(50)  NOT NULL,
    display_name              VARCHAR(100) NOT NULL,
    global_priority           INTEGER      NOT NULL DEFAULT 100,
    staleness_threshold_hours INTEGER      NOT NULL DEFAULT 24,
    is_active                 BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at                TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at                TIMESTAMPTZ,
    created_by               VARCHAR(255),

    last_modified_by               VARCHAR(255),
    valid_from                TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to                  TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from               TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to                 TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current                BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted                BOOLEAN      NOT NULL DEFAULT FALSE,
    CONSTRAINT pk_vendor_source PRIMARY KEY (id),
    CONSTRAINT uq_vendor_source_code UNIQUE (code)
);
CREATE INDEX IF NOT EXISTS ix_vs_is_active  ON vendor_source(is_active);
CREATE INDEX IF NOT EXISTS ix_vs_is_current ON vendor_source(is_current);

-- Deferred FKs
ALTER TABLE price ADD CONSTRAINT fk_price_vendor_source
    FOREIGN KEY (vendor_source_id) REFERENCES vendor_source(id);
ALTER TABLE issuer ADD CONSTRAINT fk_issuer_country
    FOREIGN KEY (country_alpha2) REFERENCES country(alpha2);

-- ====================================================================
-- vendor_field_priority
-- ====================================================================
CREATE TABLE IF NOT EXISTS vendor_field_priority (
    id               UUID         NOT NULL DEFAULT gen_random_uuid(),
    vendor_source_id UUID         NOT NULL,
    field_name       VARCHAR(100) NOT NULL,
    asset_class_code VARCHAR(50),
    priority         INTEGER      NOT NULL DEFAULT 100,
    is_active        BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at       TIMESTAMPTZ,
    created_by      VARCHAR(255),

    last_modified_by      VARCHAR(255),
    valid_from       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to         TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to        TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current       BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN      NOT NULL DEFAULT FALSE,
    CONSTRAINT pk_vendor_field_priority PRIMARY KEY (id),
    CONSTRAINT fk_vfp_vendor FOREIGN KEY (vendor_source_id) REFERENCES vendor_source(id),
    CONSTRAINT uq_vfp_key UNIQUE (vendor_source_id, field_name, asset_class_code)
);
CREATE INDEX IF NOT EXISTS ix_vfp_vendor_id  ON vendor_field_priority(vendor_source_id);
CREATE INDEX IF NOT EXISTS ix_vfp_field_name ON vendor_field_priority(field_name);
CREATE INDEX IF NOT EXISTS ix_vfp_is_current ON vendor_field_priority(is_current);

-- ====================================================================
-- security_vendor_data
-- ====================================================================
CREATE TABLE IF NOT EXISTS security_vendor_data (
    id               UUID         NOT NULL DEFAULT gen_random_uuid(),
    security_id      UUID         NOT NULL,
    vendor_source_id UUID         NOT NULL,
    field_name       VARCHAR(100) NOT NULL,
    raw_value        VARCHAR(500),
    feed_batch_id    VARCHAR(200),
    received_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT pk_security_vendor_data PRIMARY KEY (id),
    CONSTRAINT fk_svd_security      FOREIGN KEY (security_id)      REFERENCES security(id),
    CONSTRAINT fk_svd_vendor_source FOREIGN KEY (vendor_source_id) REFERENCES vendor_source(id)
);
CREATE INDEX IF NOT EXISTS ix_svd_security_id           ON security_vendor_data(security_id);
CREATE INDEX IF NOT EXISTS ix_svd_vendor_source_id      ON security_vendor_data(vendor_source_id);
CREATE INDEX IF NOT EXISTS ix_svd_feed_batch_id         ON security_vendor_data(feed_batch_id);
CREATE INDEX IF NOT EXISTS ix_svd_security_vendor_field ON security_vendor_data(security_id, vendor_source_id, field_name, received_at);

-- ====================================================================
-- data_lineage_event
-- ====================================================================
CREATE TABLE IF NOT EXISTS data_lineage_event (
    id                  UUID          NOT NULL DEFAULT gen_random_uuid(),
    security_id         UUID          NOT NULL,
    field_name          VARCHAR(100)  NOT NULL,
    field_value         VARCHAR(500),
    source_type         VARCHAR(30)   NOT NULL,
    vendor_source_id    UUID,
    feed_batch_id       VARCHAR(100),
    resolution_rule     VARCHAR(500),
    runner_up_vendor_id UUID,
    runner_up_value     VARCHAR(500),
    override_user_id    VARCHAR(100),
    override_reason     VARCHAR(1000),
    resolved_at         TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    CONSTRAINT pk_data_lineage_event PRIMARY KEY (id),
    CONSTRAINT chk_dle_source_type CHECK (source_type IN ('VENDOR','MANUAL_OVERRIDE','SYSTEM_DEFAULT','DERIVED')),
    CONSTRAINT fk_dle_security      FOREIGN KEY (security_id)         REFERENCES security(id),
    CONSTRAINT fk_dle_vendor_source FOREIGN KEY (vendor_source_id)    REFERENCES vendor_source(id),
    CONSTRAINT fk_dle_runner_up     FOREIGN KEY (runner_up_vendor_id) REFERENCES vendor_source(id)
);
CREATE INDEX IF NOT EXISTS ix_dle_security_id         ON data_lineage_event(security_id);
CREATE INDEX IF NOT EXISTS ix_dle_source_type         ON data_lineage_event(source_type);
CREATE INDEX IF NOT EXISTS ix_dle_security_field_date ON data_lineage_event(security_id, field_name, resolved_at);

-- ====================================================================
-- user_cache  (populated automatically from JWT claims on every request)
-- ====================================================================
CREATE TABLE IF NOT EXISTS user_cache (
    id           VARCHAR(36)  NOT NULL,
    display_name VARCHAR(255) NOT NULL,
    last_seen    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    CONSTRAINT pk_user_cache PRIMARY KEY (id)
);

-- ====================================================================
-- Identity indexes
-- ====================================================================
CREATE UNIQUE INDEX IF NOT EXISTS user_name_index ON "AspNetUsers"("NormalizedUserName");
CREATE        INDEX IF NOT EXISTS email_index     ON "AspNetUsers"("NormalizedEmail");
CREATE UNIQUE INDEX IF NOT EXISTS role_name_index ON "AspNetRoles"("NormalizedName");
CREATE        INDEX IF NOT EXISTS ix_aspnetuserlogins_userid ON "AspNetUserLogins"("UserId");
CREATE        INDEX IF NOT EXISTS ix_aspnetuserclaims_userid ON "AspNetUserClaims"("UserId");
CREATE        INDEX IF NOT EXISTS ix_aspnetuserroles_roleid  ON "AspNetUserRoles"("RoleId");
CREATE        INDEX IF NOT EXISTS ix_aspnetroleclaims_roleid ON "AspNetRoleClaims"("RoleId");

-- ====================================================================
-- app_resource_group
-- ====================================================================
CREATE TABLE IF NOT EXISTS app_resource_group (
    id               UUID         NOT NULL DEFAULT gen_random_uuid(),
    group_key        VARCHAR(200) NOT NULL,
    display_name     VARCHAR(200) NOT NULL,
    description      VARCHAR(1000),
    icon_name        VARCHAR(100),
    sort_order       INTEGER      NOT NULL DEFAULT 0,
    is_active        BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    last_modified_at TIMESTAMPTZ,
    created_by       VARCHAR(255),
    last_modified_by VARCHAR(255),
    valid_from       TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    valid_to         TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    system_from      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    system_to        TIMESTAMPTZ  NOT NULL DEFAULT '9999-12-31',
    is_current       BOOLEAN      NOT NULL DEFAULT TRUE,
    is_deleted       BOOLEAN      NOT NULL DEFAULT FALSE,
    CONSTRAINT pk_app_resource_group PRIMARY KEY (id)
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_app_resource_group_key ON app_resource_group(group_key) WHERE is_current = true AND is_deleted = false;
CREATE INDEX IF NOT EXISTS ix_arg_is_current ON app_resource_group(is_current);

-- ====================================================================
-- Version record
-- ====================================================================
INSERT INTO "__SchemaVersions" (version, description, script_name)
VALUES ('2.0', 'Full schema parity with SQL Server (all milestones through QW4)', 'CreateSchema_PostgreSQL.sql')
ON CONFLICT (version) DO NOTHING;

\echo 'SecurityApp schema created successfully.';

