﻿-- ====================================================================
-- SecurityApp — Complete Schema (MySQL)
-- Fully idempotent. All CREATE TABLE / INDEX use IF NOT EXISTS.
-- Type map from SQL Server:
--   UNIQUEIDENTIFIER  -> CHAR(36), DEFAULT (UUID())
--   NVARCHAR(n)       -> VARCHAR(n), MAX -> TEXT/LONGTEXT
--   NCHAR(n)          -> CHAR(n)
--   DATETIME2         -> DATETIME(6)
--   BIT               -> TINYINT(1)
--   ROWVERSION        -> omitted
--   IDENTITY          -> AUTO_INCREMENT
--   DECIMAL(x,y)      -> DECIMAL(x,y)
--   Filtered indexes  -> regular indexes (MySQL has no partial indexes)
--   All tables: ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
-- ====================================================================

SELECT 'Creating SecurityApp schema (MySQL)...' AS status;

-- ====================================================================
-- Schema version tracking
-- ====================================================================
CREATE TABLE IF NOT EXISTS `__SchemaVersions` (
    `id`             INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `version`        VARCHAR(50)  NOT NULL,
    `description`    TEXT         NOT NULL,
    `script_name`    VARCHAR(255) NOT NULL DEFAULT '',
    `applied_on`     DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `applied_by`     VARCHAR(100) NOT NULL DEFAULT (CURRENT_USER()),
    `execution_time` VARCHAR(50),
    `status`         VARCHAR(20)  NOT NULL DEFAULT 'Success',
    CONSTRAINT uq_schemaversions_version UNIQUE (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- ASP.NET Identity tables
-- ====================================================================
CREATE TABLE IF NOT EXISTS `AspNetRoles` (
    `Id`               VARCHAR(255) NOT NULL PRIMARY KEY,
    `Name`             VARCHAR(256),
    `NormalizedName`   VARCHAR(256),
    `ConcurrencyStamp` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `AspNetUsers` (
    `Id`                   VARCHAR(255) NOT NULL PRIMARY KEY,
    `UserName`             VARCHAR(256),
    `NormalizedUserName`   VARCHAR(256),
    `Email`                VARCHAR(256),
    `NormalizedEmail`      VARCHAR(256),
    `EmailConfirmed`       TINYINT(1)   NOT NULL DEFAULT 0,
    `PasswordHash`         TEXT,
    `SecurityStamp`        TEXT,
    `ConcurrencyStamp`     TEXT,
    `PhoneNumber`          TEXT,
    `PhoneNumberConfirmed` TINYINT(1)   NOT NULL DEFAULT 0,
    `TwoFactorEnabled`     TINYINT(1)   NOT NULL DEFAULT 0,
    `LockoutEnd`           DATETIME(6),
    `LockoutEnabled`       TINYINT(1)   NOT NULL DEFAULT 0,
    `AccessFailedCount`    INT          NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `AspNetUserRoles` (
    `UserId` VARCHAR(255) NOT NULL,
    `RoleId` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`UserId`, `RoleId`),
    CONSTRAINT fk_aspnetuserroles_users FOREIGN KEY (`UserId`) REFERENCES `AspNetUsers` (`Id`) ON DELETE CASCADE,
    CONSTRAINT fk_aspnetuserroles_roles FOREIGN KEY (`RoleId`) REFERENCES `AspNetRoles`  (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `AspNetUserClaims` (
    `Id`         INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `UserId`     VARCHAR(255) NOT NULL,
    `ClaimType`  TEXT,
    `ClaimValue` TEXT,
    CONSTRAINT fk_aspnetuserclaims_users FOREIGN KEY (`UserId`) REFERENCES `AspNetUsers` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `AspNetUserLogins` (
    `LoginProvider`       VARCHAR(255) NOT NULL,
    `ProviderKey`         VARCHAR(255) NOT NULL,
    `ProviderDisplayName` TEXT,
    `UserId`              VARCHAR(255) NOT NULL,
    PRIMARY KEY (`LoginProvider`, `ProviderKey`),
    CONSTRAINT fk_aspnetuserlogins_users FOREIGN KEY (`UserId`) REFERENCES `AspNetUsers` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `AspNetUserTokens` (
    `UserId`        VARCHAR(255) NOT NULL,
    `LoginProvider` VARCHAR(255) NOT NULL,
    `Name`          VARCHAR(255) NOT NULL,
    `Value`         TEXT,
    PRIMARY KEY (`UserId`, `LoginProvider`, `Name`),
    CONSTRAINT fk_aspnetusertokens_users FOREIGN KEY (`UserId`) REFERENCES `AspNetUsers` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `AspNetRoleClaims` (
    `Id`         INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `RoleId`     VARCHAR(255) NOT NULL,
    `ClaimType`  TEXT,
    `ClaimValue` TEXT,
    CONSTRAINT fk_aspnetroleclaims_roles FOREIGN KEY (`RoleId`) REFERENCES `AspNetRoles` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- Reference tables
-- ====================================================================
CREATE TABLE IF NOT EXISTS `security_status_ref` (
    `code`        VARCHAR(32)  NOT NULL,
    `description` VARCHAR(255) NOT NULL,
    CONSTRAINT pk_security_status_ref PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `security_status_transition_ref` (
    `from_code` VARCHAR(32) NOT NULL,
    `to_code`   VARCHAR(32) NOT NULL,
    CONSTRAINT pk_security_status_transition PRIMARY KEY (`from_code`, `to_code`),
    CONSTRAINT fk_sst_from FOREIGN KEY (`from_code`) REFERENCES `security_status_ref`(`code`),
    CONSTRAINT fk_sst_to   FOREIGN KEY (`to_code`)   REFERENCES `security_status_ref`(`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `asset_class_ref` (
    `code`        VARCHAR(32)  NOT NULL,
    `name`        VARCHAR(100) NOT NULL,
    `description` VARCHAR(255),
    CONSTRAINT pk_asset_class_ref PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `instrument_type_ref` (
    `code`             VARCHAR(64) NOT NULL,
    `asset_class_code` VARCHAR(32) NOT NULL,
    `description`      VARCHAR(255),
    CONSTRAINT pk_instrument_type_ref PRIMARY KEY (`code`),
    CONSTRAINT fk_instrument_type_asset_class FOREIGN KEY (`asset_class_code`) REFERENCES `asset_class_ref`(`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- Currency
-- ====================================================================
CREATE TABLE IF NOT EXISTS `currency` (
    `id`               CHAR(36)     NOT NULL DEFAULT (UUID()),
    `code`             VARCHAR(10)  NOT NULL,
    `numeric_code`     VARCHAR(3),
    `name`             VARCHAR(150) NOT NULL,
    `symbol`           VARCHAR(10),
    `decimals`         SMALLINT     NOT NULL DEFAULT 2,
    `display_decimals` SMALLINT     NOT NULL DEFAULT 2,
    `currency_type`    VARCHAR(10)  NOT NULL DEFAULT 'FIAT',
    `is_active`        TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`       DATETIME(6),
    `valid_from`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`         DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`      DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`        DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`       TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`       TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`      VARCHAR(255),
    CONSTRAINT pk_currency PRIMARY KEY (`id`),
    CONSTRAINT uq_currency_code UNIQUE (`code`),
    CONSTRAINT chk_currency_type CHECK (`currency_type` IN ('FIAT','CRYPTO','COMMODITY','OTHER'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_currency_currency_type ON `currency`(`currency_type`);
CREATE INDEX ix_currency_is_active     ON `currency`(`is_active`);
CREATE INDEX ix_currency_is_current    ON `currency`(`is_current`);
CREATE INDEX ix_currency_is_deleted    ON `currency`(`is_deleted`);

-- ====================================================================
-- Country
-- ====================================================================
CREATE TABLE IF NOT EXISTS `country` (
    `id`           CHAR(36)     NOT NULL DEFAULT (UUID()),
    `alpha2`       CHAR(2)      NOT NULL,
    `alpha3`       CHAR(3)      NOT NULL,
    `numeric_code` CHAR(3)      NOT NULL,
    `name`         VARCHAR(200) NOT NULL,
    `tld`          VARCHAR(10),
    `is_active`    TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at`   DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`   DATETIME(6),
    `valid_from`   DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`     DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`  DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`    DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`   TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`   TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`  VARCHAR(255),
    CONSTRAINT pk_country PRIMARY KEY (`id`),
    CONSTRAINT uq_country_alpha2   UNIQUE (`alpha2`),
    CONSTRAINT uq_country_alpha3   UNIQUE (`alpha3`),
    CONSTRAINT uq_country_numeric  UNIQUE (`numeric_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_country_is_current ON `country`(`is_current`);
CREATE INDEX ix_country_is_deleted ON `country`(`is_deleted`);

-- ====================================================================
-- country_currency
-- ====================================================================
CREATE TABLE IF NOT EXISTS `country_currency` (
    `id`              CHAR(36)    NOT NULL DEFAULT (UUID()),
    `country_alpha2`  CHAR(2)     NOT NULL,
    `currency_code`   VARCHAR(10) NOT NULL,
    `is_primary`      TINYINT(1)  NOT NULL DEFAULT 0,
    `is_legal_tender` TINYINT(1)  NOT NULL DEFAULT 1,
    `is_operational`  TINYINT(1)  NOT NULL DEFAULT 1,
    `created_at`      DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`      DATETIME(6),
    `valid_from`      DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`        DATETIME(6) NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`     DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`       DATETIME(6) NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`      TINYINT(1)  NOT NULL DEFAULT 1,
    `is_deleted`      TINYINT(1)  NOT NULL DEFAULT 0,
    `modified_by`     VARCHAR(255),
    CONSTRAINT pk_country_currency PRIMARY KEY (`id`),
    CONSTRAINT uq_country_currency_pair UNIQUE (`country_alpha2`, `currency_code`),
    CONSTRAINT fk_country_currency_country  FOREIGN KEY (`country_alpha2`) REFERENCES `country`(`alpha2`),
    CONSTRAINT fk_country_currency_currency FOREIGN KEY (`currency_code`)  REFERENCES `currency`(`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_country_currency_alpha2  ON `country_currency`(`country_alpha2`);
CREATE INDEX ix_country_currency_code    ON `country_currency`(`currency_code`);
CREATE INDEX ix_country_currency_current ON `country_currency`(`is_current`);

-- ====================================================================
-- currency_external_code
-- ====================================================================
CREATE TABLE IF NOT EXISTS `currency_external_code` (
    `id`            CHAR(36)     NOT NULL DEFAULT (UUID()),
    `currency_code` VARCHAR(10)  NOT NULL,
    `system_name`   VARCHAR(100) NOT NULL,
    `external_code` VARCHAR(100) NOT NULL,
    `created_at`    DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`    DATETIME(6),
    `valid_from`    DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`      DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`   DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`     DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`    TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`    TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`   VARCHAR(255),
    CONSTRAINT pk_currency_external_code PRIMARY KEY (`id`),
    CONSTRAINT uq_currency_external_code_system UNIQUE (`currency_code`, `system_name`),
    CONSTRAINT fk_currency_external_code_currency FOREIGN KEY (`currency_code`) REFERENCES `currency`(`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_currency_external_code_currency_code ON `currency_external_code`(`currency_code`);
CREATE INDEX ix_currency_external_code_system_name   ON `currency_external_code`(`system_name`);
CREATE INDEX ix_currency_external_code_is_current    ON `currency_external_code`(`is_current`);

-- ====================================================================
-- currency_pair
-- ====================================================================
CREATE TABLE IF NOT EXISTS `currency_pair` (
    `id`                  CHAR(36)    NOT NULL DEFAULT (UUID()),
    `base_currency_code`  VARCHAR(10) NOT NULL,
    `quote_currency_code` VARCHAR(10) NOT NULL,
    `created_at`          DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`          DATETIME(6),
    `valid_from`          DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`            DATETIME(6) NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`         DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`           DATETIME(6) NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`          TINYINT(1)  NOT NULL DEFAULT 1,
    `is_deleted`          TINYINT(1)  NOT NULL DEFAULT 0,
    `modified_by`         VARCHAR(255),
    CONSTRAINT pk_currency_pair PRIMARY KEY (`id`),
    CONSTRAINT uq_currency_pair_base_quote UNIQUE (`base_currency_code`, `quote_currency_code`),
    CONSTRAINT fk_currency_pair_base  FOREIGN KEY (`base_currency_code`)  REFERENCES `currency`(`code`),
    CONSTRAINT fk_currency_pair_quote FOREIGN KEY (`quote_currency_code`) REFERENCES `currency`(`code`),
    CONSTRAINT chk_currency_pair_not_self CHECK (`base_currency_code` <> `quote_currency_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_currency_pair_base_code  ON `currency_pair`(`base_currency_code`);
CREATE INDEX ix_currency_pair_quote_code ON `currency_pair`(`quote_currency_code`);
CREATE INDEX ix_currency_pair_is_current ON `currency_pair`(`is_current`);

-- ====================================================================
-- issuer
-- ====================================================================
CREATE TABLE IF NOT EXISTS `issuer` (
    `id`                                   CHAR(36)     NOT NULL DEFAULT (UUID()),
    `legal_name`                           VARCHAR(255) NOT NULL,
    `display_name`                         VARCHAR(255),
    `short_name`                           VARCHAR(100),
    `lei_code`                             VARCHAR(20),
    `issuer_type`                          VARCHAR(50),
    `country_alpha2`                       CHAR(2),
    `direct_accounting_parent_issuer_id`   CHAR(36),
    `ultimate_accounting_parent_issuer_id` CHAR(36),
    `is_active`                            TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at`                           DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`                           DATETIME(6),
    `valid_from`                           DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`                             DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`                          DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`                            DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`                           TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`                           TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`                          VARCHAR(255),
    CONSTRAINT pk_issuer PRIMARY KEY (`id`),
    CONSTRAINT fk_issuer_direct_parent   FOREIGN KEY (`direct_accounting_parent_issuer_id`)   REFERENCES `issuer`(`id`),
    CONSTRAINT fk_issuer_ultimate_parent FOREIGN KEY (`ultimate_accounting_parent_issuer_id`) REFERENCES `issuer`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_issuer_legal_name  ON `issuer`(`legal_name`);
CREATE INDEX ix_issuer_lei_code    ON `issuer`(`lei_code`);
CREATE INDEX ix_issuer_country     ON `issuer`(`country_alpha2`);
CREATE INDEX ix_issuer_is_current  ON `issuer`(`is_current`);

-- ====================================================================
-- issuer_identifier
-- ====================================================================
CREATE TABLE IF NOT EXISTS `issuer_identifier` (
    `id`               CHAR(36)     NOT NULL DEFAULT (UUID()),
    `issuer_id`        CHAR(36)     NOT NULL,
    `identifier_type`  VARCHAR(50)  NOT NULL,
    `identifier_value` VARCHAR(100) NOT NULL,
    `source_system`    VARCHAR(50),
    `is_primary`       TINYINT(1)   NOT NULL DEFAULT 0,
    `created_at`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`       DATETIME(6),
    `valid_from`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`         DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`      DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`        DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`       TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`       TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`      VARCHAR(255),
    CONSTRAINT pk_issuer_identifier PRIMARY KEY (`id`),
    CONSTRAINT fk_issuer_identifier_issuer FOREIGN KEY (`issuer_id`) REFERENCES `issuer`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_issuer_identifier_issuer_id ON `issuer_identifier`(`issuer_id`);
CREATE INDEX ix_issuer_identifier_type_value ON `issuer_identifier`(`identifier_type`,`identifier_value`,`source_system`);

-- ====================================================================
-- issuer_relationship
-- ====================================================================
CREATE TABLE IF NOT EXISTS `issuer_relationship` (
    `id`                CHAR(36)      NOT NULL DEFAULT (UUID()),
    `child_issuer_id`   CHAR(36)      NOT NULL,
    `parent_issuer_id`  CHAR(36)      NOT NULL,
    `relationship_type` VARCHAR(50)   NOT NULL,
    `ownership_percent` DECIMAL(9,6),
    `control_basis`     VARCHAR(100),
    `source_system`     VARCHAR(50),
    `source_reference`  VARCHAR(255),
    `is_primary`        TINYINT(1)    NOT NULL DEFAULT 0,
    `notes`             VARCHAR(1000),
    `created_at`        DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`        DATETIME(6),
    `valid_from`        DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`          DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`       DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`         DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`        TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`        TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`       VARCHAR(255),
    CONSTRAINT pk_issuer_relationship PRIMARY KEY (`id`),
    CONSTRAINT fk_issuer_rel_child  FOREIGN KEY (`child_issuer_id`)  REFERENCES `issuer`(`id`),
    CONSTRAINT fk_issuer_rel_parent FOREIGN KEY (`parent_issuer_id`) REFERENCES `issuer`(`id`),
    CONSTRAINT chk_issuer_rel_not_self CHECK (`child_issuer_id` <> `parent_issuer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_issuer_rel_child_type   ON `issuer_relationship`(`child_issuer_id`,`relationship_type`);
CREATE INDEX ix_issuer_rel_parent_type  ON `issuer_relationship`(`parent_issuer_id`,`relationship_type`);
CREATE INDEX ix_issuer_rel_is_current   ON `issuer_relationship`(`is_current`);

-- ====================================================================
-- security
-- ====================================================================
CREATE TABLE IF NOT EXISTS `security` (
    `id`                   CHAR(36)     NOT NULL DEFAULT (UUID()),
    `data_source`          VARCHAR(50)  NOT NULL DEFAULT 'FlatFile',
    `type`                 VARCHAR(50)  NOT NULL,
    `name`                 VARCHAR(255) NOT NULL,
    `description`          TEXT,
    `issuer`               VARCHAR(255),
    `issuer_id`            CHAR(36),
    `currency_code`        VARCHAR(10),
    `has_open_position`    TINYINT(1)   NOT NULL DEFAULT 0,
    `status_code`          VARCHAR(32)  NOT NULL DEFAULT 'ACTIVE',
    `asset_class_code`     VARCHAR(32)  NOT NULL DEFAULT 'OTHER',
    `instrument_type_code` VARCHAR(64)  NOT NULL DEFAULT 'Other',
    `content_hash`         VARCHAR(64),
    `created_at`           DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`           DATETIME(6),
    `valid_from`           DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`             DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`          DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`            DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`           TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`           TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`          VARCHAR(255),
    CONSTRAINT pk_security PRIMARY KEY (`id`),
    CONSTRAINT fk_security_status_ref      FOREIGN KEY (`status_code`)          REFERENCES `security_status_ref`(`code`),
    CONSTRAINT fk_security_asset_class_ref FOREIGN KEY (`asset_class_code`)     REFERENCES `asset_class_ref`(`code`),
    CONSTRAINT fk_security_instrument_type FOREIGN KEY (`instrument_type_code`) REFERENCES `instrument_type_ref`(`code`),
    CONSTRAINT fk_security_issuer          FOREIGN KEY (`issuer_id`)            REFERENCES `issuer`(`id`),
    CONSTRAINT fk_security_currency_code   FOREIGN KEY (`currency_code`)        REFERENCES `currency`(`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_security_name         ON `security`(`name`);
CREATE INDEX ix_security_currency     ON `security`(`currency_code`);
CREATE INDEX ix_security_is_current   ON `security`(`is_current`);
CREATE INDEX ix_security_valid_time   ON `security`(`valid_from`,`valid_to`);
CREATE INDEX ix_security_system_time  ON `security`(`system_from`,`system_to`);
CREATE INDEX ix_security_is_deleted   ON `security`(`is_deleted`);
CREATE INDEX ix_security_status_code  ON `security`(`status_code`);
CREATE INDEX ix_security_asset_class  ON `security`(`asset_class_code`);
CREATE INDEX ix_security_instr_type   ON `security`(`instrument_type_code`);

-- ====================================================================
-- security_identifier
-- ====================================================================
CREATE TABLE IF NOT EXISTS `security_identifier` (
    `id`               CHAR(36)     NOT NULL DEFAULT (UUID()),
    `security_id`      CHAR(36)     NOT NULL,
    `identifier_type`  VARCHAR(50)  NOT NULL,
    `identifier_value` VARCHAR(100) NOT NULL,
    `source_system`    VARCHAR(50),
    `is_primary`       TINYINT(1)   NOT NULL DEFAULT 0,
    `created_at`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`       DATETIME(6),
    `valid_from`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`         DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`      DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`        DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`       TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`       TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`      VARCHAR(255),
    CONSTRAINT pk_security_identifier PRIMARY KEY (`id`),
    CONSTRAINT fk_si_security FOREIGN KEY (`security_id`) REFERENCES `security`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_si_security_id         ON `security_identifier`(`security_id`);
CREATE INDEX ix_si_type_value_source   ON `security_identifier`(`identifier_type`,`identifier_value`,`source_system`);
CREATE INDEX ix_si_is_current          ON `security_identifier`(`is_current`);

-- ====================================================================
-- price
-- ====================================================================
CREATE TABLE IF NOT EXISTS `price` (
    `id`               CHAR(36)      NOT NULL DEFAULT (UUID()),
    `security_id`      CHAR(36)      NOT NULL,
    `value`            DECIMAL(18,8) NOT NULL,
    `source`           VARCHAR(50)   NOT NULL,
    `price_date`       DATETIME(6)   NOT NULL,
    `price_type`       VARCHAR(50),
    `currency`         VARCHAR(10),
    `is_golden`        TINYINT(1)    NOT NULL DEFAULT 0,
    `is_stale`         TINYINT(1)    NOT NULL DEFAULT 0,
    `is_override`      TINYINT(1)    NOT NULL DEFAULT 0,
    `override_reason`  VARCHAR(500),
    `vendor_source_id` CHAR(36),
    `created_at`       DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`       DATETIME(6),
    `valid_from`       DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`         DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`      DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`        DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`       TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`       TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`      VARCHAR(255),
    CONSTRAINT pk_price PRIMARY KEY (`id`),
    CONSTRAINT fk_price_security FOREIGN KEY (`security_id`) REFERENCES `security`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_price_sec_src_date  ON `price`(`security_id`,`source`,`price_date`);
CREATE INDEX ix_price_is_current    ON `price`(`is_current`);
CREATE INDEX ix_price_valid_time    ON `price`(`valid_from`,`valid_to`);
CREATE INDEX ix_price_system_time   ON `price`(`system_from`,`system_to`);
CREATE INDEX ix_price_is_golden     ON `price`(`security_id`,`price_date`);

-- ====================================================================
-- pricing_rule
-- ====================================================================
CREATE TABLE IF NOT EXISTS `pricing_rule` (
    `id`                   CHAR(36)      NOT NULL DEFAULT (UUID()),
    `rule_name`            VARCHAR(255)  NOT NULL,
    `security_type`        VARCHAR(50),
    `rule_definition_json` TEXT          NOT NULL,
    `created_by`           CHAR(36),
    `description`          VARCHAR(1000),
    `created_at`           DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`           DATETIME(6),
    `valid_from`           DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`             DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`          DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`            DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`           TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`           TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`          VARCHAR(255),
    CONSTRAINT pk_pricing_rule PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_pricing_rule_is_current  ON `pricing_rule`(`is_current`);
CREATE INDEX ix_pricing_rule_valid_time  ON `pricing_rule`(`valid_from`,`valid_to`);

-- ====================================================================
-- derived_price
-- ====================================================================
CREATE TABLE IF NOT EXISTS `derived_price` (
    `id`                  CHAR(36)      NOT NULL DEFAULT (UUID()),
    `security_id`         CHAR(36)      NOT NULL,
    `pricing_rule_id`     CHAR(36)      NOT NULL,
    `calculated_price`    DECIMAL(18,8) NOT NULL,
    `calculated_at`       DATETIME(6)   NOT NULL,
    `calculation_details` TEXT,
    `created_at`          DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`          DATETIME(6),
    `valid_from`          DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`            DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`         DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`           DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`          TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`          TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`         VARCHAR(255),
    CONSTRAINT pk_derived_price   PRIMARY KEY (`id`),
    CONSTRAINT fk_dp_security     FOREIGN KEY (`security_id`)     REFERENCES `security`(`id`) ON DELETE CASCADE,
    CONSTRAINT fk_dp_pricing_rule FOREIGN KEY (`pricing_rule_id`) REFERENCES `pricing_rule`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_dp_security_id ON `derived_price`(`security_id`);
CREATE INDEX ix_dp_rule_id     ON `derived_price`(`pricing_rule_id`);
CREATE INDEX ix_dp_is_current  ON `derived_price`(`is_current`);

-- ====================================================================
-- security_core_attribute
-- ====================================================================
CREATE TABLE IF NOT EXISTS `security_core_attribute` (
    `id`            CHAR(36)      NOT NULL DEFAULT (UUID()),
    `security_id`   CHAR(36)      NOT NULL,
    `coupon_rate`   DECIMAL(10,6),
    `factor_rate`   DECIMAL(10,6),
    `maturity_date` DATETIME(6),
    `issue_date`    DATETIME(6),
    `face_value`    DECIMAL(18,2),
    `created_at`    DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`    DATETIME(6),
    `valid_from`    DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`      DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`   DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`     DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`    TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`    TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`   VARCHAR(255),
    CONSTRAINT pk_security_core_attribute PRIMARY KEY (`id`),
    CONSTRAINT fk_sca_security FOREIGN KEY (`security_id`) REFERENCES `security`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_sca_security_id ON `security_core_attribute`(`security_id`);
CREATE INDEX ix_sca_is_current  ON `security_core_attribute`(`is_current`);

-- ====================================================================
-- security_loan_attribute
-- ====================================================================
CREATE TABLE IF NOT EXISTS `security_loan_attribute` (
    `id`              CHAR(36)      NOT NULL DEFAULT (UUID()),
    `security_id`     CHAR(36)      NOT NULL,
    `loan_type`       VARCHAR(50),
    `collateral_type` VARCHAR(100),
    `seniority`       VARCHAR(50),
    `amortization`    VARCHAR(50),
    `payment_freq`    VARCHAR(20),
    `day_count`       VARCHAR(20),
    `margin_bps`      DECIMAL(9,4),
    `reference_index` VARCHAR(50),
    `maturity_date`   DATETIME(6),
    `drawdown_limit`  DECIMAL(18,2),
    `created_at`      DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`      DATETIME(6),
    `valid_from`      DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`        DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`     DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`       DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`      TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`      TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`     VARCHAR(255),
    CONSTRAINT pk_security_loan_attribute PRIMARY KEY (`id`),
    CONSTRAINT fk_sla_security FOREIGN KEY (`security_id`) REFERENCES `security`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_sla_security_id ON `security_loan_attribute`(`security_id`);
CREATE INDEX ix_sla_is_current  ON `security_loan_attribute`(`is_current`);

-- ====================================================================
-- security_derivative_attribute
-- ====================================================================
CREATE TABLE IF NOT EXISTS `security_derivative_attribute` (
    `id`              CHAR(36)      NOT NULL DEFAULT (UUID()),
    `security_id`     CHAR(36)      NOT NULL,
    `underlying_type` VARCHAR(50),
    `underlying_id`   CHAR(36),
    `notional`        DECIMAL(28,8),
    `notional_ccy`    CHAR(3),
    `strike_price`    DECIMAL(28,8),
    `strike_ccy`      CHAR(3),
    `option_style`    VARCHAR(20),
    `option_type`     VARCHAR(10),
    `expiry_date`     DATETIME(6),
    `settlement_type` VARCHAR(20),
    `leg_count`       INT,
    `created_at`      DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`      DATETIME(6),
    `valid_from`      DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`        DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`     DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`       DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`      TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`      TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`     VARCHAR(255),
    CONSTRAINT pk_security_derivative_attribute PRIMARY KEY (`id`),
    CONSTRAINT fk_sda_security FOREIGN KEY (`security_id`) REFERENCES `security`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_sda_security_id ON `security_derivative_attribute`(`security_id`);
CREATE INDEX ix_sda_is_current  ON `security_derivative_attribute`(`is_current`);

-- ====================================================================
-- security_securitized_attribute
-- ====================================================================
CREATE TABLE IF NOT EXISTS `security_securitized_attribute` (
    `id`                 CHAR(36)      NOT NULL DEFAULT (UUID()),
    `security_id`        CHAR(36)      NOT NULL,
    `pool_id`            VARCHAR(100),
    `tranche_label`      VARCHAR(50),
    `tranche_seniority`  VARCHAR(50),
    `original_balance`   DECIMAL(28,8),
    `current_balance`    DECIMAL(28,8),
    `credit_enhancement` DECIMAL(9,4),
    `callable`           TINYINT(1),
    `call_date`          DATETIME(6),
    `created_at`         DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`         DATETIME(6),
    `valid_from`         DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`           DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`        DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`          DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`         TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`         TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`        VARCHAR(255),
    CONSTRAINT pk_security_securitized_attribute PRIMARY KEY (`id`),
    CONSTRAINT fk_ssa_security FOREIGN KEY (`security_id`) REFERENCES `security`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_ssa_security_id ON `security_securitized_attribute`(`security_id`);
CREATE INDEX ix_ssa_is_current  ON `security_securitized_attribute`(`is_current`);

-- ====================================================================
-- security_attribute_kv
-- ====================================================================
CREATE TABLE IF NOT EXISTS `security_attribute_kv` (
    `id`             CHAR(36)      NOT NULL DEFAULT (UUID()),
    `security_id`    CHAR(36)      NOT NULL,
    `attribute_name` VARCHAR(100)  NOT NULL,
    `attribute_type` VARCHAR(20)   NOT NULL,
    `value_string`   VARCHAR(4000),
    `value_decimal`  DECIMAL(28,10),
    `value_int`      BIGINT,
    `value_date`     DATETIME(6),
    `value_bool`     TINYINT(1),
    `source_system`  VARCHAR(50),
    `created_at`     DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`     DATETIME(6),
    `valid_from`     DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`       DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`    DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`      DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`     TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`     TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`    VARCHAR(255),
    CONSTRAINT pk_security_attribute_kv PRIMARY KEY (`id`),
    CONSTRAINT fk_sakv_security FOREIGN KEY (`security_id`) REFERENCES `security`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_sakv_security_id    ON `security_attribute_kv`(`security_id`);
CREATE INDEX ix_sakv_name_current   ON `security_attribute_kv`(`security_id`,`attribute_name`,`is_current`);
CREATE INDEX ix_sakv_is_current     ON `security_attribute_kv`(`is_current`);

-- ====================================================================
-- audit_log
-- ====================================================================
CREATE TABLE IF NOT EXISTS `audit_log` (
    `id`             CHAR(36)    NOT NULL DEFAULT (UUID()),
    `entity_type`    VARCHAR(50) NOT NULL,
    `action`         VARCHAR(50) NOT NULL,
    `user_id`        CHAR(36),
    `user_name`      VARCHAR(255),
    `details`        TEXT,
    `ip_address`     VARCHAR(45),
    `entity_id`      CHAR(36),
    `before_state`   LONGTEXT,
    `after_state`    LONGTEXT,
    `changed_fields` LONGTEXT,
    `correlation_id` CHAR(36),
    `causation_id`   CHAR(36),
    `source`         VARCHAR(50) NOT NULL DEFAULT 'Http',
    `created_at`     DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    CONSTRAINT pk_audit_log PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_audit_log_created_at     ON `audit_log`(`created_at`);
CREATE INDEX ix_audit_log_user_id        ON `audit_log`(`user_id`);
CREATE INDEX ix_audit_log_entity         ON `audit_log`(`entity_type`,`entity_id`);
CREATE INDEX ix_audit_log_correlation_id ON `audit_log`(`correlation_id`);

-- ====================================================================
-- audit_log_archive  (MySQL has no declarative partitioning via RANGE by expression in CREATE INDEX;
--                     table structure mirrors audit_log)
-- ====================================================================
CREATE TABLE IF NOT EXISTS `audit_log_archive` (
    `id`             CHAR(36)    NOT NULL DEFAULT (UUID()),
    `entity_type`    VARCHAR(50) NOT NULL,
    `action`         VARCHAR(50) NOT NULL,
    `user_id`        CHAR(36),
    `user_name`      VARCHAR(255),
    `details`        TEXT,
    `ip_address`     VARCHAR(45),
    `entity_id`      CHAR(36),
    `before_state`   LONGTEXT,
    `after_state`    LONGTEXT,
    `changed_fields` LONGTEXT,
    `correlation_id` CHAR(36),
    `causation_id`   CHAR(36),
    `source`         VARCHAR(50) NOT NULL DEFAULT 'Http',
    `created_at`     DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `archived_at`    DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    CONSTRAINT pk_audit_log_archive PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_ala_entity         ON `audit_log_archive`(`entity_type`,`entity_id`);
CREATE INDEX ix_ala_user_id        ON `audit_log_archive`(`user_id`);
CREATE INDEX ix_ala_correlation_id ON `audit_log_archive`(`correlation_id`);

-- ====================================================================
-- idempotency_key_store
-- ====================================================================
CREATE TABLE IF NOT EXISTS `idempotency_key_store` (
    `key`            VARCHAR(200) NOT NULL,
    `operation_type` VARCHAR(100) NOT NULL,
    `status`         VARCHAR(20)  NOT NULL DEFAULT 'PROCESSING',
    `response_code`  INT,
    `response_body`  TEXT,
    `created_at`     DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `expires_at`     DATETIME(6)  NOT NULL,
    CONSTRAINT pk_idempotency_key_store PRIMARY KEY (`key`),
    CONSTRAINT chk_idempotency_status CHECK (`status` IN ('PROCESSING','COMPLETED','FAILED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_idempotency_expires_at ON `idempotency_key_store`(`expires_at`);

-- ====================================================================
-- dead_letter_event
-- ====================================================================
CREATE TABLE IF NOT EXISTS `dead_letter_event` (
    `id`               CHAR(36)     NOT NULL DEFAULT (UUID()),
    `event_type`       VARCHAR(100) NOT NULL,
    `correlation_id`   CHAR(36)     NOT NULL,
    `idempotency_key`  VARCHAR(200),
    `payload`          TEXT         NOT NULL,
    `failure_reason`   VARCHAR(500) NOT NULL,
    `failure_stage`    INT          NOT NULL DEFAULT 0,
    `retry_count`      INT          NOT NULL DEFAULT 0,
    `status`           VARCHAR(20)  NOT NULL DEFAULT 'PENDING',
    `resolved_by`      VARCHAR(255),
    `resolved_at`      DATETIME(6),
    `resolution_notes` VARCHAR(500),
    `created_at`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`       DATETIME(6),
    `modified_by`      VARCHAR(255),
    CONSTRAINT pk_dead_letter_event PRIMARY KEY (`id`),
    CONSTRAINT chk_dead_letter_status CHECK (`status` IN ('PENDING','IN_REVIEW','REPLAYED','RESOLVED','DISCARDED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_dle_status         ON `dead_letter_event`(`status`);
CREATE INDEX ix_dle_event_type     ON `dead_letter_event`(`event_type`);
CREATE INDEX ix_dle_correlation_id ON `dead_letter_event`(`correlation_id`);
CREATE INDEX ix_dle_created_at     ON `dead_letter_event`(`created_at`);

-- ====================================================================
-- import_request
-- ====================================================================
CREATE TABLE IF NOT EXISTS `import_request` (
    `id`                CHAR(36)    NOT NULL DEFAULT (UUID()),
    `created_at`        DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`        DATETIME(6),
    `request_type`      VARCHAR(50) NOT NULL,
    `source_system`     VARCHAR(50),
    `target_system`     VARCHAR(50),
    `status`            VARCHAR(50) NOT NULL DEFAULT 'InProgress',
    `user_id`           CHAR(36),
    `user_name`         VARCHAR(255),
    `completed_at`      DATETIME(6),
    `error_message`     TEXT,
    `request_details`   TEXT,
    `total_records`     INT,
    `processed_records` INT,
    `failed_records`    INT,
    `attempt_number`    INT         NOT NULL DEFAULT 0,
    `skipped_records`   INT,
    CONSTRAINT pk_import_request PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_import_request_status     ON `import_request`(`status`);
CREATE INDEX ix_import_request_created_at ON `import_request`(`created_at`);

-- ====================================================================
-- credit_rating
-- ====================================================================
CREATE TABLE IF NOT EXISTS `credit_rating` (
    `id`          CHAR(36)    NOT NULL DEFAULT (UUID()),
    `security_id` CHAR(36)    NOT NULL,
    `agency`      VARCHAR(50) NOT NULL,
    `rating`      VARCHAR(20) NOT NULL,
    `rating_type` VARCHAR(30) NOT NULL DEFAULT 'LongTerm',
    `rating_date` DATETIME(6),
    `created_at`  DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`  DATETIME(6),
    `valid_from`  DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`    DATETIME(6) NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from` DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`   DATETIME(6) NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`  TINYINT(1)  NOT NULL DEFAULT 1,
    `is_deleted`  TINYINT(1)  NOT NULL DEFAULT 0,
    `modified_by` VARCHAR(255),
    CONSTRAINT pk_credit_rating PRIMARY KEY (`id`),
    CONSTRAINT fk_credit_rating_security FOREIGN KEY (`security_id`) REFERENCES `security`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_credit_rating_security_agency ON `credit_rating`(`security_id`,`agency`,`rating_type`,`is_current`);
CREATE INDEX ix_credit_rating_valid_time       ON `credit_rating`(`valid_from`,`valid_to`);

-- ====================================================================
-- derived_rating
-- ====================================================================
CREATE TABLE IF NOT EXISTS `derived_rating` (
    `id`                       CHAR(36)       NOT NULL DEFAULT (UUID()),
    `security_id`              CHAR(36)       NOT NULL,
    `implied_rating_score`     INT,
    `vpm_rating_score`         INT,
    `fundamental_rating_score` INT,
    `composite_rating_score`   INT,
    `output_agency`            VARCHAR(30)    NOT NULL DEFAULT 'SP',
    `implied_rating`           VARCHAR(20),
    `vpm_rating`               VARCHAR(20),
    `fundamental_rating`       VARCHAR(20),
    `composite_rating`         VARCHAR(20),
    `implied_pd`               DECIMAL(12,10),
    `model_pd`                 DECIMAL(12,10),
    `fair_price`               DECIMAL(18,6),
    `source_hash`              VARCHAR(64)    NOT NULL DEFAULT '',
    `last_calculated_utc`      DATETIME(6)    NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `created_at`               DATETIME(6)    NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`               DATETIME(6),
    `valid_from`               DATETIME(6)    NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`                 DATETIME(6)    NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`              DATETIME(6)    NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`                DATETIME(6)    NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`               TINYINT(1)     NOT NULL DEFAULT 1,
    `is_deleted`               TINYINT(1)     NOT NULL DEFAULT 0,
    `modified_by`              VARCHAR(255),
    CONSTRAINT pk_derived_rating PRIMARY KEY (`id`),
    CONSTRAINT fk_derived_rating_security FOREIGN KEY (`security_id`) REFERENCES `security`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_derived_rating_security_id      ON `derived_rating`(`security_id`);
CREATE INDEX ix_derived_rating_security_current ON `derived_rating`(`security_id`,`is_current`);
CREATE INDEX ix_derived_rating_valid_time       ON `derived_rating`(`valid_from`,`valid_to`);

-- ====================================================================
-- vendor_rating_metadata
-- ====================================================================
CREATE TABLE IF NOT EXISTS `vendor_rating_metadata` (
    `id`               CHAR(36)     NOT NULL DEFAULT (UUID()),
    `vendor_name`      VARCHAR(100) NOT NULL,
    `accuracy_score`   DECIMAL(5,4) NOT NULL DEFAULT 0.5,
    `stability_score`  DECIMAL(5,4) NOT NULL DEFAULT 0.5,
    `timeliness_score` DECIMAL(5,4) NOT NULL DEFAULT 0.5,
    `coverage_score`   DECIMAL(5,4) NOT NULL DEFAULT 0.5,
    `last_updated_utc` DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `created_at`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`       DATETIME(6),
    CONSTRAINT pk_vendor_rating_metadata PRIMARY KEY (`id`),
    CONSTRAINT uq_vendor_rating_metadata_vendor_name UNIQUE (`vendor_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- rating_scale_entry
-- ====================================================================
CREATE TABLE IF NOT EXISTS `rating_scale_entry` (
    `id`                  CHAR(36)    NOT NULL DEFAULT (UUID()),
    `agency`              VARCHAR(50) NOT NULL,
    `score`               INT         NOT NULL,
    `label`               VARCHAR(20) NOT NULL,
    `is_investment_grade` TINYINT(1)  NOT NULL DEFAULT 0,
    `created_at`          DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`          DATETIME(6),
    `valid_from`          DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`            DATETIME(6) NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`         DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`           DATETIME(6) NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`          TINYINT(1)  NOT NULL DEFAULT 1,
    `is_deleted`          TINYINT(1)  NOT NULL DEFAULT 0,
    `modified_by`         VARCHAR(255),
    CONSTRAINT pk_rating_scale_entry PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_rating_scale_entry_agency_score ON `rating_scale_entry`(`agency`,`score`,`is_current`);
CREATE INDEX ix_rating_scale_entry_valid_time   ON `rating_scale_entry`(`valid_from`,`valid_to`);

-- ====================================================================
-- rating_derivation_rule
-- ====================================================================
CREATE TABLE IF NOT EXISTS `rating_derivation_rule` (
    `id`            CHAR(36)     NOT NULL DEFAULT (UUID()),
    `model_name`    VARCHAR(50)  NOT NULL,
    `security_type` VARCHAR(50),
    `config_json`   TEXT         NOT NULL,
    `description`   VARCHAR(500),
    `created_at`    DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`    DATETIME(6),
    `valid_from`    DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`      DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`   DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`     DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`    TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`    TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`   VARCHAR(255),
    CONSTRAINT pk_rating_derivation_rule PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_rating_derivation_rule_model_type ON `rating_derivation_rule`(`model_name`,`security_type`,`is_current`);
CREATE INDEX ix_rating_derivation_rule_valid_time ON `rating_derivation_rule`(`valid_from`,`valid_to`);

-- ====================================================================
-- formula_macro
-- ====================================================================
CREATE TABLE IF NOT EXISTS `formula_macro` (
    `id`          CHAR(36)     NOT NULL DEFAULT (UUID()),
    `name`        VARCHAR(100) NOT NULL,
    `expression`  TEXT         NOT NULL,
    `description` VARCHAR(500),
    `scope`       VARCHAR(50),
    `created_at`  DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`  DATETIME(6),
    `valid_from`  DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`    DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from` DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`   DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`  TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`  TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by` VARCHAR(255),
    CONSTRAINT pk_formula_macro PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_formula_macro_name_current ON `formula_macro`(`name`,`is_current`);
CREATE INDEX ix_formula_macro_valid_time   ON `formula_macro`(`valid_from`,`valid_to`);

-- ====================================================================
-- import_profile
-- ====================================================================
CREATE TABLE IF NOT EXISTS `import_profile` (
    `id`                        CHAR(36)     NOT NULL DEFAULT (UUID()),
    `name`                      VARCHAR(100) NOT NULL,
    `description`               VARCHAR(500),
    `source_type`               VARCHAR(50)  NOT NULL,
    `file_pattern`              VARCHAR(200) NOT NULL DEFAULT '*.csv',
    `folder`                    VARCHAR(500),
    `delimiter`                 VARCHAR(10),
    `text_qualifier`            VARCHAR(5),
    `has_header`                TINYINT(1)   NOT NULL DEFAULT 1,
    `skip_rows`                 INT          NOT NULL DEFAULT 0,
    `records_path`              VARCHAR(500),
    `records_x_path`            VARCHAR(500),
    `transport_type`            VARCHAR(20)  NOT NULL DEFAULT 'Local',
    `transport_host`            VARCHAR(500),
    `transport_port`            INT,
    `transport_username`        VARCHAR(200),
    `transport_password_secret` VARCHAR(500),
    `transport_remote_path`     VARCHAR(500),
    `transport_tls_thumbprint`  VARCHAR(100),
    `is_active`                 TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at`                DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`                DATETIME(6),
    CONSTRAINT pk_import_profile PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE UNIQUE INDEX uix_import_profile_name_source ON `import_profile`(`name`,`source_type`);
CREATE INDEX ix_import_profile_source_active        ON `import_profile`(`source_type`,`is_active`);

-- ====================================================================
-- import_profile_column
-- ====================================================================
CREATE TABLE IF NOT EXISTS `import_profile_column` (
    `id`            CHAR(36)     NOT NULL DEFAULT (UUID()),
    `profile_id`    CHAR(36)     NOT NULL,
    `source_column` VARCHAR(200) NOT NULL,
    `target_field`  VARCHAR(200) NOT NULL,
    `sort_order`    INT          NOT NULL DEFAULT 0,
    `created_at`    DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`    DATETIME(6),
    CONSTRAINT pk_import_profile_column PRIMARY KEY (`id`),
    CONSTRAINT fk_ipc_profile FOREIGN KEY (`profile_id`) REFERENCES `import_profile`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_import_profile_column_profile_id ON `import_profile_column`(`profile_id`);

-- ====================================================================
-- import_profile_column_validation
-- ====================================================================
CREATE TABLE IF NOT EXISTS `import_profile_column_validation` (
    `id`            CHAR(36)      NOT NULL DEFAULT (UUID()),
    `column_id`     CHAR(36)      NOT NULL,
    `rule_type`     VARCHAR(50)   NOT NULL,
    `rule_value`    VARCHAR(500),
    `condition`     VARCHAR(1000),
    `error_message` VARCHAR(500),
    `severity`      VARCHAR(20)   NOT NULL DEFAULT 'Error',
    `is_active`     TINYINT(1)    NOT NULL DEFAULT 1,
    `created_at`    DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`    DATETIME(6),
    CONSTRAINT pk_import_profile_column_validation PRIMARY KEY (`id`),
    CONSTRAINT fk_ipcv_column FOREIGN KEY (`column_id`) REFERENCES `import_profile_column`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_ipcv_column_id ON `import_profile_column_validation`(`column_id`);

-- ====================================================================
-- import_profile_row_validation
-- ====================================================================
CREATE TABLE IF NOT EXISTS `import_profile_row_validation` (
    `id`            CHAR(36)     NOT NULL DEFAULT (UUID()),
    `profile_id`    CHAR(36)     NOT NULL,
    `expression`    TEXT         NOT NULL,
    `error_message` VARCHAR(500) NOT NULL,
    `severity`      VARCHAR(20)  NOT NULL DEFAULT 'Error',
    `sort_order`    INT          NOT NULL DEFAULT 0,
    `is_active`     TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at`    DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`    DATETIME(6),
    CONSTRAINT pk_import_profile_row_validation PRIMARY KEY (`id`),
    CONSTRAINT fk_iprv_profile FOREIGN KEY (`profile_id`) REFERENCES `import_profile`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_iprv_profile_id ON `import_profile_row_validation`(`profile_id`);

-- ====================================================================
-- job_execution_history
-- ====================================================================
CREATE TABLE IF NOT EXISTS `job_execution_history` (
    `id`              CHAR(36)      NOT NULL,
    `job_name`        VARCHAR(200)  NOT NULL,
    `job_group`       VARCHAR(200)  NOT NULL,
    `triggered_by`    VARCHAR(255)  NOT NULL DEFAULT 'scheduler',
    `started_at`      DATETIME(6)   NOT NULL,
    `completed_at`    DATETIME(6),
    `succeeded`       TINYINT(1)    NOT NULL DEFAULT 0,
    `error_message`   VARCHAR(2000),
    `error_detail`    TEXT,
    `skipped_records` INT,
    CONSTRAINT pk_job_execution_history PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_job_execution_history_job_name   ON `job_execution_history`(`job_name`);
CREATE INDEX ix_job_execution_history_started_at ON `job_execution_history`(`started_at`);

-- ====================================================================
-- job_schedule
-- ====================================================================
CREATE TABLE IF NOT EXISTS `job_schedule` (
    `id`              CHAR(36)     NOT NULL DEFAULT (UUID()),
    `plugin_name`     VARCHAR(200) NOT NULL,
    `job_group`       VARCHAR(200) NOT NULL,
    `cron_expression` VARCHAR(100),
    `enabled`         TINYINT(1)   NOT NULL DEFAULT 1,
    `time_zone`       VARCHAR(100) NOT NULL DEFAULT 'UTC',
    `created_at`      DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`      DATETIME(6),
    `valid_from`      DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`        DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`     DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`       DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`      TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`      TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`     VARCHAR(255),
    CONSTRAINT pk_job_schedule PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_job_schedule_plugin_name ON `job_schedule`(`plugin_name`);
CREATE INDEX ix_job_schedule_is_current  ON `job_schedule`(`is_current`);
CREATE INDEX ix_job_schedule_system_time ON `job_schedule`(`system_from`,`system_to`);

-- ====================================================================
-- approval_request
-- ====================================================================
CREATE TABLE IF NOT EXISTS `approval_request` (
    `id`                CHAR(36)     NOT NULL DEFAULT (UUID()),
    `type`              VARCHAR(100) NOT NULL,
    `status`            VARCHAR(50)  NOT NULL DEFAULT 'Pending',
    `security_ids`      TEXT,
    `requested_by`      VARCHAR(256) NOT NULL,
    `requested_at`      DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `reviewed_by`       VARCHAR(256),
    `reviewed_at`       DATETIME(6),
    `expires_at`        DATETIME(6),
    `notes`             TEXT,
    `export_request_id` CHAR(36),
    `created_at`        DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`        DATETIME(6),
    `valid_from`        DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`          DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`         DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`        TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`        TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`       VARCHAR(255),
    CONSTRAINT pk_approval_request PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_approval_request_status       ON `approval_request`(`status`);
CREATE INDEX ix_approval_request_requested_at ON `approval_request`(`requested_at`);
CREATE INDEX ix_approval_request_is_current   ON `approval_request`(`is_current`);

-- ====================================================================
-- workflow_definition
-- ====================================================================
CREATE TABLE IF NOT EXISTS `workflow_definition` (
    `id`             CHAR(36)      NOT NULL DEFAULT (UUID()),
    `name`           VARCHAR(200)  NOT NULL,
    `description`    VARCHAR(1000),
    `trigger_type`   VARCHAR(50)   NOT NULL,
    `is_enabled`     TINYINT(1)    NOT NULL DEFAULT 1,
    `condition_json` TEXT,
    `created_at`     DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`     DATETIME(6),
    `valid_from`     DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`       DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`    DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`      DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`     TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`     TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`    VARCHAR(255),
    CONSTRAINT pk_workflow_definition PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_wf_def_trigger_type ON `workflow_definition`(`trigger_type`);
CREATE INDEX ix_wf_def_is_enabled   ON `workflow_definition`(`is_enabled`);
CREATE INDEX ix_wf_def_is_current   ON `workflow_definition`(`is_current`);

-- ====================================================================
-- workflow_definition_step
-- ====================================================================
CREATE TABLE IF NOT EXISTS `workflow_definition_step` (
    `id`                    CHAR(36)     NOT NULL DEFAULT (UUID()),
    `definition_id`         CHAR(36)     NOT NULL,
    `step_order`            INT          NOT NULL,
    `name`                  VARCHAR(200) NOT NULL,
    `description`           VARCHAR(500),
    `step_type`             VARCHAR(50)  NOT NULL,
    `required_role`         VARCHAR(100),
    `required_approvals`    INT          NOT NULL DEFAULT 1,
    `timeout_hours`         INT          NOT NULL DEFAULT 48,
    `timeout_action`        VARCHAR(50)  NOT NULL DEFAULT 'Expire',
    `escalate_to_role`      VARCHAR(100),
    `on_approved_goto_step` INT,
    `on_rejected_goto_step` INT,
    `on_timeout_goto_step`  INT,
    `action_config_json`    TEXT,
    `created_at`            DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `last_modified_at`      DATETIME(6),
    `created_by`            VARCHAR(255),
    `last_modified_by`      VARCHAR(255),
    CONSTRAINT pk_workflow_definition_step PRIMARY KEY (`id`),
    CONSTRAINT fk_wf_step_definition FOREIGN KEY (`definition_id`) REFERENCES `workflow_definition`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_wf_step_definition_id    ON `workflow_definition_step`(`definition_id`);
CREATE INDEX ix_wf_step_definition_order ON `workflow_definition_step`(`definition_id`,`step_order`);

-- ====================================================================
-- workflow_instance
-- ====================================================================
CREATE TABLE IF NOT EXISTS `workflow_instance` (
    `id`                 CHAR(36)     NOT NULL DEFAULT (UUID()),
    `definition_id`      CHAR(36),
    `trigger_type`       VARCHAR(50)  NOT NULL,
    `entity_type`        VARCHAR(100) NOT NULL,
    `entity_id`          CHAR(36)     NOT NULL,
    `status`             VARCHAR(50)  NOT NULL DEFAULT 'Pending',
    `current_step_order` INT          NOT NULL DEFAULT 1,
    `triggered_by`       VARCHAR(255) NOT NULL,
    `triggered_at`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `completed_at`       DATETIME(6),
    `payload_json`       TEXT,
    `created_at`         DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`         DATETIME(6),
    `valid_from`         DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`           DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`        DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`          DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`         TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`         TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`        VARCHAR(255),
    CONSTRAINT pk_workflow_instance PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_wf_inst_status         ON `workflow_instance`(`status`);
CREATE INDEX ix_wf_inst_entity_id      ON `workflow_instance`(`entity_id`);
CREATE INDEX ix_wf_inst_trigger_entity ON `workflow_instance`(`trigger_type`,`entity_id`);
CREATE INDEX ix_wf_inst_is_current     ON `workflow_instance`(`is_current`);

-- ====================================================================
-- workflow_step_instance
-- ====================================================================
CREATE TABLE IF NOT EXISTS `workflow_step_instance` (
    `id`                 CHAR(36)     NOT NULL DEFAULT (UUID()),
    `instance_id`        CHAR(36)     NOT NULL,
    `step_order`         INT          NOT NULL,
    `step_type`          VARCHAR(50)  NOT NULL,
    `required_role`      VARCHAR(100),
    `required_approvals` INT          NOT NULL DEFAULT 1,
    `received_approvals` INT          NOT NULL DEFAULT 0,
    `status`             VARCHAR(50)  NOT NULL DEFAULT 'Waiting',
    `timeout_at`         DATETIME(6),
    `reviewed_by`        VARCHAR(255),
    `reviewed_at`        DATETIME(6),
    `notes`              TEXT,
    `created_at`         DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`         DATETIME(6),
    `valid_from`         DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`           DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`        DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`          DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`         TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`         TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`        VARCHAR(255),
    CONSTRAINT pk_workflow_step_instance PRIMARY KEY (`id`),
    CONSTRAINT fk_wf_step_inst_instance FOREIGN KEY (`instance_id`) REFERENCES `workflow_instance`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_wf_step_inst_instance_id ON `workflow_step_instance`(`instance_id`);
CREATE INDEX ix_wf_step_inst_status      ON `workflow_step_instance`(`status`);
CREATE INDEX ix_wf_step_inst_role_status ON `workflow_step_instance`(`required_role`,`status`);
CREATE INDEX ix_wf_step_inst_is_current  ON `workflow_step_instance`(`is_current`);

-- ====================================================================
-- workflow_step_approval
-- ====================================================================
CREATE TABLE IF NOT EXISTS `workflow_step_approval` (
    `id`                CHAR(36)     NOT NULL DEFAULT (UUID()),
    `instance_id`       CHAR(36)     NOT NULL,
    `step_instance_id`  CHAR(36),
    `from_step_order`   INT          NOT NULL,
    `target_step_order` INT,
    `decision`          VARCHAR(50)  NOT NULL,
    `decision_by`       VARCHAR(255) NOT NULL,
    `decision_at`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `notes`             TEXT,
    `created_at`        DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`        DATETIME(6),
    CONSTRAINT pk_workflow_step_approval PRIMARY KEY (`id`),
    CONSTRAINT fk_wf_approval_instance FOREIGN KEY (`instance_id`) REFERENCES `workflow_instance`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_wf_approval_instance_id ON `workflow_step_approval`(`instance_id`);
CREATE INDEX ix_wf_approval_decision_at ON `workflow_step_approval`(`decision_at`);

-- ====================================================================
-- client
-- ====================================================================
CREATE TABLE IF NOT EXISTS `client` (
    `id`         CHAR(36)     NOT NULL DEFAULT (UUID()),
    `name`       VARCHAR(255) NOT NULL,
    `code`       VARCHAR(50)  NOT NULL,
    `email`      VARCHAR(255),
    `phone`      VARCHAR(100),
    `is_active`  TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at` DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at` DATETIME(6),
    CONSTRAINT pk_client   PRIMARY KEY (`id`),
    CONSTRAINT uq_client_code UNIQUE (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- portfolio
-- ====================================================================
CREATE TABLE IF NOT EXISTS `portfolio` (
    `id`         CHAR(36)     NOT NULL DEFAULT (UUID()),
    `client_id`  CHAR(36)     NOT NULL,
    `name`       VARCHAR(255) NOT NULL,
    `code`       VARCHAR(50)  NOT NULL,
    `currency`   VARCHAR(10)  NOT NULL DEFAULT 'USD',
    `is_active`  TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at` DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at` DATETIME(6),
    CONSTRAINT pk_portfolio PRIMARY KEY (`id`),
    CONSTRAINT uq_portfolio_code   UNIQUE (`code`),
    CONSTRAINT fk_portfolio_client FOREIGN KEY (`client_id`) REFERENCES `client`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_portfolio_client_id ON `portfolio`(`client_id`);

-- ====================================================================
-- position
-- ====================================================================
CREATE TABLE IF NOT EXISTS `position` (
    `id`            CHAR(36)      NOT NULL DEFAULT (UUID()),
    `portfolio_id`  CHAR(36)      NOT NULL,
    `security_id`   CHAR(36)      NOT NULL,
    `quantity`      DECIMAL(28,8) NOT NULL,
    `as_of_date`    DATE          NOT NULL,
    `market_value`  DECIMAL(28,8),
    `book_value`    DECIMAL(28,8),
    `currency_code` CHAR(3)       NOT NULL,
    `source_system` VARCHAR(50)   NOT NULL,
    `created_at`    DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`    DATETIME(6),
    `valid_from`    DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`      DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`   DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`     DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`    TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`    TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`   VARCHAR(255),
    CONSTRAINT pk_position PRIMARY KEY (`id`),
    CONSTRAINT fk_position_portfolio FOREIGN KEY (`portfolio_id`) REFERENCES `portfolio`(`id`),
    CONSTRAINT fk_position_security  FOREIGN KEY (`security_id`)  REFERENCES `security`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_position_portfolio_id                ON `position`(`portfolio_id`);
CREATE INDEX ix_position_security_id                 ON `position`(`security_id`);
CREATE INDEX ix_position_portfolio_security_asofdate ON `position`(`portfolio_id`,`security_id`,`as_of_date`);
CREATE INDEX ix_position_is_current                  ON `position`(`is_current`);

-- ====================================================================
-- field_visibility_entity
-- ====================================================================
CREATE TABLE IF NOT EXISTS `field_visibility_entity` (
    `id`           CHAR(36)      NOT NULL DEFAULT (UUID()),
    `entity_type`  VARCHAR(200)  NOT NULL,
    `display_name` VARCHAR(200)  NOT NULL,
    `description`  VARCHAR(1000),
    `is_active`    TINYINT(1)    NOT NULL DEFAULT 1,
    `created_at`   DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`   DATETIME(6),
    `valid_from`   DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`     DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`  DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`    DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`   TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`   TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`  VARCHAR(255),
    CONSTRAINT pk_field_visibility_entity PRIMARY KEY (`id`),
    CONSTRAINT uq_field_visibility_entity_type UNIQUE (`entity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_fve_is_active  ON `field_visibility_entity`(`is_active`);
CREATE INDEX ix_fve_is_current ON `field_visibility_entity`(`is_current`);

-- ====================================================================
-- field_visibility_field
-- ====================================================================
CREATE TABLE IF NOT EXISTS `field_visibility_field` (
    `id`                         CHAR(36)     NOT NULL DEFAULT (UUID()),
    `field_visibility_entity_id` CHAR(36)     NOT NULL,
    `field_name`                 VARCHAR(200) NOT NULL,
    `display_name`               VARCHAR(200) NOT NULL,
    `data_type`                  VARCHAR(100),
    `sensitivity_level`          VARCHAR(100),
    `default_visibility_state`   VARCHAR(20)  NOT NULL DEFAULT 'VISIBLE',
    `default_obfuscation_type`   VARCHAR(30)  NOT NULL DEFAULT 'NONE',
    `sort_order`                 INT          NOT NULL DEFAULT 0,
    `is_active`                  TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at`                 DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`                 DATETIME(6),
    `valid_from`                 DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`                   DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`                DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`                  DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`                 TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`                 TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`                VARCHAR(255),
    CONSTRAINT pk_field_visibility_field PRIMARY KEY (`id`),
    CONSTRAINT uq_fvf_entity_field UNIQUE (`field_visibility_entity_id`,`field_name`),
    CONSTRAINT fk_fvf_entity FOREIGN KEY (`field_visibility_entity_id`) REFERENCES `field_visibility_entity`(`id`) ON DELETE CASCADE,
    CONSTRAINT chk_fvf_default_visibility_state CHECK (`default_visibility_state` IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED')),
    CONSTRAINT chk_fvf_default_obfuscation_type CHECK (`default_obfuscation_type` IN ('NONE','TEXT','EMAIL','NAME','DATE','NUMBER','CUSTOM'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_fvf_entity_id  ON `field_visibility_field`(`field_visibility_entity_id`);
CREATE INDEX ix_fvf_is_active  ON `field_visibility_field`(`is_active`);
CREATE INDEX ix_fvf_is_current ON `field_visibility_field`(`is_current`);

-- ====================================================================
-- permission_definition
-- ====================================================================
CREATE TABLE IF NOT EXISTS `permission_definition` (
    `id`               CHAR(36)      NOT NULL DEFAULT (UUID()),
    `permission_key`   VARCHAR(200)  NOT NULL,
    `display_name`     VARCHAR(200)  NOT NULL,
    `permission_group` VARCHAR(100)  NOT NULL,
    `description`      VARCHAR(1000),
    `is_assignable`    TINYINT(1)    NOT NULL DEFAULT 1,
    `is_system`        TINYINT(1)    NOT NULL DEFAULT 0,
    `sort_order`       INT           NOT NULL DEFAULT 0,
    `is_active`        TINYINT(1)    NOT NULL DEFAULT 1,
    `created_at`       DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`       DATETIME(6),
    `valid_from`       DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`         DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`      DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`        DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`       TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`       TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`      VARCHAR(255),
    CONSTRAINT pk_permission_definition PRIMARY KEY (`id`),
    CONSTRAINT uq_permission_definition_key UNIQUE (`permission_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_pd_group      ON `permission_definition`(`permission_group`);
CREATE INDEX ix_pd_is_current ON `permission_definition`(`is_current`);

-- ====================================================================
-- field_visibility_rule
-- ====================================================================
CREATE TABLE IF NOT EXISTS `field_visibility_rule` (
    `id`                        CHAR(36)     NOT NULL DEFAULT (UUID()),
    `field_visibility_field_id` CHAR(36)     NOT NULL,
    `permission_definition_id`  CHAR(36)     NOT NULL,
    `visibility_state`          VARCHAR(20)  NOT NULL,
    `obfuscation_type`          VARCHAR(30)  NOT NULL DEFAULT 'NONE',
    `priority`                  INT          NOT NULL DEFAULT 10,
    `is_active`                 TINYINT(1)   NOT NULL DEFAULT 1,
    `effective_from`            DATETIME(6),
    `effective_to`              DATETIME(6),
    `created_by`                VARCHAR(150) NOT NULL,
    `updated_by`                VARCHAR(150),
    `created_at`                DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`                DATETIME(6),
    `valid_from`                DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`                  DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`               DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`                 DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`                TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`                TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`               VARCHAR(255),
    CONSTRAINT pk_field_visibility_rule PRIMARY KEY (`id`),
    CONSTRAINT fk_fvr_field      FOREIGN KEY (`field_visibility_field_id`) REFERENCES `field_visibility_field`(`id`) ON DELETE CASCADE,
    CONSTRAINT fk_fvr_permission FOREIGN KEY (`permission_definition_id`)  REFERENCES `permission_definition`(`id`),
    CONSTRAINT chk_fvr_visibility_state CHECK (`visibility_state` IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED')),
    CONSTRAINT chk_fvr_obfuscation_type CHECK (`obfuscation_type` IN ('NONE','TEXT','EMAIL','NAME','DATE','NUMBER','CUSTOM'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_fvr_field_id       ON `field_visibility_rule`(`field_visibility_field_id`);
CREATE INDEX ix_fvr_permission_def ON `field_visibility_rule`(`permission_definition_id`);
CREATE INDEX ix_fvr_is_current     ON `field_visibility_rule`(`is_current`);

-- ====================================================================
-- app_resource
-- ====================================================================
CREATE TABLE IF NOT EXISTS `app_resource` (
    `id`                       CHAR(36)      NOT NULL DEFAULT (UUID()),
    `resource_type`            VARCHAR(30)   NOT NULL,
    `resource_key`             VARCHAR(300)  NOT NULL,
    `parent_app_resource_id`   CHAR(36),
    `display_name`             VARCHAR(200)  NOT NULL,
    `route_path`               VARCHAR(300),
    `icon_name`                VARCHAR(100),
    `description`              VARCHAR(1000),
    `default_visibility_state` VARCHAR(20)   NOT NULL DEFAULT 'VISIBLE',
    `default_execution_state`  VARCHAR(20)   NOT NULL DEFAULT 'ALLOW',
    `is_security_sensitive`    TINYINT(1)    NOT NULL DEFAULT 0,
    `sort_order`               INT           NOT NULL DEFAULT 0,
    `is_active`                TINYINT(1)    NOT NULL DEFAULT 1,
    `created_at`               DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`               DATETIME(6),
    `valid_from`               DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`                 DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`              DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`                DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`               TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`               TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`              VARCHAR(255),
    CONSTRAINT pk_app_resource PRIMARY KEY (`id`),
    CONSTRAINT uq_app_resource_key UNIQUE (`resource_key`),
    CONSTRAINT fk_app_resource_parent FOREIGN KEY (`parent_app_resource_id`) REFERENCES `app_resource`(`id`),
    CONSTRAINT chk_app_resource_type             CHECK (`resource_type` IN ('MENU_GROUP','MENU_ITEM','ROUTE','ACTION','TAB','SECTION')),
    CONSTRAINT chk_app_resource_visibility_state CHECK (`default_visibility_state` IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED')),
    CONSTRAINT chk_app_resource_execution_state  CHECK (`default_execution_state`  IN ('ALLOW','DENY','NOT_APPLICABLE'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_ar_parent_id  ON `app_resource`(`parent_app_resource_id`);
CREATE INDEX ix_ar_is_active  ON `app_resource`(`is_active`);
CREATE INDEX ix_ar_is_current ON `app_resource`(`is_current`);

-- ====================================================================
-- app_resource_rule
-- ====================================================================
CREATE TABLE IF NOT EXISTS `app_resource_rule` (
    `id`                       CHAR(36)     NOT NULL DEFAULT (UUID()),
    `app_resource_id`          CHAR(36)     NOT NULL,
    `permission_definition_id` CHAR(36)     NOT NULL,
    `visibility_state`         VARCHAR(20)  NOT NULL,
    `execution_state`          VARCHAR(20)  NOT NULL,
    `priority`                 INT          NOT NULL DEFAULT 100,
    `is_active`                TINYINT(1)   NOT NULL DEFAULT 1,
    `effective_from`           DATETIME(6),
    `effective_to`             DATETIME(6),
    `created_by`               VARCHAR(150) NOT NULL,
    `updated_by`               VARCHAR(150),
    `created_at`               DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`               DATETIME(6),
    `valid_from`               DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`                 DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`              DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`                DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`               TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`               TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`              VARCHAR(255),
    CONSTRAINT pk_app_resource_rule PRIMARY KEY (`id`),
    CONSTRAINT fk_arr_resource   FOREIGN KEY (`app_resource_id`)          REFERENCES `app_resource`(`id`) ON DELETE CASCADE,
    CONSTRAINT fk_arr_permission FOREIGN KEY (`permission_definition_id`) REFERENCES `permission_definition`(`id`),
    CONSTRAINT chk_arr_visibility CHECK (`visibility_state` IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED')),
    CONSTRAINT chk_arr_execution  CHECK (`execution_state`  IN ('ALLOW','DENY','NOT_APPLICABLE'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_arr_resource_id    ON `app_resource_rule`(`app_resource_id`);
CREATE INDEX ix_arr_permission_def ON `app_resource_rule`(`permission_definition_id`);
CREATE INDEX ix_arr_is_current     ON `app_resource_rule`(`is_current`);

-- ====================================================================
-- vendor_source
-- ====================================================================
CREATE TABLE IF NOT EXISTS `vendor_source` (
    `id`                        CHAR(36)     NOT NULL DEFAULT (UUID()),
    `code`                      VARCHAR(50)  NOT NULL,
    `display_name`              VARCHAR(100) NOT NULL,
    `global_priority`           INT          NOT NULL DEFAULT 100,
    `staleness_threshold_hours` INT          NOT NULL DEFAULT 24,
    `is_active`                 TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at`                DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`                DATETIME(6),
    `modified_by`               VARCHAR(255),
    `valid_from`                DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`                  DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`               DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`                 DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`                TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`                TINYINT(1)   NOT NULL DEFAULT 0,
    CONSTRAINT pk_vendor_source PRIMARY KEY (`id`),
    CONSTRAINT uq_vendor_source_code UNIQUE (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_vs_is_active  ON `vendor_source`(`is_active`);
CREATE INDEX ix_vs_is_current ON `vendor_source`(`is_current`);

-- Deferred FK: price -> vendor_source
ALTER TABLE `price` ADD CONSTRAINT fk_price_vendor_source
    FOREIGN KEY (`vendor_source_id`) REFERENCES `vendor_source`(`id`);

-- Deferred FK: issuer -> country
ALTER TABLE `issuer` ADD CONSTRAINT fk_issuer_country
    FOREIGN KEY (`country_alpha2`) REFERENCES `country`(`alpha2`);

-- ====================================================================
-- vendor_field_priority
-- ====================================================================
CREATE TABLE IF NOT EXISTS `vendor_field_priority` (
    `id`               CHAR(36)     NOT NULL DEFAULT (UUID()),
    `vendor_source_id` CHAR(36)     NOT NULL,
    `field_name`       VARCHAR(100) NOT NULL,
    `asset_class_code` VARCHAR(50),
    `priority`         INT          NOT NULL DEFAULT 100,
    `is_active`        TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`       DATETIME(6),
    `modified_by`      VARCHAR(255),
    `valid_from`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`         DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`      DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`        DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`       TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`       TINYINT(1)   NOT NULL DEFAULT 0,
    CONSTRAINT pk_vendor_field_priority PRIMARY KEY (`id`),
    CONSTRAINT fk_vfp_vendor FOREIGN KEY (`vendor_source_id`) REFERENCES `vendor_source`(`id`),
    CONSTRAINT uq_vfp_key UNIQUE (`vendor_source_id`,`field_name`,`asset_class_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_vfp_vendor_id  ON `vendor_field_priority`(`vendor_source_id`);
CREATE INDEX ix_vfp_field_name ON `vendor_field_priority`(`field_name`);
CREATE INDEX ix_vfp_is_current ON `vendor_field_priority`(`is_current`);

-- ====================================================================
-- security_vendor_data
-- ====================================================================
CREATE TABLE IF NOT EXISTS `security_vendor_data` (
    `id`               CHAR(36)     NOT NULL DEFAULT (UUID()),
    `security_id`      CHAR(36)     NOT NULL,
    `vendor_source_id` CHAR(36)     NOT NULL,
    `field_name`       VARCHAR(100) NOT NULL,
    `raw_value`        VARCHAR(500),
    `feed_batch_id`    VARCHAR(200),
    `received_at`      DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `created_at`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    CONSTRAINT pk_security_vendor_data PRIMARY KEY (`id`),
    CONSTRAINT fk_svd_security      FOREIGN KEY (`security_id`)      REFERENCES `security`(`id`),
    CONSTRAINT fk_svd_vendor_source FOREIGN KEY (`vendor_source_id`) REFERENCES `vendor_source`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_svd_security_id           ON `security_vendor_data`(`security_id`);
CREATE INDEX ix_svd_vendor_source_id      ON `security_vendor_data`(`vendor_source_id`);
CREATE INDEX ix_svd_feed_batch_id         ON `security_vendor_data`(`feed_batch_id`);
CREATE INDEX ix_svd_security_vendor_field ON `security_vendor_data`(`security_id`,`vendor_source_id`,`field_name`,`received_at`);

-- ====================================================================
-- data_lineage_event
-- ====================================================================
CREATE TABLE IF NOT EXISTS `data_lineage_event` (
    `id`                  CHAR(36)      NOT NULL DEFAULT (UUID()),
    `security_id`         CHAR(36)      NOT NULL,
    `field_name`          VARCHAR(100)  NOT NULL,
    `field_value`         VARCHAR(500),
    `source_type`         VARCHAR(30)   NOT NULL,
    `vendor_source_id`    CHAR(36),
    `feed_batch_id`       VARCHAR(100),
    `resolution_rule`     VARCHAR(500),
    `runner_up_vendor_id` CHAR(36),
    `runner_up_value`     VARCHAR(500),
    `override_user_id`    VARCHAR(100),
    `override_reason`     VARCHAR(1000),
    `resolved_at`         DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `created_at`          DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    CONSTRAINT pk_data_lineage_event PRIMARY KEY (`id`),
    CONSTRAINT chk_dle_source_type CHECK (`source_type` IN ('VENDOR','MANUAL_OVERRIDE','SYSTEM_DEFAULT','DERIVED')),
    CONSTRAINT fk_dle_security      FOREIGN KEY (`security_id`)         REFERENCES `security`(`id`),
    CONSTRAINT fk_dle_vendor_source FOREIGN KEY (`vendor_source_id`)    REFERENCES `vendor_source`(`id`),
    CONSTRAINT fk_dle_runner_up     FOREIGN KEY (`runner_up_vendor_id`) REFERENCES `vendor_source`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_dle_security_id         ON `data_lineage_event`(`security_id`);
CREATE INDEX ix_dle_source_type         ON `data_lineage_event`(`source_type`);
CREATE INDEX ix_dle_security_field_date ON `data_lineage_event`(`security_id`,`field_name`,`resolved_at`);

-- ====================================================================
-- Identity indexes
-- ====================================================================
CREATE UNIQUE INDEX user_name_index ON `AspNetUsers`(`NormalizedUserName`);
CREATE        INDEX email_index     ON `AspNetUsers`(`NormalizedEmail`);
CREATE UNIQUE INDEX role_name_index ON `AspNetRoles`(`NormalizedName`);
CREATE        INDEX ix_aspnetuserlogins_userid  ON `AspNetUserLogins`(`UserId`);
CREATE        INDEX ix_aspnetuserclaims_userid  ON `AspNetUserClaims`(`UserId`);
CREATE        INDEX ix_aspnetuserroles_roleid   ON `AspNetUserRoles`(`RoleId`);
CREATE        INDEX ix_aspnetroleclaims_roleid  ON `AspNetRoleClaims`(`RoleId`);

-- ====================================================================
-- Version record
-- ====================================================================
INSERT IGNORE INTO `__SchemaVersions` (`version`, `description`, `script_name`)
VALUES ('2.0', 'Full schema parity with SQL Server (all milestones through QW4)', 'CreateSchema_MySQL.sql');

SELECT 'SecurityApp schema created successfully.' AS status;

-- ====================================================================
-- ASP.NET Identity tables
-- Column names stay PascalCase — owned by the Identity framework.
-- ====================================================================
CREATE TABLE IF NOT EXISTS `AspNetRoles` (
    `id`               VARCHAR(255) NOT NULL PRIMARY KEY,
    `name`             VARCHAR(256),
    `normalized_name`   VARCHAR(256),
    `concurrency_stamp` TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `AspNetUsers` (
    `id`                   VARCHAR(255) NOT NULL PRIMARY KEY,
    `user_name`             VARCHAR(256),
    `normalized_user_name`   VARCHAR(256),
    `email`                VARCHAR(256),
    `normalized_email`      VARCHAR(256),
    `email_confirmed`       TINYINT(1)   NOT NULL DEFAULT 0,
    `password_hash`         TEXT,
    `security_stamp`        TEXT,
    `concurrency_stamp`     TEXT,
    `phone_number`          TEXT,
    `phone_number_confirmed` TINYINT(1)   NOT NULL DEFAULT 0,
    `two_factor_enabled`     TINYINT(1)   NOT NULL DEFAULT 0,
    `lockout_end`           DATETIME(6),
    `lockout_enabled`       TINYINT(1)   NOT NULL DEFAULT 0,
    `access_failed_count`    INT          NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `AspNetUserRoles` (
    `user_id` VARCHAR(255) NOT NULL,
    `role_id` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`user_id`, `role_id`),
    CONSTRAINT fk_aspnetuserroles_users FOREIGN KEY (`user_id`) REFERENCES `AspNetUsers` (`id`) ON DELETE CASCADE,
    CONSTRAINT fk_aspnetuserroles_roles FOREIGN KEY (`role_id`) REFERENCES `AspNetRoles`  (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `AspNetUserClaims` (
    `id`         INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `user_id`     VARCHAR(255) NOT NULL,
    `claim_type`  TEXT,
    `claim_value` TEXT,
    CONSTRAINT fk_aspnetuserclaims_users FOREIGN KEY (`user_id`) REFERENCES `AspNetUsers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `AspNetUserLogins` (
    `login_provider`       VARCHAR(255) NOT NULL,
    `provider_key`         VARCHAR(255) NOT NULL,
    `provider_display_name` TEXT,
    `user_id`              VARCHAR(255) NOT NULL,
    PRIMARY KEY (`login_provider`, `provider_key`),
    CONSTRAINT fk_aspnetuserlogins_users FOREIGN KEY (`user_id`) REFERENCES `AspNetUsers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `AspNetUserTokens` (
    `user_id`        VARCHAR(255) NOT NULL,
    `login_provider` VARCHAR(255) NOT NULL,
    `name`          VARCHAR(255) NOT NULL,
    `value`         TEXT,
    PRIMARY KEY (`user_id`, `login_provider`, `name`),
    CONSTRAINT fk_aspnetusertokens_users FOREIGN KEY (`user_id`) REFERENCES `AspNetUsers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `AspNetRoleClaims` (
    `id`         INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `role_id`     VARCHAR(255) NOT NULL,
    `claim_type`  TEXT,
    `claim_value` TEXT,
    CONSTRAINT fk_aspnetroleclaims_roles FOREIGN KEY (`role_id`) REFERENCES `AspNetRoles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- Business tables
-- ====================================================================

-- ── Securities ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `securities` (
    `id`              CHAR(36)     NOT NULL DEFAULT (UUID()) PRIMARY KEY,
    `identifier_type`  VARCHAR(50)  NOT NULL,
    `identifier_value` VARCHAR(100) NOT NULL,
    `data_source`      VARCHAR(50)  NOT NULL DEFAULT 'FlatFile',
    `type`            VARCHAR(50)  NOT NULL,
    `name`            VARCHAR(255) NOT NULL,
    `description`     TEXT,
    `issuer`          VARCHAR(255),
    `currency`        VARCHAR(10),
    -- BaseEntity
    `created_at`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`       DATETIME(6),
    -- TemporalEntity
    `valid_from`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`         DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`      DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`        DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`       TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`       TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`      VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Prices ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `prices` (
    `id`         CHAR(36)      NOT NULL DEFAULT (UUID()) PRIMARY KEY,
    `security_id` CHAR(36)      NOT NULL,
    `value`      DECIMAL(18,8) NOT NULL,
    `source`     VARCHAR(50)   NOT NULL,
    `price_date`  DATETIME(6)   NOT NULL,
    `price_type`  VARCHAR(50),
    `currency`   VARCHAR(10),
    -- BaseEntity
    `created_at`  DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`  DATETIME(6),
    -- TemporalEntity
    `valid_from`  DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`    DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from` DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`   DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`  TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`  TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by` VARCHAR(255),
    CONSTRAINT fk_prices_securities FOREIGN KEY (`security_id`) REFERENCES `securities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── PricingRules ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `pricing_rules` (
    `id`             CHAR(36)      NOT NULL DEFAULT (UUID()) PRIMARY KEY,
    `rule_name`       VARCHAR(255)  NOT NULL,
    `security_type`   VARCHAR(50),
    `rule_definition_json` TEXT          NOT NULL,
    `created_by`      CHAR(36),
    `description`    VARCHAR(1000),
    -- BaseEntity
    `created_at`      DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`      DATETIME(6),
    -- TemporalEntity
    `valid_from`      DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`        DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`     DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`       DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`      TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`      TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`     VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── DerivedPrices ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `derived_prices` (
    `id`                 CHAR(36)      NOT NULL DEFAULT (UUID()) PRIMARY KEY,
    `security_id`         CHAR(36)      NOT NULL,
    `pricing_rule_id`      CHAR(36)      NOT NULL,
    `calculated_price`    DECIMAL(18,8) NOT NULL,
    `calculated_at`       DATETIME(6)   NOT NULL,
    `calculation_details` TEXT,
    -- BaseEntity
    `created_at`          DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`          DATETIME(6),
    -- TemporalEntity
    `valid_from`          DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`            DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`         DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`           DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`          TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`          TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`         VARCHAR(255),
    CONSTRAINT fk_derivedprices_securities   FOREIGN KEY (`security_id`)    REFERENCES `securities`   (`id`) ON DELETE CASCADE,
    CONSTRAINT fk_derivedprices_pricingrules FOREIGN KEY (`pricing_rule_id`) REFERENCES `pricing_rules` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── SecurityAttributes ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `security_attributes` (
    `id`           CHAR(36)      NOT NULL DEFAULT (UUID()) PRIMARY KEY,
    `security_id`   CHAR(36)      NOT NULL,
    `coupon_rate`   DECIMAL(10,6),
    `factor_rate`   DECIMAL(10,6),
    `maturity_date` DATETIME(6),
    `issue_date`    DATETIME(6),
    `face_value`    DECIMAL(18,2),
    -- BaseEntity
    `created_at`    DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`    DATETIME(6),
    -- TemporalEntity
    `valid_from`    DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`      DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`   DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`     DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`    TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`    TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`   VARCHAR(255),
    CONSTRAINT fk_securityattributes_securities FOREIGN KEY (`security_id`) REFERENCES `securities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── AuditLogs ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `audit_logs` (
    `id`             CHAR(36)    NOT NULL DEFAULT (UUID()) PRIMARY KEY,
    `entity_type`    VARCHAR(50) NOT NULL,
    `action`         VARCHAR(50) NOT NULL,
    `user_id`        CHAR(36),
    `user_name`      VARCHAR(255),
    `details`        TEXT,
    `ip_address`     VARCHAR(45),
    `entity_id`      CHAR(36),
    `before_state`   LONGTEXT,
    `after_state`    LONGTEXT,
    `changed_fields` LONGTEXT,
    `correlation_id` CHAR(36),
    `causation_id`   CHAR(36),
    `source`         VARCHAR(50) NOT NULL DEFAULT 'Http',
    `created_at`     DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── ImportRequests ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `import_requests` (
    `id`               CHAR(36)     NOT NULL DEFAULT (UUID()) PRIMARY KEY,
    -- BaseEntity
    `created_at`        DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`        DATETIME(6),
    -- Request fields (stored as string names via EF Core HasConversion<string>())
    `request_type`      VARCHAR(50)  NOT NULL,
    `source_system`     VARCHAR(50),
    `target_system`     VARCHAR(50),
    `status`           VARCHAR(50)  NOT NULL DEFAULT 'InProgress',
    `user_id`           CHAR(36),
    `user_name`         VARCHAR(255),
    `completed_at`      DATETIME(6),
    `error_message`     TEXT,
    `request_details`   TEXT,
    `total_records`     INT,
    `processed_records` INT,
    `failed_records`    INT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── CreditRatings ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `credit_ratings` (
    `id`         CHAR(36)     NOT NULL DEFAULT (UUID()) PRIMARY KEY,
    `security_id` CHAR(36)     NOT NULL,
    `agency`     VARCHAR(50)  NOT NULL,
    `rating`     VARCHAR(20)  NOT NULL,
    `rating_type` VARCHAR(30)  NOT NULL DEFAULT 'LongTerm',
    `rating_date` DATETIME(6),
    -- BaseEntity
    `created_at`  DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`  DATETIME(6),
    -- TemporalEntity
    `valid_from`  DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`    DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from` DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`   DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`  TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`  TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by` VARCHAR(255),
    CONSTRAINT fk_creditratings_securities FOREIGN KEY (`security_id`) REFERENCES `securities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── DerivedRatings ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `derived_ratings` (
    `id`                     CHAR(36)      NOT NULL DEFAULT (UUID()) PRIMARY KEY,
    `security_id`             CHAR(36)      NOT NULL,
    `implied_rating_score`     INT,
    `vpm_rating_score`         INT,
    `fundamental_rating_score` INT,
    `composite_rating_score`   INT,
    `output_agency`           VARCHAR(30)   NOT NULL DEFAULT 'SP',
    `implied_rating`          VARCHAR(20),
    `vpm_rating`              VARCHAR(20),
    `fundamental_rating`      VARCHAR(20),
    `composite_rating`        VARCHAR(20),
    `implied_pd`              DECIMAL(12,10),
    `model_pd`                DECIMAL(12,10),
    `fair_price`              DECIMAL(18,6),
    `source_hash`             VARCHAR(64)   NOT NULL DEFAULT '',
    `last_calculated_utc`      DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    -- BaseEntity
    `created_at`              DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`              DATETIME(6),
    -- TemporalEntity
    `valid_from`              DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`                DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`             DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`               DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`              TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`              TINYINT(1)    NOT NULL DEFAULT 0,
    `modified_by`             VARCHAR(255),
    CONSTRAINT fk_derivedratings_securities FOREIGN KEY (`security_id`) REFERENCES `securities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── VendorRatingMetadata ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `vendor_rating_metadata` (
    `id`              CHAR(36)    NOT NULL DEFAULT (UUID()) PRIMARY KEY,
    `vendor_name`      VARCHAR(100) NOT NULL,
    `accuracy_score`   DECIMAL(5,4)  NOT NULL DEFAULT 0.5,
    `stability_score`  DECIMAL(5,4)  NOT NULL DEFAULT 0.5,
    `timeliness_score` DECIMAL(5,4)  NOT NULL DEFAULT 0.5,
    `coverage_score`   DECIMAL(5,4)  NOT NULL DEFAULT 0.5,
    `last_updated_utc`  DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    -- BaseEntity
    `created_at`       DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`       DATETIME(6),
    CONSTRAINT uq_vendorratingmetadata_vendorname UNIQUE (`vendor_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── RatingScaleEntries ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `rating_scale_entries` (
    `id`                CHAR(36)    NOT NULL DEFAULT (UUID()) PRIMARY KEY,
    `agency`            VARCHAR(50) NOT NULL,
    `score`             INT         NOT NULL,
    `label`             VARCHAR(20) NOT NULL,
    `is_investment_grade` TINYINT(1)  NOT NULL DEFAULT 0,
    -- BaseEntity
    `created_at`         DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`         DATETIME(6),
    -- TemporalEntity
    `valid_from`         DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`           DATETIME(6) NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`        DATETIME(6) NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`          DATETIME(6) NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`         TINYINT(1)  NOT NULL DEFAULT 1,
    `is_deleted`         TINYINT(1)  NOT NULL DEFAULT 0,
    `modified_by`        VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── RatingDerivationRules ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `rating_derivation_rules` (
    `id`           CHAR(36)     NOT NULL DEFAULT (UUID()) PRIMARY KEY,
    `model_name`    VARCHAR(50)  NOT NULL,
    `security_type` VARCHAR(50),
    `config_json`   TEXT         NOT NULL DEFAULT ('{}'),
    `description`  VARCHAR(500),
    -- BaseEntity
    `created_at`    DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`    DATETIME(6),
    -- TemporalEntity
    `valid_from`    DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`      DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`   DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`     DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`    TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`    TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`   VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── FormulaMacros ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `formula_macros` (
    `id`          CHAR(36)     NOT NULL DEFAULT (UUID()) PRIMARY KEY,
    `name`        VARCHAR(100) NOT NULL,
    `expression`  TEXT         NOT NULL,
    `description` VARCHAR(500),
    `scope`       VARCHAR(50),
    -- BaseEntity
    `created_at`   DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `updated_at`   DATETIME(6),
    -- TemporalEntity
    `valid_from`   DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`     DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`  DATETIME(6)  NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`    DATETIME(6)  NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`   TINYINT(1)   NOT NULL DEFAULT 1,
    `is_deleted`   TINYINT(1)   NOT NULL DEFAULT 0,
    `modified_by`  VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── ImportProfiles ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `import_profiles` (
    `id`             CHAR(36)     NOT NULL PRIMARY KEY,
    `name`           VARCHAR(100) NOT NULL,
    `description`    VARCHAR(500),
    `source_type`     VARCHAR(50)  NOT NULL,
    `file_pattern`    VARCHAR(200) NOT NULL DEFAULT '*.csv',
    `folder`         VARCHAR(500),
    `delimiter`      VARCHAR(10),
    `text_qualifier`  VARCHAR(5),
    `has_header`      TINYINT(1)   NOT NULL DEFAULT 1,
    `skip_rows`       INT          NOT NULL DEFAULT 0,
    `records_path`    VARCHAR(500),
    `records_x_path`   VARCHAR(500),
    `is_active`       TINYINT(1)   NOT NULL DEFAULT 1,
    -- BaseEntity
    `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME     NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── ImportProfileColumns ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `import_profile_columns` (
    `id`           CHAR(36)     NOT NULL PRIMARY KEY,
    `profile_id`    CHAR(36)     NOT NULL,
    `source_column` VARCHAR(200) NOT NULL,
    `target_field`  VARCHAR(200) NOT NULL,
    `sort_order`    INT          NOT NULL DEFAULT 0,
    -- BaseEntity
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME     NULL ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `f_k__import_profile_columns__import_profiles`
        FOREIGN KEY (`profile_id`) REFERENCES `import_profiles` (`id`)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── ImportProfileColumnValidations ───────────────────────────────────
CREATE TABLE IF NOT EXISTS `import_profile_column_validations` (
    `id`           CHAR(36)      NOT NULL PRIMARY KEY,
    `column_id`     CHAR(36)      NOT NULL,
    `rule_type`     VARCHAR(50)   NOT NULL,
    `rule_value`    VARCHAR(500),
    `condition`    VARCHAR(1000),
    `error_message` VARCHAR(500),
    `severity`     VARCHAR(20)   NOT NULL DEFAULT 'Error',
    `is_active`     TINYINT(1)   NOT NULL DEFAULT 1,
    -- BaseEntity
    `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME      NULL ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `f_k__import_profile_column_validations__import_profile_columns`
        FOREIGN KEY (`column_id`) REFERENCES `import_profile_columns` (`id`)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── ImportProfileRowValidations ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS `import_profile_row_validations` (
    `id`           CHAR(36)     NOT NULL PRIMARY KEY,
    `profile_id`    CHAR(36)     NOT NULL,
    `expression`   TEXT         NOT NULL,
    `error_message` VARCHAR(500) NOT NULL,
    `severity`     VARCHAR(20)  NOT NULL DEFAULT 'Error',
    `sort_order`    INT          NOT NULL DEFAULT 0,
    `is_active`     TINYINT(1)   NOT NULL DEFAULT 1,
    -- BaseEntity
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME     NULL ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `f_k__import_profile_row_validations__import_profiles`
        FOREIGN KEY (`profile_id`) REFERENCES `import_profiles` (`id`)
        ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- Indexes
-- ====================================================================

-- Identity
CREATE UNIQUE INDEX `user_name_index`       ON `AspNetUsers`      (`normalized_user_name`);
CREATE INDEX `email_index`                 ON `AspNetUsers`      (`normalized_email`);
CREATE UNIQUE INDEX `role_name_index`       ON `AspNetRoles`      (`normalized_name`);
CREATE INDEX `i_x__asp_net_user_claims__user_id` ON `AspNetUserClaims` (`user_id`);
CREATE INDEX `i_x__asp_net_user_logins__user_id` ON `AspNetUserLogins` (`user_id`);
CREATE INDEX `i_x__asp_net_user_roles__role_id`  ON `AspNetUserRoles`  (`role_id`);
CREATE INDEX `i_x__asp_net_role_claims__role_id` ON `AspNetRoleClaims` (`role_id`);

-- Securities
-- MySQL 8.0 does not support partial/filtered unique indexes, so this is a regular index.
-- Application logic and the global query filter (IsCurrent=1) together prevent duplicate live rows.
CREATE INDEX `i_x__securities__identifier_type__identifier_value__data_source`
    ON `securities` (`identifier_type`, `identifier_value`, `data_source`);
CREATE INDEX `i_x__securities__is_current`  ON `securities` (`is_current`);
CREATE INDEX `i_x__securities__is_deleted`  ON `securities` (`is_deleted`);
CREATE INDEX `i_x__securities__valid_time`  ON `securities` (`valid_from`, `valid_to`);
CREATE INDEX `i_x__securities__system_time` ON `securities` (`system_from`, `system_to`);

-- Prices
CREATE INDEX `i_x__prices__security_id__source__price_date` ON `prices` (`security_id`, `source`, `price_date`);
CREATE INDEX `i_x__prices__is_current`  ON `prices` (`is_current`);
CREATE INDEX `i_x__prices__valid_time`  ON `prices` (`valid_from`, `valid_to`);
CREATE INDEX `i_x__prices__system_time` ON `prices` (`system_from`, `system_to`);

-- AuditLogs
CREATE INDEX `i_x__audit_logs__created_at`            ON `audit_logs` (`created_at`);
CREATE INDEX `i_x__audit_logs__user_id`               ON `audit_logs` (`user_id`);
CREATE INDEX `i_x__audit_logs__entity_type_entity_id` ON `audit_logs` (`entity_type`, `entity_id`);
CREATE INDEX `i_x__audit_logs__correlation_id`        ON `audit_logs` (`correlation_id`);

-- ImportRequests
CREATE INDEX `i_x__import_requests__status`    ON `import_requests` (`status`);
CREATE INDEX `i_x__import_requests__created_at` ON `import_requests` (`created_at`);

-- CreditRatings
CREATE INDEX `i_x__credit_ratings__security_id__agency__rating_type__is_current`
    ON `credit_ratings` (`security_id`, `agency`, `rating_type`, `is_current`);
CREATE INDEX `i_x__credit_ratings__valid_time`  ON `credit_ratings` (`valid_from`, `valid_to`);
CREATE INDEX `i_x__credit_ratings__system_time` ON `credit_ratings` (`system_from`, `system_to`);

-- DerivedRatings
CREATE INDEX `i_x__derived_ratings__security_id`       ON `derived_ratings` (`security_id`);
CREATE INDEX `i_x__derived_ratings__security__current` ON `derived_ratings` (`security_id`, `is_current`);
CREATE INDEX `i_x__derived_ratings__valid_time`        ON `derived_ratings` (`valid_from`, `valid_to`);

-- RatingScaleEntries
CREATE INDEX `i_x__rating_scale_entries__agency__score` ON `rating_scale_entries` (`agency`, `score`, `is_current`);
CREATE INDEX `i_x__rating_scale_entries__valid_time`     ON `rating_scale_entries` (`valid_from`, `valid_to`);

-- RatingDerivationRules
CREATE INDEX `i_x__rating_derivation_rules__model_type`  ON `rating_derivation_rules` (`model_name`, `security_type`, `is_current`);
CREATE INDEX `i_x__rating_derivation_rules__valid_time`  ON `rating_derivation_rules` (`valid_from`, `valid_to`);

-- FormulaMacros
CREATE INDEX `i_x__formula_macros__name__current` ON `formula_macros` (`name`, `is_current`);
CREATE INDEX `i_x__formula_macros__valid_time`    ON `formula_macros` (`valid_from`, `valid_to`);

-- ImportProfiles
CREATE UNIQUE INDEX `u_i_x__import_profiles__name__source_type`
    ON `import_profiles` (`name`, `source_type`);
CREATE INDEX `i_x__import_profiles__source_type__is_active`
    ON `import_profiles` (`source_type`, `is_active`);

-- ImportProfileColumns
CREATE INDEX `i_x__import_profile_columns__profile_id`
    ON `import_profile_columns` (`profile_id`);

-- ImportProfileColumnValidations
CREATE INDEX `i_x__import_profile_column_validations__column_id`
    ON `import_profile_column_validations` (`column_id`);

-- ImportProfileRowValidations
CREATE INDEX `i_x__import_profile_row_validations__profile_id`
    ON `import_profile_row_validations` (`profile_id`);

-- ─────────────────────────────────────────────────────────────────────────────
-- Job Scheduling
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `job_execution_history` (
    `id`               CHAR(36)      NOT NULL,
    `job_name`         VARCHAR(200)  NOT NULL,
    `job_group`        VARCHAR(200)  NOT NULL,
    `triggered_by`     VARCHAR(255)  NOT NULL  DEFAULT 'scheduler',
    `started_at`       DATETIME(3)   NOT NULL,
    `completed_at`     DATETIME(3)       NULL,
    `succeeded`        TINYINT(1)    NOT NULL  DEFAULT 0,
    `error_message`    VARCHAR(2000)     NULL,
    `error_detail`     TEXT              NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `job_schedules` (
    `id`              CHAR(36)     NOT NULL  DEFAULT (UUID()),
    `plugin_name`     VARCHAR(200) NOT NULL,
    `job_group`       VARCHAR(200) NOT NULL,
    `cron_expression` VARCHAR(100)     NULL,
    `enabled`         TINYINT(1)   NOT NULL  DEFAULT 1,
    `time_zone`       VARCHAR(100) NOT NULL  DEFAULT 'UTC',
    -- BaseEntity
    `created_at`      DATETIME(6)  NOT NULL  DEFAULT CURRENT_TIMESTAMP(6),
    `updated_at`      DATETIME(6)      NULL,
    -- TemporalEntity
    `valid_from`      DATETIME(6)  NOT NULL  DEFAULT CURRENT_TIMESTAMP(6),
    `valid_to`        DATETIME(6)  NOT NULL  DEFAULT '9999-12-31 00:00:00',
    `system_from`     DATETIME(6)  NOT NULL  DEFAULT CURRENT_TIMESTAMP(6),
    `system_to`       DATETIME(6)  NOT NULL  DEFAULT '9999-12-31 00:00:00',
    `is_current`      TINYINT(1)   NOT NULL  DEFAULT 1,
    `is_deleted`      TINYINT(1)   NOT NULL  DEFAULT 0,
    `modified_by`     VARCHAR(255)     NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- JobExecutionHistory
CREATE INDEX `ix__job_execution_history__job_name`   ON `job_execution_history` (`job_name`);
CREATE INDEX `ix__job_execution_history__started_at` ON `job_execution_history` (`started_at`);

-- JobSchedules
CREATE INDEX `ix__job_schedules__plugin_name` ON `job_schedules` (`plugin_name`);
CREATE INDEX `ix__job_schedules__is_current`  ON `job_schedules` (`is_current`);
CREATE INDEX `ix__job_schedules__system_time` ON `job_schedules` (`system_from`, `system_to`);

-- ====================================================================
-- Record this script
-- ====================================================================
INSERT IGNORE INTO `__SchemaVersions` (`version`, `description`)
VALUES ('1.0-schema', 'Initial schema — all tables and indexes (PascalCase columns)');

-- ====================================================================
-- app_resource_group
-- ====================================================================
CREATE TABLE IF NOT EXISTS `app_resource_group` (
    `id`               CHAR(36)      NOT NULL DEFAULT (UUID()),
    `group_key`        VARCHAR(200)  NOT NULL,
    `display_name`     VARCHAR(200)  NOT NULL,
    `description`      VARCHAR(1000),
    `icon_name`        VARCHAR(100),
    `sort_order`       INT           NOT NULL DEFAULT 0,
    `is_active`        TINYINT(1)    NOT NULL DEFAULT 1,
    `created_at`       DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `last_modified_at` DATETIME(6),
    `created_by`       VARCHAR(255),
    `last_modified_by` VARCHAR(255),
    `valid_from`       DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `valid_to`         DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `system_from`      DATETIME(6)   NOT NULL DEFAULT (UTC_TIMESTAMP(6)),
    `system_to`        DATETIME(6)   NOT NULL DEFAULT '9999-12-31 00:00:00',
    `is_current`       TINYINT(1)    NOT NULL DEFAULT 1,
    `is_deleted`       TINYINT(1)    NOT NULL DEFAULT 0,
    CONSTRAINT pk_app_resource_group PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE UNIQUE INDEX `uq_app_resource_group_key` ON `app_resource_group` (`group_key`, `is_current`, `is_deleted`);
CREATE INDEX `ix_arg_is_current` ON `app_resource_group` (`is_current`);

SELECT 'SecurityApp schema created successfully.' AS status;