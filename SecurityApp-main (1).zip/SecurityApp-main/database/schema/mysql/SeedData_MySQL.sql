-- ====================================================================
-- SecurityApp � Seed Data (MySQL)
-- Populates initial reference data required for the rating model.
-- Run AFTER CreateSchema_MySQL.sql.
-- All inserts are idempotent (WHERE NOT EXISTS guards).
-- ====================================================================

SELECT 'Seeding SecurityApp reference data (MySQL)...' AS status;

-- ====================================================================
-- Reference tables
-- ====================================================================

-- security_status_ref
INSERT INTO `security_status_ref` (`code`, `description`)
SELECT v.code, v.description
FROM (
    SELECT 'DRAFT'            AS code, 'Created but not yet submitted'          AS description FROM DUAL UNION ALL
    SELECT 'PENDING_APPROVAL',          'Awaiting Compliance approval'          FROM DUAL UNION ALL
    SELECT 'ACTIVE',                    'Approved and operational'              FROM DUAL UNION ALL
    SELECT 'SUSPENDED',                 'Temporarily disabled; still reportable'FROM DUAL UNION ALL
    SELECT 'CALLED',                    'Issuer has called the instrument'      FROM DUAL UNION ALL
    SELECT 'MATURED',                   'Reached maturity date'                 FROM DUAL UNION ALL
    SELECT 'DEFAULTED',                 'Issuer has defaulted'                  FROM DUAL UNION ALL
    SELECT 'RESTRUCTURED',              'Terms restructured post-default'       FROM DUAL UNION ALL
    SELECT 'RETIRED',                   'Removed from active universe'          FROM DUAL UNION ALL
    SELECT 'CANCELLED',                 'Cancelled before or at issuance'       FROM DUAL
) AS v
WHERE NOT EXISTS (SELECT 1 FROM `security_status_ref` WHERE `code` = v.code)
ON DUPLICATE KEY UPDATE `description` = VALUES(`description`);

-- security_status_transition_ref
INSERT IGNORE INTO `security_status_transition_ref` (`from_code`, `to_code`)
SELECT v.f, v.t
FROM (
    SELECT 'DRAFT'            AS f, 'PENDING_APPROVAL' AS t FROM DUAL UNION ALL
    SELECT 'DRAFT',                 'CANCELLED'              FROM DUAL UNION ALL
    SELECT 'PENDING_APPROVAL',      'ACTIVE'                 FROM DUAL UNION ALL
    SELECT 'PENDING_APPROVAL',      'DRAFT'                  FROM DUAL UNION ALL
    SELECT 'PENDING_APPROVAL',      'CANCELLED'              FROM DUAL UNION ALL
    SELECT 'ACTIVE',                'SUSPENDED'              FROM DUAL UNION ALL
    SELECT 'ACTIVE',                'CALLED'                 FROM DUAL UNION ALL
    SELECT 'ACTIVE',                'MATURED'                FROM DUAL UNION ALL
    SELECT 'ACTIVE',                'DEFAULTED'              FROM DUAL UNION ALL
    SELECT 'ACTIVE',                'RETIRED'                FROM DUAL UNION ALL
    SELECT 'SUSPENDED',             'ACTIVE'                 FROM DUAL UNION ALL
    SELECT 'SUSPENDED',             'CALLED'                 FROM DUAL UNION ALL
    SELECT 'SUSPENDED',             'MATURED'                FROM DUAL UNION ALL
    SELECT 'SUSPENDED',             'DEFAULTED'              FROM DUAL UNION ALL
    SELECT 'SUSPENDED',             'RETIRED'                FROM DUAL UNION ALL
    SELECT 'DEFAULTED',             'RESTRUCTURED'           FROM DUAL UNION ALL
    SELECT 'DEFAULTED',             'RETIRED'                FROM DUAL UNION ALL
    SELECT 'RESTRUCTURED',          'ACTIVE'                 FROM DUAL UNION ALL
    SELECT 'RESTRUCTURED',          'RETIRED'                FROM DUAL UNION ALL
    SELECT 'CALLED',                'RETIRED'                FROM DUAL UNION ALL
    SELECT 'MATURED',               'RETIRED'                FROM DUAL
) AS v;

-- asset_class_ref
INSERT INTO `asset_class_ref` (`code`, `name`, `description`)
SELECT v.code, v.name, v.description
FROM (
    SELECT 'EQUITY'       AS code, 'Equity'                      AS name, NULL AS description FROM DUAL UNION ALL
    SELECT 'BOND',                 'Bond / Fixed Income',                  NULL               FROM DUAL UNION ALL
    SELECT 'LOAN',                 'Loan',                                 NULL               FROM DUAL UNION ALL
    SELECT 'MONEY_MARKET',         'Money Market',                         NULL               FROM DUAL UNION ALL
    SELECT 'FUND',                 'Fund / Collective Investment',         NULL               FROM DUAL UNION ALL
    SELECT 'DERIVATIVE',           'Derivative',                           NULL               FROM DUAL UNION ALL
    SELECT 'SECURITIZED',          'Securitized / Structured',             NULL               FROM DUAL UNION ALL
    SELECT 'FX',                   'Foreign Exchange',                     NULL               FROM DUAL UNION ALL
    SELECT 'COMMODITY',            'Commodity',                            NULL               FROM DUAL UNION ALL
    SELECT 'OTHER',                'Other / Misc',                         NULL               FROM DUAL
) AS v
WHERE NOT EXISTS (SELECT 1 FROM `asset_class_ref` WHERE `code` = v.code)
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- instrument_type_ref
INSERT INTO `instrument_type_ref` (`code`, `asset_class_code`, `description`)
SELECT v.code, v.asset_class_code, v.description
FROM (
    SELECT 'TreasuryBond'            AS code, 'BOND'        AS asset_class_code, 'Government treasury bond'                         AS description FROM DUAL UNION ALL
    SELECT 'SovereignBond',                   'BOND',                            'Non-treasury sovereign issues'                                    FROM DUAL UNION ALL
    SELECT 'AgencyBond',                      'BOND',                            'Supranational / agency bond'                                      FROM DUAL UNION ALL
    SELECT 'CorporateBond',                   'BOND',                            'Vanilla corporate bond'                                           FROM DUAL UNION ALL
    SELECT 'MunicipalBond',                   'BOND',                            'Municipal / local government bond'                                FROM DUAL UNION ALL
    SELECT 'SubordinatedBond',                'BOND',                            'Subordinated debt'                                                FROM DUAL UNION ALL
    SELECT 'InflationLinkedBond',             'BOND',                            'Inflation-linked government or corporate bond'                    FROM DUAL UNION ALL
    SELECT 'PerpetualBond',                   'BOND',                            'Bond with no fixed maturity'                                      FROM DUAL UNION ALL
    SELECT 'CommercialPaper',                 'BOND',                            'Short-term unsecured note'                                        FROM DUAL UNION ALL
    SELECT 'CertificateOfDeposit',            'BOND',                            'Certificate of deposit / time deposit'                            FROM DUAL UNION ALL
    SELECT 'ConvertibleBond',                 'BOND',                            'Bond convertible into equity'                                     FROM DUAL UNION ALL
    SELECT 'TermLoan',                        'LOAN',                            'Amortising or bullet term loan'                                   FROM DUAL UNION ALL
    SELECT 'RevolvingLoan',                   'LOAN',                            'Revolving credit facility'                                        FROM DUAL UNION ALL
    SELECT 'SyndicatedLoan',                  'LOAN',                            'Syndicated term / revolver'                                       FROM DUAL UNION ALL
    SELECT 'MortgageLoan',                    'LOAN',                            'Mortgage loan'                                                    FROM DUAL UNION ALL
    SELECT 'ConsumerLoan',                    'LOAN',                            'Retail / consumer loan'                                           FROM DUAL UNION ALL
    SELECT 'ABS',                             'SECURITIZED',                     'Asset-backed security (non-mortgage)'                             FROM DUAL UNION ALL
    SELECT 'MBS',                             'SECURITIZED',                     'Mortgage-backed security (generic)'                               FROM DUAL UNION ALL
    SELECT 'RMBS',                            'SECURITIZED',                     'Residential mortgage-backed security'                             FROM DUAL UNION ALL
    SELECT 'CMBS',                            'SECURITIZED',                     'Commercial mortgage-backed security'                              FROM DUAL UNION ALL
    SELECT 'CLO',                             'SECURITIZED',                     'Collateralised loan obligation'                                   FROM DUAL UNION ALL
    SELECT 'CDO',                             'SECURITIZED',                     'Collateralised debt obligation'                                   FROM DUAL UNION ALL
    SELECT 'CoveredBond',                     'SECURITIZED',                     'Covered bond'                                                     FROM DUAL UNION ALL
    SELECT 'Future',                          'DERIVATIVE',                      'Exchange-traded future (generic)'                                 FROM DUAL UNION ALL
    SELECT 'InterestRateFuture',              'DERIVATIVE',                      'Interest rate future'                                             FROM DUAL UNION ALL
    SELECT 'EquityFuture',                    'DERIVATIVE',                      'Equity or index future'                                           FROM DUAL UNION ALL
    SELECT 'Option',                          'DERIVATIVE',                      'Generic option'                                                   FROM DUAL UNION ALL
    SELECT 'EquityOption',                    'DERIVATIVE',                      'Option on single stock or index'                                  FROM DUAL UNION ALL
    SELECT 'BondOption',                      'DERIVATIVE',                      'Option on bond or future'                                         FROM DUAL UNION ALL
    SELECT 'FXOption',                        'DERIVATIVE',                      'FX option'                                                        FROM DUAL UNION ALL
    SELECT 'Swap',                            'DERIVATIVE',                      'Generic swap'                                                     FROM DUAL UNION ALL
    SELECT 'InterestRateSwap',                'DERIVATIVE',                      'Fixed-float interest rate swap'                                   FROM DUAL UNION ALL
    SELECT 'BasisSwap',                       'DERIVATIVE',                      'Float-float basis swap'                                           FROM DUAL UNION ALL
    SELECT 'CrossCurrencySwap',               'DERIVATIVE',                      'Cross-currency swap'                                              FROM DUAL UNION ALL
    SELECT 'CDS',                             'DERIVATIVE',                      'Credit default swap'                                              FROM DUAL UNION ALL
    SELECT 'TotalReturnSwap',                 'DERIVATIVE',                      'Total return swap'                                                FROM DUAL UNION ALL
    SELECT 'FXSwap',                          'DERIVATIVE',                      'FX swap / forward-forward'                                        FROM DUAL UNION ALL
    SELECT 'Forward',                         'DERIVATIVE',                      'Generic forward (non-listed)'                                     FROM DUAL UNION ALL
    SELECT 'Equity',                          'EQUITY',                          'Common stock'                                                     FROM DUAL UNION ALL
    SELECT 'PreferredEquity',                 'EQUITY',                          'Preferred / preference shares'                                    FROM DUAL UNION ALL
    SELECT 'DepositaryReceipt',               'EQUITY',                          'ADR / GDR'                                                        FROM DUAL UNION ALL
    SELECT 'Warrant',                         'EQUITY',                          'Equity warrant'                                                   FROM DUAL UNION ALL
    SELECT 'Right',                           'EQUITY',                          'Subscription right'                                               FROM DUAL UNION ALL
    SELECT 'MutualFund',                      'FUND',                            'Open-ended fund'                                                  FROM DUAL UNION ALL
    SELECT 'ExchangeTradedFund',              'FUND',                            'Exchange-traded fund (ETF)'                                       FROM DUAL UNION ALL
    SELECT 'HedgeFund',                       'FUND',                            'Hedge fund share class'                                           FROM DUAL UNION ALL
    SELECT 'PooledVehicle',                   'FUND',                            'Other pooled investment vehicle'                                  FROM DUAL UNION ALL
    SELECT 'MoneyMarketFund',                 'MONEY_MARKET',                    'Money market fund share'                                          FROM DUAL UNION ALL
    SELECT 'TreasuryBill',                    'MONEY_MARKET',                    'T-bill / short-dated sovereign note'                              FROM DUAL UNION ALL
    SELECT 'Repo',                            'MONEY_MARKET',                    'Repurchase agreement'                                             FROM DUAL UNION ALL
    SELECT 'Deposit',                         'MONEY_MARKET',                    'Term or call deposit'                                             FROM DUAL UNION ALL
    SELECT 'FXSpot',                          'FX',                              'FX spot'                                                          FROM DUAL UNION ALL
    SELECT 'FXForward',                       'FX',                              'FX forward'                                                       FROM DUAL UNION ALL
    SELECT 'FXNDF',                           'FX',                              'Non-deliverable FX forward'                                       FROM DUAL UNION ALL
    SELECT 'CommoditySpot',                   'COMMODITY',                       'Physical commodity spot'                                          FROM DUAL UNION ALL
    SELECT 'CommodityFuture',                 'COMMODITY',                       'Commodity future'                                                 FROM DUAL UNION ALL
    SELECT 'CommoditySwap',                   'COMMODITY',                       'Swap on commodity index or price'                                 FROM DUAL UNION ALL
    SELECT 'Index',                           'OTHER',                           'Benchmark index (non-tradable)'                                   FROM DUAL UNION ALL
    SELECT 'CustomStructuredProduct',         'OTHER',                           'Bank-issued structured note / product'                            FROM DUAL UNION ALL
    SELECT 'Other',                           'OTHER',                           'Catch-all for unclassified types'                                 FROM DUAL
) AS v
WHERE NOT EXISTS (SELECT 1 FROM `instrument_type_ref` WHERE `code` = v.code)
ON DUPLICATE KEY UPDATE `description` = VALUES(`description`);

-- ====================================================================
-- FormulaMacros
-- ====================================================================
INSERT INTO `formula_macro` (`id`, `name`, `expression`, `description`, `scope`,
    `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DebtScore',
    'Normalize([debtToEquity], 0.0, 8.0, 1.0, 21.0)',
    'Scores debt burden: lower D/E ? lower (better) score',
    'Fundamental',
    UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31 00:00:00', UTC_TIMESTAMP(6), '9999-12-31 00:00:00', 1, 0
WHERE NOT EXISTS (
    SELECT 1 FROM `formula_macro` WHERE `name` = 'DebtScore' AND `is_current` = 1 AND `is_deleted` = 0
);

INSERT INTO `formula_macro` (`id`, `name`, `expression`, `description`, `scope`,
    `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'CoverageScore',
    'Normalize([interestCoverageRatio], 15.0, 0.5, 1.0, 21.0)',
    'Scores interest coverage: higher coverage ? lower (better) score',
    'Fundamental',
    UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31 00:00:00', UTC_TIMESTAMP(6), '9999-12-31 00:00:00', 1, 0
WHERE NOT EXISTS (
    SELECT 1 FROM `formula_macro` WHERE `name` = 'CoverageScore' AND `is_current` = 1 AND `is_deleted` = 0
);

INSERT INTO `formula_macro` (`id`, `name`, `expression`, `description`, `scope`,
    `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'VendorQualityWeight',
    '[quality] * Normalize([priceDeviation], 0.0, 0.1, 1.0, 0.1)',
    'Weights vendor price by quality score and deviation band',
    'VPM',
    UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31 00:00:00', UTC_TIMESTAMP(6), '9999-12-31 00:00:00', 1, 0
WHERE NOT EXISTS (
    SELECT 1 FROM `formula_macro` WHERE `name` = 'VendorQualityWeight' AND `is_current` = 1 AND `is_deleted` = 0
);

INSERT INTO `formula_macro` (`id`, `name`, `expression`, `description`, `scope`,
    `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SpreadConfidence',
    'Normalize(([ask] - [bid]) / [mid], 0.0, 0.10, 1.0, 0.0)',
    'Measures bid/ask spread as a confidence proxy; tighter ? more confident',
    'MICR',
    UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31 00:00:00', UTC_TIMESTAMP(6), '9999-12-31 00:00:00', 1, 0
WHERE NOT EXISTS (
    SELECT 1 FROM `formula_macro` WHERE `name` = 'SpreadConfidence' AND `is_current` = 1 AND `is_deleted` = 0
);

INSERT INTO `formula_macro` (`id`, `name`, `expression`, `description`, `scope`,
    `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'MacroRiskScore',
    'Normalize(RecessionRisk([gdpGrowth], [unemploymentRate]), -5.0, 5.0, 1.0, 21.0)',
    'Combines GDP growth and unemployment into a macro risk score',
    'Macro',
    UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31 00:00:00', UTC_TIMESTAMP(6), '9999-12-31 00:00:00', 1, 0
WHERE NOT EXISTS (
    SELECT 1 FROM `formula_macro` WHERE `name` = 'MacroRiskScore' AND `is_current` = 1 AND `is_deleted` = 0
);

-- ====================================================================
-- RatingScaleEntries
-- ====================================================================

-- S&P
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP',  1, 'AAA',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=1  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP',  2, 'AA+',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=2  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP',  3, 'AA',   1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=3  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP',  4, 'AA-',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=4  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP',  5, 'A+',   1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=5  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP',  6, 'A',    1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=6  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP',  7, 'A-',   1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=7  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP',  8, 'BBB+', 1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=8  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP',  9, 'BBB',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=9  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP', 10, 'BBB-', 1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=10 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP', 11, 'BB+',  0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=11 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP', 12, 'BB',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=12 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP', 13, 'BB-',  0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=13 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP', 14, 'B+',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=14 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP', 15, 'B',    0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=15 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP', 16, 'B-',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=16 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP', 17, 'CCC+', 0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=17 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP', 18, 'CCC',  0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=18 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP', 19, 'CCC-', 0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=19 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP', 20, 'CC',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=20 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'SP', 21, 'D',    0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='SP' AND `score`=21 AND `is_current`=1 AND `is_deleted`=0);

-- Moody's
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys',  1, 'Aaa',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=1  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys',  2, 'Aa1',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=2  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys',  3, 'Aa2',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=3  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys',  4, 'Aa3',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=4  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys',  5, 'A1',   1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=5  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys',  6, 'A2',   1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=6  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys',  7, 'A3',   1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=7  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys',  8, 'Baa1', 1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=8  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys',  9, 'Baa2', 1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=9  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys', 10, 'Baa3', 1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=10 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys', 11, 'Ba1',  0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=11 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys', 12, 'Ba2',  0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=12 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys', 13, 'Ba3',  0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=13 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys', 14, 'B1',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=14 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys', 15, 'B2',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=15 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys', 16, 'B3',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=16 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys', 17, 'Caa1', 0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=17 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys', 18, 'Caa2', 0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=18 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys', 19, 'Caa3', 0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=19 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys', 20, 'Ca',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=20 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Moodys', 21, 'C',    0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Moodys' AND `score`=21 AND `is_current`=1 AND `is_deleted`=0);

-- Fitch
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch',  1, 'AAA',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=1  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch',  2, 'AA+',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=2  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch',  3, 'AA',   1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=3  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch',  4, 'AA-',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=4  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch',  5, 'A+',   1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=5  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch',  6, 'A',    1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=6  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch',  7, 'A-',   1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=7  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch',  8, 'BBB+', 1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=8  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch',  9, 'BBB',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=9  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch', 10, 'BBB-', 1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=10 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch', 11, 'BB+',  0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=11 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch', 12, 'BB',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=12 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch', 13, 'BB-',  0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=13 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch', 14, 'B+',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=14 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch', 15, 'B',    0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=15 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch', 16, 'B-',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=16 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch', 17, 'CCC',  0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=17 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch', 18, 'CC',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=18 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch', 19, 'C',    0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=19 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch', 20, 'RD',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=20 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Fitch', 21, 'D',    0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Fitch' AND `score`=21 AND `is_current`=1 AND `is_deleted`=0);

-- DBRS
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS',  1, 'AAA',     1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=1  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS',  2, 'AA (h)',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=2  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS',  3, 'AA',      1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=3  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS',  4, 'AA (l)',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=4  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS',  5, 'A (h)',   1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=5  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS',  6, 'A',       1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=6  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS',  7, 'A (l)',   1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=7  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS',  8, 'BBB (h)', 1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=8  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS',  9, 'BBB',     1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=9  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS', 10, 'BBB (l)', 1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=10 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS', 11, 'BB (h)',  0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=11 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS', 12, 'BB',      0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=12 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS', 13, 'BB (l)',  0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=13 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS', 14, 'B (h)',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=14 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS', 15, 'B',       0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=15 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS', 16, 'B (l)',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=16 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS', 17, 'CCC (h)', 0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=17 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS', 18, 'CCC',     0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=18 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS', 19, 'CCC (l)', 0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=19 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS', 20, 'CC',      0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=20 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'DBRS', 21, 'D',       0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='DBRS' AND `score`=21 AND `is_current`=1 AND `is_deleted`=0);

-- Kroll
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll',  1, 'AAA',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=1  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll',  2, 'AA+',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=2  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll',  3, 'AA',   1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=3  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll',  4, 'AA-',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=4  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll',  5, 'A+',   1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=5  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll',  6, 'A',    1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=6  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll',  7, 'A-',   1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=7  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll',  8, 'BBB+', 1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=8  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll',  9, 'BBB',  1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=9  AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll', 10, 'BBB-', 1, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=10 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll', 11, 'BB+',  0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=11 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll', 12, 'BB',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=12 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll', 13, 'BB-',  0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=13 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll', 14, 'B+',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=14 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll', 15, 'B',    0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=15 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll', 16, 'B-',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=16 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll', 17, 'CCC+', 0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=17 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll', 18, 'CCC',  0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=18 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll', 19, 'CCC-', 0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=19 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll', 20, 'CC',   0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=20 AND `is_current`=1 AND `is_deleted`=0);
INSERT INTO `rating_scale_entry` (`id`, `agency`, `score`, `label`, `is_investment_grade`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'Kroll', 21, 'D',    0, UTC_TIMESTAMP(6), UTC_TIMESTAMP(6), '9999-12-31', UTC_TIMESTAMP(6), '9999-12-31', 1, 0 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_scale_entry` WHERE `agency`='Kroll' AND `score`=21 AND `is_current`=1 AND `is_deleted`=0);

-- ====================================================================
-- RatingDerivationRules
-- ====================================================================
INSERT INTO `rating_derivation_rule` (`id`, `model_name`, `security_type`, `config_json`, `description`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'micr', NULL, '{}', 'Market-Implied Credit Rating: derives score from observed market spread',
    UTC_TIMESTAMP(6), '2000-01-01 00:00:00', '9999-12-31 00:00:00', UTC_TIMESTAMP(6), '9999-12-31 00:00:00', 1, 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_derivation_rule` WHERE `model_name`='micr' AND `security_type` IS NULL AND `is_current`=1 AND `is_deleted`=0);

INSERT INTO `rating_derivation_rule` (`id`, `model_name`, `security_type`, `config_json`, `description`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'vpm', NULL, '{}', 'Vendor Price Model: aggregates weighted vendor prices into a composite rating',
    UTC_TIMESTAMP(6), '2000-01-01 00:00:00', '9999-12-31 00:00:00', UTC_TIMESTAMP(6), '9999-12-31 00:00:00', 1, 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_derivation_rule` WHERE `model_name`='vpm' AND `security_type` IS NULL AND `is_current`=1 AND `is_deleted`=0);

INSERT INTO `rating_derivation_rule` (`id`, `model_name`, `security_type`, `config_json`, `description`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'fundamental', NULL, '{}', 'Fundamental Model: derives rating from balance-sheet and income-statement ratios',
    UTC_TIMESTAMP(6), '2000-01-01 00:00:00', '9999-12-31 00:00:00', UTC_TIMESTAMP(6), '9999-12-31 00:00:00', 1, 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_derivation_rule` WHERE `model_name`='fundamental' AND `security_type` IS NULL AND `is_current`=1 AND `is_deleted`=0);

INSERT INTO `rating_derivation_rule` (`id`, `model_name`, `security_type`, `config_json`, `description`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'composite', NULL, '{}', 'Composite Model: blends MICR, VPM, and fundamental scores with equal weights',
    UTC_TIMESTAMP(6), '2024-01-01 00:00:00', '9999-12-31 00:00:00', UTC_TIMESTAMP(6), '9999-12-31 00:00:00', 1, 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_derivation_rule` WHERE `model_name`='composite' AND `security_type` IS NULL AND `is_current`=1 AND `is_deleted`=0);

INSERT INTO `rating_derivation_rule` (`id`, `model_name`, `security_type`, `config_json`, `description`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'composite', 'Bond', '{}', 'Composite Model for plain bonds: applies bond-specific blending weights',
    UTC_TIMESTAMP(6), '2026-01-01 00:00:00', '9999-12-31 00:00:00', UTC_TIMESTAMP(6), '9999-12-31 00:00:00', 1, 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_derivation_rule` WHERE `model_name`='composite' AND `security_type`='Bond' AND `is_current`=1 AND `is_deleted`=0);

INSERT INTO `rating_derivation_rule` (`id`, `model_name`, `security_type`, `config_json`, `description`, `created_at`, `valid_from`, `valid_to`, `system_from`, `system_to`, `is_current`, `is_deleted`)
SELECT UUID(), 'composite', 'CorporateBond', '{}', 'Composite Model for corporate bonds: applies credit-spread and leverage adjustments',
    UTC_TIMESTAMP(6), '2026-01-01 00:00:00', '9999-12-31 00:00:00', UTC_TIMESTAMP(6), '9999-12-31 00:00:00', 1, 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `rating_derivation_rule` WHERE `model_name`='composite' AND `security_type`='CorporateBond' AND `is_current`=1 AND `is_deleted`=0);

-- ====================================================================
-- Record this script
-- ====================================================================
INSERT IGNORE INTO `__SchemaVersions` (`version`, `description`)
VALUES ('1.0-seed', 'Initial seed data � FormulaMacros, RatingScaleEntries, RatingDerivationRules');

-- ====================================================================
-- Import Profiles seed data
-- ====================================================================

-- -- 1. Default CSV profile (FlatFile) --------------------------------
SET @existing_flat = (SELECT `id` FROM `import_profile` WHERE `name` = 'Default' AND `source_type` = 'FlatFile' LIMIT 1);

INSERT INTO `import_profile`
    (`id`, `name`, `description`, `source_type`, `file_pattern`, `folder`,
     `delimiter`, `text_qualifier`, `has_header`, `skip_rows`, `is_active`, `created_at`)
SELECT UUID(), 'Default',
    'Catch-all CSV profile; matches any *.csv not claimed by a named profile.',
    'FlatFile', '*.csv', '', ',', '"', 1, 0, 1, NOW()
FROM DUAL WHERE @existing_flat IS NULL;

SET @flat_id = (SELECT `id` FROM `import_profile` WHERE `name` = 'Default' AND `source_type` = 'FlatFile' LIMIT 1);

INSERT INTO `import_profile_column`
    (`id`, `profile_id`, `source_column`, `target_field`, `sort_order`, `created_at`)
SELECT UUID(), @flat_id, 'Symbol',         'symbol',          0,  NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @flat_id, 'Name',           'name',            1,  NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @flat_id, 'SecurityType',   'securitytype',    2,  NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @flat_id, 'ISIN',           'identifiervalue', 3,  NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @flat_id, 'CUSIP',          'cusip',           4,  NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @flat_id, 'Currency',       'currency',        5,  NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @flat_id, 'CouponRate',     'couponrate',      6,  NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @flat_id, 'MaturityDate',   'maturitydate',    7,  NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @flat_id, 'IssuerName',     'issuername',      8,  NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @flat_id, 'Country',        'country',         9,  NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @flat_id, 'Exchange',       'exchange',        10, NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @flat_id, 'Sector',         'sector',          11, NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @flat_id, 'IdentifierType', 'identifiertype',  12, NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @flat_id, 'DataSource',     'datasource',      13, NOW() FROM DUAL WHERE @existing_flat IS NULL;

SET @sym_col     = (SELECT `id` FROM `import_profile_column` WHERE `profile_id` = @flat_id AND `target_field` = 'symbol'          LIMIT 1);
SET @sectype_col = (SELECT `id` FROM `import_profile_column` WHERE `profile_id` = @flat_id AND `target_field` = 'securitytype'    LIMIT 1);
SET @coupon_col  = (SELECT `id` FROM `import_profile_column` WHERE `profile_id` = @flat_id AND `target_field` = 'couponrate'      LIMIT 1);
SET @maturity_col = (SELECT `id` FROM `import_profile_column` WHERE `profile_id` = @flat_id AND `target_field` = 'maturitydate'   LIMIT 1);
SET @isin_col    = (SELECT `id` FROM `import_profile_column` WHERE `profile_id` = @flat_id AND `target_field` = 'identifiervalue' LIMIT 1);

INSERT INTO `import_profile_column_validation`
    (`id`, `column_id`, `rule_type`, `rule_value`, `condition`, `error_message`, `severity`, `is_active`, `created_at`)
SELECT UUID(), @sym_col,     'Required',      NULL, NULL, 'Symbol is required.', 'Error', 1, NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @sectype_col, 'Required',      NULL, NULL, 'SecurityType is required.', 'Error', 1, NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @sectype_col, 'AllowedValues', 'Equity,Bond,CorporateBond,GovernmentBond,MunicipalBond,ETF,MutualFund,Derivative,Future,Option,Swap,Other',
    NULL, 'Unknown SecurityType value.', 'Warning', 1, NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @coupon_col,  'MinValue',  '0',
    '[securitytype] == ''Bond'' or [securitytype] == ''CorporateBond'' or [securitytype] == ''GovernmentBond''',
    'CouponRate must be >= 0 for bond instruments.', 'Warning', 1, NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @coupon_col,  'MaxValue',  '100',
    '[securitytype] == ''Bond'' or [securitytype] == ''CorporateBond'' or [securitytype] == ''GovernmentBond''',
    'CouponRate > 100 is unusual � please verify.', 'Warning', 1, NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @maturity_col, 'DateFormat', 'yyyy-MM-dd',
    '[securitytype] == ''Bond'' or [securitytype] == ''CorporateBond'' or [securitytype] == ''GovernmentBond''',
    'MaturityDate must be in yyyy-MM-dd format for bond instruments.', 'Warning', 1, NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @isin_col,    'Regex', '^[A-Z]{2}[A-Z0-9]{10}$',
    NULL, 'ISIN does not match the standard format (e.g. US0231351067).', 'Warning', 1, NOW() FROM DUAL WHERE @existing_flat IS NULL;

INSERT INTO `import_profile_row_validation`
    (`id`, `profile_id`, `expression`, `error_message`, `severity`, `sort_order`, `is_active`, `created_at`)
SELECT UUID(), @flat_id,
    'not ([securitytype] == ''Bond'' or [securitytype] == ''CorporateBond'' or [securitytype] == ''GovernmentBond'') or not string.IsNullOrEmpty([maturitydate])',
    'Bond instruments must have a MaturityDate.', 'Warning', 0, 1, NOW() FROM DUAL WHERE @existing_flat IS NULL UNION ALL
SELECT UUID(), @flat_id,
    '[symbol] != ''''',
    'Symbol must not be blank.', 'Error', 1, 1, NOW() FROM DUAL WHERE @existing_flat IS NULL;

-- -- 2. Default JSON profile -------------------------------------------
SET @existing_json = (SELECT `id` FROM `import_profile` WHERE `name` = 'Default' AND `source_type` = 'JsonFile' LIMIT 1);

INSERT INTO `import_profile`
    (`id`, `name`, `description`, `source_type`, `file_pattern`, `folder`, `records_path`, `is_active`, `created_at`)
SELECT UUID(), 'Default', 'Default JSON import profile; reads a root-level array ($[*]).',
    'JsonFile', '*.json', '', '$[*]', 1, NOW()
FROM DUAL WHERE @existing_json IS NULL;

SET @json_id = (SELECT `id` FROM `import_profile` WHERE `name` = 'Default' AND `source_type` = 'JsonFile' LIMIT 1);

INSERT INTO `import_profile_column`
    (`id`, `profile_id`, `source_column`, `target_field`, `sort_order`, `created_at`)
SELECT UUID(), @json_id, 'symbol',         'symbol',          0,  NOW() FROM DUAL WHERE @existing_json IS NULL UNION ALL
SELECT UUID(), @json_id, 'name',           'name',            1,  NOW() FROM DUAL WHERE @existing_json IS NULL UNION ALL
SELECT UUID(), @json_id, 'securityType',   'securitytype',    2,  NOW() FROM DUAL WHERE @existing_json IS NULL UNION ALL
SELECT UUID(), @json_id, 'isin',           'identifiervalue', 3,  NOW() FROM DUAL WHERE @existing_json IS NULL UNION ALL
SELECT UUID(), @json_id, 'currency',       'currency',        4,  NOW() FROM DUAL WHERE @existing_json IS NULL UNION ALL
SELECT UUID(), @json_id, 'couponRate',     'couponrate',      5,  NOW() FROM DUAL WHERE @existing_json IS NULL UNION ALL
SELECT UUID(), @json_id, 'maturityDate',   'maturitydate',    6,  NOW() FROM DUAL WHERE @existing_json IS NULL UNION ALL
SELECT UUID(), @json_id, 'issuerName',     'issuername',      7,  NOW() FROM DUAL WHERE @existing_json IS NULL UNION ALL
SELECT UUID(), @json_id, 'identifierType', 'identifiertype',  8,  NOW() FROM DUAL WHERE @existing_json IS NULL;

SET @json_sym_col = (SELECT `id` FROM `import_profile_column` WHERE `profile_id` = @json_id AND `target_field` = 'symbol' LIMIT 1);
INSERT INTO `import_profile_column_validation`
    (`id`, `column_id`, `rule_type`, `rule_value`, `condition`, `error_message`, `severity`, `is_active`, `created_at`)
SELECT UUID(), @json_sym_col, 'Required', NULL, NULL, 'Symbol is required.', 'Error', 1, NOW()
FROM DUAL WHERE @existing_json IS NULL;

-- -- 3. Default XML profile --------------------------------------------
SET @existing_xml = (SELECT `id` FROM `import_profile` WHERE `name` = 'Default' AND `source_type` = 'XmlFile' LIMIT 1);

INSERT INTO `import_profile`
    (`id`, `name`, `description`, `source_type`, `file_pattern`, `folder`, `records_x_path`, `is_active`, `created_at`)
SELECT UUID(), 'Default', 'Default XML import profile; selects //Security elements.',
    'XmlFile', '*.xml', '', '//Security', 1, NOW()
FROM DUAL WHERE @existing_xml IS NULL;

SET @xml_id = (SELECT `id` FROM `import_profile` WHERE `name` = 'Default' AND `source_type` = 'XmlFile' LIMIT 1);

INSERT INTO `import_profile_column`
    (`id`, `profile_id`, `source_column`, `target_field`, `sort_order`, `created_at`)
SELECT UUID(), @xml_id, 'Symbol',         'symbol',          0,  NOW() FROM DUAL WHERE @existing_xml IS NULL UNION ALL
SELECT UUID(), @xml_id, 'Name',           'name',            1,  NOW() FROM DUAL WHERE @existing_xml IS NULL UNION ALL
SELECT UUID(), @xml_id, 'SecurityType',   'securitytype',    2,  NOW() FROM DUAL WHERE @existing_xml IS NULL UNION ALL
SELECT UUID(), @xml_id, 'ISIN',           'identifiervalue', 3,  NOW() FROM DUAL WHERE @existing_xml IS NULL UNION ALL
SELECT UUID(), @xml_id, 'Currency',       'currency',        4,  NOW() FROM DUAL WHERE @existing_xml IS NULL UNION ALL
SELECT UUID(), @xml_id, 'CouponRate',     'couponrate',      5,  NOW() FROM DUAL WHERE @existing_xml IS NULL UNION ALL
SELECT UUID(), @xml_id, 'MaturityDate',   'maturitydate',    6,  NOW() FROM DUAL WHERE @existing_xml IS NULL UNION ALL
SELECT UUID(), @xml_id, 'IdentifierType', 'identifiertype',  7,  NOW() FROM DUAL WHERE @existing_xml IS NULL;

SET @xml_sym_col = (SELECT `id` FROM `import_profile_column` WHERE `profile_id` = @xml_id AND `target_field` = 'symbol' LIMIT 1);
INSERT INTO `import_profile_column_validation`
    (`id`, `column_id`, `rule_type`, `rule_value`, `condition`, `error_message`, `severity`, `is_active`, `created_at`)
SELECT UUID(), @xml_sym_col, 'Required', NULL, NULL, 'Symbol is required.', 'Error', 1, NOW()
FROM DUAL WHERE @existing_xml IS NULL;

INSERT IGNORE INTO `__SchemaVersions` (`version`, `description`)
VALUES ('1.1-seed', 'ImportProfile seed data � Default profiles for FlatFile, JsonFile, XmlFile');

SELECT 'SecurityApp seed data loaded successfully.' AS status;

-- ====================================================================
-- Currencies -- ISO 4217
-- ====================================================================
SELECT 'Seeding currencies...' AS status;
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('AED','784','UAE Dirham','Ø¯.Ø¥',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('AFN','971','Afghan Afghani','Ø‹',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('ALL','008','Albanian Lek','L',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('AMD','051','Armenian Dram','Ö',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('ANG','532','Netherlands Antillean Guilder','Æ’',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('AOA','973','Angolan Kwanza','Kz',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('ARS','032','Argentine Peso','$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('AUD','036','Australian Dollar','A$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('AWG','533','Aruban Florin','Æ’',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('AZN','944','Azerbaijani Manat','â‚¼',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('BAM','977','Bosnia-Herzegovina Convertible Mark','KM',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('BBD','052','Barbadian Dollar','Bds$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('BDT','050','Bangladeshi Taka','à§³',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('BGN','975','Bulgarian Lev','Ð»Ð²',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('BHD','048','Bahraini Dinar','BD',3,3,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('BIF','108','Burundian Franc','Fr',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('BMD','060','Bermudian Dollar','BD$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('BND','096','Brunei Dollar','B$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('BOB','068','Bolivian Boliviano','Bs.',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('BRL','986','Brazilian Real','R$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('BSD','044','Bahamian Dollar','B$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('BTN','064','Bhutanese Ngultrum','Nu',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('BWP','072','Botswanan Pula','P',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('BYN','933','Belarusian Ruble','Br',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('BZD','084','Belize Dollar','BZ$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('CAD','124','Canadian Dollar','CA$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('CDF','976','Congolese Franc','FC',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('CHF','756','Swiss Franc','Fr',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('CLP','152','Chilean Peso','CLP$',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('CNY','156','Chinese Yuan','Â¥',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('COP','170','Colombian Peso','COL$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('CRC','188','Costa Rican ColÃ³n','â‚¡',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('CUP','192','Cuban Peso','â‚±',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('CVE','132','Cape Verdean Escudo','$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('CZK','203','Czech Koruna','KÄ',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('DJF','262','Djiboutian Franc','Fdj',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('DKK','208','Danish Krone','kr',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('DOP','214','Dominican Peso','RD$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('DZD','012','Algerian Dinar','Ø¯Ø¬',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('EGP','818','Egyptian Pound','EÂ£',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('ERN','232','Eritrean Nakfa','Nfk',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('ETB','230','Ethiopian Birr','Br',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('EUR','978','Euro','â‚¬',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('FJD','242','Fijian Dollar','FJ$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('FKP','238','Falkland Islands Pound','Â£',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('GBP','826','British Pound Sterling','Â£',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('GEL','981','Georgian Lari','â‚¾',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('GHS','936','Ghanaian Cedi','â‚µ',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('GIP','292','Gibraltar Pound','Â£',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('GMD','270','Gambian Dalasi','D',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('GNF','324','Guinean Franc','FG',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('GTQ','320','Guatemalan Quetzal','Q',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('GYD','328','Guyanaese Dollar','G$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('HKD','344','Hong Kong Dollar','HK$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('HNL','340','Honduran Lempira','L',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('HTG','332','Haitian Gourde','G',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('HUF','348','Hungarian Forint','Ft',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('IDR','360','Indonesian Rupiah','Rp',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('ILS','376','Israeli New Shekel','â‚ª',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('INR','356','Indian Rupee','â‚¹',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('IQD','368','Iraqi Dinar','Ø¹.Ø¯',3,3,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('IRR','364','Iranian Rial','ï·¼',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('ISK','352','Icelandic KrÃ³na','kr',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('JMD','388','Jamaican Dollar','J$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('JOD','400','Jordanian Dinar','JD',3,3,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('JPY','392','Japanese Yen','Â¥',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('KES','404','Kenyan Shilling','KSh',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('KGS','417','Kyrgystani Som','Ð»Ð²',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('KHR','116','Cambodian Riel','áŸ›',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('KMF','174','Comorian Franc','CF',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('KPW','408','North Korean Won','â‚©',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('KRW','410','South Korean Won','â‚©',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('KWD','414','Kuwaiti Dinar','KD',3,3,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('KYD','136','Cayman Islands Dollar','CI$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('KZT','398','Kazakhstani Tenge','â‚¸',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('LAK','418','Laotian Kip','â‚­',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('LBP','422','Lebanese Pound','Ù„.Ù„',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('LKR','144','Sri Lankan Rupee','Rs',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('LRD','430','Liberian Dollar','L$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('LSL','426','Lesotho Loti','L',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('LYD','434','Libyan Dinar','LD',3,3,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('MAD','504','Moroccan Dirham','MAD',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('MDL','498','Moldovan Leu','L',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('MGA','969','Malagasy Ariary','Ar',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('MKD','807','Macedonian Denar','Ð´ÐµÐ½',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('MMK','104','Myanmar Kyat','K',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('MNT','496','Mongolian TÃ¶grÃ¶g','â‚®',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('MOP','446','Macanese Pataca','P',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('MRU','929','Mauritanian Ouguiya','UM',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('MUR','480','Mauritian Rupee','Rs',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('MVR','462','Maldivian Rufiyaa','Rf',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('MWK','454','Malawian Kwacha','MK',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('MXN','484','Mexican Peso','Mex$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('MYR','458','Malaysian Ringgit','RM',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('MZN','943','Mozambican Metical','MT',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('NAD','516','Namibian Dollar','N$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('NGN','566','Nigerian Naira','â‚¦',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('NIO','558','Nicaraguan CÃ³rdoba','C$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('NOK','578','Norwegian Krone','kr',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('NPR','524','Nepalese Rupee','Rs',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('NZD','554','New Zealand Dollar','NZ$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('OMR','512','Omani Rial','Ø±.Ø¹.',3,3,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('PAB','590','Panamanian Balboa','B/.',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('PEN','604','Peruvian Sol','S/.',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('PGK','598','Papua New Guinean Kina','K',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('PHP','608','Philippine Peso','â‚±',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('PKR','586','Pakistani Rupee','Rs',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('PLN','985','Polish Zloty','zÅ‚',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('PYG','600','Paraguayan Guarani','â‚²',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('QAR','634','Qatari Riyal','QR',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('RON','946','Romanian Leu','lei',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('RSD','941','Serbian Dinar','din',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('RUB','643','Russian Ruble','â‚½',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('RWF','646','Rwandan Franc','RF',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('SAR','682','Saudi Riyal','SR',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('SBD','090','Solomon Islands Dollar','SI$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('SCR','690','Seychellois Rupee','Rs',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('SDG','938','Sudanese Pound','Ø¬.Ø³.',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('SEK','752','Swedish Krona','kr',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('SGD','702','Singapore Dollar','S$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('SHP','654','Saint Helena Pound','Â£',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('SLE','925','Sierra Leonean Leone','Le',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('SOS','706','Somali Shilling','Sh',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('SRD','968','Surinamese Dollar','$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('SSP','728','South Sudanese Pound','Â£',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('STN','930','SÃ£o TomÃ© and PrÃ­ncipe Dobra','Db',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('SVC','222','Salvadoran ColÃ³n','â‚¡',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('SYP','760','Syrian Pound','Â£S',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('SZL','748','Swazi Lilangeni','L',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('THB','764','Thai Baht','à¸¿',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('TJS','972','Tajikistani Somoni','SM',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('TMT','934','Turkmenistani Manat','T',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('TND','788','Tunisian Dinar','DT',3,3,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('TOP','776','Tongan PaÊ»anga','T$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('TRY','949','Turkish Lira','â‚º',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('TTD','780','Trinidad and Tobago Dollar','TT$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('TWD','901','New Taiwan Dollar','NT$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('TZS','834','Tanzanian Shilling','Sh',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('UAH','980','Ukrainian Hryvnia','â‚´',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('UGX','800','Ugandan Shilling','USh',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('USD','840','US Dollar','$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('UYU','858','Uruguayan Peso','$U',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('UZS','860','Uzbekistani Sum','Ð»Ð²',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('VES','928','Venezuelan BolÃ­var Soberano','Bs.S',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('VND','704','Vietnamese Dong','â‚«',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('VUV','548','Vanuatu Vatu','VT',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('WST','882','Samoan Tala','T',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('XAF','950','Central African CFA Franc','Fr',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('XCD','951','East Caribbean Dollar','EC$',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('XOF','952','West African CFA Franc','Fr',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('XPF','953','CFP Franc','Fr',0,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('YER','886','Yemeni Rial','ï·¼',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('ZAR','710','South African Rand','R',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('ZMW','967','Zambian Kwacha','ZK',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('ZWG','924','Zimbabwe Gold','ZiG',2,2,'FIAT',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('XDR','960','IMF Special Drawing Rights','SDR',0,2,'OTHER',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('XAU','959','Gold (troy ounce)','XAU',4,4,'COMMODITY',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('XAG','961','Silver (troy ounce)','XAG',4,4,'COMMODITY',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('USDT',NULL,'Tether','â‚®',6,6,'CRYPTO',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('USDC',NULL,'USD Coin','USDC',6,6,'CRYPTO',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('DOGE',NULL,'Dogecoin','Ã',8,8,'CRYPTO',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('AVAX',NULL,'Avalanche','AVAX',18,8,'CRYPTO',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('LINK',NULL,'Chainlink','LINK',18,8,'CRYPTO',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('MATIC',NULL,'Polygon','MATIC',18,8,'CRYPTO',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('ALGO',NULL,'Algorand','ALGO',6,6,'CRYPTO',1);
INSERT IGNORE INTO `currency` (`code`,`numeric_code`,`name`,`symbol`,`decimals`,`display_decimals`,`currency_type`,`is_active`) VALUES ('ATOM',NULL,'Cosmos','ATOM',6,6,'CRYPTO',1);
SELECT 'Currencies seeded.' AS status;

-- ====================================================================
-- Countries -- ISO 3166-1
-- ====================================================================
SELECT 'Seeding countries...' AS status;
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AF','AFG','004','Afghanistan','.af');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AX','ALA','248','Ã…land Islands','.ax');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AL','ALB','008','Albania','.al');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('DZ','DZA','012','Algeria','.dz');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AS','ASM','016','American Samoa','.as');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AD','AND','020','Andorra','.ad');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AO','AGO','024','Angola','.ao');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AI','AIA','660','Anguilla','.ai');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AQ','ATA','010','Antarctica','.aq');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AG','ATG','028','Antigua and Barbuda','.ag');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AR','ARG','032','Argentina','.ar');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AM','ARM','051','Armenia','.am');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AW','ABW','533','Aruba','.aw');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AU','AUS','036','Australia','.au');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AT','AUT','040','Austria','.at');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AZ','AZE','031','Azerbaijan','.az');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BS','BHS','044','Bahamas','.bs');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BH','BHR','048','Bahrain','.bh');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BD','BGD','050','Bangladesh','.bd');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BB','BRB','052','Barbados','.bb');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BY','BLR','112','Belarus','.by');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BE','BEL','056','Belgium','.be');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BZ','BLZ','084','Belize','.bz');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BJ','BEN','204','Benin','.bj');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BM','BMU','060','Bermuda','.bm');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BT','BTN','064','Bhutan','.bt');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BO','BOL','068','Bolivia','.bo');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BQ','BES','535','Bonaire, Sint Eustatius and Saba','.bq');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BA','BIH','070','Bosnia and Herzegovina','.ba');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BW','BWA','072','Botswana','.bw');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BV','BVT','074','Bouvet Island',NULL);
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BR','BRA','076','Brazil','.br');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('IO','IOT','086','British Indian Ocean Territory','.io');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BN','BRN','096','Brunei Darussalam','.bn');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BG','BGR','100','Bulgaria','.bg');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BF','BFA','854','Burkina Faso','.bf');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BI','BDI','108','Burundi','.bi');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CV','CPV','132','Cabo Verde','.cv');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('KH','KHM','116','Cambodia','.kh');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CM','CMR','120','Cameroon','.cm');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CA','CAN','124','Canada','.ca');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('KY','CYM','136','Cayman Islands','.ky');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CF','CAF','140','Central African Republic','.cf');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TD','TCD','148','Chad','.td');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CL','CHL','152','Chile','.cl');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CN','CHN','156','China','.cn');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CX','CXR','162','Christmas Island','.cx');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CC','CCK','166','Cocos (Keeling) Islands','.cc');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CO','COL','170','Colombia','.co');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('KM','COM','174','Comoros','.km');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CD','COD','180','Congo, Democratic Republic of the','.cd');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CG','COG','178','Congo','.cg');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CK','COK','184','Cook Islands','.ck');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CR','CRI','188','Costa Rica','.cr');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('HR','HRV','191','Croatia','.hr');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CU','CUB','192','Cuba','.cu');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CW','CUW','531','CuraÃ§ao','.cw');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CY','CYP','196','Cyprus','.cy');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CZ','CZE','203','Czechia','.cz');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('DK','DNK','208','Denmark','.dk');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('DJ','DJI','262','Djibouti','.dj');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('DM','DMA','212','Dominica','.dm');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('DO','DOM','214','Dominican Republic','.do');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('EC','ECU','218','Ecuador','.ec');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('EG','EGY','818','Egypt','.eg');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SV','SLV','222','El Salvador','.sv');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GQ','GNQ','226','Equatorial Guinea','.gq');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('ER','ERI','232','Eritrea','.er');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('EE','EST','233','Estonia','.ee');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SZ','SWZ','748','Eswatini','.sz');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('ET','ETH','231','Ethiopia','.et');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('FK','FLK','238','Falkland Islands','.fk');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('FO','FRO','234','Faroe Islands','.fo');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('FJ','FJI','242','Fiji','.fj');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('FI','FIN','246','Finland','.fi');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('FR','FRA','250','France','.fr');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GF','GUF','254','French Guiana','.gf');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('PF','PYF','258','French Polynesia','.pf');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TF','ATF','260','French Southern Territories','.tf');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GA','GAB','266','Gabon','.ga');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GM','GMB','270','Gambia','.gm');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GE','GEO','268','Georgia','.ge');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('DE','DEU','276','Germany','.de');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GH','GHA','288','Ghana','.gh');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GI','GIB','292','Gibraltar','.gi');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GR','GRC','300','Greece','.gr');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GL','GRL','304','Greenland','.gl');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GD','GRD','308','Grenada','.gd');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GP','GLP','312','Guadeloupe','.gp');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GU','GUM','316','Guam','.gu');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GT','GTM','320','Guatemala','.gt');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GG','GGY','831','Guernsey','.gg');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GN','GIN','324','Guinea','.gn');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GW','GNB','624','Guinea-Bissau','.gw');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GY','GUY','328','Guyana','.gy');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('HT','HTI','332','Haiti','.ht');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('HM','HMD','334','Heard Island and McDonald Islands','.hm');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('VA','VAT','336','Holy See','.va');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('HN','HND','340','Honduras','.hn');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('HK','HKG','344','Hong Kong','.hk');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('HU','HUN','348','Hungary','.hu');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('IS','ISL','352','Iceland','.is');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('IN','IND','356','India','.in');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('ID','IDN','360','Indonesia','.id');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('IR','IRN','364','Iran','.ir');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('IQ','IRQ','368','Iraq','.iq');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('IE','IRL','372','Ireland','.ie');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('IM','IMN','833','Isle of Man','.im');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('IL','ISR','376','Israel','.il');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('IT','ITA','380','Italy','.it');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('JM','JAM','388','Jamaica','.jm');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('JP','JPN','392','Japan','.jp');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('JE','JEY','832','Jersey','.je');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('JO','JOR','400','Jordan','.jo');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('KZ','KAZ','398','Kazakhstan','.kz');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('KE','KEN','404','Kenya','.ke');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('KI','KIR','296','Kiribati','.ki');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('KR','KOR','410','Korea, Republic of','.kr');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('KW','KWT','414','Kuwait','.kw');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('KG','KGZ','417','Kyrgyzstan','.kg');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('LV','LVA','428','Latvia','.lv');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('LB','LBN','422','Lebanon','.lb');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('LS','LSO','426','Lesotho','.ls');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('LR','LBR','430','Liberia','.lr');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('LY','LBY','434','Libya','.ly');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('LI','LIE','438','Liechtenstein','.li');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('LT','LTU','440','Lithuania','.lt');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('LU','LUX','442','Luxembourg','.lu');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MO','MAC','446','Macao','.mo');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MG','MDG','450','Madagascar','.mg');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MW','MWI','454','Malawi','.mw');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MY','MYS','458','Malaysia','.my');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MV','MDV','462','Maldives','.mv');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('ML','MLI','466','Mali','.ml');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MT','MLT','470','Malta','.mt');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MH','MHL','584','Marshall Islands','.mh');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MQ','MTQ','474','Martinique','.mq');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MR','MRT','478','Mauritania','.mr');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MU','MUS','480','Mauritius','.mu');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('YT','MYT','175','Mayotte','.yt');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MX','MEX','484','Mexico','.mx');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('FM','FSM','583','Micronesia','.fm');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MD','MDA','498','Moldova','.md');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MC','MCO','492','Monaco','.mc');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MN','MNG','496','Mongolia','.mn');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('ME','MNE','499','Montenegro','.me');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MS','MSR','500','Montserrat','.ms');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MA','MAR','504','Morocco','.ma');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MZ','MOZ','508','Mozambique','.mz');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MM','MMR','104','Myanmar','.mm');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('NA','NAM','516','Namibia','.na');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('NR','NRU','520','Nauru','.nr');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('NP','NPL','524','Nepal','.np');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('NL','NLD','528','Netherlands','.nl');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('NC','NCL','540','New Caledonia','.nc');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('NZ','NZL','554','New Zealand','.nz');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('NI','NIC','558','Nicaragua','.ni');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('NE','NER','562','Niger','.ne');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('NG','NGA','566','Nigeria','.ng');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('NU','NIU','570','Niue','.nu');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('NF','NFK','574','Norfolk Island','.nf');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MK','MKD','807','North Macedonia','.mk');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MP','MNP','580','Northern Mariana Islands','.mp');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('NO','NOR','578','Norway','.no');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('OM','OMN','512','Oman','.om');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('PK','PAK','586','Pakistan','.pk');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('PW','PLW','585','Palau','.pw');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('PS','PSE','275','Palestine, State of','.ps');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('PA','PAN','591','Panama','.pa');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('PG','PNG','598','Papua New Guinea','.pg');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('PY','PRY','600','Paraguay','.py');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('PE','PER','604','Peru','.pe');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('PH','PHL','608','Philippines','.ph');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('PN','PCN','612','Pitcairn','.pn');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('PL','POL','616','Poland','.pl');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('PT','PRT','620','Portugal','.pt');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('PR','PRI','630','Puerto Rico','.pr');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('QA','QAT','634','Qatar','.qa');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('RE','REU','638','RÃ©union','.re');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('RO','ROU','642','Romania','.ro');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('RU','RUS','643','Russian Federation','.ru');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('RW','RWA','646','Rwanda','.rw');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('BL','BLM','652','Saint BarthÃ©lemy','.bl');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SH','SHN','654','Saint Helena, Ascension and Tristan da Cunha','.sh');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('KN','KNA','659','Saint Kitts and Nevis','.kn');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('LC','LCA','662','Saint Lucia','.lc');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('MF','MAF','663','Saint Martin (French part)','.mf');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('PM','SPM','666','Saint Pierre and Miquelon','.pm');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('VC','VCT','670','Saint Vincent and the Grenadines','.vc');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('WS','WSM','882','Samoa','.ws');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SM','SMR','674','San Marino','.sm');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('ST','STP','678','Sao Tome and Principe','.st');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SA','SAU','682','Saudi Arabia','.sa');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SN','SEN','686','Senegal','.sn');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('RS','SRB','688','Serbia','.rs');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SC','SYC','690','Seychelles','.sc');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SL','SLE','694','Sierra Leone','.sl');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SG','SGP','702','Singapore','.sg');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SX','SXM','534','Sint Maarten (Dutch part)','.sx');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SK','SVK','703','Slovakia','.sk');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SI','SVN','705','Slovenia','.si');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SB','SLB','090','Solomon Islands','.sb');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SO','SOM','706','Somalia','.so');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('ZA','ZAF','710','South Africa','.za');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GS','SGS','239','South Georgia and the South Sandwich Islands','.gs');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SS','SSD','728','South Sudan','.ss');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('ES','ESP','724','Spain','.es');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('LK','LKA','144','Sri Lanka','.lk');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SD','SDN','729','Sudan','.sd');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SR','SUR','740','Suriname','.sr');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SJ','SJM','744','Svalbard and Jan Mayen',NULL);
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SE','SWE','752','Sweden','.se');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('CH','CHE','756','Switzerland','.ch');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('SY','SYR','760','Syrian Arab Republic','.sy');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TW','TWN','158','Taiwan, Province of China','.tw');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TJ','TJK','762','Tajikistan','.tj');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TZ','TZA','834','Tanzania, United Republic of','.tz');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TH','THA','764','Thailand','.th');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TL','TLS','626','Timor-Leste','.tl');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TG','TGO','768','Togo','.tg');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TK','TKL','772','Tokelau','.tk');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TO','TON','776','Tonga','.to');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TT','TTO','780','Trinidad and Tobago','.tt');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TN','TUN','788','Tunisia','.tn');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TR','TUR','792','TÃ¼rkiye','.tr');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TM','TKM','795','Turkmenistan','.tm');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TC','TCA','796','Turks and Caicos Islands','.tc');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('TV','TUV','798','Tuvalu','.tv');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('UG','UGA','800','Uganda','.ug');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('UA','UKR','804','Ukraine','.ua');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('AE','ARE','784','United Arab Emirates','.ae');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('GB','GBR','826','United Kingdom','.uk');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('UM','UMI','581','United States Minor Outlying Islands',NULL);
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('US','USA','840','United States of America','.us');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('UY','URY','858','Uruguay','.uy');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('UZ','UZB','860','Uzbekistan','.uz');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('VU','VUT','548','Vanuatu','.vu');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('VE','VEN','862','Venezuela','.ve');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('VN','VNM','704','Viet Nam','.vn');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('VG','VGB','092','Virgin Islands, British','.vg');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('VI','VIR','850','Virgin Islands, U.S.','.vi');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('WF','WLF','876','Wallis and Futuna','.wf');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('EH','ESH','732','Western Sahara',NULL);
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('YE','YEM','887','Yemen','.ye');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('ZM','ZMB','894','Zambia','.zm');
INSERT IGNORE INTO `country` (`alpha2`,`alpha3`,`numeric_code`,`name`,`tld`) VALUES ('ZW','ZWE','716','Zimbabwe','.zw');
SELECT 'Countries seeded.' AS status;

-- ====================================================================
-- Country-Currency associations
-- ====================================================================
SELECT 'Seeding country_currency links...' AS status;
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('US','USD',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('GB','GBP',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('JP','JPY',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('CH','CHF',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('AU','AUD',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('CA','CAD',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('NZ','NZD',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('HK','HKD',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('SG','SGD',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('CN','CNY',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('IN','INR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('BR','BRL',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('MX','MXN',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('ZA','ZAR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('RU','RUB',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('TR','TRY',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('KR','KRW',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('ID','IDR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('MY','MYR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('TH','THB',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('PH','PHP',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('PL','PLN',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('CZ','CZK',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('HU','HUF',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('RO','RON',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('BG','BGN',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('IS','ISK',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('IL','ILS',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('AE','AED',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('SA','SAR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('QA','QAR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('KW','KWD',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('BH','BHD',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('OM','OMR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('JO','JOD',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('EG','EGP',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('MA','MAD',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('NG','NGN',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('KE','KES',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('TZ','TZS',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('UG','UGX',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('GH','GHS',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('ZM','ZMW',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('ET','ETB',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('DZ','DZD',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('UA','UAH',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('BY','BYN',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('NO','NOK',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('SE','SEK',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('DK','DKK',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('AT','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('BE','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('CY','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('EE','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('FI','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('FR','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('DE','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('GR','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('IE','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('IT','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('LV','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('LT','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('LU','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('MT','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('NL','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('PT','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('SK','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('SI','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('ES','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('HR','EUR',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('PA','PAB',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('PA','USD',0,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('SV','USD',1,1,1);
INSERT IGNORE INTO `country_currency` (`country_alpha2`,`currency_code`,`is_primary`,`is_legal_tender`,`is_operational`) VALUES ('SV','SVC',0,1,1);
SELECT 'Country-currency links seeded.' AS status;

-- ====================================================================
-- Field Visibility seed (idempotent)
-- ====================================================================
-- SecurityDto
SET @fve_exists = (SELECT COUNT(*) FROM `field_visibility_entity` WHERE `entity_type` = 'SecurityDto');
SET @fveId = UUID();
INSERT INTO `field_visibility_entity` (`id`, `entity_type`, `display_name`, `description`, `is_active`)
SELECT @fveId, 'SecurityDto', 'Security', 'Security master DTO fields', 1
WHERE @fve_exists = 0;

INSERT INTO `field_visibility_field` (`id`, `field_visibility_entity_id`, `field_name`, `display_name`, `data_type`, `sensitivity_level`, `default_visibility_state`, `sort_order`, `is_active`)
SELECT UUID(), (SELECT `id` FROM `field_visibility_entity` WHERE `entity_type`='SecurityDto' LIMIT 1), v.fn, v.dn, v.dt, v.sl, v.dvs, v.so, 1
FROM (SELECT 'IdentifierType' fn,'Identifier Type' dn,'string' dt,'Public' sl,'VISIBLE' dvs, 10 so UNION ALL
      SELECT 'IdentifierValue','Identifier Value','string','Public','VISIBLE',20 UNION ALL
      SELECT 'Name','Name','string','Public','VISIBLE',30 UNION ALL
      SELECT 'Type','Type','string','Public','VISIBLE',40 UNION ALL
      SELECT 'IsActive','Is Active','boolean','Public','VISIBLE',50 UNION ALL
      SELECT 'Description','Description','string','Public','VISIBLE',60 UNION ALL
      SELECT 'Issuer','Issuer','string','Public','VISIBLE',70 UNION ALL
      SELECT 'Currency','Currency','string','Public','VISIBLE',80 UNION ALL
      SELECT 'CreatedAt','Created At','datetime','Public','VISIBLE',90 UNION ALL
      SELECT 'UpdatedAt','Updated At','datetime','Public','VISIBLE',100 UNION ALL
      SELECT 'Attributes','Attributes','object','Public','VISIBLE',110 UNION ALL
      SELECT 'CreditRatings','Credit Ratings','object','Public','VISIBLE',120 UNION ALL
      SELECT 'ModifiedBy','Modified By','string','Internal','HIDDEN',130 UNION ALL
      SELECT 'ContentHash','Content Hash','string','Internal','HIDDEN',140) v
WHERE @fve_exists = 0;

INSERT INTO `field_visibility_rule` (`id`, `field_visibility_field_id`, `required_permission`, `visibility_state`, `obfuscation_type`, `priority`, `created_by`)
SELECT UUID(), f.`id`, 'securities:read', 'VISIBLE', 'NONE', 10, 'seed'
FROM `field_visibility_field` f
JOIN `field_visibility_entity` e ON e.`id` = f.`field_visibility_entity_id`
WHERE e.`entity_type` = 'SecurityDto' AND f.`sensitivity_level` = 'Public' AND @fve_exists = 0;

INSERT INTO `field_visibility_rule` (`id`, `field_visibility_field_id`, `required_permission`, `visibility_state`, `obfuscation_type`, `priority`, `created_by`)
SELECT UUID(), f.`id`, 'securities:view-internal', 'VISIBLE', 'NONE', 10, 'seed'
FROM `field_visibility_field` f
JOIN `field_visibility_entity` e ON e.`id` = f.`field_visibility_entity_id`
WHERE e.`entity_type` = 'SecurityDto' AND f.`sensitivity_level` = 'Internal' AND @fve_exists = 0;

SELECT 'Field Visibility seed data loaded.' AS status;

-- ====================================================================
-- Permission Catalog (idempotent)
-- ====================================================================
INSERT IGNORE INTO `permission_definition` (`id`, `permission_key`, `display_name`, `permission_group`, `description`, `is_assignable`, `is_system`, `sort_order`, `is_active`)
SELECT UUID(), v.k, v.d, v.g, v.desc, v.asgn, v.sys, v.srt, 1
FROM (SELECT 'securities:read' k,'View Securities' d,'Securities' g,'View securities master data' `desc`,1 asgn,0 sys,10 srt UNION ALL
SELECT 'securities:write','Create/Update Securities','Securities','Create and update securities',1,0,20 UNION ALL
SELECT 'securities:delete','Delete Securities','Securities','Delete securities',1,0,30 UNION ALL
SELECT 'securities:view-internal','View Internal Fields','Securities','View internal/sensitive fields',1,0,40 UNION ALL
SELECT 'ratings:read','View Ratings','Ratings','View ratings and audit trail',1,0,50 UNION ALL
SELECT 'ratings:write','Trigger Rating Calculations','Ratings','Trigger rating calculations',1,0,60 UNION ALL
SELECT 'ratings:manage','Manage Rating Models','Ratings','Manage rating models, rules, and scales',1,0,70 UNION ALL
SELECT 'pricing:read','View Prices','Pricing','View prices and pricing rules',1,0,80 UNION ALL
SELECT 'pricing:write','Import Prices','Pricing','Import prices and run derivations',1,0,90 UNION ALL
SELECT 'pricing:manage','Manage Pricing Rules','Pricing','Create, update, and delete pricing rules',1,0,100 UNION ALL
SELECT 'imports:read','View Imports','Imports','View import requests and profiles',1,0,110 UNION ALL
SELECT 'imports:run','Trigger Imports','Imports','Trigger imports',1,0,120 UNION ALL
SELECT 'imports:manage','Manage Import Profiles','Imports','Manage import profiles and retry failed imports',1,0,130 UNION ALL
SELECT 'exports:run','Export Data','Exports','Export securities data',1,0,140 UNION ALL
SELECT 'workflows:read','View Workflows','Workflows','View workflow instances',1,0,150 UNION ALL
SELECT 'workflows:use','Submit Workflow Decisions','Workflows','Submit workflow step decisions',1,0,160 UNION ALL
SELECT 'workflows:manage','Manage Workflows','Workflows','Create, cancel, and delete workflow definitions',1,0,170 UNION ALL
SELECT 'jobs:read','View Jobs','Jobs','View job status and history',1,0,180 UNION ALL
SELECT 'jobs:manage','Manage Jobs','Jobs','Trigger, pause, resume, and schedule jobs',1,0,190 UNION ALL
SELECT 'audit:read','View Audit Logs','Audit','View audit logs',1,0,200 UNION ALL
SELECT 'portfolios:read','View Portfolios','Portfolios','View clients, portfolios and positions',1,0,210 UNION ALL
SELECT 'portfolios:write','Manage Portfolios','Portfolios','Create and manage clients, portfolios and positions',1,0,220 UNION ALL
SELECT 'admin:field-visibility','Manage Field Visibility','Admin','Manage dynamic field visibility rules',1,0,230 UNION ALL
SELECT 'admin:ui-resources','Manage UI Resources','Admin','Manage UI resource catalog and rules',1,0,240 UNION ALL
SELECT 'system:manage','Manage System','System','Manage plugins and system settings',1,1,250 UNION ALL
SELECT 'issuers:read','View Issuers','Issuers','View issuers and their relationships',1,0,260 UNION ALL
SELECT 'issuers:write','Create/Update Issuers','Issuers','Create, update, and delete issuers',1,0,270 UNION ALL
SELECT 'admin:manage-permissions','Manage Permission Definitions','Administrator','Create, update, and delete permission definitions',1,0,310 UNION ALL
SELECT 'admin:manage-authorization','Manage Authorization Config','Administrator','Full access to field visibility and resource auth config',1,0,320 UNION ALL
SELECT 'admin:manage-users','Manage User Assignments','Administrator','Assign permissions and roles to users via Keycloak',1,0,330 UNION ALL
SELECT 'admin:super','Superuser / Full Admin Access','Administrator','Unrestricted administrative access across platform',1,1,340) v
WHERE NOT EXISTS (SELECT 1 FROM `permission_definition` WHERE `permission_key` = v.k);

SELECT 'Permission catalog seed data loaded.' AS status;

-- ====================================================================
-- Issuers seed (idempotent)
-- ====================================================================
SELECT 'Seeding issuers...' AS status;

INSERT IGNORE INTO `issuer` (`id`, `legal_name`, `display_name`, `short_name`, `lei_code`, `issuer_type`, `country_alpha2`, `is_active`, `modified_by`)
SELECT UUID(), v.ln, v.dn, v.sn, v.lei, v.itype, v.c2, 1, 'seed'
FROM (SELECT 'Apple Inc.' ln,'Apple' dn,'AAPL' sn,'HWUPKR0MPOU8FGXBT394' lei,'Corporate' itype,'US' c2 UNION ALL
SELECT 'Microsoft Corporation','Microsoft','MSFT','INR2EJN1ERAN0W5ZP974','Corporate','US' UNION ALL
SELECT 'Tesla Inc.','Tesla','TSLA','54930043XZGB27CTOV49','Corporate','US' UNION ALL
SELECT 'JPMorgan Chase & Co.','JPMorgan','JPM','8I5DZWZKVSZI1NUHU748','Corporate','US' UNION ALL
SELECT 'JPMorgan Chase Bank, N.A.','JPMorgan Chase Bank','JPMCB','7H6GLXDRUGQFU57RNE97','Corporate','US' UNION ALL
SELECT 'Deutsche Bank AG','Deutsche Bank','DBK','7LTWFZYICNSX8D621K86','Corporate','DE' UNION ALL
SELECT 'US Department of the Treasury','US Treasury','UST',NULL,'Government','US' UNION ALL
SELECT 'State of California','California','CA',NULL,'Government','US' UNION ALL
SELECT 'New York Metropolitan Transportation Authority','NY MTA','NYMTA',NULL,'Government','US' UNION ALL
SELECT 'TechCo Holdings LLC','TechCo Holdings','TECHCO',NULL,'Corporate','US') v
WHERE NOT EXISTS (
    SELECT 1 FROM `issuer`
    WHERE (`lei_code` IS NOT NULL AND `lei_code` = v.lei AND `is_current` = 1)
       OR (v.lei IS NULL AND `legal_name` = v.ln AND `is_current` = 1)
);

-- Set parent links for JPMorgan Chase Bank, N.A.
SET @jpm_parent = (SELECT `id` FROM `issuer` WHERE `lei_code` = '8I5DZWZKVSZI1NUHU748' AND `is_current` = 1 LIMIT 1);
SET @jpm_child  = (SELECT `id` FROM `issuer` WHERE `lei_code` = '7H6GLXDRUGQFU57RNE97' AND `is_current` = 1 LIMIT 1);
UPDATE `issuer` SET `direct_accounting_parent_issuer_id` = @jpm_parent,
                    `ultimate_accounting_parent_issuer_id` = @jpm_parent
WHERE `id` = @jpm_child AND @jpm_parent IS NOT NULL AND `direct_accounting_parent_issuer_id` IS NULL;

-- Issuer identifiers
INSERT IGNORE INTO `issuer_identifier` (`id`, `issuer_id`, `identifier_type`, `identifier_value`, `source_system`, `is_primary`, `modified_by`)
SELECT UUID(), iss.`id`, v.itype, v.ival, 'Manual', v.prim, 'seed'
FROM (SELECT 'HWUPKR0MPOU8FGXBT394' lei,'Ticker' itype,'AAPL' ival,1 prim UNION ALL
SELECT 'HWUPKR0MPOU8FGXBT394','CUSIP','037833100',0 UNION ALL
SELECT 'INR2EJN1ERAN0W5ZP974','Ticker','MSFT',1 UNION ALL
SELECT '54930043XZGB27CTOV49','Ticker','TSLA',1 UNION ALL
SELECT '8I5DZWZKVSZI1NUHU748','Ticker','JPM',1 UNION ALL
SELECT '7LTWFZYICNSX8D621K86','Ticker','DBK',1) v
JOIN `issuer` iss ON iss.`lei_code` = v.lei AND iss.`is_current` = 1
WHERE NOT EXISTS (
    SELECT 1 FROM `issuer_identifier`
    WHERE `issuer_id` = iss.`id` AND `identifier_type` = v.itype AND `identifier_value` = v.ival AND `is_current` = 1
);

-- Issuer relationships
SET @jpm_par2 = (SELECT `id` FROM `issuer` WHERE `lei_code` = '8I5DZWZKVSZI1NUHU748' AND `is_current` = 1 LIMIT 1);
SET @jpm_chd2 = (SELECT `id` FROM `issuer` WHERE `lei_code` = '7H6GLXDRUGQFU57RNE97' AND `is_current` = 1 LIMIT 1);

INSERT IGNORE INTO `issuer_relationship` (`id`, `child_issuer_id`, `parent_issuer_id`, `relationship_type`, `ownership_percent`, `is_primary`, `modified_by`)
SELECT UUID(), @jpm_chd2, @jpm_par2, v.rtype, 100.00, 1, 'seed'
FROM (SELECT 'ACCOUNTING_DIRECT_PARENT' rtype UNION ALL
      SELECT 'ACCOUNTING_ULTIMATE_PARENT' UNION ALL
      SELECT 'OWNERSHIP_PARENT') v
WHERE @jpm_chd2 IS NOT NULL AND @jpm_par2 IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM `issuer_relationship`
    WHERE `child_issuer_id` = @jpm_chd2 AND `parent_issuer_id` = @jpm_par2 AND `relationship_type` = v.rtype AND `is_current` = 1);

-- Link securities to issuers
SET @iss_apple = (SELECT `id` FROM `issuer` WHERE `lei_code` = 'HWUPKR0MPOU8FGXBT394' AND `is_current` = 1 LIMIT 1);
SET @iss_msft  = (SELECT `id` FROM `issuer` WHERE `lei_code` = 'INR2EJN1ERAN0W5ZP974' AND `is_current` = 1 LIMIT 1);
SET @iss_tsla  = (SELECT `id` FROM `issuer` WHERE `lei_code` = '54930043XZGB27CTOV49' AND `is_current` = 1 LIMIT 1);
SET @iss_jpm   = (SELECT `id` FROM `issuer` WHERE `lei_code` = '8I5DZWZKVSZI1NUHU748' AND `is_current` = 1 LIMIT 1);
SET @iss_db    = (SELECT `id` FROM `issuer` WHERE `lei_code` = '7LTWFZYICNSX8D621K86' AND `is_current` = 1 LIMIT 1);
SET @iss_ust   = (SELECT `id` FROM `issuer` WHERE `legal_name` = 'US Department of the Treasury' AND `is_current` = 1 LIMIT 1);
SET @iss_ca    = (SELECT `id` FROM `issuer` WHERE `legal_name` = 'State of California' AND `is_current` = 1 LIMIT 1);
SET @iss_mta   = (SELECT `id` FROM `issuer` WHERE `legal_name` = 'New York Metropolitan Transportation Authority' AND `is_current` = 1 LIMIT 1);
SET @iss_tech  = (SELECT `id` FROM `issuer` WHERE `legal_name` = 'TechCo Holdings LLC' AND `is_current` = 1 LIMIT 1);

UPDATE `security` SET `issuer_id` = @iss_apple WHERE `issuer` = 'Apple Inc.' AND `issuer_id` IS NULL;
UPDATE `security` SET `issuer_id` = @iss_msft  WHERE `issuer` = 'Microsoft Corporation' AND `issuer_id` IS NULL;
UPDATE `security` SET `issuer_id` = @iss_tsla  WHERE `issuer` = 'Tesla Inc.' AND `issuer_id` IS NULL;
UPDATE `security` SET `issuer_id` = @iss_jpm   WHERE `issuer` IN ('JPMorgan Chase & Co.','JPMorgan Chase') AND `issuer_id` IS NULL;
UPDATE `security` SET `issuer_id` = @iss_db    WHERE `issuer` = 'Deutsche Bank AG' AND `issuer_id` IS NULL;
UPDATE `security` SET `issuer_id` = @iss_ust   WHERE `issuer` IN ('US Treasury','US Department of the Treasury','United States Treasury') AND `issuer_id` IS NULL;
UPDATE `security` SET `issuer_id` = @iss_ca    WHERE `issuer` IN ('State of California','California') AND `issuer_id` IS NULL;
UPDATE `security` SET `issuer_id` = @iss_mta   WHERE `issuer` IN ('New York MTA','New York Metropolitan Transportation Authority','MTA') AND `issuer_id` IS NULL;
UPDATE `security` SET `issuer_id` = @iss_tech  WHERE `issuer` = 'TechCo Holdings LLC' AND `issuer_id` IS NULL;

SELECT 'Issuer seed data loaded.' AS status;

-- ====================================================================
-- Vendor Source seed
-- ====================================================================
INSERT IGNORE INTO `vendor_source` (`code`, `display_name`, `global_priority`, `staleness_threshold_hours`)
SELECT v.code, v.display_name, v.global_priority, v.staleness_threshold_hours
FROM (SELECT 'BLOOMBERG' code,'Bloomberg B-PIPE' display_name,1 global_priority,24 staleness_threshold_hours UNION ALL
SELECT 'REFINITIV','Refinitiv / LSEG',2,24 UNION ALL
SELECT 'ICE','ICE Data Services',3,24 UNION ALL
SELECT 'ALPHAVANTAGE','Alpha Vantage',10,48 UNION ALL
SELECT 'FLAT_FILE','Flat File / SFTP Import',20,72 UNION ALL
SELECT 'INTERNAL','Internal / Manual',50,0) v
WHERE NOT EXISTS (SELECT 1 FROM `vendor_source` WHERE `code` = v.code AND `is_current` = 1 AND `is_deleted` = 0);

INSERT IGNORE INTO `__SchemaVersions` (`version`, `description`)
VALUES ('1.2-ref-data', 'Currencies, countries, field visibility, permissions, issuers, vendor sources');

SELECT 'Vendor source seed data loaded.' AS status;
SELECT 'SecurityApp extended seed data loaded successfully.' AS status;
