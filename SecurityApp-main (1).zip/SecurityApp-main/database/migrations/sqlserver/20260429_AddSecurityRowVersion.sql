USE securityapp_db;
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

-- Migration 2B: Add row_version (ROWVERSION) to dbo.security for optimistic concurrency.
-- EF Core maps this via IsRowVersion(); the API exposes it as an ETag on GET and
-- validates If-Match on PUT — returning 409 CONCURRENCY_CONFLICT on mismatch.

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.security') AND name = 'row_version')
    ALTER TABLE dbo.security ADD row_version ROWVERSION NOT NULL;
GO
