-- =============================================================================
-- Migration: 20260426_AuditLogPartitionAndArchive
-- Purpose:   M22 — Audit log partitioning + archive infrastructure.
--
-- What this migration does:
--   1. Creates audit_log_archive — identical structure to audit_log, used as
--      the long-term cold store for rows older than the retention period.
--      Partitioned monthly by created_at so old months can be dropped cheaply.
--   2. Creates a partition function (pf_audit_log_monthly) and scheme
--      (ps_audit_log_monthly) on the PRIMARY filegroup as a scaffold.
--      A DBA may redirect future partitions to separate filegroups for I/O
--      isolation without any application changes.
--   3. Adds a covering index on audit_log(created_at) if not already present.
--
-- Note on live table partitioning:
--   Switching audit_log itself to a partitioned table would require the PK
--   (UNIQUEIDENTIFIER clustered) to include the partition column (created_at),
--   which is a breaking change on a live table.  Instead the archive table is
--   partitioned and the AuditArchiveJobPlugin copies-then-deletes rows on a
--   monthly schedule.  When volume warrants it, a DBA can rebuild audit_log
--   with a composite PK in a maintenance window and switch to true partition
--   switching at that point.
--
-- Idempotent: safe to run multiple times.
-- =============================================================================

-- ── 1. Partition function (monthly, RIGHT boundary) ──────────────────────────
-- Boundaries seed 2025-01 → 2030-12 (auto-extended monthly by AuditArchiveJob).
IF NOT EXISTS (SELECT 1 FROM sys.partition_functions WHERE name = 'pf_audit_log_monthly')
BEGIN
    CREATE PARTITION FUNCTION pf_audit_log_monthly (DATETIME2)
    AS RANGE RIGHT FOR VALUES (
        '2025-01-01', '2025-02-01', '2025-03-01', '2025-04-01',
        '2025-05-01', '2025-06-01', '2025-07-01', '2025-08-01',
        '2025-09-01', '2025-10-01', '2025-11-01', '2025-12-01',
        '2026-01-01', '2026-02-01', '2026-03-01', '2026-04-01',
        '2026-05-01', '2026-06-01', '2026-07-01', '2026-08-01',
        '2026-09-01', '2026-10-01', '2026-11-01', '2026-12-01',
        '2027-01-01', '2027-02-01', '2027-03-01', '2027-04-01',
        '2027-05-01', '2027-06-01', '2027-07-01', '2027-08-01',
        '2027-09-01', '2027-10-01', '2027-11-01', '2027-12-01',
        '2028-01-01', '2028-02-01', '2028-03-01', '2028-04-01',
        '2028-05-01', '2028-06-01', '2028-07-01', '2028-08-01',
        '2028-09-01', '2028-10-01', '2028-11-01', '2028-12-01',
        '2029-01-01', '2029-02-01', '2029-03-01', '2029-04-01',
        '2029-05-01', '2029-06-01', '2029-07-01', '2029-08-01',
        '2029-09-01', '2029-10-01', '2029-11-01', '2029-12-01',
        '2030-01-01'
    );
END
GO

-- ── 2. Partition scheme ───────────────────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM sys.partition_schemes WHERE name = 'ps_audit_log_monthly')
    CREATE PARTITION SCHEME ps_audit_log_monthly
    AS PARTITION pf_audit_log_monthly ALL TO ([PRIMARY]);
GO

-- ── 3. audit_log_archive ──────────────────────────────────────────────────────
-- Mirrors audit_log columns exactly.  Clustered index includes created_at so
-- the partition scheme is honoured (composite PK avoids hotspot on NEWID()).
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'audit_log_archive' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.audit_log_archive (
        id             UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
        entity_type    NVARCHAR(50)     NOT NULL,
        action         NVARCHAR(50)     NOT NULL,
        user_id        UNIQUEIDENTIFIER NULL,
        user_name      NVARCHAR(255)    NULL,
        details        NVARCHAR(MAX)    NULL,
        ip_address     NVARCHAR(45)     NULL,
        entity_id      UNIQUEIDENTIFIER NULL,
        before_state   NVARCHAR(MAX)    NULL,
        after_state    NVARCHAR(MAX)    NULL,
        changed_fields NVARCHAR(MAX)    NULL,
        correlation_id UNIQUEIDENTIFIER NULL,
        causation_id   UNIQUEIDENTIFIER NULL,
        source         NVARCHAR(50)     NOT NULL DEFAULT 'Http',
        created_at     DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        archived_at    DATETIME2        NOT NULL DEFAULT GETUTCDATE(),
        -- Composite PK includes created_at so the clustered index aligns with
        -- the partition scheme and allows future partition switching.
        CONSTRAINT pk_audit_log_archive PRIMARY KEY CLUSTERED (created_at, id)
    ) ON ps_audit_log_monthly(created_at);

    CREATE INDEX ix_ala_entity_type_entity_id
        ON dbo.audit_log_archive (entity_type, entity_id)
        ON ps_audit_log_monthly(created_at);

    CREATE INDEX ix_ala_user_id
        ON dbo.audit_log_archive (user_id)
        ON ps_audit_log_monthly(created_at);

    CREATE INDEX ix_ala_correlation_id
        ON dbo.audit_log_archive (correlation_id)
        WHERE correlation_id IS NOT NULL
        ON ps_audit_log_monthly(created_at);
END
GO

-- ── 4. Covering index on audit_log(created_at) ───────────────────────────────
-- Ensures the DELETE in AuditArchiveJob runs as a seek, not a scan.
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__audit_log__created_at'
               AND object_id = OBJECT_ID('dbo.audit_log'))
    CREATE INDEX ix__audit_log__created_at ON dbo.audit_log (created_at);
GO

-- ── 5. Record migration version ──────────────────────────────────────────────
IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'SchemaVersions')
    INSERT INTO dbo.SchemaVersions (version, applied_at, description)
    SELECT '20260426_AuditLogPartitionAndArchive', GETUTCDATE(),
           'M22: audit_log_archive partitioned table + pf/ps_audit_log_monthly'
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.SchemaVersions
        WHERE version = '20260426_AuditLogPartitionAndArchive'
    );
GO
