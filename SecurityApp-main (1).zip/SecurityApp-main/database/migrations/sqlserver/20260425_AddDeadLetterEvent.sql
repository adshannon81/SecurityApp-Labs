USE securityapp_db;
GO
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'dead_letter_event' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.dead_letter_event (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        event_type       NVARCHAR(100)    NOT NULL,
        correlation_id   UNIQUEIDENTIFIER NOT NULL,
        idempotency_key  NVARCHAR(200)    NULL,
        payload          NVARCHAR(MAX)    NOT NULL,
        failure_reason   NVARCHAR(500)    NOT NULL,
        failure_stage    INT              NOT NULL DEFAULT 0,
        -- 0=unknown 1=schema 2=domain 3=business 4=transport 5=timeout
        retry_count      INT              NOT NULL DEFAULT 0,
        status           NVARCHAR(20)     NOT NULL DEFAULT 'PENDING',
        -- PENDING | IN_REVIEW | REPLAYED | RESOLVED | DISCARDED
        resolved_by      NVARCHAR(255)    NULL,
        resolved_at      DATETIME2(3)     NULL,
        resolution_notes NVARCHAR(500)    NULL,
        created_at       DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        updated_at       DATETIME2(3)     NULL,
        modified_by      NVARCHAR(255)    NULL,
        CONSTRAINT pk_dead_letter_event PRIMARY KEY (id),
        CONSTRAINT ck_dead_letter_status CHECK (status IN ('PENDING','IN_REVIEW','REPLAYED','RESOLVED','DISCARDED'))
    );
    CREATE INDEX ix_dle_status         ON dbo.dead_letter_event (status);
    CREATE INDEX ix_dle_event_type     ON dbo.dead_letter_event (event_type);
    CREATE INDEX ix_dle_correlation_id ON dbo.dead_letter_event (correlation_id);
    CREATE INDEX ix_dle_created_at     ON dbo.dead_letter_event (created_at);
END
GO
