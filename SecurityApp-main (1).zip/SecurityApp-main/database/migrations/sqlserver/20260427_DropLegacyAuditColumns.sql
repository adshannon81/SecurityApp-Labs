USE securityapp_db;
GO
-- Migration 1D: Drop legacy old_values / new_values columns from audit_log.
-- These were the original column names before Milestone 3 renamed them to
-- before_state / after_state.  EF Core no longer maps them; they are dead weight.
-- Idempotent: each DROP is guarded by a column existence check.

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.audit_log') AND name = 'old_values')
    ALTER TABLE dbo.audit_log DROP COLUMN old_values;
GO
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.audit_log') AND name = 'new_values')
    ALTER TABLE dbo.audit_log DROP COLUMN new_values;
GO
