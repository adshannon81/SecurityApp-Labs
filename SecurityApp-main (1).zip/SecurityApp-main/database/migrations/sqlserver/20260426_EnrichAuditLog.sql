USE securityapp_db;
GO
-- Migration 1C: Enrich audit_log with structured diff columns
-- Idempotent: each ALTER is guarded by a column existence check.

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.audit_log') AND name = 'before_state')
    ALTER TABLE dbo.audit_log ADD before_state   NVARCHAR(MAX) NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.audit_log') AND name = 'after_state')
    ALTER TABLE dbo.audit_log ADD after_state    NVARCHAR(MAX) NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.audit_log') AND name = 'changed_fields')
    ALTER TABLE dbo.audit_log ADD changed_fields NVARCHAR(MAX) NULL;
    -- JSON: [{"field":"status_code","before":"ACTIVE","after":"SUSPENDED"}]
GO
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.audit_log') AND name = 'correlation_id')
    ALTER TABLE dbo.audit_log ADD correlation_id UNIQUEIDENTIFIER NULL;
GO
-- Fix correlation_id type if it was already nvarchar (original schema had it as string)
IF EXISTS (
    SELECT 1 FROM sys.columns c
    JOIN sys.types t ON c.user_type_id = t.user_type_id
    WHERE c.object_id = OBJECT_ID('dbo.audit_log') AND c.name = 'correlation_id' AND t.name = 'nvarchar'
)
BEGIN
    -- Drop any existing index on the column first
    IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__audit_log__correlation_id' AND object_id = OBJECT_ID('dbo.audit_log'))
        DROP INDEX ix__audit_log__correlation_id ON dbo.audit_log;
    IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_audit_logs_correlation_id' AND object_id = OBJECT_ID('dbo.audit_log'))
        DROP INDEX ix_audit_logs_correlation_id ON dbo.audit_log;
    IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_audit_log_correlation_id' AND object_id = OBJECT_ID('dbo.audit_log'))
        DROP INDEX ix_audit_log_correlation_id ON dbo.audit_log;
    ALTER TABLE dbo.audit_log ALTER COLUMN correlation_id UNIQUEIDENTIFIER NULL;
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.audit_log') AND name = 'causation_id')
    ALTER TABLE dbo.audit_log ADD causation_id   UNIQUEIDENTIFIER NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_audit_log_correlation_id' AND object_id = OBJECT_ID('dbo.audit_log'))
BEGIN
    SET QUOTED_IDENTIFIER ON;
    CREATE INDEX ix_audit_log_correlation_id ON dbo.audit_log (correlation_id)
    WHERE correlation_id IS NOT NULL;
END
GO
-- Drop superseded columns (replaced by before_state / after_state)
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.audit_log') AND name = 'old_values')
    ALTER TABLE dbo.audit_log DROP COLUMN old_values;
GO
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.audit_log') AND name = 'new_values')
    ALTER TABLE dbo.audit_log DROP COLUMN new_values;
GO
