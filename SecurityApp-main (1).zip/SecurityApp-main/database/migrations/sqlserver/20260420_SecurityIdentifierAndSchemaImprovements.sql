-- =============================================================================
-- Migration: 20260420 — SecurityIdentifier table + schema improvements
-- Implements recommendations from docs/securityapp-securities-schema-and-ui.md
--
-- Steps:
--   1. Create dbo.security_identifier (multi-identifier support)
--   2. Backfill identifiers from dbo.security
--   3. Add currency_code FK column to dbo.security
--   4. Populate currency_code from existing currency column
--   5. Add temporal check constraints to dbo.security
--   6. Add non-blank check constraints to dbo.security
--   7. Replace old identifier-based unique index with new search indexes
--   8. Fix FLOAT → DECIMAL in dbo.derived_rating
--   9. Fix FLOAT → DECIMAL in dbo.vendor_rating_metadata
--  10. Add single-value check constraint to dbo.security_attribute_kv
--  11. Add temporal check constraints to child attribute tables
-- =============================================================================

-- ── 1. Create dbo.security_identifier ────────────────────────────────────────

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'security_identifier' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.security_identifier (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        security_id      UNIQUEIDENTIFIER NOT NULL,
        identifier_type  NVARCHAR(50)     NOT NULL,
        identifier_value NVARCHAR(100)    NOT NULL,
        source_system    NVARCHAR(50)     NULL,
        is_primary       BIT              NOT NULL DEFAULT 0,

        -- BaseEntity
        created_at       DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        updated_at       DATETIME2(3)     NULL,

        -- TemporalEntity
        valid_from       DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        valid_to         DATETIME2(3)     NOT NULL DEFAULT '9999-12-31 23:59:59',
        system_from      DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        system_to        DATETIME2(3)     NOT NULL DEFAULT '9999-12-31 23:59:59',
        is_current       BIT              NOT NULL DEFAULT 1,
        is_deleted       BIT              NOT NULL DEFAULT 0,
        modified_by      NVARCHAR(255)    NULL,

        CONSTRAINT pk_security_identifier PRIMARY KEY (id),
        CONSTRAINT fk_security_identifier_security
            FOREIGN KEY (security_id) REFERENCES dbo.security(id) ON DELETE CASCADE,
        CONSTRAINT ck_security_identifier_valid_time  CHECK (valid_from  < valid_to),
        CONSTRAINT ck_security_identifier_system_time CHECK (system_from < system_to)
    );
    PRINT 'Created dbo.security_identifier';
END
GO

-- Unique: one active identifier value per type+source
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_security_identifier_current_value' AND object_id = OBJECT_ID('dbo.security_identifier'))
    CREATE UNIQUE INDEX ux_security_identifier_current_value
        ON dbo.security_identifier (identifier_type, identifier_value, source_system)
        WHERE is_current = 1 AND is_deleted = 0;
GO

-- Unique: only one primary identifier per type and source per security
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_security_identifier_primary_per_type' AND object_id = OBJECT_ID('dbo.security_identifier'))
    CREATE UNIQUE INDEX ux_security_identifier_primary_per_type
        ON dbo.security_identifier (security_id, identifier_type, source_system)
        WHERE is_current = 1 AND is_deleted = 0 AND is_primary = 1;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_security_identifier_security_id' AND object_id = OBJECT_ID('dbo.security_identifier'))
    CREATE INDEX ix_security_identifier_security_id
        ON dbo.security_identifier (security_id);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_security_identifier_is_current' AND object_id = OBJECT_ID('dbo.security_identifier'))
    CREATE INDEX ix_security_identifier_is_current
        ON dbo.security_identifier (is_current)
        WHERE is_current = 1 AND is_deleted = 0;
GO

-- ── 2. Backfill existing single-identifier rows ───────────────────────────────

INSERT INTO dbo.security_identifier
    (security_id, identifier_type, identifier_value, source_system, is_primary,
     created_at, valid_from, valid_to, system_from, system_to, is_current, is_deleted)
SELECT
    id                                      AS security_id,
    CAST(identifier_type AS NVARCHAR(50))   AS identifier_type,
    identifier_value                        AS identifier_value,
    CAST(data_source AS NVARCHAR(50))       AS source_system,
    1                                       AS is_primary,
    created_at,
    valid_from,
    valid_to,
    system_from,
    system_to,
    is_current,
    is_deleted
FROM dbo.security AS s
WHERE NOT EXISTS (
    SELECT 1
    FROM dbo.security_identifier si
    WHERE si.security_id = s.id
      AND si.is_current  = s.is_current
      AND si.is_deleted  = s.is_deleted
);
GO

-- ── 3. Add currency_code column to dbo.security ───────────────────────────────

IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.security') AND name = 'currency_code')
BEGIN
    ALTER TABLE dbo.security ADD currency_code NVARCHAR(10) NULL;
    PRINT 'Added currency_code column to dbo.security';
END
GO

-- ── 4. Populate currency_code from the existing free-text currency column ─────

UPDATE dbo.security
SET currency_code = c.code
FROM dbo.security s
INNER JOIN dbo.currency c ON c.code = s.currency
WHERE s.currency_code IS NULL
  AND s.currency IS NOT NULL;
GO

-- Add FK only after populating (allows NULL for securities with no valid currency)
IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys
    WHERE name = 'fk_security_currency_code' AND parent_object_id = OBJECT_ID('dbo.security')
)
BEGIN
    ALTER TABLE dbo.security
        ADD CONSTRAINT fk_security_currency_code
        FOREIGN KEY (currency_code) REFERENCES dbo.currency(code);
    PRINT 'Added FK fk_security_currency_code';
END
GO

-- ── 5. Temporal check constraints on dbo.security ────────────────────────────

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_security_valid_time' AND parent_object_id = OBJECT_ID('dbo.security'))
    ALTER TABLE dbo.security ADD CONSTRAINT ck_security_valid_time  CHECK (valid_from  < valid_to);
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_security_system_time' AND parent_object_id = OBJECT_ID('dbo.security'))
    ALTER TABLE dbo.security ADD CONSTRAINT ck_security_system_time CHECK (system_from < system_to);
GO

-- ── 6. Non-blank check constraints on dbo.security ───────────────────────────

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_security_name_not_blank' AND parent_object_id = OBJECT_ID('dbo.security'))
    ALTER TABLE dbo.security ADD CONSTRAINT ck_security_name_not_blank CHECK (LEN(LTRIM(RTRIM(name))) > 0);
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_security_type_not_blank' AND parent_object_id = OBJECT_ID('dbo.security'))
    ALTER TABLE dbo.security ADD CONSTRAINT ck_security_type_not_blank CHECK (LEN(LTRIM(RTRIM(CAST(type AS NVARCHAR(50))))) > 0);
GO

-- ── 7. Replace old identifier-based unique index with search indexes ──────────

-- Drop the old unique index that enforced uniqueness on the single-identifier design
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__security__identifier_type__identifier_value__data_source' AND object_id = OBJECT_ID('dbo.security'))
    DROP INDEX ix__security__identifier_type__identifier_value__data_source ON dbo.security;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_security_name_current' AND object_id = OBJECT_ID('dbo.security'))
    CREATE INDEX ix_security_name_current
        ON dbo.security (name)
        WHERE is_current = 1 AND is_deleted = 0;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_security_currency_code' AND object_id = OBJECT_ID('dbo.security'))
    CREATE INDEX ix_security_currency_code
        ON dbo.security (currency_code)
        WHERE is_current = 1 AND is_deleted = 0;
GO

-- ── 8. Improve derived_rating: FLOAT → DECIMAL for probability columns ────────

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.derived_rating') AND name = 'implied_pd' AND system_type_id = TYPE_ID('float'))
BEGIN
    ALTER TABLE dbo.derived_rating ALTER COLUMN implied_pd DECIMAL(12,10) NULL;
    PRINT 'Changed derived_rating.implied_pd from FLOAT to DECIMAL(12,10)';
END
GO

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.derived_rating') AND name = 'model_pd' AND system_type_id = TYPE_ID('float'))
BEGIN
    ALTER TABLE dbo.derived_rating ALTER COLUMN model_pd DECIMAL(12,10) NULL;
    PRINT 'Changed derived_rating.model_pd from FLOAT to DECIMAL(12,10)';
END
GO

-- ── 9. Improve vendor_rating_metadata: FLOAT → DECIMAL for score columns ─────

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.vendor_rating_metadata') AND name = 'accuracy_score' AND system_type_id = TYPE_ID('float'))
BEGIN
    ALTER TABLE dbo.vendor_rating_metadata ALTER COLUMN accuracy_score   DECIMAL(5,4) NOT NULL;
    ALTER TABLE dbo.vendor_rating_metadata ALTER COLUMN stability_score  DECIMAL(5,4) NOT NULL;
    ALTER TABLE dbo.vendor_rating_metadata ALTER COLUMN timeliness_score DECIMAL(5,4) NOT NULL;
    ALTER TABLE dbo.vendor_rating_metadata ALTER COLUMN coverage_score   DECIMAL(5,4) NOT NULL;
    PRINT 'Changed vendor_rating_metadata score columns from FLOAT to DECIMAL(5,4)';
END
GO

-- ── 10. Add single-value check constraint to dbo.security_attribute_kv ────────

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_security_attribute_kv_single_value' AND parent_object_id = OBJECT_ID('dbo.security_attribute_kv'))
BEGIN
    ALTER TABLE dbo.security_attribute_kv
    ADD CONSTRAINT ck_security_attribute_kv_single_value CHECK (
        (CASE WHEN value_string  IS NOT NULL THEN 1 ELSE 0 END) +
        (CASE WHEN value_decimal IS NOT NULL THEN 1 ELSE 0 END) +
        (CASE WHEN value_int     IS NOT NULL THEN 1 ELSE 0 END) +
        (CASE WHEN value_date    IS NOT NULL THEN 1 ELSE 0 END) +
        (CASE WHEN value_bool    IS NOT NULL THEN 1 ELSE 0 END)
        <= 1
    );
    PRINT 'Added ck_security_attribute_kv_single_value';
END
GO

-- ── 11. Temporal check constraints on child attribute tables ──────────────────

-- security_core_attribute
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_security_core_attribute_valid_time' AND parent_object_id = OBJECT_ID('dbo.security_core_attribute'))
    ALTER TABLE dbo.security_core_attribute ADD CONSTRAINT ck_security_core_attribute_valid_time  CHECK (valid_from  < valid_to);
GO
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_security_core_attribute_system_time' AND parent_object_id = OBJECT_ID('dbo.security_core_attribute'))
    ALTER TABLE dbo.security_core_attribute ADD CONSTRAINT ck_security_core_attribute_system_time CHECK (system_from < system_to);
GO

-- security_loan_attribute
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_security_loan_attribute_valid_time' AND parent_object_id = OBJECT_ID('dbo.security_loan_attribute'))
    ALTER TABLE dbo.security_loan_attribute ADD CONSTRAINT ck_security_loan_attribute_valid_time  CHECK (valid_from  < valid_to);
GO
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_security_loan_attribute_system_time' AND parent_object_id = OBJECT_ID('dbo.security_loan_attribute'))
    ALTER TABLE dbo.security_loan_attribute ADD CONSTRAINT ck_security_loan_attribute_system_time CHECK (system_from < system_to);
GO

-- security_derivative_attribute
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_security_derivative_attribute_valid_time' AND parent_object_id = OBJECT_ID('dbo.security_derivative_attribute'))
    ALTER TABLE dbo.security_derivative_attribute ADD CONSTRAINT ck_security_derivative_attribute_valid_time  CHECK (valid_from  < valid_to);
GO
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_security_derivative_attribute_system_time' AND parent_object_id = OBJECT_ID('dbo.security_derivative_attribute'))
    ALTER TABLE dbo.security_derivative_attribute ADD CONSTRAINT ck_security_derivative_attribute_system_time CHECK (system_from < system_to);
GO

-- security_securitized_attribute
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_security_securitized_attribute_valid_time' AND parent_object_id = OBJECT_ID('dbo.security_securitized_attribute'))
    ALTER TABLE dbo.security_securitized_attribute ADD CONSTRAINT ck_security_securitized_attribute_valid_time  CHECK (valid_from  < valid_to);
GO
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_security_securitized_attribute_system_time' AND parent_object_id = OBJECT_ID('dbo.security_securitized_attribute'))
    ALTER TABLE dbo.security_securitized_attribute ADD CONSTRAINT ck_security_securitized_attribute_system_time CHECK (system_from < system_to);
GO

-- security_attribute_kv
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_security_attribute_kv_valid_time' AND parent_object_id = OBJECT_ID('dbo.security_attribute_kv'))
    ALTER TABLE dbo.security_attribute_kv ADD CONSTRAINT ck_security_attribute_kv_valid_time  CHECK (valid_from  < valid_to);
GO
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'ck_security_attribute_kv_system_time' AND parent_object_id = OBJECT_ID('dbo.security_attribute_kv'))
    ALTER TABLE dbo.security_attribute_kv ADD CONSTRAINT ck_security_attribute_kv_system_time CHECK (system_from < system_to);
GO

PRINT 'Migration 20260420 completed successfully.';
GO
