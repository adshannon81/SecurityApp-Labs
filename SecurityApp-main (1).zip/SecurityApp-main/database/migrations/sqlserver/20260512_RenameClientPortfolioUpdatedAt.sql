USE securityapp_db;
GO
-- Migration: Rename updated_at -> last_modified_at on client and portfolio tables
-- Generated: 2026-05-12
-- These two tables were created before the column-name convention was standardised.
-- The schema files already define last_modified_at; this migration brings the database
-- into alignment so the EF HasColumnName("updated_at") workaround can be removed.

-- client
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.client') AND name = 'updated_at')
BEGIN
    EXEC sp_rename 'dbo.client.updated_at', 'last_modified_at', 'COLUMN';
END
GO

-- portfolio
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.portfolio') AND name = 'updated_at')
BEGIN
    EXEC sp_rename 'dbo.portfolio.updated_at', 'last_modified_at', 'COLUMN';
END
GO
