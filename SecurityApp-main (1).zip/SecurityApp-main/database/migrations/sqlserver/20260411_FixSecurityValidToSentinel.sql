-- ============================================================
-- Migration: 20260411_FixSecurityValidToSentinel
-- Normalises open-ended sentinel in dbo.security from midnight
-- (SQL column-default '9999-12-31 00:00:00') to 23:59:59 to
-- match the C# TemporalEntity.MaxSentinel value, so that
-- dashboard active-count queries return correct results.
-- Safe to re-run (UPDATE only affects rows that still have the
-- midnight sentinel; rows already at 23:59:59 are untouched).
-- ============================================================

SET NOCOUNT ON;
GO

PRINT 'Migration 20260411_FixSecurityValidToSentinel: normalising sentinel dates...';
GO

UPDATE dbo.security
SET    valid_to   = '9999-12-31 23:59:59'
WHERE  valid_to   = '9999-12-31 00:00:00';

PRINT CONCAT('  valid_to   updated: ', @@ROWCOUNT, ' row(s)');
GO

UPDATE dbo.security
SET    system_to  = '9999-12-31 23:59:59'
WHERE  system_to  = '9999-12-31 00:00:00';

PRINT CONCAT('  system_to  updated: ', @@ROWCOUNT, ' row(s)');
GO

-- Fix column defaults so future SQL inserts also use the correct sentinel
ALTER TABLE dbo.security
    DROP CONSTRAINT IF EXISTS df_security_valid_to;
GO
ALTER TABLE dbo.security
    ADD CONSTRAINT df_security_valid_to
    DEFAULT '9999-12-31 23:59:59' FOR valid_to;
GO

ALTER TABLE dbo.security
    DROP CONSTRAINT IF EXISTS df_security_system_to;
GO
ALTER TABLE dbo.security
    ADD CONSTRAINT df_security_system_to
    DEFAULT '9999-12-31 23:59:59' FOR system_to;
GO

PRINT 'Migration 20260411_FixSecurityValidToSentinel: complete.';
GO
