USE securityapp_db;
GO
SET QUOTED_IDENTIFIER ON; SET ANSI_NULLS ON;
GO

-- Migration 2D (finalize): promote free-text security.issuer to issuer master, then drop the column.
-- The issuer / issuer_identifier / issuer_relationship tables and the issuer_id FK column on security
-- were created as part of the initial schema deployment. Only the data migration and column drop remain.

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.security') AND name = 'issuer')
BEGIN
    -- Step 1: seed any remaining free-text issuers that have no issuer_id yet.
    INSERT INTO dbo.issuer (legal_name, created_at, valid_from, system_from)
    SELECT DISTINCT LTRIM(RTRIM(issuer)), GETUTCDATE(), GETUTCDATE(), GETUTCDATE()
    FROM dbo.security
    WHERE issuer IS NOT NULL AND LTRIM(RTRIM(issuer)) <> ''
      AND issuer_id IS NULL
      AND NOT EXISTS (
          SELECT 1 FROM dbo.issuer i
          WHERE i.legal_name = LTRIM(RTRIM(dbo.security.issuer)) AND i.is_current = 1
      );

    -- Step 2: link any unlinked securities to their issuer master rows.
    UPDATE s
    SET s.issuer_id = i.id, s.updated_at = GETUTCDATE()
    FROM dbo.security s
    INNER JOIN dbo.issuer i ON i.legal_name = LTRIM(RTRIM(s.issuer)) AND i.is_current = 1
    WHERE s.issuer IS NOT NULL AND s.issuer_id IS NULL;

    -- Step 3: drop the legacy free-text column.
    ALTER TABLE dbo.security DROP COLUMN issuer;
END
GO
