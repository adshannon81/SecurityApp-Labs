-- ── Flatten Main Navigation Group ─────────────────────────────────────────
-- Reparents all children of group.main to root level and deactivates the
-- group.main wrapper. This corrects data seeded by SeedData_SqlServer.sql
-- before 20260428_SeedNavAppResources.sql introduced the flat structure.

DECLARE @grpMain  UNIQUEIDENTIFIER = (SELECT id FROM dbo.app_resource WHERE resource_key = 'group.main'  AND is_current = 1 AND is_deleted = 0);
DECLARE @grpAdmin UNIQUEIDENTIFIER = (SELECT id FROM dbo.app_resource WHERE resource_key = 'group.admin' AND is_current = 1 AND is_deleted = 0);

-- Only run if group.main still exists
IF @grpMain IS NOT NULL
BEGIN
    -- 1. Reparent all direct children of group.main to root (NULL parent)
    --    Use the sort_order from 20260428 as the authoritative order where the
    --    resource_key matches; otherwise keep existing sort_order.
    UPDATE dbo.app_resource
    SET parent_app_resource_id = NULL,
        sort_order = CASE resource_key
            WHEN 'nav.dashboard'  THEN 10
            WHEN 'nav.securities' THEN 20
            WHEN 'nav.issuers'    THEN 30
            WHEN 'nav.ratings'    THEN 40
            WHEN 'nav.pricing'    THEN 50
            WHEN 'nav.imports'    THEN 60
            WHEN 'nav.jobs'       THEN 70
            WHEN 'nav.workflows'  THEN 80
            WHEN 'nav.history'    THEN 90
            WHEN 'nav.settings'   THEN 100
            ELSE sort_order
        END,
        updated_at = SYSUTCDATETIME()
    WHERE parent_app_resource_id = @grpMain
      AND is_current = 1
      AND is_deleted = 0
      AND resource_type IN ('MENU_ITEM', 'MENU_GROUP');

    -- 2. Deactivate group.main (soft delete — keep the row for audit)
    UPDATE dbo.app_resource
    SET is_active   = 0,
        is_deleted  = 1,
        is_current  = 0,
        updated_at  = SYSUTCDATETIME()
    WHERE id = @grpMain;
END

-- Deactivate old group.admin if it still exists (replaced by nav.admin)
IF @grpAdmin IS NOT NULL
BEGIN
    UPDATE dbo.app_resource
    SET is_active  = 0,
        is_deleted = 1,
        is_current = 0,
        updated_at = SYSUTCDATETIME()
    WHERE id = @grpAdmin;
END
