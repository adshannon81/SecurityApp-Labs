-- ============================================================
-- Migration: Rename all business tables to singular form
-- Date:      2026-04-11
-- Purpose:   Align existing database objects with the updated
--            schema convention (singular table names, singular
--            index/constraint names, lowercase snake_case).
-- Run once against each environment that was created before
-- the schema rename.  Idempotent — each step checks for the
-- old name before acting.
-- ============================================================

SET NOCOUNT ON;
GO

-- ============================================================
-- STEP 1 — Rename tables
-- ============================================================
-- Helper: only rename when the old name exists and the new
-- one does NOT yet exist (safe to re-run).

IF OBJECT_ID('dbo.securities',                    'U') IS NOT NULL AND OBJECT_ID('dbo.security',                    'U') IS NULL  EXEC sp_rename 'dbo.securities',                    'security';
IF OBJECT_ID('dbo.prices',                        'U') IS NOT NULL AND OBJECT_ID('dbo.price',                       'U') IS NULL  EXEC sp_rename 'dbo.prices',                        'price';
IF OBJECT_ID('dbo.pricing_rules',                 'U') IS NOT NULL AND OBJECT_ID('dbo.pricing_rule',                'U') IS NULL  EXEC sp_rename 'dbo.pricing_rules',                 'pricing_rule';
IF OBJECT_ID('dbo.derived_prices',                'U') IS NOT NULL AND OBJECT_ID('dbo.derived_price',               'U') IS NULL  EXEC sp_rename 'dbo.derived_prices',                'derived_price';
IF OBJECT_ID('dbo.security_attributes',           'U') IS NOT NULL AND OBJECT_ID('dbo.security_attribute',          'U') IS NULL  EXEC sp_rename 'dbo.security_attributes',           'security_attribute';
IF OBJECT_ID('dbo.audit_logs',                    'U') IS NOT NULL AND OBJECT_ID('dbo.audit_log',                   'U') IS NULL  EXEC sp_rename 'dbo.audit_logs',                    'audit_log';
IF OBJECT_ID('dbo.import_requests',               'U') IS NOT NULL AND OBJECT_ID('dbo.import_request',              'U') IS NULL  EXEC sp_rename 'dbo.import_requests',               'import_request';
IF OBJECT_ID('dbo.credit_ratings',                'U') IS NOT NULL AND OBJECT_ID('dbo.credit_rating',               'U') IS NULL  EXEC sp_rename 'dbo.credit_ratings',                'credit_rating';
IF OBJECT_ID('dbo.derived_ratings',               'U') IS NOT NULL AND OBJECT_ID('dbo.derived_rating',              'U') IS NULL  EXEC sp_rename 'dbo.derived_ratings',               'derived_rating';
IF OBJECT_ID('dbo.rating_scale_entries',          'U') IS NOT NULL AND OBJECT_ID('dbo.rating_scale_entry',          'U') IS NULL  EXEC sp_rename 'dbo.rating_scale_entries',          'rating_scale_entry';
IF OBJECT_ID('dbo.rating_derivation_rules',       'U') IS NOT NULL AND OBJECT_ID('dbo.rating_derivation_rule',      'U') IS NULL  EXEC sp_rename 'dbo.rating_derivation_rules',       'rating_derivation_rule';
IF OBJECT_ID('dbo.formula_macros',                'U') IS NOT NULL AND OBJECT_ID('dbo.formula_macro',               'U') IS NULL  EXEC sp_rename 'dbo.formula_macros',                'formula_macro';
IF OBJECT_ID('dbo.import_profiles',               'U') IS NOT NULL AND OBJECT_ID('dbo.import_profile',              'U') IS NULL  EXEC sp_rename 'dbo.import_profiles',               'import_profile';
IF OBJECT_ID('dbo.import_profile_columns',        'U') IS NOT NULL AND OBJECT_ID('dbo.import_profile_column',       'U') IS NULL  EXEC sp_rename 'dbo.import_profile_columns',        'import_profile_column';
IF OBJECT_ID('dbo.import_profile_column_validations','U') IS NOT NULL AND OBJECT_ID('dbo.import_profile_column_validation','U') IS NULL  EXEC sp_rename 'dbo.import_profile_column_validations','import_profile_column_validation';
IF OBJECT_ID('dbo.import_profile_row_validations','U') IS NOT NULL AND OBJECT_ID('dbo.import_profile_row_validation','U') IS NULL  EXEC sp_rename 'dbo.import_profile_row_validations','import_profile_row_validation';
IF OBJECT_ID('dbo.job_schedules',                 'U') IS NOT NULL AND OBJECT_ID('dbo.job_schedule',                'U') IS NULL  EXEC sp_rename 'dbo.job_schedules',                 'job_schedule';
IF OBJECT_ID('dbo.approval_requests',             'U') IS NOT NULL AND OBJECT_ID('dbo.approval_request',            'U') IS NULL  EXEC sp_rename 'dbo.approval_requests',             'approval_request';
IF OBJECT_ID('dbo.workflow_definitions',          'U') IS NOT NULL AND OBJECT_ID('dbo.workflow_definition',         'U') IS NULL  EXEC sp_rename 'dbo.workflow_definitions',          'workflow_definition';
IF OBJECT_ID('dbo.workflow_definition_steps',     'U') IS NOT NULL AND OBJECT_ID('dbo.workflow_definition_step',    'U') IS NULL  EXEC sp_rename 'dbo.workflow_definition_steps',     'workflow_definition_step';
IF OBJECT_ID('dbo.workflow_instances',            'U') IS NOT NULL AND OBJECT_ID('dbo.workflow_instance',           'U') IS NULL  EXEC sp_rename 'dbo.workflow_instances',            'workflow_instance';
IF OBJECT_ID('dbo.workflow_step_instances',       'U') IS NOT NULL AND OBJECT_ID('dbo.workflow_step_instance',      'U') IS NULL  EXEC sp_rename 'dbo.workflow_step_instances',       'workflow_step_instance';
IF OBJECT_ID('dbo.workflow_step_approvals',       'U') IS NOT NULL AND OBJECT_ID('dbo.workflow_step_approval',      'U') IS NULL  EXEC sp_rename 'dbo.workflow_step_approvals',       'workflow_step_approval';
IF OBJECT_ID('dbo.clients',                       'U') IS NOT NULL AND OBJECT_ID('dbo.client',                      'U') IS NULL  EXEC sp_rename 'dbo.clients',                       'client';
IF OBJECT_ID('dbo.portfolios',                    'U') IS NOT NULL AND OBJECT_ID('dbo.portfolio',                   'U') IS NULL  EXEC sp_rename 'dbo.portfolios',                    'portfolio';
IF OBJECT_ID('dbo.positions',                     'U') IS NOT NULL AND OBJECT_ID('dbo.position',                    'U') IS NULL  EXEC sp_rename 'dbo.positions',                     'position';
IF OBJECT_ID('dbo.field_visibility_rules',        'U') IS NOT NULL AND OBJECT_ID('dbo.field_visibility_rule',       'U') IS NULL  EXEC sp_rename 'dbo.field_visibility_rules',        'field_visibility_rule';
GO

PRINT 'Step 1 complete — tables renamed.';
GO

-- ============================================================
-- STEP 2 — Rename indexes
-- sp_rename indexes via 'table.index_name', 'new_name', 'INDEX'
-- Only acts when old index exists on the (now-renamed) table.
-- ============================================================

-- security
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__securities__identifier_type__identifier_value__data_source' AND object_id = OBJECT_ID('dbo.security'))
    EXEC sp_rename N'dbo.security.ix__securities__identifier_type__identifier_value__data_source', N'ix__security__identifier_type__identifier_value__data_source', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__securities__is_current'  AND object_id = OBJECT_ID('dbo.security'))
    EXEC sp_rename N'dbo.security.ix__securities__is_current',  N'ix__security__is_current',  N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__securities__valid_time'  AND object_id = OBJECT_ID('dbo.security'))
    EXEC sp_rename N'dbo.security.ix__securities__valid_time',  N'ix__security__valid_time',  N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__securities__system_time' AND object_id = OBJECT_ID('dbo.security'))
    EXEC sp_rename N'dbo.security.ix__securities__system_time', N'ix__security__system_time', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__securities__is_deleted'  AND object_id = OBJECT_ID('dbo.security'))
    EXEC sp_rename N'dbo.security.ix__securities__is_deleted',  N'ix__security__is_deleted',  N'INDEX';
GO

-- price
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__prices__security_id__source__price_date' AND object_id = OBJECT_ID('dbo.price'))
    EXEC sp_rename N'dbo.price.ix__prices__security_id__source__price_date', N'ix__price__security_id__source__price_date', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__prices__is_current'  AND object_id = OBJECT_ID('dbo.price'))
    EXEC sp_rename N'dbo.price.ix__prices__is_current',  N'ix__price__is_current',  N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__prices__valid_time'  AND object_id = OBJECT_ID('dbo.price'))
    EXEC sp_rename N'dbo.price.ix__prices__valid_time',  N'ix__price__valid_time',  N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__prices__system_time' AND object_id = OBJECT_ID('dbo.price'))
    EXEC sp_rename N'dbo.price.ix__prices__system_time', N'ix__price__system_time', N'INDEX';
GO

-- audit_log
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__audit_logs__created_at' AND object_id = OBJECT_ID('dbo.audit_log'))
    EXEC sp_rename N'dbo.audit_log.ix__audit_logs__created_at', N'ix__audit_log__created_at', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__audit_logs__user_id' AND object_id = OBJECT_ID('dbo.audit_log'))
    EXEC sp_rename N'dbo.audit_log.ix__audit_logs__user_id', N'ix__audit_log__user_id', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__audit_logs__entity_type_entity_id' AND object_id = OBJECT_ID('dbo.audit_log'))
    EXEC sp_rename N'dbo.audit_log.ix__audit_logs__entity_type_entity_id', N'ix__audit_log__entity_type_entity_id', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__audit_logs__correlation_id' AND object_id = OBJECT_ID('dbo.audit_log'))
    EXEC sp_rename N'dbo.audit_log.ix__audit_logs__correlation_id', N'ix__audit_log__correlation_id', N'INDEX';
GO

-- import_request
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__import_requests__status' AND object_id = OBJECT_ID('dbo.import_request'))
    EXEC sp_rename N'dbo.import_request.ix__import_requests__status', N'ix__import_request__status', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__import_requests__created_at' AND object_id = OBJECT_ID('dbo.import_request'))
    EXEC sp_rename N'dbo.import_request.ix__import_requests__created_at', N'ix__import_request__created_at', N'INDEX';
GO

-- credit_rating
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__credit_ratings__security_id__agency__rating_type__is_current' AND object_id = OBJECT_ID('dbo.credit_rating'))
    EXEC sp_rename N'dbo.credit_rating.ix__credit_ratings__security_id__agency__rating_type__is_current', N'ix__credit_rating__security_id__agency__rating_type__is_current', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__credit_ratings__valid_time' AND object_id = OBJECT_ID('dbo.credit_rating'))
    EXEC sp_rename N'dbo.credit_rating.ix__credit_ratings__valid_time',  N'ix__credit_rating__valid_time',  N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__credit_ratings__system_time' AND object_id = OBJECT_ID('dbo.credit_rating'))
    EXEC sp_rename N'dbo.credit_rating.ix__credit_ratings__system_time', N'ix__credit_rating__system_time', N'INDEX';
GO

-- derived_rating
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__derived_ratings__security_id' AND object_id = OBJECT_ID('dbo.derived_rating'))
    EXEC sp_rename N'dbo.derived_rating.ix__derived_ratings__security_id',       N'ix__derived_rating__security_id',       N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__derived_ratings__security__current' AND object_id = OBJECT_ID('dbo.derived_rating'))
    EXEC sp_rename N'dbo.derived_rating.ix__derived_ratings__security__current', N'ix__derived_rating__security__current', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__derived_ratings__valid_time' AND object_id = OBJECT_ID('dbo.derived_rating'))
    EXEC sp_rename N'dbo.derived_rating.ix__derived_ratings__valid_time',        N'ix__derived_rating__valid_time',        N'INDEX';
GO

-- import_profile
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'uix__import_profiles__name__source_type' AND object_id = OBJECT_ID('dbo.import_profile'))
    EXEC sp_rename N'dbo.import_profile.uix__import_profiles__name__source_type', N'uix__import_profile__name__source_type', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__import_profiles__source_type__is_active' AND object_id = OBJECT_ID('dbo.import_profile'))
    EXEC sp_rename N'dbo.import_profile.ix__import_profiles__source_type__is_active', N'ix__import_profile__source_type__is_active', N'INDEX';
GO

-- import_profile_column
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__import_profile_columns__profile_id' AND object_id = OBJECT_ID('dbo.import_profile_column'))
    EXEC sp_rename N'dbo.import_profile_column.ix__import_profile_columns__profile_id', N'ix__import_profile_column__profile_id', N'INDEX';
GO

-- import_profile_column_validation
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__import_profile_column_validations__column_id' AND object_id = OBJECT_ID('dbo.import_profile_column_validation'))
    EXEC sp_rename N'dbo.import_profile_column_validation.ix__import_profile_column_validations__column_id', N'ix__import_profile_column_validation__column_id', N'INDEX';
GO

-- import_profile_row_validation
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__import_profile_row_validations__profile_id' AND object_id = OBJECT_ID('dbo.import_profile_row_validation'))
    EXEC sp_rename N'dbo.import_profile_row_validation.ix__import_profile_row_validations__profile_id', N'ix__import_profile_row_validation__profile_id', N'INDEX';
GO

-- rating_scale_entry
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__rating_scale_entries__agency__score' AND object_id = OBJECT_ID('dbo.rating_scale_entry'))
    EXEC sp_rename N'dbo.rating_scale_entry.ix__rating_scale_entries__agency__score', N'ix__rating_scale_entry__agency__score', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__rating_scale_entries__valid_time' AND object_id = OBJECT_ID('dbo.rating_scale_entry'))
    EXEC sp_rename N'dbo.rating_scale_entry.ix__rating_scale_entries__valid_time', N'ix__rating_scale_entry__valid_time', N'INDEX';
GO

-- rating_derivation_rule
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__rating_derivation_rules__model_type' AND object_id = OBJECT_ID('dbo.rating_derivation_rule'))
    EXEC sp_rename N'dbo.rating_derivation_rule.ix__rating_derivation_rules__model_type', N'ix__rating_derivation_rule__model_type', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__rating_derivation_rules__valid_time' AND object_id = OBJECT_ID('dbo.rating_derivation_rule'))
    EXEC sp_rename N'dbo.rating_derivation_rule.ix__rating_derivation_rules__valid_time', N'ix__rating_derivation_rule__valid_time', N'INDEX';
GO

-- formula_macro
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__formula_macros__name__current' AND object_id = OBJECT_ID('dbo.formula_macro'))
    EXEC sp_rename N'dbo.formula_macro.ix__formula_macros__name__current', N'ix__formula_macro__name__current', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__formula_macros__valid_time' AND object_id = OBJECT_ID('dbo.formula_macro'))
    EXEC sp_rename N'dbo.formula_macro.ix__formula_macros__valid_time', N'ix__formula_macro__valid_time', N'INDEX';
GO

-- job_schedule
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__job_schedules__plugin_name' AND object_id = OBJECT_ID('dbo.job_schedule'))
    EXEC sp_rename N'dbo.job_schedule.ix__job_schedules__plugin_name', N'ix__job_schedule__plugin_name', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__job_schedules__is_current' AND object_id = OBJECT_ID('dbo.job_schedule'))
    EXEC sp_rename N'dbo.job_schedule.ix__job_schedules__is_current',  N'ix__job_schedule__is_current',  N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__job_schedules__system_time' AND object_id = OBJECT_ID('dbo.job_schedule'))
    EXEC sp_rename N'dbo.job_schedule.ix__job_schedules__system_time', N'ix__job_schedule__system_time', N'INDEX';
GO

-- approval_request (inline indexes created in original BEGIN block)
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_approval_requests_status' AND object_id = OBJECT_ID('dbo.approval_request'))
    EXEC sp_rename N'dbo.approval_request.IX_approval_requests_status', N'ix_approval_request_status', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_approval_requests_requested_at' AND object_id = OBJECT_ID('dbo.approval_request'))
    EXEC sp_rename N'dbo.approval_request.IX_approval_requests_requested_at', N'ix_approval_request_requested_at', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__approval_requests__is_current' AND object_id = OBJECT_ID('dbo.approval_request'))
    EXEC sp_rename N'dbo.approval_request.ix__approval_requests__is_current', N'ix__approval_request__is_current', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__approval_requests__is_deleted' AND object_id = OBJECT_ID('dbo.approval_request'))
    EXEC sp_rename N'dbo.approval_request.ix__approval_requests__is_deleted', N'ix__approval_request__is_deleted', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__approval_requests__valid_time' AND object_id = OBJECT_ID('dbo.approval_request'))
    EXEC sp_rename N'dbo.approval_request.ix__approval_requests__valid_time', N'ix__approval_request__valid_time', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__approval_requests__system_time' AND object_id = OBJECT_ID('dbo.approval_request'))
    EXEC sp_rename N'dbo.approval_request.ix__approval_requests__system_time', N'ix__approval_request__system_time', N'INDEX';
GO

-- workflow_definition
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_workflow_definitions_trigger_type' AND object_id = OBJECT_ID('dbo.workflow_definition'))
    EXEC sp_rename N'dbo.workflow_definition.IX_workflow_definitions_trigger_type', N'ix_workflow_definition_trigger_type', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_workflow_definitions_is_enabled' AND object_id = OBJECT_ID('dbo.workflow_definition'))
    EXEC sp_rename N'dbo.workflow_definition.IX_workflow_definitions_is_enabled', N'ix_workflow_definition_is_enabled', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_definitions__is_current' AND object_id = OBJECT_ID('dbo.workflow_definition'))
    EXEC sp_rename N'dbo.workflow_definition.ix__workflow_definitions__is_current', N'ix__workflow_definition__is_current', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_definitions__is_deleted' AND object_id = OBJECT_ID('dbo.workflow_definition'))
    EXEC sp_rename N'dbo.workflow_definition.ix__workflow_definitions__is_deleted', N'ix__workflow_definition__is_deleted', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_definitions__valid_time' AND object_id = OBJECT_ID('dbo.workflow_definition'))
    EXEC sp_rename N'dbo.workflow_definition.ix__workflow_definitions__valid_time', N'ix__workflow_definition__valid_time', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_definitions__system_time' AND object_id = OBJECT_ID('dbo.workflow_definition'))
    EXEC sp_rename N'dbo.workflow_definition.ix__workflow_definitions__system_time', N'ix__workflow_definition__system_time', N'INDEX';
GO

-- workflow_definition_step
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_workflow_definition_steps_definition_id' AND object_id = OBJECT_ID('dbo.workflow_definition_step'))
    EXEC sp_rename N'dbo.workflow_definition_step.IX_workflow_definition_steps_definition_id', N'ix_workflow_definition_step_definition_id', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_workflow_definition_steps_definition_order' AND object_id = OBJECT_ID('dbo.workflow_definition_step'))
    EXEC sp_rename N'dbo.workflow_definition_step.IX_workflow_definition_steps_definition_order', N'ix_workflow_definition_step_definition_order', N'INDEX';
GO

-- workflow_instance
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_workflow_instances_status' AND object_id = OBJECT_ID('dbo.workflow_instance'))
    EXEC sp_rename N'dbo.workflow_instance.IX_workflow_instances_status', N'ix_workflow_instance_status', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_workflow_instances_entity_id' AND object_id = OBJECT_ID('dbo.workflow_instance'))
    EXEC sp_rename N'dbo.workflow_instance.IX_workflow_instances_entity_id', N'ix_workflow_instance_entity_id', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_workflow_instances_trigger_entity' AND object_id = OBJECT_ID('dbo.workflow_instance'))
    EXEC sp_rename N'dbo.workflow_instance.IX_workflow_instances_trigger_entity', N'ix_workflow_instance_trigger_entity', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_instances__is_current' AND object_id = OBJECT_ID('dbo.workflow_instance'))
    EXEC sp_rename N'dbo.workflow_instance.ix__workflow_instances__is_current', N'ix__workflow_instance__is_current', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_instances__is_deleted' AND object_id = OBJECT_ID('dbo.workflow_instance'))
    EXEC sp_rename N'dbo.workflow_instance.ix__workflow_instances__is_deleted', N'ix__workflow_instance__is_deleted', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_instances__valid_time' AND object_id = OBJECT_ID('dbo.workflow_instance'))
    EXEC sp_rename N'dbo.workflow_instance.ix__workflow_instances__valid_time', N'ix__workflow_instance__valid_time', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_instances__system_time' AND object_id = OBJECT_ID('dbo.workflow_instance'))
    EXEC sp_rename N'dbo.workflow_instance.ix__workflow_instances__system_time', N'ix__workflow_instance__system_time', N'INDEX';
GO

-- workflow_step_instance
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_workflow_step_instances_instance_id' AND object_id = OBJECT_ID('dbo.workflow_step_instance'))
    EXEC sp_rename N'dbo.workflow_step_instance.IX_workflow_step_instances_instance_id', N'ix_workflow_step_instance_instance_id', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_workflow_step_instances_status' AND object_id = OBJECT_ID('dbo.workflow_step_instance'))
    EXEC sp_rename N'dbo.workflow_step_instance.IX_workflow_step_instances_status', N'ix_workflow_step_instance_status', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_workflow_step_instances_role_status' AND object_id = OBJECT_ID('dbo.workflow_step_instance'))
    EXEC sp_rename N'dbo.workflow_step_instance.IX_workflow_step_instances_role_status', N'ix_workflow_step_instance_role_status', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_step_instances__is_current' AND object_id = OBJECT_ID('dbo.workflow_step_instance'))
    EXEC sp_rename N'dbo.workflow_step_instance.ix__workflow_step_instances__is_current', N'ix__workflow_step_instance__is_current', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_step_instances__is_deleted' AND object_id = OBJECT_ID('dbo.workflow_step_instance'))
    EXEC sp_rename N'dbo.workflow_step_instance.ix__workflow_step_instances__is_deleted', N'ix__workflow_step_instance__is_deleted', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_step_instances__valid_time' AND object_id = OBJECT_ID('dbo.workflow_step_instance'))
    EXEC sp_rename N'dbo.workflow_step_instance.ix__workflow_step_instances__valid_time', N'ix__workflow_step_instance__valid_time', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix__workflow_step_instances__system_time' AND object_id = OBJECT_ID('dbo.workflow_step_instance'))
    EXEC sp_rename N'dbo.workflow_step_instance.ix__workflow_step_instances__system_time', N'ix__workflow_step_instance__system_time', N'INDEX';
GO

-- workflow_step_approval
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_workflow_step_approvals_instance_id' AND object_id = OBJECT_ID('dbo.workflow_step_approval'))
    EXEC sp_rename N'dbo.workflow_step_approval.IX_workflow_step_approvals_instance_id', N'ix_workflow_step_approval_instance_id', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_workflow_step_approvals_decision_at' AND object_id = OBJECT_ID('dbo.workflow_step_approval'))
    EXEC sp_rename N'dbo.workflow_step_approval.IX_workflow_step_approvals_decision_at', N'ix_workflow_step_approval_decision_at', N'INDEX';
GO

-- portfolio
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_portfolios_client_id' AND object_id = OBJECT_ID('dbo.portfolio'))
    EXEC sp_rename N'dbo.portfolio.ix_portfolios_client_id', N'ix_portfolio_client_id', N'INDEX';
GO

-- position
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_positions_portfolio_id' AND object_id = OBJECT_ID('dbo.position'))
    EXEC sp_rename N'dbo.position.ix_positions_portfolio_id', N'ix_position_portfolio_id', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_positions_security_id' AND object_id = OBJECT_ID('dbo.position'))
    EXEC sp_rename N'dbo.position.ix_positions_security_id', N'ix_position_security_id', N'INDEX';
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_positions_status' AND object_id = OBJECT_ID('dbo.position'))
    EXEC sp_rename N'dbo.position.ix_positions_status', N'ix_position_status', N'INDEX';
GO

-- field_visibility_rule
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_field_visibility_rules_entity_type' AND object_id = OBJECT_ID('dbo.field_visibility_rule'))
    EXEC sp_rename N'dbo.field_visibility_rule.ix_field_visibility_rules_entity_type', N'ix_field_visibility_rule_entity_type', N'INDEX';
GO

PRINT 'Step 2 complete — indexes renamed.';
GO

-- ============================================================
-- STEP 3 — Rename FK and UQ constraint names
-- SQL Server does not have a built-in sp_rename for constraints;
-- use the indirect metadata approach.
-- ============================================================

-- Rename inline constraints (recreate is the only safe way for
-- CHECK/FK constraints; for simple renames on same columns we
-- drop-and-recreate with transaction).

-- fk_price_security (was FK_Prices_Securities)
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_Prices_Securities' AND parent_object_id = OBJECT_ID('dbo.price'))
BEGIN
    ALTER TABLE dbo.price DROP CONSTRAINT FK_Prices_Securities;
    ALTER TABLE dbo.price ADD CONSTRAINT fk_price_security FOREIGN KEY (security_id) REFERENCES dbo.security (id) ON DELETE CASCADE;
END
GO

-- fk_derived_price_security (was FK_DerivedPrices_Securities)
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_DerivedPrices_Securities' AND parent_object_id = OBJECT_ID('dbo.derived_price'))
BEGIN
    ALTER TABLE dbo.derived_price DROP CONSTRAINT FK_DerivedPrices_Securities;
    ALTER TABLE dbo.derived_price ADD CONSTRAINT fk_derived_price_security FOREIGN KEY (security_id) REFERENCES dbo.security (id) ON DELETE CASCADE;
END
GO

-- fk_derived_price_pricing_rule (was FK_DerivedPrices_PricingRules)
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_DerivedPrices_PricingRules' AND parent_object_id = OBJECT_ID('dbo.derived_price'))
BEGIN
    ALTER TABLE dbo.derived_price DROP CONSTRAINT FK_DerivedPrices_PricingRules;
    ALTER TABLE dbo.derived_price ADD CONSTRAINT fk_derived_price_pricing_rule FOREIGN KEY (pricing_rule_id) REFERENCES dbo.pricing_rule (id);
END
GO

-- fk_security_attribute_security (was FK_SecurityAttributes_Securities)
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_SecurityAttributes_Securities' AND parent_object_id = OBJECT_ID('dbo.security_attribute'))
BEGIN
    ALTER TABLE dbo.security_attribute DROP CONSTRAINT FK_SecurityAttributes_Securities;
    ALTER TABLE dbo.security_attribute ADD CONSTRAINT fk_security_attribute_security FOREIGN KEY (security_id) REFERENCES dbo.security (id) ON DELETE CASCADE;
END
GO

-- fk_credit_rating_security (was FK_CreditRatings_Securities)
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_CreditRatings_Securities' AND parent_object_id = OBJECT_ID('dbo.credit_rating'))
BEGIN
    ALTER TABLE dbo.credit_rating DROP CONSTRAINT FK_CreditRatings_Securities;
    ALTER TABLE dbo.credit_rating ADD CONSTRAINT fk_credit_rating_security FOREIGN KEY (security_id) REFERENCES dbo.security (id) ON DELETE CASCADE;
END
GO

-- fk_derived_rating_security (was FK_DerivedRatings_Securities)
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_DerivedRatings_Securities' AND parent_object_id = OBJECT_ID('dbo.derived_rating'))
BEGIN
    ALTER TABLE dbo.derived_rating DROP CONSTRAINT FK_DerivedRatings_Securities;
    ALTER TABLE dbo.derived_rating ADD CONSTRAINT fk_derived_rating_security FOREIGN KEY (security_id) REFERENCES dbo.security (id) ON DELETE CASCADE;
END
GO

-- uq_vendor_rating_metadata_vendor_name (was UQ_VendorRatingMetadata_VendorName)
IF EXISTS (SELECT 1 FROM sys.key_constraints WHERE name = 'UQ_VendorRatingMetadata_VendorName' AND parent_object_id = OBJECT_ID('dbo.vendor_rating_metadata'))
BEGIN
    ALTER TABLE dbo.vendor_rating_metadata DROP CONSTRAINT UQ_VendorRatingMetadata_VendorName;
    ALTER TABLE dbo.vendor_rating_metadata ADD CONSTRAINT uq_vendor_rating_metadata_vendor_name UNIQUE (vendor_name);
END
GO

PRINT 'Step 3 complete — FK and UQ constraints renamed.';
GO

-- ============================================================
-- Record this migration
-- ============================================================
IF NOT EXISTS (SELECT 1 FROM dbo.[__SchemaVersions] WHERE version = '1.1-singular-rename')
BEGIN
    INSERT INTO dbo.[__SchemaVersions] (version, description, script_name)
    VALUES ('1.1-singular-rename',
            'Rename all business tables, indexes and constraints from plural to singular form',
            '20260411_RenameTablesToSingular.sql');
END
GO

PRINT 'Migration 20260411_RenameTablesToSingular complete.';
GO
