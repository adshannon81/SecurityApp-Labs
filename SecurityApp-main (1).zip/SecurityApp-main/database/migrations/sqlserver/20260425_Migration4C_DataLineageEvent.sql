-- ============================================================
-- Migration 4C — data_lineage_event (golden source audit trail)
-- Append-only: no TemporalEntity columns.
-- ============================================================

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'data_lineage_event' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.data_lineage_event (
        id                  UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        security_id         UNIQUEIDENTIFIER NOT NULL,
        field_name          NVARCHAR(100)    NOT NULL,
        field_value         NVARCHAR(500)    NULL,
        source_type         NVARCHAR(20)     NOT NULL,
        -- 'VENDOR' | 'MANUAL_OVERRIDE' | 'SYSTEM_DEFAULT' | 'DERIVED'
        vendor_source_id    UNIQUEIDENTIFIER NULL,
        feed_batch_id       NVARCHAR(200)    NULL,
        resolution_rule     NVARCHAR(100)    NULL,
        runner_up_vendor_id UNIQUEIDENTIFIER NULL,
        runner_up_value     NVARCHAR(500)    NULL,
        override_user_id    NVARCHAR(255)    NULL,
        override_reason     NVARCHAR(500)    NULL,
        resolved_at         DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        created_at          DATETIME2(3)     NOT NULL DEFAULT GETUTCDATE(),
        -- No TemporalEntity: append-only
        CONSTRAINT pk_data_lineage_event PRIMARY KEY (id),
        CONSTRAINT fk_dle_security      FOREIGN KEY (security_id)         REFERENCES dbo.security     (id),
        CONSTRAINT fk_dle_vendor        FOREIGN KEY (vendor_source_id)    REFERENCES dbo.vendor_source (id),
        CONSTRAINT fk_dle_runner_up     FOREIGN KEY (runner_up_vendor_id) REFERENCES dbo.vendor_source (id),
        CONSTRAINT ck_dle_source_type   CHECK (source_type IN ('VENDOR','MANUAL_OVERRIDE','SYSTEM_DEFAULT','DERIVED'))
    );
    CREATE INDEX ix_dle_security_id        ON dbo.data_lineage_event (security_id);
    CREATE INDEX ix_dle_source_type        ON dbo.data_lineage_event (source_type);
    CREATE INDEX ix_dle_security_field_date ON dbo.data_lineage_event (security_id, field_name, resolved_at DESC);
END
GO
