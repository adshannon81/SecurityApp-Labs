-- ============================================================
-- Migration: AddFieldGroupAndEntityScreenTables
-- Recreates field_group, field_group_member, and entity_screen
-- tables that were dropped in 20260414_SimplifyAdminSchema.sql.
-- ============================================================

-- ── field_group ──────────────────────────────────────────────────────────────

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'field_group' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    PRINT 'Creating dbo.field_group';
    CREATE TABLE dbo.field_group (
        id                          UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID()
                                        CONSTRAINT PK_field_group PRIMARY KEY,
        field_visibility_entity_id  UNIQUEIDENTIFIER NOT NULL,
        group_key                   NVARCHAR(100)    NOT NULL,
        display_name                NVARCHAR(200)    NOT NULL,
        description                 NVARCHAR(MAX)    NULL,
        sort_order                  INT              NOT NULL DEFAULT 0,
        is_active                   BIT              NOT NULL DEFAULT 1,
        -- BaseEntity
        created_by                  NVARCHAR(200)    NULL,
        created_at                  DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        updated_by                  NVARCHAR(200)    NULL,
        updated_at                  DATETIME2        NULL,
        -- TemporalEntity
        valid_from                  DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        valid_to                    DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from                 DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        system_to                   DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current                  BIT              NOT NULL DEFAULT 1,
        is_deleted                  BIT              NOT NULL DEFAULT 0,
        modified_by                 NVARCHAR(200)    NULL,
        CONSTRAINT FK_field_group_entity FOREIGN KEY (field_visibility_entity_id)
            REFERENCES dbo.field_visibility_entity(id)
    );
    CREATE UNIQUE INDEX UX_field_group_key ON dbo.field_group(group_key)
        WHERE is_current = 1 AND is_deleted = 0;
    PRINT 'Created dbo.field_group';
END
ELSE
    PRINT 'dbo.field_group already exists — skipping.';
GO

-- ── field_group_member ───────────────────────────────────────────────────────

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'field_group_member' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    PRINT 'Creating dbo.field_group_member';
    CREATE TABLE dbo.field_group_member (
        id                          UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID()
                                        CONSTRAINT PK_field_group_member PRIMARY KEY,
        field_group_id              UNIQUEIDENTIFIER NOT NULL,
        field_visibility_field_id   UNIQUEIDENTIFIER NOT NULL,
        -- BaseEntity
        created_by                  NVARCHAR(200)    NULL,
        created_at                  DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        updated_by                  NVARCHAR(200)    NULL,
        updated_at                  DATETIME2        NULL,
        -- TemporalEntity
        valid_from                  DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        valid_to                    DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from                 DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        system_to                   DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current                  BIT              NOT NULL DEFAULT 1,
        is_deleted                  BIT              NOT NULL DEFAULT 0,
        modified_by                 NVARCHAR(200)    NULL,
        CONSTRAINT FK_field_group_member_group FOREIGN KEY (field_group_id)
            REFERENCES dbo.field_group(id),
        CONSTRAINT FK_field_group_member_field FOREIGN KEY (field_visibility_field_id)
            REFERENCES dbo.field_visibility_field(id)
    );
    CREATE UNIQUE INDEX UX_field_group_member ON dbo.field_group_member(field_group_id, field_visibility_field_id)
        WHERE is_current = 1 AND is_deleted = 0;
    PRINT 'Created dbo.field_group_member';
END
ELSE
    PRINT 'dbo.field_group_member already exists — skipping.';
GO

-- ── entity_screen ────────────────────────────────────────────────────────────

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'entity_screen' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    PRINT 'Creating dbo.entity_screen';
    CREATE TABLE dbo.entity_screen (
        id              UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID()
                            CONSTRAINT PK_entity_screen PRIMARY KEY,
        screen_key      NVARCHAR(200)    NOT NULL,
        display_name    NVARCHAR(200)    NOT NULL,
        entity_type     NVARCHAR(200)    NULL,
        app_resource_id UNIQUEIDENTIFIER NULL,
        description     NVARCHAR(MAX)    NULL,
        sort_order      INT              NOT NULL DEFAULT 0,
        is_active       BIT              NOT NULL DEFAULT 1,
        -- BaseEntity
        created_by      NVARCHAR(200)    NULL,
        created_at      DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        updated_by      NVARCHAR(200)    NULL,
        updated_at      DATETIME2        NULL,
        -- TemporalEntity
        valid_from      DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        valid_to        DATETIME2        NOT NULL DEFAULT '9999-12-31',
        system_from     DATETIME2        NOT NULL DEFAULT SYSUTCDATETIME(),
        system_to       DATETIME2        NOT NULL DEFAULT '9999-12-31',
        is_current      BIT              NOT NULL DEFAULT 1,
        is_deleted      BIT              NOT NULL DEFAULT 0,
        modified_by     NVARCHAR(200)    NULL,
        CONSTRAINT FK_entity_screen_app_resource FOREIGN KEY (app_resource_id)
            REFERENCES dbo.app_resource(id)
    );
    CREATE UNIQUE INDEX UX_entity_screen_key ON dbo.entity_screen(screen_key)
        WHERE is_current = 1 AND is_deleted = 0;
    PRINT 'Created dbo.entity_screen';
END
ELSE
    PRINT 'dbo.entity_screen already exists — skipping.';
GO
