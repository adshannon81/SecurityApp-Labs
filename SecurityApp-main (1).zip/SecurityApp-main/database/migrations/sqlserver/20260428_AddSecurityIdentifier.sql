USE securityapp_db;
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

-- Step 1: create security_identifier child table
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'security_identifier' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.security_identifier (
        id               UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
        security_id      UNIQUEIDENTIFIER NOT NULL,
        identifier_type  NVARCHAR(50)     NOT NULL,
        -- 'ISIN' | 'CUSIP' | 'SEDOL' | 'BLOOMBERG_TICKER' | 'INTERNAL' | 'OTHER'
        identifier_value NVARCHAR(100)    NOT NULL,
        source_system    NVARCHAR(50)     NULL,
        is_primary       BIT              NOT NULL DEFAULT 0,
        -- BaseEntity
        created_at  DATETIME2(3) NOT NULL DEFAULT GETUTCDATE(),
        updated_at  DATETIME2(3) NULL,
        modified_by NVARCHAR(255) NULL,
        -- TemporalEntity
        valid_from  DATETIME2(3) NOT NULL DEFAULT GETUTCDATE(),
        valid_to    DATETIME2(3) NOT NULL DEFAULT '9999-12-31 23:59:59',
        system_from DATETIME2(3) NOT NULL DEFAULT GETUTCDATE(),
        system_to   DATETIME2(3) NOT NULL DEFAULT '9999-12-31 23:59:59',
        is_current  BIT          NOT NULL DEFAULT 1,
        is_deleted  BIT          NOT NULL DEFAULT 0,
        CONSTRAINT pk_security_identifier PRIMARY KEY (id),
        CONSTRAINT fk_security_identifier_security
            FOREIGN KEY (security_id) REFERENCES dbo.security (id) ON DELETE CASCADE,
        CONSTRAINT ck_security_identifier_valid_time  CHECK (valid_from  < valid_to),
        CONSTRAINT ck_security_identifier_system_time CHECK (system_from < system_to)
    );
    CREATE UNIQUE INDEX ux_security_identifier_current_value
        ON dbo.security_identifier (identifier_type, identifier_value, source_system)
        WHERE is_current = 1 AND is_deleted = 0;
    CREATE UNIQUE INDEX ux_security_identifier_primary_per_type
        ON dbo.security_identifier (security_id, identifier_type, source_system)
        WHERE is_current = 1 AND is_deleted = 0 AND is_primary = 1;
    CREATE INDEX ix_security_identifier_security_id ON dbo.security_identifier (security_id);
    CREATE INDEX ix_security_identifier_is_current  ON dbo.security_identifier (is_current);
END
GO

-- Step 2: migrate existing rows from security.identifier_value into the child table
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.security') AND name = 'identifier_value')
BEGIN
    INSERT INTO dbo.security_identifier
        (security_id, identifier_type, identifier_value, source_system, is_primary, created_at, valid_from, system_from)
    SELECT id,
           ISNULL(NULLIF(LTRIM(RTRIM(identifier_type)),''),'INTERNAL'),
           identifier_value,
           ISNULL(NULLIF(LTRIM(RTRIM(data_source)),''),'INTERNAL'),
           1, created_at, valid_from, system_from
    FROM dbo.security
    WHERE identifier_value IS NOT NULL AND identifier_value <> ''
      AND NOT EXISTS (SELECT 1 FROM dbo.security_identifier si WHERE si.security_id = dbo.security.id AND si.is_current = 1);
END
GO

-- Step 3: drop old columns from security
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.security') AND name = 'identifier_value')
BEGIN
    -- Drop any dependent indexes first
    IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ux_security_identifier_current' AND object_id = OBJECT_ID('dbo.security'))
        DROP INDEX ux_security_identifier_current ON dbo.security;
    IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_securities_identifier_type_identifier_value_data_source' AND object_id = OBJECT_ID('dbo.security'))
        DROP INDEX ix_securities_identifier_type_identifier_value_data_source ON dbo.security;
    ALTER TABLE dbo.security DROP COLUMN identifier_type;
    ALTER TABLE dbo.security DROP COLUMN identifier_value;
END
GO
