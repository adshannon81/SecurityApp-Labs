USE securityapp_db;
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

-- Migration 2C: Security lifecycle state machine.
-- 1. Extend security_status_ref with all lifecycle statuses.
-- 2. Create security_status_transition_ref with allowed transitions.

-- ── 1. Extend status reference data ──────────────────────────────────────────
INSERT INTO dbo.security_status_ref (code, description)
SELECT v.code, v.description FROM (VALUES
    ('DRAFT',            'Created but not yet submitted'),
    ('PENDING_APPROVAL', 'Awaiting Compliance approval'),
    ('ACTIVE',           'Approved and operational'),
    ('SUSPENDED',        'Temporarily disabled; still reportable'),
    ('CALLED',           'Issuer has called the instrument'),
    ('MATURED',          'Reached maturity date'),
    ('DEFAULTED',        'Issuer has defaulted'),
    ('RESTRUCTURED',     'Terms restructured post-default'),
    ('RETIRED',          'Removed from active universe'),
    ('CANCELLED',        'Cancelled before or at issuance')
) AS v(code, description)
WHERE NOT EXISTS (SELECT 1 FROM dbo.security_status_ref WHERE code = v.code);
GO

-- ── 2. Transition rules table ─────────────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'security_status_transition_ref' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.security_status_transition_ref (
        from_code VARCHAR(32) NOT NULL,
        to_code   VARCHAR(32) NOT NULL,
        CONSTRAINT pk_security_status_transition PRIMARY KEY (from_code, to_code),
        CONSTRAINT fk_sst_from FOREIGN KEY (from_code) REFERENCES dbo.security_status_ref (code),
        CONSTRAINT fk_sst_to   FOREIGN KEY (to_code)   REFERENCES dbo.security_status_ref (code)
    );
END
GO

INSERT INTO dbo.security_status_transition_ref (from_code, to_code)
SELECT v.f, v.t FROM (VALUES
    ('DRAFT',            'PENDING_APPROVAL'),
    ('DRAFT',            'CANCELLED'),
    ('PENDING_APPROVAL', 'ACTIVE'),
    ('PENDING_APPROVAL', 'DRAFT'),
    ('PENDING_APPROVAL', 'CANCELLED'),
    ('ACTIVE',           'SUSPENDED'),
    ('ACTIVE',           'CALLED'),
    ('ACTIVE',           'MATURED'),
    ('ACTIVE',           'DEFAULTED'),
    ('ACTIVE',           'RETIRED'),
    ('SUSPENDED',        'ACTIVE'),
    ('SUSPENDED',        'CALLED'),
    ('SUSPENDED',        'MATURED'),
    ('SUSPENDED',        'DEFAULTED'),
    ('SUSPENDED',        'RETIRED'),
    ('DEFAULTED',        'RESTRUCTURED'),
    ('DEFAULTED',        'RETIRED'),
    ('RESTRUCTURED',     'ACTIVE'),
    ('RESTRUCTURED',     'RETIRED'),
    ('CALLED',           'RETIRED'),
    ('MATURED',          'RETIRED')
) AS v(f, t)
WHERE NOT EXISTS (
    SELECT 1 FROM dbo.security_status_transition_ref
    WHERE from_code = v.f AND to_code = v.t
);
GO
