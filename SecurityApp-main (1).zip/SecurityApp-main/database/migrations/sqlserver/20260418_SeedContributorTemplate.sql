-- ============================================================
-- 20260418_SeedContributorTemplate.sql
--
-- Comprehensive authorization seed for the Contributor role.
-- Covers all six admin tables:
--   1. permission_definition   — already fully seeded; guarded reference only
--   2. field_visibility_entity — adds DerivedRatingDto, PricingRuleDto,
--                                ImportRequestDto, JobHistoryDto
--   3. field_visibility_field  — all fields for the new entities
--   4. field_visibility_rule   — per-permission visibility rules
--   5. app_resource            — adds nav/routes/actions for ratings,
--                                pricing, imports, jobs, workflows:use
--   6. app_resource_rule       — maps ALL 12 Contributor permissions to
--                                the appropriate resources (VISIBLE + ALLOW)
--
-- Contributor permissions (from Keycloak realm role 'Contributor'):
--   securities:read, securities:write,
--   ratings:read, ratings:write,
--   pricing:read, pricing:write,
--   imports:read, imports:run,
--   exports:run,
--   workflows:read, workflows:use,
--   jobs:read
--
-- Idempotent — safe to run multiple times against any environment.
-- Use as a TEMPLATE when seeding Viewer (read-only subset) or
-- Admin (full access superset) role data.
-- ============================================================

PRINT '== 20260418_SeedContributorTemplate.sql ==';
GO

-- ============================================================
-- SECTION 1: permission_definition
-- The full catalog is seeded by SeedData_SqlServer.sql.
-- This block is a safety net for fresh databases that skipped
-- that file and ran only the migrations folder.
-- ============================================================

IF NOT EXISTS (SELECT 1 FROM dbo.permission_definition WHERE permission_key = 'securities:read')
BEGIN
    PRINT '  Seeding permission_definition catalog (fallback — SeedData not yet applied)...';

    INSERT INTO dbo.permission_definition
        (id, permission_key, display_name, permission_group, description, is_assignable, is_system, sort_order, is_active)
    VALUES
        -- Securities
        (NEWID(), 'securities:read',           'View Securities',               'Securities',    'View securities master data',                                        1, 0,  10, 1),
        (NEWID(), 'securities:write',          'Create/Update Securities',      'Securities',    'Create and update securities',                                       1, 0,  20, 1),
        (NEWID(), 'securities:delete',         'Delete Securities',             'Securities',    'Delete securities',                                                  1, 0,  30, 1),
        (NEWID(), 'securities:view-internal',  'View Internal Fields',          'Securities',    'View internal/sensitive fields e.g. ModifiedBy',                     1, 0,  40, 1),
        -- Ratings
        (NEWID(), 'ratings:read',              'View Ratings',                  'Ratings',       'View ratings and audit trail',                                       1, 0,  50, 1),
        (NEWID(), 'ratings:write',             'Trigger Rating Calculations',   'Ratings',       'Trigger rating calculations',                                        1, 0,  60, 1),
        (NEWID(), 'ratings:manage',            'Manage Rating Models',          'Ratings',       'Manage rating models, rules, and scales',                            1, 0,  70, 1),
        -- Pricing
        (NEWID(), 'pricing:read',              'View Prices',                   'Pricing',       'View prices and pricing rules',                                      1, 0,  80, 1),
        (NEWID(), 'pricing:write',             'Import Prices',                 'Pricing',       'Import prices and run derivations',                                  1, 0,  90, 1),
        (NEWID(), 'pricing:manage',            'Manage Pricing Rules',          'Pricing',       'Create, update, and delete pricing rules',                           1, 0, 100, 1),
        -- Imports
        (NEWID(), 'imports:read',              'View Imports',                  'Imports',       'View import requests and profiles',                                  1, 0, 110, 1),
        (NEWID(), 'imports:run',               'Trigger Imports',               'Imports',       'Trigger imports',                                                    1, 0, 120, 1),
        (NEWID(), 'imports:manage',            'Manage Import Profiles',        'Imports',       'Manage import profiles and retry failed imports',                    1, 0, 130, 1),
        -- Exports
        (NEWID(), 'exports:run',               'Export Data',                   'Exports',       'Export securities data',                                             1, 0, 140, 1),
        -- Workflows
        (NEWID(), 'workflows:read',            'View Workflows',                'Workflows',     'View workflow instances',                                             1, 0, 150, 1),
        (NEWID(), 'workflows:use',             'Submit Workflow Decisions',     'Workflows',     'Submit workflow step decisions',                                      1, 0, 160, 1),
        (NEWID(), 'workflows:manage',          'Manage Workflows',              'Workflows',     'Create, cancel, and delete workflow definitions',                    1, 0, 170, 1),
        -- Jobs
        (NEWID(), 'jobs:read',                 'View Jobs',                     'Jobs',          'View job status and history',                                        1, 0, 180, 1),
        (NEWID(), 'jobs:manage',               'Manage Jobs',                   'Jobs',          'Trigger, pause, resume, and schedule jobs',                          1, 0, 190, 1),
        -- Audit
        (NEWID(), 'audit:read',                'View Audit Logs',               'Audit',         'View audit logs',                                                    1, 0, 200, 1),
        -- Portfolios
        (NEWID(), 'portfolios:read',           'View Portfolios',               'Portfolios',    'View clients, portfolios and positions',                             1, 0, 210, 1),
        (NEWID(), 'portfolios:write',          'Manage Portfolios',             'Portfolios',    'Create and manage clients, portfolios and positions',                1, 0, 220, 1),
        -- Admin
        (NEWID(), 'admin:field-visibility',    'Manage Field Visibility',       'Admin',         'Manage dynamic field visibility rules',                              1, 0, 230, 1),
        (NEWID(), 'admin:ui-resources',        'Manage UI Resources',           'Admin',         'Manage UI resource catalog, visibility rules, and execution rules',  1, 0, 240, 1),
        (NEWID(), 'system:manage',             'Manage System',                 'System',        'Manage plugins and system settings',                                 1, 1, 250, 1),
        -- Administrator
        (NEWID(), 'admin:manage-permissions',  'Manage Permission Definitions', 'Administrator', 'Create, update, and delete permission definitions and rules',        1, 0, 310, 1),
        (NEWID(), 'admin:manage-authorization','Manage Authorization Config',   'Administrator', 'Full access to field visibility and resource authorization config',  1, 0, 320, 1),
        (NEWID(), 'admin:manage-users',        'Manage User Assignments',       'Administrator', 'Assign permissions and roles to users via Keycloak integration',     1, 0, 330, 1),
        (NEWID(), 'admin:super',               'Superuser / Full Admin Access', 'Administrator', 'Unrestricted administrative access across the entire platform',      1, 1, 340, 1);
END
ELSE
    PRINT '  Skipped: permission_definition (already seeded)';
GO

PRINT '  Permission catalog ready.';
GO

-- ============================================================
-- SECTION 2-4: Field Visibility — new entities with fields
--              and per-permission visibility rules
-- ============================================================

PRINT 'Seeding field visibility — contributor entities...';
GO

-- ──────────────────────────────────────────────────────────────
-- 2a. DerivedRatingDto  (ratings:read / ratings:write)
-- ──────────────────────────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM dbo.field_visibility_entity WHERE entity_type = 'DerivedRatingDto')
BEGIN
    DECLARE @fveRating UNIQUEIDENTIFIER = NEWID();

    INSERT INTO dbo.field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (@fveRating, 'DerivedRatingDto', 'Derived Rating',
            'Derived and composite rating scores for a security', 1);

    INSERT INTO dbo.field_visibility_field
        (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level,
         default_visibility_state, sort_order, is_active)
    VALUES
        (NEWID(), @fveRating, 'SecurityId',                 'Security ID',                  'guid',     'Public',   'VISIBLE', 10,  1),
        (NEWID(), @fveRating, 'ImpliedRatingScore',         'Implied Rating Score',         'int',      'Public',   'VISIBLE', 20,  1),
        (NEWID(), @fveRating, 'VpmRatingScore',             'VPM Rating Score',             'int',      'Public',   'VISIBLE', 30,  1),
        (NEWID(), @fveRating, 'FundamentalRatingScore',     'Fundamental Rating Score',     'int',      'Public',   'VISIBLE', 40,  1),
        (NEWID(), @fveRating, 'CompositeRatingScore',       'Composite Rating Score',       'int',      'Public',   'VISIBLE', 50,  1),
        (NEWID(), @fveRating, 'CompositeRatingsByAgency',   'Composite Ratings by Agency',  'object',   'Public',   'VISIBLE', 60,  1),
        (NEWID(), @fveRating, 'ImpliedRatingsByAgency',     'Implied Ratings by Agency',    'object',   'Public',   'VISIBLE', 70,  1),
        (NEWID(), @fveRating, 'VpmRatingsByAgency',         'VPM Ratings by Agency',        'object',   'Public',   'VISIBLE', 80,  1),
        (NEWID(), @fveRating, 'FundamentalRatingsByAgency', 'Fundamental Ratings by Agency','object',   'Public',   'VISIBLE', 90,  1),
        (NEWID(), @fveRating, 'IsInvestmentGrade',          'Investment Grade',             'boolean',  'Public',   'VISIBLE', 100, 1),
        (NEWID(), @fveRating, 'LastCalculatedUtc',          'Last Calculated',              'datetime', 'Public',   'VISIBLE', 110, 1),
        (NEWID(), @fveRating, 'OutputAgency',               'Output Agency',                'string',   'Public',   'VISIBLE', 120, 1),
        -- VIEWER role sees scores; CONTRIBUTOR also sees PD / fair price
        (NEWID(), @fveRating, 'ImpliedPd',                  'Implied Probability of Default','decimal', 'Internal', 'HIDDEN',  130, 1),
        (NEWID(), @fveRating, 'ModelPd',                    'Model Probability of Default', 'decimal',  'Internal', 'HIDDEN',  140, 1),
        (NEWID(), @fveRating, 'FairPrice',                  'Fair (Model) Price',           'decimal',  'Internal', 'HIDDEN',  150, 1);

    -- [VIEWER / CONTRIBUTOR] ratings:read → all Public fields VISIBLE
    INSERT INTO dbo.field_visibility_rule
        (id, field_visibility_field_id, required_permission, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, 'ratings:read', 'VISIBLE', 'NONE', 10, 'seed:contributor-template'
    FROM   dbo.field_visibility_field f
    WHERE  f.field_visibility_entity_id = @fveRating
      AND  f.sensitivity_level = 'Public';

    -- [CONTRIBUTOR] ratings:write → Internal fields (PD, FairPrice) also VISIBLE
    INSERT INTO dbo.field_visibility_rule
        (id, field_visibility_field_id, required_permission, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, 'ratings:write', 'VISIBLE', 'NONE', 10, 'seed:contributor-template'
    FROM   dbo.field_visibility_field f
    WHERE  f.field_visibility_entity_id = @fveRating
      AND  f.sensitivity_level = 'Internal';

    PRINT '  Inserted: DerivedRatingDto entity + fields + rules';
END
ELSE
    PRINT '  Skipped:  DerivedRatingDto (already exists)';
GO

-- ──────────────────────────────────────────────────────────────
-- 2b. PricingRuleDto  (pricing:read / pricing:write)
-- ──────────────────────────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM dbo.field_visibility_entity WHERE entity_type = 'PricingRuleDto')
BEGIN
    DECLARE @fvePricing UNIQUEIDENTIFIER = NEWID();

    INSERT INTO dbo.field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (@fvePricing, 'PricingRuleDto', 'Pricing Rule',
            'Pricing rule definitions, parameters, and derivation formulas', 1);

    INSERT INTO dbo.field_visibility_field
        (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level,
         default_visibility_state, sort_order, is_active)
    VALUES
        (NEWID(), @fvePricing, 'Id',           'ID',             'guid',     'Public',   'VISIBLE', 10,  1),
        (NEWID(), @fvePricing, 'RuleName',     'Rule Name',      'string',   'Public',   'VISIBLE', 20,  1),
        (NEWID(), @fvePricing, 'SecurityType', 'Security Type',  'string',   'Public',   'VISIBLE', 30,  1),
        (NEWID(), @fvePricing, 'Source',       'Source',         'string',   'Public',   'VISIBLE', 40,  1),
        (NEWID(), @fvePricing, 'PriceType',    'Price Type',     'string',   'Public',   'VISIBLE', 50,  1),
        (NEWID(), @fvePricing, 'Description',  'Description',    'string',   'Public',   'VISIBLE', 60,  1),
        (NEWID(), @fvePricing, 'IsActive',     'Is Active',      'boolean',  'Public',   'VISIBLE', 70,  1),
        (NEWID(), @fvePricing, 'CreatedAt',    'Created At',     'datetime', 'Public',   'VISIBLE', 80,  1),
        (NEWID(), @fvePricing, 'UpdatedAt',    'Updated At',     'datetime', 'Public',   'VISIBLE', 90,  1),
        -- Formula is sensitive — only visible to users who can write pricing rules
        (NEWID(), @fvePricing, 'Formula',      'Derivation Formula', 'string', 'Internal', 'HIDDEN', 100, 1);

    -- [VIEWER / CONTRIBUTOR] pricing:read → all Public fields VISIBLE
    INSERT INTO dbo.field_visibility_rule
        (id, field_visibility_field_id, required_permission, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, 'pricing:read', 'VISIBLE', 'NONE', 10, 'seed:contributor-template'
    FROM   dbo.field_visibility_field f
    WHERE  f.field_visibility_entity_id = @fvePricing
      AND  f.sensitivity_level = 'Public';

    -- [CONTRIBUTOR] pricing:write → Formula also VISIBLE
    INSERT INTO dbo.field_visibility_rule
        (id, field_visibility_field_id, required_permission, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, 'pricing:write', 'VISIBLE', 'NONE', 10, 'seed:contributor-template'
    FROM   dbo.field_visibility_field f
    WHERE  f.field_visibility_entity_id = @fvePricing
      AND  f.sensitivity_level = 'Internal';

    PRINT '  Inserted: PricingRuleDto entity + fields + rules';
END
ELSE
    PRINT '  Skipped:  PricingRuleDto (already exists)';
GO

-- ──────────────────────────────────────────────────────────────
-- 2c. ImportRequestDto  (imports:read / imports:run)
-- ──────────────────────────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM dbo.field_visibility_entity WHERE entity_type = 'ImportRequestDto')
BEGIN
    DECLARE @fveImport UNIQUEIDENTIFIER = NEWID();

    INSERT INTO dbo.field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (@fveImport, 'ImportRequestDto', 'Import Request',
            'Import job request status, record counts, and error details', 1);

    INSERT INTO dbo.field_visibility_field
        (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level,
         default_visibility_state, sort_order, is_active)
    VALUES
        (NEWID(), @fveImport, 'Id',               'ID',                 'guid',     'Public',   'VISIBLE', 10,  1),
        (NEWID(), @fveImport, 'RequestType',      'Request Type',       'string',   'Public',   'VISIBLE', 20,  1),
        (NEWID(), @fveImport, 'SourceSystem',     'Source System',      'string',   'Public',   'VISIBLE', 30,  1),
        (NEWID(), @fveImport, 'TargetSystem',     'Target System',      'string',   'Public',   'VISIBLE', 40,  1),
        (NEWID(), @fveImport, 'Status',           'Status',             'string',   'Public',   'VISIBLE', 50,  1),
        (NEWID(), @fveImport, 'TotalRecords',     'Total Records',      'int',      'Public',   'VISIBLE', 60,  1),
        (NEWID(), @fveImport, 'ProcessedRecords', 'Processed Records',  'int',      'Public',   'VISIBLE', 70,  1),
        (NEWID(), @fveImport, 'FailedRecords',    'Failed Records',     'int',      'Public',   'VISIBLE', 80,  1),
        (NEWID(), @fveImport, 'CreatedAt',        'Created At',         'datetime', 'Public',   'VISIBLE', 90,  1),
        (NEWID(), @fveImport, 'CompletedAt',      'Completed At',       'datetime', 'Public',   'VISIBLE', 100, 1),
        -- ErrorMessage contains stack traces / internal detail — elevated permission required
        (NEWID(), @fveImport, 'ErrorMessage',     'Error Message',      'string',   'Internal', 'HIDDEN',  110, 1);

    -- [VIEWER / CONTRIBUTOR] imports:read → all Public fields VISIBLE
    INSERT INTO dbo.field_visibility_rule
        (id, field_visibility_field_id, required_permission, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, 'imports:read', 'VISIBLE', 'NONE', 10, 'seed:contributor-template'
    FROM   dbo.field_visibility_field f
    WHERE  f.field_visibility_entity_id = @fveImport
      AND  f.sensitivity_level = 'Public';

    -- [CONTRIBUTOR] imports:run → ErrorMessage also VISIBLE (operator needs to diagnose failures)
    INSERT INTO dbo.field_visibility_rule
        (id, field_visibility_field_id, required_permission, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, 'imports:run', 'VISIBLE', 'NONE', 10, 'seed:contributor-template'
    FROM   dbo.field_visibility_field f
    WHERE  f.field_visibility_entity_id = @fveImport
      AND  f.sensitivity_level = 'Internal';

    PRINT '  Inserted: ImportRequestDto entity + fields + rules';
END
ELSE
    PRINT '  Skipped:  ImportRequestDto (already exists)';
GO

-- ──────────────────────────────────────────────────────────────
-- 2d. JobHistoryDto  (jobs:read)
-- ──────────────────────────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM dbo.field_visibility_entity WHERE entity_type = 'JobHistoryDto')
BEGIN
    DECLARE @fveJob UNIQUEIDENTIFIER = NEWID();

    INSERT INTO dbo.field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (@fveJob, 'JobHistoryDto', 'Job History',
            'Background job execution history, timing, and failure details', 1);

    INSERT INTO dbo.field_visibility_field
        (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level,
         default_visibility_state, sort_order, is_active)
    VALUES
        (NEWID(), @fveJob, 'JobId',            'Job ID',            'string',   'Public',   'VISIBLE', 10, 1),
        (NEWID(), @fveJob, 'JobName',          'Job Name',          'string',   'Public',   'VISIBLE', 20, 1),
        (NEWID(), @fveJob, 'State',            'State',             'string',   'Public',   'VISIBLE', 30, 1),
        (NEWID(), @fveJob, 'EnqueuedAt',       'Enqueued At',       'datetime', 'Public',   'VISIBLE', 40, 1),
        (NEWID(), @fveJob, 'SucceededAt',      'Succeeded At',      'datetime', 'Public',   'VISIBLE', 50, 1),
        -- ExceptionMessage may contain internal paths/connection strings — admin only
        (NEWID(), @fveJob, 'ExceptionMessage', 'Exception Message', 'string',   'Internal', 'HIDDEN',  60, 1);

    -- [VIEWER / CONTRIBUTOR] jobs:read → all Public fields VISIBLE
    INSERT INTO dbo.field_visibility_rule
        (id, field_visibility_field_id, required_permission, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, 'jobs:read', 'VISIBLE', 'NONE', 10, 'seed:contributor-template'
    FROM   dbo.field_visibility_field f
    WHERE  f.field_visibility_entity_id = @fveJob
      AND  f.sensitivity_level = 'Public';

    -- ExceptionMessage stays HIDDEN unless admin:super overrides at runtime via admin UI.
    -- No rule inserted here intentionally — field default_visibility_state = 'HIDDEN'.

    PRINT '  Inserted: JobHistoryDto entity + fields + rules';
END
ELSE
    PRINT '  Skipped:  JobHistoryDto (already exists)';
GO

-- ──────────────────────────────────────────────────────────────
-- 2e. WorkflowInstanceDto  (workflows:read / workflows:use)
-- ──────────────────────────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM dbo.field_visibility_entity WHERE entity_type = 'WorkflowInstanceDto')
BEGIN
    DECLARE @fveWf UNIQUEIDENTIFIER = NEWID();

    INSERT INTO dbo.field_visibility_entity (id, entity_type, display_name, description, is_active)
    VALUES (@fveWf, 'WorkflowInstanceDto', 'Workflow Instance',
            'Workflow instance state, steps, and assignment details', 1);

    INSERT INTO dbo.field_visibility_field
        (id, field_visibility_entity_id, field_name, display_name, data_type, sensitivity_level,
         default_visibility_state, sort_order, is_active)
    VALUES
        (NEWID(), @fveWf, 'Id',               'ID',                'guid',     'Public',   'VISIBLE', 10,  1),
        (NEWID(), @fveWf, 'WorkflowType',     'Workflow Type',     'string',   'Public',   'VISIBLE', 20,  1),
        (NEWID(), @fveWf, 'Status',           'Status',            'string',   'Public',   'VISIBLE', 30,  1),
        (NEWID(), @fveWf, 'CurrentStep',      'Current Step',      'string',   'Public',   'VISIBLE', 40,  1),
        (NEWID(), @fveWf, 'SecurityId',       'Security ID',       'guid',     'Public',   'VISIBLE', 50,  1),
        (NEWID(), @fveWf, 'InitiatedBy',      'Initiated By',      'string',   'Public',   'VISIBLE', 60,  1),
        (NEWID(), @fveWf, 'CurrentAssignee',  'Current Assignee',  'string',   'Public',   'VISIBLE', 70,  1),
        (NEWID(), @fveWf, 'CreatedAt',        'Created At',        'datetime', 'Public',   'VISIBLE', 80,  1),
        (NEWID(), @fveWf, 'UpdatedAt',        'Updated At',        'datetime', 'Public',   'VISIBLE', 90,  1),
        (NEWID(), @fveWf, 'Notes',            'Notes',             'string',   'Public',   'VISIBLE', 100, 1),
        -- Internal audit context
        (NEWID(), @fveWf, 'DefinitionJson',   'Workflow Definition','string',  'Internal', 'HIDDEN',  110, 1),
        (NEWID(), @fveWf, 'StateJson',        'State Snapshot',    'string',   'Internal', 'HIDDEN',  120, 1);

    -- [VIEWER / CONTRIBUTOR] workflows:read → Public fields VISIBLE
    INSERT INTO dbo.field_visibility_rule
        (id, field_visibility_field_id, required_permission, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, 'workflows:read', 'VISIBLE', 'NONE', 10, 'seed:contributor-template'
    FROM   dbo.field_visibility_field f
    WHERE  f.field_visibility_entity_id = @fveWf
      AND  f.sensitivity_level = 'Public';

    -- [CONTRIBUTOR] workflows:use → Internal fields (definition/state) also VISIBLE
    INSERT INTO dbo.field_visibility_rule
        (id, field_visibility_field_id, required_permission, visibility_state, obfuscation_type, priority, created_by)
    SELECT NEWID(), f.id, 'workflows:use', 'VISIBLE', 'NONE', 10, 'seed:contributor-template'
    FROM   dbo.field_visibility_field f
    WHERE  f.field_visibility_entity_id = @fveWf
      AND  f.sensitivity_level = 'Internal';

    PRINT '  Inserted: WorkflowInstanceDto entity + fields + rules';
END
ELSE
    PRINT '  Skipped:  WorkflowInstanceDto (already exists)';
GO

PRINT '  Field visibility entities done.';
GO

-- ============================================================
-- SECTION 5-6: App Resources (nav / routes / actions) +
--              App Resource Rules (Contributor permissions)
-- ============================================================

PRINT 'Seeding app resources — contributor areas...';
GO

-- Add nav items, routes, and actions for the areas covered by Contributor
-- permissions that are NOT yet in the seeded resource tree.
-- Guard: if nav.ratings already exists assume this whole block ran.

IF NOT EXISTS (SELECT 1 FROM dbo.app_resource WHERE resource_key = 'nav.ratings')
BEGIN
    -- ── Resolve parent group IDs from already-seeded data ──────────────────
    DECLARE @grpMain UNIQUEIDENTIFIER;
    SELECT  @grpMain = id FROM dbo.app_resource WHERE resource_key = 'group.main';

    -- ── New MENU_ITEMs ─────────────────────────────────────────────────────
    -- (All hidden by default; rules below make them visible per permission)
    DECLARE @rRatings  UNIQUEIDENTIFIER = NEWID();
    DECLARE @rPricing  UNIQUEIDENTIFIER = NEWID();
    DECLARE @rImports  UNIQUEIDENTIFIER = NEWID();
    DECLARE @rJobs     UNIQUEIDENTIFIER = NEWID();

    INSERT INTO dbo.app_resource
        (id, parent_app_resource_id, resource_type, resource_key, display_name,
         route_path, icon_name, default_visibility_state, default_execution_state,
         is_security_sensitive, sort_order, is_active)
    VALUES
        -- [ratings:read]
        (@rRatings, @grpMain, 'MENU_ITEM', 'nav.ratings',  'Ratings',  '/ratings',  'star_rate',         'HIDDEN', 'DENY', 0, 25, 1),
        -- [pricing:read]
        (@rPricing, @grpMain, 'MENU_ITEM', 'nav.pricing',  'Pricing',  '/pricing',  'monetization_on',   'HIDDEN', 'DENY', 0, 27, 1),
        -- [imports:read]
        (@rImports, @grpMain, 'MENU_ITEM', 'nav.imports',  'Imports',  '/imports',  'upload_file',       'HIDDEN', 'DENY', 0, 28, 1),
        -- [jobs:read]
        (@rJobs,    @grpMain, 'MENU_ITEM', 'nav.jobs',     'Jobs',     '/jobs',     'work_history',      'HIDDEN', 'DENY', 0, 29, 1);

    -- ── New ROUTEs ─────────────────────────────────────────────────────────
    DECLARE @rtRatings       UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtRatingCalc    UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtPricing       UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtPricingRules  UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtImports       UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtImportNew     UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtImportProfs   UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtJobs          UNIQUEIDENTIFIER = NEWID();
    DECLARE @rtJobDetail     UNIQUEIDENTIFIER = NEWID();

    INSERT INTO dbo.app_resource
        (id, parent_app_resource_id, resource_type, resource_key, display_name,
         route_path, default_visibility_state, default_execution_state,
         is_security_sensitive, sort_order, is_active)
    VALUES
        -- Ratings routes
        (@rtRatings,      @grpMain, 'ROUTE', 'route./ratings',                  'Ratings Route',                 '/ratings',                    'HIDDEN', 'DENY', 0, 250, 1),
        (@rtRatingCalc,   @grpMain, 'ROUTE', 'route./ratings/new-calculation',  'Trigger Calculation Route',     '/ratings/new-calculation',    'HIDDEN', 'DENY', 1, 251, 1),
        -- Pricing routes
        (@rtPricing,      @grpMain, 'ROUTE', 'route./pricing',                  'Pricing Route',                 '/pricing',                    'HIDDEN', 'DENY', 0, 270, 1),
        (@rtPricingRules, @grpMain, 'ROUTE', 'route./pricing/rules',            'Pricing Rules Route',           '/pricing/rules',              'HIDDEN', 'DENY', 1, 271, 1),
        -- Import routes
        (@rtImports,      @grpMain, 'ROUTE', 'route./imports',                  'Imports Route',                 '/imports',                    'HIDDEN', 'DENY', 0, 280, 1),
        (@rtImportNew,    @grpMain, 'ROUTE', 'route./imports/new',              'Trigger Import Route',          '/imports/new',                'HIDDEN', 'DENY', 1, 281, 1),
        (@rtImportProfs,  @grpMain, 'ROUTE', 'route./imports/profiles',         'Import Profiles Route',         '/imports/profiles',           'HIDDEN', 'DENY', 0, 282, 1),
        -- Jobs routes
        (@rtJobs,         @grpMain, 'ROUTE', 'route./jobs',                     'Jobs Route',                    '/jobs',                       'HIDDEN', 'DENY', 0, 290, 1),
        (@rtJobDetail,    @grpMain, 'ROUTE', 'route./jobs/detail',              'Job Detail Route',              '/jobs/:id',                   'HIDDEN', 'DENY', 0, 291, 1);

    -- ── New ACTIONs ────────────────────────────────────────────────────────
    DECLARE @actRatingTrigger  UNIQUEIDENTIFIER = NEWID();
    DECLARE @actPricingImport  UNIQUEIDENTIFIER = NEWID();
    DECLARE @actImportRun      UNIQUEIDENTIFIER = NEWID();
    DECLARE @actWfSubmit       UNIQUEIDENTIFIER = NEWID();

    INSERT INTO dbo.app_resource
        (id, parent_app_resource_id, resource_type, resource_key, display_name,
         default_visibility_state, default_execution_state, is_security_sensitive, sort_order, is_active)
    VALUES
        -- [ratings:write]
        (@actRatingTrigger, @grpMain, 'ACTION', 'ratings.trigger',       'Trigger Rating Calculation', 'HIDDEN', 'DENY', 1, 260, 1),
        -- [pricing:write]
        (@actPricingImport, @grpMain, 'ACTION', 'pricing.import-prices', 'Import / Re-derive Prices',  'HIDDEN', 'DENY', 1, 272, 1),
        -- [imports:run]
        (@actImportRun,     @grpMain, 'ACTION', 'imports.run',           'Run Import',                 'HIDDEN', 'DENY', 1, 283, 1),
        -- [workflows:use]
        (@actWfSubmit,      @grpMain, 'ACTION', 'workflows.submit',      'Submit Workflow Decision',   'HIDDEN', 'DENY', 1, 310, 1);

    -- ──────────────────────────────────────────────────────────────────────
    -- App Resource Rules — Contributor role (12 permissions)
    -- ──────────────────────────────────────────────────────────────────────
    -- Resolve already-seeded resource IDs needed for cross-resource rules
    DECLARE @rDash     UNIQUEIDENTIFIER; SELECT @rDash     = id FROM dbo.app_resource WHERE resource_key = 'nav.dashboard';
    DECLARE @rSec      UNIQUEIDENTIFIER; SELECT @rSec      = id FROM dbo.app_resource WHERE resource_key = 'nav.securities';
    DECLARE @rWork     UNIQUEIDENTIFIER; SELECT @rWork     = id FROM dbo.app_resource WHERE resource_key = 'nav.workflows';
    DECLARE @rHist     UNIQUEIDENTIFIER; SELECT @rHist     = id FROM dbo.app_resource WHERE resource_key = 'nav.history';
    DECLARE @rtDash    UNIQUEIDENTIFIER; SELECT @rtDash    = id FROM dbo.app_resource WHERE resource_key = 'route./dashboard';
    DECLARE @rtSec     UNIQUEIDENTIFIER; SELECT @rtSec     = id FROM dbo.app_resource WHERE resource_key = 'route./securities';
    DECLARE @rtHist    UNIQUEIDENTIFIER; SELECT @rtHist    = id FROM dbo.app_resource WHERE resource_key = 'route./history';
    DECLARE @rtWork    UNIQUEIDENTIFIER; SELECT @rtWork    = id FROM dbo.app_resource WHERE resource_key = 'route./workflows';
    DECLARE @actCreate UNIQUEIDENTIFIER; SELECT @actCreate = id FROM dbo.app_resource WHERE resource_key = 'security.create';
    DECLARE @actEdit   UNIQUEIDENTIFIER; SELECT @actEdit   = id FROM dbo.app_resource WHERE resource_key = 'security.edit';
    DECLARE @actDelete UNIQUEIDENTIFIER; SELECT @actDelete = id FROM dbo.app_resource WHERE resource_key = 'security.delete';
    DECLARE @actExport UNIQUEIDENTIFIER; SELECT @actExport = id FROM dbo.app_resource WHERE resource_key = 'security.export';

    INSERT INTO dbo.app_resource_rule
        (id, app_resource_id, required_permission, visibility_state, execution_state, priority, created_by)
    VALUES
        -- ── securities:read ──────────────────────────────────────────────────
        -- [already seeded by SeedData_SqlServer.sql — no new rules needed here]
        -- Adding a comment for template completeness:
        --   nav.dashboard  → 'securities:read' VISIBLE ALLOW  (seeded)
        --   nav.securities → 'securities:read' VISIBLE ALLOW  (seeded)
        --   nav.history    → 'securities:read' VISIBLE ALLOW  (seeded)
        --   route./dashboard, route./securities, route./history  (seeded)

        -- ── securities:write ─────────────────────────────────────────────────
        -- [already seeded; security.create + security.edit have rules]
        -- security.delete rule is already seeded for 'securities:delete' (not in Contributor)
        -- Adding edit action rule in case it was missed:
        (NEWID(), @actCreate, 'securities:write', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),
        (NEWID(), @actEdit,   'securities:write', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),

        -- ── ratings:read ─────────────────────────────────────────────────────
        (NEWID(), @rRatings,    'ratings:read', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),
        (NEWID(), @rtRatings,   'ratings:read', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),

        -- ── ratings:write ────────────────────────────────────────────────────
        (NEWID(), @rtRatingCalc,    'ratings:write', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),
        (NEWID(), @actRatingTrigger,'ratings:write', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),

        -- ── pricing:read ─────────────────────────────────────────────────────
        (NEWID(), @rPricing,      'pricing:read', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),
        (NEWID(), @rtPricing,     'pricing:read', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),
        (NEWID(), @rtPricingRules,'pricing:read', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),

        -- ── pricing:write ────────────────────────────────────────────────────
        (NEWID(), @actPricingImport,'pricing:write', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),

        -- ── imports:read ─────────────────────────────────────────────────────
        (NEWID(), @rImports,     'imports:read', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),
        (NEWID(), @rtImports,    'imports:read', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),
        (NEWID(), @rtImportProfs,'imports:read', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),

        -- ── imports:run ──────────────────────────────────────────────────────
        (NEWID(), @rtImportNew, 'imports:run', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),
        (NEWID(), @actImportRun,'imports:run', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),

        -- ── exports:run ──────────────────────────────────────────────────────
        -- [already seeded: security.export → exports:run VISIBLE ALLOW]
        (NEWID(), @actExport, 'exports:run', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),

        -- ── workflows:read ───────────────────────────────────────────────────
        -- [already seeded: nav.workflows + route./workflows → workflows:read]
        (NEWID(), @rWork,  'workflows:read', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),
        (NEWID(), @rtWork, 'workflows:read', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),

        -- ── workflows:use ────────────────────────────────────────────────────
        (NEWID(), @actWfSubmit, 'workflows:use', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),

        -- ── jobs:read ────────────────────────────────────────────────────────
        (NEWID(), @rJobs,      'jobs:read', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),
        (NEWID(), @rtJobs,     'jobs:read', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template'),
        (NEWID(), @rtJobDetail,'jobs:read', 'VISIBLE', 'ALLOW', 100, 'seed:contributor-template');

    PRINT '  Inserted: nav.ratings, nav.pricing, nav.imports, nav.jobs + routes + actions + rules';
END
ELSE
    PRINT '  Skipped:  Contributor nav resources (already exist)';
GO

-- ============================================================
-- NOTE: Duplicate rule guard
-- The existing seed in SeedData_SqlServer.sql already inserts
-- rules for nav.dashboard/securities/history/workflows using
-- required_permission strings.  The rules above for
-- securities:write, exports:run, and workflows:read will create
-- ADDITIONAL rule rows (same resource, same permission).  This
-- is safe — the evaluation engine uses MAX(priority) and allows
-- multiple rules per resource.  If strict deduplication is
-- needed, add a UNIQUE INDEX on (app_resource_id, required_permission)
-- to the app_resource_rule table.
-- ============================================================

-- ============================================================
-- Schema version record
-- ============================================================
IF NOT EXISTS (SELECT 1 FROM dbo.[__SchemaVersions] WHERE version = '2.0-contributor-template')
BEGIN
    INSERT INTO dbo.[__SchemaVersions]
        (version, description, script_name, applied_on, applied_by, status)
    VALUES
        ('2.0-contributor-template',
         'Contributor role authorization template: FV entities (DerivedRatingDto, PricingRuleDto, '
         + 'ImportRequestDto, JobHistoryDto, WorkflowInstanceDto) + nav resources (ratings, pricing, '
         + 'imports, jobs) + comprehensive app_resource_rule coverage for all 12 Contributor permissions',
         '20260418_SeedContributorTemplate.sql',
         GETUTCDATE(), SYSTEM_USER, 'Success');
END
GO

PRINT '== 20260418_SeedContributorTemplate.sql complete ==';
GO

-- ============================================================
-- TEMPLATE GUIDE
-- ============================================================
-- To create a VIEWER role seed (read-only subset):
--   Copy this file, rename to 20260418_SeedViewerTemplate.sql
--   Remove/replace *:write and *:run rules with DENY / HIDDEN.
--   Viewer permissions: securities:read, ratings:read,
--     pricing:read, imports:read, workflows:read, jobs:read.
--
-- To create an ADMIN role seed (full access superset):
--   Copy this file, rename to 20260418_SeedAdminTemplate.sql
--   Add admin:field-visibility, admin:ui-resources,
--     admin:manage-permissions, admin:super rules against
--     the admin nav routes (already seeded by SeedData_SqlServer.sql).
-- ============================================================
