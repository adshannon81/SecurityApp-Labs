-- ============================================================
-- Migration: Simplify Admin Schema (lean authorization)
-- Date:      2026-04-14
-- Aligns the authorization tables with the simplified requirements:
--   1. Drop future-reference tables not needed for the lean schema
--   2. Add default_obfuscation_type to field_visibility_field
--   3. Rename default_visibility → default_visibility_state and align enum values to uppercase
--   4. Add permission_definition_id FK to field_visibility_rule and app_resource_rule
--   5. Rename visibility → visibility_state in field_visibility_rule
--   6. Align check constraints to uppercase enum values across all admin tables
--   7. Remove app_resource_group_id FK + column from app_resource
--   8. Seed Administrator permission group
-- ============================================================
SET QUOTED_IDENTIFIER ON;
GO

PRINT 'Migration 20260414_SimplifyAdminSchema — begin';
GO

-- ============================================================
-- STEP 1 — Drop future-reference tables (in FK dependency order)
-- ============================================================

-- field_group_member depends on field_group + field_visibility_field
IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'field_group_member' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    PRINT 'Dropping dbo.field_group_member';
    DROP TABLE dbo.field_group_member;
END
GO

-- field_group depends on field_visibility_entity
IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'field_group' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    PRINT 'Dropping dbo.field_group';
    DROP TABLE dbo.field_group;
END
GO

-- permission_bundle_member depends on permission_bundle + permission_definition
IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'permission_bundle_member' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    PRINT 'Dropping dbo.permission_bundle_member';
    DROP TABLE dbo.permission_bundle_member;
END
GO

-- permission_bundle (standalone)
IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'permission_bundle' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    PRINT 'Dropping dbo.permission_bundle';
    DROP TABLE dbo.permission_bundle;
END
GO

-- policy_template (standalone)
IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'policy_template' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    PRINT 'Dropping dbo.policy_template';
    DROP TABLE dbo.policy_template;
END
GO

-- entity_screen (standalone)
IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'entity_screen' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    PRINT 'Dropping dbo.entity_screen';
    DROP TABLE dbo.entity_screen;
END
GO

-- Remove app_resource.app_resource_group_id FK + column before dropping the group table
IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'fk_app_resource_group' AND parent_object_id = OBJECT_ID('dbo.app_resource'))
BEGIN
    PRINT 'Dropping FK fk_app_resource_group from dbo.app_resource';
    ALTER TABLE dbo.app_resource DROP CONSTRAINT fk_app_resource_group;
END
GO

IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_app_resource_group_id' AND object_id = OBJECT_ID('dbo.app_resource'))
BEGIN
    DROP INDEX ix_app_resource_group_id ON dbo.app_resource;
END
GO

IF EXISTS (SELECT 1 FROM sys.columns WHERE name = 'app_resource_group_id' AND object_id = OBJECT_ID('dbo.app_resource'))
BEGIN
    PRINT 'Dropping column app_resource_group_id from dbo.app_resource';
    ALTER TABLE dbo.app_resource DROP COLUMN app_resource_group_id;
END
GO

-- app_resource_group
IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'app_resource_group' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    PRINT 'Dropping dbo.app_resource_group';
    DROP TABLE dbo.app_resource_group;
END
GO

-- ============================================================
-- STEP 2 — field_visibility_field: rename column + add obfuscation
-- ============================================================

-- Rename default_visibility → default_visibility_state
IF EXISTS (
    SELECT 1 FROM sys.columns
    WHERE name = 'default_visibility' AND object_id = OBJECT_ID('dbo.field_visibility_field')
)
AND NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE name = 'default_visibility_state' AND object_id = OBJECT_ID('dbo.field_visibility_field')
)
BEGIN
    PRINT 'Renaming field_visibility_field.default_visibility → default_visibility_state';
    EXEC sp_rename 'dbo.field_visibility_field.default_visibility', 'default_visibility_state', 'COLUMN';
END
GO

-- Normalise existing data values to uppercase
UPDATE dbo.field_visibility_field SET default_visibility_state = 'VISIBLE'
    WHERE default_visibility_state IN ('Full', 'FULL', 'Visible');
UPDATE dbo.field_visibility_field SET default_visibility_state = 'HIDDEN'
    WHERE default_visibility_state = 'Hidden';
UPDATE dbo.field_visibility_field SET default_visibility_state = 'DISABLED'
    WHERE default_visibility_state = 'Disabled';
UPDATE dbo.field_visibility_field SET default_visibility_state = 'OBFUSCATED'
    WHERE default_visibility_state IN ('Obfuscated', 'Redacted');
GO

-- Drop old default constraint (named in original schema as df_fvf_default_visibility)
IF EXISTS (
    SELECT 1 FROM sys.default_constraints
    WHERE name = 'df_fvf_default_visibility' AND parent_object_id = OBJECT_ID('dbo.field_visibility_field')
)
    ALTER TABLE dbo.field_visibility_field DROP CONSTRAINT df_fvf_default_visibility;
GO

-- Add correct default for the renamed column
IF NOT EXISTS (
    SELECT 1 FROM sys.default_constraints
    WHERE name = 'df_fvf_default_visibility_state' AND parent_object_id = OBJECT_ID('dbo.field_visibility_field')
)
    ALTER TABLE dbo.field_visibility_field
        ADD CONSTRAINT df_fvf_default_visibility_state DEFAULT 'VISIBLE' FOR default_visibility_state;
GO

-- Drop any existing check on visibility state
IF EXISTS (
    SELECT 1 FROM sys.check_constraints
    WHERE name = 'ck_fvf_default_visibility_state' AND parent_object_id = OBJECT_ID('dbo.field_visibility_field')
)
    ALTER TABLE dbo.field_visibility_field DROP CONSTRAINT ck_fvf_default_visibility_state;
GO

ALTER TABLE dbo.field_visibility_field
    ADD CONSTRAINT ck_fvf_default_visibility_state
        CHECK (default_visibility_state IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED'));
GO

-- Add default_obfuscation_type column
IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE name = 'default_obfuscation_type' AND object_id = OBJECT_ID('dbo.field_visibility_field')
)
BEGIN
    PRINT 'Adding field_visibility_field.default_obfuscation_type';
    ALTER TABLE dbo.field_visibility_field
        ADD default_obfuscation_type NVARCHAR(30) NOT NULL
            CONSTRAINT df_fvf_default_obfuscation_type DEFAULT 'NONE';
    ALTER TABLE dbo.field_visibility_field
        ADD CONSTRAINT ck_fvf_default_obfuscation_type
            CHECK (default_obfuscation_type IN ('NONE','TEXT','EMAIL','NAME','DATE','NUMBER','CUSTOM'));
END
GO

-- ============================================================
-- STEP 3 — field_visibility_rule: rename visibility + add FK
-- ============================================================

-- Rename visibility → visibility_state
IF EXISTS (
    SELECT 1 FROM sys.columns
    WHERE name = 'visibility' AND object_id = OBJECT_ID('dbo.field_visibility_rule')
)
AND NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE name = 'visibility_state' AND object_id = OBJECT_ID('dbo.field_visibility_rule')
)
BEGIN
    PRINT 'Renaming field_visibility_rule.visibility → visibility_state';
    EXEC sp_rename 'dbo.field_visibility_rule.visibility', 'visibility_state', 'COLUMN';
END
GO

-- Normalise visibility_state values to uppercase
UPDATE dbo.field_visibility_rule SET visibility_state = 'VISIBLE'
    WHERE visibility_state IN ('Full', 'FULL', 'Visible');
UPDATE dbo.field_visibility_rule SET visibility_state = 'HIDDEN'
    WHERE visibility_state = 'Hidden';
UPDATE dbo.field_visibility_rule SET visibility_state = 'DISABLED'
    WHERE visibility_state = 'Disabled';
UPDATE dbo.field_visibility_rule SET visibility_state = 'OBFUSCATED'
    WHERE visibility_state IN ('Obfuscated', 'Redacted');
GO

-- Normalise obfuscation_type values to uppercase
UPDATE dbo.field_visibility_rule SET obfuscation_type = 'NONE'
    WHERE obfuscation_type IN ('None', 'none');
UPDATE dbo.field_visibility_rule SET obfuscation_type = 'TEXT'
    WHERE obfuscation_type = 'Text';
UPDATE dbo.field_visibility_rule SET obfuscation_type = 'EMAIL'
    WHERE obfuscation_type = 'Email';
UPDATE dbo.field_visibility_rule SET obfuscation_type = 'NAME'
    WHERE obfuscation_type = 'Name';
UPDATE dbo.field_visibility_rule SET obfuscation_type = 'DATE'
    WHERE obfuscation_type = 'Date';
UPDATE dbo.field_visibility_rule SET obfuscation_type = 'NUMBER'
    WHERE obfuscation_type = 'Number';
UPDATE dbo.field_visibility_rule SET obfuscation_type = 'CUSTOM'
    WHERE obfuscation_type = 'Custom';
GO

-- Drop old check constraints on field_visibility_rule
IF EXISTS (
    SELECT 1 FROM sys.check_constraints
    WHERE name = 'ck_fvr_visibility_state' AND parent_object_id = OBJECT_ID('dbo.field_visibility_rule')
)
    ALTER TABLE dbo.field_visibility_rule DROP CONSTRAINT ck_fvr_visibility_state;
GO
IF EXISTS (
    SELECT 1 FROM sys.check_constraints
    WHERE name = 'ck_fvr_obfuscation_type' AND parent_object_id = OBJECT_ID('dbo.field_visibility_rule')
)
    ALTER TABLE dbo.field_visibility_rule DROP CONSTRAINT ck_fvr_obfuscation_type;
GO

-- Add updated check constraints
ALTER TABLE dbo.field_visibility_rule
    ADD CONSTRAINT ck_fvr_visibility_state
        CHECK (visibility_state IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED'));
GO
ALTER TABLE dbo.field_visibility_rule
    ADD CONSTRAINT ck_fvr_obfuscation_type
        CHECK (obfuscation_type IN ('NONE','TEXT','EMAIL','NAME','DATE','NUMBER','CUSTOM'));
GO

-- Add permission_definition_id FK column (nullable — either this or required_permission)
IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE name = 'permission_definition_id' AND object_id = OBJECT_ID('dbo.field_visibility_rule')
)
BEGIN
    PRINT 'Adding field_visibility_rule.permission_definition_id';
    ALTER TABLE dbo.field_visibility_rule
        ADD permission_definition_id UNIQUEIDENTIFIER NULL
            CONSTRAINT fk_fvr_permission_definition
                REFERENCES dbo.permission_definition (id) ON DELETE NO ACTION;
END
GO

-- Mutual exclusion: exactly one of permission_definition_id / required_permission must be set
-- Only add if the rule does not already exist
IF NOT EXISTS (
    SELECT 1 FROM sys.check_constraints
    WHERE name = 'ck_fvr_permission_source' AND parent_object_id = OBJECT_ID('dbo.field_visibility_rule')
)
    ALTER TABLE dbo.field_visibility_rule
        ADD CONSTRAINT ck_fvr_permission_source
            CHECK (
                (permission_definition_id IS NOT NULL AND required_permission IS NULL) OR
                (permission_definition_id IS NULL     AND required_permission IS NOT NULL)
            );
GO

-- ============================================================
-- STEP 4 — app_resource: update check constraints + remove group_id
-- ============================================================

-- Drop old resource_type check (uses PascalCase)
IF EXISTS (
    SELECT 1 FROM sys.check_constraints
    WHERE name = 'ck_app_resource_type' AND parent_object_id = OBJECT_ID('dbo.app_resource')
)
    ALTER TABLE dbo.app_resource DROP CONSTRAINT ck_app_resource_type;
GO

-- Normalise resource_type values to uppercase with underscores
UPDATE dbo.app_resource SET resource_type = 'MENU_GROUP' WHERE resource_type = 'MenuGroup';
UPDATE dbo.app_resource SET resource_type = 'MENU_ITEM'  WHERE resource_type = 'MenuItem';
UPDATE dbo.app_resource SET resource_type = 'ROUTE'      WHERE resource_type = 'Route';
UPDATE dbo.app_resource SET resource_type = 'ACTION'     WHERE resource_type = 'Action';
UPDATE dbo.app_resource SET resource_type = 'TAB'        WHERE resource_type = 'Tab';
UPDATE dbo.app_resource SET resource_type = 'SECTION'    WHERE resource_type = 'Section';
GO

ALTER TABLE dbo.app_resource
    ADD CONSTRAINT ck_app_resource_type
        CHECK (resource_type IN ('MENU_GROUP','MENU_ITEM','ROUTE','ACTION','TAB','SECTION'));
GO

-- Drop old visibility / execution check constraints
IF EXISTS (
    SELECT 1 FROM sys.check_constraints
    WHERE name = 'ck_app_resource_visibility_state' AND parent_object_id = OBJECT_ID('dbo.app_resource')
)
    ALTER TABLE dbo.app_resource DROP CONSTRAINT ck_app_resource_visibility_state;
GO
IF EXISTS (
    SELECT 1 FROM sys.check_constraints
    WHERE name = 'ck_app_resource_execution_state' AND parent_object_id = OBJECT_ID('dbo.app_resource')
)
    ALTER TABLE dbo.app_resource DROP CONSTRAINT ck_app_resource_execution_state;
GO

-- Normalise visibility_state values to uppercase
UPDATE dbo.app_resource SET default_visibility_state = 'VISIBLE'    WHERE default_visibility_state = 'Visible';
UPDATE dbo.app_resource SET default_visibility_state = 'HIDDEN'     WHERE default_visibility_state = 'Hidden';
UPDATE dbo.app_resource SET default_visibility_state = 'DISABLED'   WHERE default_visibility_state = 'Disabled';
UPDATE dbo.app_resource SET default_visibility_state = 'OBFUSCATED' WHERE default_visibility_state = 'NotApplicable';
GO

-- Normalise execution_state values to uppercase
UPDATE dbo.app_resource SET default_execution_state = 'ALLOW'          WHERE default_execution_state = 'Allow';
UPDATE dbo.app_resource SET default_execution_state = 'DENY'           WHERE default_execution_state = 'Deny';
UPDATE dbo.app_resource SET default_execution_state = 'NOT_APPLICABLE' WHERE default_execution_state = 'NotApplicable';
GO

-- Update defaults on app_resource
IF EXISTS (
    SELECT 1 FROM sys.default_constraints
    WHERE name = 'df_ar_default_visibility' AND parent_object_id = OBJECT_ID('dbo.app_resource')
)
    ALTER TABLE dbo.app_resource DROP CONSTRAINT df_ar_default_visibility;
GO
IF EXISTS (
    SELECT 1 FROM sys.default_constraints
    WHERE name = 'df_ar_default_execution' AND parent_object_id = OBJECT_ID('dbo.app_resource')
)
    ALTER TABLE dbo.app_resource DROP CONSTRAINT df_ar_default_execution;
GO

ALTER TABLE dbo.app_resource ADD CONSTRAINT df_ar_default_visibility DEFAULT 'VISIBLE' FOR default_visibility_state;
ALTER TABLE dbo.app_resource ADD CONSTRAINT df_ar_default_execution  DEFAULT 'ALLOW'   FOR default_execution_state;
GO

-- Add new check constraints with uppercase enum values
ALTER TABLE dbo.app_resource
    ADD CONSTRAINT ck_app_resource_visibility_state
        CHECK (default_visibility_state IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED'));
GO
ALTER TABLE dbo.app_resource
    ADD CONSTRAINT ck_app_resource_execution_state
        CHECK (default_execution_state IN ('ALLOW','DENY','NOT_APPLICABLE'));
GO

-- ============================================================
-- STEP 5 — app_resource_rule: add permission_definition_id FK + update checks
-- ============================================================

-- Drop old check constraints
IF EXISTS (
    SELECT 1 FROM sys.check_constraints
    WHERE name = 'ck_app_resource_rule_visibility' AND parent_object_id = OBJECT_ID('dbo.app_resource_rule')
)
    ALTER TABLE dbo.app_resource_rule DROP CONSTRAINT ck_app_resource_rule_visibility;
GO
IF EXISTS (
    SELECT 1 FROM sys.check_constraints
    WHERE name = 'ck_app_resource_rule_execution' AND parent_object_id = OBJECT_ID('dbo.app_resource_rule')
)
    ALTER TABLE dbo.app_resource_rule DROP CONSTRAINT ck_app_resource_rule_execution;
GO

-- Normalise existing data
UPDATE dbo.app_resource_rule SET visibility_state = 'VISIBLE'    WHERE visibility_state = 'Visible';
UPDATE dbo.app_resource_rule SET visibility_state = 'HIDDEN'     WHERE visibility_state = 'Hidden';
UPDATE dbo.app_resource_rule SET visibility_state = 'DISABLED'   WHERE visibility_state = 'Disabled';
UPDATE dbo.app_resource_rule SET visibility_state = 'OBFUSCATED' WHERE visibility_state = 'NotApplicable';
UPDATE dbo.app_resource_rule SET execution_state  = 'ALLOW'          WHERE execution_state = 'Allow';
UPDATE dbo.app_resource_rule SET execution_state  = 'DENY'           WHERE execution_state = 'Deny';
UPDATE dbo.app_resource_rule SET execution_state  = 'NOT_APPLICABLE' WHERE execution_state = 'NotApplicable';
GO

-- Add updated check constraints
ALTER TABLE dbo.app_resource_rule
    ADD CONSTRAINT ck_app_resource_rule_visibility
        CHECK (visibility_state IN ('VISIBLE','HIDDEN','DISABLED','OBFUSCATED'));
GO
ALTER TABLE dbo.app_resource_rule
    ADD CONSTRAINT ck_app_resource_rule_execution
        CHECK (execution_state IN ('ALLOW','DENY','NOT_APPLICABLE'));
GO

-- Add permission_definition_id FK column
IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE name = 'permission_definition_id' AND object_id = OBJECT_ID('dbo.app_resource_rule')
)
BEGIN
    PRINT 'Adding app_resource_rule.permission_definition_id';
    ALTER TABLE dbo.app_resource_rule
        ADD permission_definition_id UNIQUEIDENTIFIER NULL
            CONSTRAINT fk_arr_permission_definition
                REFERENCES dbo.permission_definition (id) ON DELETE NO ACTION;
END
GO

-- Mutual exclusion check
IF NOT EXISTS (
    SELECT 1 FROM sys.check_constraints
    WHERE name = 'ck_arr_permission_source' AND parent_object_id = OBJECT_ID('dbo.app_resource_rule')
)
    ALTER TABLE dbo.app_resource_rule
        ADD CONSTRAINT ck_arr_permission_source
            CHECK (
                (permission_definition_id IS NOT NULL AND required_permission IS NULL) OR
                (permission_definition_id IS NULL     AND required_permission IS NOT NULL)
            );
GO

-- Index for the new FK column
IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'ix_app_resource_rule_permission_def_id' AND object_id = OBJECT_ID('dbo.app_resource_rule')
)
    CREATE INDEX ix_app_resource_rule_permission_def_id
        ON dbo.app_resource_rule (permission_definition_id)
        WHERE permission_definition_id IS NOT NULL;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'ix_field_visibility_rule_permission_def_id' AND object_id = OBJECT_ID('dbo.field_visibility_rule')
)
    CREATE INDEX ix_field_visibility_rule_permission_def_id
        ON dbo.field_visibility_rule (permission_definition_id)
        WHERE permission_definition_id IS NOT NULL;
GO

-- ============================================================
-- STEP 6 — Seed Administrator permission group
-- ============================================================
IF NOT EXISTS (SELECT 1 FROM dbo.permission_definition WHERE permission_key = 'admin:manage-permissions')
BEGIN
    INSERT INTO dbo.permission_definition
        (id, permission_key, display_name, permission_group, description, is_assignable, is_system, sort_order, is_active)
    VALUES
        (NEWID(), 'admin:manage-permissions',  'Manage Permission Definitions', 'Administrator', 'Create, update, and delete permission definitions and rules',      1, 0, 310, 1),
        (NEWID(), 'admin:manage-authorization','Manage Authorization Config',   'Administrator', 'Full access to field visibility and resource authorization config', 1, 0, 320, 1),
        (NEWID(), 'admin:manage-users',        'Manage User Assignments',       'Administrator', 'Assign permissions and roles to users via Keycloak integration',    1, 0, 330, 1),
        (NEWID(), 'admin:super',               'Superuser / Full Admin Access', 'Administrator', 'Unrestricted administrative access across the entire platform',     1, 1, 340, 1);
END
GO

-- ============================================================
-- Record migration
-- ============================================================
IF NOT EXISTS (SELECT 1 FROM dbo.[__SchemaVersions] WHERE version = '20260414-simplify-admin')
BEGIN
    INSERT INTO dbo.[__SchemaVersions] (version, description, script_name)
    VALUES (
        '20260414-simplify-admin',
        'Lean admin schema: drop future-reference tables, align enum values to uppercase, add obfuscation_type to fv_field, add permission_definition_id FK to rule tables, add Administrator permission group',
        '20260414_SimplifyAdminSchema.sql'
    );
END
GO

PRINT 'Migration 20260414_SimplifyAdminSchema — complete';
GO
