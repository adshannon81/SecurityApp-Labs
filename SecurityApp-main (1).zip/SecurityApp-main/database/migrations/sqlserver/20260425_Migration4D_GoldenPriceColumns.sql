-- =============================================================================
-- Migration 4D  –  Add golden-source columns to dbo.price
--                  + create ix_price_is_golden filtered index
-- Idempotent: all statements guarded with IF NOT EXISTS
-- =============================================================================

-- is_golden / is_stale / is_override / override_reason
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.price') AND name = 'is_golden')
BEGIN
    ALTER TABLE dbo.price ADD
        is_golden        BIT              NOT NULL DEFAULT 0,
        is_stale         BIT              NOT NULL DEFAULT 0,
        is_override      BIT              NOT NULL DEFAULT 0,
        override_reason  NVARCHAR(500)    NULL,
        vendor_source_id UNIQUEIDENTIFIER NULL;
END
GO

-- FK to vendor_source
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'fk_price_vendor_source')
    ALTER TABLE dbo.price
        ADD CONSTRAINT fk_price_vendor_source
            FOREIGN KEY (vendor_source_id) REFERENCES dbo.vendor_source (id);
GO

-- Filtered index: fast lookup of the golden price row per security/date
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_price_is_golden' AND object_id = OBJECT_ID('dbo.price'))
    CREATE INDEX ix_price_is_golden
        ON dbo.price (security_id, price_date DESC)
        WHERE is_golden = 1 AND is_deleted = 0;
GO

PRINT 'Migration 4D applied: golden-source columns added to dbo.price.';
GO
