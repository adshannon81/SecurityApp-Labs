-- ============================================================
-- Migration: 20260412_AddSecurityRefTables
-- Adds security_status_ref, asset_class_ref, instrument_type_ref
-- reference tables and replaces the flat [type] column on
-- dbo.security with asset_class_code + instrument_type_code.
-- Also adds status_code to replace the implicit IsCurrent-only
-- lifecycle model, and adds the optional currency FK.
-- ============================================================

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

-- ── 1. Create dbo.security_status_ref ─────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'security_status_ref' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.security_status_ref (
        code        VARCHAR(32)   NOT NULL,
        description NVARCHAR(255) NOT NULL,
        CONSTRAINT pk_security_status_ref PRIMARY KEY (code)
    );
END
GO

-- ── 2. Create dbo.asset_class_ref ─────────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'asset_class_ref' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.asset_class_ref (
        code        VARCHAR(32)   NOT NULL,
        name        NVARCHAR(100) NOT NULL,
        description NVARCHAR(255) NULL,
        CONSTRAINT pk_asset_class_ref PRIMARY KEY (code)
    );
END
GO

-- ── 3. Create dbo.instrument_type_ref ─────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'instrument_type_ref' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.instrument_type_ref (
        code             VARCHAR(64)   NOT NULL,
        asset_class_code VARCHAR(32)   NOT NULL,
        description      NVARCHAR(255) NULL,
        CONSTRAINT pk_instrument_type_ref PRIMARY KEY (code),
        CONSTRAINT fk_instrument_type_asset_class
            FOREIGN KEY (asset_class_code) REFERENCES dbo.asset_class_ref(code)
    );
END
GO

-- ── 4. Seed dbo.security_status_ref ──────────────────────────────────────────
MERGE dbo.security_status_ref AS t
USING (VALUES
    ('ACTIVE',    'Issued and tradable'),
    ('SUSPENDED', 'Temporarily not tradable but still in master'),
    ('CALLED',    'Fully called early'),
    ('MATURED',   'Passed maturity date'),
    ('DEFAULTED', 'Payment default'),
    ('RETIRED',   'No longer used operationally but kept for history')
) AS s (code, description)
ON t.code = s.code
WHEN NOT MATCHED THEN INSERT (code, description) VALUES (s.code, s.description);
GO

-- ── 5. Seed dbo.asset_class_ref ───────────────────────────────────────────────
MERGE dbo.asset_class_ref AS t
USING (VALUES
    ('EQUITY',       'Equity',                      NULL),
    ('BOND',         'Bond / Fixed Income',          NULL),
    ('LOAN',         'Loan',                         NULL),
    ('MONEY_MARKET', 'Money Market',                 NULL),
    ('FUND',         'Fund / Collective Investment', NULL),
    ('DERIVATIVE',   'Derivative',                   NULL),
    ('SECURITIZED',  'Securitized / Structured',     NULL),
    ('FX',           'Foreign Exchange',             NULL),
    ('COMMODITY',    'Commodity',                    NULL),
    ('OTHER',        'Other / Misc',                 NULL)
) AS s (code, name, description)
ON t.code = s.code
WHEN NOT MATCHED THEN INSERT (code, name, description) VALUES (s.code, s.name, s.description);
GO

-- ── 6. Seed dbo.instrument_type_ref ──────────────────────────────────────────
MERGE dbo.instrument_type_ref AS t
USING (VALUES
    -- BOND
    ('TreasuryBond',           'BOND',        'Government treasury bond'),
    ('SovereignBond',          'BOND',        'Non-treasury sovereign issues'),
    ('AgencyBond',             'BOND',        'Supranational / agency bond'),
    ('CorporateBond',          'BOND',        'Vanilla corporate bond'),
    ('MunicipalBond',          'BOND',        'Municipal / local government bond'),
    ('SubordinatedBond',       'BOND',        'Subordinated debt'),
    ('InflationLinkedBond',    'BOND',        'Inflation-linked government or corporate bond'),
    ('PerpetualBond',          'BOND',        'Bond with no fixed maturity'),
    ('CommercialPaper',        'BOND',        'Short-term unsecured note'),
    ('CertificateOfDeposit',   'BOND',        'Certificate of deposit / time deposit'),
    ('ConvertibleBond',        'BOND',        'Bond convertible into equity'),
    -- LOAN
    ('TermLoan',               'LOAN',        'Amortising or bullet term loan'),
    ('RevolvingLoan',          'LOAN',        'Revolving credit facility'),
    ('SyndicatedLoan',         'LOAN',        'Syndicated term / revolver'),
    ('MortgageLoan',           'LOAN',        'Mortgage loan'),
    ('ConsumerLoan',           'LOAN',        'Retail / consumer loan'),
    -- SECURITIZED
    ('ABS',                    'SECURITIZED', 'Asset-backed security (non-mortgage)'),
    ('MBS',                    'SECURITIZED', 'Mortgage-backed security (generic)'),
    ('RMBS',                   'SECURITIZED', 'Residential mortgage-backed security'),
    ('CMBS',                   'SECURITIZED', 'Commercial mortgage-backed security'),
    ('CLO',                    'SECURITIZED', 'Collateralised loan obligation'),
    ('CDO',                    'SECURITIZED', 'Collateralised debt obligation'),
    ('CoveredBond',            'SECURITIZED', 'Covered bond'),
    -- DERIVATIVE
    ('Future',                 'DERIVATIVE',  'Exchange-traded future (generic)'),
    ('InterestRateFuture',     'DERIVATIVE',  'Interest rate future'),
    ('EquityFuture',           'DERIVATIVE',  'Equity or index future'),
    ('Option',                 'DERIVATIVE',  'Generic option'),
    ('EquityOption',           'DERIVATIVE',  'Option on single stock or index'),
    ('BondOption',             'DERIVATIVE',  'Option on bond or future'),
    ('FXOption',               'DERIVATIVE',  'FX option'),
    ('Swap',                   'DERIVATIVE',  'Generic swap'),
    ('InterestRateSwap',       'DERIVATIVE',  'Fixed-float interest rate swap'),
    ('BasisSwap',              'DERIVATIVE',  'Float-float basis swap'),
    ('CrossCurrencySwap',      'DERIVATIVE',  'Cross-currency swap'),
    ('CDS',                    'DERIVATIVE',  'Credit default swap'),
    ('TotalReturnSwap',        'DERIVATIVE',  'Total return swap'),
    ('FXSwap',                 'DERIVATIVE',  'FX swap / forward-forward'),
    ('Forward',                'DERIVATIVE',  'Generic forward (non-listed)'),
    -- EQUITY
    ('Equity',                 'EQUITY',      'Common stock'),
    ('PreferredEquity',        'EQUITY',      'Preferred / preference shares'),
    ('DepositaryReceipt',      'EQUITY',      'ADR / GDR'),
    ('Warrant',                'EQUITY',      'Equity warrant'),
    ('Right',                  'EQUITY',      'Subscription right'),
    -- FUND
    ('MutualFund',             'FUND',        'Open-ended fund'),
    ('ExchangeTradedFund',     'FUND',        'Exchange-traded fund (ETF)'),
    ('HedgeFund',              'FUND',        'Hedge fund share class'),
    ('PooledVehicle',          'FUND',        'Other pooled investment vehicle'),
    -- MONEY_MARKET
    ('MoneyMarketFund',        'MONEY_MARKET','Money market fund share'),
    ('TreasuryBill',           'MONEY_MARKET','T-bill / short-dated sovereign note'),
    ('Repo',                   'MONEY_MARKET','Repurchase agreement'),
    ('Deposit',                'MONEY_MARKET','Term or call deposit'),
    -- FX
    ('FXSpot',                 'FX',          'FX spot'),
    ('FXForward',              'FX',          'FX forward'),
    ('FXNDF',                  'FX',          'Non-deliverable FX forward'),
    -- COMMODITY
    ('CommoditySpot',          'COMMODITY',   'Physical commodity spot'),
    ('CommodityFuture',        'COMMODITY',   'Commodity future'),
    ('CommoditySwap',          'COMMODITY',   'Swap on commodity index or price'),
    -- OTHER
    ('Index',                  'OTHER',       'Benchmark index (non-tradable)'),
    ('CustomStructuredProduct','OTHER',       'Bank-issued structured note / product'),
    ('Other',                  'OTHER',       'Catch-all for unclassified types')
) AS s (code, asset_class_code, description)
ON t.code = s.code
WHEN NOT MATCHED THEN INSERT (code, asset_class_code, description)
    VALUES (s.code, s.asset_class_code, s.description);
GO

-- ── 7. Add new columns to dbo.security (nullable initially) ───────────────────
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.security') AND name = 'status_code')
    ALTER TABLE dbo.security ADD status_code VARCHAR(32) NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.security') AND name = 'asset_class_code')
    ALTER TABLE dbo.security ADD asset_class_code VARCHAR(32) NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.security') AND name = 'instrument_type_code')
    ALTER TABLE dbo.security ADD instrument_type_code VARCHAR(64) NULL;
GO

-- ── 8. Populate new columns from the legacy [type] column ────────────────────
UPDATE dbo.security
SET
    status_code        = 'ACTIVE',
    asset_class_code   = CASE [type]
        WHEN 'ABS'           THEN 'SECURITIZED'
        WHEN 'Bond'          THEN 'BOND'
        WHEN 'CorporateBond' THEN 'BOND'
        WHEN 'MunicipalBond' THEN 'BOND'
        WHEN 'TreasuryBond'  THEN 'BOND'
        WHEN 'Equity'        THEN 'EQUITY'
        WHEN 'Loan'          THEN 'LOAN'
        WHEN 'Derivative'    THEN 'DERIVATIVE'
        WHEN 'Option'        THEN 'DERIVATIVE'
        WHEN 'Future'        THEN 'DERIVATIVE'
        WHEN 'Swap'          THEN 'DERIVATIVE'
        ELSE 'OTHER'
    END,
    instrument_type_code = CASE [type]
        WHEN 'ABS'           THEN 'ABS'
        WHEN 'Bond'          THEN 'CorporateBond'
        WHEN 'CorporateBond' THEN 'CorporateBond'
        WHEN 'MunicipalBond' THEN 'MunicipalBond'
        WHEN 'TreasuryBond'  THEN 'TreasuryBond'
        WHEN 'Equity'        THEN 'Equity'
        WHEN 'Loan'          THEN 'TermLoan'
        WHEN 'Derivative'    THEN 'Forward'
        WHEN 'Option'        THEN 'Option'
        WHEN 'Future'        THEN 'Future'
        WHEN 'Swap'          THEN 'Swap'
        ELSE 'Other'
    END
WHERE status_code IS NULL;
GO

-- ── 9. Make NOT NULL with defaults ────────────────────────────────────────────
ALTER TABLE dbo.security ALTER COLUMN status_code          VARCHAR(32) NOT NULL;
ALTER TABLE dbo.security ALTER COLUMN asset_class_code     VARCHAR(32) NOT NULL;
ALTER TABLE dbo.security ALTER COLUMN instrument_type_code VARCHAR(64) NOT NULL;
GO

IF NOT EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = 'df_security_status_code')
    ALTER TABLE dbo.security ADD CONSTRAINT df_security_status_code    DEFAULT 'ACTIVE' FOR status_code;
IF NOT EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = 'df_security_asset_class_code')
    ALTER TABLE dbo.security ADD CONSTRAINT df_security_asset_class_code DEFAULT 'OTHER' FOR asset_class_code;
IF NOT EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = 'df_security_instrument_type_code')
    ALTER TABLE dbo.security ADD CONSTRAINT df_security_instrument_type_code DEFAULT 'Other' FOR instrument_type_code;
GO

-- ── 10. Add FK constraints ────────────────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'fk_security_status_ref')
    ALTER TABLE dbo.security ADD CONSTRAINT fk_security_status_ref
        FOREIGN KEY (status_code) REFERENCES dbo.security_status_ref(code);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'fk_security_asset_class_ref')
    ALTER TABLE dbo.security ADD CONSTRAINT fk_security_asset_class_ref
        FOREIGN KEY (asset_class_code) REFERENCES dbo.asset_class_ref(code);
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'fk_security_instrument_type_ref')
    ALTER TABLE dbo.security ADD CONSTRAINT fk_security_instrument_type_ref
        FOREIGN KEY (instrument_type_code) REFERENCES dbo.instrument_type_ref(code);
GO

-- ── 11. Add indexes on the new columns ───────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_security_status_code' AND object_id = OBJECT_ID('dbo.security'))
    CREATE NONCLUSTERED INDEX ix_security_status_code
        ON dbo.security (status_code) WHERE is_deleted = 0;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_security_asset_class_code' AND object_id = OBJECT_ID('dbo.security'))
    CREATE NONCLUSTERED INDEX ix_security_asset_class_code
        ON dbo.security (asset_class_code) WHERE is_deleted = 0;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_security_instrument_type_code' AND object_id = OBJECT_ID('dbo.security'))
    CREATE NONCLUSTERED INDEX ix_security_instrument_type_code
        ON dbo.security (instrument_type_code) WHERE is_deleted = 0;
GO
