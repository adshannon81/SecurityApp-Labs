-- ============================================================
-- Migration: 20260426_FieldVisibilityRulePermissionFK.sql
-- Purpose  : Replace field_visibility_rule.required_permission
--            free-text column with a proper FK to
--            permission_definition.id.
-- ============================================================

SET NOCOUNT ON;
SET XACT_ABORT ON;

PRINT 'Starting FieldVisibilityRule permission FK migration...';

-- ──────────────────────────────────────────────────────────────
-- Step 1 — Add nullable FK column (idempotent)
-- ──────────────────────────────────────────────────────────────
IF NOT EXISTS (
    SELECT 1 FROM sys.columns
    WHERE  object_id = OBJECT_ID('dbo.field_visibility_rule')
    AND    name = 'permission_definition_id'
)
BEGIN
    PRINT '  Adding permission_definition_id column...';
    ALTER TABLE dbo.field_visibility_rule
        ADD permission_definition_id UNIQUEIDENTIFIER NULL
        CONSTRAINT FK_fvr_permission_definition
            FOREIGN KEY REFERENCES dbo.permission_definition(id);
    PRINT '  Column added.';
END
ELSE
    PRINT '  permission_definition_id already exists — skipped.';

-- ──────────────────────────────────────────────────────────────
-- Step 2 — Back-fill from existing required_permission strings
-- ──────────────────────────────────────────────────────────────
IF EXISTS (
    SELECT 1 FROM sys.columns
    WHERE  object_id = OBJECT_ID('dbo.field_visibility_rule')
    AND    name = 'required_permission'
)
BEGIN
    PRINT '  Back-filling permission_definition_id from required_permission...';
    UPDATE fvr
    SET    fvr.permission_definition_id = pd.id
    FROM   dbo.field_visibility_rule fvr
    JOIN   dbo.permission_definition  pd  ON pd.permission_key = fvr.required_permission
    WHERE  fvr.permission_definition_id IS NULL;
    PRINT '  Back-fill complete.';
END

-- ──────────────────────────────────────────────────────────────
-- Step 3 — Log any unmapped rows before proceeding
--          (should return 0 rows if AppPermissions are seeded)
-- ──────────────────────────────────────────────────────────────
IF EXISTS (
    SELECT 1 FROM sys.columns
    WHERE  object_id = OBJECT_ID('dbo.field_visibility_rule')
    AND    name = 'required_permission'
)
BEGIN
    DECLARE @unmapped INT;
    SELECT @unmapped = COUNT(*)
    FROM   dbo.field_visibility_rule
    WHERE  permission_definition_id IS NULL
    AND    required_permission IS NOT NULL;

    IF @unmapped > 0
    BEGIN
        PRINT '  WARNING: ' + CAST(@unmapped AS NVARCHAR) + ' row(s) could not be mapped to permission_definition.';
        SELECT id, required_permission
        FROM   dbo.field_visibility_rule
        WHERE  permission_definition_id IS NULL
        AND    required_permission IS NOT NULL;
    END
    ELSE
        PRINT '  All rows successfully mapped.';
END

-- ──────────────────────────────────────────────────────────────
-- Step 4 — Make FK column NOT NULL and drop the old string column
-- ──────────────────────────────────────────────────────────────
-- Drop existing unique index that used the old string column
IF EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE  object_id = OBJECT_ID('dbo.field_visibility_rule')
    AND    name = 'uq_field_visibility_rule_field_permission'
)
BEGIN
    PRINT '  Dropping old unique index uq_field_visibility_rule_field_permission...';
    DROP INDEX uq_field_visibility_rule_field_permission ON dbo.field_visibility_rule;
END

-- Make permission_definition_id NOT NULL
IF EXISTS (
    SELECT 1 FROM sys.columns
    WHERE  object_id = OBJECT_ID('dbo.field_visibility_rule')
    AND    name = 'permission_definition_id'
    AND    is_nullable = 1
)
BEGIN
    PRINT '  Making permission_definition_id NOT NULL...';
    ALTER TABLE dbo.field_visibility_rule
        ALTER COLUMN permission_definition_id UNIQUEIDENTIFIER NOT NULL;
END

-- Re-create the unique index on the new FK column
IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE  object_id = OBJECT_ID('dbo.field_visibility_rule')
    AND    name = 'uq_field_visibility_rule_field_permission'
)
BEGIN
    PRINT '  Creating new unique index on (field_visibility_field_id, permission_definition_id)...';
    CREATE UNIQUE INDEX uq_field_visibility_rule_field_permission
        ON dbo.field_visibility_rule(field_visibility_field_id, permission_definition_id)
        WHERE is_current = 1 AND is_deleted = 0;
END

-- Drop the old string column
IF EXISTS (
    SELECT 1 FROM sys.columns
    WHERE  object_id = OBJECT_ID('dbo.field_visibility_rule')
    AND    name = 'required_permission'
)
BEGIN
    PRINT '  Dropping required_permission column...';
    ALTER TABLE dbo.field_visibility_rule DROP COLUMN required_permission;
    PRINT '  Column dropped.';
END
ELSE
    PRINT '  required_permission column already removed — skipped.';

-- ──────────────────────────────────────────────────────────────
-- Step 5 — Register in schema version log
-- ──────────────────────────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM dbo.[__SchemaVersions] WHERE version = '7C-fvr-permission-fk')
BEGIN
    INSERT INTO dbo.[__SchemaVersions] (version, description, script_name)
    VALUES ('7C-fvr-permission-fk',
            'Replace field_visibility_rule.required_permission string with permission_definition_id FK',
            '20260426_FieldVisibilityRulePermissionFK.sql');
    PRINT '  Schema version 7C-fvr-permission-fk registered.';
END

PRINT 'Migration 20260426_FieldVisibilityRulePermissionFK complete.';
GO
