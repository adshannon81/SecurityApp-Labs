-- ============================================================================
-- Migration: 20260413_RebuildPositionTable
-- Purpose:   Upgrade dbo.position from simple status-based model to a
--            bi-temporal financial holdings table.
--            Removes: status, opened_at, closed_at, notes
--            Adds:    as_of_date, market_value, book_value, currency_code,
--                     source_system, and all temporal columns
--                     (valid_from/to, system_from/to, is_current, is_deleted,
--                     modified_by).
-- ============================================================================

SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;

BEGIN TRANSACTION;
BEGIN TRY

    -- ── 1. Drop existing FK constraints ──────────────────────────────────────
    IF EXISTS (
        SELECT 1 FROM sys.foreign_keys
        WHERE name = 'fk_position_portfolio' AND parent_object_id = OBJECT_ID('dbo.position')
    )
        ALTER TABLE dbo.position DROP CONSTRAINT fk_position_portfolio;

    IF EXISTS (
        SELECT 1 FROM sys.foreign_keys
        WHERE name = 'fk_position_security' AND parent_object_id = OBJECT_ID('dbo.position')
    )
        ALTER TABLE dbo.position DROP CONSTRAINT fk_position_security;

    -- ── 2. Drop existing indexes ──────────────────────────────────────────────
    IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_position_portfolio_id' AND object_id = OBJECT_ID('dbo.position'))
        DROP INDEX ix_position_portfolio_id ON dbo.position;

    IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_position_security_id'  AND object_id = OBJECT_ID('dbo.position'))
        DROP INDEX ix_position_security_id  ON dbo.position;

    IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'ix_position_status'       AND object_id = OBJECT_ID('dbo.position'))
        DROP INDEX ix_position_status       ON dbo.position;

    -- ── 3. Drop columns that no longer belong ─────────────────────────────────
    IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'status')
        ALTER TABLE dbo.position DROP COLUMN status;

    IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'opened_at')
        ALTER TABLE dbo.position DROP COLUMN opened_at;

    IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'closed_at')
        ALTER TABLE dbo.position DROP COLUMN closed_at;

    IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'notes')
        ALTER TABLE dbo.position DROP COLUMN notes;

    -- ── 4. Alter quantity precision: DECIMAL(18,8) → DECIMAL(28,8) ───────────
    ALTER TABLE dbo.position ALTER COLUMN quantity DECIMAL(28,8) NOT NULL;

    -- ── 5. Add new financial columns ──────────────────────────────────────────
    IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'as_of_date')
        ALTER TABLE dbo.position ADD as_of_date DATE NOT NULL CONSTRAINT df_position_as_of_date DEFAULT CAST(GETUTCDATE() AS DATE);

    IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'market_value')
        ALTER TABLE dbo.position ADD market_value DECIMAL(28,8) NULL;

    IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'book_value')
        ALTER TABLE dbo.position ADD book_value DECIMAL(28,8) NULL;

    IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'currency_code')
        ALTER TABLE dbo.position ADD currency_code CHAR(3) NOT NULL CONSTRAINT df_position_currency_code DEFAULT 'USD';

    IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'source_system')
        ALTER TABLE dbo.position ADD source_system NVARCHAR(50) NOT NULL CONSTRAINT df_position_source_system DEFAULT '';

    -- ── 6. Add bi-temporal columns ────────────────────────────────────────────
    IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'valid_from')
        ALTER TABLE dbo.position ADD valid_from DATETIME2 NOT NULL
            CONSTRAINT df_position_valid_from DEFAULT GETUTCDATE();

    IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'valid_to')
        ALTER TABLE dbo.position ADD valid_to DATETIME2 NOT NULL
            CONSTRAINT df_position_valid_to DEFAULT '9999-12-31 23:59:59';

    IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'system_from')
        ALTER TABLE dbo.position ADD system_from DATETIME2 NOT NULL
            CONSTRAINT df_position_system_from DEFAULT GETUTCDATE();

    IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'system_to')
        ALTER TABLE dbo.position ADD system_to DATETIME2 NOT NULL
            CONSTRAINT df_position_system_to DEFAULT '9999-12-31 23:59:59';

    IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'is_current')
        ALTER TABLE dbo.position ADD is_current BIT NOT NULL CONSTRAINT df_position_is_current DEFAULT 1;

    IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'is_deleted')
        ALTER TABLE dbo.position ADD is_deleted BIT NOT NULL CONSTRAINT df_position_is_deleted DEFAULT 0;

    IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.position') AND name = 'modified_by')
        ALTER TABLE dbo.position ADD modified_by NVARCHAR(255) NULL;

    -- ── 7. Backfill existing rows into temporal open state ────────────────────
    UPDATE dbo.position
    SET    valid_from   = created_at,
           valid_to     = '9999-12-31 23:59:59',
           system_from  = created_at,
           system_to    = '9999-12-31 23:59:59',
           is_current   = 1,
           is_deleted   = 0
    WHERE  valid_from   = GETUTCDATE()  -- only rows just defaulted
       AND valid_to     = '9999-12-31 23:59:59';

    -- ── 8. Re-add FK constraints ──────────────────────────────────────────────
    ALTER TABLE dbo.position
        ADD CONSTRAINT fk_position_portfolio
            FOREIGN KEY (portfolio_id) REFERENCES dbo.portfolio(id);

    ALTER TABLE dbo.position
        ADD CONSTRAINT fk_position_security
            FOREIGN KEY (security_id) REFERENCES dbo.security(id);

    -- ── 9. Rebuild indexes ────────────────────────────────────────────────────
    CREATE INDEX ix_position_portfolio_id
        ON dbo.position (portfolio_id);

    CREATE INDEX ix_position_security_id
        ON dbo.position (security_id);

    CREATE INDEX ix_position_portfolio_security_asofdate
        ON dbo.position (portfolio_id, security_id, as_of_date);

    CREATE INDEX ix_position_is_current
        ON dbo.position (is_current);

    CREATE INDEX ix_position_valid_from_to
        ON dbo.position (valid_from, valid_to);

    CREATE INDEX ix_position_system_from_to
        ON dbo.position (system_from, system_to);

    -- ── 10. Drop column-level defaults now that backfill is done ──────────────
    --  (Keeps schema clean; values are set by the application / interceptor.)
    ALTER TABLE dbo.position DROP CONSTRAINT df_position_as_of_date;
    ALTER TABLE dbo.position DROP CONSTRAINT df_position_currency_code;
    ALTER TABLE dbo.position DROP CONSTRAINT df_position_source_system;
    ALTER TABLE dbo.position DROP CONSTRAINT df_position_valid_from;
    ALTER TABLE dbo.position DROP CONSTRAINT df_position_valid_to;
    ALTER TABLE dbo.position DROP CONSTRAINT df_position_system_from;
    ALTER TABLE dbo.position DROP CONSTRAINT df_position_system_to;
    ALTER TABLE dbo.position DROP CONSTRAINT df_position_is_current;
    ALTER TABLE dbo.position DROP CONSTRAINT df_position_is_deleted;

    COMMIT TRANSACTION;
    PRINT 'Migration 20260413_RebuildPositionTable completed successfully.';

END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION;
    DECLARE @msg  NVARCHAR(4000) = ERROR_MESSAGE();
    DECLARE @line INT            = ERROR_LINE();
    RAISERROR('Migration failed at line %d: %s', 16, 1, @line, @msg);
END CATCH;
GO
