USE securityapp_db;
GO
-- Migration 1A: Idempotency Key Store
-- Prevents duplicate processing of mutating API calls (REST + gRPC).
-- Records expire via expires_at (set to NOW + 24h by application).
-- No TemporalEntity — rows are ephemeral, not business records.
-- Cleanup: ExecutionHistoryCleanupJob deletes rows WHERE expires_at < GETUTCDATE().

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'idempotency_key_store' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.idempotency_key_store (
        [key]          NVARCHAR(200) NOT NULL,
        operation_type NVARCHAR(100) NOT NULL,
        status         NVARCHAR(20)  NOT NULL DEFAULT 'PROCESSING',
        -- PROCESSING | COMPLETED | FAILED
        response_code  INT           NULL,
        response_body  NVARCHAR(MAX) NULL,
        created_at     DATETIME2(3)  NOT NULL DEFAULT GETUTCDATE(),
        expires_at     DATETIME2(3)  NOT NULL,
        CONSTRAINT pk_idempotency_key_store PRIMARY KEY ([key]),
        CONSTRAINT ck_idempotency_status CHECK (status IN ('PROCESSING','COMPLETED','FAILED'))
    );
    CREATE INDEX ix_idempotency_expires_at ON dbo.idempotency_key_store (expires_at);
END
GO
