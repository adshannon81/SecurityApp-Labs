-- ============================================================
-- Migration: 20260426_SweepFloatToDecimal.sql
-- Purpose  : Replace any remaining FLOAT / REAL columns with
--            DECIMAL equivalents per column-type conventions.
--
-- Conventions applied:
--   Monetary / price / rate   → DECIMAL(18,6)
--   Rating / score (numeric)  → DECIMAL(18,8)  [or existing precision if already converted]
--
-- NOTE: derived_rating.implied_pd, derived_rating.model_pd, and
--       vendor_rating_metadata.*_score were already converted in
--       20260420_SecurityIdentifierAndSchemaImprovements.sql.
--       This script is idempotent and verifies there are no
--       remaining FLOAT / REAL columns in application tables.
-- ============================================================

SET NOCOUNT ON;
SET XACT_ABORT ON;

PRINT 'Starting FLOAT/REAL sweep migration...';

-- ──────────────────────────────────────────────────────────────
-- 1.  derived_rating.implied_pd  (guard – already decimal(12,10))
-- ──────────────────────────────────────────────────────────────
IF EXISTS (
    SELECT 1 FROM sys.columns c
    JOIN   sys.objects o ON o.object_id = c.object_id
    WHERE  o.name = 'derived_rating'
    AND    c.name = 'implied_pd'
    AND    c.system_type_id IN (TYPE_ID('float'), TYPE_ID('real'))
)
BEGIN
    PRINT '  Altering derived_rating.implied_pd FLOAT → DECIMAL(12,10)';
    ALTER TABLE dbo.derived_rating ALTER COLUMN implied_pd DECIMAL(12,10) NULL;
END
ELSE
    PRINT '  derived_rating.implied_pd: already DECIMAL — skipped.';

-- ──────────────────────────────────────────────────────────────
-- 2.  derived_rating.model_pd  (guard – already decimal(12,10))
-- ──────────────────────────────────────────────────────────────
IF EXISTS (
    SELECT 1 FROM sys.columns c
    JOIN   sys.objects o ON o.object_id = c.object_id
    WHERE  o.name = 'derived_rating'
    AND    c.name = 'model_pd'
    AND    c.system_type_id IN (TYPE_ID('float'), TYPE_ID('real'))
)
BEGIN
    PRINT '  Altering derived_rating.model_pd FLOAT → DECIMAL(12,10)';
    ALTER TABLE dbo.derived_rating ALTER COLUMN model_pd DECIMAL(12,10) NULL;
END
ELSE
    PRINT '  derived_rating.model_pd: already DECIMAL — skipped.';

-- ──────────────────────────────────────────────────────────────
-- 3.  vendor_rating_metadata.*_score  (guard – already decimal(5,4))
-- ──────────────────────────────────────────────────────────────
IF EXISTS (
    SELECT 1 FROM sys.columns c
    JOIN   sys.objects o ON o.object_id = c.object_id
    WHERE  o.name = 'vendor_rating_metadata'
    AND    c.name IN ('accuracy_score','stability_score','timeliness_score','coverage_score')
    AND    c.system_type_id IN (TYPE_ID('float'), TYPE_ID('real'))
)
BEGIN
    PRINT '  Altering vendor_rating_metadata score columns FLOAT → DECIMAL(5,4)';
    ALTER TABLE dbo.vendor_rating_metadata ALTER COLUMN accuracy_score   DECIMAL(5,4) NOT NULL;
    ALTER TABLE dbo.vendor_rating_metadata ALTER COLUMN stability_score  DECIMAL(5,4) NOT NULL;
    ALTER TABLE dbo.vendor_rating_metadata ALTER COLUMN timeliness_score DECIMAL(5,4) NOT NULL;
    ALTER TABLE dbo.vendor_rating_metadata ALTER COLUMN coverage_score   DECIMAL(5,4) NOT NULL;
END
ELSE
    PRINT '  vendor_rating_metadata score columns: already DECIMAL — skipped.';

-- ──────────────────────────────────────────────────────────────
-- 4.  Verification — report any remaining FLOAT/REAL columns
--     in user-created tables (non-system, non-temporal)
-- ──────────────────────────────────────────────────────────────
DECLARE @remaining INT;
SELECT @remaining = COUNT(*)
FROM   sys.columns c
JOIN   sys.objects o ON o.object_id = c.object_id
WHERE  o.type = 'U'                             -- user tables only
AND    c.system_type_id IN (TYPE_ID('float'), TYPE_ID('real'))
AND    o.name NOT IN (
    -- EF temporal system-time tables use float internally in some metadata views
    -- Add any intentionally-float tables here
    '__EFMigrationsHistory'
);

IF @remaining = 0
    PRINT '  Sweep complete: zero FLOAT/REAL columns remain.';
ELSE
BEGIN
    PRINT '  WARNING: ' + CAST(@remaining AS NVARCHAR) + ' FLOAT/REAL column(s) still exist:';
    SELECT o.name AS table_name, c.name AS column_name,
           tp.name AS type_name
    FROM   sys.columns c
    JOIN   sys.objects o  ON o.object_id = c.object_id
    JOIN   sys.types   tp ON tp.user_type_id = c.user_type_id
    WHERE  o.type = 'U'
    AND    c.system_type_id IN (TYPE_ID('float'), TYPE_ID('real'))
    AND    o.name NOT IN ('__EFMigrationsHistory');
END

-- ──────────────────────────────────────────────────────────────
-- 5.  Register in schema version log
-- ──────────────────────────────────────────────────────────────
IF NOT EXISTS (SELECT 1 FROM dbo.[__SchemaVersions] WHERE version = '7B-sweep-float-decimal')
BEGIN
    INSERT INTO dbo.[__SchemaVersions] (version, description, script_name)
    VALUES ('7B-sweep-float-decimal',
            'Replace all FLOAT/REAL columns with DECIMAL equivalents',
            '20260426_SweepFloatToDecimal.sql');
    PRINT '  Schema version 7B-sweep-float-decimal registered.';
END

PRINT 'Migration 20260426_SweepFloatToDecimal complete.';
GO
