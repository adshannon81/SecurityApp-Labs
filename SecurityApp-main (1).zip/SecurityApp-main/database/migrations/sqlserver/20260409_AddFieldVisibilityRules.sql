-- ============================================================
-- Migration: Add FieldVisibilityRules table
-- Date:      2026-04-09
-- Purpose:   Dynamic DB-driven field-level visibility control.
--            Replaces compile-time [FieldPermission] attributes.
-- ============================================================

CREATE TABLE field_visibility_rules (
    id                    INT IDENTITY(1,1) NOT NULL,
    entity_type           NVARCHAR(200)     NOT NULL,
    field_name            NVARCHAR(200)     NOT NULL,
    required_permission   NVARCHAR(200)     NOT NULL,
    visibility            NVARCHAR(20)      NOT NULL,   -- 'Full' | 'Obfuscated'
    obfuscation_type      NVARCHAR(20)      NOT NULL CONSTRAINT df_fvr_obfuscation_type DEFAULT 'None',
    priority              INT               NOT NULL CONSTRAINT df_fvr_priority          DEFAULT 10,
    is_active             BIT               NOT NULL CONSTRAINT df_fvr_is_active          DEFAULT 1,
    created_at            DATETIME2         NOT NULL CONSTRAINT df_fvr_created_at         DEFAULT SYSUTCDATETIME(),
    updated_at            DATETIME2         NULL,

    CONSTRAINT pk_field_visibility_rules PRIMARY KEY (id),
    CONSTRAINT ux_field_visibility_rules_entity_field_permission
        UNIQUE (entity_type, field_name, required_permission)
);

CREATE INDEX ix_field_visibility_rules_entity_type
    ON field_visibility_rules (entity_type);

-- ============================================================
-- Seed: replicate the previous [FieldPermission] attribute
-- behaviour for SecurityDto.
--
-- Basic fields (securities:read → Full, priority 10)
-- Internal fields have two tiers:
--   securities:view-full       → Full,        priority 20
--   securities:view-internal   → Full,        priority 10  (keep old behaviour)
-- ============================================================

INSERT INTO field_visibility_rules (entity_type, field_name, required_permission, visibility, obfuscation_type, priority)
VALUES
  -- Core identity fields
  ('SecurityDto', 'IdentifierType',  'securities:read', 'Full', 'None', 10),
  ('SecurityDto', 'IdentifierValue', 'securities:read', 'Full', 'None', 10),
  ('SecurityDto', 'Name',            'securities:read', 'Full', 'None', 10),
  ('SecurityDto', 'Type',            'securities:read', 'Full', 'None', 10),
  ('SecurityDto', 'IsActive',        'securities:read', 'Full', 'None', 10),
  ('SecurityDto', 'Description',     'securities:read', 'Full', 'None', 10),
  ('SecurityDto', 'Issuer',          'securities:read', 'Full', 'None', 10),
  ('SecurityDto', 'Currency',        'securities:read', 'Full', 'None', 10),
  ('SecurityDto', 'CreatedAt',       'securities:read', 'Full', 'None', 10),
  ('SecurityDto', 'UpdatedAt',       'securities:read', 'Full', 'None', 10),
  ('SecurityDto', 'Attributes',      'securities:read', 'Full', 'None', 10),
  ('SecurityDto', 'CreditRatings',   'securities:read', 'Full', 'None', 10),

  -- Internal fields — full view requires securities:view-internal (existing role)
  -- Add a second row per field with securities:view-obfuscated / Obfuscated
  -- whenever you want a middle tier (managed via admin UI without redeployment)
  ('SecurityDto', 'ModifiedBy',  'securities:view-internal', 'Full', 'None', 10),
  ('SecurityDto', 'ContentHash', 'securities:view-internal', 'Full', 'None', 10);
