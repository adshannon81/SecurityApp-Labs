-- ============================================================
-- Migration: SeedFieldGroups_PostgreSQL
-- Date: 2026-05-17
-- Description: Creates one "All Fields" field_group per
--   field_visibility_entity and adds every field as a member.
--   Idempotent — safe to run multiple times.
-- ============================================================

-- ── field_group: one group per entity that has no groups yet ─────────────────
INSERT INTO field_group (field_visibility_entity_id, group_key, display_name, description, sort_order, created_by)
SELECT fve.id,
       regexp_replace(lower(fve.entity_type), 'dto$', '') || '-all-fields',
       'All Fields',
       'Default group containing all ' || fve.display_name || ' fields',
       10,
       'seed'
FROM field_visibility_entity fve
WHERE fve.is_current AND NOT fve.is_deleted
  AND NOT EXISTS (
    SELECT 1 FROM field_group g
    WHERE g.field_visibility_entity_id = fve.id
      AND g.is_current AND NOT g.is_deleted
  );

-- ── field_group_member: all fields added to their entity's group ──────────────
INSERT INTO field_group_member (field_group_id, field_visibility_field_id, created_by)
SELECT fg.id, fvf.id, 'seed'
FROM field_visibility_field fvf
JOIN field_group fg
  ON fg.field_visibility_entity_id = fvf.field_visibility_entity_id
 AND fg.is_current AND NOT fg.is_deleted
WHERE fvf.is_current AND NOT fvf.is_deleted
  AND NOT EXISTS (
    SELECT 1 FROM field_group_member m
    WHERE m.field_group_id              = fg.id
      AND m.field_visibility_field_id   = fvf.id
      AND m.is_current AND NOT m.is_deleted
  );
