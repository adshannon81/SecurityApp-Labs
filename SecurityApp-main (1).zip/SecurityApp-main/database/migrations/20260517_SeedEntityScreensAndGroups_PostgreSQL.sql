-- =======================================================================
-- 2026-05-17  Seed: App Resource Groups, Entity Screens, Admin-Only Rules
--
-- Groups   : logical organisation of app_resource rows
-- Screens  : populate the ar/matrix dropdown (one per major UI area)
-- Rules    : nav.admin* and route./admin* are Visible only for admin:super
--            → contributor@securityapp.local (no admin:super) won't see admin
-- =======================================================================
BEGIN;

-- ── 1. App Resource Groups ──────────────────────────────────────────────
INSERT INTO app_resource_group
  (group_key, display_name, description, icon_name, sort_order, created_by)
SELECT v.group_key, v.display_name, v.description, v.icon_name, v.sort_order, 'seed'
FROM (VALUES
  ('nav-main',         'Main Navigation',    'Top-level navigation visible to all users',           'menu',                  10),
  ('nav-admin',        'Admin Navigation',   'Navigation items within the administration area',     'admin_panel_settings',  20),
  ('routes-feature',   'Feature Routes',     'User-facing application page routes',                 'route',                 30),
  ('routes-admin',     'Admin Routes',       'Administration page routes',                          'settings',              40),
  ('actions-security', 'Security Actions',   'CRUD and export actions on securities',               'shield',                50),
  ('actions-feature',  'Feature Actions',    'Operational actions: ratings, pricing, imports',      'bolt',                  60)
) AS v(group_key, display_name, description, icon_name, sort_order)
WHERE NOT EXISTS (
  SELECT 1 FROM app_resource_group g
  WHERE g.group_key = v.group_key AND g.is_current AND NOT g.is_deleted
);

-- ── 2. Entity Screens ───────────────────────────────────────────────────
-- Each screen links to its primary route app_resource via resource_key.
-- Screens appear in the ar/matrix "Screen" dropdown.
INSERT INTO entity_screen
  (screen_key, display_name, description, app_resource_id, sort_order, created_by)
SELECT v.screen_key, v.display_name, v.description, ar.id, v.sort_order, 'seed'
FROM (VALUES
  ('screen.dashboard',         'Dashboard',                 'Main dashboard overview',                   'route./dashboard',                      10),
  ('screen.securities',        'Securities',                'Securities list and management',             'route./securities',                     20),
  ('screen.issuers',           'Issuers',                   'Issuers list and management',                'route./issuers',                        30),
  ('screen.ratings',           'Ratings',                   'Ratings overview and calculations',          'route./ratings',                        40),
  ('screen.pricing',           'Pricing',                   'Pricing overview and rules',                 'route./pricing',                        50),
  ('screen.portfolios',        'Portfolios',                'Portfolio management',                       'route./portfolios',                     60),
  ('screen.imports',           'Imports',                   'Data import management',                     'route./imports',                        70),
  ('screen.jobs',              'Jobs',                      'Background job monitoring',                  'route./jobs',                           80),
  ('screen.workflows',         'Workflows',                 'Workflow instance management',               'route./workflows',                      90),
  ('screen.history',           'History',                   'Audit and change history',                   'route./history',                        100),
  ('screen.admin',             'Admin',                     'Administration landing page',                'route./admin',                          200),
  ('screen.admin.fv',          'Admin — Field Visibility',  'Field visibility configuration',             'route./admin/fv/entities',              210),
  ('screen.admin.ar',          'Admin — App Resources',     'App resource and rule management',           'route./admin/ar/resources',             220),
  ('screen.admin.permissions', 'Admin — Permissions',       'Permission catalog, bundles and templates',  'route./admin/permissions/catalog',      230),
  ('screen.admin.monitoring',  'Admin — Monitoring',        'Audit history, dead letters and system',     'route./admin/audit-history',            240)
) AS v(screen_key, display_name, description, resource_key, sort_order)
JOIN app_resource ar ON ar.resource_key = v.resource_key AND ar.is_current AND NOT ar.is_deleted
WHERE NOT EXISTS (
  SELECT 1 FROM entity_screen es
  WHERE es.screen_key = v.screen_key AND es.is_current AND NOT es.is_deleted
);

-- ── 3. Admin-Only Resource Rules ────────────────────────────────────────
-- All nav.admin* / group.admin / route./admin* resources require admin:super
-- to be visible. Users without that permission (e.g. contributors) will not
-- see the admin navigation or be able to reach admin routes.
--
-- Permission: admin:super  id = b955d39e-fead-468d-983c-a5cc544f0b3a
INSERT INTO app_resource_rule
  (app_resource_id, permission_definition_id, visibility_state, execution_state, priority, created_by)
SELECT
  ar.id,
  'b955d39e-fead-468d-983c-a5cc544f0b3a',
  'VISIBLE',
  'ALLOW',
  100,
  'seed'
FROM app_resource ar
WHERE ar.is_current AND NOT ar.is_deleted
  AND (
       ar.resource_key LIKE 'nav.admin%'
    OR ar.resource_key LIKE 'route./admin%'
    OR ar.resource_key = 'group.admin'
  )
  AND NOT EXISTS (
    SELECT 1 FROM app_resource_rule r
    WHERE r.app_resource_id = ar.id
      AND r.permission_definition_id = 'b955d39e-fead-468d-983c-a5cc544f0b3a'
      AND r.is_current AND NOT r.is_deleted
  );

COMMIT;
