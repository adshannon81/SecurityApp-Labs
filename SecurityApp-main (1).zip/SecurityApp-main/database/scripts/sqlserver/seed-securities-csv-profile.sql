SET NOCOUNT ON;
DECLARE @pid UNIQUEIDENTIFIER = NEWID();

INSERT INTO dbo.import_profiles
    (id, name, description, source_type, file_pattern, folder,
     delimiter, text_qualifier, has_header, skip_rows, is_active, created_at)
VALUES
    (@pid,
     'Securities CSV Import',
     'Standard securities CSV with text qualifiers. Maps IdentifierType/IdentifierValue/Name/Type/Currency/Issuer/Description.',
     'FlatFile', '*.csv', NULL,
     ',', '"', 1, 0, 1, GETUTCDATE());

DECLARE @c0 UNIQUEIDENTIFIER = NEWID();
DECLARE @c1 UNIQUEIDENTIFIER = NEWID();
DECLARE @c2 UNIQUEIDENTIFIER = NEWID();
DECLARE @c3 UNIQUEIDENTIFIER = NEWID();
DECLARE @c4 UNIQUEIDENTIFIER = NEWID();
DECLARE @c5 UNIQUEIDENTIFIER = NEWID();
DECLARE @c6 UNIQUEIDENTIFIER = NEWID();

INSERT INTO dbo.import_profile_columns
    (id, profile_id, source_column, target_field, sort_order, created_at)
VALUES
    (@c0, @pid, 'IdentifierType',  'identifiertype',  0, GETUTCDATE()),
    (@c1, @pid, 'IdentifierValue', 'identifiervalue', 1, GETUTCDATE()),
    (@c2, @pid, 'Name',            'name',            2, GETUTCDATE()),
    (@c3, @pid, 'Type',            'type',            3, GETUTCDATE()),
    (@c4, @pid, 'Currency',        'currency',        4, GETUTCDATE()),
    (@c5, @pid, 'Issuer',          'issuer',          5, GETUTCDATE()),
    (@c6, @pid, 'Description',     'description',     6, GETUTCDATE());

-- IdentifierValue: Required
INSERT INTO dbo.import_profile_column_validations
    (id, column_id, rule_type, rule_value, condition, error_message, severity, is_active, created_at)
VALUES (NEWID(), @c1, 'Required', NULL, NULL, 'IdentifierValue is required.', 'Error', 1, GETUTCDATE());

-- Name: Required
INSERT INTO dbo.import_profile_column_validations
    (id, column_id, rule_type, rule_value, condition, error_message, severity, is_active, created_at)
VALUES (NEWID(), @c2, 'Required', NULL, NULL, 'Name is required.', 'Error', 1, GETUTCDATE());

-- Type: Required + AllowedValues
INSERT INTO dbo.import_profile_column_validations
    (id, column_id, rule_type, rule_value, condition, error_message, severity, is_active, created_at)
VALUES
    (NEWID(), @c3, 'Required', NULL, NULL, 'Type is required.', 'Error', 1, GETUTCDATE()),
    (NEWID(), @c3, 'AllowedValues',
     'ABS,Bond,CorporateBond,MunicipalBond,TreasuryBond,Equity,Loan,Derivative,Option,Future,Swap,Other',
     NULL, 'Unknown security type. Row will use ''Other''.', 'Warning', 1, GETUTCDATE());

-- IdentifierType: AllowedValues
INSERT INTO dbo.import_profile_column_validations
    (id, column_id, rule_type, rule_value, condition, error_message, severity, is_active, created_at)
VALUES
    (NEWID(), @c0, 'AllowedValues',
     'Ticker,ISIN,CUSIP,SEDOL,Bloomberg,Reuters,Internal,Other',
     NULL, 'Unknown identifier type. Defaulting to Ticker.', 'Warning', 1, GETUTCDATE());

PRINT 'Inserted: Securities CSV Import profile';
SELECT name, source_type, delimiter, text_qualifier, has_header FROM dbo.import_profiles WHERE id = @pid;
SELECT source_column, target_field FROM dbo.import_profile_columns WHERE profile_id = @pid ORDER BY sort_order;
