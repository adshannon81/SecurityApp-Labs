﻿# Apply-Migrations-SqlServer.ps1
# -----------------------------------------------------------------------------
# Applies the SecurityApp schema and seed data to SQL Server, then creates
# least-privilege logins for the API ('securityapp') and Keycloak ('keycloak').
#
# Called by deploy.ps1 (Step 8) with -AppDbPassword and -KcDbPassword.
# Can also be run manually for a fresh container.
#
# Usage:
#   .\Apply-Migrations-SqlServer.ps1 -AppDbPassword "SomePass123!" -KcDbPassword "KcPass456!"
#
# Environment (read from docker-compose / .env):
#   MSSQL_SA_PASSWORD  - set by docker-compose; must be resolvable by the
#                        sqlserver container name from the host
# -----------------------------------------------------------------------------

param(
    [string]$SaPassword  = '',   # SA (admin) password - fetched from Vault if omitted
    [Parameter(Mandatory)]
    [string]$AppDbPassword,      # password for the least-privilege 'securityapp' login
    [Parameter(Mandatory)]
    [string]$KcDbPassword        # password for the least-privilege 'keycloak' login
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$Root      = Split-Path (Split-Path (Split-Path $PSScriptRoot -Parent) -Parent) -Parent  # project root
$SchemaDir = Join-Path $Root 'database\schema\sqlserver'

# -- Resolve SA password: param > env var > Vault ----------------------------
if ([string]::IsNullOrWhiteSpace($SaPassword)) {
    $SaPassword = $env:MSSQL_SA_PASSWORD
}
if ([string]::IsNullOrWhiteSpace($SaPassword)) {
    # Fetch from Vault using root token (works after vault is healthy and seeded)
    Write-Host "  [DB]   SA password not supplied - reading from Vault..." -ForegroundColor DarkGray
    $vaultRoot = docker exec securityapp-vault cat /vault/data/.init.json 2>&1 |
        Select-String '"root_token"' |
        ForEach-Object { if ($_ -match '"root_token"\s*:\s*"([^"]+)"') { $Matches[1] } }
    if ($vaultRoot) {
        $SaPassword = docker exec -e "VAULT_TOKEN=$vaultRoot" securityapp-vault `
            vault kv get -field=saPassword secret/admin/database 2>&1
        if ($LASTEXITCODE -ne 0) { $SaPassword = '' }
        else { $SaPassword = $SaPassword.Trim() }
    }
}
if ([string]::IsNullOrWhiteSpace($SaPassword)) {
    Write-Error "Could not determine SA password. Pass -SaPassword, set MSSQL_SA_PASSWORD, or ensure Vault is seeded."
    exit 1
}

function Invoke-Sqlcmd18([string]$Query, [string]$Database = 'master') {
    $result = docker exec securityapp-sqlserver `
        /opt/mssql-tools18/bin/sqlcmd `
        -S localhost -U sa -P $SaPassword `
        -d $Database -Q $Query -C -b 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Error "sqlcmd failed:`n$result"
        exit 1
    }
    return $result
}

function Invoke-SqlcmdFile([string]$FilePath, [string]$Database = 'securityapp_db') {
    # Pipe SQL content via stdin — avoids docker cp and permission issues with /tmp
    $result = Get-Content $FilePath -Raw |
        docker exec -i securityapp-sqlserver `
            /opt/mssql-tools18/bin/sqlcmd `
            -S localhost -U sa -P $SaPassword `
            -d $Database -C -b 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Error "sqlcmd file failed ($FilePath):`n$result"
        exit 1
    }
    return $result
}

# ---------------------------------------------------------------------------
Write-Host "  [DB]   Creating securityapp_db (if not exists)..." -ForegroundColor DarkGray
Invoke-Sqlcmd18 "IF DB_ID('securityapp_db') IS NULL CREATE DATABASE [securityapp_db];" | Out-Null
Write-Host "  [OK]   Database ready." -ForegroundColor Green

# ---------------------------------------------------------------------------
# keycloak_db — Keycloak cannot create its own database; it must already exist.
# ---------------------------------------------------------------------------
Write-Host "  [DB]   Creating keycloak_db (if not exists)..." -ForegroundColor DarkGray
Invoke-Sqlcmd18 "IF DB_ID('keycloak_db') IS NULL CREATE DATABASE [keycloak_db] COLLATE Latin1_General_100_CI_AS_SC_UTF8;" | Out-Null
Write-Host "  [OK]   keycloak_db ready." -ForegroundColor Green

# ---------------------------------------------------------------------------
Write-Host "  [DB]   Applying schema..." -ForegroundColor DarkGray
Invoke-SqlcmdFile (Join-Path $SchemaDir 'CreateSchema_SqlServer.sql')
Write-Host "  [OK]   Schema applied." -ForegroundColor Green

# ---------------------------------------------------------------------------
Write-Host "  [DB]   Seeding data..." -ForegroundColor DarkGray
Invoke-SqlcmdFile (Join-Path $SchemaDir 'SeedData_SqlServer.sql')
Write-Host "  [OK]   Seed data applied." -ForegroundColor Green

# ---------------------------------------------------------------------------
# Create least-privilege application login + user
# The API uses this login - not sa. Permissions: read + write + execute procs.
# ---------------------------------------------------------------------------
Write-Host "  [DB]   Creating application login 'securityapp'..." -ForegroundColor DarkGray

# Escape the password for T-SQL (replace ' with '')
$escapedPass = $AppDbPassword -replace "'", "''"

$createLoginSql = @"
-- Server-level login
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = 'securityapp')
    CREATE LOGIN [securityapp] WITH PASSWORD = '$escapedPass',
        CHECK_EXPIRATION = OFF, CHECK_POLICY = OFF;
ELSE
    ALTER LOGIN [securityapp] WITH PASSWORD = '$escapedPass';
GO

-- Database user mapped to login
USE [securityapp_db];
GO
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'securityapp')
    CREATE USER [securityapp] FOR LOGIN [securityapp];
GO

-- Least-privilege roles: read rows, write rows, execute stored procedures
ALTER ROLE [db_datareader] ADD MEMBER [securityapp];
ALTER ROLE [db_datawriter] ADD MEMBER [securityapp];
-- Allow EXECUTE on all procedures (for any sprocs used by the app)
GRANT EXECUTE TO [securityapp];
GO
"@

Invoke-Sqlcmd18 $createLoginSql 'master' | Out-Null
Write-Host "  [OK]   Application login 'securityapp' created with least-privilege access." -ForegroundColor Green

# ---------------------------------------------------------------------------
# Create least-privilege Keycloak login + user
# Keycloak needs db_owner on keycloak_db to run its Liquibase migrations,
# but must NOT touch any other database.
# ---------------------------------------------------------------------------
Write-Host "  [DB]   Creating Keycloak login 'keycloak'..." -ForegroundColor DarkGray

$escapedKcPass = $KcDbPassword -replace "'", "''"

$createKcLoginSql = @"
-- Server-level login
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = 'keycloak')
    CREATE LOGIN [keycloak] WITH PASSWORD = '$escapedKcPass',
        CHECK_EXPIRATION = OFF, CHECK_POLICY = OFF;
ELSE
    ALTER LOGIN [keycloak] WITH PASSWORD = '$escapedKcPass';
GO

-- Database user mapped to login
USE [keycloak_db];
GO
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'keycloak')
    CREATE USER [keycloak] FOR LOGIN [keycloak];
GO

-- db_owner on keycloak_db only (Keycloak Liquibase needs DDL rights on its own schema)
ALTER ROLE [db_owner] ADD MEMBER [keycloak];
GO
"@

Invoke-Sqlcmd18 $createKcLoginSql 'master' | Out-Null
Write-Host "  [OK]   Keycloak login 'keycloak' created with db_owner on keycloak_db only." -ForegroundColor Green

Write-Host "  [OK]   SQL Server migrations complete." -ForegroundColor Green
exit 0
