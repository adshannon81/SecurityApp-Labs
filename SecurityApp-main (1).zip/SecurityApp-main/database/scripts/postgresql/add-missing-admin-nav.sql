-- ============================================================
-- Migration: Add missing admin nav items to sidebar
-- Removes dependency on topbar gear icon panel.
-- Idempotent — safe to run multiple times.
-- ============================================================

DO $$
DECLARE
    rAdmin       UUID;
    rFvSection   UUID;
    rArSection   UUID;
    rPermSection UUID;
    rSysSection  UUID;
BEGIN
    -- Resolve existing parent IDs
    SELECT id INTO rAdmin       FROM app_resource WHERE resource_key = 'nav.admin'       AND is_current = TRUE AND is_deleted = FALSE;
    SELECT id INTO rFvSection   FROM app_resource WHERE resource_key = 'nav.admin.fv'    AND is_current = TRUE AND is_deleted = FALSE;
    SELECT id INTO rArSection   FROM app_resource WHERE resource_key = 'nav.admin.ar'    AND is_current = TRUE AND is_deleted = FALSE;
    SELECT id INTO rPermSection FROM app_resource WHERE resource_key = 'nav.admin.perm'  AND is_current = TRUE AND is_deleted = FALSE;

    -- ── Add System section (if not present) ──────────────────────────────────
    IF NOT EXISTS (SELECT 1 FROM app_resource WHERE resource_key = 'nav.admin.system' AND is_current = TRUE AND is_deleted = FALSE) THEN
        INSERT INTO app_resource
            (id, resource_type, resource_key, display_name, icon_name, route_path,
             parent_app_resource_id, sort_order,
             default_visibility_state, default_execution_state, is_security_sensitive, is_active)
        VALUES
            (gen_random_uuid(), 'SECTION', 'nav.admin.system', 'System', NULL, NULL, rAdmin, 40, 'HIDDEN', 'DENY', TRUE, TRUE);
    END IF;

    SELECT id INTO rSysSection FROM app_resource WHERE resource_key = 'nav.admin.system' AND is_current = TRUE AND is_deleted = FALSE;

    -- ── Add missing FV nav items ──────────────────────────────────────────────
    IF NOT EXISTS (SELECT 1 FROM app_resource WHERE resource_key = 'nav.admin.fv.matrix' AND is_current = TRUE AND is_deleted = FALSE) THEN
        INSERT INTO app_resource
            (id, resource_type, resource_key, display_name, icon_name, route_path,
             parent_app_resource_id, sort_order,
             default_visibility_state, default_execution_state, is_security_sensitive, is_active)
        VALUES
            (gen_random_uuid(), 'MENU_ITEM', 'nav.admin.fv.matrix', 'FV Matrix',    NULL, '/admin/fv/matrix', rFvSection, 40, 'HIDDEN', 'DENY', TRUE, TRUE),
            (gen_random_uuid(), 'MENU_ITEM', 'nav.admin.fv.groups', 'Field Groups', NULL, '/admin/fv/groups', rFvSection, 50, 'HIDDEN', 'DENY', TRUE, TRUE);
    END IF;

    -- ── Add missing AR nav items ──────────────────────────────────────────────
    IF NOT EXISTS (SELECT 1 FROM app_resource WHERE resource_key = 'nav.admin.ar.groups' AND is_current = TRUE AND is_deleted = FALSE) THEN
        INSERT INTO app_resource
            (id, resource_type, resource_key, display_name, icon_name, route_path,
             parent_app_resource_id, sort_order,
             default_visibility_state, default_execution_state, is_security_sensitive, is_active)
        VALUES
            (gen_random_uuid(), 'MENU_ITEM', 'nav.admin.ar.groups',  'Resource Groups', NULL, '/admin/ar/groups',  rArSection, 30, 'HIDDEN', 'DENY', TRUE, TRUE),
            (gen_random_uuid(), 'MENU_ITEM', 'nav.admin.ar.matrix',  'AR Matrix',       NULL, '/admin/ar/matrix',  rArSection, 40, 'HIDDEN', 'DENY', TRUE, TRUE);
    END IF;

    -- ── Add missing Permissions nav items ────────────────────────────────────
    IF NOT EXISTS (SELECT 1 FROM app_resource WHERE resource_key = 'nav.admin.perm.bundles' AND is_current = TRUE AND is_deleted = FALSE) THEN
        INSERT INTO app_resource
            (id, resource_type, resource_key, display_name, icon_name, route_path,
             parent_app_resource_id, sort_order,
             default_visibility_state, default_execution_state, is_security_sensitive, is_active)
        VALUES
            (gen_random_uuid(), 'MENU_ITEM', 'nav.admin.perm.bundles',        'Bundles',          NULL, '/admin/permissions/bundles',        rPermSection, 20, 'HIDDEN', 'DENY', TRUE, TRUE),
            (gen_random_uuid(), 'MENU_ITEM', 'nav.admin.perm.templates',      'Policy Templates', NULL, '/admin/permissions/templates',      rPermSection, 30, 'HIDDEN', 'DENY', TRUE, TRUE),
            (gen_random_uuid(), 'MENU_ITEM', 'nav.admin.perm.entity-screens', 'Entity Screens',   NULL, '/admin/permissions/entity-screens', rPermSection, 40, 'HIDDEN', 'DENY', TRUE, TRUE);
    END IF;

    -- ── Add System nav items (Workflows, Vendor Sources, Dead Letters) ────────
    IF NOT EXISTS (SELECT 1 FROM app_resource WHERE resource_key = 'nav.admin.workflows' AND is_current = TRUE AND is_deleted = FALSE) THEN
        INSERT INTO app_resource
            (id, resource_type, resource_key, display_name, icon_name, route_path,
             parent_app_resource_id, sort_order,
             default_visibility_state, default_execution_state, is_security_sensitive, is_active)
        VALUES
            (gen_random_uuid(), 'MENU_ITEM', 'nav.admin.workflows',      'Workflow Definitions', NULL, '/admin/workflows',      rSysSection, 10, 'HIDDEN', 'DENY', TRUE, TRUE),
            (gen_random_uuid(), 'MENU_ITEM', 'nav.admin.vendor-sources', 'Vendor Sources',       NULL, '/admin/vendor-sources', rSysSection, 20, 'HIDDEN', 'DENY', TRUE, TRUE),
            (gen_random_uuid(), 'MENU_ITEM', 'nav.admin.dead-letters',   'Dead Letters',         NULL, '/admin/dead-letters',   rSysSection, 30, 'HIDDEN', 'DENY', TRUE, TRUE);
    END IF;

END $$;

-- ── Add permission rules for all new items (idempotent) ───────────────────────
INSERT INTO app_resource_rule
    (id, app_resource_id, permission_definition_id, visibility_state, execution_state, priority, created_by)
SELECT gen_random_uuid(), ar.id, pd.id, v.vs, v.es, v.pri, 'migration'
FROM (VALUES
    ('nav.admin.system',                       'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('nav.admin.fv.matrix',                    'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
    ('nav.admin.fv.groups',                    'admin:field-visibility',     'VISIBLE', 'ALLOW', 100),
    ('nav.admin.ar.groups',                    'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
    ('nav.admin.ar.matrix',                    'admin:ui-resources',         'VISIBLE', 'ALLOW', 100),
    ('nav.admin.perm.bundles',                 'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
    ('nav.admin.perm.templates',               'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
    ('nav.admin.perm.entity-screens',          'admin:manage-permissions',   'VISIBLE', 'ALLOW', 100),
    ('nav.admin.workflows',                    'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('nav.admin.vendor-sources',               'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100),
    ('nav.admin.dead-letters',                 'admin:manage-authorization', 'VISIBLE', 'ALLOW', 100)
) AS v(rkey, pkey, vs, es, pri)
JOIN app_resource        ar ON ar.resource_key    = v.rkey AND ar.is_current = TRUE AND ar.is_deleted = FALSE
JOIN permission_definition pd ON pd.permission_key = v.pkey
WHERE NOT EXISTS (
    SELECT 1 FROM app_resource_rule
    WHERE app_resource_id        = ar.id
      AND permission_definition_id = pd.id
      AND is_current = TRUE AND is_deleted = FALSE
);
