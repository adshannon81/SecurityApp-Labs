#!/usr/bin/env bash
# Creates extra databases inside the shared Postgres instance.
# This script is executed by the postgres container only on FIRST init
# (i.e. when the data volume is empty / a brand-new deployment).
#
# For an EXISTING cluster (volume already has data) run once manually:
#   docker exec -it securityapp-postgres \
#     psql -U securityapp -c "CREATE DATABASE keycloak_db;"
set -e

psql -v ON_ERROR_STOP=1 \
     --username "$POSTGRES_USER" \
     --dbname   "$POSTGRES_DB" \
     <<-EOSQL
  -- Keycloak persistent store
  SELECT 'CREATE DATABASE keycloak_db'
  WHERE NOT EXISTS (
      SELECT FROM pg_database WHERE datname = 'keycloak_db'
  )\gexec
EOSQL

echo "[postgres-init] Extra databases created."
