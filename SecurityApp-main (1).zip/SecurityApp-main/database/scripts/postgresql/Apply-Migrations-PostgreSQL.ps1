# Apply-Migrations-PostgreSQL.ps1
# ─────────────────────────────────────────────────────────────────────────────
# Creates the securityapp_db database if it doesn't exist, then applies the
# full schema and seed data using the files in database/schema/postgresql/.
#
# Usage:
#   .\database\scripts\postgresql\Apply-Migrations-PostgreSQL.ps1
#   .\database\scripts\postgresql\Apply-Migrations-PostgreSQL.ps1 -DryRun
#
# The user and password are read from .env (POSTGRES_USER, POSTGRES_PASSWORD).

param(
    [switch]$DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ── Locate repo root ──────────────────────────────────────────────────────────
$RepoRoot = Resolve-Path (Join-Path $PSScriptRoot "../../..")

# ── Read credentials from .env ────────────────────────────────────────────────
$EnvFile  = Join-Path $RepoRoot ".env"
$PgUser   = $null
$PgPass   = $null

if (Test-Path $EnvFile) {
    Get-Content $EnvFile | ForEach-Object {
        if ($_ -match '^\s*POSTGRES_USER\s*=\s*"?([^"\r\n]+?)"?\s*$')     { $PgUser = $Matches[1].Trim() }
        if ($_ -match '^\s*POSTGRES_PASSWORD\s*=\s*"?([^"\r\n]+?)"?\s*$') { $PgPass = $Matches[1].Trim() }
    }
}

$PgUser = if ($PgUser) { $PgUser } else { $env:POSTGRES_USER }
$PgPass = if ($PgPass) { $PgPass } else { $env:POSTGRES_PASSWORD }

if (-not $PgUser -or -not $PgPass) {
    Write-Host "✗ POSTGRES_USER or POSTGRES_PASSWORD not found in .env or environment." -ForegroundColor Red
    Write-Host "  Set them in .env (copy .env.example) or as environment variables." -ForegroundColor Yellow
    exit 1
}

# ── Helper: run psql inside the container ────────────────────────────────────
function Invoke-Psql {
    param([string]$Database, [string]$Query, [string]$InputFile)

    $env:PGPASSWORD = $PgPass
    $baseArgs = @("exec", "-e", "PGPASSWORD=$PgPass", "securityapp-postgres",
                  "psql", "-U", $PgUser, "-d", $Database)

    if ($InputFile) {
        $containerPath = "/tmp/$(Split-Path $InputFile -Leaf)"
        docker cp $InputFile "securityapp-postgres:$containerPath" | Out-Null
        # -v ON_ERROR_STOP=1 causes psql to exit with code 3 on the first SQL error,
        # so $LASTEXITCODE is non-zero and the caller can detect failures reliably.
        $result = & docker @baseArgs -v "ON_ERROR_STOP=1" -f $containerPath 2>&1
        docker exec securityapp-postgres rm -f $containerPath | Out-Null
    } else {
        $result = & docker @baseArgs -c $Query 2>&1
    }
    return $result
}

# ── SQL file paths ─────────────────────────────────────────────────────────────
$SchemaFile = Join-Path $RepoRoot "database/schema/postgresql/CreateSchema_PostgreSQL.sql"
$SeedFile   = Join-Path $RepoRoot "database/schema/postgresql/SeedData_PostgreSQL.sql"

foreach ($f in @($SchemaFile, $SeedFile)) {
    if (-not (Test-Path $f)) {
        Write-Host "✗ Required file not found: $f" -ForegroundColor Red
        exit 1
    }
}

if ($DryRun) {
    Write-Host "[DryRun] Would create database 'securityapp_db' on PostgreSQL if missing." -ForegroundColor DarkCyan
    Write-Host "[DryRun] Would apply: $SchemaFile" -ForegroundColor DarkCyan
    Write-Host "[DryRun] Would apply: $SeedFile" -ForegroundColor DarkCyan
    exit 0
}

# ── Step 1: Ensure database exists ────────────────────────────────────────────
# securityapp_db is created automatically by Docker via POSTGRES_DB env var.
# We attempt CREATE DATABASE and ignore the "already exists" error — idempotent.
Write-Host "  Creating database 'securityapp_db' (if not exists)..." -ForegroundColor Gray
Invoke-Psql -Database "postgres" -Query "CREATE DATABASE securityapp_db" | Out-Null

# ── Step 2: Apply schema ───────────────────────────────────────────────────────
Write-Host "  Applying schema (CreateSchema_PostgreSQL.sql)..." -ForegroundColor Gray
$result = Invoke-Psql -Database "securityapp_db" -InputFile $SchemaFile
if ($LASTEXITCODE -ne 0) {
    Write-Host "✗ Schema application failed:" -ForegroundColor Red
    Write-Host ($result -join "`n") -ForegroundColor Red
    exit 1
}

# ── Step 3: Apply seed data ────────────────────────────────────────────────────
Write-Host "  Applying seed data (SeedData_PostgreSQL.sql)..." -ForegroundColor Gray
$result = Invoke-Psql -Database "securityapp_db" -InputFile $SeedFile
if ($LASTEXITCODE -ne 0) {
    Write-Host "✗ Seed data application failed:" -ForegroundColor Red
    Write-Host ($result -join "`n") -ForegroundColor Red
    exit 1
}

Write-Host "✓ PostgreSQL migrations applied successfully." -ForegroundColor Green
