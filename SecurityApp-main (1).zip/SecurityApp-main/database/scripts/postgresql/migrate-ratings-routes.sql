-- ─────────────────────────────────────────────────────────────────────────────
-- Migration: Move ratings-rules and ratings-scales out of admin
-- Routes change from /admin/ratings/rules → /ratings/rules
--                and /admin/ratings/scales → /ratings/scales
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. Update nav MENU_ITEM route paths
UPDATE app_resource
   SET route_path = '/ratings/rules'
 WHERE resource_key = 'nav.ratings.rules';

UPDATE app_resource
   SET route_path = '/ratings/scales'
 WHERE resource_key = 'nav.ratings.scales';

-- 2. Update ROUTE resources: rename keys, update paths, clear admin flag
UPDATE app_resource
   SET resource_key        = 'route./ratings/rules',
       display_name        = 'Rating Rules',
       route_path          = '/ratings/rules',
       is_security_sensitive = FALSE
 WHERE resource_key = 'route./admin/ratings/rules';

UPDATE app_resource
   SET resource_key        = 'route./ratings/scales',
       display_name        = 'Rating Scales',
       route_path          = '/ratings/scales',
       is_security_sensitive = FALSE
 WHERE resource_key = 'route./admin/ratings/scales';

-- 3. Update permission rules referencing the old resource keys
UPDATE app_resource_rule arr
   SET app_resource_id = ar_new.id
  FROM app_resource ar_new
 WHERE ar_new.resource_key = 'route./ratings/rules'
   AND arr.app_resource_id = (
       SELECT id FROM app_resource WHERE resource_key = 'route./ratings/rules'
   );
-- (The UPDATE on app_resource above already renamed the key, so no join
--  on old key is needed — rule rows already point to the correct resource id.)

-- 4. Remove the admin:manage-authorization rules that were on the old admin paths
--    (They are now gone because those resource rows were renamed, and no new
--     admin:manage-authorization rule should apply to business screens.)
DELETE FROM app_resource_rule arr
 USING app_resource ar, permission_definition pd
 WHERE arr.app_resource_id = ar.id
   AND arr.permission_definition_id = pd.id
   AND ar.resource_key IN ('route./ratings/rules', 'route./ratings/scales')
   AND pd.permission_key = 'admin:manage-authorization';

-- 5. Ensure ratings:read rules exist for the new route resources
--    (idempotent — skip if already present)
INSERT INTO app_resource_rule
    (id, app_resource_id, permission_definition_id, visibility_state, execution_state, priority, created_by)
SELECT gen_random_uuid(), ar.id, pd.id, 'VISIBLE', 'ALLOW', 100, 'migration'
  FROM app_resource ar
  JOIN permission_definition pd ON pd.permission_key = 'ratings:read'
 WHERE ar.resource_key IN ('route./ratings/rules', 'route./ratings/scales')
   AND NOT EXISTS (
       SELECT 1 FROM app_resource_rule x
        WHERE x.app_resource_id = ar.id
          AND x.permission_definition_id = pd.id
   );
