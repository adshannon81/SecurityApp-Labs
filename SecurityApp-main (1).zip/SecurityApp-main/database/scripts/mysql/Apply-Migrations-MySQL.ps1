# Apply-Migrations-MySQL.ps1
# ─────────────────────────────────────────────────────────────────────────────
# Creates the securityapp_db database if it doesn't exist, then applies the
# full schema and seed data using the files in database/schema/mysql/.
#
# Usage:
#   .\database\scripts\mysql\Apply-Migrations-MySQL.ps1
#   .\database\scripts\mysql\Apply-Migrations-MySQL.ps1 -DryRun
#
# The root password is read from .env (MYSQL_ROOT_PASSWORD).

param(
    [switch]$DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ── Locate repo root ──────────────────────────────────────────────────────────
$RepoRoot = Resolve-Path (Join-Path $PSScriptRoot "../../..")

# ── Read credentials from .env ────────────────────────────────────────────────
$EnvFile   = Join-Path $RepoRoot ".env"
$RootPass  = $null

if (Test-Path $EnvFile) {
    Get-Content $EnvFile | ForEach-Object {
        if ($_ -match '^\s*MYSQL_ROOT_PASSWORD\s*=\s*"?([^"#\r\n]+)"?') {
            $RootPass = $Matches[1].Trim()
        }
    }
}

$RootPass = if ($RootPass) { $RootPass } else { $env:MYSQL_ROOT_PASSWORD }

if (-not $RootPass) {
    Write-Host "✗ MYSQL_ROOT_PASSWORD not found in .env or environment." -ForegroundColor Red
    Write-Host "  Set it in .env (copy .env.example) or as an environment variable." -ForegroundColor Yellow
    exit 1
}

# ── Helper: run mysql inside the container ────────────────────────────────────
function Invoke-MySQL {
    param([string]$Database, [string]$Query, [string]$InputFile)

    $baseArgs = @("exec", "securityapp-mysql",
                  "mysql", "-uroot", "-p$RootPass", "--batch", "--silent")

    if ($Database) { $baseArgs += $Database }

    if ($InputFile) {
        $containerPath = "/tmp/$(Split-Path $InputFile -Leaf)"
        docker cp $InputFile "securityapp-mysql:$containerPath" | Out-Null
        $result = & docker @baseArgs -e "source $containerPath" 2>&1
        docker exec securityapp-mysql rm -f $containerPath | Out-Null
    } else {
        $result = & docker @baseArgs --execute=$Query 2>&1
    }
    return $result
}

# ── SQL file paths ─────────────────────────────────────────────────────────────
$SchemaFile = Join-Path $RepoRoot "database/schema/mysql/CreateSchema_MySQL.sql"
$SeedFile   = Join-Path $RepoRoot "database/schema/mysql/SeedData_MySQL.sql"

foreach ($f in @($SchemaFile, $SeedFile)) {
    if (-not (Test-Path $f)) {
        Write-Host "✗ Required file not found: $f" -ForegroundColor Red
        exit 1
    }
}

if ($DryRun) {
    Write-Host "[DryRun] Would create database 'securityapp_db' on MySQL if missing." -ForegroundColor DarkCyan
    Write-Host "[DryRun] Would apply: $SchemaFile" -ForegroundColor DarkCyan
    Write-Host "[DryRun] Would apply: $SeedFile" -ForegroundColor DarkCyan
    exit 0
}

# ── Step 1: Create database if it doesn't exist ───────────────────────────────
Write-Host "  Creating database 'securityapp_db' (if not exists)..." -ForegroundColor Gray
$result = Invoke-MySQL -Query "CREATE DATABASE IF NOT EXISTS \`securityapp_db\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
Write-Host "  $($result -join ' ')" -ForegroundColor DarkGray

# ── Step 2: Apply schema ───────────────────────────────────────────────────────
Write-Host "  Applying schema (CreateSchema_MySQL.sql)..." -ForegroundColor Gray
$result = Invoke-MySQL -Database "securityapp_db" -InputFile $SchemaFile
if ($LASTEXITCODE -ne 0) {
    Write-Host "✗ Schema application failed:" -ForegroundColor Red
    Write-Host ($result -join "`n") -ForegroundColor Red
    exit 1
}

# ── Step 3: Apply seed data ────────────────────────────────────────────────────
Write-Host "  Applying seed data (SeedData_MySQL.sql)..." -ForegroundColor Gray
$result = Invoke-MySQL -Database "securityapp_db" -InputFile $SeedFile
if ($LASTEXITCODE -ne 0) {
    Write-Host "✗ Seed data application failed:" -ForegroundColor Red
    Write-Host ($result -join "`n") -ForegroundColor Red
    exit 1
}

Write-Host "✓ MySQL migrations applied successfully." -ForegroundColor Green
