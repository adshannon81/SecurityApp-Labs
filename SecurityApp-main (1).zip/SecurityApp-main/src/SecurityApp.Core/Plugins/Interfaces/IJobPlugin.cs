﻿namespace SecurityApp.Core.Plugins.Interfaces;

public interface IJobPlugin
{
    Type JobType { get; }
    string Name { get; }
    string Group { get; }
    string? DefaultCron { get; }
    string Description { get; }
}
