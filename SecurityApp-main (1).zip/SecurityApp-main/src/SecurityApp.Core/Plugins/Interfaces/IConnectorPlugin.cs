﻿using SecurityApp.Core.Shared.Enums;


namespace SecurityApp.Core.Plugins.Interfaces;

/// <summary>
/// Metadata describing a plugin
/// </summary>
public class PluginMetadata
{
    public string Name { get; set; } = string.Empty;
    public string Version { get; set; } = string.Empty;
    public string Author { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string[] Dependencies { get; set; } = Array.Empty<string>();
    public DataSourceType ConnectorType { get; set; }
}

/// <summary>
/// Interface that all connector plugins must implement
/// </summary>
public interface IConnectorPlugin : IDisposable
{
    PluginMetadata Metadata { get; }
    Task InitializeAsync(IServiceProvider serviceProvider, CancellationToken cancellationToken = default);
    IDataConnector GetConnector();
    bool IsCompatible();
}
