﻿using SecurityApp.Core.Shared.Enums;


namespace SecurityApp.Core.Plugins.Interfaces;

/// <summary>
/// Base interface for all data connectors (Bloomberg, Markit, etc.)
/// </summary>
public interface IDataConnector
{
    DataSourceType SourceType { get; }
    string SourceName { get; }
    Task<bool> IsAvailableAsync(CancellationToken cancellationToken = default);
    Task<HealthStatus> GetHealthStatusAsync(CancellationToken cancellationToken = default);
}

/// <summary>
/// Health status for a data connector
/// </summary>
public class HealthStatus
{
    public bool IsHealthy { get; set; }
    public string Message { get; set; } = string.Empty;
    public DateTime CheckedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Aggregated health + capability info for a single connector, returned by the health API.
/// </summary>
public class ConnectorHealthStatus
{
    public string Name { get; set; } = string.Empty;
    public DataSourceType SourceType { get; set; }
    /// <summary>"Security", "Pricing", or both.</summary>
    public List<string> Capabilities { get; set; } = [];
    public bool IsHealthy { get; set; }
    public string Message { get; set; } = string.Empty;
    public DateTime CheckedAt { get; set; }
}
