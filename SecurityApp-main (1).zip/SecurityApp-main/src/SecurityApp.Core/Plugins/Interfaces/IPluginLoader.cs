﻿using SecurityApp.Core.Shared.Enums;


namespace SecurityApp.Core.Plugins.Interfaces;

/// <summary>
/// Plugin loader for dynamic connector loading
/// </summary>
public interface IPluginLoader
{
    Task LoadPluginsAsync(string pluginDirectory, CancellationToken cancellationToken = default);
    IDataConnector? GetConnector(DataSourceType sourceType);
    IEnumerable<PluginMetadata> GetLoadedPlugins();
    Task ReloadPluginAsync(string pluginName, CancellationToken cancellationToken = default);
    void UnloadPlugin(string pluginName);
}
