namespace SecurityApp.Core.Users;

public interface IUserCacheService
{
    /// <summary>
    /// Upserts the user's sub UUID and display name into the user_cache table.
    /// Called on every authenticated API request via middleware.
    /// Also registers email/preferred_username as additional in-memory lookup keys so that
    /// legacy records whose created_by/last_modified_by stores an email still resolve.
    /// </summary>
    Task UpsertAsync(string sub, string displayName, string? email = null, CancellationToken ct = default);

    /// <summary>
    /// Resolves a stored sub UUID to a display name.
    /// Falls back to rawId if not found (handles legacy email values and unknown UUIDs).
    /// </summary>
    string ResolveDisplayName(string? rawId);
}
