namespace SecurityApp.Core.Users;

public class UserCache
{
    public string Id { get; set; } = string.Empty;       // Keycloak sub UUID
    public string DisplayName { get; set; } = string.Empty;
    public DateTime LastSeen { get; set; }
}
