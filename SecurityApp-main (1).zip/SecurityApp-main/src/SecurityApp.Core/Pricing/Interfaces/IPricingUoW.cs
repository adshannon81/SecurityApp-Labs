﻿using SecurityApp.Core.Pricing.Entities;
using SecurityApp.Core.Shared.Interfaces;


namespace SecurityApp.Core.Pricing.Interfaces;

/// <summary>
/// Narrow unit-of-work interface scoped to the Pricing bounded context.
/// Inject this instead of <see cref="IUnitOfWork"/> in any class that only needs
/// Price / PricingRule / DerivedPrice data.
/// </summary>
public interface IPricingUoW
{
    IRepository<Price> Prices { get; }
    IRepository<PricingRule> PricingRules { get; }
    IRepository<DerivedPrice> DerivedPrices { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    Task BeginTransactionAsync(CancellationToken cancellationToken = default);
    Task CommitTransactionAsync(CancellationToken cancellationToken = default);
    Task RollbackTransactionAsync(CancellationToken cancellationToken = default);
}
