﻿using SecurityApp.Core.Plugins.Interfaces;
using SecurityApp.Core.Pricing.Models;


namespace SecurityApp.Core.Pricing.Interfaces;

/// <summary>
/// Extended data connector that can fetch pricing data for securities.
/// Implement this for each pricing source: AlphaVantage, Bloomberg, Markit, IDC, etc.
/// </summary>
public interface IPricingDataProvider : IDataConnector
{
    /// <summary>Priority order (lower = tried first)</summary>
    int Priority { get; }

    Task<ExternalPriceData?> GetCurrentPriceAsync(
        string symbol,
        CancellationToken cancellationToken = default);

    Task<IEnumerable<ExternalPriceData>> GetHistoricalPricesAsync(
        string symbol,
        DateTime fromDate,
        DateTime toDate,
        CancellationToken cancellationToken = default);
}
