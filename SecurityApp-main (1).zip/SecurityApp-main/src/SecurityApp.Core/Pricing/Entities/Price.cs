﻿using SecurityApp.Core.Shared;
using SecurityApp.Core.Shared.Enums;
using SecurityApp.Core.Securities.Entities;


namespace SecurityApp.Core.Pricing.Entities;

/// <summary>
/// Represents pricing data from external sources
/// Supports bi-temporal tracking for complete price history
/// </summary>
public class Price : TemporalEntity
{
    public Guid SecurityId { get; set; }
    public decimal Value { get; set; }
    public DataSourceType Source { get; set; }
    public DateTime PriceDate { get; set; }
    public string? PriceType { get; set; } // Bid, Ask, Mid, Close, etc.
    public string? Currency { get; set; }

    // ── Golden source (M15) ─────────────────────────────────────────
    public bool IsGolden { get; set; }
    public bool IsStale { get; set; }
    public bool IsOverride { get; set; }
    public string? OverrideReason { get; set; }
    public Guid? VendorSourceId { get; set; }

    // Navigation properties
    public Security Security { get; set; } = null!;
}
