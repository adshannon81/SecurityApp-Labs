﻿using SecurityApp.Core.Shared;
using SecurityApp.Core.Securities.Entities;


namespace SecurityApp.Core.Pricing.Entities;

/// <summary>
/// Represents a calculated derived price based on pricing rules
/// Supports bi-temporal tracking for calculation history
/// </summary>
public class DerivedPrice : TemporalEntity
{
    public Guid SecurityId { get; set; }
    public Guid PricingRuleId { get; set; }
    public decimal CalculatedPrice { get; set; }
    public DateTime CalculatedAt { get; set; } = DateTime.UtcNow;
    public string? CalculationDetails { get; set; } // JSON with calculation breakdown
    
    // Navigation properties
    public Security Security { get; set; } = null!;
    public PricingRule PricingRule { get; set; } = null!;
}
