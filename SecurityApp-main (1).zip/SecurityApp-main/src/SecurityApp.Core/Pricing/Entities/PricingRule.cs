﻿using SecurityApp.Core.Shared;


namespace SecurityApp.Core.Pricing.Entities;

/// <summary>
/// Represents a pricing rule for calculating derived prices
/// Supports bi-temporal tracking for rule version history
/// </summary>
public class PricingRule : TemporalEntity
{
    public string RuleName { get; set; } = string.Empty;
    public string? SecurityType { get; set; }
    public string RuleDefinitionJson { get; set; } = string.Empty;
    public Guid? CreatedByUserId { get; set; }
    public string? Description { get; set; }
    
    // Navigation properties
    public ICollection<DerivedPrice> DerivedPrices { get; set; } = new List<DerivedPrice>();
}
