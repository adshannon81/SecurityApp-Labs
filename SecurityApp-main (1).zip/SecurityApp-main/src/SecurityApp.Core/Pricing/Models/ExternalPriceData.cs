﻿using SecurityApp.Core.Shared.Enums;


namespace SecurityApp.Core.Pricing.Models;

/// <summary>
/// Normalized price data returned by any external pricing provider.
/// </summary>
public class ExternalPriceData
{
    public string Symbol { get; set; } = string.Empty;
    public decimal Price { get; set; }
    public string PriceType { get; set; } = "Close"; // Close, Bid, Ask, Mid, Open

    // Optional price breakdown
    public decimal? BidPrice { get; set; }
    public decimal? AskPrice { get; set; }
    public decimal? OpenPrice { get; set; }
    public decimal? HighPrice { get; set; }
    public decimal? LowPrice { get; set; }
    public long? Volume { get; set; }

    public DateTime PriceDate { get; set; }
    public string? Currency { get; set; }

    // Metadata
    public DataSourceType Source { get; set; }
    public DateTime FetchedAt { get; set; } = DateTime.UtcNow;
}
