﻿namespace SecurityApp.Core.Ratings.Interfaces;

/// <summary>
/// A named NCalc function that can be registered into the evaluator at startup.
///
/// Implementations live in three places, evaluated in this precedence order:
/// <list type="number">
///   <item><b>Plugin functions</b> - loaded from drop-in DLLs at startup; highest precedence,
///         allowing organisations to override any built-in without recompiling the API.</item>
///   <item><b>Hardcoded built-in functions</b> - registered at construction time in
///         <c>BuiltInNCalcFunctions</c>; stable utilities every model relies on.</item>
/// </list>
///
/// DB formula macros are a separate layer - they are string-expanded <em>before</em> the
/// expression reaches an <see cref="INCalcFunction"/>, so a macro body may freely call any
/// registered function by name.
/// </summary>
public interface INCalcFunction
{
    /// <summary>
    /// Case-insensitive function name as it appears in NCalc formulas, e.g. "ScoreBucket".
    /// </summary>
    string Name { get; }

    /// <summary>
    /// Evaluates the function.
    /// </summary>
    /// <param name="args">
    /// Already-evaluated argument values in the order they appear in the formula call.
    /// Each element is a boxed <see cref="double"/>, <see cref="bool"/>, <see cref="string"/>,
    /// or <c>null</c>.
    /// </param>
    /// <returns>The function result (typically a boxed <see cref="double"/> or <see cref="bool"/>).</returns>
    ValueTask<object?> EvaluateAsync(object?[] args);
}
