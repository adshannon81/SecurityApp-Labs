﻿namespace SecurityApp.Core.Ratings.Interfaces;

/// <summary>
/// Generic contract for a single rating sub-model (MICR, VPM, Fundamental, Composite).
/// Implementations live in the Infrastructure layer and are wired by the DI container.
/// </summary>
public interface IRatingCalculator<TInput, TOutput>
{
    /// <summary>Name used in audit logs and config lookups (e.g. "MICR", "VPM").</summary>
    string ModelName { get; }

    Task<TOutput> CalculateAsync(TInput input, CancellationToken cancellationToken = default);
}
