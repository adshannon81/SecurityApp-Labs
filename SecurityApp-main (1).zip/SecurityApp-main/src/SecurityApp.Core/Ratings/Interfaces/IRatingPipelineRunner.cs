﻿using SecurityApp.Core.Ratings.Models;


namespace SecurityApp.Core.Ratings.Interfaces;

/// <summary>
/// Orchestrates the full derived-rating pipeline for a single security:
/// MICR â†’ VPM â†’ Fundamental â†’ Composite.
/// Handles input assembly, hash-based skip logic, audit logging, and persistence.
/// </summary>
public interface IRatingPipelineRunner
{
    /// <summary>
    /// Runs all four sub-models, upserts the <see cref="Entities.DerivedRating"/> row,
    /// and writes a <see cref="Entities.RatingAuditLog"/> entry.
    /// </summary>
    /// <param name="securityId">Target security.</param>
    /// <param name="userId">Identity of the caller (for audit trail).</param>
    /// <param name="evaluationDate">
    /// Optional UTC date used for temporal rule selection (Â«as-ofÂ» back-calculation).
    /// Null = use <see cref="DateTime.UtcNow"/>.
    /// </param>
    /// <param name="cancellationToken">Propagated cancellation token.</param>
    Task<DerivedRatingResult> RunAsync(
        Guid securityId,
        string? userId,
        DateTime? evaluationDate        = null,
        CancellationToken cancellationToken = default);
}
