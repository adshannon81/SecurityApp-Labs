﻿namespace SecurityApp.Core.Ratings.Interfaces;

/// <summary>
/// Registry of all <see cref="INCalcFunction"/> instances available to the NCalc evaluator.
///
/// Resolution order (first match wins, so plugins can override built-ins):
/// <list type="number">
///   <item>Plugin-supplied functions (loaded from DLLs at startup)</item>
///   <item>Hardcoded built-in functions registered at construction time</item>
/// </list>
/// </summary>
public interface INCalcFunctionRegistry
{
    /// <summary>Registers a function. Later registrations with the same name override earlier ones.</summary>
    void Register(INCalcFunction function);

    /// <summary>Returns the function registered under <paramref name="name"/> (case-insensitive),
    /// or <c>null</c> if none exists.</summary>
    INCalcFunction? Resolve(string name);

    /// <summary>All currently registered functions.</summary>
    IReadOnlyCollection<INCalcFunction> All { get; }
}
