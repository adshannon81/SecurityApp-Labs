﻿namespace SecurityApp.Core.Ratings.Interfaces;

/// <summary>
/// Provides named formula macro expansion.
///
/// A <em>formula macro</em> is a named NCalc sub-expression stored in the database.
/// Before any formula string is evaluated by NCalc, the macro service expands all
/// macro references (written as <c>@MacroName</c>) with their stored expression bodies.
/// Expansion is recursive so macros may reference other macros.
///
/// Because macros are stored in the database they can be:
/// <list type="bullet">
///   <item>Created, edited, and deleted through the admin API without deployment.</item>
///   <item>Versioned and audited via the standard bi-temporal mechanism.</item>
///   <item>Referenced by any model formula across MICR, VPM, Fundamental, Composite,
///         and the generic FormulaCalculator.</item>
/// </list>
///
/// Macro bodies may themselves call any registered <see cref="INCalcFunction"/>
/// (hardcoded or plugin-supplied), giving full composability across all three layers.
/// </summary>
public interface IFormulaMacroService
{
    /// <summary>
    /// Expands all <c>@MacroName</c> references in <paramref name="formula"/> with
    /// the corresponding stored expression body.  Recurses until no more references remain
    /// or <paramref name="maxDepth"/> is exceeded (cycle guard).
    /// </summary>
    Task<string> ExpandAsync(string formula, CancellationToken ct = default);

    /// <summary>
    /// Invalidates the in-process cache, forcing the next call to <see cref="ExpandAsync"/>
    /// to reload macro definitions from the database.
    /// </summary>
    Task ReloadAsync(CancellationToken ct = default);
}
