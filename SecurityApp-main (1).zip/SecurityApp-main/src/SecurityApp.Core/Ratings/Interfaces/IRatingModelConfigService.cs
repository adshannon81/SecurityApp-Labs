﻿namespace SecurityApp.Core.Ratings.Interfaces;

/// <summary>
/// Loads and hot-reloads JSON configuration for each rating model
/// (micr.json, vpm.json, fundamental.json, composite.json).
///
/// In the database-backed implementation, JSON files serve only as bootstrap
/// seed data; the database is the authoritative source of truth.
/// Changes are fully audited via <see cref="Entities.AuditLog"/>.
/// </summary>
public interface IRatingModelConfigService
{
    // -- Synchronous (legacy / JSON-fallback) ---------------------------------

    /// <summary>Returns the strongly-typed config for <paramref name="modelName"/> (sync, JSON-based fallback).</summary>
    T Load<T>(string modelName) where T : class, new();

    /// <summary>Returns the currently-active rule for <paramref name="modelName"/> matching the given date and security type (sync).</summary>
    T LoadActive<T>(string modelName,
        DateTime? evaluationDate = null,
        string?   securityType   = null) where T : class, new();

    /// <summary>Returns the raw JSON string for <paramref name="modelName"/>.</summary>
    string GetJson(string modelName);

    // -- Async (preferred - reads from database) ------------------------------

    /// <summary>
    /// Async load of the most-recent generic (no security-type scope) rule for
    /// <paramref name="modelName"/>. Preferred over <see cref="Load{T}"/> in production code.
    /// </summary>
    Task<T> LoadAsync<T>(string modelName,
        CancellationToken cancellationToken = default) where T : class, new();

    /// <summary>
    /// Async active-rule selection from the database.
    /// Evaluates the valid-time window and security-type priority.
    /// </summary>
    Task<T> LoadActiveAsync<T>(string modelName,
        DateTime? evaluationDate        = null,
        string?   securityType          = null,
        CancellationToken cancellationToken = default) where T : class, new();

    /// <summary>Returns the raw JSON for <paramref name="modelName"/> asynchronously.</summary>
    Task<string> GetJsonAsync(string modelName,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Persists the new config to the database, expires the previous version,
    /// and writes a <see cref="Entities.AuditLog"/> record.
    /// Hot-reload - no application restart required.
    /// </summary>
    Task ReloadAsync(string modelName, string json,
        string?   userId                = null,
        CancellationToken cancellationToken = default);

    /// <summary>
    /// Selects the rule version active at <paramref name="evaluationDate"/> (UTC).
    /// Falls back to <see cref="LoadAsync{T}"/> when no versioned config is found.
    /// </summary>
    [Obsolete("Use LoadActiveAsync instead.")]
    void Reload(string modelName, string json);
}
