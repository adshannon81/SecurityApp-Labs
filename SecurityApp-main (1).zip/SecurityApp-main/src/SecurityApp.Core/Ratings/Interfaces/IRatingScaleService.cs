﻿namespace SecurityApp.Core.Ratings.Interfaces;

/// <summary>
/// Maps agency-agnostic numeric scores (1â€“21) to and from label strings
/// for every supported rating agency (S&amp;P, Moody's, Fitch, DBRS, â€¦).
///
/// Score convention: 1 = best (AAA / Aaa), 21 = worst (D).
/// Investment-grade boundary: scores 1â€“10 (BBB- / Baa3 / BBB-).
///
/// In the database-backed implementation the scale data lives in
/// <see cref="Entities.RatingScaleEntry"/> rows; <c>rating-scales.json</c> is seed-only.
/// Changes are audited via <see cref="Entities.AuditLog"/>.
/// </summary>
public interface IRatingScaleService
{
    /// <summary>All agencies available in the loaded rating-scales config.</summary>
    IReadOnlyList<string> SupportedAgencies { get; }

    /// <summary>Returns the label for <paramref name="score"/> in <paramref name="agency"/> notation.</summary>
    string GetLabel(string agency, int score);

    /// <summary>Returns the numeric score for a label in a given agency's notation.</summary>
    int GetScore(string agency, string label);

    /// <summary>Cross-converts a label from one agency's notation to another's.</summary>
    string Convert(string fromAgency, string label, string toAgency);

    /// <summary>Returns true when <paramref name="score"/> is investment-grade (â‰¤ 10).</summary>
    bool IsInvestmentGrade(int score);

    /// <summary>
    /// Replaces all current scale entries with the data in <paramref name="json"/>,
    /// persists to the database, and writes an audit record. Hot-reload - no restart needed.
    /// </summary>
    Task ReloadAsync(string json,
        string?   userId                = null,
        CancellationToken cancellationToken = default);

    /// <summary>Synchronous hot-reload (kept for backward compatibility; prefer <see cref="ReloadAsync"/>).</summary>
    void Reload(string json);
}
