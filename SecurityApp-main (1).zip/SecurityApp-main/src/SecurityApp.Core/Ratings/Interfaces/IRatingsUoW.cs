﻿using SecurityApp.Core.Ratings.Entities;
using SecurityApp.Core.Audit.Entities;
using SecurityApp.Core.Shared.Interfaces;


namespace SecurityApp.Core.Ratings.Interfaces;

/// <summary>
/// Narrow unit-of-work interface scoped to the Ratings bounded context.
/// Inject this instead of <see cref="IUnitOfWork"/> in any class that only needs
/// ratings-related data (CreditRating, DerivedRating, rules, scales, macros).
/// </summary>
public interface IRatingsUoW
{
    IRepository<CreditRating> CreditRatings { get; }
    IRepository<DerivedRating> DerivedRatings { get; }
    IRepository<RatingDerivationRule> RatingDerivationRules { get; }
    IRepository<RatingScaleEntry> RatingScaleEntries { get; }
    IRepository<VendorRatingMetadata> VendorRatingMetadata { get; }
    IRepository<FormulaMacro> FormulaMacros { get; }
    IRepository<AuditLog> AuditLogs { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    Task BeginTransactionAsync(CancellationToken cancellationToken = default);
    Task CommitTransactionAsync(CancellationToken cancellationToken = default);
    Task RollbackTransactionAsync(CancellationToken cancellationToken = default);
}
