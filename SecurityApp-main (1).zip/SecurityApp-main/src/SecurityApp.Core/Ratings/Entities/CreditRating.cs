﻿using SecurityApp.Core.Shared;
using SecurityApp.Core.Ratings.Enums;
using SecurityApp.Core.Securities.Entities;


namespace SecurityApp.Core.Ratings.Entities;

/// <summary>
/// A credit rating issued by a specific agency for a security.
/// A security can have multiple concurrent ratings (e.g., one from S&P, one from Moody's, one from Fitch).
/// Supports bi-temporal tracking so rating history is preserved when an agency changes its opinion.
/// </summary>
public class CreditRating : TemporalEntity
{
    public Guid SecurityId { get; set; }

    /// <summary>The agency that issued this rating (S&P, Moody's, Fitch, etc.)</summary>
    public RatingAgency Agency { get; set; }

    /// <summary>
    /// The rating value in the agency's own notation.
    /// S&P/Fitch: AAA, AA+, AA, AA-, A+, A, A-, BBB+, BBB, BBB-, BB+, ..., D
    /// Moody's:   Aaa, Aa1, Aa2, Aa3, A1, A2, A3, Baa1, Baa2, Baa3, Ba1, ..., C
    /// </summary>
    public string Rating { get; set; } = string.Empty;

    /// <summary>Long-term, short-term, outlook, watch, or recovery rating</summary>
    public RatingType RatingType { get; set; } = RatingType.LongTerm;

    /// <summary>Date the agency published this rating action (null if unknown)</summary>
    public DateTime? RatingDate { get; set; }

    /// <summary>SHA-256 hash of the rating data used for import deduplication.</summary>
    public string? ContentHash { get; set; }

    // Navigation
    public Security Security { get; set; } = null!;
}
