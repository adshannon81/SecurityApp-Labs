﻿using SecurityApp.Core.Shared;


namespace SecurityApp.Core.Ratings.Entities;

/// <summary>
/// One notch in a rating agency's scale, stored in the database so that
/// scales can be managed, versioned, and audited through the standard admin API.
///
/// Replaces the flat <c>rating-scales.json</c> file as the authoritative source.
///
/// Bi-temporal contract:
/// <list type="bullet">
///   <item><b>ValidFrom / ValidTo</b> - when this label/score mapping is considered
///         effective in the real world (e.g. S&amp;P added CC in 2011).</item>
///   <item><b>SystemFrom / SystemTo</b> - when this knowledge was recorded /
///         superseded in the database (transaction time).</item>
///   <item><b>IsCurrent = true</b> - the row currently reflects our best knowledge.</item>
/// </list>
/// </summary>
public class RatingScaleEntry : TemporalEntity
{
    /// <summary>Agency code, e.g. "SP", "Moodys", "Fitch", "DBRS", "Kroll".</summary>
    public string Agency { get; set; } = string.Empty;

    /// <summary>Agency-agnostic ordinal score (1 = best / AAA, 21 = worst / D).</summary>
    public int Score { get; set; }

    /// <summary>Agency-specific label, e.g. "AAA", "Aaa", "BB+".</summary>
    public string Label { get; set; } = string.Empty;

    /// <summary>True when this score maps to investment-grade (â‰¤ 10 on the 1â€“21 scale).</summary>
    public bool IsInvestmentGrade { get; set; }
}
