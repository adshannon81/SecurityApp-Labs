﻿using SecurityApp.Core.Shared;


namespace SecurityApp.Core.Ratings.Entities;

/// <summary>
/// A named NCalc sub-expression stored in the database, usable by any rating model formula.
///
/// Macros are referenced in formula strings using the <c>@MacroName</c> syntax.
/// Before an expression is evaluated, the <c>IFormulaMacroService</c> performs a
/// text-substitution pass that replaces every <c>@MacroName</c> occurrence with the
/// macro's <see cref="Expression"/> body.  Expansion is recursive (macros may reference
/// other macros) up to a configurable depth limit (default 10).
///
/// <b>Composability with other layers:</b>
/// A macro body is itself a valid NCalc expression and may therefore call any function
/// registered in the <c>INCalcFunctionRegistry</c> - including hardcoded built-ins
/// (<c>ScoreBucket</c>, <c>Clamp</c>, etc.) and functions supplied by DLL plugins.
///
/// Bi-temporal contract (inherited from <see cref="TemporalEntity"/>):
/// <list type="bullet">
///   <item><b>ValidFrom / ValidTo</b> - when this macro definition is effective.</item>
///   <item><b>SystemFrom / SystemTo</b> - transaction time (when knowledge was recorded).</item>
///   <item><b>IsCurrent = true</b> - the row is the latest known definition for this name.</item>
/// </list>
/// </summary>
public class FormulaMacro : TemporalEntity
{
    /// <summary>
    /// Unique case-insensitive name used in formula references (<c>@MacroName</c>).
    /// Must be a valid identifier: letters, digits, underscores, no spaces.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// The NCalc expression this macro expands to.
    /// May reference formula variables (<c>[varName]</c>), other macros (<c>@OtherMacro</c>),
    /// and any registered function (<c>ScoreBucket(...)</c>, <c>Clamp(...)</c>, etc.).
    /// </summary>
    public string Expression { get; set; } = string.Empty;

    /// <summary>Optional human-readable description explaining the macro's purpose.</summary>
    public string? Description { get; set; }

    /// <summary>
    /// Optional scope tag (e.g. "MICR", "VPM", "Composite", or null for global).
    /// Purely informational - macros are always globally available regardless of scope.
    /// </summary>
    public string? Scope { get; set; }
}
