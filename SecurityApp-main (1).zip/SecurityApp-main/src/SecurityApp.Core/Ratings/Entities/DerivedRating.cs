﻿using SecurityApp.Core.Shared;


namespace SecurityApp.Core.Ratings.Entities;

/// <summary>
/// Stores the results of the derived rating pipeline for a security.
/// One row per security (upserted on each calculation run).
/// All numeric scores use an agency-agnostic ordinal scale (1 = best/AAA, 21 = worst/D).
/// String labels are pre-rendered for the configured OutputAgency and stored for fast reads.
/// </summary>
public class DerivedRating : TemporalEntity
{
    public Guid SecurityId { get; set; }

    // -- Agency-agnostic ordinal scores (1â€“21, lower = better) ------------------
    public int? ImpliedRatingScore { get; set; }
    public int? VpmRatingScore { get; set; }
    public int? FundamentalRatingScore { get; set; }
    public int? CompositeRatingScore { get; set; }

    // -- Pre-rendered labels for the target output agency -----------------------
    // e.g. "SP" â†’ "AA-", "Moodys" â†’ "Aa3", etc.
    public string OutputAgency { get; set; } = "SP";
    public string? ImpliedRating { get; set; }
    public string? VpmRating { get; set; }
    public string? FundamentalRating { get; set; }
    public string? CompositeRating { get; set; }

    // -- Key model outputs -------------------------------------------------------
    public decimal? ImpliedPd { get; set; }
    public decimal? ModelPd { get; set; }
    public decimal? FairPrice { get; set; }

    // -- Calculation metadata ----------------------------------------------------
    /// <summary>MD5 hash of the inputs used - allows skipping recalculation when inputs haven't changed.</summary>
    public string SourceHash { get; set; } = string.Empty;
    public DateTime LastCalculatedUtc { get; set; } = DateTime.UtcNow;
}
