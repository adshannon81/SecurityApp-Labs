﻿using SecurityApp.Core.Shared;


namespace SecurityApp.Core.Ratings.Entities;

/// <summary>
/// One version of a rating model's configuration, stored in the database so that
/// derivation rules can be created, versioned, and audited through the admin API.
///
/// Replaces per-model JSON files (<c>micr.json</c>, <c>vpm.json</c>, etc.) as the
/// authoritative source of truth. JSON files remain as bootstrap seed data only.
///
/// Bi-temporal contract:
/// <list type="bullet">
///   <item><b>ValidFrom / ValidTo</b> (business / valid time) - the date window during
///         which this rule set is effective. Set by the admin when configuring the rule.
///         Maps to <c>effectiveFrom</c> / <c>effectiveTo</c> in the versioned JSON schema.</item>
///   <item><b>SystemFrom / SystemTo</b> (transaction time) - when this version was
///         written to / superseded in the database.</item>
///   <item><b>IsCurrent = true</b> - the latest known version for this
///         (<see cref="ModelName"/>, <see cref="SecurityType"/>) pair.</item>
/// </list>
///
/// Selection priority (from <see cref="Interfaces.IRatingModelConfigService.LoadActiveAsync{T}"/>):
/// <list type="number">
///   <item>Type-specific version (<see cref="SecurityType"/> matches the security's type).</item>
///   <item>Generic version (<see cref="SecurityType"/> is null/empty - applies to all types).</item>
/// </list>
/// </summary>
public class RatingDerivationRule : TemporalEntity
{
    /// <summary>
    /// Model this rule belongs to: "composite", "micr", "vpm", or "fundamental".
    /// </summary>
    public string ModelName { get; set; } = string.Empty;

    /// <summary>
    /// Security type scope, e.g. "Bond", "Loan", "ABS".
    /// Null / empty means the rule applies to <em>all</em> security types (generic default).
    /// A type-specific rule takes precedence over a generic one when both are active.
    /// </summary>
    public string? SecurityType { get; set; }

    /// <summary>
    /// JSON blob of the model's configuration class
    /// (e.g. <see cref="Configuration.Rating.MicrConfig"/>, <see cref="Configuration.Rating.CompositeRatingConfig"/>).
    /// Must be a valid flat config JSON - not the outer versioned wrapper.
    /// </summary>
    public string ConfigJson { get; set; } = "{}";

    /// <summary>Optional human-readable description of what changed in this version.</summary>
    public string? Description { get; set; }
}
