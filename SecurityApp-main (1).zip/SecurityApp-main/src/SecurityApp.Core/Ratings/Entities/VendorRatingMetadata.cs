﻿using SecurityApp.Core.Shared;


namespace SecurityApp.Core.Ratings.Entities;

/// <summary>
/// Stores quality metadata about individual pricing/rating data vendors
/// (Bloomberg, Markit, ICE, etc.).  Used by the VPM calculator to weight
/// vendor prices according to their historical reliability.
/// </summary>
public class VendorRatingMetadata : BaseEntity
{
    /// <summary>Vendor identifier, e.g. "Bloomberg", "Markit".</summary>
    public string VendorName { get; set; } = string.Empty;

    /// <summary>
    /// How accurate the vendor's prices are historically (0â€“1).
    /// Typically derived from back-testing realised vs. quoted spreads.
    /// </summary>
    public decimal AccuracyScore { get; set; }

    /// <summary>
    /// How stable (low-variance) the vendor's prices are over a rolling window (0â€“1).
    /// </summary>
    public decimal StabilityScore { get; set; }

    /// <summary>
    /// How timely the vendor's data is - intra-day freshness (0â€“1).
    /// </summary>
    public decimal TimelinessScore { get; set; }

    /// <summary>
    /// Fraction of the universe this vendor covers (0â€“1).
    /// Vendors with low coverage are down-weighted automatically.
    /// </summary>
    public decimal CoverageScore { get; set; }

    public DateTime LastUpdatedUtc { get; set; } = DateTime.UtcNow;
}
