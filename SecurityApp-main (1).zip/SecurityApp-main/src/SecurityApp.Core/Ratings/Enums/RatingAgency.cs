﻿namespace SecurityApp.Core.Ratings.Enums;

/// <summary>
/// Credit rating agency that issued the rating
/// </summary>
public enum RatingAgency
{
    SP,           // Standard & Poor's
    Moodys,       // Moody's Investors Service
    Fitch,        // Fitch Ratings
    DBRS,         // DBRS Morningstar
    Kroll,        // Kroll Bond Rating Agency
    Morningstar,  // Morningstar Credit Ratings
    AM_Best,      // AM Best (insurance focus)
    Other
}
