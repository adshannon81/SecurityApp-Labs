﻿namespace SecurityApp.Core.Ratings.Enums;

/// <summary>
/// Type of credit rating opinion
/// </summary>
public enum RatingType
{
    LongTerm,   // Senior unsecured long-term debt (most common)
    ShortTerm,  // Commercial paper / short-term obligations
    Outlook,    // Positive, Stable, Negative, Developing
    Watch,      // CreditWatch / Review for upgrade or downgrade
    Recovery    // Post-default recovery rating
}
