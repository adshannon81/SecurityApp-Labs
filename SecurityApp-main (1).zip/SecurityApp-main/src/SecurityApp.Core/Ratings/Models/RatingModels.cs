﻿namespace SecurityApp.Core.Ratings.Models;

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// MICR (Market-Implied Credit Rating) Models
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

/// <summary>Inputs required by the MICR sub-model.</summary>
public record MicrInput(
    Guid SecurityId,
    decimal BidPrice,
    decimal AskPrice,
    decimal MidPrice,
    /// <summary>Z-spread in basis points (market-implied credit spread over the benchmark curve).</summary>
    double ZSpreadBps,
    double RiskFreeRatePct,
    double RecoveryRatePct,
    double MaturityYears,
    /// <summary>Optional: override annual coupon rate; null = infer from price.</summary>
    double? AnnualCouponPct
);

/// <summary>Outputs produced by the MICR sub-model.</summary>
public record MicrOutput(
    int Score,
    string ModelName,
    double ImpliedPd,
    double FairYield,
    decimal FairPrice,
    double ConfidenceScore,
    string Notes,
    /// <summary>Non-null when the PD formula threw; fallback PD of 0.05 was used.</summary>
    string? PdFormulaError = null,
    /// <summary>Non-null when the yield formula threw; fallback riskFree + spread/10000 was used.</summary>
    string? YieldFormulaError = null,
    /// <summary>Non-null when the confidence formula threw; fallback confidence of 0.5 was used.</summary>
    string? ConfidenceFormulaError = null
);

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// VPM (Vendor Price Matrix) Models
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

/// <summary>A single vendor's price contribution.</summary>
public record VendorPricePoint(
    string VendorName,
    decimal Price,
    double Weight,
    DateTime ObservedAt
);

/// <summary>Inputs required by the VPM sub-model.</summary>
public record VpmInput(
    Guid SecurityId,
    IReadOnlyList<VendorPricePoint> VendorPrices,
    /// <summary>Consensus / reference price (e.g. mid of bid/ask) for deviation scoring.</summary>
    decimal ReferencePrice
);

/// <summary>Outputs produced by the VPM sub-model.</summary>
public record VpmOutput(
    int Score,
    string ModelName,
    decimal WeightedConsensusPrice,
    double PriceDispersionPct,
    int ActiveVendorCount,
    string Notes,
    /// <summary>
    /// Non-null when the effective-weight formula threw for one or more vendors;
    /// the quality weight was used as fallback for those vendors.
    /// </summary>
    string? EffectiveWeightFormulaError = null
);

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// Fundamental Rating Models
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

/// <summary>Single PD driver (a named variable fed to the PD formula).</summary>
public record PdDriver(string Name, double Value);

/// <summary>Inputs required by the Fundamental sub-model.</summary>
public record FundamentalInput(
    Guid SecurityId,
    IReadOnlyList<PdDriver> PdDrivers,
    /// <summary>Existing agency rating label (e.g. "BBB-") if available; null if unrated.</summary>
    string? AgencyRatingLabel,
    string? AgencyName
);

/// <summary>Outputs produced by the Fundamental sub-model.</summary>
public record FundamentalOutput(
    int Score,
    string ModelName,
    double EstimatedPd,
    bool IsAgencyOverrideApplied,
    string Notes,
    /// <summary>
    /// Non-null when the PD formula evaluation threw an exception and the
    /// fallback PD of 0.05 was used instead.  Surfaced in API responses so
    /// consumers can detect silent formula failures.
    /// </summary>
    string? FormulaError = null
);

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// Composite Rating Models
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

/// <summary>Inputs required by the Composite aggregator.</summary>
public record CompositeInput(
    Guid SecurityId,
    MicrOutput? Micr,
    VpmOutput? Vpm,
    FundamentalOutput? Fundamental,
    /// <summary>
    /// UTC date used for temporal rule selection (e.g. "as-of" back-calculation).
    /// Null = use the current UTC time.
    /// </summary>
    DateTime? EvaluationDate = null,
    /// <summary>
    /// Security type string (e.g. "Bond", "Loan") used to pick type-specific rule
    /// versions from the composite config. Null = generic fallback.
    /// </summary>
    string? SecurityType = null
);

/// <summary>Outputs produced by the Composite aggregator.</summary>
public record CompositeOutput(
    int Score,
    string ModelName,
    double MicrWeight,
    double VpmWeight,
    double FundamentalWeight,
    string Notes,
    /// <summary>
    /// Non-null when the composite formula evaluation threw an exception and the
    /// arithmetic weighted average fallback was used instead.  Surfaced in API
    /// responses so consumers can detect silent formula failures.
    /// </summary>
    string? FormulaError = null
);

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// Pipeline Result
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

/// <summary>
/// Aggregated output from a full pipeline run.
/// Label properties are populated by <see cref="Interfaces.IRatingScaleService"/>
/// using the configured output agency.
/// </summary>
public record DerivedRatingResult(
    Guid SecurityId,
    MicrOutput? Micr,
    VpmOutput? Vpm,
    FundamentalOutput? Fundamental,
    CompositeOutput? Composite,
    string OutputAgency,
    string? ImpliedRatingLabel,
    string? VpmRatingLabel,
    string? FundamentalRatingLabel,
    string? CompositeRatingLabel,
    bool WasSkipped,
    string SourceHash,
    DateTime CalculatedAt
);
