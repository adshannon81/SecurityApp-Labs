﻿namespace SecurityApp.Core.Ratings.Configuration;

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// Rating Scale Configuration
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

/// <summary>One entry in a rating scale (one row in the 1-21 table for an agency).</summary>
public class RatingScaleConfigEntry
{
    /// <summary>Agency-agnostic ordinal score (1 = best, 21 = worst).</summary>
    public int Score { get; set; }

    /// <summary>Agency-specific label, e.g. "AAA", "Aaa", "BB+".</summary>
    public string Label { get; set; } = string.Empty;

    /// <summary>True when the score maps to an investment-grade rating (â‰¤ 10).</summary>
    public bool IsInvestmentGrade { get; set; }
}

/// <summary>Full rating scale definition for one agency.</summary>
public class RatingScale
{
    public string Agency { get; set; } = string.Empty;
    public List<RatingScaleConfigEntry> Entries { get; set; } = [];
}

/// <summary>Root config object loaded from rating-scales.json.</summary>
public class RatingScalesConfig
{
    public List<RatingScale> Scales { get; set; } = [];
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// MICR Configuration
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

/// <summary>Z-spread â†’ score bucket: if zSpread â‰¤ MaxBps, assign this score.</summary>
public class SpreadBucket
{
    public double MaxBps { get; set; }
    public int Score { get; set; }
}

/// <summary>Configuration for the Market-Implied Credit Rating model.</summary>
public class MicrConfig
{
    /// <summary>NCalc expression for computing implied PD from spread, recovery rate, and maturity.</summary>
    public string PdFormula { get; set; } = "1 - Exp(-[spread] / (1 - [recovery]) / 10000 * [maturity])";

    /// <summary>NCalc expression for converting PD to a fair yield.</summary>
    public string YieldFormula { get; set; } = "[riskFree] + [spread] / 100";

    /// <summary>
    /// NCalc expression for confidence score (0â€“1) based on bid-ask spread.
    /// Maps the bid-ask spread as a fraction of mid price [0 %, 10 %] linearly
    /// to a confidence score [1.0, 0.0] using <c>Normalize</c> (inverted output
    /// range: a tighter spread yields higher confidence).  Values outside
    /// [0 %, 10 %] are clamped automatically.
    /// </summary>
    public string ConfidenceFormula { get; set; } = "Normalize(([ask] - [bid]) / [mid], 0.0, 0.10, 1.0, 0.0)";

    /// <summary>Ordered list of spread buckets (evaluated in order, first match wins).</summary>
    public List<SpreadBucket> SpreadBuckets { get; set; } = [];

    /// <summary>Default recovery rate used when not supplied by the caller.</summary>
    public double DefaultRecoveryRate { get; set; } = 0.40;

    /// <summary>Risk-free rate (%) used when no market rate is supplied - update as rates change.</summary>
    public double DefaultRiskFreeRatePct { get; set; } = 4.5;

    /// <summary>Minimum confidence score to use the MICR result in the composite (else it is excluded).</summary>
    public double MinConfidenceThreshold { get; set; } = 0.30;
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// VPM Configuration
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

/// <summary>Price dispersion â†’ score bucket.</summary>
public class DeviationBucket
{
    public double MaxDeviationPct { get; set; }
    public int Score { get; set; }
}

/// <summary>Configuration for the Vendor Price Matrix model.</summary>
public class VpmConfig
{
    /// <summary>Per-vendor quality weights (vendor name â†’ weight 0â€“1).  Missing vendors default to 0.5.</summary>
    public Dictionary<string, double> VendorWeights { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>
    /// NCalc expression for a vendor's effective weight.
    /// Variables: [quality] (vendor weight from VendorWeights), [priceDeviation] (% deviation from reference).
    /// Uses <c>Normalize</c> to map price deviation [0 %, 10 %] â†’ weight factor [1.0, 0.1],
    /// then scales by the vendor's quality rating.  Vendors with wider deviations receive
    /// less weight; the 0.1 floor prevents any vendor from being zeroed out entirely.
    /// </summary>
    public string EffectiveWeightFormula { get; set; } = "[quality] * Normalize([priceDeviation], 0.0, 0.1, 1.0, 0.1)";

    /// <summary>Ordered deviationâ†’score buckets (first match wins).</summary>
    public List<DeviationBucket> DeviationBuckets { get; set; } = [];

    /// <summary>Fraction above which a vendor price is considered an outlier and excluded.</summary>
    public double OutlierThresholdPct { get; set; } = 0.05;

    /// <summary>Minimum number of active vendors required to produce a VPM score.</summary>
    public int MinVendorCount { get; set; } = 2;
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// Fundamental Rating Configuration
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

/// <summary>PD range â†’ score bucket used by the fundamental model.</summary>
public class PdRatingBucket
{
    public double MaxPd { get; set; }
    public int Score { get; set; }
}

/// <summary>Override rule: when an agency label is present, floor or cap the computed score.</summary>
public class AgencyOverrideRule
{
    public string AgencyName { get; set; } = string.Empty;
    /// <summary>If the agency label maps to a score better than [BetterScoreThreshold], cap the model score there.</summary>
    public int? BetterScoreThreshold { get; set; }
    /// <summary>If the agency label maps to a score worse than [WorseScoreThreshold], floor the model score there.</summary>
    public int? WorseScoreThreshold { get; set; }
}

/// <summary>Configuration for the Fundamental Rating model.</summary>
public class FundamentalRatingConfig
{
    /// <summary>
    /// NCalc formula that computes a probability of default (PD) from named driver variables
    /// supplied by the caller (e.g. <c>[leverageRatio]</c>, <c>[interestCoverageRatio]</c>).
    /// The default expression uses <c>Normalize</c> twice:
    /// <list type="bullet">
    ///   <item>Leverage contribution - higher leverage [0,10] maps to higher PD [0.001, 0.20].</item>
    ///   <item>Coverage contribution - higher coverage [0.5,15] maps to <em>lower</em> PD
    ///         [0.15, 0.0]; the output range is inverted so good coverage reduces PD.</item>
    /// </list>
    /// Both contributions are summed and clamped to [0, 1].
    /// Custom PD formulas loaded from the database or a JSON config file always take
    /// precedence over this hard-coded default.
    /// </summary>
    public string PdFormula { get; set; } =
        "Clamp(Normalize([leverageRatio], 0.0, 10.0, 0.001, 0.20) + Normalize([interestCoverageRatio], 15.0, 0.5, 0.0, 0.15), 0.0, 1.0)";

    /// <summary>Mapping from PD ranges to scores (sorted ascending by MaxPd).</summary>
    public List<PdRatingBucket> PdRatingBuckets { get; set; } = [];

    /// <summary>Optional agency override rules applied after the PD-based score is computed.</summary>
    public List<AgencyOverrideRule> OverrideRules { get; set; } = [];
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// Composite Rating Configuration
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

/// <summary>Configuration for the Composite aggregator model.</summary>
public class CompositeRatingConfig
{
    /// <summary>
    /// NCalc expression for the composite score.
    /// Available variables: [micrScore], [vpmScore], [fundamentalScore],
    ///                       [micrWeight], [vpmWeight], [fundamentalWeight].
    /// </summary>
    public string Formula { get; set; } =
        "Round([micrScore] * [micrWeight] + [vpmScore] * [vpmWeight] + [fundamentalScore] * [fundamentalWeight])";

    /// <summary>Weight applied to the MICR sub-score (0â€“1).</summary>
    public double MicrWeight { get; set; } = 0.40;

    /// <summary>Weight applied to the VPM sub-score (0â€“1).</summary>
    public double VpmWeight { get; set; } = 0.30;

    /// <summary>Weight applied to the Fundamental sub-score (0â€“1).</summary>
    public double FundamentalWeight { get; set; } = 0.30;

    /// <summary>
    /// When a sub-model is unavailable, redistribute its weight equally among the available ones.
    /// </summary>
    public bool RedistributeWeightsWhenModelMissing { get; set; } = true;

    /// <summary>Which agency's labels to store in DerivedRating (default "SP").</summary>
    public string DefaultOutputAgency { get; set; } = "SP";
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// Temporal / Versioned Config Support
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

/// <summary>
/// Wraps any rating model config with valid-time temporal metadata so that
/// different rule sets can apply in different date ranges and/or for specific
/// security types.
/// <para>
/// Two time dimensions are supported:
/// <list type="bullet">
///   <item><b>Valid time</b> - the period during which this rule set reflects reality
///         (<see cref="EffectiveFrom"/> / <see cref="EffectiveTo"/>).</item>
///   <item><b>Security-type scope</b> - apply only to the listed types, or to all when
///         <see cref="SecurityTypes"/> is empty (generic fallback).</item>
/// </list>
/// </para>
/// <para>
/// For full bi-temporal audit (also tracking <em>when a rule was committed</em>),
/// persist rule versions to the database via the admin API - JSON files alone
/// provide only the valid-time dimension.
/// </para>
/// </summary>
/// <typeparam name="TConfig">The rating model config type (e.g. <see cref="CompositeRatingConfig"/>).</typeparam>
public class RatingRuleVersion<TConfig>
{
    /// <summary>UTC date from which this rule set is active (inclusive). Defaults to the beginning of time.</summary>
    public DateTime EffectiveFrom { get; set; } = DateTime.MinValue;

    /// <summary>
    /// UTC date through which this rule set is active (inclusive).
    /// Use <c>9999-12-31</c> for open-ended / current rules.
    /// </summary>
    public DateTime EffectiveTo { get; set; } = DateTime.MaxValue;

    /// <summary>
    /// Security types this version applies to (e.g. "Bond", "Loan").
    /// An empty list means the version applies to <em>all</em> security types and
    /// acts as a generic default. A type-specific entry always takes precedence
    /// over a generic one when both are active on the same date.
    /// </summary>
    public List<string> SecurityTypes { get; set; } = [];

    /// <summary>The concrete config for this version.</summary>
    public TConfig? Config { get; set; }
}

/// <summary>
/// Root container for a versioned config file.
/// When the JSON root contains a <c>"versions"</c> array,
/// <see cref="Interfaces.IRatingModelConfigService.LoadActive{T}"/> performs
/// temporal and security-type selection.
/// Files without a <c>"versions"</c> key are treated as flat (non-temporal)
/// configs - fully backward-compatible.
/// </summary>
/// <typeparam name="TConfig">The rating model config type.</typeparam>
public class VersionedConfigRoot<TConfig>
{
    public List<RatingRuleVersion<TConfig>> Versions { get; set; } = [];
}
