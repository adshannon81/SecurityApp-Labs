namespace SecurityApp.Core.Dashboard;

public record DashboardCounts(
    int TotalSecurities,
    int ActiveSecurities,
    int FailedImports,
    int RunningJobs);

public interface IDashboardRepository
{
    Task<DashboardCounts> GetCountsAsync(CancellationToken ct = default);
}

/// <summary>
/// Implement this interface to expose a new dashboard widget data source.
/// Register your implementation in DI as <see cref="IDashboardWidgetProvider"/>.
/// The <see cref="WidgetId"/> must match the <c>id</c> registered in the Angular
/// widget registry, and becomes the route segment for <c>GET /api/widgets/{id}</c>.
///
/// Adding a widget requires only:
///   1. A C# class implementing this interface (backend data).
///   2. A standalone Angular component + optional service (frontend UI).
///   3. One line added to <c>ALL_WIDGETS</c> in <c>widget-registry.service.ts</c>.
/// </summary>
public interface IDashboardWidgetProvider
{
    /// <summary>Unique widget id — must match the Angular widget registry id.</summary>
    string WidgetId { get; }

    /// <summary>Returns the widget's JSON-serialisable data payload.</summary>
    Task<object> GetDataAsync(CancellationToken ct = default);
}
