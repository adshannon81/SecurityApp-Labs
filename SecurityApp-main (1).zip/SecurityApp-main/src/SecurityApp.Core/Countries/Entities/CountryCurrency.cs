using SecurityApp.Core.Shared;
using SecurityApp.Core.Countries.Entities;
using SecurityApp.Core.Currencies.Entities;

namespace SecurityApp.Core.Countries.Entities;

/// <summary>
/// Links a country to one or more currencies, distinguishing primary, legal-tender,
/// and operational usage. Supports bi-temporal tracking for historical accuracy.
/// </summary>
public class CountryCurrency : TemporalEntity
{
    /// <summary>ISO 3166-1 alpha-2 code of the country.</summary>
    public string CountryAlpha2 { get; set; } = string.Empty;

    /// <summary>ISO 4217 / crypto code of the currency.</summary>
    public string CurrencyCode { get; set; } = string.Empty;

    /// <summary>This is the official/primary currency of the country.</summary>
    public bool IsPrimary { get; set; }

    /// <summary>Recognised as legal tender in the country.</summary>
    public bool IsLegalTender { get; set; } = true;

    /// <summary>Used for day-to-day operational transactions.</summary>
    public bool IsOperational { get; set; } = true;

    // Navigation
    public Country Country { get; set; } = null!;
    public Currency Currency { get; set; } = null!;
}
