using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Countries.Entities;

/// <summary>
/// ISO 3166-1 country reference record.
/// </summary>
public class Country : TemporalEntity
{
    /// <summary>ISO 3166-1 alpha-2 code (e.g. "US"). Natural unique key.</summary>
    public string Alpha2 { get; set; } = string.Empty;

    /// <summary>ISO 3166-1 alpha-3 code (e.g. "USA").</summary>
    public string Alpha3 { get; set; } = string.Empty;

    /// <summary>ISO 3166-1 numeric code zero-padded to 3 digits (e.g. "840").</summary>
    public string NumericCode { get; set; } = string.Empty;

    public string Name { get; set; } = string.Empty;

    /// <summary>Country-code top-level domain (e.g. ".us"). NULL for territories without a ccTLD.</summary>
    public string? Tld { get; set; }

    public new bool IsActive { get; set; } = true;

    public ICollection<CountryCurrency> CountryCurrencies { get; set; } = new List<CountryCurrency>();
}
