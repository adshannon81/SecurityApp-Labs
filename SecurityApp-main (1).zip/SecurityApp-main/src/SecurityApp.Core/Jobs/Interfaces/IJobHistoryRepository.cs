﻿using SecurityApp.Core.Jobs.Entities;


namespace SecurityApp.Core.Jobs.Interfaces;

public interface IJobHistoryRepository
{
    Task AddExecutionAsync(JobExecutionHistory record, CancellationToken ct = default);
    Task<IEnumerable<JobExecutionHistory>> GetRecentAsync(int take = 50, CancellationToken ct = default);
    Task DeleteOlderThanAsync(DateTime cutoff, CancellationToken ct = default);
}
