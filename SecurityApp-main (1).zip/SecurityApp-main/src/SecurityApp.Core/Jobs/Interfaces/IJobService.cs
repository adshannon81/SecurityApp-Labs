﻿using SecurityApp.Core.Jobs.Models;


namespace SecurityApp.Core.Jobs.Interfaces;

public interface IJobService
{
    Task TriggerNightlyUpdateAsync(CancellationToken ct = default);
    Task<IEnumerable<JobHistoryDto>> GetJobHistoryAsync(int take = 50, CancellationToken ct = default);

    Task<IEnumerable<JobStatusDto>> GetAllJobsAsync(CancellationToken ct = default);
    Task TriggerJobAsync(string pluginName, string triggeredBy, CancellationToken ct = default);
    Task PauseJobAsync(string pluginName, CancellationToken ct = default);
    Task ResumeJobAsync(string pluginName, CancellationToken ct = default);
    Task UpsertScheduleAsync(JobScheduleConfig config, string changedBy, CancellationToken ct = default);
    Task DeleteJobAsync(string pluginName, CancellationToken ct = default);
}
