﻿namespace SecurityApp.Core.Jobs.Interfaces;

public interface IJobExecutionContext
{
    string? CurrentJobName { get; }
    IDisposable SetCurrentJob(string jobName);
}
