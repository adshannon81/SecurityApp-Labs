﻿using SecurityApp.Core.Jobs.Models;


namespace SecurityApp.Core.Jobs.Interfaces;

public interface IJobScheduleStore
{
    Task<IEnumerable<JobScheduleConfig>> GetAllAsync(CancellationToken ct = default);
    Task UpsertAsync(JobScheduleConfig config, string changedBy, CancellationToken ct = default);
    Task DeleteAsync(string pluginName, CancellationToken ct = default);
}
