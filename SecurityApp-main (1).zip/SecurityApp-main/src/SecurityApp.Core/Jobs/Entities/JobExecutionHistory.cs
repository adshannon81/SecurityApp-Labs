﻿namespace SecurityApp.Core.Jobs.Entities;

public class JobExecutionHistory
{
    public Guid Id { get; set; }
    public string JobName { get; set; } = string.Empty;
    public string JobGroup { get; set; } = string.Empty;
    /// <summary>"scheduler" for cron-fired runs; "manual:{userName}" for API-triggered runs.</summary>
    public string TriggeredBy { get; set; } = "scheduler";
    public DateTime StartedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
    public bool Succeeded { get; set; }
    public string? ErrorMessage { get; set; }
    /// <summary>Full exception stack trace, stored only on failure.</summary>
    public string? ErrorDetail { get; set; }
    /// <summary>Securities skipped because their content hash was unchanged.</summary>
    public int? SkippedRecords { get; set; }
}
