﻿using SecurityApp.Core.Shared;


namespace SecurityApp.Core.Jobs.Entities;

public class JobSchedule : TemporalEntity
{
    public string PluginName { get; set; } = string.Empty;
    public string JobGroup { get; set; } = string.Empty;
    public string? CronExpression { get; set; }
    public bool Enabled { get; set; }
    public string TimeZone { get; set; } = "UTC";
}
