﻿namespace SecurityApp.Core.Jobs.Models;

public class JobStatusDto
{
    public string Name { get; set; } = string.Empty;
    public string Group { get; set; } = string.Empty;
    public string? CronExpression { get; set; }
    public string? TimeZone { get; set; }
    public bool IsPaused { get; set; }
    public DateTime? NextFireTimeUtc { get; set; }
    public DateTime? PreviousFireTimeUtc { get; set; }
    public string Description { get; set; } = string.Empty;
}
