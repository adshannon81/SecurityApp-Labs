﻿namespace SecurityApp.Core.Jobs.Models;

public record JobHistoryDto(
    string    JobId,
    string    JobName,
    string    State,
    DateTime? EnqueuedAt,
    DateTime? SucceededAt,
    string?   ExceptionMessage);
