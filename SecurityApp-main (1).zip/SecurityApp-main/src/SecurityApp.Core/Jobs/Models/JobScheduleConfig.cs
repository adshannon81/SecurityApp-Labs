﻿namespace SecurityApp.Core.Jobs.Models;

public class JobScheduleConfig
{
    public string PluginName { get; set; } = string.Empty;
    public string Group { get; set; } = string.Empty;
    public string CronExpression { get; set; } = string.Empty;
    public bool Enabled { get; set; } = true;
    public string TimeZone { get; set; } = "UTC";  // IANA tz id
}
