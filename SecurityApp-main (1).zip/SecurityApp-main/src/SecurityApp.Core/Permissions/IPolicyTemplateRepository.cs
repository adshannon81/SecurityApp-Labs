namespace SecurityApp.Core.Permissions;

public interface IPolicyTemplateRepository
{
    Task<IReadOnlyList<PolicyTemplate>> GetAllAsync(CancellationToken ct = default);
    Task<PolicyTemplate?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<PolicyTemplate> CreateAsync(PolicyTemplate template, CancellationToken ct = default);
    Task<PolicyTemplate> UpdateAsync(PolicyTemplate template, CancellationToken ct = default);
    Task DeleteAsync(Guid id, CancellationToken ct = default);
}
