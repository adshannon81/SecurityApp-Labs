using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Permissions;

public class PermissionBundleMember : BaseEntity
{
    public Guid PermissionBundleId     { get; set; }
    public Guid PermissionDefinitionId { get; set; }

    // Navigation
    public PermissionBundle?     Bundle     { get; set; }
    public PermissionDefinition? Permission { get; set; }
}
