namespace SecurityApp.Core.Permissions;

public interface IEntityScreenRepository
{
    Task<IReadOnlyList<EntityScreen>> GetAllAsync(CancellationToken ct = default);
    Task<EntityScreen?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<EntityScreen> CreateAsync(EntityScreen screen, CancellationToken ct = default);
    Task<EntityScreen> UpdateAsync(EntityScreen screen, CancellationToken ct = default);
    Task DeleteAsync(Guid id, CancellationToken ct = default);
}
