using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Permissions;

public class PermissionBundle : TemporalEntity
{
    public string BundleKey   { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public new bool IsActive { get; set; } = true;

    // Navigation
    public ICollection<PermissionBundleMember> Members { get; set; } = new List<PermissionBundleMember>();
}
