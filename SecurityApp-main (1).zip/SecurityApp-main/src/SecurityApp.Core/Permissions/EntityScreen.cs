using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Permissions;

public class EntityScreen : TemporalEntity
{
    public string ScreenKey { get; set; } = string.Empty;

    public string DisplayName { get; set; } = string.Empty;

    public string? EntityType { get; set; }

    public Guid? AppResourceId { get; set; }

    public string? Description { get; set; }

    public int SortOrder { get; set; }

    public new bool IsActive { get; set; } = true;
}
