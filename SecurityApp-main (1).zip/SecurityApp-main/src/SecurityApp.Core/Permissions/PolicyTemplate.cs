using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Permissions;

public class PolicyTemplate : TemporalEntity
{
    public string  TemplateKey  { get; set; } = string.Empty;
    public string  TemplateName { get; set; } = string.Empty;
    public string  TargetType   { get; set; } = string.Empty;
    public string? Description  { get; set; }
    public string  TemplateJson { get; set; } = string.Empty;
    public new bool IsActive { get; set; } = true;
}
