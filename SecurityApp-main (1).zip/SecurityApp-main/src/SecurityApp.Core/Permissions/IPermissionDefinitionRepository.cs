namespace SecurityApp.Core.Permissions;

public interface IPermissionDefinitionRepository
{
    Task<IReadOnlyList<PermissionDefinition>> GetAllAsync(CancellationToken ct = default);
    Task<PermissionDefinition?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<PermissionDefinition?> GetByKeyAsync(string permissionKey, CancellationToken ct = default);
    Task<PermissionDefinition> CreateAsync(PermissionDefinition entity, CancellationToken ct = default);
    Task<PermissionDefinition> UpdateAsync(PermissionDefinition entity, CancellationToken ct = default);
    Task DeleteAsync(Guid id, CancellationToken ct = default);
}
