using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Permissions;

/// <summary>
/// Master catalog of every permission key that can be assigned in rules.
/// Admins select from this catalog instead of typing raw strings.
/// </summary>
public class PermissionDefinition : TemporalEntity
{
    /// <summary>Keycloak client role key, e.g. "securities:read".</summary>
    public string PermissionKey { get; set; } = string.Empty;

    public string DisplayName { get; set; } = string.Empty;

    /// <summary>Logical grouping, e.g. "Securities", "Admin", "Audit".</summary>
    public string PermissionGroup { get; set; } = string.Empty;

    public string? Description { get; set; }

    /// <summary>When false, this permission cannot be selected in rule editors.</summary>
    public bool IsAssignable { get; set; } = true;

    /// <summary>When true, this is a reserved system permission.</summary>
    public bool IsSystem { get; set; }

    public int SortOrder { get; set; }

    public new bool IsActive { get; set; } = true;

}
