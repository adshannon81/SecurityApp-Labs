namespace SecurityApp.Core.Permissions;

public interface IPermissionBundleRepository
{
    Task<IReadOnlyList<PermissionBundle>> GetAllAsync(CancellationToken ct = default);
    Task<PermissionBundle?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<PermissionBundle?> GetWithMembersAsync(Guid id, CancellationToken ct = default);
    Task<IReadOnlyList<PermissionBundleMember>> GetMembersAsync(Guid bundleId, CancellationToken ct = default);
    Task<PermissionBundle> CreateAsync(PermissionBundle bundle, CancellationToken ct = default);
    Task<PermissionBundle> UpdateAsync(PermissionBundle bundle, CancellationToken ct = default);
    Task DeleteAsync(Guid id, CancellationToken ct = default);
    Task<PermissionBundleMember> AddMemberAsync(PermissionBundleMember member, CancellationToken ct = default);
    Task RemoveMemberAsync(Guid memberId, CancellationToken ct = default);
}
