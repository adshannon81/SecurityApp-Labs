namespace SecurityApp.Core.Grpc;

/// <summary>
/// Redis Pub/Sub channel names used by gRPC streaming services.
/// Publishers (domain handlers, background services) and subscribers (gRPC services)
/// must agree on these names.
/// </summary>
public static class GrpcStreamChannels
{
    public const string SecurityChanges        = "securityapp:grpc:security:changes";
    private const string PriceTickTemplate     = "securityapp:grpc:price:{0}";
    public const string WorkflowPendingChanged = "securityapp:grpc:workflow:pending";
    private const string WorkflowInstanceTemplate = "securityapp:grpc:workflow:instance:{0}";
    public const string DashboardMetrics       = "securityapp:grpc:dashboard";
    public const string NavConfigChanged        = "securityapp:grpc:nav:config";
    public const string RefDataChanged          = "securityapp:grpc:refdata:changed";

    public static string ForPrice(Guid securityId)            => string.Format(PriceTickTemplate, securityId);
    public static string ForWorkflowInstance(Guid instanceId) => string.Format(WorkflowInstanceTemplate, instanceId);
}
