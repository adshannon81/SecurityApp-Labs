namespace SecurityApp.Core.Grpc;

// ── Payload records ────────────────────────────────────────────────────────────
// Simple serialisable wire payloads carried over Redis Pub/Sub channels.
// Intentionally separate from Application DTOs and gRPC proto messages.

public record SecurityChangedPayload(
    Guid     SecurityId,
    string   ChangeType,
    string   IdentifierType,
    string   IdentifierValue,
    string   Name,
    string   SecurityType,
    bool     IsActive,
    string   Currency,
    string   Issuer,
    string   Description,
    DateTime OccurredAt,
    string?  StatusCode         = null,
    string?  AssetClassCode     = null,
    string?  InstrumentTypeCode = null);

public record PriceChangedPayload(
    Guid     SecurityId,
    decimal  Value,
    string?  Currency,
    string?  Source,
    string?  PriceType,
    DateTime PriceDate,
    DateTime OccurredAt);

public record WorkflowInstanceChangedPayload(
    Guid    InstanceId,
    string  Status,
    int     StepOrder,
    string? LastDecision,
    string? LastDecisionBy,
    DateTime OccurredAt);

public record ConnectorHealthPayload(string Name, bool IsHealthy, string Message);

public record DashboardMetricsPayload(
    int TotalSecurities,
    int ActiveSecurities,
    int PendingApprovals,
    IReadOnlyList<ConnectorHealthPayload> Connectors,
    DateTime AsOf);

/// <summary>Fired whenever any AppResource is created, updated, or deleted.</summary>
public record NavConfigChangedPayload(string ChangedBy, DateTime OccurredAt);

/// <summary>Fired whenever a named reference-data entity is created, updated, or deleted.
/// <c>EntityType</c> is one of: Issuer, DerivationRule, RatingScale, Client, Portfolio, FieldVisibility.</summary>
public record RefDataChangedPayload(string EntityType, string ChangedBy);

// ── Publisher interface ────────────────────────────────────────────────────────

/// <summary>
/// Publishes domain events to Redis Pub/Sub channels so that all connected gRPC
/// streaming clients receive updates in real-time (fan-out).
/// <para>
/// Implementations: <c>RedisGrpcEventPublisher</c> (production),
/// <c>NullGrpcEventPublisher</c> (local dev / CI without Redis).
/// </para>
/// </summary>
public interface IGrpcEventPublisher
{
    Task PublishSecurityChangedAsync(SecurityChangedPayload payload,                    CancellationToken ct = default);
    Task PublishPriceChangedAsync(PriceChangedPayload payload,                        CancellationToken ct = default);
    Task PublishWorkflowInstanceChangedAsync(WorkflowInstanceChangedPayload payload,   CancellationToken ct = default);
    /// <summary>Fires an empty signal so pending-count subscribers re-query their role.</summary>
    Task PublishWorkflowPendingChangedAsync(CancellationToken ct = default);
    Task PublishDashboardMetricsAsync(DashboardMetricsPayload payload,                 CancellationToken ct = default);
    /// <summary>Notifies all connected clients that the nav/menu configuration has changed.</summary>
    Task PublishNavConfigChangedAsync(NavConfigChangedPayload payload,                  CancellationToken ct = default);
    /// <summary>Notifies all connected clients that a reference-data entity has changed.</summary>
    Task PublishRefDataChangedAsync(RefDataChangedPayload payload,                     CancellationToken ct = default);
}
