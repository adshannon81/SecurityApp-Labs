namespace SecurityApp.Core.Import.Services;

using SecurityApp.Core.Import.Interfaces;

/// <summary>
/// Pass-through implementation of <see cref="ISecretResolver"/> used when Vault is
/// disabled or in testing scenarios. Every value is returned unchanged.
/// </summary>
public sealed class LiteralSecretResolver : ISecretResolver
{
    public Task<string> ResolveAsync(string? value, CancellationToken ct = default)
        => Task.FromResult(value ?? string.Empty);
}
