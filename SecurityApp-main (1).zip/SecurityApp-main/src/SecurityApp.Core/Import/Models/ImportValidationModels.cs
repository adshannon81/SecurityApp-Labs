﻿namespace SecurityApp.Core.Import.Models;

/// <summary>
/// A validation error or warning produced by <see cref="SecurityApp.Core.Interfaces.IImportValidationRunner"/>
/// during file parsing.
/// </summary>
public class ImportValidationError
{
    /// <summary>1-based row number within the source file.</summary>
    public int RowNumber { get; set; }

    /// <summary>
    /// Target field name that failed validation. Null for row-level (cross-column) errors.
    /// </summary>
    public string? ColumnName { get; set; }

    /// <summary>Rule type that triggered this entry (Required, Regex, MinValue, NCalcExpression, etc.).</summary>
    public string RuleType { get; set; } = string.Empty;

    public string Message { get; set; } = string.Empty;

    /// <summary>Error (blocks import of this row) or Warning (informational).</summary>
    public string Severity { get; set; } = "Error";

    /// <summary>Raw cell value at the time of evaluation (before any Transform).</summary>
    public string? RawValue { get; set; }
}
