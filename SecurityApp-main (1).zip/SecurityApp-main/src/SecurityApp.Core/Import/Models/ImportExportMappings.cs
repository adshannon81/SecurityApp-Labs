﻿namespace SecurityApp.Core.Import.Models;

// ------------------------------------------------------------------
// Import mapping models
// ------------------------------------------------------------------

/// <summary>
/// Maps one source column/field name to an <see cref="ExternalSecurityData"/> property name.
/// </summary>
public class ImportColumnMap
{
    /// <summary>Column header as it appears in the source file (case-insensitive match).</summary>
    public string Source { get; set; } = string.Empty;

    /// <summary>Target property name on <see cref="ExternalSecurityData"/> (e.g. "IdentifierValue").</summary>
    public string Target { get; set; } = string.Empty;
}

/// <summary>
/// Import profile for a single flat/delimiter-separated source (CSV, TSV, pipe-delimited, -).
/// Multiple named profiles can be configured - each scans its own <see cref="Folder"/> for
/// files matching <see cref="FilePattern"/>.
/// </summary>
public class FlatFileImportProfile
{
    /// <summary>
    /// Sub-folder relative to the connector's root <c>ImportDirectory</c>.
    /// Examples: <c>"bloomberg"</c>, <c>"feeds/reuters"</c>.
    /// Empty string or omitted means the root <c>ImportDirectory</c> itself.
    /// </summary>
    public string Folder { get; set; } = string.Empty;

    /// <summary>
    /// Glob pattern matched against file names inside <see cref="Folder"/>.
    /// Examples: <c>"*.csv"</c>, <c>"bloomberg_*.csv"</c>, <c>"equities_*.txt"</c>.
    /// Default: <c>"*.csv"</c>.
    /// </summary>
    public string FilePattern { get; set; } = "*.csv";

    /// <summary>
    /// Field delimiter as the actual character(s).
    /// Examples: <c>","</c> (comma), <c>"|"</c> (pipe), <c>"\t"</c> (tab), <c>";"</c> (semicolon).
    /// Default: <c>","</c>.
    /// </summary>
    public string Delimiter { get; set; } = ",";

    /// <summary>
    /// Optional text qualifier wrapped around field values.
    /// Examples: <c>"\""</c> (double-quote), <c>"'"</c> (single-quote).
    /// Empty string means no qualifier. Default: <c>"\""</c>.
    /// </summary>
    public string TextQualifier { get; set; } = "\"";

    /// <summary>Number of leading data rows to skip after the header. Default: 0.</summary>
    public int SkipRows { get; set; } = 0;

    /// <summary>
    /// Whether the first data line contains column headers. Default: true.
    /// When false, column mappings must use zero-based ordinal strings ("0", "1", …) as Source values.
    /// </summary>
    public bool HasHeader { get; set; } = true;

    /// <summary>
    /// Column mappings from source header to target property.
    /// When empty the connector falls back to the built-in default header names.
    /// </summary>
    public List<ImportColumnMap> Columns { get; set; } = [];

    /// <summary>
    /// Transport configuration. Null or <see cref="TransportConfig.Type"/> == Local means
    /// files are already present on the local filesystem.
    /// </summary>
    public TransportConfig? Transport { get; set; }
}

/// <summary>
/// Import profile for a single JSON file source.
/// Multiple named profiles can be configured - each scans its own <see cref="Folder"/> for
/// files matching <see cref="FilePattern"/>.
/// </summary>
public class JsonImportProfile
{
    /// <summary>
    /// Sub-folder relative to the connector's root <c>ImportDirectory</c>.
    /// Empty string or omitted means the root <c>ImportDirectory</c> itself.
    /// </summary>
    public string Folder { get; set; } = string.Empty;

    /// <summary>
    /// Glob pattern matched against file names inside <see cref="Folder"/>.
    /// Examples: <c>"*.json"</c>, <c>"bloomberg_*.json"</c>.
    /// Default: <c>"*.json"</c>.
    /// </summary>
    public string FilePattern { get; set; } = "*.json";

    /// <summary>
    /// JSONPath expression that selects the array of record objects.
    /// Examples: <c>"$.securities[*]"</c>, <c>"$.items[*]"</c>, <c>"$[*]"</c> (root array).
    /// Default: <c>"$[*]"</c> (root array).
    /// </summary>
    public string RecordsPath { get; set; } = "$[*]";

    /// <summary>
    /// Column mappings from source JSON property name to target property.
    /// When empty the connector falls back to the built-in default names.
    /// </summary>
    public List<ImportColumnMap> Columns { get; set; } = [];

    /// <summary>
    /// Transport configuration. Null or <see cref="TransportConfig.Type"/> == Local means
    /// files are already present on the local filesystem.
    /// </summary>
    public TransportConfig? Transport { get; set; }
}

/// <summary>
/// Import profile for a single XML file source.
/// Multiple named profiles can be configured - each scans its own <see cref="Folder"/> for
/// files matching <see cref="FilePattern"/>.
/// </summary>
public class XmlImportProfile
{
    /// <summary>
    /// Sub-folder relative to the connector's root <c>ImportDirectory</c>.
    /// Empty string or omitted means the root <c>ImportDirectory</c> itself.
    /// </summary>
    public string Folder { get; set; } = string.Empty;

    /// <summary>
    /// Glob pattern matched against file names inside <see cref="Folder"/>.
    /// Examples: <c>"*.xml"</c>, <c>"bloomberg_*.xml"</c>.
    /// Default: <c>"*.xml"</c>.
    /// </summary>
    public string FilePattern { get; set; } = "*.xml";

    /// <summary>
    /// XPath expression that selects the individual record elements.
    /// Examples: <c>"//Securities/Security"</c>, <c>"//items/item"</c>.
    /// Default: <c>"//Security"</c>.
    /// </summary>
    public string RecordsXPath { get; set; } = "//Security";

    /// <summary>
    /// Column mappings from source element/attribute name to target property.
    /// When empty the connector falls back to the built-in default names.
    /// </summary>
    public List<ImportColumnMap> Columns { get; set; } = [];

    /// <summary>
    /// Transport configuration. Null or <see cref="TransportConfig.Type"/> == Local means
    /// files are already present on the local filesystem.
    /// </summary>
    public TransportConfig? Transport { get; set; }
}

// ------------------------------------------------------------------
// Export mapping models
// ------------------------------------------------------------------

/// <summary>
/// Maps one <see cref="SecurityExportRecord"/> property to an output column.
/// </summary>
public class ExportColumnMap
{
    /// <summary>Property name on <see cref="SecurityExportRecord"/> (e.g. "IdentifierValue").</summary>
    public string Field { get; set; } = string.Empty;

    /// <summary>
    /// Column header written to the output file.
    /// Defaults to <see cref="Field"/> when not specified.
    /// </summary>
    public string Header { get; set; } = string.Empty;

    /// <summary>
    /// Optional .NET format string applied when the field is numeric or a date.
    /// Examples: <c>"F4"</c>, <c>"yyyy-MM-dd"</c>, <c>"P2"</c>.
    /// </summary>
    public string? Format { get; set; }
}

/// <summary>
/// Export profile controlling which fields are included and how they are rendered.
/// </summary>
public class ExportMappingProfile
{
    /// <summary>
    /// The ordered list of columns to emit.
    /// When empty all fields on <see cref="SecurityExportRecord"/> are exported in declaration order.
    /// </summary>
    public List<ExportColumnMap> Columns { get; set; } = [];
}
