using SecurityApp.Core.Import.Enums;

namespace SecurityApp.Core.Import.Models;

/// <summary>
/// Transport configuration attached to an import profile.
/// Populated from <see cref="SecurityApp.Core.Import.Entities.ImportProfile"/> transport columns.
/// </summary>
public class TransportConfig
{
    public TransportType Type { get; set; } = TransportType.Local;

    /// <summary>Remote host (SFTP/FTP/FTPS) or base URL (HTTPS). Null for Local.</summary>
    public string? Host { get; set; }

    /// <summary>Port override. Null means use the protocol default.</summary>
    public int? Port { get; set; }

    /// <summary>Login username (SFTP/FTP/FTPS).</summary>
    public string? Username { get; set; }

    /// <summary>
    /// Password or secret reference. Treated as a literal password.
    /// For production deployments, inject via environment variable or Vault.
    /// </summary>
    public string? PasswordSecret { get; set; }

    /// <summary>
    /// Remote directory path (SFTP/FTP/FTPS) or full URL (HTTPS).
    /// </summary>
    public string? RemotePath { get; set; }

    /// <summary>
    /// Expected server TLS certificate thumbprint (SHA-256, hex no colons) for FTPS pinning.
    /// Null disables pinning.
    /// </summary>
    public string? TlsThumbprint { get; set; }

    /// <summary>
    /// Maximum HTTPS download retry attempts (applies to <see cref="TransportType.Https"/> only).
    /// Controlled globally via <c>Resilience:HttpsDownloadMaxRetryCount</c> in appsettings.
    /// Default 3.
    /// </summary>
    public int RetryCount { get; set; } = 3;
}
