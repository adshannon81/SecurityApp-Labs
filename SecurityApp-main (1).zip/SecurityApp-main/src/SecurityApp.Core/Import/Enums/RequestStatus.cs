﻿namespace SecurityApp.Core.Import.Enums;

/// <summary>
/// Status of import/export requests
/// </summary>
public enum RequestStatus
{
    Pending,
    InProgress,
    Completed,
    Failed,
    Cancelled,
    PartiallyCompleted
}
