﻿namespace SecurityApp.Core.Import.Enums;

/// <summary>
/// Type of import/export request
/// </summary>
public enum RequestType
{
    Import,
    Export,
    Update,
    Sync
}
