namespace SecurityApp.Core.Import.Enums;

/// <summary>
/// Defines how files are fetched before being parsed by a file-based connector.
/// </summary>
public enum TransportType
{
    /// <summary>Files are already present on the local filesystem (default, no network I/O).</summary>
    Local = 0,

    /// <summary>Files are fetched via SSH File Transfer Protocol (SFTP, TCP/22 by default).</summary>
    Sftp = 1,

    /// <summary>Files are fetched via FTP over explicit TLS (FTPS, TCP/21 by default).</summary>
    Ftps = 2,

    /// <summary>Files are fetched via plain FTP (not encrypted — use only on trusted networks).</summary>
    Ftp = 3,

    /// <summary>A single file is fetched via HTTPS GET.</summary>
    Https = 4
}
