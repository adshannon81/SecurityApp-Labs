﻿using SecurityApp.Core.Shared;
using SecurityApp.Core.Import.Enums;
using SecurityApp.Core.Shared.Enums;


namespace SecurityApp.Core.Import.Entities;

/// <summary>
/// Represents an import/export request to external systems
/// </summary>
public class ImportRequest : BaseEntity
{
    public RequestType RequestType { get; set; }
    public DataSourceType? SourceSystem { get; set; }
    public DataSourceType? TargetSystem { get; set; }
    public RequestStatus Status { get; set; } = RequestStatus.Pending;
    public Guid? UserId { get; set; }
    public string? UserName { get; set; }
    public DateTime? CompletedAt { get; set; }
    public string? ErrorMessage { get; set; }
    public string? RequestDetails { get; set; } // JSON format
    public int? TotalRecords { get; set; }
    public int? ProcessedRecords { get; set; }
    public int? FailedRecords { get; set; }
    /// <summary>Records that were unchanged (content hash matched) and skipped.</summary>
    public int? SkippedRecords { get; set; }
    /// <summary>Retry attempt counter. 0 = original attempt; incremented by ImportRetryConsumer.</summary>
    public int AttemptNumber { get; set; } = 0;
}
