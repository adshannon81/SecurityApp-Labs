﻿using SecurityApp.Core.Shared;


namespace SecurityApp.Core.Import.Entities;

/// <summary>
/// Maps one source column (file header or ordinal index) to a target field on
/// <see cref="SecurityApp.Core.Models.ExternalSecurityData"/>.
/// Belongs to an <see cref="ImportProfile"/>.
/// </summary>
public class ImportProfileColumn : BaseEntity
{
    public Guid ProfileId { get; set; }

    /// <summary>
    /// Source column identifier as it appears in the file.
    /// For text files with headers (<see cref="ImportProfile.HasHeader"/> = true):
    ///   the header name, e.g. "bloomberg_ticker".
    /// For header-less files (HasHeader = false):
    ///   the zero-based ordinal as a string, e.g. "0", "1", "2".
    /// </summary>
    public string SourceColumn { get; set; } = string.Empty;

    /// <summary>
    /// Target property name on ExternalSecurityData, stored lowercase.
    /// E.g. "symbol", "identifiervalue", "couponrate".
    /// </summary>
    public string TargetField { get; set; } = string.Empty;

    /// <summary>Display and processing order within the profile (ascending).</summary>
    public int SortOrder { get; set; }

    // Navigation
    public ImportProfile Profile { get; set; } = null!;
    public ICollection<ImportProfileColumnValidation> Validations { get; set; } = new List<ImportProfileColumnValidation>();
}
