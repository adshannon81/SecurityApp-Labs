﻿using SecurityApp.Core.Shared;


namespace SecurityApp.Core.Import.Entities;

/// <summary>
/// A single validation or transform rule attached to one import profile column.
/// Rules are evaluated in <see cref="SortOrder"/> order; Transform rules mutate
/// the cell value in-place before subsequent validation rules run.
/// </summary>
public class ImportProfileColumnValidation : BaseEntity
{
    public Guid ColumnId { get; set; }

    /// <summary>
    /// Rule type. Supported values:
    /// <list type="bullet">
    ///   <item><term>Required</term><description>Cell value must not be null or whitespace.</description></item>
    ///   <item><term>Regex</term><description>Cell value must match the regex in RuleValue.</description></item>
    ///   <item><term>MinLength</term><description>Minimum string length (integer in RuleValue).</description></item>
    ///   <item><term>MaxLength</term><description>Maximum string length (integer in RuleValue).</description></item>
    ///   <item><term>MinValue</term><description>Minimum numeric value (decimal in RuleValue).</description></item>
    ///   <item><term>MaxValue</term><description>Maximum numeric value (decimal in RuleValue).</description></item>
    ///   <item><term>AllowedValues</term><description>Comma-separated list of allowed values in RuleValue.</description></item>
    ///   <item><term>DateFormat</term><description>.NET date format string in RuleValue, e.g. "yyyy-MM-dd".</description></item>
    ///   <item><term>NCalcExpression</term><description>NCalc boolean expression in RuleValue; must evaluate to true, e.g. "[CouponRate] > 0".</description></item>
    ///   <item><term>Transform</term><description>NCalc expression in RuleValue that returns the normalised cell value, e.g. "[Value].ToUpper()". Mutates the row dict.</description></item>
    /// </list>
    /// </summary>
    public string RuleType { get; set; } = string.Empty;

    /// <summary>Rule parameter - interpretation depends on RuleType (see above).</summary>
    public string? RuleValue { get; set; }

    /// <summary>
    /// Optional NCalc condition evaluated against the full row (target field names as variables).
    /// The rule fires only when this expression evaluates to true.
    /// Leave null to always fire. E.g. "[SecurityType] == 'Bond'".
    /// </summary>
    public string? Condition { get; set; }

    /// <summary>Custom error message; overrides the auto-generated message when set.</summary>
    public string? ErrorMessage { get; set; }

    /// <summary>Severity level: "Error" (blocks import) or "Warning" (informational).</summary>
    public string Severity { get; set; } = "Error";

    public bool IsActive { get; set; } = true;

    // Navigation
    public ImportProfileColumn Column { get; set; } = null!;
}
