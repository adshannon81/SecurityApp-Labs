﻿using SecurityApp.Core.Shared;


namespace SecurityApp.Core.Import.Entities;

/// <summary>
/// A named import configuration profile stored in the database.
/// Each profile targets one connector source type (FlatFile, JsonFile, XmlFile) and
/// defines the file-matching glob, column mappings, and format-specific settings
/// (delimiter, qualifier, JSONPath, XPath, etc.).
///
/// Multiple active profiles per source type are supported so that different data
/// vendors can each have their own mapping without redeploying.
/// </summary>
public class ImportProfile : BaseEntity
{
    /// <summary>Human-readable name, unique within a SourceType. E.g. "Bloomberg_Daily".</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>Optional description.</summary>
    public string? Description { get; set; }

    /// <summary>
    /// Connector source type. One of: "FlatFile", "JsonFile", "XmlFile".
    /// Used by connectors to filter profiles relevant to them.
    /// </summary>
    public string SourceType { get; set; } = string.Empty;

    /// <summary>Glob pattern matched against incoming file names (e.g. "bloomberg_*.csv").</summary>
    public string FilePattern { get; set; } = "*.csv";

    /// <summary>Optional sub-folder under the connector's ImportDirectory.</summary>
    public string? Folder { get; set; }

    // -- FlatFile-specific ----------------------------------------------------

    /// <summary>
    /// Field delimiter character(s). Use actual chars: "," or "|" or "\t" (tab).
    /// Null defaults to comma.
    /// </summary>
    public string? Delimiter { get; set; }

    /// <summary>
    /// Text qualifier character. Use "\"" for double-quote, "'" for single-quote,
    /// or null / empty string for no qualifier.
    /// </summary>
    public string? TextQualifier { get; set; }

    /// <summary>
    /// Whether the first data line is a header row.
    /// When false, column mappings must use zero-based ordinal indices ("0", "1", â€¦)
    /// as SourceColumn values.
    /// </summary>
    public bool HasHeader { get; set; } = true;

    /// <summary>Number of data rows to skip after the header (or from beginning when HasHeader=false).</summary>
    public int SkipRows { get; set; } = 0;

    // -- JsonFile-specific ----------------------------------------------------

    /// <summary>JSONPath expression selecting the record array (e.g. "$[*]" or "$.securities[*]").</summary>
    public string? RecordsPath { get; set; }

    // -- XmlFile-specific ----------------------------------------------------

    /// <summary>XPath expression selecting record elements (e.g. "//Security").</summary>
    public string? RecordsXPath { get; set; }

    // ── Transport ────────────────────────────────────────────────────────────────

    /// <summary>
    /// How files are acquired before parsing. One of: "Local", "Sftp", "Ftps", "Ftp", "Https".
    /// Defaults to "Local" (files already present on the filesystem).
    /// </summary>
    public string TransportType { get; set; } = "Local";

    /// <summary>Remote host name or IP address (SFTP/FTP/FTPS/HTTPS). Null for Local.</summary>
    public string? TransportHost { get; set; }

    /// <summary>Remote port override. Null uses the protocol default (SFTP=22, FTP/FTPS=21, HTTPS=443).</summary>
    public int? TransportPort { get; set; }

    /// <summary>Login username for SFTP/FTP/FTPS.</summary>
    public string? TransportUsername { get; set; }

    /// <summary>
    /// Password or secret reference. For production use a Vault/environment-variable key here
    /// rather than the literal password.
    /// </summary>
    public string? TransportPasswordSecret { get; set; }

    /// <summary>
    /// Remote directory path to list/download files from (SFTP/FTP/FTPS),
    /// or full URL for HTTPS transport.
    /// </summary>
    public string? TransportRemotePath { get; set; }

    /// <summary>
    /// Expected TLS certificate thumbprint (SHA-256 hex, no colons) for FTPS certificate pinning.
    /// Null disables pinning (system CA validation applies).
    /// </summary>
    public string? TransportTlsThumbprint { get; set; }

    // ── State ────────────────────────────────────────────────────────────────────

    /// <summary>When false, this profile is ignored by connectors.</summary>
    public bool IsActive { get; set; } = true;

    // -- Navigation -----------------------------------------------------------

    public ICollection<ImportProfileColumn> Columns { get; set; } = new List<ImportProfileColumn>();
    public ICollection<ImportProfileRowValidation> RowValidations { get; set; } = new List<ImportProfileRowValidation>();
}
