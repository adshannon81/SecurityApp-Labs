﻿using SecurityApp.Core.Shared;


namespace SecurityApp.Core.Import.Entities;

/// <summary>
/// A row-level NCalc validation rule applied after all column-level transforms and validations.
/// The full row (keyed by canonical target field names) is exposed as NCalc variables.
/// </summary>
public class ImportProfileRowValidation : BaseEntity
{
    public Guid ProfileId { get; set; }

    /// <summary>
    /// NCalc boolean expression evaluated over the full row.
    /// Row field values are available as [FieldName] (canonical lower-case target names).
    /// E.g. "[securitytype] == 'Bond' &amp;&amp; [couponrate] > 0".
    /// </summary>
    public string Expression { get; set; } = string.Empty;

    /// <summary>Error message returned when the expression evaluates to false.</summary>
    public string ErrorMessage { get; set; } = string.Empty;

    /// <summary>Severity level: "Error" (blocks import) or "Warning" (informational).</summary>
    public string Severity { get; set; } = "Error";

    /// <summary>Order in which row rules are evaluated (ascending).</summary>
    public int SortOrder { get; set; }

    public bool IsActive { get; set; } = true;

    // Navigation
    public ImportProfile Profile { get; set; } = null!;
}
