﻿using SecurityApp.Core.Import.Entities;
using SecurityApp.Core.Import.Models;


namespace SecurityApp.Core.Import.Interfaces;

/// <summary>
/// Validates a single parsed row against an <see cref="ImportProfile"/>'s column rules
/// and row-level NCalc expressions.
///
/// Transform rules (RuleType = "Transform") are applied in-place to the row dictionary
/// before validation rules run - subsequent mappers see the normalised value.
/// </summary>
public interface IImportValidationRunner
{
    /// <summary>
    /// Validates and optionally transforms one raw data row.
    /// </summary>
    /// <param name="profile">Profile with <see cref="ImportProfile.Columns"/> and <see cref="ImportProfile.RowValidations"/> eagerly loaded.</param>
    /// <param name="row">Mutable keyâ†’value dictionary; keys are lower-case target field names. Transform rules mutate this dictionary.</param>
    /// <param name="rowNumber">1-based row number in the source file (for error reporting).</param>
    /// <returns>All validation errors and warnings; empty list when the row is fully valid.</returns>
    Task<List<ImportValidationError>> ValidateRowAsync(
        ImportProfile profile,
        Dictionary<string, string> row,
        int rowNumber,
        CancellationToken ct = default);
}
