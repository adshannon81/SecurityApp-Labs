﻿using SecurityApp.Core.Import.Entities;


namespace SecurityApp.Core.Import.Interfaces;

/// <summary>
/// CRUD service for database-backed import profiles (column mappings and validation rules).
/// Profiles are the runtime alternative to static appsettings.json column configuration.
/// </summary>
public interface IImportProfileService
{
    /// <summary>Returns all active profiles for a given connector source type (FlatFile / JsonFile / XmlFile).</summary>
    Task<IReadOnlyList<ImportProfile>> GetActiveProfilesAsync(string sourceType, CancellationToken ct = default);

    Task<ImportProfile?> GetByIdAsync(Guid id, CancellationToken ct = default);

    Task<ImportProfile?> GetByNameAsync(string name, string sourceType, CancellationToken ct = default);

    Task<ImportProfile> CreateAsync(ImportProfile profile, CancellationToken ct = default);

    Task UpdateAsync(ImportProfile profile, CancellationToken ct = default);

    /// <summary>Soft-deactivates a profile (sets IsActive = false).</summary>
    Task DeactivateAsync(Guid id, CancellationToken ct = default);

    // -- Column operations -----------------------------------------------------

    Task<ImportProfileColumn> AddColumnAsync(ImportProfileColumn column, CancellationToken ct = default);

    Task RemoveColumnAsync(Guid columnId, CancellationToken ct = default);

    /// <summary>Replaces all columns on a profile atomically (delete-then-insert).</summary>
    Task ReplaceColumnsAsync(Guid profileId, List<ImportProfileColumn> columns, CancellationToken ct = default);

    // -- Column validation operations -----------------------------------------

    Task<ImportProfileColumnValidation> AddColumnValidationAsync(ImportProfileColumnValidation validation, CancellationToken ct = default);

    Task RemoveColumnValidationAsync(Guid validationId, CancellationToken ct = default);

    // -- Row validation operations ---------------------------------------------

    Task<ImportProfileRowValidation> AddRowValidationAsync(ImportProfileRowValidation validation, CancellationToken ct = default);

    Task RemoveRowValidationAsync(Guid validationId, CancellationToken ct = default);
}
