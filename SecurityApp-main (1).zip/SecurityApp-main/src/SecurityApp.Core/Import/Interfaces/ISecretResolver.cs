namespace SecurityApp.Core.Import.Interfaces;

/// <summary>
/// Resolves a raw DB-stored value to its actual runtime value.
///
/// Convention for Vault references (KV v2):
///   vault:{path}#{field}
///   e.g. "vault:sftp/bloomberg#host"   → reads field "host" from KV path "sftp/bloomberg"
///        "vault:sftp/bloomberg#password" → reads field "password" from same path
///
/// Any value that does not start with a recognised prefix is returned as-is,
/// allowing literal values to be stored alongside references without extra configuration.
/// </summary>
public interface ISecretResolver
{
    /// <summary>
    /// Returns the resolved secret, or the original <paramref name="value"/> if it is not a reference.
    /// Returns an empty string when <paramref name="value"/> is null.
    /// </summary>
    Task<string> ResolveAsync(string? value, CancellationToken ct = default);
}
