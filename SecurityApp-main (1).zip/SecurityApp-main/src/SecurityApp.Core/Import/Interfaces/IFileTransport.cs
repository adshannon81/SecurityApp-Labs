namespace SecurityApp.Core.Import.Interfaces;

/// <summary>
/// Abstracts how files are acquired before a file-based connector parses them.
///
/// For <c>Local</c> transport the implementation is a no-op — it returns the local
/// source path as-is. For remote transports (SFTP, FTPS, FTP, HTTPS) the implementation
/// downloads matching files into a temporary local directory and returns that path.
/// The connector calls <see cref="DisposeAsync"/> after parsing to clean up the temp directory.
/// </summary>
public interface IFileTransport : IAsyncDisposable
{
    /// <summary>
    /// Ensures files matching <paramref name="filePattern"/> are available locally and
    /// returns the local directory path to scan.
    ///
    /// For <c>Local</c> transport: returns <paramref name="localSourcePath"/> unchanged.
    /// For remote transports: downloads all matching files from the remote path into a
    /// new temp directory and returns that temp directory path.
    /// </summary>
    /// <param name="localSourcePath">
    ///   The local directory already configured on the profile. Used directly by Local transport;
    ///   ignored (except as a fallback) by remote transports.
    /// </param>
    /// <param name="filePattern">Glob pattern (e.g. "*.csv") for file selection.</param>
    /// <param name="ct">Cancellation token.</param>
    /// <returns>Path of the local directory that contains the files to parse.</returns>
    Task<string> AcquireLocalFolderAsync(
        string localSourcePath,
        string filePattern,
        CancellationToken ct = default);
}
