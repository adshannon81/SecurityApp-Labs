﻿using SecurityApp.Core.Import.Entities;
using SecurityApp.Core.Audit.Entities;
using SecurityApp.Core.Shared.Interfaces;


namespace SecurityApp.Core.Import.Interfaces;

/// <summary>
/// Narrow unit-of-work interface scoped to the Import bounded context.
/// Inject this instead of <see cref="IUnitOfWork"/> in any class that only needs
/// import request tracking or profile management data.
/// </summary>
public interface IImportUoW
{
    IRepository<ImportRequest> ImportRequests { get; }
    IRepository<ImportProfile> ImportProfiles { get; }
    IRepository<ImportProfileColumn> ImportProfileColumns { get; }
    IRepository<ImportProfileColumnValidation> ImportProfileColumnValidations { get; }
    IRepository<ImportProfileRowValidation> ImportProfileRowValidations { get; }
    IRepository<AuditLog> AuditLogs { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    Task BeginTransactionAsync(CancellationToken cancellationToken = default);
    Task CommitTransactionAsync(CancellationToken cancellationToken = default);
    Task RollbackTransactionAsync(CancellationToken cancellationToken = default);
}
