﻿using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Securities.Models;


namespace SecurityApp.Core.Import.Messages;

/// <summary>
/// Published by <see cref="Application.Handlers.ImportSecurityHandler"/> after a provider fetch
/// confirms data has changed (or is newly imported).
/// <para>
/// <see cref="Infrastructure.Messaging.SecurityImportedHandler"/> subscribes and performs the
/// Security / SecurityAttribute / CreditRating upsert, so the Import slice never writes directly
/// to the Securities domain tables.
/// </para>
/// </summary>
/// <param name="SecurityId">
///     Pre-determined ID: the existing security's ID for updates, or a freshly generated
///     <see cref="Guid"/> for new inserts. Included in <see cref="Application.DTOs.ImportResult"/>
///     so callers receive the ID synchronously while the upsert completes asynchronously.
/// </param>
/// <param name="IsNew">
///     <c>true</c> if a new Security row should be inserted; <c>false</c> if an existing row
///     identified by <paramref name="SecurityId"/> should be updated.
/// </param>
public record ImportCompletedEvent(
    Guid SecurityId,
    bool IsNew,
    IdentifierType IdentifierType,
    string IdentifierValue,
    ExternalSecurityData Data,
    string ContentHash,
    string? UserId);
