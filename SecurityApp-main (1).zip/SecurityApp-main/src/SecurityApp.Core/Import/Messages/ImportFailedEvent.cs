﻿using SecurityApp.Core.Securities.Enums;


namespace SecurityApp.Core.Import.Messages;

/// <summary>
/// Published when a security import fails with a transient exception so that
/// ImportRetryConsumer can re-attempt the operation with exponential back-off.
/// </summary>
public record ImportFailedEvent(
    Guid ImportRequestId,
    string IdentifierValue,
    IdentifierType IdentifierType,
    string? ProviderName,
    string? UserId,
    int AttemptNumber);
