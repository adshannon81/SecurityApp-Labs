namespace SecurityApp.Core.FieldVisibility;

public interface IFieldVisibilityRuleRepository
{
    Task<IReadOnlyList<FieldVisibilityRule>> GetAllAsync(CancellationToken ct = default);
    Task<IReadOnlyList<FieldVisibilityRule>> GetByFieldIdAsync(Guid fieldId, CancellationToken ct = default);
    Task<FieldVisibilityRule?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<FieldVisibilityRule> CreateAsync(FieldVisibilityRule rule, CancellationToken ct = default);
    Task<FieldVisibilityRule> UpdateAsync(FieldVisibilityRule rule, CancellationToken ct = default);
    Task DeleteAsync(Guid id, CancellationToken ct = default);
}
