using SecurityApp.Core.Shared;

namespace SecurityApp.Core.FieldVisibility;

public class FieldGroupMember : TemporalEntity
{
    public Guid FieldGroupId { get; set; }

    public Guid FieldVisibilityFieldId { get; set; }

    public FieldGroup? Group { get; set; }

    public FieldVisibilityField? Field { get; set; }
}
