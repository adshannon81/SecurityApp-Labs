namespace SecurityApp.Core.FieldVisibility.Enums;

public enum ObfuscationType
{
    /// <summary>No obfuscation — used when Visibility = Full.</summary>
    None,

    /// <summary>Masks a local part and domain: john.doe@company.com → j***.d**@c******.com</summary>
    Email,

    /// <summary>Keeps the first 3 characters and masks the rest: SomeValue → Som*****</summary>
    Text,

    /// <summary>Keeps first letter of each word: John Smith → J*** S****</summary>
    Name,

    /// <summary>Keeps the year, masks day/month: 2024-01-15 → 2024-**-**</summary>
    Date,

    /// <summary>Replaces numeric value with ***</summary>
    Number,
}
