namespace SecurityApp.Core.FieldVisibility.Enums;

public enum FieldVisibility
{
    /// <summary>The field value is returned as-is.</summary>
    Full,

    /// <summary>The field value is obfuscated before being returned.</summary>
    Obfuscated,
}
