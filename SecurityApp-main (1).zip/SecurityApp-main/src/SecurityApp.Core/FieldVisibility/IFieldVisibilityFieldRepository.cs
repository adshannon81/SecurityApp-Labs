namespace SecurityApp.Core.FieldVisibility;

public interface IFieldVisibilityFieldRepository
{
    Task<IReadOnlyList<FieldVisibilityField>> GetAllAsync(CancellationToken ct = default);
    Task<IReadOnlyList<FieldVisibilityField>> GetByEntityIdAsync(Guid entityId, CancellationToken ct = default);
    Task<FieldVisibilityField?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<FieldVisibilityField> CreateAsync(FieldVisibilityField field, CancellationToken ct = default);
    Task<FieldVisibilityField> UpdateAsync(FieldVisibilityField field, CancellationToken ct = default);
    Task DeleteAsync(Guid id, CancellationToken ct = default);
}
