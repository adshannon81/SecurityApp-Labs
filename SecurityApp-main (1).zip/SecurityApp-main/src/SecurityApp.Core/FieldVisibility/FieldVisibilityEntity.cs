using SecurityApp.Core.Shared;

namespace SecurityApp.Core.FieldVisibility;

/// <summary>
/// Represents a DTO or response model type whose fields can be controlled
/// by visibility rules. Example: "SecurityDto", "PriceDto".
/// </summary>
public class FieldVisibilityEntity : TemporalEntity
{
    /// <summary>Class name of the DTO, e.g. "SecurityDto".</summary>
    public string EntityType { get; set; } = string.Empty;

    public string DisplayName { get; set; } = string.Empty;

    public string? Description { get; set; }

    public new bool IsActive { get; set; } = true;

    public ICollection<FieldVisibilityField> Fields { get; set; } = [];
}
