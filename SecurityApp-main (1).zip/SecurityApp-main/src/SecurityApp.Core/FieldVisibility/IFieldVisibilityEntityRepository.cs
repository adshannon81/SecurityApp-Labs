namespace SecurityApp.Core.FieldVisibility;

public interface IFieldVisibilityEntityRepository
{
    Task<IReadOnlyList<FieldVisibilityEntity>> GetAllAsync(CancellationToken ct = default);
    Task<FieldVisibilityEntity?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<FieldVisibilityEntity> CreateAsync(FieldVisibilityEntity entity, CancellationToken ct = default);
    Task<FieldVisibilityEntity> UpdateAsync(FieldVisibilityEntity entity, CancellationToken ct = default);
    Task DeleteAsync(Guid id, CancellationToken ct = default);
}
