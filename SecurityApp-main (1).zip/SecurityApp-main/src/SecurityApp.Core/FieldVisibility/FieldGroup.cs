using SecurityApp.Core.Shared;

namespace SecurityApp.Core.FieldVisibility;

public class FieldGroup : TemporalEntity
{
    public Guid FieldVisibilityEntityId { get; set; }

    public string GroupKey { get; set; } = string.Empty;

    public string DisplayName { get; set; } = string.Empty;

    public string? Description { get; set; }

    public int SortOrder { get; set; }

    public new bool IsActive { get; set; } = true;

    public FieldVisibilityEntity? Entity { get; set; }

    public ICollection<FieldGroupMember> Members { get; set; } = [];
}
