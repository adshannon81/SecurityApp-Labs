using SecurityApp.Core.Shared;

namespace SecurityApp.Core.FieldVisibility;

/// <summary>
/// A field on a tracked DTO entity. Stores metadata (display name, data type,
/// sensitivity level, default visibility) and owns the visibility rules for that field.
/// </summary>
public class FieldVisibilityField : TemporalEntity
{
    public Guid FieldVisibilityEntityId { get; set; }

    public FieldVisibilityEntity? Entity { get; set; }

    /// <summary>C# property name (case-sensitive), e.g. "ModifiedBy".</summary>
    public string FieldName { get; set; } = string.Empty;

    public string DisplayName { get; set; } = string.Empty;

    /// <summary>Optional hint, e.g. "string", "decimal", "DateTime".</summary>
    public string? DataType { get; set; }

    /// <summary>Descriptive sensitivity note, e.g. "PII", "Internal", "Confidential".</summary>
    public string? SensitivityLevel { get; set; }

    /// <summary>Default state when no rule matches — hidden by default for sensitive fields.</summary>
    public string DefaultVisibilityState { get; set; } = "HIDDEN";

    public string DefaultObfuscationType { get; set; } = "NONE";

    public int SortOrder { get; set; }

    public new bool IsActive { get; set; } = true;

    public ICollection<FieldVisibilityRule> Rules { get; set; } = [];
}
