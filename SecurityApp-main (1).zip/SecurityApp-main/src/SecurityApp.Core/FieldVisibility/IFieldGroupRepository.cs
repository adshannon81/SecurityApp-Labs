namespace SecurityApp.Core.FieldVisibility;

public interface IFieldGroupRepository
{
    Task<IReadOnlyList<FieldGroup>> GetAllAsync(CancellationToken ct = default);
    Task<IReadOnlyList<FieldGroup>> GetByEntityAsync(Guid entityId, CancellationToken ct = default);
    Task<FieldGroup?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<FieldGroup?> GetWithMembersAsync(Guid id, CancellationToken ct = default);
    Task<IReadOnlyList<FieldGroupMember>> GetMembersAsync(Guid groupId, CancellationToken ct = default);
    Task<FieldGroup> CreateAsync(FieldGroup group, CancellationToken ct = default);
    Task<FieldGroup> UpdateAsync(FieldGroup group, CancellationToken ct = default);
    Task DeleteAsync(Guid id, CancellationToken ct = default);
    Task<FieldGroupMember> AddMemberAsync(FieldGroupMember member, CancellationToken ct = default);
    Task RemoveMemberAsync(Guid memberId, CancellationToken ct = default);
}
