using SecurityApp.Core.FieldVisibility.Enums;
using SecurityApp.Core.Permissions;
using SecurityApp.Core.Shared;
using FieldVisibilityValue = SecurityApp.Core.FieldVisibility.Enums.FieldVisibility;

namespace SecurityApp.Core.FieldVisibility;

/// <summary>
/// A single tier in the field-visibility rule chain.
///
/// Rules are owned by a <see cref="FieldVisibilityField"/>; entity type and field name
/// are resolved via navigation (Field → Entity) rather than stored redundantly here.
///
/// For each field the serializer checks all active rules ordered by Priority descending
/// and applies the first one whose RequiredPermission is present in the caller's JWT.
///
/// If no rule matches, the field default visibility is applied.
/// Extends TemporalEntity so the full audit + validity history is preserved.
/// </summary>
public class FieldVisibilityRule : TemporalEntity
{
    /// <summary>FK to the field this rule governs.</summary>
    public Guid FieldVisibilityFieldId { get; set; }

    public FieldVisibilityField? Field { get; set; }

    public Guid PermissionDefinitionId { get; set; }

    public PermissionDefinition PermissionDefinition { get; set; } = null!;

    /// <summary>What to do when the caller has this permission: VISIBLE, HIDDEN, DISABLED, OBFUSCATED.</summary>
    public string VisibilityState { get; set; } = "HIDDEN";

    /// <summary>Which obfuscation strategy to apply when Visibility = Obfuscated.</summary>
    public ObfuscationType ObfuscationType { get; set; }

    /// <summary>Higher priority rules are evaluated first.</summary>
    public int Priority { get; set; }

    /// <summary>When false the rule is excluded from the serialization cache.</summary>
    public new bool IsActive { get; set; } = true;

    public DateTime? EffectiveFrom { get; set; }
    public DateTime? EffectiveTo  { get; set; }

}
