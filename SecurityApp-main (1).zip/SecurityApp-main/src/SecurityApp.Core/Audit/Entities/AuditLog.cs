﻿using SecurityApp.Core.Shared;
using SecurityApp.Core.Audit.Enums;


namespace SecurityApp.Core.Audit.Entities;

/// <summary>
/// Unified audit log covering all system activities.
/// Replaces the former IAuditService (manual) and RatingAuditLog (pipeline-specific).
/// MiFID II / SOX / FINRA: captures who, what, when, old-value, new-value, changed fields,
/// correlation ID, and whether the change came from an HTTP request or an internal process.
/// </summary>
public class AuditLog : BaseEntity
{
    public string EntityType { get; set; } = string.Empty;
    public AuditAction Action { get; set; }
    public Guid? UserId { get; set; }
    public string? UserName { get; set; }
    public string? Details { get; set; } // JSON format with action details
    public string? IpAddress { get; set; }
    public Guid? EntityId { get; set; }

    /// <summary>JSON snapshot of the entity state before the change (null for inserts).</summary>
    public string? BeforeState { get; set; }

    /// <summary>JSON snapshot of the entity state after the change (null for deletes).</summary>
    public string? AfterState { get; set; }

    /// <summary>JSON array of per-field diffs: [{"field":"name","before":"old","after":"new"}] (Modified only).</summary>
    public string? ChangedFields { get; set; }

    /// <summary>X-Correlation-Id propagated from CorrelationIdMiddleware.</summary>
    public Guid? CorrelationId { get; set; }

    /// <summary>ID of the command/event that caused this change (set by message handlers).</summary>
    public Guid? CausationId { get; set; }

    /// <summary>"Http" for web-request changes, "Job" for background jobs, "System" otherwise.</summary>
    public string Source { get; set; } = "Http";
}
