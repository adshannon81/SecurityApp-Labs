﻿namespace SecurityApp.Core.Audit.Enums;

/// <summary>
/// Type of audit action performed
/// </summary>
public enum AuditAction
{
    Create,
    Update,
    Delete,
    Import,
    Export,
    Login,
    Logout,
    PriceCalculation,
    ConfigurationChange,
    PluginLoaded,
    PluginUnloaded,
    Other
}
