namespace SecurityApp.Core.GoldenSource.Entities;

/// <summary>
/// Append-only audit record written by <c>GoldenSourceResolver</c> each time
/// a winning field value is selected across competing vendor snapshots.
///
/// Mapped to <c>dbo.data_lineage_event</c>.  No TemporalEntity columns — every
/// row is an immutable historical fact.
/// </summary>
public class DataLineageEvent
{
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>Security this lineage record belongs to.</summary>
    public Guid SecurityId { get; set; }

    /// <summary>Dot-notated field name, e.g. "Price.Close", "Name", "ISIN".</summary>
    public string FieldName { get; set; } = string.Empty;

    /// <summary>The resolved (winning) value stored as a string.</summary>
    public string? FieldValue { get; set; }

    /// <summary>
    /// Why this row was written: VENDOR | MANUAL_OVERRIDE | SYSTEM_DEFAULT | DERIVED.
    /// </summary>
    public string SourceType { get; set; } = "VENDOR";

    /// <summary>FK to the vendor that supplied the winning value.  Null for MANUAL / SYSTEM.</summary>
    public Guid? VendorSourceId { get; set; }

    /// <summary>Batch / snapshot identifier from the vendor feed.</summary>
    public string? FeedBatchId { get; set; }

    /// <summary>
    /// Short label describing which resolution rule produced this outcome,
    /// e.g. "FIELD_PRIORITY(Bloomberg, Price.Close, EQUITY)" or "GLOBAL_PRIORITY".
    /// </summary>
    public string? ResolutionRule { get; set; }

    /// <summary>FK to the second-place vendor.  Used to detect subsequent divergence.</summary>
    public Guid? RunnerUpVendorId { get; set; }

    /// <summary>Runner-up's value at the time of resolution.</summary>
    public string? RunnerUpValue { get; set; }

    /// <summary>Who initiated a MANUAL_OVERRIDE (Keycloak subject / preferred_username).</summary>
    public string? OverrideUserId { get; set; }

    /// <summary>Free-text reason supplied for a MANUAL_OVERRIDE.</summary>
    public string? OverrideReason { get; set; }

    /// <summary>When the resolution took place (UTC).</summary>
    public DateTime ResolvedAt { get; set; } = DateTime.UtcNow;

    /// <summary>Row-insert timestamp (UTC).</summary>
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
