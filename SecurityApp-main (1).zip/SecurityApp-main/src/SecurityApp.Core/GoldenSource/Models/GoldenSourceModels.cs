namespace SecurityApp.Core.GoldenSource.Models;

/// <summary>
/// A set of field values provided by one vendor for one security.
/// </summary>
public class VendorSnapshot
{
    /// <summary>FK to <c>dbo.vendor_source</c>.</summary>
    public Guid VendorSourceId { get; set; }

    public string VendorCode { get; set; } = string.Empty;

    public int GlobalPriority { get; set; }

    /// <summary>Batch or feed reference from the source system.</summary>
    public string? FeedBatchId { get; set; }

    /// <summary>
    /// Field name → string-serialised value.
    /// Keys use the canonical dot-notated names, e.g. "Price.Close", "Name".
    /// </summary>
    public Dictionary<string, string?> Fields { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

/// <summary>
/// The resolved golden dataset for a security: one winning value per field,
/// plus the lineage events that were written.
/// </summary>
public class GoldenSecurityData
{
    public Guid SecurityId { get; set; }

    /// <summary>Field name → resolved winning value.</summary>
    public Dictionary<string, string?> Fields { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>The lineage events written during this resolution run.</summary>
    public IReadOnlyList<GoldenSource.Entities.DataLineageEvent> LineageEvents { get; set; } = [];
}
