namespace SecurityApp.Core.GoldenSource;

/// <summary>
/// Selects the winning ("golden") price for a security per price-type by arbitrating
/// across prices from all vendor sources using <c>vendor_source.global_priority</c>.
/// Marks the winner <c>IsGolden = true</c>, marks any previously golden price as no
/// longer golden, and writes a <c>data_lineage_event</c> row for each resolved field.
/// </summary>
public interface IGoldenPriceResolver
{
    /// <summary>
    /// Resolves the golden price for a security.
    /// Persists <c>IsGolden</c> / <c>IsStale</c> flags and lineage events.
    /// </summary>
    /// <param name="securityId">The security to resolve prices for.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    Task ResolveAsync(Guid securityId, CancellationToken cancellationToken = default);
}
