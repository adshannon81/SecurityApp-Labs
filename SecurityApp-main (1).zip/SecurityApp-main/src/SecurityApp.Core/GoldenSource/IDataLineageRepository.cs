using SecurityApp.Core.GoldenSource.Entities;

namespace SecurityApp.Core.GoldenSource;

/// <summary>
/// Read/write repository for <see cref="DataLineageEvent"/> rows.
/// All writes are INSERT-only (no UPDATE / DELETE — append-only table).
/// </summary>
public interface IDataLineageRepository
{
    /// <summary>Returns all lineage events for a security, newest first.</summary>
    Task<IReadOnlyList<DataLineageEvent>> GetBySecurityIdAsync(
        Guid securityId,
        CancellationToken ct = default);

    /// <summary>
    /// Returns the latest resolved event per field for a security.
    /// Useful for rendering a "current golden source" summary per field.
    /// </summary>
    Task<IReadOnlyList<DataLineageEvent>> GetLatestPerFieldAsync(
        Guid securityId,
        CancellationToken ct = default);

    /// <summary>Inserts a new lineage event row.</summary>
    Task AddAsync(DataLineageEvent evt, CancellationToken ct = default);

    /// <summary>Bulk-inserts multiple lineage events in one round-trip.</summary>
    Task AddRangeAsync(IEnumerable<DataLineageEvent> events, CancellationToken ct = default);
}
