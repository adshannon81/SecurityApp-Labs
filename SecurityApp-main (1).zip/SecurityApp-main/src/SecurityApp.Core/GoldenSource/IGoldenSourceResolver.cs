using SecurityApp.Core.GoldenSource.Entities;
using SecurityApp.Core.GoldenSource.Models;

namespace SecurityApp.Core.GoldenSource;

/// <summary>
/// Resolves the "golden" (winning) value for each field of a security
/// by arbitrating across competing vendor snapshots.
///
/// Algorithm (in priority order):
///   1. If a MANUAL_OVERRIDE lineage event exists for this field, use it.
///   2. Look up <c>vendor_field_priority</c> rows for (field, asset_class) — take the vendor
///      with the lowest <c>Priority</c> number among those whose snapshot has a non-null value.
///   3. If no field-level override exists, fall back to <c>vendor_source.global_priority</c>.
///   4. If no vendor data at all, write a SYSTEM_DEFAULT event and return null.
/// </summary>
public interface IGoldenSourceResolver
{
    /// <summary>
    /// Resolves all fields for the given security from the provided vendor snapshots,
    /// writes <see cref="DataLineageEvent"/> rows for each resolved field, and returns
    /// the resolved golden data.
    /// </summary>
    Task<GoldenSecurityData> ResolveAsync(
        Guid securityId,
        string assetClassCode,
        IReadOnlyList<VendorSnapshot> vendorSnapshots,
        CancellationToken ct = default);
}
