namespace SecurityApp.Core.DeadLetters;

public static class DeadLetterStatus
{
    public const string Pending   = "PENDING";
    public const string InReview  = "IN_REVIEW";
    public const string Replayed  = "REPLAYED";
    public const string Resolved  = "RESOLVED";
    public const string Discarded = "DISCARDED";
}

public static class DeadLetterFailureStage
{
    public const int Unknown   = 0;
    public const int Schema    = 1;
    public const int Domain    = 2;
    public const int Business  = 3;
    public const int Transport = 4;
    public const int Timeout   = 5;
}
