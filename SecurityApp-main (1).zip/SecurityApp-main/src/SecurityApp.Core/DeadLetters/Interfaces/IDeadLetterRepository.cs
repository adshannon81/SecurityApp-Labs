using SecurityApp.Core.DeadLetters.Entities;

namespace SecurityApp.Core.DeadLetters.Interfaces;

public interface IDeadLetterRepository
{
    Task<(IReadOnlyList<DeadLetterEvent> Items, int TotalCount)> GetPagedAsync(
        int pageNumber, int pageSize,
        string? status, string? eventType,
        CancellationToken ct = default);

    Task<DeadLetterEvent?> FindAsync(Guid id, CancellationToken ct = default);

    Task CreateAsync(DeadLetterEvent entry, CancellationToken ct = default);

    Task MarkInReviewAsync(Guid id, string modifiedBy, CancellationToken ct = default);

    Task MarkReplayedAsync(Guid id, string modifiedBy, CancellationToken ct = default);

    Task MarkResolvedAsync(Guid id, string resolvedBy, string? notes, CancellationToken ct = default);

    Task MarkDiscardedAsync(Guid id, string resolvedBy, string? notes, CancellationToken ct = default);
}
