namespace SecurityApp.Core.DeadLetters.Entities;

/// <summary>
/// Represents a message that could not be processed after exhausting all retries.
/// Not a TemporalEntity — each row is an audit record with its own lifecycle.
/// </summary>
public class DeadLetterEvent
{
    public Guid    Id              { get; set; }
    public string  EventType       { get; set; } = string.Empty;
    public Guid    CorrelationId   { get; set; }
    public string? IdempotencyKey  { get; set; }
    public string  Payload         { get; set; } = string.Empty;
    public string  FailureReason   { get; set; } = string.Empty;
    public int     FailureStage    { get; set; } = DeadLetterFailureStage.Unknown;
    public int     RetryCount      { get; set; }
    public string  Status          { get; set; } = DeadLetterStatus.Pending;
    public string? ResolvedBy      { get; set; }
    public DateTime? ResolvedAt    { get; set; }
    public string? ResolutionNotes { get; set; }
    public DateTime  CreatedAt       { get; set; } = DateTime.UtcNow;
    public DateTime? LastModifiedAt  { get; set; }
    public string?   LastModifiedBy  { get; set; }
}
