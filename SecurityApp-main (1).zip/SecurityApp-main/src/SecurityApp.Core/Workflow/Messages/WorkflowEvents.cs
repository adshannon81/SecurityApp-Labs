﻿using SecurityApp.Core.Workflow.Enums;


namespace SecurityApp.Core.Workflow.Messages;

/// <summary>Published when a workflow instance is created and active.</summary>
public record WorkflowTriggeredEvent(
    Guid InstanceId,
    WorkflowTriggerType TriggerType,
    string EntityType,
    Guid EntityId,
    string TriggeredBy);

/// <summary>Published when a human submits any decision on a step.</summary>
public record WorkflowStepDecisionEvent(
    Guid InstanceId,
    int StepOrder,
    string DecisionBy,
    WorkflowDecision Decision);

/// <summary>
/// Command published by the engine to drive automated step execution via the bus.
/// Wolverine routes this to WorkflowStepActivatedHandler for retry-capable processing.
/// </summary>
public record WorkflowStepActivatedCommand(Guid InstanceId, int StepOrder);

/// <summary>Fire-and-forget notification dispatched by the engine for Notification steps.</summary>
public record WorkflowNotificationCommand(
    Guid InstanceId,
    Guid StepInstanceId,
    string ActionConfigJson);

/// <summary>HTTP webhook call dispatched to an external URL; retried by Wolverine on failure.</summary>
public record WorkflowWebhookCommand(
    Guid InstanceId,
    Guid StepInstanceId,
    string ActionConfigJson,
    string PayloadJson);

/// <summary>
/// Scheduled by the engine when an Approval or Wait step opens.
/// Delivered after TimeoutHours via Wolverine's delayed dispatch (same pattern as the old
/// ScheduledApprovalExpiryCommand). The handler no-ops if the step is already decided.
/// </summary>
public record WorkflowStepTimeoutCommand(
    Guid InstanceId,
    Guid StepInstanceId,
    int StepOrder);

/// <summary>Published when a workflow reaches any terminal state (Approved/Rejected/Expired/Cancelled).</summary>
public record WorkflowCompletedEvent(
    Guid InstanceId,
    WorkflowStatus FinalStatus,
    string CompletedBy);
