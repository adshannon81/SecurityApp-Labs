﻿namespace SecurityApp.Core.Workflow.Enums;

public enum WorkflowTriggerType
{
    Export,
    Import,
    SecurityInsert,
    SecurityUpdate,
    SecurityDelete,
    CreditRatingUpdate,
    PricingRuleChange,
    PriceOverride,
    JobScheduleChange,
    Any
}
