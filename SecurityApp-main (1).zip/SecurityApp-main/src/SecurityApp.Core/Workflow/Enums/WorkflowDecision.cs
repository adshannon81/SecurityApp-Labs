﻿namespace SecurityApp.Core.Workflow.Enums;

public enum WorkflowDecision
{
    /// <summary>Positive vote; step advances when RequiredApprovals is reached.</summary>
    Approved,
    /// <summary>Notes required; entire instance moves to Rejected.</summary>
    Rejected,
    /// <summary>Notes + target step required; reopens a previous step.</summary>
    SentBack,
    /// <summary>Admin-only; notes + target step required; skips forward to a future step.</summary>
    Advanced,
    /// <summary>System-generated when timeout_action = Escalate.</summary>
    Escalated,
    /// <summary>Informational comment; no status change.</summary>
    Noted
}
