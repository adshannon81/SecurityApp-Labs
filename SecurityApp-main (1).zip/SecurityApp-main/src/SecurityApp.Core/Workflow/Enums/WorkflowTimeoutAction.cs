﻿namespace SecurityApp.Core.Workflow.Enums;

public enum WorkflowTimeoutAction
{
    /// <summary>Mark the step as Expired and terminate the workflow instance.</summary>
    Expire,
    /// <summary>Skip the step and advance to the next one.</summary>
    Skip,
    /// <summary>Re-assign to EscalateToRole and keep the step Pending.</summary>
    Escalate
}
