﻿namespace SecurityApp.Core.Workflow.Enums;

public enum WorkflowStatus
{
    Pending,    // at least one step is still active
    Approved,   // all steps completed with Approved
    Rejected,   // a step was rejected
    Expired,    // a step timed out
    Cancelled   // manually cancelled by an admin
}
