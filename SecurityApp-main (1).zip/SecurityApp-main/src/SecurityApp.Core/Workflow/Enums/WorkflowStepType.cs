﻿namespace SecurityApp.Core.Workflow.Enums;

public enum WorkflowStepType
{
    /// <summary>N humans of RequiredRole must approve before advancing.</summary>
    Approval,
    /// <summary>Always passes immediately - audit record + notification only.</summary>
    AutoApprove,
    /// <summary>Evaluates a condition rule; routes on_approved or on_rejected with no human input.</summary>
    Condition,
    /// <summary>Sends a notification to the configured role/channel; never blocks.</summary>
    Notification,
    /// <summary>POSTs payload_json to an external URL; fire-and-forget or wait-for-callback.</summary>
    Webhook,
    /// <summary>Invokes a named IWorkflowAction registered in DI.</summary>
    Script,
    /// <summary>Pauses for N hours then auto-advances.</summary>
    Wait
}
