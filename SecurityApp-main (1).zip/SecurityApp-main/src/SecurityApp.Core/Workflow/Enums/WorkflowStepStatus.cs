﻿namespace SecurityApp.Core.Workflow.Enums;

public enum WorkflowStepStatus
{
    Waiting,    // not yet reached by the engine
    Pending,    // current step, awaiting decisions or timer
    Approved,   // received required approvals / auto-completed
    Rejected,   // rejected by an approver
    Skipped,    // bypassed by condition or advance action
    Expired,    // timed out
    SentBack    // returned to a previous step
}
