﻿using SecurityApp.Core.Workflow.Entities;


namespace SecurityApp.Core.Workflow.Interfaces;

/// <summary>
/// Plugin interface for automated workflow step types.
/// Implement and register with services.AddWorkflowAction&lt;T&gt;() to add a new action
/// without changing the engine.
/// </summary>
public interface IWorkflowAction
{
    /// <summary>
    /// Matches the 'actionName' field in action_config_json, or the step_type string
    /// for well-known built-in types (e.g. "AutoApprove", "Condition").
    /// </summary>
    string ActionName { get; }

    /// <summary>
    /// Execute the action. Returning Success=true follows the OnApproved route;
    /// Success=false follows the OnRejected route.
    /// </summary>
    Task<WorkflowActionResult> ExecuteAsync(
        WorkflowStepInstance step,
        WorkflowInstance instance,
        CancellationToken ct);
}

/// <summary>Result returned by an IWorkflowAction execution.</summary>
public record WorkflowActionResult(
    bool Success,
    string? Notes = null,
    /// <summary>When set, the engine uses this step order instead of the definition's routing.</summary>
    int? OverrideNextStep = null
);
