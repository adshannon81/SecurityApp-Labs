﻿using SecurityApp.Core.Workflow.Entities;
using SecurityApp.Core.Shared.Interfaces;


namespace SecurityApp.Core.Workflow.Interfaces;

/// <summary>
/// Narrow unit-of-work interface scoped to the Workflow bounded context.
/// Inject this instead of <see cref="IUnitOfWork"/> in any class that only needs
/// workflow definitions, instances, steps or approvals.
/// </summary>
public interface IWorkflowUoW
{
    IRepository<WorkflowDefinition> WorkflowDefinitions { get; }
    IRepository<WorkflowDefinitionStep> WorkflowDefinitionSteps { get; }
    IRepository<WorkflowInstance> WorkflowInstances { get; }
    IRepository<WorkflowStepInstance> WorkflowStepInstances { get; }
    IRepository<WorkflowStepApproval> WorkflowStepApprovals { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    Task BeginTransactionAsync(CancellationToken cancellationToken = default);
    Task CommitTransactionAsync(CancellationToken cancellationToken = default);
    Task RollbackTransactionAsync(CancellationToken cancellationToken = default);
}
