﻿using SecurityApp.Core.Workflow.Enums;
using SecurityApp.Core.Workflow.Entities;


namespace SecurityApp.Core.Workflow.Interfaces;

/// <summary>
/// Core workflow engine. Drives trigger evaluation, automated step execution,
/// human decision processing, and step routing.
/// </summary>
public interface IWorkflowEngine
{
    /// <summary>
    /// Evaluates whether a workflow definition matches the trigger and payload, creates a
    /// WorkflowInstance, and runs all automated steps until the first Approval/Wait step or
    /// terminal state. Returns immediately with Status=Approved if no definition matches.
    /// </summary>
    Task<WorkflowInstance> TriggerAsync(
        WorkflowTriggerType trigger,
        string entityType,
        Guid entityId,
        object payload,
        string triggeredBy,
        CancellationToken ct = default);

    /// <summary>Returns the active (Pending) blocking instance for this entity, or null.</summary>
    Task<WorkflowInstance?> GetActiveGateAsync(
        WorkflowTriggerType trigger,
        Guid entityId,
        CancellationToken ct = default);

    /// <summary>
    /// Submits a human decision on the current step.
    /// The engine validates that the submitter holds the required role.
    /// </summary>
    Task<WorkflowStepInstance> SubmitDecisionAsync(
        Guid instanceId,
        int stepOrder,
        string decisionBy,
        string userRole,
        WorkflowDecision decision,
        string? notes,
        int? targetStepOrder,
        CancellationToken ct = default);

    /// <summary>Returns all Pending step instances for the specified role.</summary>
    Task<IEnumerable<WorkflowStepInstance>> GetPendingForRoleAsync(
        string role,
        CancellationToken ct = default);

    /// <summary>Admin cancels an entire workflow instance.</summary>
    Task CancelAsync(
        Guid instanceId,
        string cancelledBy,
        string notes,
        CancellationToken ct = default);

    /// <summary>
    /// Called by WorkflowStepTimeoutHandler when a scheduled timeout fires.
    /// No-ops if the step is no longer Pending (already decided by a human).
    /// </summary>
    Task HandleStepTimeoutAsync(
        Guid instanceId,
        Guid stepInstanceId,
        int stepOrder,
        CancellationToken ct = default);
}
