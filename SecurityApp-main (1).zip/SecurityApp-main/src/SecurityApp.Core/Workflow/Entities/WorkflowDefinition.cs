﻿using SecurityApp.Core.Shared;
using SecurityApp.Core.Workflow.Enums;


namespace SecurityApp.Core.Workflow.Entities;

/// <summary>
/// Named, DB-managed workflow template. Admins create/update definitions without deployment.
/// Extends TemporalEntity so every change to the definition is preserved as history.
/// </summary>
public class WorkflowDefinition : TemporalEntity
{
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public WorkflowTriggerType TriggerType { get; set; }
    public bool IsEnabled { get; set; } = true;

    /// <summary>
    /// Optional JsonLogic condition evaluated against the trigger payload.
    /// When null/empty the definition applies to all payloads of the given trigger type.
    /// </summary>
    public string? ConditionJson { get; set; }

    public ICollection<WorkflowDefinitionStep> Steps { get; set; } = [];
}
