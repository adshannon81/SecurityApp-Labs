﻿using SecurityApp.Core.Shared;
using SecurityApp.Core.Workflow.Enums;


namespace SecurityApp.Core.Workflow.Entities;

/// <summary>
/// One ordered step within a WorkflowDefinition.
/// Non-temporal: step changes are versioned via the parent definition's temporal rows.
/// </summary>
public class WorkflowDefinitionStep : BaseEntity
{
    public Guid DefinitionId { get; set; }
    public int StepOrder { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public WorkflowStepType StepType { get; set; }

    // -- Approval fields ------------------------------------------------------
    /// <summary>ASP.NET role name required to action this step (e.g. "Compliance", "Risk").</summary>
    public string? RequiredRole { get; set; }
    /// <summary>Number of distinct approvals required before the step advances (1 = single, 2 = dual control).</summary>
    public int RequiredApprovals { get; set; } = 1;

    // -- Timeout & escalation -------------------------------------------------
    public int TimeoutHours { get; set; } = 48;
    public WorkflowTimeoutAction TimeoutAction { get; set; } = WorkflowTimeoutAction.Expire;
    /// <summary>Role to reassign the step to when TimeoutAction = Escalate.</summary>
    public string? EscalateToRole { get; set; }

    // -- Transition routing ---------------------------------------------------
    /// <summary>Step order to jump to on success; null = next in sequence.</summary>
    public int? OnApprovedGotoStep { get; set; }
    /// <summary>Step order to jump to on rejection; null = terminal Rejected.</summary>
    public int? OnRejectedGotoStep { get; set; }
    /// <summary>Step order to jump to on timeout; null = honour TimeoutAction.</summary>
    public int? OnTimeoutGotoStep { get; set; }

    // -- Action config --------------------------------------------------------
    /// <summary>
    /// JSON configuration for automated step types.
    /// Notification: { "channels": ["email","inapp"], "templateKey": "...", "recipientRole": "..." }
    /// Webhook:      { "url": "...", "method": "POST", "waitForCallback": false }
    /// Script:       { "actionName": "...", "args": {} }
    /// Condition:    { "field": "...", "operator": "GreaterThan", "value": 10 }
    /// Wait:         { "hours": 2 }
    /// </summary>
    public string? ActionConfigJson { get; set; }
}
