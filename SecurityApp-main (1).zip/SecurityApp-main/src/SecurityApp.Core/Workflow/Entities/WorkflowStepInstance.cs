﻿using SecurityApp.Core.Shared;
using SecurityApp.Core.Workflow.Enums;


namespace SecurityApp.Core.Workflow.Entities;

/// <summary>
/// Live state of one step within a WorkflowInstance.
/// Extends TemporalEntity so every status change (Pending â†’ Approved, SentBack, etc.)
/// is preserved as a history row by TemporalInterceptor automatically.
/// </summary>
public class WorkflowStepInstance : TemporalEntity
{
    public Guid InstanceId { get; set; }
    public int StepOrder { get; set; }
    public WorkflowStepType StepType { get; set; }
    public string? RequiredRole { get; set; }
    public int RequiredApprovals { get; set; } = 1;
    public int ReceivedApprovals { get; set; } = 0;
    public WorkflowStepStatus Status { get; set; } = WorkflowStepStatus.Waiting;
    public DateTime? TimeoutAt { get; set; }
    public string? ReviewedBy { get; set; }
    public DateTime? ReviewedAt { get; set; }
    public string? Notes { get; set; }
}
