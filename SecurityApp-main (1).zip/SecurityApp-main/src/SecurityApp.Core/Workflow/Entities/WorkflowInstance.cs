﻿using SecurityApp.Core.Shared;
using SecurityApp.Core.Workflow.Enums;


namespace SecurityApp.Core.Workflow.Entities;

/// <summary>
/// One live execution of a WorkflowDefinition.
/// Carries a frozen payload snapshot for the approver UI.
/// Extends TemporalEntity so the full status history is preserved.
/// </summary>
public class WorkflowInstance : TemporalEntity
{
    /// <summary>Null when the instance was auto-approved (no matching definition found).</summary>
    public Guid? DefinitionId { get; set; }
    public WorkflowTriggerType TriggerType { get; set; }
    public string EntityType { get; set; } = string.Empty;
    public Guid EntityId { get; set; }
    public WorkflowStatus Status { get; set; } = WorkflowStatus.Pending;
    public int CurrentStepOrder { get; set; } = 1;
    public string TriggeredBy { get; set; } = string.Empty;
    public DateTime TriggeredAt { get; set; } = DateTime.UtcNow;
    public DateTime? CompletedAt { get; set; }

    /// <summary>
    /// Frozen JSON snapshot of the triggering context captured at trigger time.
    /// This is what the approver UI displays.
    /// </summary>
    public string? PayloadJson { get; set; }
}
