﻿using SecurityApp.Core.Shared;
using SecurityApp.Core.Workflow.Enums;


namespace SecurityApp.Core.Workflow.Entities;

/// <summary>
/// Immutable audit record of every action taken on a workflow step.
/// Append-only - never updated after insert (no temporal required).
/// </summary>
public class WorkflowStepApproval : BaseEntity
{
    /// <summary>Parent instance - enables fast full-history queries.</summary>
    public Guid InstanceId { get; set; }

    /// <summary>Null for instance-level actions (e.g. Cancel with no active step).</summary>
    public Guid? StepInstanceId { get; set; }

    public int FromStepOrder { get; set; }

    /// <summary>Filled when Decision is SentBack or Advanced.</summary>
    public int? TargetStepOrder { get; set; }

    public WorkflowDecision Decision { get; set; }
    public string DecisionBy { get; set; } = string.Empty;
    public DateTime DecisionAt { get; set; } = DateTime.UtcNow;

    /// <summary>Required for Rejected, SentBack, Advanced, and Cancel.</summary>
    public string? Notes { get; set; }
}
