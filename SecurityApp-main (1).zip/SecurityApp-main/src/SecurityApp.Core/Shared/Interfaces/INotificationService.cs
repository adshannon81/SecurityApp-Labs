﻿namespace SecurityApp.Core.Shared.Interfaces;

/// <summary>
/// Notification channel abstraction. Implementations fan out to email, webhooks, etc.
/// NullNotificationService is the default (no channels configured).
/// </summary>
public interface INotificationService
{
    Task SendJobFailureAsync(string jobName, string errorMessage, CancellationToken ct = default);
    Task SendImportDeadLetteredAsync(Guid importRequestId, string identifierValue, int attemptNumber, CancellationToken ct = default);
    Task SendWorkflowNotificationAsync(Guid instanceId, string templateKey, string recipientRole, CancellationToken ct = default);
}
