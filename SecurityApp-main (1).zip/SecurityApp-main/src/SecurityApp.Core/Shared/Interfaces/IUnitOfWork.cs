﻿using SecurityApp.Core.Securities.Entities;
using SecurityApp.Core.Ratings.Entities;
using SecurityApp.Core.Pricing.Entities;
using SecurityApp.Core.Audit.Entities;
using SecurityApp.Core.Import.Entities;
using SecurityApp.Core.Workflow.Entities;
using SecurityApp.Core.Portfolio.Entities;
using PortfolioEntity = SecurityApp.Core.Portfolio.Entities.Portfolio;

namespace SecurityApp.Core.Shared.Interfaces;

/// <summary>
/// Unit of Work pattern for coordinating multiple repository operations
/// </summary>
public interface IUnitOfWork : IDisposable
{
    IRepository<Security> Securities { get; }
    IRepository<SecurityIdentifier>          SecurityIdentifiers           { get; }
    IRepository<SecurityCoreAttribute>       SecurityCoreAttributes       { get; }
    IRepository<SecurityLoanAttribute>        SecurityLoanAttributes        { get; }
    IRepository<SecurityDerivativeAttribute>  SecurityDerivativeAttributes  { get; }
    IRepository<SecuritySecuritizedAttribute> SecuritySecuritizedAttributes { get; }
    IRepository<SecurityAttributeKv>          SecurityAttributeKvs          { get; }
    IRepository<CreditRating> CreditRatings { get; }
    IRepository<Price> Prices { get; }
    IRepository<PricingRule> PricingRules { get; }
    IRepository<DerivedPrice> DerivedPrices { get; }
    IRepository<AuditLog> AuditLogs { get; }
    IRepository<ImportRequest> ImportRequests { get; }
    IRepository<DerivedRating> DerivedRatings { get; }
    IRepository<VendorRatingMetadata> VendorRatingMetadata { get; }
    IRepository<RatingScaleEntry> RatingScaleEntries { get; }
    IRepository<RatingDerivationRule> RatingDerivationRules { get; }
    IRepository<FormulaMacro> FormulaMacros { get; }
    IRepository<ImportProfile> ImportProfiles { get; }
    IRepository<ImportProfileColumn> ImportProfileColumns { get; }
    IRepository<ImportProfileColumnValidation> ImportProfileColumnValidations { get; }
    IRepository<ImportProfileRowValidation> ImportProfileRowValidations { get; }
    IRepository<WorkflowDefinition> WorkflowDefinitions { get; }
    IRepository<WorkflowDefinitionStep> WorkflowDefinitionSteps { get; }
    IRepository<WorkflowInstance> WorkflowInstances { get; }
    IRepository<WorkflowStepInstance> WorkflowStepInstances { get; }
    IRepository<WorkflowStepApproval> WorkflowStepApprovals { get; }
    IRepository<Client>    Clients    { get; }
    IRepository<PortfolioEntity> Portfolios { get; }
    IRepository<Position>  Positions  { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    Task BeginTransactionAsync(CancellationToken cancellationToken = default);
    Task CommitTransactionAsync(CancellationToken cancellationToken = default);
    Task RollbackTransactionAsync(CancellationToken cancellationToken = default);
}
