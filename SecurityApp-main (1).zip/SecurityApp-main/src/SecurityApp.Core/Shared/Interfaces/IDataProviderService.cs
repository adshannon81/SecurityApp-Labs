﻿using SecurityApp.Core.Securities.Interfaces;
using SecurityApp.Core.Pricing.Interfaces;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Securities.Models;
using SecurityApp.Core.Pricing.Models;
using SecurityApp.Core.Plugins.Interfaces;


namespace SecurityApp.Core.Shared.Interfaces;

/// <summary>
/// Facade over all registered security and pricing providers.
/// Application layer uses this to fetch external data without knowing which provider handles the request.
/// </summary>
public interface IDataProviderService
{
    ISecurityDataProvider? GetSecurityProvider(string? providerName = null);
    IPricingDataProvider? GetPricingProvider(string? providerName = null);

    Task<ExternalSecurityData?> GetSecurityAsync(
        string identifierValue,
        IdentifierType identifierType,
        string? providerName = null,
        CancellationToken cancellationToken = default);

    Task<IEnumerable<ExternalSecurityData>> SearchSecuritiesAsync(
        string keyword,
        string? providerName = null,
        CancellationToken cancellationToken = default);

    Task<ExternalPriceData?> GetCurrentPriceAsync(
        string symbol,
        string? providerName = null,
        CancellationToken cancellationToken = default);

    Task<IEnumerable<ExternalPriceData>> GetHistoricalPricesAsync(
        string symbol,
        DateTime fromDate,
        DateTime toDate,
        string? providerName = null,
        CancellationToken cancellationToken = default);

    IEnumerable<string> GetAvailableSecurityProviders();
    IEnumerable<string> GetAvailablePricingProviders();

    /// <summary>
    /// Returns health status for every enabled connector, deduplicating connectors that implement
    /// both ISecurityDataProvider and IPricingDataProvider.
    /// </summary>
    Task<IReadOnlyList<ConnectorHealthStatus>> GetAllConnectorHealthAsync(
        CancellationToken cancellationToken = default);
}
