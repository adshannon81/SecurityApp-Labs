﻿namespace SecurityApp.Core.Shared.Interfaces;

/// <summary>
/// Transport-agnostic event bus. IEventBus callers are unaware of whether the
/// backing transport is RabbitMQ, Azure Service Bus, SQS, or in-memory (tests).
/// The single registration swap in Program.cs / WolverineExtensions is sufficient
/// to change transport without touching any handler or consumer.
/// </summary>
public interface IEventBus
{
    /// <summary>Publish to all interested subscribers (1-to-many, fire-and-forget).</summary>
    Task PublishAsync<T>(T message, CancellationToken ct = default) where T : notnull;

    /// <summary>Send to a specific queue / consumer (1-to-1 command-style dispatch).</summary>
    Task SendAsync<T>(T message, CancellationToken ct = default) where T : notnull;

    /// <summary>Schedule a message for delivery after the specified delay.</summary>
    Task ScheduleAsync<T>(T message, TimeSpan delay, CancellationToken ct = default) where T : notnull;
}
