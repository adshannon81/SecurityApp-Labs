﻿namespace SecurityApp.Core.Shared.Interfaces;

public interface ICacheService
{
    Task<T?> GetAsync<T>(string key, CancellationToken ct = default);
    Task SetAsync<T>(string key, T value, TimeSpan? expiry = null, CancellationToken ct = default);
    Task RemoveAsync(string key, CancellationToken ct = default);

    /// <summary>
    /// Removes all keys matching a glob-style pattern.
    /// No-ops silently when using the in-memory fallback (no Redis IConnectionMultiplexer available).
    /// </summary>
    Task RemoveByPatternAsync(string pattern, CancellationToken ct = default);
}
