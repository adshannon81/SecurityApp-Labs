﻿namespace SecurityApp.Core.Shared.Configuration;

/// <summary>Notification channel settings - read from the Notifications section of appsettings.</summary>
public class NotificationOptions
{
    public const string SectionName = "Notifications";

    public EmailNotificationSettings Email { get; set; } = new();
    public WebhookNotificationSettings[] Webhooks { get; set; } = [];
}

public class EmailNotificationSettings
{
    public bool Enabled { get; set; } = false;
    public string SmtpHost { get; set; } = string.Empty;
    public int SmtpPort { get; set; } = 587;
    public bool UseTls { get; set; } = true;
    public string FromAddress { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string[] AdminRecipients { get; set; } = [];
}

public class WebhookNotificationSettings
{
    public string Url { get; set; } = string.Empty;
    /// <summary>Event names this webhook subscribes to ("JobFailure", "ApprovalRequest", "ApprovalDecision", "ImportDeadLettered").</summary>
    public string[] Events { get; set; } = [];
    /// <summary>Optional HMAC-SHA256 signing secret. If omitted the payload is unsigned.</summary>
    public string? Secret { get; set; }
}
