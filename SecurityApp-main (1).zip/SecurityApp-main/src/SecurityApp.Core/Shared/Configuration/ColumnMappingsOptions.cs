﻿using SecurityApp.Core.Import.Models;


namespace SecurityApp.Core.Shared.Configuration;

/// <summary>
/// Root options for export column mapping.
/// Bound from the "ColumnMappings" section in appsettings.json.
/// </summary>
public class ColumnMappingsOptions
{
    public const string SectionName = "ColumnMappings";

    /// <summary>
    /// Named export profiles. Key = profile name (e.g. "Default", "Bloomberg").
    /// When a profile's Columns list is empty all SecurityExportRecord fields are exported.
    /// </summary>
    public Dictionary<string, ExportMappingProfile> Export { get; set; } = new();
}


