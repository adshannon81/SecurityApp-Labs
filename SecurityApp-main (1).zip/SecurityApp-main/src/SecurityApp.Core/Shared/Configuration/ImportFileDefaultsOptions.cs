namespace SecurityApp.Core.Shared.Configuration;

/// <summary>
/// Fallback parse settings used when no import profile is specified.
/// Configured under "Import:FileDefaults" in appsettings.json.
/// </summary>
public class ImportFileDefaultsOptions
{
    public const string SectionName = "Import:FileDefaults";

    /// <summary>Column delimiter character or escape sequence. Default: , (comma).</summary>
    public string Delimiter     { get; set; } = ",";

    /// <summary>Text qualifier character, "none" to disable, or empty for double-quote.</summary>
    public string TextQualifier { get; set; } = "\"";

    /// <summary>Whether the first row is a header row.</summary>
    public bool   HasHeader     { get; set; } = true;

    /// <summary>Number of leading data rows to skip after the header (or from the start when no header).</summary>
    public int    SkipRows      { get; set; } = 0;
}
