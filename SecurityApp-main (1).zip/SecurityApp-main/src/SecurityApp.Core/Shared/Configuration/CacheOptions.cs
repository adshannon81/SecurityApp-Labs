﻿namespace SecurityApp.Core.Shared.Configuration;

public class CacheOptions
{
    public bool   Enabled              { get; set; } = true;
    public int    DefaultExpirySeconds { get; set; } = 300;
    public string InstanceName         { get; set; } = "SecurityApp:";
}
