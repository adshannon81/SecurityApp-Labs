﻿namespace SecurityApp.Core.Shared;

/// <summary>
/// Interface for entities that support bi-temporal tracking
/// Combines business time (ValidFrom/ValidTo) and system time (SystemFrom/SystemTo)
/// </summary>
public interface ITemporalEntity
{
    // Business Time (Valid Time) - When the data is valid in the real world
    /// <summary>
    /// Business effective date - when this record becomes valid in real world
    /// </summary>
    DateTime ValidFrom { get; set; }
    
    /// <summary>
    /// Business expiration date - when this record stops being valid in real world
    /// Set to DateTime.MaxValue for current records
    /// </summary>
    DateTime ValidTo { get; set; }
    
    // System Time (Transaction Time) - When the database recorded the change
    /// <summary>
    /// System time - when this record was inserted/created in database
    /// </summary>
    DateTime SystemFrom { get; set; }
    
    /// <summary>
    /// System time - when this record was superseded/deleted in database
    /// Set to DateTime.MaxValue for current records
    /// </summary>
    DateTime SystemTo { get; set; }
    
    // Tracking Flags
    /// <summary>
    /// True if this is the current active version (ValidTo = MaxValue and SystemTo = MaxValue)
    /// </summary>
    bool IsCurrent { get; set; }
    
    /// <summary>
    /// Soft delete flag - marks record as deleted without physical removal
    /// </summary>
    bool IsDeleted { get; set; }
    
    /// <summary>
    /// User who originally created this record.
    /// </summary>
    string? CreatedBy { get; set; }

    /// <summary>
    /// User who last modified this record (equals CreatedBy on first insert).
    /// </summary>
    string? LastModifiedBy { get; set; }
}
