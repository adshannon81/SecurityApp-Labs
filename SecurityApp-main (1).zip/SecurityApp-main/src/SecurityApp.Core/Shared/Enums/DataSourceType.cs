﻿namespace SecurityApp.Core.Shared.Enums;

/// <summary>
/// External data sources for security and pricing data
/// </summary>
public enum DataSourceType
{
    Bloomberg,
    Markit,
    IDC,
    VPM,
    Reuters,
    Manual,
    FlatFile,
    JsonFile,
    XmlFile,
    Other,
    AlphaVantage
}
