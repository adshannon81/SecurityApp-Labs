﻿namespace SecurityApp.Core.Shared.Exceptions;

/// <summary>
/// Thrown when a requested resource does not exist. Maps to HTTP 404 in the global exception handler.
/// </summary>
public class NotFoundException : Exception
{
    public NotFoundException(string entityName, object key)
        : base($"{entityName} with ID {key} not found") { }

    public NotFoundException(string message)
        : base(message) { }
}
