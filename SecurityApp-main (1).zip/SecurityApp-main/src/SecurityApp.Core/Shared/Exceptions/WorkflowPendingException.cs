using SecurityApp.Core.Workflow.Entities;

namespace SecurityApp.Core.Shared.Exceptions;

/// <summary>
/// Thrown by WorkflowGateBehavior when a command is blocked by a pending workflow instance.
/// Maps to HTTP 202 Accepted in ExceptionHandlingMiddleware.
/// </summary>
public class WorkflowPendingException(WorkflowInstance instance) : Exception(
    $"Action is pending workflow approval (instance {instance.Id}).")
{
    public WorkflowInstance Instance { get; } = instance;
}
