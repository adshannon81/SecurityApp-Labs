namespace SecurityApp.Core.Shared.Exceptions;

/// <summary>
/// Thrown when an optimistic concurrency conflict is detected (the resource was modified
/// by another writer since the client last read it). Maps to HTTP 409 CONCURRENCY_CONFLICT.
/// </summary>
public class ConcurrencyConflictException : Exception
{
    public ConcurrencyConflictException(string entityName, object key)
        : base($"Concurrency conflict: {entityName} with ID {key} was modified by another writer. Re-fetch and retry.") { }

    public ConcurrencyConflictException(string message)
        : base(message) { }
}
