namespace SecurityApp.Core.Shared.Exceptions;

/// <summary>
/// Thrown when a security status transition is not permitted by the lifecycle state machine.
/// Maps to HTTP 422 INVALID_LIFECYCLE_TRANSITION.
/// </summary>
public class InvalidLifecycleTransitionException : Exception
{
    public string FromCode { get; }
    public string ToCode { get; }

    public InvalidLifecycleTransitionException(string fromCode, string toCode)
        : base($"Transition from '{fromCode}' to '{toCode}' is not a permitted lifecycle transition.")
    {
        FromCode = fromCode;
        ToCode   = toCode;
    }
}
