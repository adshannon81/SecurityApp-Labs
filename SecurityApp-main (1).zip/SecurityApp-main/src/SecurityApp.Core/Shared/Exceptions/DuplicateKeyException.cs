namespace SecurityApp.Core.Shared.Exceptions;

/// <summary>
/// Thrown when an attempt is made to create a resource that conflicts with an existing unique key.
/// Maps to HTTP 409 Conflict.
/// </summary>
public class DuplicateKeyException : Exception
{
    public DuplicateKeyException(string message) : base(message) { }
    public DuplicateKeyException(string entityName, string key, object value)
        : base($"A {entityName} with {key} '{value}' already exists.") { }
}
