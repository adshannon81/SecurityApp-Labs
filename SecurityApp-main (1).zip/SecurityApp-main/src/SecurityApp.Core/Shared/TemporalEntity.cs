﻿namespace SecurityApp.Core.Shared;

/// <summary>
/// Base class for temporal entities supporting bi-temporal tracking
/// All temporal tables inherit from this to get automatic history tracking
/// </summary>
public abstract class TemporalEntity : BaseEntity, ITemporalEntity
{
    // Sentinel for "open ended" temporal records – end of day on the last representable date
    private static readonly DateTime MaxSentinel = new DateTime(9999, 12, 31, 23, 59, 59, DateTimeKind.Utc);

    // Business Time (Valid Time) - When data is valid in real world
    public DateTime ValidFrom { get; set; } = DateTime.UtcNow;
    public DateTime ValidTo { get; set; } = MaxSentinel;
    
    // System Time (Transaction Time) - When database recorded the change
    public DateTime SystemFrom { get; set; } = DateTime.UtcNow;
    public DateTime SystemTo { get; set; } = MaxSentinel;
    
    // Tracking Flags
    public bool IsCurrent { get; set; } = true;
    public bool IsDeleted { get; set; } = false;
    // CreatedBy and LastModifiedBy are inherited from BaseEntity
    
    /// <summary>
    /// Check if this record is valid at a specific business date
    /// </summary>
    public bool IsValidAt(DateTime businessDate)
    {
        return ValidFrom <= businessDate && businessDate < ValidTo && !IsDeleted;
    }
    
    /// <summary>
    /// Check if this record existed in the database at a specific system date
    /// </summary>
    public bool ExistedAt(DateTime systemDate)
    {
        return SystemFrom <= systemDate && systemDate < SystemTo;
    }
    
    /// <summary>
    /// Check if this is an active, current record
    /// </summary>
    public bool IsActive()
    {
        return IsCurrent && !IsDeleted && ValidTo == MaxSentinel;
    }
}
