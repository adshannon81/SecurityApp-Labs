using SecurityApp.Core.Issuers.Entities;
using SecurityApp.Core.Shared.Interfaces;

namespace SecurityApp.Core.Issuers.Interfaces;

/// <summary>
/// Narrow unit-of-work interface scoped to the Issuers bounded context.
/// </summary>
public interface IIssuersUoW
{
    IRepository<Issuer>             Issuers              { get; }
    IRepository<IssuerIdentifier>   IssuerIdentifiers    { get; }
    IRepository<IssuerRelationship> IssuerRelationships  { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    Task BeginTransactionAsync(CancellationToken cancellationToken = default);
    Task CommitTransactionAsync(CancellationToken cancellationToken = default);
    Task RollbackTransactionAsync(CancellationToken cancellationToken = default);
}
