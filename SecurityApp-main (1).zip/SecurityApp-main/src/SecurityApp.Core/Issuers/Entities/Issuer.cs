using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Issuers.Entities;

/// <summary>
/// Issuer master entity — represents the legal entity that issues a security.
/// Follows the same BaseEntity + TemporalEntity pattern as all business tables.
/// <para>
/// Ownership/control relationships are stored in <see cref="IssuerRelationship"/>.
/// The <c>DirectAccountingParentIssuerId</c> and <c>UltimateAccountingParentIssuerId</c>
/// columns are optional cache values derived from relationship rows for fast reads.
/// </para>
/// </summary>
public class Issuer : TemporalEntity
{
    public string LegalName { get; set; } = string.Empty;
    public string? DisplayName { get; set; }
    public string? ShortName { get; set; }
    public string? LeiCode { get; set; }
    public string? IssuerType { get; set; }
    public string? CountryAlpha2 { get; set; }
    public bool IsActive { get; set; } = true;

    // ── Optional cached parent references (source of truth = IssuerRelationship) ──
    public Guid? DirectAccountingParentIssuerId { get; set; }
    public Guid? UltimateAccountingParentIssuerId { get; set; }

    public string? ContentHash { get; set; }

    // Navigation properties
    public Issuer? DirectAccountingParent { get; set; }
    public Issuer? UltimateAccountingParent { get; set; }
    public ICollection<IssuerIdentifier>   Identifiers   { get; set; } = new List<IssuerIdentifier>();
    public ICollection<IssuerRelationship> Relationships { get; set; } = new List<IssuerRelationship>();
}
