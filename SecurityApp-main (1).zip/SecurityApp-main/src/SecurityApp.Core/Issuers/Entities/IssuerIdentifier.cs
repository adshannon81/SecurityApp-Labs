using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Issuers.Entities;

/// <summary>
/// External identifier for an issuer (LEI, Bloomberg, S&P issuer ID, etc.).
/// </summary>
public class IssuerIdentifier : TemporalEntity
{
    public Guid IssuerId { get; set; }
    public string IdentifierType { get; set; } = string.Empty;
    public string IdentifierValue { get; set; } = string.Empty;
    public string? SourceSystem { get; set; }
    public bool IsPrimary { get; set; } = false;

    public Issuer Issuer { get; set; } = null!;
}
