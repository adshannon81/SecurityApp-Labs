using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Issuers.Entities;

/// <summary>
/// Represents a typed, temporal relationship between two issuers.
/// This is the source of truth for ownership and control hierarchies.
/// </summary>
public class IssuerRelationship : TemporalEntity
{
    public Guid   ChildIssuerId    { get; set; }
    public Guid   ParentIssuerId   { get; set; }
    public string RelationshipType { get; set; } = string.Empty;

    /// <summary>Percentage of the child owned/controlled by the parent, if known.</summary>
    public decimal? OwnershipPercent { get; set; }

    /// <summary>Basis of control, e.g. MAJORITY_VOTING, CONSOLIDATION, CONTRACTUAL_CONTROL.</summary>
    public string? ControlBasis { get; set; }

    /// <summary>Which external system provided this relationship row.</summary>
    public string? SourceSystem { get; set; }

    /// <summary>External reference ID in the source system.</summary>
    public string? SourceReference { get; set; }

    /// <summary>Whether this is the primary relationship of this type for the child.</summary>
    public bool IsPrimary { get; set; }

    public string? Notes { get; set; }

    // Navigation properties
    public Issuer? ChildIssuer  { get; set; }
    public Issuer? ParentIssuer { get; set; }
}

/// <summary>Well-known relationship type constants.</summary>
public static class IssuerRelationshipTypes
{
    public const string AccountingDirectParent   = "ACCOUNTING_DIRECT_PARENT";
    public const string AccountingUltimateParent = "ACCOUNTING_ULTIMATE_PARENT";
    public const string OwnershipParent          = "OWNERSHIP_PARENT";
    public const string ControlParent            = "CONTROL_PARENT";
    public const string Guarantor                = "GUARANTOR";
    public const string Sponsor                  = "SPONSOR";
    public const string ManagingEntity           = "MANAGING_ENTITY";

    public static readonly IReadOnlyList<string> All = new[]
    {
        AccountingDirectParent, AccountingUltimateParent, OwnershipParent,
        ControlParent, Guarantor, Sponsor, ManagingEntity,
    };
}
