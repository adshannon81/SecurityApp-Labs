using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Portfolio.Entities;

/// <summary>
/// A named point-of-contact for a client.
/// Multiple contacts are allowed per client; contacts can be activated or deactivated
/// without losing history (bi-temporal tracking via TemporalEntity).
/// </summary>
public class ClientContact : TemporalEntity
{
    public Guid ClientId { get; set; }

    /// <summary>Full name of the contact person.</summary>
    public string ContactName { get; set; } = string.Empty;

    /// <summary>Job title or role (e.g. "Relationship Manager", "Compliance Officer").</summary>
    public string? Role { get; set; }

    public string? Email { get; set; }
    public string? Phone { get; set; }

    /// <summary>True for the designated primary / main point of contact.</summary>
    public bool IsPrimary { get; set; } = false;

    /// <summary>Whether this contact is currently reachable / active.</summary>
    public bool IsActive { get; set; } = true;

    // Navigation
    public Client Client { get; set; } = null!;
}
