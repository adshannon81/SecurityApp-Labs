using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Portfolio.Entities;

/// <summary>
/// A portfolio owned by a client. A client may have many portfolios
/// (e.g. Growth Fund, Income Fund, ESG Mandate).
/// Supports bi-temporal tracking for complete history.
/// </summary>
public class Portfolio : TemporalEntity
{
    public Guid ClientId { get; set; }
    public string Name { get; set; } = string.Empty;
    /// <summary>Short mnemonic code (e.g. "ACME-GROWTH").</summary>
    public string Code { get; set; } = string.Empty;
    public string Currency { get; set; } = "USD";
    public bool IsActive { get; set; } = true;

    // Navigation
    public Client Client { get; set; } = null!;
    public ICollection<Position> Positions { get; set; } = new List<Position>();
}
