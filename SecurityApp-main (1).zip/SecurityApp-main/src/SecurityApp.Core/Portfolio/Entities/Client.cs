using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Portfolio.Entities;

/// <summary>
/// Represents a client (firm or individual) who owns one or more portfolios.
/// Supports bi-temporal tracking for complete history.
/// </summary>
public class Client : TemporalEntity
{
    public string Name { get; set; } = string.Empty;
    /// <summary>Short mnemonic code used for display and import matching (e.g. "ACME").</summary>
    public string Code { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;

    // Navigation
    public ICollection<Portfolio> Portfolios { get; set; } = new List<Portfolio>();
    public ICollection<ClientContact> Contacts { get; set; } = new List<ClientContact>();
}
