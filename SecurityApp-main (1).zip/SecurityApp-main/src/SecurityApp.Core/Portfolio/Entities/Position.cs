using SecurityApp.Core.Shared;
using SecurityApp.Core.Securities.Entities;

namespace SecurityApp.Core.Portfolio.Entities;

/// <summary>
/// A holding of a specific security within a portfolio, keyed by portfolio + security + as_of_date.
/// Supports bi-temporal tracking via TemporalEntity — full history is retained automatically.
/// HasOpenPosition on Security is a cached flag updated whenever positions are created or removed.
/// </summary>
public class Position : TemporalEntity
{
    public Guid    PortfolioId  { get; set; }
    public Guid    SecurityId   { get; set; }
    public DateOnly AsOfDate    { get; set; }
    public decimal Quantity     { get; set; }
    public decimal? MarketValue { get; set; }
    public decimal? BookValue   { get; set; }
    public string  CurrencyCode { get; set; } = "USD";
    public string  SourceSystem { get; set; } = string.Empty;

    // Navigation properties
    public Portfolio Portfolio { get; set; } = null!;
    public Security  Security  { get; set; } = null!;
}
