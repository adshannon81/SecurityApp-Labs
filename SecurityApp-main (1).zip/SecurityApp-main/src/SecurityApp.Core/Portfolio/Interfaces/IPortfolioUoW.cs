using SecurityApp.Core.Portfolio.Entities;
using SecurityApp.Core.Securities.Entities;
using SecurityApp.Core.Shared.Interfaces;
using PortfolioEntity = SecurityApp.Core.Portfolio.Entities.Portfolio;

namespace SecurityApp.Core.Portfolio.Interfaces;

/// <summary>
/// Narrow unit-of-work scoped to the Portfolio bounded context.
/// Includes Securities so position handlers can update HasOpenPosition without a separate UoW.
/// </summary>
public interface IPortfolioUoW
{
    IRepository<Client>    Clients    { get; }
    IRepository<ClientContact> ClientContacts { get; }
    IRepository<PortfolioEntity> Portfolios { get; }
    IRepository<Position>  Positions  { get; }
    IRepository<Security>  Securities { get; }
    IRepository<SecurityIdentifier> SecurityIdentifiers { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    Task BeginTransactionAsync(CancellationToken cancellationToken = default);
    Task CommitTransactionAsync(CancellationToken cancellationToken = default);
    Task RollbackTransactionAsync(CancellationToken cancellationToken = default);
}
