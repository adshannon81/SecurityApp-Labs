namespace SecurityApp.Core.Portfolio.Enums;

public enum PositionStatus
{
    Pending,
    Open,
    Closed
}
