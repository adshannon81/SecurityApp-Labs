﻿using SecurityApp.Core.Plugins.Interfaces;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Securities.Models;


namespace SecurityApp.Core.Securities.Interfaces;

/// <summary>
/// Extended data connector that can fetch and search security reference data.
/// Implement this for each external source: AlphaVantage, Bloomberg, Reuters, etc.
/// </summary>
public interface ISecurityDataProvider : IDataConnector
{
    /// <summary>Priority order (lower = tried first)</summary>
    int Priority { get; }

    bool SupportsIdentifierType(IdentifierType identifierType);

    Task<ExternalSecurityData?> GetSecurityAsync(
        string identifierValue,
        IdentifierType identifierType,
        CancellationToken cancellationToken = default);

    Task<IEnumerable<ExternalSecurityData>> SearchSecuritiesAsync(
        string keyword,
        CancellationToken cancellationToken = default);
}
