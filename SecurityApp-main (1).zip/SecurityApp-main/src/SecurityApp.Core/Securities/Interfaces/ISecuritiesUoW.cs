﻿using SecurityApp.Core.Securities.Entities;
using SecurityApp.Core.Shared.Interfaces;


namespace SecurityApp.Core.Securities.Interfaces;

/// <summary>
/// Narrow unit-of-work interface scoped to the Securities bounded context.
/// Inject this instead of <see cref="IUnitOfWork"/> in any class that only needs
/// Security / SecurityAttribute data - prevents accidental cross-domain writes.
/// </summary>
public interface ISecuritiesUoW
{
    IRepository<Security> Securities { get; }
    IRepository<SecurityIdentifier>          SecurityIdentifiers           { get; }
    IRepository<SecurityCoreAttribute>       SecurityCoreAttributes       { get; }
    IRepository<SecurityLoanAttribute>        SecurityLoanAttributes        { get; }
    IRepository<SecurityDerivativeAttribute>  SecurityDerivativeAttributes  { get; }
    IRepository<SecuritySecuritizedAttribute> SecuritySecuritizedAttributes { get; }
    IRepository<SecurityAttributeKv>          SecurityAttributeKvs          { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    Task BeginTransactionAsync(CancellationToken cancellationToken = default);
    Task CommitTransactionAsync(CancellationToken cancellationToken = default);
    Task RollbackTransactionAsync(CancellationToken cancellationToken = default);
}
