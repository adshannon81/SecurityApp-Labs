﻿using SecurityApp.Core.Securities.Models;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Import.Models;


namespace SecurityApp.Core.Securities.Interfaces;

/// <summary>
/// Serialises a list of <see cref="SecurityExportRecord"/> objects to a byte
/// array in one of the supported file formats (JSON / XML / CSV).
/// Used by <c>ExportController</c> to produce a downloadable file response.
/// </summary>
public interface ISecurityExportService
{
    /// <summary>Serialise records to the requested format.</summary>
    /// <param name="records">Flat export records produced by <c>ExportSecuritiesQuery</c>.</param>
    /// <param name="format">Output format.</param>
    /// <param name="delimiter">Column delimiter used only when <paramref name="format"/> is <see cref="ExportFormat.Csv"/>.</param>
    /// <param name="profile">Optional column mapping profile. When null or empty all fields are exported with default names.</param>
    byte[] Export(
        IEnumerable<SecurityExportRecord> records,
        ExportFormat format,
        char delimiter = ',',
        ExportMappingProfile? profile = null);

    string GetContentType(ExportFormat format);
    string GetFileName(ExportFormat format);
}
