using SecurityApp.Core.Securities.Entities;

namespace SecurityApp.Core.Securities.Interfaces;

/// <summary>
/// Read-only access to security reference / lookup tables:
/// security_status_ref, asset_class_ref, instrument_type_ref.
/// </summary>
public interface ISecurityRefDataRepository
{
    Task<IList<SecurityStatusRef>>  GetStatusesAsync(CancellationToken ct = default);
    Task<IList<AssetClassRef>>      GetAssetClassesWithTypesAsync(CancellationToken ct = default);
}
