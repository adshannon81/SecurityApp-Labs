using SecurityApp.Core.Shared.Exceptions;

namespace SecurityApp.Core.Securities.Services;

/// <summary>
/// Domain service that enforces the security lifecycle state machine and computes
/// capability flags from the current status. Rules are the single source of truth;
/// they mirror the rows seeded into <c>dbo.security_status_transition_ref</c>.
/// </summary>
public static class LifecycleGuard
{
    // Allowed transitions: key = fromCode, value = set of permitted toCodes.
    // Includes both forward (lifecycle progression) and backward (correction/reversal) transitions.
    private static readonly IReadOnlyDictionary<string, IReadOnlySet<string>> AllowedTransitions =
        new Dictionary<string, IReadOnlySet<string>>(StringComparer.OrdinalIgnoreCase)
        {
            ["DRAFT"]            = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "PENDING_APPROVAL", "CANCELLED" },
            ["PENDING_APPROVAL"] = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "ACTIVE", "DRAFT", "CANCELLED" },
            ["ACTIVE"]           = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "SUSPENDED", "CALLED", "MATURED", "DEFAULTED", "RETIRED", "PENDING_APPROVAL", "RESTRUCTURED" },
            ["SUSPENDED"]        = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "ACTIVE", "CALLED", "MATURED", "DEFAULTED", "RETIRED" },
            ["CALLED"]           = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "RETIRED", "ACTIVE", "SUSPENDED" },
            ["MATURED"]          = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "RETIRED", "ACTIVE", "SUSPENDED" },
            ["DEFAULTED"]        = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "RESTRUCTURED", "RETIRED", "ACTIVE", "SUSPENDED" },
            ["RESTRUCTURED"]     = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "ACTIVE", "RETIRED", "DEFAULTED" },
            // Previously terminal — backwards correction now permitted
            ["RETIRED"]          = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "ACTIVE", "SUSPENDED", "DEFAULTED", "RESTRUCTURED", "CALLED", "MATURED" },
            ["CANCELLED"]        = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "DRAFT", "PENDING_APPROVAL" },
        };

    /// <summary>
    /// Throws <see cref="InvalidLifecycleTransitionException"/> when the proposed status
    /// change is not in the allowed-transitions table. No-ops when fromCode == toCode.
    /// </summary>
    public static void GuardTransition(string fromCode, string toCode)
    {
        if (string.Equals(fromCode, toCode, StringComparison.OrdinalIgnoreCase))
            return; // same-status write is always allowed

        if (!AllowedTransitions.TryGetValue(fromCode, out var allowed) || !allowed.Contains(toCode))
            throw new InvalidLifecycleTransitionException(fromCode, toCode);
    }

    // ── Capability flags ──────────────────────────────────────────────────────

    /// <summary>Security can be used in trading. True only when ACTIVE.</summary>
    public static bool IsTradeable(string statusCode) =>
        string.Equals(statusCode, "ACTIVE", StringComparison.OrdinalIgnoreCase);

    /// <summary>Security can receive a market price. True when ACTIVE or SUSPENDED.</summary>
    public static bool IsPriceable(string statusCode) =>
        statusCode.Equals("ACTIVE",    StringComparison.OrdinalIgnoreCase) ||
        statusCode.Equals("SUSPENDED", StringComparison.OrdinalIgnoreCase);

    /// <summary>Security is eligible for new allocations. True only when ACTIVE.</summary>
    public static bool IsEligible(string statusCode) =>
        string.Equals(statusCode, "ACTIVE", StringComparison.OrdinalIgnoreCase);

    /// <summary>Security must appear in regulatory reports. True for all states except DRAFT and CANCELLED.</summary>
    public static bool IsReportable(string statusCode) =>
        !statusCode.Equals("DRAFT",     StringComparison.OrdinalIgnoreCase) &&
        !statusCode.Equals("CANCELLED", StringComparison.OrdinalIgnoreCase);
}
