﻿namespace SecurityApp.Core.Securities.Enums;

/// <summary>
/// File format for security data export.
/// </summary>
public enum ExportFormat
{
    Json,
    Xml,
    Csv
}
