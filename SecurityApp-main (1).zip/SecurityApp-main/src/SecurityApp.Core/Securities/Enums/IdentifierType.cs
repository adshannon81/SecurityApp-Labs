﻿namespace SecurityApp.Core.Securities.Enums;

/// <summary>
/// Type of security identifier (CUSIP, ISIN, etc.)
/// </summary>
public enum IdentifierType
{
    CUSIP,
    ISIN,
    SEDOL,
    Ticker,
    Bloomberg,
    Reuters,
    Internal,
    Other
}
