﻿namespace SecurityApp.Core.Securities.Enums;

/// <summary>
/// Types of securities supported by the system
/// </summary>
public enum SecurityType
{
    ABS,          // Asset-Backed Security
    Bond,
    Equity,
    CorporateBond,
    MunicipalBond,
    TreasuryBond,
    Loan,
    Derivative,
    Option,
    Future,
    Swap,
    Other
}
