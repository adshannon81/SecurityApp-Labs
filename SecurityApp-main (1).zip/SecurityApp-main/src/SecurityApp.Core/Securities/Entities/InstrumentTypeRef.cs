namespace SecurityApp.Core.Securities.Entities;

/// <summary>
/// Specific instrument type under an asset class
/// (TreasuryBond, CDS, Future, TermLoan, etc.).
/// Managed via the instrument_type_ref table — add new types without schema changes.
/// </summary>
public class InstrumentTypeRef
{
    public string  Code           { get; set; } = string.Empty;
    public string  AssetClassCode { get; set; } = string.Empty;
    public string? Description    { get; set; }

    public AssetClassRef?        AssetClass  { get; set; }
    public ICollection<Security> Securities  { get; set; } = new List<Security>();
}
