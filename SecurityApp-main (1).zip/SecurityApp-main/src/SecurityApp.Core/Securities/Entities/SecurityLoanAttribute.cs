using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Securities.Entities;

/// <summary>
/// Loan-specific attributes. Extends the core attribute for LOAN instruments.
/// margin_bps is spread in basis points above the reference index.
/// reference_index holds values like SOFR, EURIBOR, SONIA.
/// </summary>
public class SecurityLoanAttribute : TemporalEntity
{
    public Guid SecurityId { get; set; }
    public string? LoanType       { get; set; }
    public string? CollateralType { get; set; }
    public string? Seniority      { get; set; }
    public string? Amortization   { get; set; }
    public string? PaymentFreq    { get; set; }
    public string? DayCount       { get; set; }
    public decimal? MarginBps     { get; set; }
    public string? ReferenceIndex { get; set; }
    public DateTime? MaturityDate  { get; set; }
    public decimal? DrawdownLimit { get; set; }

    // Navigation property
    public Security Security { get; set; } = null!;
}
