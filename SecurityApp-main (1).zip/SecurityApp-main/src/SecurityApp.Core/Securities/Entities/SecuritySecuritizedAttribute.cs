using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Securities.Entities;

/// <summary>
/// Securitized product attributes (ABS, MBS, RMBS, CMBS, CLO, CDO, CoveredBond).
/// pool_id is the external identifier of the collateral pool.
/// tranche_label identifies the tranche, e.g. A, B, Mezz, Equity.
/// credit_enhancement is typically expressed as a percentage.
/// current_balance and original_balance may change over time and are historized.
/// </summary>
public class SecuritySecuritizedAttribute : TemporalEntity
{
    public Guid SecurityId           { get; set; }
    public string? PoolId             { get; set; }
    public string? TrancheLabel       { get; set; }
    public string? TrancheSeniority   { get; set; }
    public decimal? OriginalBalance   { get; set; }
    public decimal? CurrentBalance    { get; set; }
    public decimal? CreditEnhancement { get; set; }
    public bool? Callable             { get; set; }
    public DateTime? CallDate         { get; set; }

    // Navigation property
    public Security Security { get; set; } = null!;
}
