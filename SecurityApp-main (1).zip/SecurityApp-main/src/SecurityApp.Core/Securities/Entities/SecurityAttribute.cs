﻿using SecurityApp.Core.Shared;


namespace SecurityApp.Core.Securities.Entities;

/// <summary>
/// Additional attributes for specific security types (e.g., loans)
/// Supports bi-temporal tracking for attribute history
/// </summary>
public class SecurityCoreAttribute : TemporalEntity
{
    public Guid SecurityId { get; set; }
    public decimal? CouponRate { get; set; }
    public decimal? FactorRate { get; set; }
    public DateTime? MaturityDate { get; set; }
    public DateTime? IssueDate { get; set; }
    public decimal? FaceValue { get; set; }

    // Navigation properties
    public Security Security { get; set; } = null!;
}
