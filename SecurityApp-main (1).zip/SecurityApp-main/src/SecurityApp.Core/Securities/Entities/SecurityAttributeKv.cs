using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Securities.Entities;

/// <summary>
/// Generic key/value attribute store for client-specific, rare, or fast-evolving fields.
/// attribute_name should be stable and machine-friendly.
/// Exactly one value column should be populated according to attribute_type.
/// Promoted to a typed table if the attribute becomes widely used.
/// </summary>
public class SecurityAttributeKv : TemporalEntity
{
    public Guid SecurityId      { get; set; }
    public string AttributeName { get; set; } = string.Empty;
    public string AttributeType { get; set; } = string.Empty;
    public string? ValueString  { get; set; }
    public decimal? ValueDecimal { get; set; }
    public long? ValueInt        { get; set; }
    public DateTime? ValueDate   { get; set; }
    public bool? ValueBool       { get; set; }
    public string? SourceSystem  { get; set; }

    // Navigation property
    public Security Security { get; set; } = null!;
}
