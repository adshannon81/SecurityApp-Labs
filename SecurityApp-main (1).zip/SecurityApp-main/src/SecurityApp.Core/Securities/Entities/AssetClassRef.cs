namespace SecurityApp.Core.Securities.Entities;

/// <summary>
/// High-level instrument classification bucket
/// (EQUITY, BOND, LOAN, DERIVATIVE, SECURITIZED, etc.).
/// Managed via the asset_class_ref table — clients can extend without schema changes.
/// </summary>
public class AssetClassRef
{
    public string  Code        { get; set; } = string.Empty;
    public string  Name        { get; set; } = string.Empty;
    public string? Description { get; set; }

    public ICollection<InstrumentTypeRef> InstrumentTypes { get; set; } = new List<InstrumentTypeRef>();
    public ICollection<Security>          Securities      { get; set; } = new List<Security>();
}
