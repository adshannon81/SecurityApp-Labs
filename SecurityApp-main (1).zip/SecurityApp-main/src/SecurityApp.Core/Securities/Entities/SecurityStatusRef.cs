namespace SecurityApp.Core.Securities.Entities;

/// <summary>
/// Reference row for the lifecycle state of a security
/// (ACTIVE, SUSPENDED, MATURED, DEFAULTED, etc.).
/// Managed via the security_status_ref table — add new states without schema changes.
/// </summary>
public class SecurityStatusRef
{
    public string Code        { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;

    public ICollection<Security> Securities { get; set; } = new List<Security>();
}
