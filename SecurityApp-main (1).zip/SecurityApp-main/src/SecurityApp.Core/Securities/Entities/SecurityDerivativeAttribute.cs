using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Securities.Entities;

/// <summary>
/// Derivative-specific attributes (options, futures, swaps, forwards, CDS, etc.).
/// underlying_id may point to another security if the underlying exists in the master.
/// notional_ccy and strike_ccy are allowed because derivatives can use currencies
/// different from the security base currency.
/// option_type: Call | Put
/// option_style: European | American | Bermudan
/// </summary>
public class SecurityDerivativeAttribute : TemporalEntity
{
    public Guid SecurityId       { get; set; }
    public string? UnderlyingType  { get; set; }
    public Guid? UnderlyingId     { get; set; }
    public decimal? Notional       { get; set; }
    public string? NotionalCcy     { get; set; }
    public decimal? StrikePrice    { get; set; }
    public string? StrikeCcy       { get; set; }
    public string? OptionStyle     { get; set; }
    public string? OptionType      { get; set; }
    public DateTime? ExpiryDate    { get; set; }
    public string? SettlementType  { get; set; }
    public int? LegCount           { get; set; }

    // Navigation property
    public Security Security { get; set; } = null!;
}
