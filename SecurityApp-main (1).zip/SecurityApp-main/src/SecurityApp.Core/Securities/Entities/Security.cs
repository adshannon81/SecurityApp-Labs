﻿using SecurityApp.Core.Shared;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Shared.Enums;
using SecurityApp.Core.Ratings.Entities;
using SecurityApp.Core.Pricing.Entities;
using SecurityApp.Core.Issuers.Entities;


namespace SecurityApp.Core.Securities.Entities;

/// <summary>
/// Represents a financial security (ABS, Bonds, Equity, etc.)
/// Supports bi-temporal tracking for complete history
/// </summary>
public class Security : TemporalEntity
{
    /// <summary>Which external provider is the origin of this record.</summary>
    public DataSourceType DataSource { get; set; }
    public SecurityType Type { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    /// <summary>FK → dbo.issuer(id). Preferred way to link a security to its issuer.</summary>
    public Guid? IssuerId { get; set; }
    /// <summary>ISO 4217 currency code. FK → dbo.currency(code).</summary>
    public string? CurrencyCode { get; set; }
    public bool HasOpenPosition { get; set; } = false;

    // ── New lifecycle + classification columns ────────────────────────────────
    /// <summary>Lifecycle state (ACTIVE, MATURED, DEFAULTED, …). FK → security_status_ref.</summary>
    public string StatusCode { get; set; } = "ACTIVE";

    /// <summary>High-level asset class (BOND, EQUITY, DERIVATIVE, …). FK → asset_class_ref.</summary>
    public string AssetClassCode { get; set; } = "OTHER";

    /// <summary>Specific instrument type (TreasuryBond, CDS, TermLoan, …). FK → instrument_type_ref.</summary>
    public string InstrumentTypeCode { get; set; } = "Other";

    /// <summary>
    /// SHA-256 hex digest of normalised external data fields.
    /// Updated on every successful import; when the hash is unchanged the write is skipped (delta detection).
    /// </summary>
    public string? ContentHash { get; set; }

    /// <summary>
    /// SQL Server ROWVERSION concurrency token. Exposed as ETag on GET; validated via If-Match on PUT.
    /// Mapped with IsRowVersion() in EF Core — never manually set by application code.
    /// </summary>
    public byte[] RowVersion { get; set; } = Array.Empty<byte>();

    /// <summary>
    /// PostgreSQL xmin system column — transaction ID of the last write.
    /// Used as optimistic concurrency token on PostgreSQL (UseXminAsConcurrencyToken).
    /// Always 0 / ignored on SQL Server.
    /// </summary>
    public uint Xmin { get; set; }

    // Navigation properties
    public ICollection<SecurityIdentifier> Identifiers { get; set; } = new List<SecurityIdentifier>();
    public Issuer? IssuerNav { get; set; }
    public SecurityStatusRef?  Status         { get; set; }
    public AssetClassRef?      AssetClass     { get; set; }
    public InstrumentTypeRef?  InstrumentType { get; set; }
    public SecurityCoreAttribute?        Attributes            { get; set; }
    public SecurityLoanAttribute?        LoanAttributes        { get; set; }
    public SecurityDerivativeAttribute?  DerivativeAttributes  { get; set; }
    public SecuritySecuritizedAttribute? SecuritizedAttributes { get; set; }
    public ICollection<SecurityAttributeKv> Kv { get; set; } = new List<SecurityAttributeKv>();
    public ICollection<CreditRating> CreditRatings { get; set; } = new List<CreditRating>();
    public ICollection<Price> Prices { get; set; } = new List<Price>();
    public ICollection<DerivedPrice> DerivedPrices { get; set; } = new List<DerivedPrice>();
}
