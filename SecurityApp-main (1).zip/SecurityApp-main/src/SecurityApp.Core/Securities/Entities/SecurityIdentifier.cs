using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Securities.Entities;

/// <summary>
/// Represents one identifier for a security (ISIN, CUSIP, SEDOL, Bloomberg ticker, etc.).
/// A single security may have multiple active identifiers, each tracked under the
/// bi-temporal model so the full identifier history is preserved.
/// </summary>
public class SecurityIdentifier : TemporalEntity
{
    public Guid   SecurityId      { get; set; }
    public string IdentifierType  { get; set; } = string.Empty;
    public string IdentifierValue { get; set; } = string.Empty;
    public string? SourceSystem   { get; set; } = "Manual";
    /// <summary>True when this is the preferred display identifier for its type and source.</summary>
    public bool IsPrimary         { get; set; } = false;

    // Navigation
    public Security Security { get; set; } = null!;
}
