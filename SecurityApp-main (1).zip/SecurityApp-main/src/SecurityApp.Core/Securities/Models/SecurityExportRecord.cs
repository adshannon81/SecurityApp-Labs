﻿namespace SecurityApp.Core.Securities.Models;

/// <summary>
/// Flat, serialisation-ready record used for security data exports.
/// Populated by the export query handler and consumed by both the download API
/// and by ISecurityDataExporter plugin implementations (e.g. VPM file drop).
/// </summary>
public class SecurityExportRecord
{
    // Identity
    public Guid   Id                  { get; set; }
    public string IdentifierType      { get; set; } = string.Empty;
    public string IdentifierValue     { get; set; } = string.Empty;
    public string SecurityType        { get; set; } = string.Empty;
    public string Name                { get; set; } = string.Empty;
    public bool   IsActive            { get; set; }

    // Descriptive
    public string? Description        { get; set; }
    public string? Issuer             { get; set; }
    public string? Currency           { get; set; }

    // Fixed-income / loan attributes
    public decimal?  CouponRate       { get; set; }
    public decimal?  FactorRate       { get; set; }
    public DateTime? MaturityDate     { get; set; }
    public DateTime? IssueDate        { get; set; }
    public decimal?  FaceValue        { get; set; }

    // Primary credit rating (first active rating found)
    public string? PrimaryRating      { get; set; }
    public string? PrimaryRatingAgency { get; set; }

    // Audit
    public DateTime ExportedAt        { get; set; } = DateTime.UtcNow;
}
