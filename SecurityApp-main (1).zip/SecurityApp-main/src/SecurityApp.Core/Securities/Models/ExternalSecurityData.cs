﻿using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Ratings.Enums;
using SecurityApp.Core.Shared.Enums;
using SecurityApp.Core.Import.Models;


namespace SecurityApp.Core.Securities.Models;

/// <summary>
/// Normalized security data returned by any external data provider.
/// Provider-specific response models are mapped to this before reaching the application layer.
/// </summary>
public class ExternalSecurityData
{
    // Primary identifiers
    public string Symbol { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public SecurityType SecurityType { get; set; }
    public IdentifierType IdentifierType { get; set; }
    public string IdentifierValue { get; set; } = string.Empty;

    // Classification
    public string? Exchange { get; set; }
    public string? Currency { get; set; }
    public string? Country { get; set; }
    public string? Sector { get; set; }
    public string? Industry { get; set; }
    public string? Issuer { get; set; }
    public string? Description { get; set; }

    // Fixed income / loan specific
    public decimal? CouponRate { get; set; }
    public decimal? FactorRate { get; set; }
    public DateTime? MaturityDate { get; set; }
    public DateTime? IssueDate { get; set; }
    public decimal? FaceValue { get; set; }

    // Credit rating (optional - set when the provider supplies rating data)
    public string? Rating { get; set; }
    public RatingAgency? RatingAgency { get; set; }
    public RatingType? RatingType { get; set; }
    public DateTime? RatingDate { get; set; }

    // Metadata
    public DataSourceType Source { get; set; }
    public DateTime FetchedAt { get; set; } = DateTime.UtcNow;

    // Raw provider data (JSON-serializable key-value pairs for audit/debugging)
    public Dictionary<string, string?> RawData { get; set; } = new();

    // Import provenance (set by file connectors)
    /// <summary>1-based row number in the source file. Zero when not set by a connector.</summary>
    public int RowNumber { get; set; }

    /// <summary>Validation errors/warnings produced during file parsing (empty for API/provider imports).</summary>
    public List<ImportValidationError> ValidationErrors { get; set; } = new();
}
