using SecurityApp.Core.AppAuthorization.Enums;
using SecurityApp.Core.Shared;

namespace SecurityApp.Core.AppAuthorization;

/// <summary>
/// A concrete protected resource: a menu item, route, action, tab, or section.
/// Supports parent-child hierarchies via <see cref="ParentAppResourceId"/> so that
/// MENU_GROUP can own MENU_ITEMs and MENU_ITEMs can nest further.
/// </summary>
public class AppResource : TemporalEntity
{
    public AppResourceType ResourceType { get; set; }

    /// <summary>Global unique technical key, e.g. "nav.securities", "/admin/users", "security.delete".</summary>
    public string ResourceKey { get; set; } = string.Empty;

    /// <summary>Optional parent resource for nested menus.</summary>
    public Guid? ParentAppResourceId { get; set; }
    public AppResource? Parent { get; set; }
    public ICollection<AppResource> Children { get; set; } = [];

    public string DisplayName { get; set; } = string.Empty;

    /// <summary>Angular router path — relevant for MENU_ITEM and ROUTE types.</summary>
    public string? RoutePath { get; set; }

    public string? IconName { get; set; }

    public string? Description { get; set; }

    /// <summary>State applied when no rule matches for the current user.</summary>
    public VisibilityState DefaultVisibilityState { get; set; } = VisibilityState.Hidden;

    /// <summary>Execution state applied when no rule matches for the current user.</summary>
    public AppExecutionState DefaultExecutionState { get; set; } = AppExecutionState.Deny;

    /// <summary>When true the existence of this resource is itself sensitive — deny-by-default.</summary>
    public bool IsSecuritySensitive { get; set; }

    public int SortOrder { get; set; }

    public new bool IsActive { get; set; } = true;

    public ICollection<AppResourceRule> Rules { get; set; } = [];
}
