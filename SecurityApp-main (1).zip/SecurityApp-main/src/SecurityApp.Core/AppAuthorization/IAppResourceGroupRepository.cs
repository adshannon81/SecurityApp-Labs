namespace SecurityApp.Core.AppAuthorization;

public interface IAppResourceGroupRepository
{
    Task<IReadOnlyList<AppResourceGroup>> GetAllAsync(CancellationToken ct = default);
    Task<AppResourceGroup?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<AppResourceGroup> CreateAsync(AppResourceGroup group, CancellationToken ct = default);
    Task<AppResourceGroup> UpdateAsync(AppResourceGroup group, CancellationToken ct = default);
    Task DeleteAsync(Guid id, CancellationToken ct = default);
}
