namespace SecurityApp.Core.AppAuthorization;

public interface IAppResourceRuleRepository
{
    Task<IReadOnlyList<AppResourceRule>> GetAllAsync(CancellationToken ct = default);
    Task<IReadOnlyList<AppResourceRule>> GetByResourceAsync(Guid resourceId, CancellationToken ct = default);
    Task<AppResourceRule?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<AppResourceRule> CreateAsync(AppResourceRule rule, CancellationToken ct = default);
    Task<AppResourceRule> UpdateAsync(AppResourceRule rule, CancellationToken ct = default);
    Task DeleteAsync(Guid id, CancellationToken ct = default);
}
