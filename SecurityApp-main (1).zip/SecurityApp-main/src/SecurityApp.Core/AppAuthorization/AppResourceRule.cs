using SecurityApp.Core.AppAuthorization.Enums;
using SecurityApp.Core.Permissions;
using SecurityApp.Core.Shared;

namespace SecurityApp.Core.AppAuthorization;

/// <summary>
/// Permission-based rule for an app resource.
/// Unifies visibility_state + execution_state in one temporal record.
/// </summary>
public class AppResourceRule : TemporalEntity
{
    public Guid AppResourceId { get; set; }
    public AppResource? Resource { get; set; }

    public Guid PermissionDefinitionId { get; set; }
    public PermissionDefinition? Permission { get; set; }

    /// <summary>UI visibility when the caller holds RequiredPermission.</summary>
    public VisibilityState VisibilityState { get; set; }

    /// <summary>Backend execution state when the caller holds RequiredPermission.</summary>
    public AppExecutionState ExecutionState { get; set; }

    /// <summary>Higher value wins when multiple rules match the same permission set.</summary>
    public int Priority { get; set; }

    public new bool IsActive { get; set; } = true;

    public DateTime? EffectiveFrom { get; set; }
    public DateTime? EffectiveTo { get; set; }

}
