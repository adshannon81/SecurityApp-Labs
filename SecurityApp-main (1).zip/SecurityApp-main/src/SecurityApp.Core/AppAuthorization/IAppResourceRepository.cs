namespace SecurityApp.Core.AppAuthorization;

public interface IAppResourceRepository
{
    Task<IReadOnlyList<AppResource>> GetAllAsync(CancellationToken ct = default);
    Task<AppResource?> GetByIdAsync(Guid id, CancellationToken ct = default);
    Task<AppResource?> GetByKeyAsync(string resourceKey, CancellationToken ct = default);
    Task<AppResource> CreateAsync(AppResource resource, CancellationToken ct = default);
    Task<AppResource> UpdateAsync(AppResource resource, CancellationToken ct = default);
    Task DeleteAsync(Guid id, CancellationToken ct = default);
    Task<IReadOnlyList<AppResource>> GetAllWithChildrenAsync(CancellationToken ct = default);
}
