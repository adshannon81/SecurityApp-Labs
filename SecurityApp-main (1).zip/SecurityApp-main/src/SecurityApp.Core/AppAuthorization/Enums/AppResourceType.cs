namespace SecurityApp.Core.AppAuthorization.Enums;

public enum AppResourceType
{
    MenuGroup,
    MenuItem,
    Route,
    Action,
    Tab,
    Section,
}
