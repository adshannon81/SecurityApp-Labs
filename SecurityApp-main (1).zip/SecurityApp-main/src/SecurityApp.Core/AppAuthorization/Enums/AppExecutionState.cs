namespace SecurityApp.Core.AppAuthorization.Enums;

public enum AppExecutionState
{
    Allow,
    Deny,
    NotApplicable,
}
