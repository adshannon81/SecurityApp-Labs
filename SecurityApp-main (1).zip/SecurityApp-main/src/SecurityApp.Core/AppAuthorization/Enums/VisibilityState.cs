namespace SecurityApp.Core.AppAuthorization.Enums;

public enum VisibilityState
{
    Visible,
    Hidden,
    Disabled,
    NotApplicable,
}
