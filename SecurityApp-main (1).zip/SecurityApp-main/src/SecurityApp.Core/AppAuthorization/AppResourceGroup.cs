using SecurityApp.Core.Shared;

namespace SecurityApp.Core.AppAuthorization;

/// <summary>
/// A logical grouping of app resources for organizational and display purposes.
/// Groups allow resources to be batched together for permission matrix management.
/// </summary>
public class AppResourceGroup : TemporalEntity
{
    /// <summary>Unique technical key, e.g. "nav.admin", "screens.securities".</summary>
    public string GroupKey { get; set; } = string.Empty;

    public string DisplayName { get; set; } = string.Empty;

    public string? Description { get; set; }

    public string? IconName { get; set; }

    public int SortOrder { get; set; }

    public new bool IsActive { get; set; } = true;
}
