using System.Security.Claims;

namespace SecurityApp.Core.AppAuthorization;

/// <summary>Result of resolving a field visibility state for a user.</summary>
public record FieldVisibilityResult(string State, string ObfuscationType);

/// <summary>Result of resolving a resource policy for a user.</summary>
public record ResourcePolicyResult(string VisibilityState, string ExecutionState);

/// <summary>One node in the resolved menu tree returned to the frontend.</summary>
public record MenuNodeDto(
    Guid   Id,
    string ResourceKey,
    string DisplayName,
    string? Description,
    string? IconName,
    int    SortOrder,
    IReadOnlyList<MenuItemNodeDto> Items);

public record MenuItemNodeDto(
    Guid   Id,
    string ResourceKey,
    string DisplayName,
    string? RoutePath,
    string? IconName,
    int    SortOrder,
    IReadOnlyList<MenuItemNodeDto> Children);

/// <summary>
/// Central authorization policy service.
/// Evaluates both field visibility rules and app resource rules against the current user's permissions.
/// All other services should use this interface — they must not depend on specific repositories directly.
/// </summary>
public interface IAuthorizationPolicyService
{
    /// <summary>Resolve field visibility for a specific DTO field.</summary>
    FieldVisibilityResult ResolveFieldVisibility(ClaimsPrincipal user, string entityType, string fieldName);

    /// <summary>Resolve visibility + execution policy for a resource key.</summary>
    ResourcePolicyResult ResolveResourcePolicy(ClaimsPrincipal user, string resourceKey);

    /// <summary>Returns true when the user may execute the given resource.</summary>
    bool CanExecuteResource(ClaimsPrincipal user, string resourceKey);

    /// <summary>
    /// Returns the filtered menu tree for the current user — groups with their visible items.
    /// Groups with no visible items are excluded.
    /// Items with HIDDEN effective state are excluded.
    /// </summary>
    IReadOnlyList<MenuNodeDto> GetVisibleMenu(ClaimsPrincipal user);
}
