namespace SecurityApp.Core.Idempotency;

/// <summary>Status values for <see cref="Entities.IdempotencyKey"/> records.</summary>
public static class IdempotencyStatus
{
    /// <summary>Request is currently in flight — block duplicate calls with 409.</summary>
    public const string Processing = "PROCESSING";

    /// <summary>Request succeeded — replay the stored response body.</summary>
    public const string Completed  = "COMPLETED";

    /// <summary>Request ended with a 5xx error — allow the client to retry.</summary>
    public const string Failed     = "FAILED";
}
