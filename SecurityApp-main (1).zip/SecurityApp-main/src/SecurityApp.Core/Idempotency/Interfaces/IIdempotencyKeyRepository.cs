using SecurityApp.Core.Idempotency.Entities;

namespace SecurityApp.Core.Idempotency.Interfaces;

/// <summary>Persistence contract for <see cref="IdempotencyKey"/> records.</summary>
public interface IIdempotencyKeyRepository
{
    /// <summary>Returns the entry for <paramref name="key"/>, or null if not found.</summary>
    Task<IdempotencyKey?> FindAsync(string key, CancellationToken ct = default);

    /// <summary>Inserts a new PROCESSING entry.</summary>
    Task CreateAsync(IdempotencyKey entry, CancellationToken ct = default);

    /// <summary>Transitions a PROCESSING or FAILED entry to COMPLETED and stores the response.</summary>
    Task MarkCompletedAsync(string key, int responseCode, string responseBody, CancellationToken ct = default);

    /// <summary>Transitions a PROCESSING entry to FAILED.</summary>
    Task MarkFailedAsync(string key, CancellationToken ct = default);

    /// <summary>
    /// Resets a FAILED entry back to PROCESSING with a fresh expiry, allowing the client to retry
    /// with the same idempotency key.
    /// </summary>
    Task ResetToProcessingAsync(string key, DateTime newExpiresAt, CancellationToken ct = default);

    /// <summary>Deletes all entries whose <c>expires_at</c> is in the past. Called by the cleanup job.</summary>
    Task DeleteExpiredAsync(CancellationToken ct = default);
}
