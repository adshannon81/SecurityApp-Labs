namespace SecurityApp.Core.Idempotency.Entities;

/// <summary>
/// Tracks idempotency keys for mutating API calls (REST + gRPC).
/// Not a BaseEntity/TemporalEntity — rows are ephemeral and expire after 24 hours.
/// Schema: dbo.idempotency_key_store
/// </summary>
public class IdempotencyKey
{
    /// <summary>Client-supplied idempotency key (PK). Max 200 chars.</summary>
    public string Key { get; set; } = string.Empty;

    /// <summary>
    /// Identifies the operation — "METHOD:/path" for REST, fully-qualified method name for gRPC.
    /// </summary>
    public string OperationType { get; set; } = string.Empty;

    /// <summary>Current lifecycle status. See <see cref="IdempotencyStatus"/>.</summary>
    public string Status { get; set; } = IdempotencyStatus.Processing;

    /// <summary>HTTP status code (or 200 for gRPC) of the completed response.</summary>
    public int? ResponseCode { get; set; }

    /// <summary>
    /// Full JSON-serialised response body. Stored on COMPLETED so replays return
    /// identical responses without re-processing the request.
    /// </summary>
    public string? ResponseBody { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>Record automatically expires after 24 hours and is deleted by the cleanup job.</summary>
    public DateTime ExpiresAt { get; set; }
}
