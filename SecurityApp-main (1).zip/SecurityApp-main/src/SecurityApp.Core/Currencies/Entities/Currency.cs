using SecurityApp.Core.Countries.Entities;
using SecurityApp.Core.Currencies.Enums;
using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Currencies.Entities;

/// <summary>
/// ISO 4217 fiat currency, crypto-currency, commodity or other reference record.
/// </summary>
public class Currency : TemporalEntity
{
    /// <summary>ISO 4217 alpha code (e.g. "USD") or crypto ticker (e.g. "BTC"). Natural unique key.</summary>
    public string Code { get; set; } = string.Empty;

    /// <summary>ISO 4217 three-digit numeric code. NULL for crypto / non-standard currencies.</summary>
    public string? NumericCode { get; set; }

    public string Name { get; set; } = string.Empty;

    /// <summary>Display symbol such as "$" or "€".</summary>
    public string? Symbol { get; set; }

    /// <summary>Storage decimal precision (e.g. 2 for USD, 0 for JPY, 8 for BTC).</summary>
    public byte Decimals { get; set; } = 2;

    /// <summary>UI display decimal places — at least 2, or more when the currency warrants it.</summary>
    public byte DisplayDecimals { get; set; } = 2;

    /// <summary>Classification: Fiat, Crypto, Commodity or Other.</summary>
    public CurrencyType CurrencyType { get; set; } = CurrencyType.Fiat;

    public new bool IsActive { get; set; } = true;

    public ICollection<CountryCurrency>      CountryCurrencies { get; set; } = new List<CountryCurrency>();
    public ICollection<CurrencyExternalCode> ExternalCodes     { get; set; } = new List<CurrencyExternalCode>();
}
