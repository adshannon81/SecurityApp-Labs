using SecurityApp.Core.Shared;

namespace SecurityApp.Core.Currencies.Entities;

/// <summary>
/// An external/vendor-specific code for a currency in a named external system
/// (e.g. Bloomberg ticker, Reuters code, SWIFT BIC family, etc.).
/// One currency can have many external codes across different systems.
/// </summary>
public class CurrencyExternalCode : TemporalEntity
{
    /// <summary>ISO 4217 / crypto code of the parent currency. FK → Currency.Code.</summary>
    public string CurrencyCode { get; set; } = string.Empty;

    /// <summary>Name of the external system, e.g. "Bloomberg", "Reuters", "ISIN".</summary>
    public string SystemName { get; set; } = string.Empty;

    /// <summary>The code as it is known in the external system.</summary>
    public string ExternalCode { get; set; } = string.Empty;

    // Navigation
    public Currency Currency { get; set; } = null!;
}
