namespace SecurityApp.Core.Currencies.Enums;

public enum CurrencyType
{
    Fiat,
    Crypto,
    Commodity,
    Other,
}
