using SecurityApp.Core.Shared.Enums;

namespace SecurityApp.Core.VendorSources.Interfaces;

/// <summary>
/// Writes raw vendor field snapshots captured from external data feeds into persistent storage.
/// Implementations resolve the <c>vendor_source_id</c> from the <see cref="DataSourceType"/> code.
/// </summary>
public interface IVendorSnapshotService
{
    /// <summary>
    /// Persists one snapshot row per entry in <paramref name="rawData"/>.
    /// Silently skips writing if the <paramref name="source"/> does not map to a known vendor record.
    /// </summary>
    Task WriteSnapshotsAsync(
        Guid securityId,
        DataSourceType source,
        IReadOnlyDictionary<string, string?> rawData,
        string? feedBatchId,
        DateTime receivedAt,
        CancellationToken cancellationToken = default);
}
