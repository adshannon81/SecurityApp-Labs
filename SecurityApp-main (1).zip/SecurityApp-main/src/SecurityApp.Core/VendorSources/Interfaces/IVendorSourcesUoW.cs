using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Core.VendorSources.Entities;

namespace SecurityApp.Core.VendorSources.Interfaces;

/// <summary>
/// Narrow unit-of-work interface scoped to the VendorSources bounded context.
/// </summary>
public interface IVendorSourcesUoW
{
    IRepository<VendorSource>        VendorSources        { get; }
    IRepository<VendorFieldPriority> VendorFieldPriorities { get; }
    IRepository<SecurityVendorData>  SecurityVendorData   { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    Task BeginTransactionAsync(CancellationToken cancellationToken = default);
    Task CommitTransactionAsync(CancellationToken cancellationToken = default);
    Task RollbackTransactionAsync(CancellationToken cancellationToken = default);
}
