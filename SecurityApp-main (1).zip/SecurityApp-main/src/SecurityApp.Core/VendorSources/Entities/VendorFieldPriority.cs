using SecurityApp.Core.Shared;

namespace SecurityApp.Core.VendorSources.Entities;

/// <summary>
/// Per-field, per-asset-class priority override for a vendor.
/// Allows fine-grained control over which vendor's value is preferred
/// for a specific field (e.g. "price") on a specific asset class (e.g. "EQUITY").
/// A null AssetClassCode means the override applies to all asset classes.
/// </summary>
public class VendorFieldPriority : TemporalEntity
{
    public Guid VendorSourceId { get; set; }

    /// <summary>
    /// Dot-notated field name, e.g. "Price.Close", "Ratings.SnP".
    /// </summary>
    public string FieldName { get; set; } = string.Empty;

    /// <summary>
    /// Asset class this override applies to.  Null = applies to all asset classes.
    /// </summary>
    public string? AssetClassCode { get; set; }

    /// <summary>
    /// Lower number = higher priority.  Falls back to VendorSource.GlobalPriority if no row exists.
    /// </summary>
    public int Priority { get; set; } = 100;

    /// <summary>
    /// When false this override row is ignored and the global priority is used instead.
    /// </summary>
    public bool IsActive { get; set; } = true;

    // Navigation
    public VendorSource VendorSource { get; set; } = null!;
}
