using SecurityApp.Core.Shared;

namespace SecurityApp.Core.VendorSources.Entities;

/// <summary>
/// Represents an external data vendor that provides market / reference data fields
/// for securities pricing and enrichment.
/// </summary>
public class VendorSource : TemporalEntity
{
    /// <summary>
    /// Short machine-readable code, e.g. BLOOMBERG, REFINITIV.
    /// </summary>
    public string Code { get; set; } = string.Empty;

    /// <summary>
    /// Human-readable display name shown in the UI.
    /// </summary>
    public string DisplayName { get; set; } = string.Empty;

    /// <summary>
    /// Lower number = higher priority when multiple vendors supply the same field.
    /// </summary>
    public int GlobalPriority { get; set; } = 100;

    /// <summary>
    /// Number of hours after which data from this vendor is considered stale.
    /// 0 means data never expires (e.g. manual / internal entries).
    /// </summary>
    public int StalenessThresholdHours { get; set; } = 24;

    /// <summary>
    /// When false the vendor is excluded from all data-sourcing decisions.
    /// </summary>
    public bool IsActive { get; set; } = true;

    // Navigation
    public ICollection<VendorFieldPriority> FieldPriorities { get; set; } = new List<VendorFieldPriority>();
}
