using SecurityApp.Core.Shared;

namespace SecurityApp.Core.VendorSources.Entities;

/// <summary>
/// Immutable raw field snapshot captured each time a vendor feed provides data for a security.
/// Append-only — no updates or soft deletes. Each row represents one field value at one point in time.
/// </summary>
public class SecurityVendorData : BaseEntity
{
    /// <summary>The security this snapshot belongs to.</summary>
    public Guid SecurityId { get; set; }

    /// <summary>The vendor source that provided this field value.</summary>
    public Guid VendorSourceId { get; set; }

    /// <summary>Normalised field name (e.g. "Symbol", "Name", "Price", "Volume").</summary>
    public string FieldName { get; set; } = string.Empty;

    /// <summary>Raw string value as received from the vendor.</summary>
    public string? RawValue { get; set; }

    /// <summary>
    /// Optional batch/job identifier that groups all rows captured in a single feed run
    /// (e.g. an import request GUID, a file name, or a job execution ID).
    /// </summary>
    public string? FeedBatchId { get; set; }

    /// <summary>Timestamp at which the data was received from the vendor.</summary>
    public DateTime ReceivedAt { get; set; } = DateTime.UtcNow;

    // Navigation
    public VendorSource? VendorSource { get; set; }
}
