namespace SecurityApp.API.SecretManagement;

/// <summary>
/// Implemented by Vault-backed providers that can read an arbitrary KV v2 field
/// from any secret path — not just the configured <c>VaultSecretPath</c>.
///
/// Both <see cref="Providers.HashiCorpVaultProvider"/> and
/// <see cref="Providers.KeycloakServiceAccountProvider"/> implement this interface so
/// that <see cref="VaultSecretResolver"/> can reuse the authenticated client they
/// already maintain.
/// </summary>
public interface IVaultKvReader
{
    bool IsAvailable();

    /// <summary>
    /// Reads a single field from a KV v2 secret at an arbitrary <paramref name="path"/>
    /// relative to the configured mount point.
    /// Returns <c>null</c> when the path or field is not found.
    /// </summary>
    Task<string?> ReadKvAsync(string path, string field, CancellationToken ct = default);
}
