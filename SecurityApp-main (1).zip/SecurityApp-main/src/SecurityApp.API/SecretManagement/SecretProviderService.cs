namespace SecurityApp.API.SecretManagement;

/// <summary>
/// Manages multiple secret providers with fallback chain
/// Tries providers in priority order until a secret is found
/// </summary>
public class SecretProviderService
{
    private readonly IEnumerable<ISecretProvider> _providers;
    private readonly ILogger<SecretProviderService> _logger;

    public SecretProviderService(
        IEnumerable<ISecretProvider> providers,
        ILogger<SecretProviderService> logger)
    {
        _providers = providers.OrderBy(p => p.Priority).ToList();
        _logger = logger;

        LogAvailableProviders();
    }

    /// <summary>
    /// Get a secret value trying all available providers in priority order
    /// </summary>
    public async Task<string?> GetSecretAsync(string key)
    {
        foreach (var provider in _providers.Where(p => p.IsAvailable()))
        {
            try
            {
                var value = await provider.GetSecretAsync(key);
                if (!string.IsNullOrEmpty(value))
                {
                    _logger.LogDebug(
                        "Secret '{Key}' found in provider '{Provider}'",
                        key, provider.ProviderName);
                    return value;
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex,
                    "Provider '{Provider}' failed to retrieve secret '{Key}'. Trying next provider...",
                    provider.ProviderName, key);
            }
        }

        _logger.LogWarning("Secret '{Key}' not found in any available provider", key);
        return null;
    }

    /// <summary>
    /// Get all secrets from all providers (merged with priority)
    /// </summary>
    public async Task<IDictionary<string, string>> GetAllSecretsAsync()
    {
        var allSecrets = new Dictionary<string, string>();

        // Process in reverse priority order (low priority first)
        // This way higher priority providers override lower ones
        foreach (var provider in _providers.Where(p => p.IsAvailable()).Reverse())
        {
            try
            {
                var secrets = await provider.GetAllSecretsAsync();
                foreach (var kvp in secrets)
                {
                    allSecrets[kvp.Key] = kvp.Value;
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex,
                    "Provider '{Provider}' failed to retrieve all secrets",
                    provider.ProviderName);
            }
        }

        return allSecrets;
    }

    /// <summary>
    /// Get list of available providers
    /// </summary>
    public IEnumerable<string> GetAvailableProviders()
    {
        return _providers
            .Where(p => p.IsAvailable())
            .OrderBy(p => p.Priority)
            .Select(p => $"{p.ProviderName} (Priority: {p.Priority})");
    }

    private void LogAvailableProviders()
    {
        var available = _providers.Where(p => p.IsAvailable()).ToList();
        var unavailable = _providers.Where(p => !p.IsAvailable()).ToList();

        if (available.Any())
        {
            _logger.LogInformation(
                "Secret providers available (in priority order): {Providers}",
                string.Join(", ", available.OrderBy(p => p.Priority).Select(p => p.ProviderName)));
        }

        if (unavailable.Any())
        {
            _logger.LogDebug(
                "Secret providers unavailable: {Providers}",
                string.Join(", ", unavailable.Select(p => p.ProviderName)));
        }

        if (!available.Any())
        {
            _logger.LogWarning("No secret providers are available! Using default configuration only.");
        }
    }
}
