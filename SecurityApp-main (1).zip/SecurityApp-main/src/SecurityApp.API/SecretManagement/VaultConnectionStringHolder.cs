using Microsoft.Data.SqlClient;

namespace SecurityApp.API.SecretManagement;

/// <summary>
/// Thread-safe singleton that holds the current Vault-issued database connection string
/// and the original lease duration so <see cref="VaultCredentialRenewalService"/> can
/// schedule the next renewal at 75 % of the lease.
///
/// <see cref="VaultCredentialRenewalService"/> writes here; the <c>AddDbContext</c> factory
/// in <c>Program.cs</c> reads <see cref="Current"/> on every new DI scope (every HTTP
/// request), so credential rotation is seamless — no app restart required.
/// </summary>
public sealed class VaultConnectionStringHolder
{
    private volatile string? _current;
    private volatile int     _leaseDurationSeconds;

    /// <summary>The fully assembled, credential-bearing connection string, or <c>null</c> when Vault has not yet issued creds.</summary>
    public string? Current              => _current;

    /// <summary>Vault lease duration (seconds) from the most recent credential issuance.</summary>
    public int     LeaseDurationSeconds => _leaseDurationSeconds;

    /// <summary>Atomically replaces the live connection string and its associated lease duration.</summary>
    public void Update(string connectionString, int leaseDurationSeconds)
    {
        _current              = connectionString;
        _leaseDurationSeconds = leaseDurationSeconds;

        // Clear all pooled SqlConnections bearing the expired credential.
        // Without this, SQL Server rejects stale pooled connections one by one
        // at their 30s timeout — causing up to 60s of 503s after rotation.
        SqlConnection.ClearAllPools();
    }
}
