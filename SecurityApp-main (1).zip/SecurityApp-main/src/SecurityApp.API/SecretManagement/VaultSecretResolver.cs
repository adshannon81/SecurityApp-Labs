using SecurityApp.Core.Import.Interfaces;

namespace SecurityApp.API.SecretManagement;

/// <summary>
/// Resolves <c>vault:path#field</c> references to their runtime values by querying
/// HashiCorp Vault KV v2 via the project's already-authenticated <see cref="IVaultKvReader"/>.
///
/// Reference format (case-insensitive prefix, case-sensitive path and field):
///   vault:{path}#{field}
///   e.g. "vault:sftp/bloomberg#host"
///        "vault:sftp/bloomberg#password"
///
/// Any string that does not start with "vault:" is returned unchanged, so literal
/// values and environment-variable overrides continue to work without modification.
/// </summary>
public sealed class VaultSecretResolver : ISecretResolver
{
    private const string VaultPrefix = "vault:";

    private readonly IVaultKvReader                  _kvReader;
    private readonly ILogger<VaultSecretResolver>    _logger;

    public VaultSecretResolver(IVaultKvReader kvReader, ILogger<VaultSecretResolver> logger)
    {
        _kvReader = kvReader;
        _logger   = logger;
    }

    /// <summary>
    /// Parses a <c>vault:{path}#{field}</c> reference into its components.
    /// Returns <c>null</c> when the value is not a Vault reference.
    /// </summary>
    public static (string Path, string Field)? ParseReference(string? value)
    {
        if (string.IsNullOrEmpty(value) ||
            !value.StartsWith(VaultPrefix, StringComparison.OrdinalIgnoreCase))
            return null;

        var body  = value[VaultPrefix.Length..];
        var hash  = body.LastIndexOf('#');
        if (hash <= 0 || hash == body.Length - 1)
            return null;

        return (body[..hash], body[(hash + 1)..]);
    }

    /// <inheritdoc/>
    public async Task<string> ResolveAsync(string? value, CancellationToken ct = default)
    {
        var parsed = ParseReference(value);
        if (parsed is null)
            return value ?? string.Empty;

        var (path, field) = parsed.Value;

        if (!_kvReader.IsAvailable())
        {
            _logger.LogWarning(
                "VaultSecretResolver: Vault is not available — returning empty string for reference '{Value}'.",
                value);
            return string.Empty;
        }

        var resolved = await _kvReader.ReadKvAsync(path, field, ct);
        if (resolved is null)
        {
            _logger.LogWarning(
                "VaultSecretResolver: field '{Field}' not found at KV path '{Path}'.",
                field, path);
            return string.Empty;
        }

        return resolved;
    }
}
