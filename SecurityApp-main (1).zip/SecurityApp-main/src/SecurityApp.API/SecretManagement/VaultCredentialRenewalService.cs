﻿using VaultSharp.Core;

namespace SecurityApp.API.SecretManagement;

/// <summary>
/// Hosted service that keeps Vault-issued database credentials fresh for the lifetime
/// of the application.
///
/// When <see cref="SecretProviderOptions.VaultDatabaseRole"/> is configured the service
/// operates in <em>dynamic-credential mode</em>: it calls the Vault database secrets
/// engine (<c>database/creds/{role}</c>) and writes the new connection string into
/// <see cref="VaultConnectionStringHolder"/> before the current lease expires.
/// The <c>AddDbContext</c> factory in <c>Program.cs</c> reads from the holder on every
/// new DI scope, so all subsequent HTTP requests transparently use the refreshed
/// connection string without any app restart.
///
/// When <c>VaultDatabaseRole</c> is empty (or <c>IVaultDatabaseProvider</c> is not
/// available) the service falls back to refreshing KV secrets every 5 minutes.
///
/// Renewal failures use exponential back-off (up to 5 retries) and are logged at
/// Critical level so alerting systems can detect a credential outage before the
/// current lease fully expires.
/// </summary>
public sealed class VaultCredentialRenewalService : BackgroundService
{
    private readonly SecretProviderService                   _secretService;
    private readonly SecretProviderOptions                   _options;
    private readonly VaultConnectionStringHolder             _holder;
    private readonly IVaultDatabaseProvider                  _vaultDbProvider;
    private readonly ILogger<VaultCredentialRenewalService>  _logger;

    private const int MaxRetries = 5;

    public VaultCredentialRenewalService(
        SecretProviderService                   secretService,
        SecretProviderOptions                   options,
        VaultConnectionStringHolder             holder,
        IVaultDatabaseProvider                  vaultDbProvider,
        ILogger<VaultCredentialRenewalService>  logger)
    {
        _secretService   = secretService;
        _options         = options;
        _holder          = holder;
        _vaultDbProvider = vaultDbProvider;
        _logger          = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Vault credential renewal service started");

        if (!string.IsNullOrEmpty(_options.VaultDatabaseRole) && _vaultDbProvider.IsAvailable())
            await RunDatabaseCredentialLoopAsync(stoppingToken);
        else
            await RunKvRefreshLoopAsync(stoppingToken);

        _logger.LogInformation("Vault credential renewal service stopped");
    }

    // -- Dynamic database-credential renewal -------------------------------------

    private async Task RunDatabaseCredentialLoopAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            // Schedule renewal at 75 % of the current lease (min 30 s, max 1 h)
            var leaseSecs  = _holder.LeaseDurationSeconds > 0 ? _holder.LeaseDurationSeconds : 3600;
            var renewAfter = TimeSpan.FromSeconds(Math.Clamp(leaseSecs * 0.75, 30, 3600));

            _logger.LogDebug(
                "Vault DB credential renewal scheduled in {Seconds}s (lease: {Lease}s)",
                (int)renewAfter.TotalSeconds, leaseSecs);

            await SafeDelay(renewAfter, ct);
            if (ct.IsCancellationRequested) break;

            await FetchAndUpdateWithRetryAsync(ct);
        }
    }

    private async Task FetchAndUpdateWithRetryAsync(CancellationToken ct)
    {
        var backoff = TimeSpan.FromSeconds(15);

        for (int attempt = 1; attempt <= MaxRetries; attempt++)
        {
            try
            {
                var (cs, lease) = await _vaultDbProvider.GetDatabaseConnectionStringAsync(ct);
                _holder.Update(cs, lease);
                _logger.LogInformation(
                    "Vault DB credentials renewed (lease: {Lease}s, attempt: {Attempt})",
                    lease, attempt);
                return;
            }
            catch (VaultApiException vex) when (vex.HttpStatusCode == System.Net.HttpStatusCode.Forbidden)
            {
                // 403 = Vault token has expired (token_max_ttl reached). VaultSharp could not renew
                // it automatically. Re-initialize the AppRole client to trigger a fresh login,
                // then let the loop retry immediately (no back-off needed -- re-login is the fix).
                _logger.LogWarning(
                    "Vault token expired (403) on DB renewal attempt {Attempt} -- re-authenticating via AppRole.",
                    attempt);

                if (_vaultDbProvider is Providers.AppRoleVaultProvider appRoleProvider)
                    appRoleProvider.Reinitialize();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "Vault DB renewal attempt {Attempt}/{Max} failed", attempt, MaxRetries);

                if (attempt == MaxRetries)
                {
                    _logger.LogCritical(
                        "All {Max} Vault DB renewal attempts failed -- the current credential " +
                        "lease may expire soon. Check Vault connectivity.", MaxRetries);
                    return;
                }

                await SafeDelay(backoff, ct);
                backoff = TimeSpan.FromTicks(backoff.Ticks * 2); // exponential back-off
            }
        }
    }

    // -- Fallback: KV secret refresh (no database role configured) ---------------

    private async Task RunKvRefreshLoopAsync(CancellationToken ct)
    {
        _logger.LogInformation(
            "VaultDatabaseRole is not configured -- falling back to KV secret refresh every 5 minutes");

        // Do an immediate refresh on start so the holder stays current if
        // secrets were rotated between the startup bootstrap and the first
        // scheduled renewal cycle.
        await RefreshKvAsync();

        while (!ct.IsCancellationRequested)
        {
            await SafeDelay(TimeSpan.FromMinutes(5), ct);
            if (ct.IsCancellationRequested) break;
            await RefreshKvAsync();
        }
    }

    private async Task RefreshKvAsync()
    {
        try
        {
            var secrets = await _secretService.GetAllSecretsAsync();
            _logger.LogDebug("Vault KV renewal: {Count} secret(s) refreshed", secrets.Count);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Vault KV renewal cycle failed");
        }
    }

    private static async Task SafeDelay(TimeSpan delay, CancellationToken ct)
    {
        try { await Task.Delay(delay, ct); }
        catch (OperationCanceledException) { /* shutting down cleanly */ }
    }
}
