namespace SecurityApp.API.SecretManagement;

/// <summary>
/// Thread-safe singleton that holds the current Vault-issued RabbitMQ credentials.
/// Populated during app startup bootstrap (before Wolverine's transport starts).
/// Wolverine captures these via <c>Func&lt;string?&gt;</c> lambdas in WolverineExtensions
/// so the values are read lazily at transport-start time, after the holder is populated.
/// </summary>
public sealed class VaultRabbitMqCredentialHolder
{
    private volatile string? _username;
    private volatile string? _password;
    private volatile int     _leaseDurationSeconds;

    public string? Username            => _username;
    public string? Password            => _password;
    public int     LeaseDurationSeconds => _leaseDurationSeconds;
    public bool    IsPopulated          => _username is not null;

    public void Update(string username, string password, int leaseDurationSeconds)
    {
        _username             = username;
        _password             = password;
        _leaseDurationSeconds = leaseDurationSeconds;
    }
}
