﻿using SecurityApp.API.SecretManagement.Providers;
using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Core.Import.Services;

namespace SecurityApp.API.SecretManagement;

/// <summary>
/// Extension methods to easily register secret providers
/// Supports plugin-based approach: start simple, add providers as needed
/// </summary>
public static class SecretProviderExtensions
{
    /// <summary>
    /// Add secret provider system with default configuration
    /// Includes: User Secrets (dev) + Environment Variables (always)
    /// FREE - No additional packages required
    /// </summary>
    public static IServiceCollection AddSecretProviders(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        // Load options from configuration
        var options = configuration.GetSection("SecretProviders").Get<SecretProviderOptions>()
            ?? new SecretProviderOptions();

        services.AddSingleton(options);

        // Register built-in providers (always available)
        if (options.EnableEnvironmentVariables)
        {
            services.AddSingleton<ISecretProvider, EnvironmentVariableProvider>();
        }

        if (options.EnableUserSecrets)
        {
            services.AddSingleton<ISecretProvider, UserSecretsProvider>();
        }

        // Register optional providers (require additional packages)
        if (options.EnableAzureKeyVault)
        {
            services.AddSingleton<ISecretProvider, AzureKeyVaultProvider>();
        }

        if (options.EnableHashiCorpVault)
        {
            // Singleton holders written during startup bootstrap;
            // read by the AddDbContext factory and Wolverine transport on startup.
            services.AddSingleton<VaultConnectionStringHolder>();
            services.AddSingleton<VaultRabbitMqCredentialHolder>();

            if (options.EnableKeycloakVaultAuth)
            {
                // Passwordless: Keycloak service-account JWT → Vault JWT-auth method.
                // Register as concrete type first so both interface registrations
                // share the same singleton instance (no double-construction).
                services.AddHttpClient();
                services.AddSingleton<KeycloakServiceAccountProvider>();
                services.AddSingleton<ISecretProvider>(
                    sp => sp.GetRequiredService<KeycloakServiceAccountProvider>());
                services.AddSingleton<IVaultDatabaseProvider>(
                    sp => sp.GetRequiredService<KeycloakServiceAccountProvider>());
                services.AddSingleton<IVaultKvReader>(
                    sp => sp.GetRequiredService<KeycloakServiceAccountProvider>());
            }
            else if (options.EnableAppRoleAuth)
            {
                // AppRole: exchanging RoleID + reusable SecretID (num_uses=0, no TTL)
                // for a short-lived Vault token.  RoleID + SecretID live in .env and
                // are injected via docker-compose.override.yml.
                services.AddSingleton<AppRoleVaultProvider>();
                services.AddSingleton<ISecretProvider>(
                    sp => sp.GetRequiredService<AppRoleVaultProvider>());
                services.AddSingleton<IVaultDatabaseProvider>(
                    sp => sp.GetRequiredService<AppRoleVaultProvider>());
                services.AddSingleton<IVaultRabbitMqProvider>(
                    sp => sp.GetRequiredService<AppRoleVaultProvider>());
                services.AddSingleton<IVaultKvReader>(
                    sp => sp.GetRequiredService<AppRoleVaultProvider>());
            }
            else
            {
                // Token-based: VAULT_TOKEN or VaultToken in appsettings.
                services.AddSingleton<HashiCorpVaultProvider>();
                services.AddSingleton<ISecretProvider>(
                    sp => sp.GetRequiredService<HashiCorpVaultProvider>());
                services.AddSingleton<IVaultDatabaseProvider>(
                    sp => sp.GetRequiredService<HashiCorpVaultProvider>());
                services.AddSingleton<IVaultKvReader>(
                    sp => sp.GetRequiredService<HashiCorpVaultProvider>());
            }

            // Background renewal keeps Vault DB leases alive for long-running containers.
            services.AddHostedService<VaultCredentialRenewalService>();

            // Vault-backed secret resolver for transport credentials.
            services.AddSingleton<ISecretResolver, VaultSecretResolver>();
        }
        else
        {
            // Vault disabled — transport credentials are stored as literals.
            services.AddSingleton<ISecretResolver, LiteralSecretResolver>();
        }

        // Register the provider service (manages fallback chain)
        services.AddSingleton<SecretProviderService>();

        return services;
    }

    /// <summary>
    /// Add custom secret provider
    /// Use this to add your own implementations
    /// </summary>
    public static IServiceCollection AddSecretProvider<TProvider>(this IServiceCollection services)
        where TProvider : class, ISecretProvider
    {
        services.AddSingleton<ISecretProvider, TProvider>();
        return services;
    }

    /// <summary>
    /// Get connection string from secret providers with fallback to appsettings
    /// Priority: Secret Providers - appsettings.json - default value
    /// </summary>
    public static async Task<string> GetConnectionStringAsync(
        this SecretProviderService secretService,
        IConfiguration configuration,
        string name,
        string defaultValue = "")
    {
        // Try secret providers first
        var secretKey = $"ConnectionStrings:{name}";
        var value = await secretService.GetSecretAsync(secretKey);

        // Fallback to appsettings
        if (string.IsNullOrEmpty(value))
        {
            value = configuration.GetConnectionString(name);
        }

        // Fallback to default
        return value ?? defaultValue;
    }

    /// <summary>
    /// Get configuration value from secret providers with fallback to appsettings
    /// Priority: Secret Providers - appsettings.json - default value
    /// </summary>
    public static async Task<string> GetConfigurationValueAsync(
        this SecretProviderService secretService,
        IConfiguration configuration,
        string key,
        string defaultValue = "")
    {
        // Try secret providers first
        var value = await secretService.GetSecretAsync(key);

        // Fallback to appsettings
        if (string.IsNullOrEmpty(value))
        {
            value = configuration[key];
        }

        // Fallback to default
        return value ?? defaultValue;
    }
}
