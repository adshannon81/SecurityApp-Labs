using System.Text.Json;
using VaultSharp;
using VaultSharp.V1.AuthMethods.AppRole;

namespace SecurityApp.API.SecretManagement.Providers;

/// <summary>
/// Reads secrets from HashiCorp Vault using AppRole authentication.
///
/// AppRole replaces the static long-lived VAULT_TOKEN with two values:
///   RoleID   — non-secret permanent identifier (stored in docker-compose.override.yml)
///   SecretID — obtained by unwrapping a single-use, 5-minute wrapping token (VAULT_WRAP_TOKEN)
///              generated fresh by deploy.ps1 on every deployment.
///
/// Flow:
///   1. deploy.ps1 calls: vault write -wrap-ttl=5m -f auth/approle/…/secret-id
///      → returns a wrapping token (VAULT_WRAP_TOKEN), valid for 5 min, single-use.
///   2. API starts, calls V1.System.UnwrapAsync with the wrapping token → real SecretID.
///   3. API exchanges RoleID + SecretID for a short-lived Vault token (1h TTL, 4h max).
///   4. SecretID is consumed; the wrapping token is burned. Fully logged in Vault audit.
///
/// Backward-compatible: falls back to VAULT_SECRET_ID if VAULT_WRAP_TOKEN is absent.
///
/// Enable via:
///   SecretProviders:EnableHashiCorpVault = true
///   SecretProviders:EnableAppRoleAuth    = true
///   SecretProviders:VaultAddress         = "http://vault:8200"
///   SecretProviders:VaultRoleId          = (or VAULT_ROLE_ID env var)
///   SecretProviders:VaultWrapToken       = (or VAULT_WRAP_TOKEN env var)  ← preferred
///   SecretProviders:VaultSecretId        = (or VAULT_SECRET_ID env var)   ← fallback
///
/// Priority 20 — same as HashiCorpVaultProvider (only one is registered at a time).
/// </summary>
public class AppRoleVaultProvider : ISecretProvider, IVaultDatabaseProvider, IVaultRabbitMqProvider, IVaultKvReader
{
    private readonly SecretProviderOptions _options;
    private readonly ILogger<AppRoleVaultProvider> _logger;
    private IVaultClient? _vaultClient;

    public string ProviderName => "HashiCorpVaultAppRole";
    public int Priority => 20;

    public AppRoleVaultProvider(
        SecretProviderOptions options,
        ILogger<AppRoleVaultProvider> logger)
    {
        _options = options;
        _logger  = logger;
        Initialize();
    }

    // Paths on the vault_shared Docker volume (mounted at /vault/shared in both containers).
    // The Vault entrypoint writes a fresh wrap token here on every Vault restart.
    // The API writes the unwrapped SecretID here after first auth so that
    // subsequent API-only restarts don't require Vault to also restart.
    private const string SharedWrapTokenFile = "/vault/shared/api-wrap-token";
    private const string SharedSecretIdFile  = "/vault/shared/api-secret-id";

    private void Initialize()
    {
        if (!_options.EnableHashiCorpVault || string.IsNullOrEmpty(_options.VaultAddress))
            return;

        var roleId = _options.VaultRoleId ?? Environment.GetEnvironmentVariable("VAULT_ROLE_ID");

        // SecretID resolution — three fallbacks in priority order:
        //
        //  1. VAULT_WRAP_TOKEN env var  — set by deploy.ps1 / vault-rotate.ps1 (first deploy or manual rotate)
        //  2. /vault/shared/api-wrap-token — written by Vault entrypoint on every Vault restart
        //  3. /vault/shared/api-secret-id  — written by this provider after a successful unwrap;
        //     survives API-only restarts as long as the SecretID TTL has not expired
        //
        // When 1 or 2 succeeds the unwrapped SecretID is persisted to path 3 for future restarts.

        string? secretId = null;

        // Try each wrap-token source in order; stop as soon as one succeeds.
        IEnumerable<(string source, string? token)> wrapTokenCandidates =
        [
            ("env var",       _options.VaultWrapToken ?? Environment.GetEnvironmentVariable("VAULT_WRAP_TOKEN")),
            ("shared volume", ReadFileSafe(SharedWrapTokenFile)),
        ];

        foreach (var (source, token) in wrapTokenCandidates)
        {
            if (string.IsNullOrEmpty(token)) continue;
            _logger.LogInformation("Vault: attempting unwrap using {Source}.", source);
            secretId = UnwrapSecretId(token);
            if (!string.IsNullOrEmpty(secretId))
            {
                PersistSecretId(secretId);
                break;
            }
        }

        if (string.IsNullOrEmpty(secretId))
        {
            secretId = ReadFileSafe(SharedSecretIdFile);
            if (!string.IsNullOrEmpty(secretId))
                _logger.LogInformation("Vault: using persisted SecretID from shared volume ({Path}).", SharedSecretIdFile);
        }

        // ── Break-glass fallback ──────────────────────────────────────────────
        // VAULT_SECRET_ID (or SecretProviders:VaultSecretId) is a plain, unwrapped
        // SecretID. It is NOT used in normal operations — generate one with:
        //   .\scripts\vault-rotate.ps1 -Action GenerateBreakGlassSecretId
        // then uncomment VAULT_SECRET_ID= in .env and restart the API.
        // Every use logs CRITICAL so SIEM/alerting fires immediately (SOX audit trail).
        // Remove / re-comment VAULT_SECRET_ID from .env as soon as the incident is resolved.
        if (string.IsNullOrEmpty(secretId))
        {
            var breakGlass = _options.VaultSecretId ?? Environment.GetEnvironmentVariable("VAULT_SECRET_ID");
            if (!string.IsNullOrEmpty(breakGlass))
            {
                secretId = breakGlass;
                _logger.LogCritical(
                    "VAULT BREAK-GLASS ACTIVE: authenticating with plain VAULT_SECRET_ID. " +
                    "Normal wrap-token auth failed or was bypassed. " +
                    "Resolve the underlying issue and disable VAULT_SECRET_ID in .env immediately. " +
                    "Run: .\\scripts\\vault-rotate.ps1 -Action RefreshSecretId");
            }
        }

        if (string.IsNullOrEmpty(roleId) || string.IsNullOrEmpty(secretId))
        {
            _logger.LogWarning(
                "AppRole Vault auth is enabled but RoleID or SecretID is missing. " +
                "Set SecretProviders:VaultRoleId + VaultWrapToken, or VAULT_ROLE_ID + VAULT_WRAP_TOKEN. " +
                "Run deploy.ps1 or scripts/vault-rotate.ps1 -Action RefreshSecretId to generate a fresh wrapped SecretID.");
            return;
        }

        try
        {
            var authMethod = new AppRoleAuthMethodInfo(roleId, secretId);
            var settings   = new VaultClientSettings(_options.VaultAddress, authMethod);
            _vaultClient   = new VaultClient(settings);
            _logger.LogInformation(
                "HashiCorp Vault AppRole client initialised at {Address} (RoleID: {RoleId})",
                _options.VaultAddress, roleId);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Failed to initialise HashiCorp Vault AppRole client at {Address}", _options.VaultAddress);
        }
    }

    private void PersistSecretId(string secretId)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(SharedSecretIdFile)!);
            File.WriteAllText(SharedSecretIdFile, secretId);
            if (!OperatingSystem.IsWindows())
            {
                using var p = System.Diagnostics.Process.Start("chmod", $"600 {SharedSecretIdFile}");
                p?.WaitForExit(2000);
            }
            _logger.LogDebug("Vault: SecretID persisted to {Path} for restart recovery.", SharedSecretIdFile);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Vault: could not persist SecretID to {Path} — restart recovery will not work.", SharedSecretIdFile);
        }
    }

    private string? ReadFileSafe(string path)
    {
        try   { return File.Exists(path) ? File.ReadAllText(path).Trim() : null; }
        catch { return null; }
    }

    /// <summary>
    /// Unwraps a Vault response-wrapping token to retrieve the real AppRole SecretID.
    /// The wrapping token is single-use and expires after 5 minutes (set by deploy.ps1).
    /// On success the token is permanently consumed — it cannot be replayed.
    /// </summary>
    private string? UnwrapSecretId(string wrappingToken)
    {
        try
        {
            using var http    = new HttpClient { Timeout = TimeSpan.FromSeconds(10) };
            var request       = new HttpRequestMessage(
                HttpMethod.Post,
                $"{_options.VaultAddress!.TrimEnd('/')}/v1/sys/wrapping/unwrap");
            request.Headers.Add("X-Vault-Token", wrappingToken);

            var response = http.SendAsync(request).GetAwaiter().GetResult();

            if (!response.IsSuccessStatusCode)
            {
                var body = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                _logger.LogError(
                    "Vault unwrap returned {StatusCode}. " +
                    "The wrapping token may be expired (5 min TTL) or already consumed. " +
                    "Run deploy.ps1 or scripts/vault-rotate.ps1 -Action RefreshSecretId. Response: {Body}",
                    (int)response.StatusCode, body);
                return null;
            }

            var json = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
            using var doc = JsonDocument.Parse(json);

            if (doc.RootElement.TryGetProperty("data", out var data) &&
                data.TryGetProperty("secret_id", out var sid))
            {
                _logger.LogInformation("Vault AppRole SecretID successfully unwrapped from wrapping token.");
                return sid.GetString();
            }

            _logger.LogWarning("Vault unwrap succeeded but 'secret_id' was not found in the response data.");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Failed to unwrap Vault AppRole SecretID. " +
                "The wrapping token may be expired (5 min TTL) or already consumed. " +
                "Run deploy.ps1 or scripts/vault-rotate.ps1 -Action RefreshSecretId to generate a new one.");
        }

        return null;
    }

    public bool IsAvailable() =>
        _options.EnableHashiCorpVault &&
        !string.IsNullOrEmpty(_options.VaultAddress) &&
        _vaultClient is not null;

    /// <summary>
    /// Re-authenticates to Vault using the persisted SecretID from the shared volume.
    /// Called by <see cref="VaultCredentialRenewalService"/> when a Vault API call
    /// returns 403 (permission denied), which indicates the current Vault token has
    /// expired and VaultSharp was unable to renew it automatically.
    /// </summary>
    public bool Reinitialize()
    {
        var roleId   = _options.VaultRoleId ?? Environment.GetEnvironmentVariable("VAULT_ROLE_ID");
        var secretId = ReadFileSafe(SharedSecretIdFile);

        if (string.IsNullOrEmpty(roleId) || string.IsNullOrEmpty(secretId))
        {
            _logger.LogError(
                "Vault re-login failed: RoleID or persisted SecretID is missing. " +
                "Run scripts/vault-rotate.ps1 -Action RefreshSecretId to restore authentication.");
            return false;
        }

        try
        {
            var authMethod = new AppRoleAuthMethodInfo(roleId, secretId);
            var settings   = new VaultClientSettings(_options.VaultAddress!, authMethod);
            _vaultClient   = new VaultClient(settings);
            _logger.LogInformation(
                "Vault AppRole client re-initialized (token expired and renewed via re-login). RoleID: {RoleId}",
                roleId);
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Vault AppRole re-initialization failed");
            return false;
        }
    }

    public async Task<string?> GetSecretAsync(string key)
    {
        if (!IsAvailable() || _vaultClient is null)
            return null;

        try
        {
            var secret = await _vaultClient.V1.Secrets.KeyValue.V2.ReadSecretAsync(
                path:       _options.VaultSecretPath,
                mountPoint: _options.VaultMountPoint);

            if (secret?.Data?.Data?.TryGetValue(key, out var value) == true)
                return value?.ToString();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "AppRole Vault: failed to get secret '{Key}'", key);
        }
        return null;
    }

    public async Task<IDictionary<string, string>> GetAllSecretsAsync()
    {
        if (!IsAvailable() || _vaultClient is null)
            return new Dictionary<string, string>();

        try
        {
            var secret = await _vaultClient.V1.Secrets.KeyValue.V2.ReadSecretAsync(
                path:       _options.VaultSecretPath,
                mountPoint: _options.VaultMountPoint);

            if (secret?.Data?.Data is not null)
                return secret.Data.Data
                    .Where(kvp => kvp.Value is not null)
                    .ToDictionary(kvp => kvp.Key, kvp => kvp.Value!.ToString()!);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "AppRole Vault: failed to read all secrets");
        }
        return new Dictionary<string, string>();
    }

    public async Task<(string ConnectionString, int LeaseDurationSeconds)> GetDatabaseConnectionStringAsync(
        CancellationToken ct = default)
    {
        if (!IsAvailable() || _vaultClient is null)
            throw new InvalidOperationException(
                "AppRoleVaultProvider is not available. Check EnableHashiCorpVault, EnableAppRoleAuth, VaultAddress, and VAULT_ROLE_ID / VAULT_SECRET_ID.");

        var secret = await _vaultClient.V1.Secrets.Database.GetCredentialsAsync(
            _options.VaultDatabaseRole);

        var cs = AssembleConnectionString(secret.Data.Username, secret.Data.Password);
        return (cs, (int)secret.LeaseDurationSeconds);
    }

    public async Task<(string Username, string Password, int LeaseDurationSeconds)> GetRabbitMqCredentialsAsync(
        CancellationToken ct = default)
    {
        if (!IsAvailable() || _vaultClient is null)
            throw new InvalidOperationException(
                "AppRoleVaultProvider is not available. Check EnableHashiCorpVault, EnableAppRoleAuth, VaultAddress, and VAULT_ROLE_ID / VAULT_SECRET_ID.");

        var secret = await _vaultClient.V1.Secrets.RabbitMQ.GetCredentialsAsync(
            _options.VaultRabbitMqRole);

        return (secret.Data.Username, secret.Data.Password, (int)secret.LeaseDurationSeconds);
    }

    private string AssembleConnectionString(string username, string password)
    {
        var @base    = _options.VaultDatabaseConnectionBase.TrimEnd(';');
        var provider = (_options.VaultDatabaseProvider ?? "postgresql").ToLower();
        return provider switch
        {
            "postgresql" => $"{@base};Username={username};Password={password}",
            "sqlserver"  => $"{@base};User Id={username};Password={password}",
            _            => throw new InvalidOperationException(
                                $"Unknown VaultDatabaseProvider '{provider}'. Use 'postgresql' or 'sqlserver'.")
        };
    }

    public async Task<string?> ReadKvAsync(string path, string field, CancellationToken ct = default)
    {
        if (!IsAvailable() || _vaultClient is null)
            return null;

        try
        {
            var secret = await _vaultClient.V1.Secrets.KeyValue.V2.ReadSecretAsync(
                path: path, mountPoint: _options.VaultMountPoint);

            if (secret?.Data?.Data?.TryGetValue(field, out var value) == true)
                return value?.ToString();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "AppRole Vault: failed to read path '{Path}' field '{Field}'", path, field);
        }
        return null;
    }
}
