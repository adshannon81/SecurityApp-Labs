namespace SecurityApp.API.SecretManagement.Providers;

/// <summary>
/// Reads secrets from Environment Variables
/// FREE - Works everywhere (Windows, Linux, Docker, Cloud)
/// Priority: 50 (medium priority in fallback chain)
/// </summary>
public class EnvironmentVariableProvider : ISecretProvider
{
    public string ProviderName => "EnvironmentVariables";
    public int Priority => 50;

    public bool IsAvailable() => true; // Always available

    public Task<string?> GetSecretAsync(string key)
    {
        // Support both hierarchical keys (ConnectionStrings:PostgreSQL)
        // and flat keys (ConnectionStrings__PostgreSQL)
        var value = Environment.GetEnvironmentVariable(key);
        
        if (string.IsNullOrEmpty(value))
        {
            // Try with double underscore separator (common in Docker/Linux)
            var flatKey = key.Replace(":", "__");
            value = Environment.GetEnvironmentVariable(flatKey);
        }

        return Task.FromResult(value);
    }

    public Task<IDictionary<string, string>> GetAllSecretsAsync()
    {
        var secrets = new Dictionary<string, string>();
        
        foreach (System.Collections.DictionaryEntry entry in Environment.GetEnvironmentVariables())
        {
            if (entry.Key != null && entry.Value != null)
            {
                secrets[entry.Key.ToString()!] = entry.Value.ToString()!;
            }
        }

        return Task.FromResult<IDictionary<string, string>>(secrets);
    }
}
