using System.Net.Http.Json;
using VaultSharp;
using VaultSharp.V1.AuthMethods.JWT;

namespace SecurityApp.API.SecretManagement.Providers;

/// <summary>
/// Authenticates to HashiCorp Vault using a Keycloak service-account JWT
/// (Vault JWT auth method) — no static VAULT_TOKEN required.
///
/// Enterprise passwordless pattern:
///   Keycloak client_credentials → access_token (JWT)
///   → Vault auth/jwt/login with bound role → time-limited Vault token
///   → KV secrets
///
/// Prerequisites (configured by scripts/vault-init.sh):
///   vault auth enable jwt
///   vault write auth/jwt/config
///       jwks_url="http://keycloak:8180/realms/securityapp/protocol/openid-connect/certs"
///       bound_issuer="http://keycloak:8180/realms/securityapp"
///   vault write auth/jwt/role/securityapp-api
///       bound_audiences="securityapp-vault"
///       user_claim="sub"  policies="securityapp-policy"  ttl="1h"
///
/// Enable via:
///   SecretProviders:EnableHashiCorpVault      = true
///   SecretProviders:EnableKeycloakVaultAuth   = true
///   SecretProviders:VaultAddress              = "http://vault:8200"
///   SecretProviders:KeycloakAuthority         = "http://keycloak:8180/realms/securityapp"
///   SecretProviders:VaultServiceAccountClientId     = "securityapp-vault"
///   SecretProviders:VaultServiceAccountClientSecret = "..."  (or env var)
/// </summary>
public sealed class KeycloakServiceAccountProvider : ISecretProvider, IVaultDatabaseProvider, IVaultKvReader
{
    private readonly SecretProviderOptions _options;
    private readonly IHttpClientFactory    _httpClientFactory;
    private readonly ILogger<KeycloakServiceAccountProvider> _logger;

    // Cached client — reused until expiry
    private IVaultClient? _vaultClient;
    private DateTime      _clientExpiry = DateTime.MinValue;

    public string ProviderName => "KeycloakVaultAuth";
    public int    Priority     => 15;   // higher priority than plain token (lower number wins)

    public KeycloakServiceAccountProvider(
        SecretProviderOptions       options,
        IHttpClientFactory          httpClientFactory,
        ILogger<KeycloakServiceAccountProvider> logger)
    {
        _options           = options;
        _httpClientFactory = httpClientFactory;
        _logger            = logger;
    }

    public bool IsAvailable() =>
        _options.EnableHashiCorpVault &&
        _options.EnableKeycloakVaultAuth &&
        !string.IsNullOrEmpty(_options.VaultAddress) &&
        !string.IsNullOrEmpty(_options.KeycloakAuthority) &&
        !string.IsNullOrEmpty(_options.VaultServiceAccountClientId);

    public async Task<string?> GetSecretAsync(string key)
    {
        var client = await EnsureClientAsync();
        if (client is null) return null;

        try
        {
            var secret = await client.V1.Secrets.KeyValue.V2.ReadSecretAsync(
                path:       _options.VaultSecretPath,
                mountPoint: _options.VaultMountPoint);

            if (secret?.Data?.Data?.TryGetValue(key, out var value) == true)
                return value?.ToString();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "KeycloakVaultAuth: failed to read secret '{Key}'", key);
        }

        return null;
    }

    public async Task<IDictionary<string, string>> GetAllSecretsAsync()
    {
        var client = await EnsureClientAsync();
        if (client is null) return new Dictionary<string, string>();

        try
        {
            var secret = await client.V1.Secrets.KeyValue.V2.ReadSecretAsync(
                path:       _options.VaultSecretPath,
                mountPoint: _options.VaultMountPoint);

            if (secret?.Data?.Data is not null)
                return secret.Data.Data
                    .Where(kvp => kvp.Value is not null)
                    .ToDictionary(kvp => kvp.Key, kvp => kvp.Value!.ToString()!);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "KeycloakVaultAuth: failed to read all secrets");
        }

        return new Dictionary<string, string>();
    }

    // ── IVaultDatabaseProvider ───────────────────────────────────────────────────

    /// <inheritdoc/>
    public async Task<(string ConnectionString, int LeaseDurationSeconds)> GetDatabaseConnectionStringAsync(
        CancellationToken ct = default)
    {
        var client = await EnsureClientAsync();
        if (client is null)
            throw new InvalidOperationException(
                "KeycloakServiceAccountProvider is not available — check Keycloak/Vault configuration.");

        var secret = await client.V1.Secrets.Database.GetCredentialsAsync(
            _options.VaultDatabaseRole);

        var cs = AssembleConnectionString(secret.Data.Username, secret.Data.Password);
        return (cs, (int)secret.LeaseDurationSeconds);
    }

    private string AssembleConnectionString(string username, string password)
    {
        var @base    = _options.VaultDatabaseConnectionBase.TrimEnd(';');
        var provider = (_options.VaultDatabaseProvider ?? "postgresql").ToLower();
        return provider switch
        {
            "postgresql" => $"{@base};Username={username};Password={password}",
            "sqlserver"  => $"{@base};User Id={username};Password={password}",
            _            => throw new InvalidOperationException(
                                $"Unknown VaultDatabaseProvider '{provider}'. Use 'postgresql' or 'sqlserver'.")
        };
    }

    // ── Internal Vault client lifecycle ──────────────────────────────────────

    private async Task<IVaultClient?> EnsureClientAsync()
    {
        if (!IsAvailable()) return null;

        // Reuse token until 5 minutes before TTL expires
        if (_vaultClient is not null && DateTime.UtcNow < _clientExpiry)
            return _vaultClient;

        try
        {
            var jwt = await ObtainServiceAccountJwtAsync();
            if (string.IsNullOrEmpty(jwt))
            {
                _logger.LogWarning("KeycloakVaultAuth: could not obtain service-account JWT from Keycloak");
                return null;
            }

            var authMethod = new JWTAuthMethodInfo(_options.VaultRoleName, jwt);
            var settings   = new VaultClientSettings(_options.VaultAddress!, authMethod);
            _vaultClient   = new VaultClient(settings);
            _clientExpiry  = DateTime.UtcNow.AddMinutes(55); // refresh before 1 h TTL ends

            _logger.LogInformation("KeycloakVaultAuth: Vault token refreshed via Keycloak");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "KeycloakVaultAuth: failed to renew Vault token");
            _vaultClient = null;
        }

        return _vaultClient;
    }

    /// <summary>
    /// Calls Keycloak's token endpoint using client_credentials to get a JWT
    /// that Vault's JWT auth method can verify.
    /// </summary>
    private async Task<string?> ObtainServiceAccountJwtAsync()
    {
        var tokenEndpoint =
            $"{_options.KeycloakAuthority!.TrimEnd('/')}/protocol/openid-connect/token";

        var form = new Dictionary<string, string>
        {
            ["grant_type"]    = "client_credentials",
            ["client_id"]     = _options.VaultServiceAccountClientId!,
            ["client_secret"] = _options.VaultServiceAccountClientSecret ?? "",
            ["audience"]      = "securityapp-vault",
        };

        var http = _httpClientFactory.CreateClient(nameof(KeycloakServiceAccountProvider));
        using var response = await http.PostAsync(tokenEndpoint, new FormUrlEncodedContent(form));

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning(
                "KeycloakVaultAuth: Keycloak token endpoint returned {Status} for client '{ClientId}'",
                (int)response.StatusCode, _options.VaultServiceAccountClientId);
            return null;
        }

        var payload = await response.Content.ReadFromJsonAsync<KeycloakTokenResponse>();
        return payload?.AccessToken;
    }

    private sealed record KeycloakTokenResponse(
        [property: System.Text.Json.Serialization.JsonPropertyName("access_token")]
        string? AccessToken);

    // ── IVaultKvReader ───────────────────────────────────────────────────────

    /// <inheritdoc/>
    public async Task<string?> ReadKvAsync(string path, string field, CancellationToken ct = default)
    {
        var client = await EnsureClientAsync();
        if (client is null) return null;

        try
        {
            var secret = await client.V1.Secrets.KeyValue.V2.ReadSecretAsync(
                path: path, mountPoint: _options.VaultMountPoint);

            if (secret?.Data?.Data?.TryGetValue(field, out var value) == true)
                return value?.ToString();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex,
                "KeycloakVaultAuth: failed to read field '{Field}' at KV path '{Path}'", field, path);
        }
        return null;
    }
}
