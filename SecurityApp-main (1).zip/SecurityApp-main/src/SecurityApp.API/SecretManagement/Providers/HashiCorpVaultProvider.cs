using VaultSharp;
using VaultSharp.V1.AuthMethods.Token;

namespace SecurityApp.API.SecretManagement.Providers;

/// <summary>
/// Reads secrets from HashiCorp Vault using static token authentication.
/// Enable via: SecretProviders:EnableHashiCorpVault = true
///             SecretProviders:VaultAddress         = "http://vault:8200"
///             SecretProviders:VaultToken or VAULT_TOKEN env var
///
/// For passwordless auth (Keycloak service-account → Vault JWT auth method)
/// set SecretProviders:EnableKeycloakVaultAuth = true — that activates
/// KeycloakServiceAccountProvider instead of this class.
/// Priority 20 (lower number = higher priority inside SecretProviderService).
/// </summary>
public class HashiCorpVaultProvider : ISecretProvider, IVaultDatabaseProvider, IVaultKvReader
{
    private readonly SecretProviderOptions _options;
    private readonly ILogger<HashiCorpVaultProvider> _logger;
    private IVaultClient? _vaultClient;

    public string ProviderName => "HashiCorpVault";
    public int Priority => 20;

    public HashiCorpVaultProvider(
        SecretProviderOptions options,
        ILogger<HashiCorpVaultProvider> logger)
    {
        _options = options;
        _logger  = logger;
        Initialize();
    }

    private void Initialize()
    {
        if (!_options.EnableHashiCorpVault || string.IsNullOrEmpty(_options.VaultAddress))
            return;

        var token = _options.VaultToken
                    ?? Environment.GetEnvironmentVariable("VAULT_TOKEN");

        if (string.IsNullOrEmpty(token))
        {
            _logger.LogWarning(
                "HashiCorp Vault is enabled but no token found. " +
                "Set SecretProviders:VaultToken in appsettings or the VAULT_TOKEN environment variable.");
            return;
        }

        try
        {
            var authMethod = new TokenAuthMethodInfo(token);
            var settings   = new VaultClientSettings(_options.VaultAddress, authMethod);
            _vaultClient   = new VaultClient(settings);
            _logger.LogInformation("HashiCorp Vault client initialised at {Address}", _options.VaultAddress);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to initialise HashiCorp Vault client at {Address}", _options.VaultAddress);
        }
    }

    public bool IsAvailable() =>
        _options.EnableHashiCorpVault &&
        !string.IsNullOrEmpty(_options.VaultAddress) &&
        _vaultClient is not null;

    public async Task<string?> GetSecretAsync(string key)
    {
        if (!IsAvailable() || _vaultClient is null)
            return null;

        try
        {
            var secret = await _vaultClient.V1.Secrets.KeyValue.V2.ReadSecretAsync(
                path:       _options.VaultSecretPath,
                mountPoint: _options.VaultMountPoint);

            if (secret?.Data?.Data?.TryGetValue(key, out var value) == true)
                return value?.ToString();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex,
                "Vault: failed to read secret '{Key}' from '{Mount}/{Path}'",
                key, _options.VaultMountPoint, _options.VaultSecretPath);
        }

        return null;
    }

    public async Task<IDictionary<string, string>> GetAllSecretsAsync()
    {
        if (!IsAvailable() || _vaultClient is null)
            return new Dictionary<string, string>();

        try
        {
            var secret = await _vaultClient.V1.Secrets.KeyValue.V2.ReadSecretAsync(
                path:       _options.VaultSecretPath,
                mountPoint: _options.VaultMountPoint);

            if (secret?.Data?.Data is not null)
                return secret.Data.Data
                    .Where(kvp => kvp.Value is not null)
                    .ToDictionary(kvp => kvp.Key, kvp => kvp.Value!.ToString()!);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Vault: failed to read all secrets from '{Mount}/{Path}'",
                _options.VaultMountPoint, _options.VaultSecretPath);
        }

        return new Dictionary<string, string>();
    }

    // ── IVaultDatabaseProvider ───────────────────────────────────────────────────

    /// <inheritdoc/>
    public async Task<(string ConnectionString, int LeaseDurationSeconds)> GetDatabaseConnectionStringAsync(
        CancellationToken ct = default)
    {
        if (!IsAvailable() || _vaultClient is null)
            throw new InvalidOperationException(
                "HashiCorpVaultProvider is not available. Check EnableHashiCorpVault, VaultAddress, and VAULT_TOKEN.");

        var secret = await _vaultClient.V1.Secrets.Database.GetCredentialsAsync(
            _options.VaultDatabaseRole);

        var cs = AssembleConnectionString(secret.Data.Username, secret.Data.Password);
        return (cs, (int)secret.LeaseDurationSeconds);
    }

    private string AssembleConnectionString(string username, string password)
    {
        var @base    = _options.VaultDatabaseConnectionBase.TrimEnd(';');
        var provider = (_options.VaultDatabaseProvider ?? "postgresql").ToLower();
        return provider switch
        {
            "postgresql" => $"{@base};Username={username};Password={password}",
            "sqlserver"  => $"{@base};User Id={username};Password={password}",
            _            => throw new InvalidOperationException(
                                $"Unknown VaultDatabaseProvider '{provider}'. Use 'postgresql' or 'sqlserver'.")
        };
    }

    // ── IVaultKvReader ───────────────────────────────────────────────────────

    /// <inheritdoc/>
    public async Task<string?> ReadKvAsync(string path, string field, CancellationToken ct = default)
    {
        if (!IsAvailable() || _vaultClient is null) return null;

        try
        {
            var secret = await _vaultClient.V1.Secrets.KeyValue.V2.ReadSecretAsync(
                path: path, mountPoint: _options.VaultMountPoint);

            if (secret?.Data?.Data?.TryGetValue(field, out var value) == true)
                return value?.ToString();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex,
                "Vault: failed to read field '{Field}' at KV path '{Path}'", field, path);
        }
        return null;
    }
}
