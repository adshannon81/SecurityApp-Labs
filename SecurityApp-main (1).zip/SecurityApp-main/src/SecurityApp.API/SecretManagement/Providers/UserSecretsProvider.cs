using Microsoft.Extensions.Configuration;

namespace SecurityApp.API.SecretManagement.Providers;

/// <summary>
/// Reads secrets from User Secrets (Development only)
/// FREE - Built into .NET SDK
/// Priority: 100 (lowest priority - development fallback)
/// </summary>
public class UserSecretsProvider : ISecretProvider
{
    private readonly IConfiguration _configuration;
    private readonly IWebHostEnvironment _environment;

    public string ProviderName => "UserSecrets";
    public int Priority => 100;

    public UserSecretsProvider(IConfiguration configuration, IWebHostEnvironment environment)
    {
        _configuration = configuration;
        _environment = environment;
    }

    public bool IsAvailable()
    {
        // Only available in Development environment
        return _environment.IsDevelopment();
    }

    public Task<string?> GetSecretAsync(string key)
    {
        if (!IsAvailable())
        {
            return Task.FromResult<string?>(null);
        }

        // Configuration already includes User Secrets if configured
        var value = _configuration[key];
        return Task.FromResult(value);
    }

    public Task<IDictionary<string, string>> GetAllSecretsAsync()
    {
        var secrets = new Dictionary<string, string>();

        if (!IsAvailable())
        {
            return Task.FromResult<IDictionary<string, string>>(secrets);
        }

        // User Secrets are already loaded into IConfiguration
        // We can't easily separate them out, so return empty
        return Task.FromResult<IDictionary<string, string>>(secrets);
    }
}
