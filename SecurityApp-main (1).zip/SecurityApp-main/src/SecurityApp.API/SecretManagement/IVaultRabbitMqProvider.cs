namespace SecurityApp.API.SecretManagement;

/// <summary>
/// Implemented by Vault-backed secret providers that can issue dynamic RabbitMQ
/// credentials via Vault's RabbitMQ secrets engine (GET rabbitmq/creds/{role}).
/// </summary>
public interface IVaultRabbitMqProvider
{
    bool IsAvailable();

    /// <summary>
    /// Calls Vault's RabbitMQ secrets engine to obtain a fresh (username, password) pair.
    /// The returned credentials are valid for <see cref="SecretProviderOptions.VaultRabbitMqRole"/>'s
    /// configured TTL (default 1h). They should be passed to the Wolverine transport at startup.
    /// </summary>
    Task<(string Username, string Password, int LeaseDurationSeconds)> GetRabbitMqCredentialsAsync(
        CancellationToken ct = default);
}
