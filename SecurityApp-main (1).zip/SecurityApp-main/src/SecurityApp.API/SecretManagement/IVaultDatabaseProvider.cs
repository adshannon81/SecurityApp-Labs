namespace SecurityApp.API.SecretManagement;

/// <summary>
/// Implemented by Vault-backed secret providers that can issue dynamic database
/// credentials via Vault's database secrets engine (GET database/creds/{role}).
///
/// Both <see cref="Providers.HashiCorpVaultProvider"/> (static token) and
/// <see cref="Providers.KeycloakServiceAccountProvider"/> (JWT/passwordless) implement this.
/// </summary>
public interface IVaultDatabaseProvider
{
    bool IsAvailable();

    /// <summary>
    /// Calls Vault's database secrets engine to obtain a fresh (username, password) pair,
    /// then assembles a ready-to-use ADO.NET connection string using
    /// <see cref="SecretProviderOptions.VaultDatabaseConnectionBase"/> as the host/database
    /// template and <see cref="SecretProviderOptions.VaultDatabaseProvider"/> to select
    /// the correct credential key names (Username/Password vs User Id/Password).
    /// </summary>
    /// <returns>
    /// A tuple of the assembled connection string and the Vault lease duration in seconds.
    /// The caller should schedule renewal at roughly 75 % of the lease duration.
    /// </returns>
    Task<(string ConnectionString, int LeaseDurationSeconds)> GetDatabaseConnectionStringAsync(
        CancellationToken ct = default);
}
