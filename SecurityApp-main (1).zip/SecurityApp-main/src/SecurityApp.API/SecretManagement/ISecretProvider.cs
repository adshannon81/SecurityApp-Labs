namespace SecurityApp.API.SecretManagement;

/// <summary>
/// Abstraction for different secret providers (User Secrets, Environment Variables, Key Vault, etc.)
/// Supports plugin-based architecture - add providers as needed via configuration
/// </summary>
public interface ISecretProvider
{
    /// <summary>
    /// Provider name for logging and identification
    /// </summary>
    string ProviderName { get; }

    /// <summary>
    /// Priority order (lower = higher priority)
    /// Used when multiple providers are configured
    /// </summary>
    int Priority { get; }

    /// <summary>
    /// Check if this provider is available/configured
    /// </summary>
    bool IsAvailable();

    /// <summary>
    /// Try to get a secret value by key
    /// </summary>
    /// <param name="key">Secret key (e.g., "ConnectionStrings:PostgreSQL")</param>
    /// <returns>Secret value if found, null otherwise</returns>
    Task<string?> GetSecretAsync(string key);

    /// <summary>
    /// Get all secrets from this provider (optional)
    /// Used for configuration providers that support loading all values
    /// </summary>
    Task<IDictionary<string, string>> GetAllSecretsAsync();
}
