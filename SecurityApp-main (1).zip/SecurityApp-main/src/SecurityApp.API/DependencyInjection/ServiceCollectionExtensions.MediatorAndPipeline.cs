using Mediator;

namespace SecurityApp.API.DependencyInjection;

public static class ServiceCollectionExtensionsMediatorAndPipeline
{
    public static IServiceCollection AddMediatorAndPipeline(this IServiceCollection services)
    {
        services.AddMediator(options =>
        {
            options.ServiceLifetime = ServiceLifetime.Scoped;
        });

        services.AddScoped(typeof(IPipelineBehavior<,>),
            typeof(SecurityApp.Application.Pipeline.WorkflowGateBehavior<,>));

        return services;
    }
}
