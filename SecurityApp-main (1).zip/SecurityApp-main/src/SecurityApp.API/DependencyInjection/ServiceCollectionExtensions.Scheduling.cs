using Quartz;
using SecurityApp.Core.Jobs.Interfaces;
using SecurityApp.Infrastructure.GoldenSource;
using SecurityApp.Infrastructure.Jobs;
using SecurityApp.Infrastructure.Services;

namespace SecurityApp.API.DependencyInjection;

public static class ServiceCollectionExtensionsScheduling
{
    public static IServiceCollection AddScheduling(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddSingleton<SecurityApp.Core.Jobs.Interfaces.IJobExecutionContext, AsyncLocalJobExecutionContext>();
        services.AddSingleton<QuartzJobHistoryListener>();

        services.AddQuartz();
        services.AddQuartzHostedService(opts =>
        {
            opts.WaitForJobsToComplete = true;
            opts.AwaitApplicationStarted = true;
        });

        services.AddHostedService<JobPluginScheduler>();

        // ── Stale Price Monitor (M15) ─────────────────────────────────────
        services.Configure<StalePriceMonitorOptions>(
            configuration.GetSection(StalePriceMonitorOptions.SectionName));
        services.AddHostedService<StalePriceMonitor>();

        services.AddScoped<IJobHistoryRepository, JobHistoryRepository>();
        services.AddScoped<IJobScheduleStore, DbJobScheduleStore>();
        services.AddScoped<IJobService, QuartzJobService>();

        return services;
    }
}
