using Microsoft.Extensions.Options;
using SecurityApp.Core.Shared.Configuration;
using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Infrastructure.Notifications;

namespace SecurityApp.API.DependencyInjection;

public static class ServiceCollectionExtensionsNotifications
{
    public static IServiceCollection AddNotifications(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<NotificationOptions>(
            configuration.GetSection(NotificationOptions.SectionName));

        services.AddSingleton<EmailNotificationService>();
        services.AddSingleton<WebhookNotificationService>();

        services.AddSingleton<INotificationService>(sp =>
        {
            var opts = sp.GetRequiredService<IOptions<NotificationOptions>>().Value;
            var channels = new List<INotificationService>();

            if (opts.Email?.Enabled == true && !string.IsNullOrEmpty(opts.Email.SmtpHost))
                channels.Add(sp.GetRequiredService<EmailNotificationService>());

            if (opts.Webhooks?.Any(w => !string.IsNullOrEmpty(w.Url)) == true)
                channels.Add(sp.GetRequiredService<WebhookNotificationService>());

            if (channels.Count == 0)
                return new NullNotificationService();

            var log = sp.GetRequiredService<ILogger<CompositeNotificationService>>();
            return channels.Count == 1
                ? channels[0]
                : new CompositeNotificationService(channels, log);
        });

        var webhookRetryCount = configuration.GetValue<int>("Resilience:WebhookMaxRetryCount", 3);

        services.AddHttpClient("webhooks")
            .AddStandardResilienceHandler(o => o.Retry.MaxRetryAttempts = webhookRetryCount);

        services.AddHttpClient("workflow-webhooks")
            .AddStandardResilienceHandler(o => o.Retry.MaxRetryAttempts = webhookRetryCount);

        return services;
    }
}
