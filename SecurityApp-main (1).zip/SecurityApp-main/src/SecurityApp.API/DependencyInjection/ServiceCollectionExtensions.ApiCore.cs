using Asp.Versioning;
using Asp.Versioning.ApiExplorer;
using Grpc.AspNetCore.Web;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi;
using SecurityApp.API.Filters;
using SecurityApp.API.Health;
using SecurityApp.API.Json;
using SecurityApp.API.ModelBinders;
using SecurityApp.API.SecretManagement;

namespace SecurityApp.API.DependencyInjection;

public static class ServiceCollectionExtensionsApiCore
{
    public static IServiceCollection AddApiCore(
        this IServiceCollection services,
        IConfiguration configuration,
        IWebHostEnvironment environment)
    {
        services.AddControllers(options =>
        {
            options.ModelBinderProviders.Insert(0, new TimezoneAwareDateTimeModelBinderProvider());
        })
        .AddJsonOptions(o =>
        {
            o.JsonSerializerOptions.Converters.Add(
                new System.Text.Json.Serialization.JsonStringEnumConverter());
        });

        services.AddApiVersioning(options =>
        {
            options.DefaultApiVersion = new ApiVersion(1, 0);
            options.AssumeDefaultVersionWhenUnspecified = true;
            options.ReportApiVersions = true;
            options.ApiVersionReader = ApiVersionReader.Combine(
                new QueryStringApiVersionReader("api-version"),
                new HeaderApiVersionReader("X-Api-Version")
            );
        })
        .AddApiExplorer(options =>
        {
            options.GroupNameFormat           = "'v'VVV";
            options.SubstituteApiVersionInUrl = true;
        });

        services.AddEndpointsApiExplorer();

        services.AddSingleton<TimezoneAwareDateTimeConverter>();
        services.AddSingleton<IConfigureOptions<Microsoft.AspNetCore.Mvc.JsonOptions>,
            ConfigureTimezoneJsonConverter>();

        services.AddSwaggerGen(c =>
        {
            // Swagger docs are generated per API version via IApiVersionDescriptionProvider
            // (populated at app startup; a fallback "v1" doc is added as safety net).
            c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
            {
                Description = "JWT Authorization header using the Bearer scheme. Example: \"Bearer {token}\"",
                Name = "Authorization",
                In = ParameterLocation.Header,
                Type = SecuritySchemeType.ApiKey,
                Scheme = "Bearer"
            });

            c.AddSecurityRequirement(document => new OpenApiSecurityRequirement
            {
                [new OpenApiSecuritySchemeReference("Bearer", document)] = new List<string>()
            });

            c.OperationFilter<SwaggerDefaultValues>();
        });

        // Populate one SwaggerDoc per API version after the provider is resolved
        services.AddOptions<Swashbuckle.AspNetCore.SwaggerGen.SwaggerGenOptions>()
            .Configure<IApiVersionDescriptionProvider>((options, provider) =>
            {
                foreach (var description in provider.ApiVersionDescriptions)
                {
                    options.SwaggerDoc(description.GroupName, new OpenApiInfo
                    {
                        Title       = "SecurityApp API",
                        Version     = description.GroupName,
                        Description = description.IsDeprecated
                            ? "Enterprise Security Management System API — this version is deprecated."
                            : "Enterprise Security Management System API"
                    });
                }
            });

        var corsOrigins = configuration
            .GetSection("Cors:AllowedOrigins")
            .Get<string[]>() ?? [];

        services.AddCors(options =>
        {
            options.AddPolicy("AppPolicy", policy =>
            {
                policy.WithOrigins(corsOrigins)
                      .AllowAnyMethod()
                      .AllowAnyHeader()
                      .AllowCredentials()
                      .WithExposedHeaders(
                          "grpc-status",
                          "grpc-message",
                          "grpc-encoding",
                          "grpc-accept-encoding");
            });
        });

        var dbProvider = configuration["DatabaseProvider"] ?? "PostgreSQL";
        var healthChecks = services.AddHealthChecks();
        if (string.Equals(dbProvider, "SqlServer", StringComparison.OrdinalIgnoreCase))
        {
            healthChecks.AddSqlServer(
                connectionStringFactory: sp =>
                    sp.GetService<VaultConnectionStringHolder>()?.Current
                    ?? sp.GetRequiredService<IConfiguration>().GetConnectionString("SqlServer")
                    ?? string.Empty,
                failureStatus: Microsoft.Extensions.Diagnostics.HealthChecks.HealthStatus.Degraded,
                name: "sqlserver",
                tags: ["ready"]);
        }
        else if (string.Equals(dbProvider, "PostgreSQL", StringComparison.OrdinalIgnoreCase))
        {
            healthChecks.AddNpgSql(
                connectionStringFactory: sp =>
                    sp.GetService<VaultConnectionStringHolder>()?.Current
                    ?? sp.GetRequiredService<IConfiguration>().GetConnectionString("PostgreSQL")
                    ?? string.Empty,
                failureStatus: Microsoft.Extensions.Diagnostics.HealthChecks.HealthStatus.Degraded,
                name: "postgresql",
                tags: ["ready"]);
        }
        healthChecks
            .AddRedis(
                redisConnectionString: configuration.GetConnectionString("Redis") ?? string.Empty,
                name: "redis",
                tags: ["ready"])
            .AddCheck<VaultHealthCheck>(
                name: "vault",
                tags: ["ready"]);

        services.AddScoped<SecurityApp.API.Grpc.Interceptors.IdempotencyServerInterceptor>();

        services.AddGrpc(options =>
        {
            options.EnableDetailedErrors = environment.IsDevelopment();
            options.Interceptors.Add<SecurityApp.API.Grpc.Interceptors.IdempotencyServerInterceptor>();
        });

        if (environment.IsDevelopment())
        {
            services.AddGrpcReflection();
        }

        services.AddHttpContextAccessor();

        return services;
    }
}
