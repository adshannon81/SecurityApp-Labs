using Microsoft.EntityFrameworkCore;
using Serilog;
using SecurityApp.API.SecretManagement;
using SecurityApp.Core.DeadLetters.Interfaces;
using SecurityApp.Core.Idempotency.Interfaces;
using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Core.Issuers.Interfaces;
using SecurityApp.Core.VendorSources.Interfaces;
using SecurityApp.Infrastructure.DeadLetters.Persistence;
using SecurityApp.Infrastructure.Idempotency.Persistence;
using SecurityApp.Core.Portfolio.Interfaces;
using SecurityApp.Core.Pricing.Interfaces;
using SecurityApp.Core.Ratings.Interfaces;
using SecurityApp.Core.Securities.Interfaces;
using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Core.Workflow.Interfaces;
using SecurityApp.Core.Users;
using SecurityApp.Infrastructure.Import;
using SecurityApp.Infrastructure.Persistence;
using SecurityApp.Infrastructure.Persistence.Interceptors;
using SecurityApp.Infrastructure.Persistence.Repositories;
using SecurityApp.Infrastructure.Securities.Persistence;
using SecurityApp.Infrastructure.Services;
using SecurityApp.Infrastructure.Users;

namespace SecurityApp.API.DependencyInjection;

public static class ServiceCollectionExtensionsPersistence
{
    public static IServiceCollection AddPersistence(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var databaseProvider = configuration["DatabaseProvider"] ?? "PostgreSQL";
        var dbRetryCount = configuration.GetValue<int>("Resilience:DbMaxRetryCount", 6);
        var dbRetryDelay = TimeSpan.FromSeconds(
            configuration.GetValue<int>("Resilience:DbMaxRetryDelaySeconds", 30));

        services.AddDbContext<ApplicationDbContext>((sp, options) =>
        {
            ConfigureDatabaseProvider(options, sp, configuration, databaseProvider, dbRetryCount, dbRetryDelay);
        });

        services.AddDbContextFactory<ApplicationDbContext>((sp, options) =>
        {
            ConfigureDatabaseProvider(options, sp, configuration, databaseProvider, dbRetryCount, dbRetryDelay);
        }, ServiceLifetime.Scoped);

        Log.Information("Using database provider: {DatabaseProvider}", databaseProvider);

        services.AddScoped<AuditInterceptor>();
        services.AddScoped<SessionContextInterceptor>();

        services.AddScoped<UnitOfWork>();
        services.AddScoped<IUnitOfWork>(sp => sp.GetRequiredService<UnitOfWork>());
        services.AddScoped<ISecuritiesUoW>(sp => sp.GetRequiredService<UnitOfWork>());
        services.AddScoped<IPricingUoW>(sp => sp.GetRequiredService<UnitOfWork>());
        services.AddScoped<IRatingsUoW>(sp => sp.GetRequiredService<UnitOfWork>());
        services.AddScoped<IImportUoW>(sp => sp.GetRequiredService<UnitOfWork>());
        services.AddScoped<IWorkflowUoW>(sp => sp.GetRequiredService<UnitOfWork>());
        services.AddScoped<IPortfolioUoW>(sp => sp.GetRequiredService<UnitOfWork>());
        services.AddScoped<IIssuersUoW>(sp => sp.GetRequiredService<UnitOfWork>());
        services.AddScoped<IVendorSourcesUoW>(sp => sp.GetRequiredService<UnitOfWork>());
        services.AddScoped<IVendorSnapshotService,
            SecurityApp.Infrastructure.VendorSources.Services.VendorSnapshotService>();

        services.AddScoped<ISecurityRefDataRepository, SecurityRefDataRepository>();
        services.AddScoped<SecurityApp.Core.Dashboard.IDashboardRepository,
            SecurityApp.Infrastructure.Persistence.Repositories.DashboardRepository>();

        services.AddScoped<SecurityApp.Core.Dashboard.IDashboardWidgetProvider,
            SecurityApp.Infrastructure.Dashboard.Providers.SecuritiesCountProvider>();
        services.AddScoped<SecurityApp.Core.Dashboard.IDashboardWidgetProvider,
            SecurityApp.Infrastructure.Dashboard.Providers.ImportStatusProvider>();
        services.AddScoped<SecurityApp.Core.Dashboard.IDashboardWidgetProvider,
            SecurityApp.Infrastructure.Dashboard.Providers.PendingApprovalsProvider>();
        services.AddScoped<SecurityApp.Core.Dashboard.IDashboardWidgetProvider,
            SecurityApp.Infrastructure.Dashboard.Providers.ConnectorHealthProvider>();

        services.AddScoped<IImportProfileService, DbImportProfileService>();
        services.AddSingleton<IImportValidationRunner, ImportValidationEngine>();

        services.AddScoped<IIdempotencyKeyRepository, IdempotencyKeyRepository>();
        services.AddScoped<IDeadLetterRepository, DeadLetterRepository>();

        services.AddScoped<SecurityApp.Core.GoldenSource.IDataLineageRepository,
            SecurityApp.Infrastructure.GoldenSource.Persistence.Repositories.DataLineageRepository>();
        services.AddScoped<SecurityApp.Core.GoldenSource.IGoldenSourceResolver,
            SecurityApp.Infrastructure.GoldenSource.GoldenSourceResolver>();
        services.AddScoped<SecurityApp.Core.GoldenSource.IGoldenPriceResolver,
            SecurityApp.Infrastructure.GoldenSource.GoldenPriceResolver>();

        services.AddSingleton<IUserCacheService, UserCacheService>();

        return services;
    }

    private static void ConfigureDatabaseProvider(
        DbContextOptionsBuilder options,
        IServiceProvider sp,
        IConfiguration configuration,
        string databaseProvider,
        int dbRetryCount,
        TimeSpan dbRetryDelay)
    {
        var holder = sp.GetService<VaultConnectionStringHolder>();

        switch (databaseProvider.ToLowerInvariant())
        {
            case "postgresql":
            {
                var conn = holder?.Current ?? configuration.GetConnectionString("PostgreSQL");
                options.UseNpgsql(conn, o =>
                    o.EnableRetryOnFailure(
                        maxRetryCount: dbRetryCount,
                        maxRetryDelay: dbRetryDelay,
                        errorCodesToAdd: null));
                break;
            }

            case "sqlserver":
            {
                var conn = holder?.Current ?? configuration.GetConnectionString("SqlServer");
                options.UseSqlServer(conn, o =>
                    o.EnableRetryOnFailure(
                        maxRetryCount: dbRetryCount,
                        maxRetryDelay: dbRetryDelay,
                        errorNumbersToAdd: null));
                break;
            }

            case "mysql":
            {
                var conn = holder?.Current ?? configuration.GetConnectionString("MySql");
                options.UseMySql(conn, ServerVersion.AutoDetect(conn), o =>
                    o.EnableRetryOnFailure(
                        maxRetryCount: dbRetryCount,
                        maxRetryDelay: dbRetryDelay,
                        errorNumbersToAdd: null));
                break;
            }

            default:
                throw new InvalidOperationException(
                    $"Unsupported database provider: {databaseProvider}. " +
                    "Supported providers: PostgreSQL, SqlServer, MySql");
        }
    }
}
