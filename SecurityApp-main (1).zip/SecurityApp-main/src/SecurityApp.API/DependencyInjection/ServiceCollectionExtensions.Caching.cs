using StackExchange.Redis;
using SecurityApp.API.BackgroundServices;
using SecurityApp.Core.Grpc;
using SecurityApp.Core.Shared.Configuration;
using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Infrastructure.Grpc;
using SecurityApp.Infrastructure.Services;

namespace SecurityApp.API.DependencyInjection;

public static class ServiceCollectionExtensionsCaching
{
    public static IServiceCollection AddCachingAndRedis(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<CacheOptions>(configuration.GetSection("Cache"));
        services.Configure<ImportFileDefaultsOptions>(
            configuration.GetSection(ImportFileDefaultsOptions.SectionName));

        var redisConnectionString = configuration.GetConnectionString("Redis");

        if (!string.IsNullOrWhiteSpace(redisConnectionString))
        {
            services.AddStackExchangeRedisCache(options =>
            {
                options.Configuration = redisConnectionString;
                options.InstanceName = "";
            });

            services.AddSingleton<IConnectionMultiplexer>(
                ConnectionMultiplexer.Connect(redisConnectionString));

            services.AddSingleton<IGrpcEventPublisher, RedisGrpcEventPublisher>();
        }
        else
        {
            services.AddDistributedMemoryCache();
            services.AddSingleton<IGrpcEventPublisher, NullGrpcEventPublisher>();
        }

        services.AddScoped<ICacheService, CacheService>();
        services.AddHostedService<DashboardMetricsPublisher>();

        return services;
    }
}
