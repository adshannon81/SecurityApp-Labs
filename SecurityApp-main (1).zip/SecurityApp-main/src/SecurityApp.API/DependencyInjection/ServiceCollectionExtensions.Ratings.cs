using SecurityApp.Core.Ratings.Interfaces;
using SecurityApp.Infrastructure.Ratings;
using SecurityApp.Infrastructure.Ratings.Calculators;
using SecurityApp.Infrastructure.Ratings.Functions;
using SecurityApp.Infrastructure.Ratings.Pipeline;

namespace SecurityApp.API.DependencyInjection;

public static class ServiceCollectionExtensionsRatings
{
    public static IServiceCollection AddRatings(this IServiceCollection services)
    {
        services.AddScoped<IRatingScaleService, DbRatingScaleService>();
        services.AddScoped<IRatingModelConfigService, DbRatingModelConfigService>();

        services.AddSingleton<INCalcFunctionRegistry>(sp =>
        {
            var registry = new NCalcFunctionRegistry();
            BuiltInNCalcFunctions.RegisterAll(registry);
            return registry;
        });
        services.AddScoped<IFormulaMacroService, DbFormulaMacroService>();
        services.AddScoped<NCalcExpressionEvaluator>();

        services.AddScoped<MicrCalculator>();
        services.AddScoped<VpmCalculator>();
        services.AddScoped<FundamentalRatingCalculator>();
        services.AddScoped<CompositeRatingCalculator>();

        services.AddScoped<IRatingPipelineRunner, RatingPipelineRunner>();

        return services;
    }
}
