using SecurityApp.Core.Plugins.Interfaces;
using SecurityApp.Infrastructure.Extensions;
using SecurityApp.Infrastructure.Jobs;
using SecurityApp.Infrastructure.Plugins;
using SecurityApp.Infrastructure.Plugins.Configuration;

namespace SecurityApp.API.DependencyInjection;

public static class ServiceCollectionExtensionsPlugins
{
    public static IServiceCollection AddPlugins(
        this IServiceCollection services,
        IConfiguration configuration,
        IWebHostEnvironment environment)
    {
        services.Configure<DataConnectorsOptions>(
            configuration.GetSection(DataConnectorsOptions.SectionName));

        services.AddSingleton<IPluginLoader, PluginLoader>();
        services.AddSingleton<DataConnectorRegistry>();

        services.AddDataProviders(configuration);

        services.AddSingleton<JobPluginLoader>(sp =>
        {
            var cfg = sp.GetRequiredService<IConfiguration>();
            var env = sp.GetRequiredService<IWebHostEnvironment>();
            var log = sp.GetRequiredService<ILogger<JobPluginLoader>>();
            var dir = cfg["PluginSettings:PluginDirectory"] ?? "./plugins";

            if (!Directory.Exists(dir) || !Directory.GetFiles(dir, "*.dll").Any())
            {
                var candidate = env.ContentRootPath;
                for (int i = 0; i < 4; i++)
                {
                    var probe = Path.Combine(candidate, "plugins");
                    if (Directory.Exists(probe) && Directory.GetFiles(probe, "*.dll").Any())
                    {
                        dir = probe;
                        break;
                    }
                    var parent = Directory.GetParent(candidate);
                    if (parent == null) break;
                    candidate = parent.FullName;
                }
            }

            return new JobPluginLoader(log, dir);
        });

        return services;
    }
}
