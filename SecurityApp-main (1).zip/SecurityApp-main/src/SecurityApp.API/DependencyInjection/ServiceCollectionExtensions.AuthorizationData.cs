using Microsoft.Extensions.Options;
using SecurityApp.API.Json;
using SecurityApp.Core.AppAuthorization;
using SecurityApp.Core.FieldVisibility;
using SecurityApp.Core.Permissions;
using SecurityApp.Infrastructure.AppAuthorization.Persistence.Repositories;
using SecurityApp.Infrastructure.AppAuthorization.Services;
using SecurityApp.Infrastructure.FieldVisibility.Persistence.Repositories;
using SecurityApp.Infrastructure.Permissions.Persistence.Repositories;

namespace SecurityApp.API.DependencyInjection;

public static class ServiceCollectionExtensionsAuthorizationData
{
    public static IServiceCollection AddAuthorizationData(this IServiceCollection services)
    {
        // Field-level visibility: DB-driven Full / Obfuscated / Hidden per field.
        services.AddScoped<IFieldVisibilityEntityRepository, FieldVisibilityEntityRepository>();
        services.AddScoped<IFieldVisibilityFieldRepository, FieldVisibilityFieldRepository>();
        services.AddScoped<IFieldVisibilityRuleRepository, FieldVisibilityRuleRepository>();
        services.AddScoped<IFieldGroupRepository, FieldGroupRepository>();
        services.AddSingleton<FieldVisibilityRuleCache>();
        services.AddSingleton<IConfigureOptions<Microsoft.AspNetCore.Mvc.JsonOptions>>(sp =>
            new ConfigureFieldPermissionConverter(
                sp.GetRequiredService<IHttpContextAccessor>(),
                sp.GetRequiredService<FieldVisibilityRuleCache>()));

        // Permission catalog
        services.AddScoped<IPermissionDefinitionRepository, PermissionDefinitionRepository>();
        services.AddScoped<IEntityScreenRepository, EntityScreenRepository>();
        services.AddScoped<IPermissionBundleRepository, PermissionBundleRepository>();
        services.AddScoped<IPolicyTemplateRepository, PolicyTemplateRepository>();

        // App resource authorization
        services.AddScoped<IAppResourceRepository, AppResourceRepository>();
        services.AddScoped<IAppResourceRuleRepository, AppResourceRuleRepository>();
        services.AddScoped<IAppResourceGroupRepository, AppResourceGroupRepository>();
        services.AddScoped<IAuthorizationPolicyService, AuthorizationPolicyService>();

        return services;
    }
}
