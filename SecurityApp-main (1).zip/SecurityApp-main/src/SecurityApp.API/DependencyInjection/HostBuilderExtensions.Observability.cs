using OpenTelemetry.Exporter;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using Serilog;

namespace SecurityApp.API.DependencyInjection;

public static class HostBuilderExtensionsObservability
{
    public static IHostBuilder ConfigureObservability(
        this IHostBuilder host,
        IConfiguration configuration)
    {
        // ── Serilog ──────────────────────────────────────────────────────────
        const string outputTemplate =
            "[{Timestamp:HH:mm:ss} {Level:u3}] {CorrelationId,-36} {SourceContext} {Message:lj}{NewLine}{Exception}";

        Log.Logger = new LoggerConfiguration()
            .ReadFrom.Configuration(configuration)
            .Enrich.FromLogContext()
            .WriteTo.Console(outputTemplate: outputTemplate)
            .WriteTo.File(
                "logs/securityapp-.txt",
                rollingInterval: RollingInterval.Day,
                outputTemplate: outputTemplate)
            .CreateLogger();

        host.UseSerilog();

        // ── OpenTelemetry ─────────────────────────────────────────────────────
        host.ConfigureServices((ctx, services) =>
        {
            var cfg  = ctx.Configuration;
            var otlp = cfg["Observability:OtlpEndpoint"];  // e.g. http://otel-collector:4317

            var resourceBuilder = ResourceBuilder
                .CreateDefault()
                .AddService(
                    serviceName:        cfg["Observability:ServiceName"] ?? "SecurityApp.API",
                    serviceVersion:     cfg["Observability:ServiceVersion"] ?? "1.0.0",
                    serviceInstanceId:  Environment.MachineName);

            services
                .AddOpenTelemetry()

                // ── Traces ───────────────────────────────────────────────────
                .WithTracing(tracing =>
                {
                    tracing
                        .SetResourceBuilder(resourceBuilder)
                        .AddAspNetCoreInstrumentation(opts =>
                        {
                            opts.RecordException = true;
                            // Exclude health-check and metrics endpoints from traces
                            opts.Filter = ctx =>
                                !ctx.Request.Path.StartsWithSegments("/health") &&
                                !ctx.Request.Path.StartsWithSegments("/metrics");
                        })
                        .AddHttpClientInstrumentation(opts =>
                        {
                            opts.RecordException = true;
                        })
                        .AddEntityFrameworkCoreInstrumentation();

                    if (!string.IsNullOrWhiteSpace(otlp))
                    {
                        tracing.AddOtlpExporter(opts =>
                        {
                            opts.Endpoint = new Uri(otlp);
                            opts.Protocol = OtlpExportProtocol.Grpc;
                        });
                    }
                })

                // ── Metrics ──────────────────────────────────────────────────
                .WithMetrics(metrics =>
                {
                    metrics
                        .SetResourceBuilder(resourceBuilder)
                        .AddAspNetCoreInstrumentation()
                        .AddHttpClientInstrumentation()
                        // Custom SecurityApp meters (used throughout the application layer)
                        .AddMeter("SecurityApp.Pricing")
                        .AddMeter("SecurityApp.Workflow")
                        .AddMeter("SecurityApp.Import")
                        .AddMeter("SecurityApp.Portfolio")
                        // Prometheus scrape endpoint — served at /metrics
                        .AddPrometheusExporter();

                    if (!string.IsNullOrWhiteSpace(otlp))
                    {
                        metrics.AddOtlpExporter(opts =>
                        {
                            opts.Endpoint = new Uri(otlp);
                            opts.Protocol = OtlpExportProtocol.Grpc;
                        });
                    }
                });
        });

        return host;
    }
}

