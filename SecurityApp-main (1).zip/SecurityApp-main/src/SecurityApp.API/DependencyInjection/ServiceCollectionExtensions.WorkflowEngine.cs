using SecurityApp.Core.Workflow.Interfaces;
using SecurityApp.Infrastructure.Workflow;
using SecurityApp.Infrastructure.Workflow.Actions;

namespace SecurityApp.API.DependencyInjection;

public static class ServiceCollectionExtensionsWorkflowEngine
{
    public static IServiceCollection AddWorkflowEngine(this IServiceCollection services)
    {
        services.AddSingleton<ConditionEvaluator>();
        services.AddScoped<IWorkflowEngine, WorkflowEngine>();

        services.AddScoped<IWorkflowAction, AutoApproveAction>();
        services.AddScoped<IWorkflowAction, InAppNotificationAction>();
        services.AddScoped<IWorkflowAction, WebhookCallAction>();
        services.AddScoped<IWorkflowAction, WaitTimerAction>();

        return services;
    }
}
