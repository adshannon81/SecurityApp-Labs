using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using SecurityApp.API.Authorization;

namespace SecurityApp.API.DependencyInjection;

public static class ServiceCollectionExtensionsSecurity
{
    public static IServiceCollection AddSecurity(
        this IServiceCollection services,
        IConfiguration configuration,
        IWebHostEnvironment environment)
    {
        services
            .AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                var internalAuthority = configuration["Keycloak:Authority"];
                var externalAuthority = configuration["Keycloak:ExternalAuthority"];
                var authority = !string.IsNullOrEmpty(externalAuthority)
                    ? externalAuthority
                    : internalAuthority;

                options.Authority = authority;
                options.Audience = configuration["Keycloak:Audience"] ?? "securityapp-api";
                options.RequireHttpsMetadata = !environment.IsDevelopment();
                options.MapInboundClaims = false;

                if (!string.IsNullOrEmpty(externalAuthority) &&
                    !string.IsNullOrEmpty(internalAuthority) &&
                    externalAuthority != internalAuthority)
                {
                    options.BackchannelHttpHandler =
                        new KeycloakBackchannelRewriteHandler(externalAuthority, internalAuthority);
                }

                options.TokenValidationParameters = new TokenValidationParameters
                {
                    // In development KC_HOSTNAME is dynamic (uses X-Forwarded-Host),
                    // so the token issuer changes with the access origin (localhost or
                    // a tunnel URL). Skip issuer validation in dev and rely on
                    // signature + audience checks instead.
                    ValidateIssuer = !environment.IsDevelopment(),
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = authority,
                    RoleClaimType = "roles"
                };

                options.Events = new JwtBearerEvents
                {
                    OnTokenValidated = ctx =>
                    {
                        if (ctx.Principal?.Identity is ClaimsIdentity identity)
                        {
                            foreach (var rc in identity.FindAll("roles").ToList())
                            {
                                if (!identity.HasClaim(ClaimTypes.Role, rc.Value))
                                {
                                    identity.AddClaim(new Claim(ClaimTypes.Role, rc.Value));
                                }
                            }

                            const string apiClientId = "securityapp-api";

                            var direct = identity.FindAll($"resource_access.{apiClientId}.roles").ToList();
                            foreach (var rc in direct)
                            {
                                if (!identity.HasClaim("permissions", rc.Value))
                                {
                                    identity.AddClaim(new Claim("permissions", rc.Value));
                                }
                            }

                            if (direct.Count == 0)
                            {
                                var rawClaim = identity.FindFirst("resource_access");
                                if (rawClaim is not null)
                                {
                                    try
                                    {
                                        using var doc = System.Text.Json.JsonDocument.Parse(rawClaim.Value);
                                        if (doc.RootElement.TryGetProperty(apiClientId, out var clientAccess) &&
                                            clientAccess.TryGetProperty("roles", out var roles) &&
                                            roles.ValueKind == System.Text.Json.JsonValueKind.Array)
                                        {
                                            foreach (var role in roles.EnumerateArray())
                                            {
                                                var name = role.GetString();
                                                if (name is not null &&
                                                    !identity.HasClaim("permissions", name))
                                                {
                                                    identity.AddClaim(new Claim("permissions", name));
                                                }
                                            }
                                        }
                                    }
                                    catch
                                    {
                                        // non-critical
                                    }
                                }
                            }
                        }

                        return Task.CompletedTask;
                    }
                };
            });

        services.AddAuthorization();
        services.AddSingleton<IAuthorizationPolicyProvider, PermissionPolicyProvider>();
        services.AddScoped<IAuthorizationHandler, PermissionAuthorizationHandler>();

        return services;
    }
}
