using System.Globalization;
using System.Security.Claims;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.RateLimiting;

namespace SecurityApp.API.DependencyInjection;

public static class ServiceCollectionExtensionsPlatform
{
    public static IServiceCollection AddPlatformServices(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddRateLimiter(options =>
        {
            var rateLimitingEnabled = configuration.GetValue<bool>("RateLimiting:Enabled", true);
            var authWindow = configuration.GetValue<int>("RateLimiting:AuthenticatedWindowSeconds", 60);
            var authLimit = configuration.GetValue<int>("RateLimiting:AuthenticatedPermitLimit", 100);
            var anonWindow = configuration.GetValue<int>("RateLimiting:AnonymousWindowSeconds", 60);
            var anonLimit = configuration.GetValue<int>("RateLimiting:AnonymousPermitLimit", 20);

            options.AddPolicy("authenticated", httpContext =>
            {
                if (!rateLimitingEnabled)
                    return RateLimitPartition.GetNoLimiter("disabled");

                var userId = httpContext.User?.FindFirstValue("sub")
                          ?? httpContext.User?.FindFirstValue(ClaimTypes.NameIdentifier);

                if (userId is null)
                    return RateLimitPartition.GetNoLimiter("anon-skip");

                return RateLimitPartition.GetSlidingWindowLimiter(
                    partitionKey: userId,
                    factory: _ => new SlidingWindowRateLimiterOptions
                    {
                        Window = TimeSpan.FromSeconds(authWindow),
                        PermitLimit = authLimit,
                        SegmentsPerWindow = 4,
                        QueueLimit = 0
                    });
            });

            options.AddPolicy("anonymous", httpContext =>
            {
                if (!rateLimitingEnabled)
                    return RateLimitPartition.GetNoLimiter("disabled");

                return RateLimitPartition.GetSlidingWindowLimiter(
                    partitionKey: httpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown",
                    factory: _ => new SlidingWindowRateLimiterOptions
                    {
                        Window = TimeSpan.FromSeconds(anonWindow),
                        PermitLimit = anonLimit,
                        SegmentsPerWindow = 4,
                        QueueLimit = 0
                    });
            });

            options.OnRejected = async (context, ct) =>
            {
                context.HttpContext.Response.StatusCode = StatusCodes.Status429TooManyRequests;

                if (context.Lease.TryGetMetadata(MetadataName.RetryAfter, out var retryAfter))
                {
                    context.HttpContext.Response.Headers.RetryAfter =
                        ((int)retryAfter.TotalSeconds).ToString(CultureInfo.InvariantCulture);
                }

                await context.HttpContext.Response.WriteAsync("Too many requests.", ct);
            };
        });

        return services;
    }
}
