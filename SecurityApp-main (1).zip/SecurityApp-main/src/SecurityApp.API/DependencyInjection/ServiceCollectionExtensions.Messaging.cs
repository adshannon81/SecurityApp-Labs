using SecurityApp.API.SecretManagement;
using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Infrastructure.Extensions;
using SecurityApp.Infrastructure.Messaging;

namespace SecurityApp.API.DependencyInjection;

public static class ServiceCollectionExtensionsMessaging
{
    public static IServiceCollection AddMessaging(
        this IServiceCollection services,
        IHostBuilder host,
        IConfiguration configuration,
        string databaseProvider,
        VaultRabbitMqCredentialHolder vaultMqHolder)
    {
        host.AddWolverineMessaging(
            configuration,
            databaseProvider,
            () => vaultMqHolder.IsPopulated ? vaultMqHolder.Username : null,
            () => vaultMqHolder.IsPopulated ? vaultMqHolder.Password : null);

        services.AddScoped<IEventBus, WolverineEventBus>();

        return services;
    }
}
