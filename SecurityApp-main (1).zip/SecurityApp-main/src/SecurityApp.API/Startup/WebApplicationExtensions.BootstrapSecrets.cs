using Serilog;
using SecurityApp.API.SecretManagement;

namespace SecurityApp.API.Startup;

public static class WebApplicationExtensionsBootstrapSecrets
{
    public static async Task<WebApplication> BootstrapSecretsAsync(
        this WebApplication app,
        string databaseProvider,
        VaultRabbitMqCredentialHolder vaultMqHolder)
    {
        var secretProviderOpts = app.Services.GetRequiredService<SecretProviderOptions>();

        if (!secretProviderOpts.EnableHashiCorpVault)
        {
            await LogAvailableSecretProvidersAsync(app);
            return app;
        }

        var vaultKvReader = app.Services.GetService<IVaultKvReader>();
        var vaultDbProv = app.Services.GetService<IVaultDatabaseProvider>();
        var connHolder = app.Services.GetService<VaultConnectionStringHolder>();

        if (connHolder is not null)
        {
            if (!string.IsNullOrEmpty(secretProviderOpts.VaultDatabaseRole) &&
                vaultDbProv is not null &&
                vaultDbProv.IsAvailable())
            {
                try
                {
                    var (cs, lease) = await vaultDbProv.GetDatabaseConnectionStringAsync();
                    connHolder.Update(cs, lease);
                    Log.Information("Vault initial DB credentials acquired (lease: {Lease}s)", lease);
                }
                catch (Exception ex)
                {
                    Log.Error(ex,
                        "Could not acquire initial Vault DB credentials — " +
                        "falling back to ConnectionStrings configuration");
                }
            }
            else if (vaultKvReader is not null && vaultKvReader.IsAvailable())
            {
                try
                {
                    var connKey = databaseProvider.ToLowerInvariant() switch
                    {
                        "sqlserver" => "ConnectionStrings__SqlServer",
                        "postgresql" => "ConnectionStrings__PostgreSQL",
                        "mysql" => "ConnectionStrings__MySql",
                        _ => "ConnectionStrings__SqlServer"
                    };

                    var cs = await vaultKvReader.ReadKvAsync(secretProviderOpts.VaultSecretPath, connKey);
                    if (!string.IsNullOrEmpty(cs))
                    {
                        connHolder.Update(cs, 3600);
                        Log.Information(
                            "Vault KV connection string loaded for provider '{Provider}'",
                            databaseProvider);
                    }
                    else
                    {
                        Log.Warning(
                            "Vault KV bootstrap: key '{Key}' not found at path '{Path}'. " +
                            "Falling back to ConnectionStrings configuration.",
                            connKey,
                            secretProviderOpts.VaultSecretPath);
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(ex,
                        "Could not load connection string from Vault KV — " +
                        "falling back to ConnectionStrings configuration");
                }
            }
        }

        var vaultMqProv = app.Services.GetService<IVaultRabbitMqProvider>();
        if (!string.IsNullOrEmpty(secretProviderOpts.VaultRabbitMqRole) &&
            vaultMqProv is not null &&
            vaultMqProv.IsAvailable())
        {
            try
            {
                var (mqUser, mqPass, mqLease) = await vaultMqProv.GetRabbitMqCredentialsAsync();
                vaultMqHolder.Update(mqUser, mqPass, mqLease);
                Log.Information("Vault initial RabbitMQ credentials acquired (lease: {Lease}s)", mqLease);
            }
            catch (Exception ex)
            {
                Log.Error(ex,
                    "Could not acquire initial Vault RabbitMQ credentials — " +
                    "falling back to RabbitMQ:Username / RabbitMQ:Password configuration");
            }
        }

        await LogAvailableSecretProvidersAsync(app);
        return app;
    }

    private static Task LogAvailableSecretProvidersAsync(WebApplication app)
    {
        var secretService = app.Services.GetRequiredService<SecretProviderService>();
        var availableProviders = secretService.GetAvailableProviders();

        Log.Information("Active secret providers: {Providers}", string.Join(", ", availableProviders));
        return Task.CompletedTask;
    }
}
