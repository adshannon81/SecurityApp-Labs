using Serilog;
using SecurityApp.Core.Plugins.Interfaces;

namespace SecurityApp.API.Startup;

public static class WebApplicationExtensionsBootstrapPlugins
{
    public static async Task<WebApplication> BootstrapPluginsAsync(this WebApplication app)
    {
        var pluginLoader = app.Services.GetRequiredService<IPluginLoader>();
        var configuration = app.Services.GetRequiredService<IConfiguration>();

        var pluginDirectory = ResolvePluginDirectory(app, configuration);

        await pluginLoader.LoadPluginsAsync(pluginDirectory);

        Log.Information("Plugins loaded from directory: {PluginDirectory}", pluginDirectory);

        return app;
    }

    private static string ResolvePluginDirectory(WebApplication app, IConfiguration configuration)
    {
        var pluginDirectory = configuration["PluginSettings:PluginDirectory"] ?? "./plugins";

        if (Directory.Exists(pluginDirectory) &&
            Directory.GetFiles(pluginDirectory, "*.dll").Any())
        {
            return pluginDirectory;
        }

        var dir = app.Environment.ContentRootPath;

        for (var i = 0; i < 4; i++)
        {
            var candidate = Path.Combine(dir, "plugins");
            if (Directory.Exists(candidate) &&
                Directory.GetFiles(candidate, "*.dll").Any())
            {
                return candidate;
            }

            var parent = Directory.GetParent(dir);
            if (parent is null)
            {
                break;
            }

            dir = parent.FullName;
        }

        return pluginDirectory;
    }
}
