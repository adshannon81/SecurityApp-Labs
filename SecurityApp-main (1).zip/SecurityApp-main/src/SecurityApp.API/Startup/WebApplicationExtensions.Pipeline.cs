using Asp.Versioning.ApiExplorer;
using Grpc.AspNetCore.Web;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Quartz;
using Serilog;
using SecurityApp.API.Grpc;
using SecurityApp.API.Middleware;
using SecurityApp.Infrastructure.Jobs;
using System.Net;
using System.Text.Json;
using IPNetwork = Microsoft.AspNetCore.HttpOverrides.IPNetwork;

namespace SecurityApp.API.Startup;

public static class WebApplicationExtensionsPipeline
{
    public static WebApplication ConfigureHttpPipeline(this WebApplication app)
    {
        // Trust X-Forwarded-For / X-Real-IP from the nginx reverse proxy container.
        // The Docker bridge network uses 172.16.0.0/12 by default.
        app.UseForwardedHeaders(new ForwardedHeadersOptions
        {
            ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto,
            KnownNetworks = { new IPNetwork(IPAddress.Parse("172.16.0.0"), 12) },
        });

        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                var provider = app.Services.GetRequiredService<IApiVersionDescriptionProvider>();
                foreach (var description in provider.ApiVersionDescriptions)
                {
                    c.SwaggerEndpoint(
                        $"/swagger/{description.GroupName}/swagger.json",
                        $"SecurityApp API {description.GroupName.ToUpperInvariant()}");
                }
            });
        }

        app.UseMiddleware<CorrelationIdMiddleware>();

        app.UseSerilogRequestLogging(opts =>
        {
            opts.IncludeQueryInRequestPath = true;
            opts.EnrichDiagnosticContext = (diag, ctx) =>
            {
                if (ctx.Response.Headers.TryGetValue("X-Correlation-Id", out var cid))
                    diag.Set("CorrelationId", cid.ToString());

                diag.Set("UserId", ctx.User?.Identity?.Name ?? "anonymous");
            };
        });

        app.UseMiddleware<ExceptionHandlingMiddleware>();
        app.UseMiddleware<IdempotencyMiddleware>();

        app.UseHttpsRedirection();
        app.UseCors("AppPolicy");

        app.UseAuthentication();
        app.UseMiddleware<UserCacheMiddleware>();
        app.UseMiddleware<TimezoneMiddleware>();
        app.UseRateLimiter();
        app.UseAuthorization();

        app.UseGrpcWeb(new GrpcWebOptions
        {
            DefaultEnabled = true
        });

        return app;
    }

    public static async Task<WebApplication> ConfigureQuartzListenersAsync(this WebApplication app)
    {
        var schedulerFactory = app.Services.GetRequiredService<ISchedulerFactory>();
        var scheduler = await schedulerFactory.GetScheduler();

        scheduler.ListenerManager.AddJobListener(
            app.Services.GetRequiredService<QuartzJobHistoryListener>());

        return app;
    }

    public static WebApplication MapAppEndpoints(this WebApplication app)
    {
        app.MapControllers();

        // Liveness probe — returns 200 as long as the process is running (no dependency checks).
        app.MapHealthChecks("/health/live", new HealthCheckOptions
        {
            Predicate      = _ => false,
            ResponseWriter = WriteHealthJson
        });

        // Readiness probe — checks SQL Server, Redis, and Vault are reachable.
        app.MapHealthChecks("/health/ready", new HealthCheckOptions
        {
            Predicate      = check => check.Tags.Contains("ready"),
            ResponseWriter = WriteHealthJson
        });

        // Legacy endpoint kept for backwards compatibility.
        app.MapHealthChecks("/health", new HealthCheckOptions
        {
            Predicate      = check => check.Tags.Contains("ready"),
            ResponseWriter = WriteHealthJson
        });

        // Prometheus metrics scrape endpoint — no auth, scraped by Prometheus server.
        // Protected at the network level (not exposed publicly).
        app.MapPrometheusScrapingEndpoint("/metrics");

        app.MapGrpcService<SecuritiesGrpcService>().RequireAuthorization().EnableGrpcWeb();
        app.MapGrpcService<PricingGrpcService>().RequireAuthorization().EnableGrpcWeb();
        app.MapGrpcService<WorkflowGrpcService>().RequireAuthorization().EnableGrpcWeb();
        app.MapGrpcService<DashboardGrpcService>().RequireAuthorization().EnableGrpcWeb();
        app.MapGrpcService<NavConfigGrpcService>().RequireAuthorization().EnableGrpcWeb();
        app.MapGrpcService<RefDataEventsGrpcService>().RequireAuthorization().EnableGrpcWeb();
        app.MapGrpcService<ReferenceDataGrpcService>().RequireAuthorization().EnableGrpcWeb();

        if (app.Environment.IsDevelopment())
        {
            app.MapGrpcReflectionService();
        }

        return app;
    }

    private static Task WriteHealthJson(HttpContext ctx, HealthReport report)
    {
        ctx.Response.ContentType = "application/json";
        var result = JsonSerializer.Serialize(new
        {
            status = report.Status.ToString(),
            checks = report.Entries.Select(e => new
            {
                name        = e.Key,
                status      = e.Value.Status.ToString(),
                description = e.Value.Description
            })
        });
        return ctx.Response.WriteAsync(result);
    }
}
