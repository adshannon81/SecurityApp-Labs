using System.Threading.Channels;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using StackExchange.Redis;
using SecurityApp.Core.Dashboard;
using SecurityApp.Core.Grpc;
using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Core.Workflow.Interfaces;

namespace SecurityApp.API.BackgroundServices;

/// <summary>
/// Hosted service that periodically aggregates dashboard metrics and publishes them to
/// the Redis <c>securityapp:grpc:dashboard</c> channel.
/// <para>
/// All connected <see cref="Grpc.DashboardGrpcService"/> streams receive the update
/// simultaneously — one set of DB queries per tick regardless of connected client count.
/// </para>
/// <para>
/// Also subscribes to security/workflow change channels so the dashboard updates
/// within ~1 s of any mutation, not just on the 30-second heartbeat.
/// </para>
/// </summary>
public sealed class DashboardMetricsPublisher(
    IServiceScopeFactory scopeFactory,
    IGrpcEventPublisher publisher,
    ILogger<DashboardMetricsPublisher> logger,
    IConnectionMultiplexer? multiplexer = null) : BackgroundService
{
    private static readonly TimeSpan Interval = TimeSpan.FromSeconds(30);
    private static readonly TimeSpan Debounce = TimeSpan.FromSeconds(1);

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Signal channel: any write means "re-publish now (after debounce)"
        var nudge = Channel.CreateBounded<byte>(new BoundedChannelOptions(1)
        {
            FullMode = BoundedChannelFullMode.DropWrite   // coalesce bursts
        });

        // Subscribe to domain-change channels so we refresh immediately
        if (multiplexer is not null)
        {
            var sub = multiplexer.GetSubscriber();
            var channels = new[]
            {
                GrpcStreamChannels.SecurityChanges,
                GrpcStreamChannels.WorkflowPendingChanged,
            };
            foreach (var ch in channels)
            {
                await sub.SubscribeAsync(RedisChannel.Literal(ch),
                    (_, _) =>
                    {
                        logger.LogInformation("DashboardMetricsPublisher: nudge received on channel {Channel}", ch);
                        nudge.Writer.TryWrite(0);
                    });
                logger.LogInformation("DashboardMetricsPublisher: subscribed to Redis channel {Channel}", ch);
            }
        }
        else
        {
            logger.LogWarning("DashboardMetricsPublisher: IConnectionMultiplexer is null — Redis subscriptions disabled");
        }

        // Publish immediately on startup
        await PublishAsync(stoppingToken);

        while (!stoppingToken.IsCancellationRequested)
        {
            // Wait for either the heartbeat timer OR a nudge from Redis
            using var timerCts = CancellationTokenSource.CreateLinkedTokenSource(stoppingToken);
            timerCts.CancelAfter(Interval);

            try
            {
                await nudge.Reader.ReadAsync(timerCts.Token);
                // Got a nudge — debounce to coalesce rapid-fire changes (e.g. bulk import)
                try { await Task.Delay(Debounce, stoppingToken); }
                catch (OperationCanceledException) { break; }
            }
            catch (OperationCanceledException) when (!stoppingToken.IsCancellationRequested)
            {
                // Timer expired (30 s heartbeat) — publish anyway
            }
            catch (OperationCanceledException)
            {
                break;
            }

            await PublishAsync(stoppingToken);
        }
    }

    private async Task PublishAsync(CancellationToken ct)
    {
        await using var scope = scopeFactory.CreateAsyncScope();
        var dashRepo     = scope.ServiceProvider.GetRequiredService<IDashboardRepository>();
        var dataProvider = scope.ServiceProvider.GetRequiredService<IDataProviderService>();
        var workflow     = scope.ServiceProvider.GetRequiredService<IWorkflowEngine>();

        try
        {
            // Run queries sequentially — they share a single scoped DbContext instance
            // and EF Core does not support concurrent operations on the same context.
            var counts     = await dashRepo.GetCountsAsync(ct);
            var connectors = await dataProvider.GetAllConnectorHealthAsync(ct);
            var pending    = await workflow.GetPendingForRoleAsync(string.Empty, ct);

            var payload = new DashboardMetricsPayload(
                TotalSecurities  : counts.TotalSecurities,
                ActiveSecurities : counts.ActiveSecurities,
                PendingApprovals : pending.Count(),
                Connectors       : connectors
                    .Select(c => new ConnectorHealthPayload(c.Name, c.IsHealthy, c.Message))
                    .ToList(),
                AsOf             : DateTime.UtcNow);

            await publisher.PublishDashboardMetricsAsync(payload, ct);
            logger.LogInformation("DashboardMetricsPublisher: published metrics (total={Total}, active={Active})",
                payload.TotalSecurities, payload.ActiveSecurities);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested) { }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "DashboardMetricsPublisher: metric collection failed");
        }
    }
}
