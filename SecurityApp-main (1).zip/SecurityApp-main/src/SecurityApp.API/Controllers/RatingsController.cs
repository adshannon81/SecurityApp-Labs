﻿using SecurityApp.API.Authorization;
using Mediator;
using Microsoft.AspNetCore.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SecurityApp.Application.Ratings.DTOs;
using SecurityApp.Application.Ratings.Queries;
using SecurityApp.Application.Ratings.Commands;
using SecurityApp.Application.Shared;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/[controller]")]
[RequirePermission("ratings:read")]
[EnableRateLimiting("authenticated")]
public class RatingsController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly ILogger<RatingsController> _logger;

    public RatingsController(IMediator mediator, ILogger<RatingsController> logger)
    {
        _mediator = mediator;
        _logger   = logger;
    }

    // -- Queries ---------------------------------------------------------------

    /// <summary>
    /// Returns the current derived rating for a security, rendered in the requested agencies.
    /// Pass ?agencies=SP,Moodys,Fitch to receive labels for multiple agencies at once.
    /// </summary>
    [HttpGet("{securityId:guid}")]
    [ProducesResponseType(typeof(DerivedRatingDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetDerivedRating(
        Guid securityId,
        [FromQuery] string? agencies = null)
    {
        var result = await _mediator.Send(new GetDerivedRatingQuery(securityId, agencies));
        return Ok(result);
    }

    /// <summary>
    /// Returns the paginated audit trail of rating calculations for a security.
    /// </summary>
    [HttpGet("{securityId:guid}/audit")]
    [ProducesResponseType(typeof(PagedResult<RatingAuditLogDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAuditLog(
        Guid securityId,
        [FromQuery] int pageNumber = 1,
        [FromQuery] int pageSize = 20)
    {
        var result = await _mediator.Send(new GetRatingAuditLogQuery(securityId, pageNumber, pageSize));
        return Ok(result);
    }

    /// <summary>
    /// Returns the raw JSON configuration for a rating model (Admin only).
    /// Supported model names: micr, vpm, fundamental, composite, rating-scales.
    /// </summary>
    [HttpGet("config/{modelName}")]
    [RequirePermission("ratings:manage")]
    [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetModelConfig(string modelName)
    {
        try
        {
            var json = await _mediator.Send(new GetRatingModelConfigQuery(modelName));
            return Content(json, "application/json");
        }
        catch (FileNotFoundException)
        {
            return NotFound(new { message = $"Config not found for model '{modelName}'." });
        }
    }

    // -- Commands --------------------------------------------------------------

    /// <summary>
    /// Triggers the full rating pipeline (MICR â†’ VPM â†’ Fundamental â†’ Composite) for one security.
    /// Skips recalculation if inputs are unchanged.
    /// </summary>
    /// <param name="securityId">Target security.</param>
    /// <param name="asOf">
    /// Optional UTC date for temporal (as-of) back-calculation.
    /// When supplied, the pipeline selects rating rules effective on that date
    /// rather than today's rules. Useful for auditing historical derived ratings.
    /// </param>
    [HttpPost("{securityId:guid}/calculate")]
    [RequirePermission("ratings:write")]
    [ProducesResponseType(typeof(DerivedRatingDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> CalculateRating(
        Guid securityId,
        [FromQuery] DateTime? asOf = null)
    {
        var userId = User.Identity?.Name;
        var result = await _mediator.Send(
            new CalculateDerivedRatingCommand(securityId, userId, asOf));
        return Ok(result);
    }

    /// <summary>
    /// Runs the rating pipeline for multiple securities.
    /// </summary>
    [HttpPost("batch/calculate")]
    [RequirePermission("ratings:write")]
    [ProducesResponseType(typeof(BatchRatingResultDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> CalculateBatch(
        [FromBody] IReadOnlyList<Guid> securityIds,
        [FromQuery] DateTime? asOf = null)
    {
        if (securityIds is null || securityIds.Count == 0)
            return BadRequest(new { message = "At least one security ID is required." });

        var userId = User.Identity?.Name;
        var result = await _mediator.Send(
            new CalculateBatchDerivedRatingsCommand(securityIds, userId, asOf));
        return Ok(result);
    }

    /// <summary>
    /// Hot-reloads a model's JSON configuration without restarting the application (Admin only).
    /// </summary>
    [HttpPut("config/{modelName}")]
    [RequirePermission("ratings:manage")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> UpdateModelConfig(string modelName, [FromBody] string json)
    {
        if (string.IsNullOrWhiteSpace(json))
            return BadRequest(new { message = "Config JSON must not be empty." });

        var userId = User.Identity?.Name;
        await _mediator.Send(new UpdateRatingModelConfigCommand(modelName, json, userId));
        return NoContent();
    }

    // -- Derivation Rules ------------------------------------------------------

    /// <summary>
    /// Returns all active derivation rules, optionally filtered by model name and/or an as-of date.
    /// </summary>
    [HttpGet("rules")]
    [RequirePermission("ratings:manage")]
    [ProducesResponseType(typeof(IEnumerable<RatingDerivationRuleDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetDerivationRules(
        [FromQuery] string? modelName = null,
        [FromQuery] DateTime? asOf = null)
    {
        var result = await _mediator.Send(new GetRatingDerivationRulesQuery(modelName, asOf));
        return Ok(result);
    }

    /// <summary>
    /// Creates or replaces the derivation rule for a given model / security-type / effective window.
    /// The existing matching rule is expired (bi-temporal) before the new one is stored.
    /// </summary>
    [HttpPost("rules")]
    [RequirePermission("ratings:manage")]
    [ProducesResponseType(typeof(RatingDerivationRuleDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> UpsertDerivationRule(
        [FromBody] UpsertRatingDerivationRuleRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.ModelName))
            return BadRequest(new { message = "ModelName is required." });

        if (string.IsNullOrWhiteSpace(request.ConfigJson))
            return BadRequest(new { message = "ConfigJson must not be empty." });

        var userId = User.Identity?.Name;
        var result = await _mediator.Send(new UpsertRatingDerivationRuleCommand(
            request.ModelName,
            request.SecurityType,
            request.EffectiveFrom,
            request.EffectiveTo,
            request.ConfigJson,
            request.Description,
            userId));

        return CreatedAtAction(nameof(GetDerivationRules),
            new { modelName = result.ModelName }, result);
    }

    /// <summary>
    /// Expires (soft-deletes) a derivation rule by ID (Admin only).
    /// </summary>
    [HttpDelete("rules/{id:guid}")]
    [RequirePermission("ratings:manage")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> DeleteDerivationRule(Guid id)
    {
        try
        {
            var userId = User.Identity?.Name;
            await _mediator.Send(new DeleteRatingDerivationRuleCommand(id, userId));
            return NoContent();
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(new { message = ex.Message });
        }
    }

    // -- Rating Scales ---------------------------------------------------------

    /// <summary>
    /// Returns current rating scale entries, optionally filtered by agency (SP, Moodys, Fitch).
    /// </summary>
    [HttpGet("scales")]
    [ProducesResponseType(typeof(IEnumerable<RatingScaleEntryDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetRatingScales([FromQuery] string? agency = null)
    {
        var result = await _mediator.Send(new GetRatingScalesQuery(agency));
        return Ok(result);
    }

    /// <summary>
    /// Bulk-replaces the rating scale entries from a JSON payload (Admin only).
    /// All existing entries are expired and new ones are stored with full audit trail.
    /// </summary>
    [HttpPost("scales")]
    [RequirePermission("ratings:manage")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> SeedRatingScales([FromBody] string json)
    {
        if (string.IsNullOrWhiteSpace(json))
            return BadRequest(new { message = "Scale JSON must not be empty." });

        var userId = User.Identity?.Name;
        await _mediator.Send(new SeedRatingScalesCommand(json, userId));
        return NoContent();
    }

    /// <summary>Creates a single rating scale entry.</summary>
    [HttpPost("scales/entry")]
    [RequirePermission("ratings:manage")]
    [ProducesResponseType(typeof(RatingScaleEntryDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> CreateScaleEntry([FromBody] RatingScaleEntryRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Agency) || string.IsNullOrWhiteSpace(request.Label))
            return BadRequest(new { message = "Agency and Label are required." });

        var userId = User.Identity?.Name;
        var result = await _mediator.Send(new CreateRatingScaleEntryCommand(
            request.Agency,
            request.Score,
            request.Label,
            request.IsInvestmentGrade,
            request.ValidFrom,
            request.ValidTo,
            userId));

        return CreatedAtAction(nameof(GetRatingScales), new { agency = result.Agency }, result);
    }

    /// <summary>Updates an existing rating scale entry.</summary>
    [HttpPut("scales/entry/{id:guid}")]
    [RequirePermission("ratings:manage")]
    [ProducesResponseType(typeof(RatingScaleEntryDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateScaleEntry(Guid id, [FromBody] RatingScaleEntryRequest request)
    {
        try
        {
            var userId = User.Identity?.Name;
            var result = await _mediator.Send(new UpdateRatingScaleEntryCommand(
                id,
                request.Label,
                request.IsInvestmentGrade,
                request.ValidFrom,
                request.ValidTo,
                userId));
            return Ok(result);
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(new { message = ex.Message });
        }
    }

    /// <summary>Soft-expires (deletes) a rating scale entry.</summary>
    [HttpDelete("scales/entry/{id:guid}")]
    [RequirePermission("ratings:manage")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> DeleteScaleEntry(Guid id)
    {
        try
        {
            var userId = User.Identity?.Name;
            await _mediator.Send(new DeleteRatingScaleEntryCommand(id, userId));
            return NoContent();
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(new { message = ex.Message });
        }
    }
}
