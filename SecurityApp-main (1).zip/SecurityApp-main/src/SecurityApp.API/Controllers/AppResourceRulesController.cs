using Mediator;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using SecurityApp.API.Authorization;
using SecurityApp.Application.AppAuthorization.Commands;
using SecurityApp.Application.AppAuthorization.DTOs;
using SecurityApp.Application.AppAuthorization.Queries;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/app-resource-rules")]
[RequirePermission("admin:ui-resources")]
public class AppResourceRulesController(IMediator mediator) : ControllerBase
{
    [HttpGet]
    [ProducesResponseType(typeof(IReadOnlyList<AppResourceRuleDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(CancellationToken ct)
    {
        var result = await mediator.Send(new GetAllAppResourceRulesQuery(), ct);
        return Ok(result);
    }

    [HttpGet("{id:guid}")]
    [ProducesResponseType(typeof(AppResourceRuleDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id, CancellationToken ct)
    {
        var result = await mediator.Send(new GetAppResourceRuleByIdQuery(id), ct);
        return result is null ? NotFound() : Ok(result);
    }

    [HttpGet("by-resource/{resourceId:guid}")]
    [ProducesResponseType(typeof(IReadOnlyList<AppResourceRuleDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetByResource(Guid resourceId, CancellationToken ct)
    {
        var result = await mediator.Send(new GetAppResourceRulesByResourceQuery(resourceId), ct);
        return Ok(result);
    }

    [HttpPost]
    [ProducesResponseType(typeof(AppResourceRuleDto), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create([FromBody] CreateAppResourceRuleRequest request, CancellationToken ct)
    {
        var userId = User.FindFirst("sub")?.Value;
        var result = await mediator.Send(new CreateAppResourceRuleCommand(request, userId), ct);
        return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
    }

    [HttpPut("{id:guid}")]
    [ProducesResponseType(typeof(AppResourceRuleDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateAppResourceRuleRequest request, CancellationToken ct)
    {
        try
        {
            var userId = User.FindFirst("sub")?.Value;
            var result = await mediator.Send(new UpdateAppResourceRuleCommand(id, request, userId), ct);
            return Ok(result);
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
    }

    [HttpDelete("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        try
        {
            await mediator.Send(new DeleteAppResourceRuleCommand(id), ct);
            return NoContent();
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
    }
}
