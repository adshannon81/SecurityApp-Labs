﻿using SecurityApp.API.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SecurityApp.Core.Workflow.Interfaces;
using SecurityApp.Core.Workflow.Entities;
using SecurityApp.Core.Workflow.Enums;

namespace SecurityApp.API.Controllers;

// -- DTOs ----------------------------------------------------------------------

public record CreateWorkflowDefinitionRequest(
    string  Name,
    string  TriggerType,
    string? Description,
    bool    IsEnabled,
    string? ConditionJson,
    IList<CreateWorkflowDefinitionStepRequest> Steps);

public record CreateWorkflowDefinitionStepRequest(
    int     StepOrder,
    string  Name,
    string  StepType,
    string? RequiredRole,
    int     RequiredApprovals,
    int     TimeoutHours,
    string  TimeoutAction,
    string? EscalateToRole,
    int?    OnApprovedGotoStep,
    int?    OnRejectedGotoStep,
    int?    OnTimeoutGotoStep,
    string? ActionConfigJson);

public record UpdateWorkflowDefinitionRequest(
    string  Name,
    string? Description,
    bool    IsEnabled,
    string? ConditionJson);

// -- Controller ----------------------------------------------------------------

/// <summary>
/// Admin CRUD for workflow definitions.
/// GET    /api/workflowdefinitions           - list all
/// GET    /api/workflowdefinitions/{id}      - detail with steps
/// POST   /api/workflowdefinitions           - create
/// PUT    /api/workflowdefinitions/{id}      - update header fields
/// DELETE /api/workflowdefinitions/{id}      - soft-delete (disable)
/// </summary>
[ApiController]
[ApiVersion("1.0")]
[Route("api/workflowdefinitions")]
[RequirePermission("workflows:manage")]
[EnableRateLimiting("authenticated")]
public class WorkflowDefinitionsController(
    IWorkflowUoW uow,
    ILogger<WorkflowDefinitionsController> logger) : ControllerBase
{
    // -- List ------------------------------------------------------------------

    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(CancellationToken ct = default)
    {
        var definitions = await uow.WorkflowDefinitions.GetAllAsync(ct);
        var allSteps    = await uow.WorkflowDefinitionSteps.GetAllAsync(ct);
        var stepCounts  = allSteps
            .GroupBy(s => s.DefinitionId)
            .ToDictionary(g => g.Key, g => g.Count());
        return Ok(definitions.OrderBy(d => d.Name)
            .Select(d => ToSummaryDto(d, stepCounts.GetValueOrDefault(d.Id, 0))));
    }

    // -- Detail ----------------------------------------------------------------

    [HttpGet("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id, CancellationToken ct = default)
    {
        var definitions = await uow.WorkflowDefinitions.FindAsync(d => d.Id == id, ct);
        var definition  = definitions.FirstOrDefault();
        if (definition == null) return NotFound();

        var steps = await uow.WorkflowDefinitionSteps.FindAsync(
            s => s.DefinitionId == id, ct);

        return Ok(ToDetailDto(definition, steps.OrderBy(s => s.StepOrder)));
    }

    // -- Create ----------------------------------------------------------------

    [HttpPost]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create(
        [FromBody] CreateWorkflowDefinitionRequest body,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(body.Name))
            return BadRequest(new { error = "Name is required." });

        if (!Enum.TryParse<WorkflowTriggerType>(body.TriggerType, ignoreCase: true, out var triggerType))
            return BadRequest(new { error = $"Unknown TriggerType '{body.TriggerType}'." });

        var modifiedBy = User.FindFirst("sub")?.Value ?? "unknown";

        var definition = new WorkflowDefinition
        {
            Name         = body.Name,
            TriggerType  = triggerType,
            Description  = body.Description,
            IsEnabled    = body.IsEnabled,
            ConditionJson = body.ConditionJson
        };
        await uow.WorkflowDefinitions.AddAsync(definition, ct);

        foreach (var stepDto in body.Steps ?? [])
        {
            if (!Enum.TryParse<WorkflowStepType>(stepDto.StepType, ignoreCase: true, out var stepType))
                return BadRequest(new { error = $"Unknown StepType '{stepDto.StepType}'." });
            if (!Enum.TryParse<WorkflowTimeoutAction>(stepDto.TimeoutAction, ignoreCase: true, out var timeoutAction))
                return BadRequest(new { error = $"Unknown TimeoutAction '{stepDto.TimeoutAction}'." });

            await uow.WorkflowDefinitionSteps.AddAsync(new WorkflowDefinitionStep
            {
                DefinitionId       = definition.Id,
                StepOrder          = stepDto.StepOrder,
                Name               = stepDto.Name,
                StepType           = stepType,
                RequiredRole       = stepDto.RequiredRole,
                RequiredApprovals  = stepDto.RequiredApprovals,
                TimeoutHours       = stepDto.TimeoutHours,
                TimeoutAction      = timeoutAction,
                EscalateToRole     = stepDto.EscalateToRole,
                OnApprovedGotoStep = stepDto.OnApprovedGotoStep,
                OnRejectedGotoStep = stepDto.OnRejectedGotoStep,
                OnTimeoutGotoStep  = stepDto.OnTimeoutGotoStep,
                ActionConfigJson   = stepDto.ActionConfigJson
            }, ct);
        }

        await uow.SaveChangesAsync(ct);
        logger.LogInformation("Workflow definition '{Name}' created by {User}", definition.Name, modifiedBy);

        return CreatedAtAction(nameof(GetById), new { id = definition.Id },
            ToSummaryDto(definition, body.Steps?.Count ?? 0));
    }

    // -- Update ----------------------------------------------------------------

    [HttpPut("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(
        Guid id,
        [FromBody] UpdateWorkflowDefinitionRequest body,
        CancellationToken ct = default)
    {
        var definitions = await uow.WorkflowDefinitions.FindAsync(d => d.Id == id, ct);
        var definition  = definitions.FirstOrDefault();
        if (definition == null) return NotFound();

        definition.Name          = body.Name;
        definition.Description   = body.Description;
        definition.IsEnabled     = body.IsEnabled;
        definition.ConditionJson = body.ConditionJson;

        await uow.WorkflowDefinitions.UpdateAsync(definition, ct);
        await uow.SaveChangesAsync(ct);

        var stepCount = (await uow.WorkflowDefinitionSteps.FindAsync(s => s.DefinitionId == id, ct)).Count();
        return Ok(ToSummaryDto(definition, stepCount));
    }

    // -- Disable (soft delete) -------------------------------------------------

    [HttpDelete("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct = default)
    {
        var definitions = await uow.WorkflowDefinitions.FindAsync(d => d.Id == id, ct);
        var definition  = definitions.FirstOrDefault();
        if (definition == null) return NotFound();

        definition.IsEnabled = false;
        await uow.WorkflowDefinitions.UpdateAsync(definition, ct);
        await uow.SaveChangesAsync(ct);

        return NoContent();
    }

    // -- Projection helpers ----------------------------------------------------

    private static object ToSummaryDto(WorkflowDefinition d, int stepCount = 0) => new
    {
        id          = d.Id,
        name        = d.Name,
        triggerType = d.TriggerType.ToString(),
        description = d.Description,
        isEnabled   = d.IsEnabled,
        stepCount   = stepCount,
        createdAt   = d.CreatedAt
    };

    private static object ToDetailDto(WorkflowDefinition d, IEnumerable<WorkflowDefinitionStep> steps) => new
    {
        id            = d.Id,
        name          = d.Name,
        triggerType   = d.TriggerType.ToString(),
        description   = d.Description,
        isEnabled     = d.IsEnabled,
        conditionJson = d.ConditionJson,
        createdAt     = d.CreatedAt,
        steps         = steps.Select(s => new
        {
            stepOrder          = s.StepOrder,
            name               = s.Name,
            stepType           = s.StepType.ToString(),
            requiredRole       = s.RequiredRole,
            requiredApprovals  = s.RequiredApprovals,
            timeoutHours       = s.TimeoutHours,
            timeoutAction      = s.TimeoutAction.ToString(),
            escalateToRole     = s.EscalateToRole,
            onApprovedGotoStep = s.OnApprovedGotoStep,
            onRejectedGotoStep = s.OnRejectedGotoStep,
            onTimeoutGotoStep  = s.OnTimeoutGotoStep,
            actionConfigJson   = s.ActionConfigJson
        })
    };
}



