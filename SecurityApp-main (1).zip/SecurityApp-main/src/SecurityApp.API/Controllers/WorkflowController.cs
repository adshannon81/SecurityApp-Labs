﻿using SecurityApp.API.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SecurityApp.Core.Workflow.Interfaces;
using SecurityApp.Core.Workflow.Enums;

namespace SecurityApp.API.Controllers;

// -- Request/Response DTOs -----------------------------------------------------

public record SubmitDecisionRequest(
    string    Decision,
    string?   Notes,
    int?      TargetStepOrder);

// -- Controller ----------------------------------------------------------------

/// <summary>
/// Manages active workflow instances: listing, querying, and submitting decisions.
///
/// GET  /api/workflows/pending              - steps pending for the caller's role
/// GET  /api/workflows/{id}                 - full instance detail + history
/// POST /api/workflows/{id}/steps/{order}/decide - submit approve/reject/send-back/advance/noted
/// POST /api/workflows/{id}/cancel          - admin cancel
/// </summary>
[ApiController]
[ApiVersion("1.0")]
[Route("api/workflows")]
[RequirePermission("workflows:read")]
[EnableRateLimiting("authenticated")]
public class WorkflowController(
    IWorkflowEngine workflowEngine,
    IWorkflowUoW uow,
    ILogger<WorkflowController> logger) : ControllerBase
{
    // -- Pending steps for caller's role ---------------------------------------

    [HttpGet("pending")]
    [RequirePermission("workflows:use")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetPending(CancellationToken ct = default)
    {
        var role = User.FindFirstValue("roles")
                ?? User.FindFirstValue(ClaimTypes.Role)
                ?? string.Empty;

        var stepInstances = await workflowEngine.GetPendingForRoleAsync(role, ct);
        var result        = new List<object>();

        foreach (var si in stepInstances)
        {
            var instances = await uow.WorkflowInstances.FindAsync(i => i.Id == si.InstanceId, ct);
            var instance  = instances.FirstOrDefault();
            result.Add(new
            {
                instanceId        = si.InstanceId,
                stepInstanceId    = si.Id,
                stepOrder         = si.StepOrder,
                stepType          = si.StepType.ToString(),
                requiredRole      = si.RequiredRole,
                requiredApprovals = si.RequiredApprovals,
                receivedApprovals = si.ReceivedApprovals,
                timeoutAt         = si.TimeoutAt,
                workflow          = instance == null ? null : new
                {
                    triggeredBy   = instance.TriggeredBy,
                    triggeredAt   = instance.TriggeredAt,
                    entityType    = instance.EntityType,
                    entityId      = instance.EntityId,
                    triggerType   = instance.TriggerType.ToString()
                }
            });
        }

        return Ok(result);
    }

    // -- Instance detail -------------------------------------------------------

    [HttpGet("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetInstance(Guid id, CancellationToken ct = default)
    {
        var instances = await uow.WorkflowInstances.FindAsync(i => i.Id == id, ct);
        var instance  = instances.FirstOrDefault();
        if (instance == null) return NotFound();

        var stepInstances = await uow.WorkflowStepInstances.FindAsync(
            s => s.InstanceId == id, ct);
        var approvals = await uow.WorkflowStepApprovals.FindAsync(
            a => a.InstanceId == id, ct);

        return Ok(new
        {
            id               = instance.Id,
            definitionId     = instance.DefinitionId,
            triggerType      = instance.TriggerType.ToString(),
            entityType       = instance.EntityType,
            entityId         = instance.EntityId,
            status           = instance.Status.ToString(),
            currentStepOrder = instance.CurrentStepOrder,
            triggeredBy      = instance.TriggeredBy,
            triggeredAt      = instance.TriggeredAt,
            completedAt      = instance.CompletedAt,
            steps            = stepInstances.OrderBy(s => s.StepOrder).Select(s => new
            {
                stepOrder         = s.StepOrder,
                stepType          = s.StepType.ToString(),
                requiredRole      = s.RequiredRole,
                requiredApprovals = s.RequiredApprovals,
                receivedApprovals = s.ReceivedApprovals,
                status            = s.Status.ToString(),
                timeoutAt         = s.TimeoutAt,
                reviewedBy        = s.ReviewedBy,
                reviewedAt        = s.ReviewedAt
            }),
            history          = approvals.OrderBy(a => a.DecisionAt).Select(a => new
            {
                fromStepOrder   = a.FromStepOrder,
                targetStepOrder = a.TargetStepOrder,
                decision        = a.Decision.ToString(),
                decisionBy      = a.DecisionBy,
                decisionAt      = a.DecisionAt,
                notes           = a.Notes
            })
        });
    }

    // -- Submit decision -------------------------------------------------------

    [HttpPost("{id:guid}/steps/{stepOrder:int}/decide")]
    [RequirePermission("workflows:use")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> SubmitDecision(
        Guid id, int stepOrder,
        [FromBody] SubmitDecisionRequest body,
        CancellationToken ct = default)
    {
        if (!Enum.TryParse<WorkflowDecision>(body.Decision, ignoreCase: true, out var decision))
            return BadRequest(new { error = $"Unknown decision '{body.Decision}'. Valid values: {string.Join(", ", Enum.GetNames<WorkflowDecision>())}" });

        var decisionBy = User.FindFirstValue("sub")
                      ?? User.FindFirstValue(ClaimTypes.NameIdentifier)
                      ?? "unknown";
        var userRole   = User.FindFirstValue("roles")
                      ?? User.FindFirstValue(ClaimTypes.Role)
                      ?? string.Empty;

        try
        {
            var stepInstance = await workflowEngine.SubmitDecisionAsync(
                id, stepOrder, decisionBy, userRole, decision, body.Notes, body.TargetStepOrder, ct);

            return Ok(new
            {
                stepOrder         = stepInstance.StepOrder,
                status            = stepInstance.Status.ToString(),
                receivedApprovals = stepInstance.ReceivedApprovals,
                requiredApprovals = stepInstance.RequiredApprovals
            });
        }
        catch (InvalidOperationException ex) when (ex.Message.Contains("not found"))
        {
            return NotFound(new { error = ex.Message });
        }
        catch (UnauthorizedAccessException ex)
        {
            logger.LogWarning(
                "Unauthorized decision attempt on instance {Id} step {StepOrder} by {User}: {Msg}",
                id, stepOrder, decisionBy, ex.Message);
            return StatusCode(StatusCodes.Status403Forbidden, new { error = ex.Message });
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { error = ex.Message });
        }
    }

    // -- Cancel ----------------------------------------------------------------

    [HttpPost("{id:guid}/cancel")]
    [RequirePermission("workflows:manage")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Cancel(
        Guid id,
        [FromQuery] string? notes = null,
        CancellationToken ct = default)
    {
        var cancelledBy = User.FindFirstValue("sub")
                       ?? User.FindFirstValue(ClaimTypes.NameIdentifier)
                       ?? "unknown";
        try
        {
            await workflowEngine.CancelAsync(id, cancelledBy, notes ?? string.Empty, ct);
            return NoContent();
        }
        catch (InvalidOperationException ex)
        {
            return NotFound(new { error = ex.Message });
        }
    }
}
