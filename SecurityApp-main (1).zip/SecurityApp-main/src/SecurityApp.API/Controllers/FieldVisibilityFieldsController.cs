using Mediator;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using SecurityApp.API.Authorization;
using SecurityApp.Application.FieldVisibility.Commands;
using SecurityApp.Application.FieldVisibility.DTOs;
using SecurityApp.Application.FieldVisibility.Queries;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/field-visibility-fields")]
[RequirePermission("admin:field-visibility")]
public class FieldVisibilityFieldsController(IMediator mediator) : ControllerBase
{
    [HttpGet]
    [ProducesResponseType(typeof(IReadOnlyList<FieldVisibilityFieldDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(CancellationToken ct)
    {
        var result = await mediator.Send(new GetAllFieldVisibilityFieldsQuery(), ct);
        return Ok(result);
    }

    [HttpGet("{id:guid}")]
    [ProducesResponseType(typeof(FieldVisibilityFieldDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id, CancellationToken ct)
    {
        var result = await mediator.Send(new GetFieldVisibilityFieldByIdQuery(id), ct);
        return result is null ? NotFound() : Ok(result);
    }

    [HttpGet("by-entity/{entityId:guid}")]
    [ProducesResponseType(typeof(IReadOnlyList<FieldVisibilityFieldDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetByEntity(Guid entityId, CancellationToken ct)
    {
        var result = await mediator.Send(new GetFieldVisibilityFieldsByEntityQuery(entityId), ct);
        return Ok(result);
    }

    [HttpPost]
    [ProducesResponseType(typeof(FieldVisibilityFieldDto), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create([FromBody] CreateFieldVisibilityFieldRequest request, CancellationToken ct)
    {
        var userId = User.FindFirst("sub")?.Value;
        var result = await mediator.Send(new CreateFieldVisibilityFieldCommand(request, userId), ct);
        return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
    }

    [HttpPut("{id:guid}")]
    [ProducesResponseType(typeof(FieldVisibilityFieldDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateFieldVisibilityFieldRequest request, CancellationToken ct)
    {
        try
        {
            var userId = User.FindFirst("sub")?.Value;
            var result = await mediator.Send(new UpdateFieldVisibilityFieldCommand(id, request, userId), ct);
            return Ok(result);
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
    }

    [HttpDelete("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        try
        {
            await mediator.Send(new DeleteFieldVisibilityFieldCommand(id), ct);
            return NoContent();
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
    }
}
