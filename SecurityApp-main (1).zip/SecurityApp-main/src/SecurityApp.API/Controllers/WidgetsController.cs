using Microsoft.AspNetCore.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SecurityApp.Core.Dashboard;

namespace SecurityApp.API.Controllers;

/// <summary>
/// Generic widget data endpoint.
///
/// Each <see cref="IDashboardWidgetProvider"/> registered in DI is reachable at
/// <c>GET /api/widgets/{id}</c>. Adding a new backend widget requires only:
///   1. A class implementing <see cref="IDashboardWidgetProvider"/>.
///   2. Registering it as <c>IDashboardWidgetProvider</c> in Program.cs.
/// No changes to this controller are needed.
/// </summary>
[ApiController]
[ApiVersion("1.0")]
[Route("api/[controller]")]
[Authorize]
[EnableRateLimiting("authenticated")]
public class WidgetsController(IEnumerable<IDashboardWidgetProvider> providers) : ControllerBase
{
    [HttpGet("{id}")]
    [ProducesResponseType(typeof(object), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Get(string id, CancellationToken ct)
    {
        var provider = providers.FirstOrDefault(p =>
            string.Equals(p.WidgetId, id, StringComparison.OrdinalIgnoreCase));

        if (provider is null)
            return NotFound(new { error = $"Widget '{id}' is not registered." });

        var data = await provider.GetDataAsync(ct);
        return Ok(data);
    }
}
