﻿using SecurityApp.API.Authorization;
using Mediator;
using Microsoft.AspNetCore.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SecurityApp.Application.Import.DTOs;
using SecurityApp.Application.Shared;
using SecurityApp.Core.Import.Entities;
using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Application.Import.Queries;
using SecurityApp.Application.Import.Commands;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Import.Messages;
using SecurityApp.Core.Import.Enums;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/[controller]")]
[RequirePermission("imports:read")]
[EnableRateLimiting("authenticated")]
public class ImportController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly IEventBus _eventBus;
    private readonly IImportUoW _uow;
    private readonly ILogger<ImportController> _logger;

    public ImportController(IMediator mediator, IEventBus eventBus, IImportUoW uow, ILogger<ImportController> logger)
    {
        _mediator = mediator;
        _eventBus = eventBus;
        _uow      = uow;
        _logger   = logger;
    }

    /// <summary>
    /// Search an external provider for securities by keyword (read-only, does not save to DB).
    /// </summary>
    [HttpPost("securities/search")]
    [ProducesResponseType(typeof(IEnumerable<SecuritySearchResult>), StatusCodes.Status200OK)]
    public async Task<IActionResult> SearchSecurities([FromBody] SearchExternalSecuritiesRequest request)
    {
        var query = new SearchExternalSecuritiesQuery(request.Keyword, request.ProviderName);
        var result = await _mediator.Send(query);
        return Ok(result);
    }

    /// <summary>
    /// Import a single security by identifier (ticker, ISIN, etc.) from an external provider.
    /// </summary>
    [HttpPost("security")]
    [RequirePermission("imports:run")]
    [ProducesResponseType(typeof(ImportResult), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> ImportSecurity([FromBody] ImportSecurityRequest request)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        var command = new ImportSecurityCommand(
            request.IdentifierValue,
            request.IdentifierType,
            request.ProviderName,
            userId);

        var result = await _mediator.Send(command);

        if (!result.Success && result.Errors.Any())
            return BadRequest(result);

        return Ok(result);
    }

    /// <summary>
    /// Batch import a list of securities from an external provider.
    /// Items are processed in parallel (bounded concurrency); a single ImportRequest tracks the aggregate result.
    /// Per-item provider names override the request-level default.
    /// </summary>
    [HttpPost("securities/batch")]
    [RequirePermission("imports:run")]
    [ProducesResponseType(typeof(BatchImportResult), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> BatchImportSecurities([FromBody] BatchImportRequest request)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        var command = new BatchImportSecuritiesCommand(
            request.Securities,
            request.ProviderName,
            userId);

        var result = await _mediator.Send(command);
        return Ok(result);
    }

    /// <summary>
    /// Upload a delimited file to bulk-import securities.
    /// Optionally specify a named import profile (from the database) via <c>profileName</c>
    /// to control delimiter, column mappings and validation rules.
    /// Without a profile the file is parsed as a standard comma-delimited CSV with a header row.
    /// </summary>
    [HttpPost("file/securities")]
    [RequirePermission("imports:run")]
    [ProducesResponseType(typeof(BatchImportResult), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> ImportSecuritiesFromFile(IFormFile file, [FromQuery] string? profileName = null)
    {
        if (file == null || file.Length == 0)
            return BadRequest(new { message = "No file uploaded." });

        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

        using var stream = file.OpenReadStream();
        var command = new ImportSecuritiesFromFileCommand(stream, file.FileName, profileName, userId);
        var result = await _mediator.Send(command);

        return Ok(result);
    }

    /// <summary>
    /// Import prices for a specific security from an external provider.
    /// Omit FromDate/ToDate to fetch the current price only; supply both for historical data.
    /// </summary>
    [HttpPost("prices/{securityId:guid}")]
    [RequirePermission("imports:run")]
    [ProducesResponseType(typeof(BatchImportResult), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> ImportPrices(Guid securityId, [FromBody] ImportPricesRequest request)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        var command = new BatchImportPricesCommand(
            securityId,
            request.Symbol,
            request.FromDate,
            request.ToDate,
            request.ProviderName,
            userId);

        var result = await _mediator.Send(command);
        return Ok(result);
    }

    /// <summary>
    /// Upload a CSV file to bulk-import prices.
    /// Expected columns: Symbol,Price,PriceType,BidPrice,AskPrice,OpenPrice,HighPrice,LowPrice,Volume,PriceDate,Currency
    /// </summary>
    [HttpPost("file/prices")]
    [RequirePermission("imports:run")]
    [ProducesResponseType(typeof(BatchImportResult), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> ImportPricesFromFile(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest(new { message = "No file uploaded." });

        if (!file.FileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase))
            return BadRequest(new { message = "Only CSV files are supported." });

        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

        using var stream = file.OpenReadStream();
        var command = new ImportPricesFromFileCommand(stream, file.FileName, userId);
        var result = await _mediator.Send(command);

        return Ok(result);
    }

    /// <summary>
    /// Get paginated import request history.
    /// </summary>
    [HttpGet("requests")]
    [ProducesResponseType(typeof(PagedResult<ImportRequestDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetImportRequests(
        [FromQuery] int pageNumber = 1,
        [FromQuery] int pageSize = 50)
    {
        var query = new GetImportRequestsQuery(pageNumber, pageSize);
        var result = await _mediator.Send(query);
        return Ok(result);
    }

    /// <summary>
    /// Get a specific import request by ID.
    /// </summary>
    [HttpGet("requests/{id:guid}")]
    [ProducesResponseType(typeof(ImportRequestDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetImportRequestById(Guid id)
    {
        var query = new GetImportRequestByIdQuery(id);
        var result = await _mediator.Send(query);

        if (result == null)
            return NotFound(new { message = $"Import request {id} not found." });

        return Ok(result);
    }

    // -- Phase 3: Failed / dead-lettered import endpoints ---------------------

    /// <summary>
    /// Returns import requests that have been dead-lettered (Status=Failed with AttemptNumber >= 3).
    /// These are items that exhausted all automatic retry attempts.
    /// </summary>
    [HttpGet("requests/failed")]
    [RequirePermission("imports:manage")]
    [ProducesResponseType(typeof(IEnumerable<ImportRequestDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetFailedImportRequests(CancellationToken ct = default)
    {
        var all = await _uow.ImportRequests.GetAllAsync(ct);
        var failed = all
            .Where(r => r.Status == RequestStatus.Failed && r.AttemptNumber > 0)
            .OrderByDescending(r => r.CreatedAt);
        return Ok(failed.Select(ToImportRequestDto));
    }

    /// <summary>
    /// Manually re-queues a dead-lettered import request for another retry cycle.
    /// Resets AttemptNumber to 0 so a fresh set of retry attempts begins.
    /// </summary>
    [HttpPost("requests/{id:guid}/retry")]
    [RequirePermission("imports:manage")]
    [ProducesResponseType(StatusCodes.Status202Accepted)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> RetryImportRequest(Guid id, CancellationToken ct = default)
    {
        var all = await _uow.ImportRequests.GetAllAsync(ct);
        var request = all.FirstOrDefault(r => r.Id == id);
        if (request is null) return NotFound();
        if (request.Status == RequestStatus.InProgress)
            return Conflict(new { error = "Request is currently in progress." });

        // Deserialise the original import details from RequestDetails (set by ImportSecurityHandler)
        string identifierValue = request.RequestDetails is not null
            ? (System.Text.Json.JsonSerializer.Deserialize<System.Text.Json.JsonElement>(request.RequestDetails)
                .TryGetProperty("IdentifierValue", out var iv) ? iv.GetString() ?? "" : "")
            : "";

        var idType = request.RequestDetails is not null
            ? (System.Text.Json.JsonSerializer.Deserialize<System.Text.Json.JsonElement>(request.RequestDetails)
                .TryGetProperty("IdentifierType", out var it)
                    ? Enum.TryParse<IdentifierType>(it.GetString(), out var parsed) ? parsed : IdentifierType.Ticker
                    : IdentifierType.Ticker)
            : IdentifierType.Ticker;

        // Reset the request state
        request.Status        = RequestStatus.Pending;
        request.AttemptNumber = 0;
        request.ErrorMessage  = null;
        request.LastModifiedAt     = DateTime.UtcNow;
        await _uow.ImportRequests.UpdateAsync(request, ct);
        await _uow.SaveChangesAsync(ct);

        // Re-publish the retry event with AttemptNumber = 0
        await _eventBus.PublishAsync(new ImportFailedEvent(
            request.Id,
            identifierValue,
            idType,
            null,
            request.UserId?.ToString(),
            0), ct);

        _logger.LogInformation("Import request {Id} manually re-queued for retry", id);
        return Accepted();
    }

    private static ImportRequestDto ToImportRequestDto(ImportRequest r) => new ImportRequestDto
    {
        Id             = r.Id,
        RequestType    = r.RequestType.ToString(),
        SourceSystem   = r.SourceSystem?.ToString(),
        Status         = r.Status.ToString(),
        CreatedAt      = r.CreatedAt,
        CompletedAt    = r.CompletedAt,
        ErrorMessage   = r.ErrorMessage,
        TotalRecords   = r.TotalRecords,
        ProcessedRecords = r.ProcessedRecords,
        FailedRecords  = r.FailedRecords,
    };
}

/// <summary>Request body for external security search.</summary>
public record SearchExternalSecuritiesRequest(string Keyword, string? ProviderName = null);

/// <summary>Request body for importing prices for a security from an external provider.</summary>
public record ImportPricesRequest(
    string Symbol,
    DateTime? FromDate = null,
    DateTime? ToDate = null,
    string? ProviderName = null);
