using Asp.Versioning;
using Mediator;
using Microsoft.AspNetCore.Mvc;
using SecurityApp.API.Authorization;
using SecurityApp.Application.Permissions.Commands;
using SecurityApp.Application.Permissions.DTOs;
using SecurityApp.Application.Permissions.Queries;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/permission-bundles")]
[RequirePermission("admin:manage-permissions")]
public class PermissionBundlesController(IMediator mediator) : ControllerBase
{
    [HttpGet]
    [ProducesResponseType(typeof(IReadOnlyList<PermissionBundleDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(CancellationToken ct)
    {
        var result = await mediator.Send(new GetAllPermissionBundlesQuery(), ct);
        return Ok(result);
    }

    [HttpGet("{id:guid}")]
    [ProducesResponseType(typeof(PermissionBundleDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id, CancellationToken ct)
    {
        var result = await mediator.Send(new GetPermissionBundleByIdQuery(id), ct);
        return result is null ? NotFound() : Ok(result);
    }

    [HttpGet("{id:guid}/with-members")]
    [ProducesResponseType(typeof(PermissionBundleWithMembersDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetWithMembers(Guid id, CancellationToken ct)
    {
        var result = await mediator.Send(new GetPermissionBundleWithMembersQuery(id), ct);
        return result is null ? NotFound() : Ok(result);
    }

    [HttpGet("{id:guid}/members")]
    [ProducesResponseType(typeof(IReadOnlyList<PermissionBundleMemberDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetMembers(Guid id, CancellationToken ct)
    {
        var result = await mediator.Send(new GetPermissionBundleMembersQuery(id), ct);
        return Ok(result);
    }

    [HttpPost]
    [ProducesResponseType(typeof(PermissionBundleDto), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create([FromBody] CreatePermissionBundleRequest request, CancellationToken ct)
    {
        var userId = User.FindFirst("sub")?.Value;
        var result = await mediator.Send(new CreatePermissionBundleCommand(request, userId), ct);
        return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
    }

    [HttpPut("{id:guid}")]
    [ProducesResponseType(typeof(PermissionBundleDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdatePermissionBundleRequest request, CancellationToken ct)
    {
        try
        {
            var userId = User.FindFirst("sub")?.Value;
            var result = await mediator.Send(new UpdatePermissionBundleCommand(id, request, userId), ct);
            return Ok(result);
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
    }

    [HttpDelete("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        try
        {
            await mediator.Send(new DeletePermissionBundleCommand(id), ct);
            return NoContent();
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
    }

    [HttpPost("{bundleId:guid}/members")]
    [ProducesResponseType(typeof(PermissionBundleMemberDto), StatusCodes.Status201Created)]
    public async Task<IActionResult> AddMember(Guid bundleId, [FromBody] AddPermissionBundleMemberRequest request, CancellationToken ct)
    {
        var userId = User.FindFirst("sub")?.Value;
        var result = await mediator.Send(new AddPermissionBundleMemberCommand(request, userId), ct);
        return Created(string.Empty, result);
    }

    [HttpDelete("members/{memberId:guid}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> RemoveMember(Guid memberId, CancellationToken ct)
    {
        try
        {
            await mediator.Send(new RemovePermissionBundleMemberCommand(memberId), ct);
            return NoContent();
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
    }
}
