﻿using SecurityApp.API.Authorization;
using Mediator;
using Microsoft.AspNetCore.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SecurityApp.Application.Pricing.DTOs;
using SecurityApp.Application.Import.DTOs;
using SecurityApp.Application.Pricing.Queries;
using SecurityApp.Application.Import.Commands;
using SecurityApp.Application.Pricing.Commands;
using SecurityApp.Core.Shared.Exceptions;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/[controller]")]
[RequirePermission("pricing:read")]
[EnableRateLimiting("authenticated")]
public class PricingController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly ILogger<PricingController> _logger;

    public PricingController(IMediator mediator, ILogger<PricingController> logger)
    {
        _mediator = mediator;
        _logger = logger;
    }

    /// <summary>
    /// Get all stored prices for a security, with optional date range and source filter.
    /// </summary>
    [HttpGet("security/{securityId:guid}")]
    [ProducesResponseType(typeof(IEnumerable<PriceDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetPricesForSecurity(
        Guid securityId,
        [FromQuery] DateTime? fromDate = null,
        [FromQuery] DateTime? toDate = null,
        [FromQuery] string? source = null)
    {
        var query = new GetPricesForSecurityQuery(securityId, fromDate, toDate, source);
        var result = await _mediator.Send(query);
        return Ok(result);
    }

    /// <summary>
    /// Get the latest stored price for a security, optionally from a specific source.
    /// </summary>
    [HttpGet("security/{securityId:guid}/latest")]
    [ProducesResponseType(typeof(PriceDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetLatestPrice(Guid securityId, [FromQuery] string? source = null)
    {
        var query = new GetLatestPriceQuery(securityId, source);
        var result = await _mediator.Send(query);

        if (result == null)
            return NotFound(new { message = $"No price found for security {securityId}." });

        return Ok(result);
    }

    /// <summary>
    /// Fetch and store the current price for a security from an external provider.
    /// </summary>
    [HttpPost("import")]
    [RequirePermission("pricing:write")]
    [ProducesResponseType(typeof(BatchImportResult), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> ImportPrice([FromBody] ImportPriceRequest request)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        var command = new BatchImportPricesCommand(
            request.SecurityId,
            request.Symbol,
            null,
            null,
            request.ProviderName,
            userId);

        var result = await _mediator.Send(command);

        if (result.Failed > 0 && result.Succeeded == 0)
            return BadRequest(result);

        return Ok(result);
    }

    // -----------------------------------------------------------------------
    // Golden source / stale prices  (M15)
    // -----------------------------------------------------------------------

    /// <summary>
    /// Returns all currently-stale golden prices (is_stale = true &amp; is_golden = true).
    /// Used by operations teams to identify securities needing a price refresh.
    /// </summary>
    [HttpGet("stale")]
    [ProducesResponseType(typeof(IEnumerable<PriceDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetStalePrices(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 50)
    {
        var result = await _mediator.Send(new GetStalePricesQuery(page, pageSize));
        return Ok(result);
    }

    // -----------------------------------------------------------------------
    // Price override  (M17)
    // -----------------------------------------------------------------------

    /// <summary>
    /// Applies a manual override to an existing price row.
    /// Promotes the row to golden, demotes the previous golden for the same security/price-type,
    /// and writes a MANUAL_OVERRIDE lineage event.
    /// If a PriceOverride workflow definition is configured the request returns 202 (pending approval).
    /// </summary>
    [HttpPost("{priceId:guid}/override")]
    [RequirePermission("pricing:override")]
    [ProducesResponseType(typeof(PriceDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status202Accepted)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> OverridePrice(
        Guid priceId,
        [FromBody] OverridePriceRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Reason))
            return BadRequest(new { message = "Override reason is required." });

        if (request.NewValue <= 0)
            return BadRequest(new { message = "NewValue must be positive." });

        var userId = User.Identity?.Name;
        try
        {
            var result = await _mediator.Send(
                new OverridePriceCommand(priceId, request.NewValue, request.Reason, userId));
            return Ok(result);
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(new { message = ex.Message });
        }
    }

    // -----------------------------------------------------------------------
    // Pricing Rules
    // -----------------------------------------------------------------------

    /// <summary>Get all active pricing rules.</summary>
    [HttpGet("rules")]
    [ProducesResponseType(typeof(IEnumerable<PricingRuleDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAllRules()
    {
        var result = await _mediator.Send(new GetAllPricingRulesQuery());
        return Ok(result);
    }

    /// <summary>Get a single pricing rule by ID.</summary>
    [HttpGet("rules/{id:guid}")]
    [ProducesResponseType(typeof(PricingRuleDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetRuleById(Guid id)
    {
        var result = await _mediator.Send(new GetPricingRuleByIdQuery(id));
        if (result == null)
            return NotFound(new { message = $"Pricing rule {id} not found." });
        return Ok(result);
    }

    /// <summary>Create a new pricing rule.</summary>
    [HttpPost("rules")]
    [RequirePermission("pricing:manage")]
    [ProducesResponseType(typeof(PricingRuleDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> CreateRule([FromBody] CreatePricingRuleDto dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        var result = await _mediator.Send(new CreatePricingRuleCommand(dto, userId));
        return CreatedAtAction(nameof(GetRuleById), new { id = result.Id }, result);
    }

    /// <summary>Update an existing pricing rule.</summary>
    [HttpPut("rules/{id:guid}")]
    [RequirePermission("pricing:manage")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateRule(Guid id, [FromBody] CreatePricingRuleDto dto)
    {
        if (!ModelState.IsValid)
            return BadRequest(ModelState);

        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        try
        {
            await _mediator.Send(new UpdatePricingRuleCommand(id, dto, userId));
            return NoContent();
        }
        catch (InvalidOperationException ex)
        {
            return NotFound(new { message = ex.Message });
        }
    }

    /// <summary>Delete a pricing rule (soft-delete).</summary>
    [HttpDelete("rules/{id:guid}")]
    [RequirePermission("pricing:manage")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> DeleteRule(Guid id)
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        try
        {
            await _mediator.Send(new DeletePricingRuleCommand(id, userId));
            return NoContent();
        }
        catch (InvalidOperationException ex)
        {
            return NotFound(new { message = ex.Message });
        }
    }

    // -----------------------------------------------------------------------
    // Derived Prices
    // -----------------------------------------------------------------------

    /// <summary>
    /// Calculate derived prices for a rule.
    /// Optionally scope to a single security via query parameter.
    /// </summary>
    [HttpPost("derived/{ruleId:guid}/calculate")]
    [RequirePermission("pricing:write")]
    [ProducesResponseType(typeof(CalculationResult), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Calculate(Guid ruleId, [FromQuery] Guid? securityId = null)
    {
        var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
        var result = await _mediator.Send(new CalculateDerivedPriceCommand(ruleId, securityId, userId));
        if (!result.Success)
            return NotFound(new { message = result.Message });
        return Ok(result);
    }

    /// <summary>
    /// Get derived prices, optionally filtered by security and/or rule.
    /// </summary>
    [HttpGet("derived")]
    [ProducesResponseType(typeof(IEnumerable<DerivedPriceDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetDerivedPrices(
        [FromQuery] Guid? securityId = null,
        [FromQuery] Guid? ruleId = null)
    {
        var result = await _mediator.Send(new GetDerivedPricesQuery(securityId, ruleId));
        return Ok(result);
    }
}

/// <summary>Request body for importing a price for a security.</summary>
public record ImportPriceRequest(Guid SecurityId, string Symbol, string? ProviderName = null);
