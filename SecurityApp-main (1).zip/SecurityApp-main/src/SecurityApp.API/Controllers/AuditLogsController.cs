﻿using SecurityApp.API.Authorization;
using Mediator;
using Microsoft.AspNetCore.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using SecurityApp.Application.Audit.DTOs;
using SecurityApp.Application.Audit.Queries;
using SecurityApp.Application.Shared;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/[controller]")]
[RequirePermission("audit:read")]
public class AuditLogsController : ControllerBase
{
    private readonly IMediator _mediator;

    public AuditLogsController(IMediator mediator)
    {
        _mediator = mediator;
    }

    /// <summary>
    /// Query audit logs with optional filters.
    /// </summary>
    /// <param name="from">Start of date range (UTC).</param>
    /// <param name="to">End of date range (UTC).</param>
    /// <param name="userId">Filter by the user who triggered the action.</param>
    /// <param name="entityType">Filter by entity type, e.g. "Security", "Price".</param>
    /// <param name="pageNumber">1-based page number (default: 1).</param>
    /// <param name="pageSize">Page size (default: 50, max practical: 500).</param>
    [HttpGet]
    [ProducesResponseType(typeof(PagedResult<AuditLogDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetLogs(
        [FromQuery] DateTime? from = null,
        [FromQuery] DateTime? to = null,
        [FromQuery] Guid? userId = null,
        [FromQuery] string? entityType = null,
        [FromQuery] int pageNumber = 1,
        [FromQuery] int pageSize = 50)
    {
        var query = new GetAuditLogsQuery(from, to, userId, entityType, pageNumber, pageSize);
        var result = await _mediator.Send(query);
        return Ok(result);
    }
}
