using Mediator;
using Microsoft.AspNetCore.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using SecurityApp.Application.AppAuthorization.DTOs;
using SecurityApp.Application.AppAuthorization.Queries;

namespace SecurityApp.API.Controllers;

/// <summary>
/// Returns the calling user's effective authorization state for all app resources.
/// Angular calls GET /api/app-authorization/my-states once after login to drive
/// menu visibility, action rendering, and route guard decisions.
/// </summary>
[ApiController]
[ApiVersion("1.0")]
[Route("api/app-authorization")]
[Authorize]
public class AppAuthorizationController(IMediator mediator) : ControllerBase
{
    [HttpGet("my-states")]
    [ProducesResponseType(typeof(AppAuthorizationStateDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetMyStates(CancellationToken ct)
    {
        var permissions = User.Claims
            .Where(c => c.Type is "permissions" or "permission")
            .Select(c => c.Value);

        var result = await mediator.Send(new GetMyAppAuthorizationStateQuery(permissions), ct);
        return Ok(result);
    }
}
