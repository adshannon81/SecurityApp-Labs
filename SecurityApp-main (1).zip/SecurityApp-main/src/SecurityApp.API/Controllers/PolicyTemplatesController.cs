using Asp.Versioning;
using Mediator;
using Microsoft.AspNetCore.Mvc;
using SecurityApp.API.Authorization;
using SecurityApp.Application.Permissions.Commands;
using SecurityApp.Application.Permissions.DTOs;
using SecurityApp.Application.Permissions.Queries;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/policy-templates")]
[RequirePermission("admin:manage-permissions")]
public class PolicyTemplatesController(IMediator mediator) : ControllerBase
{
    [HttpGet]
    [ProducesResponseType(typeof(IReadOnlyList<PolicyTemplateDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(CancellationToken ct)
    {
        var result = await mediator.Send(new GetAllPolicyTemplatesQuery(), ct);
        return Ok(result);
    }

    [HttpGet("{id:guid}")]
    [ProducesResponseType(typeof(PolicyTemplateDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id, CancellationToken ct)
    {
        var result = await mediator.Send(new GetPolicyTemplateByIdQuery(id), ct);
        return result is null ? NotFound() : Ok(result);
    }

    [HttpPost]
    [ProducesResponseType(typeof(PolicyTemplateDto), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create([FromBody] CreatePolicyTemplateRequest request, CancellationToken ct)
    {
        var userId = User.FindFirst("sub")?.Value;
        var result = await mediator.Send(new CreatePolicyTemplateCommand(request, userId), ct);
        return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
    }

    [HttpPut("{id:guid}")]
    [ProducesResponseType(typeof(PolicyTemplateDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdatePolicyTemplateRequest request, CancellationToken ct)
    {
        try
        {
            var userId = User.FindFirst("sub")?.Value;
            var result = await mediator.Send(new UpdatePolicyTemplateCommand(id, request, userId), ct);
            return Ok(result);
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
    }

    [HttpDelete("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        try
        {
            await mediator.Send(new DeletePolicyTemplateCommand(id), ct);
            return NoContent();
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
    }
}
