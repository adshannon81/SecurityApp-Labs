﻿using SecurityApp.API.Authorization;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using Mediator;
using Microsoft.AspNetCore.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Options;
using SecurityApp.Core.Securities.Interfaces;
using SecurityApp.Core.Shared.Configuration;
using SecurityApp.Core.Workflow.Interfaces;
using SecurityApp.Application.Securities.DTOs;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Application.Securities.Queries;
using SecurityApp.Core.Workflow.Enums;
using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Core.Audit.Entities;
using SecurityApp.Core.Audit.Enums;
using SecurityApp.Application.Audit.Queries;
using SecurityApp.Application.Audit.DTOs;

namespace SecurityApp.API.Controllers;

/// <summary>
/// Exports security data in JSON, XML, or delimiter-separated (CSV/TSV/pipe) format.
///
/// Broad export (all securities with optional filters):
///   GET /api/export/securities?format=json
///   GET /api/export/securities?format=xml&amp;type=Bond&amp;isActive=true
///   GET /api/export/securities?format=csv&amp;delimiter=,
///
/// Targeted export (specific securities by ID or identifier):
///   POST /api/export/securities  { "ids": [...], "identifiers": [{"identifierType":"Ticker","identifierValue":"IBM"}], "format":"csv" }
/// </summary>
[ApiController]
[ApiVersion("1.0")]
[Route("api/[controller]")]
[RequirePermission("securities:read")]
[EnableRateLimiting("authenticated")]
public class ExportController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly ISecurityExportService _exportService;
    private readonly ILogger<ExportController> _logger;
    private readonly IOptions<ColumnMappingsOptions> _mappingOptions;
    private readonly IWorkflowEngine _workflowEngine;
    private readonly IImportUoW _importUoW;

    public ExportController(
        IMediator mediator,
        ISecurityExportService exportService,
        ILogger<ExportController> logger,
        IOptions<ColumnMappingsOptions> mappingOptions,
        IWorkflowEngine workflowEngine,
        IImportUoW importUoW)
    {
        _mediator        = mediator;
        _exportService   = exportService;
        _logger          = logger;
        _mappingOptions  = mappingOptions;
        _workflowEngine  = workflowEngine;
        _importUoW       = importUoW;
    }

    /// <summary>
    /// Broad export - downloads all securities, with optional type and active-status filters.
    /// </summary>
    [HttpGet("securities")]
    [RequirePermission("exports:run")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> ExportSecurities(
        [FromQuery] string  format    = "json",
        [FromQuery] string  delimiter = ",",
        [FromQuery] string? type      = null,
        [FromQuery] bool?   isActive  = null,
        [FromQuery] string  profile   = "Default",
        CancellationToken   cancellationToken = default)
    {
        if (!Enum.TryParse<ExportFormat>(format, ignoreCase: true, out var fmt))
            return BadRequest($"Unsupported format '{format}'. Use: json, xml, csv.");

        char sep = ParseDelimiter(delimiter, out var delimError);
        if (delimError != null)
            return BadRequest(delimError);

        // Workflow gate: check if a pending approval exists or trigger one
        var exportId = Guid.NewGuid(); // ephemeral identifier for this export request
        var triggeredBy = User.FindFirst("sub")?.Value
                       ?? User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                       ?? "unknown";
        var gateResult = await ApplyWorkflowGateAsync(exportId, triggeredBy, new { type, isActive, profile }, cancellationToken);
        if (gateResult != null) return gateResult;

        _mappingOptions.Value.Export.TryGetValue(profile, out var exportProfile);

        var records = (await _mediator.Send(
            new ExportSecuritiesQuery(type, isActive), cancellationToken)).ToList();

        _logger.LogInformation(
            "Exporting {Count} securities as {Format} (profile: {Profile})", records.Count, fmt, profile);

        var bytes       = _exportService.Export(records, fmt, sep, exportProfile);
        var contentType = _exportService.GetContentType(fmt);
        var fileName    = _exportService.GetFileName(fmt);

        return File(bytes, contentType, fileName);
    }

    /// <summary>
    /// Targeted export - downloads a specific subset of securities identified by GUID(s),
    /// by identifier type+value pairs (Ticker, ISIN, CUSIP, -), or both.
    /// Supplying both <c>ids</c> and <c>identifiers</c> returns the union.
    /// Omit both to export all securities (same as GET with no further filters).
    /// </summary>
    /// <remarks>
    /// Example body:
    /// <code>
    /// {
    ///   "ids": ["a1b2c3..."],
    ///   "identifiers": [
    ///     { "identifierType": "Ticker", "identifierValue": "IBM" },
    ///     { "identifierType": "ISIN",   "identifierValue": "US4592001014" }
    ///   ],
    ///   "format": "csv",
    ///   "delimiter": ","
    /// }
    /// </code>
    /// </remarks>
    [HttpPost("securities")]
    [RequirePermission("exports:run")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> ExportSecuritiesTargeted(
        [FromBody] ExportSecuritiesRequest request,
        CancellationToken cancellationToken = default)
    {
        if (!Enum.TryParse<ExportFormat>(request.Format, ignoreCase: true, out var fmt))
            return BadRequest($"Unsupported format '{request.Format}'. Use: json, xml, csv.");

        char sep = ParseDelimiter(request.Delimiter, out var delimError);
        if (delimError != null)
            return BadRequest(delimError);

        // Workflow gate
        var exportId = Guid.NewGuid();
        var triggeredBy = User.FindFirst("sub")?.Value
                       ?? User.FindFirst(ClaimTypes.NameIdentifier)?.Value
                       ?? "unknown";
        var gateResult = await ApplyWorkflowGateAsync(exportId, triggeredBy, request, cancellationToken);
        if (gateResult != null) return gateResult;

        _mappingOptions.Value.Export.TryGetValue(request.Profile, out var exportProfile);

        var records = (await _mediator.Send(
            new ExportSecuritiesQuery(
                Type:        request.Type,
                IsActive:    request.IsActive,
                Identifiers: request.Identifiers),
            cancellationToken)).ToList();

        bool wasTargeted = request.Identifiers is { Count: > 0 };
        if (wasTargeted && records.Count == 0)
            return NotFound(new { message = "No matching securities found for the supplied ids/identifiers." });

        _logger.LogInformation("Targeted export: {Count} securities as {Format}", records.Count, fmt);

        var bytes       = _exportService.Export(records, fmt, sep, exportProfile);
        var contentType = _exportService.GetContentType(fmt);
        var fileName    = _exportService.GetFileName(fmt);

        return File(bytes, contentType, fileName);
    }

    /// <summary>
    /// Export audit log records as CSV or NDJSON.
    /// The export request itself is appended to audit_log.
    /// </summary>
    [HttpGet("audit")]
    [RequirePermission(AppPermissions.ExportsRun)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> ExportAudit(
        [FromQuery] DateTime? dateFrom    = null,
        [FromQuery] DateTime? dateTo      = null,
        [FromQuery] string?   entityType  = null,
        [FromQuery] Guid?     entityId    = null,
        [FromQuery] string    format      = "csv",
        CancellationToken     cancellationToken = default)
    {
        if (!format.Equals("csv",    StringComparison.OrdinalIgnoreCase) &&
            !format.Equals("ndjson", StringComparison.OrdinalIgnoreCase))
            return BadRequest("Unsupported format. Use: csv, ndjson.");

        // Log this export request to audit_log (the request itself is a noteworthy event)
        var userId   = Guid.TryParse(
            User.FindFirst("sub")?.Value ?? User.FindFirst(ClaimTypes.NameIdentifier)?.Value,
            out var uid) ? uid : (Guid?)null;
        var userName = User.FindFirst("sub")?.Value ?? User.Identity?.Name;

        await _importUoW.AuditLogs.AddAsync(new AuditLog
        {
            EntityType = "AuditLog",
            Action     = AuditAction.Export,
            UserId     = userId,
            UserName   = userName,
            IpAddress  = HttpContext.Connection.RemoteIpAddress?.ToString(),
            Details    = JsonSerializer.Serialize(new { dateFrom, dateTo, entityType, entityId, format }),
            Source     = "Http"
        }, cancellationToken);
        await _importUoW.SaveChangesAsync(cancellationToken);

        var records = (await _mediator.Send(
            new ExportAuditLogsQuery(dateFrom, dateTo, entityType, entityId), cancellationToken)).ToList();

        _logger.LogInformation(
            "Audit export: {Count} rows as {Format} (user: {User})", records.Count, format, userName);

        if (format.Equals("ndjson", StringComparison.OrdinalIgnoreCase))
        {
            var ndjson = string.Join('\n', records.Select(r => JsonSerializer.Serialize(r)));
            var bytes  = Encoding.UTF8.GetBytes(ndjson);
            return File(bytes, "application/x-ndjson",
                $"audit-export-{DateTime.UtcNow:yyyyMMdd-HHmmss}.ndjson");
        }
        else
        {
            var csv   = BuildAuditCsv(records);
            var bytes = Encoding.UTF8.GetBytes(csv);
            return File(bytes, "text/csv",
                $"audit-export-{DateTime.UtcNow:yyyyMMdd-HHmmss}.csv");
        }
    }

    // ------------------------------------------
    // Helper
    // ------------------------------------------

    private static char ParseDelimiter(string delimiter, out string? error)
    {
        error = null;

        if (string.IsNullOrEmpty(delimiter)) return ',';

        // Accept URL-decoded tab either as actual tab char or the escape sequence
        if (delimiter == "\t" || delimiter == "\\t") return '\t';

        // Accept any single printable character directly
        if (delimiter.Length == 1) return delimiter[0];

        // Backwards-compatible word aliases (deprecated - prefer actual characters)
        return delimiter.ToLowerInvariant() switch
        {
            "comma"              => ',',
            "tab"                => '\t',
            "pipe"               => '|',
            "semi" or "semicolon" => ';',
            _ => SetError(out error,
                    $"Unsupported delimiter '{delimiter}'. Supply the actual character, e.g. ',' or '|'.")
        };
    }

    // Returns a dummy char; the out-error signals the caller to return BadRequest
    private static char SetError(out string? error, string message)
    {
        error = message;
        return ',';
    }

    /// <summary>
    /// Checks for an active pending workflow gate for the given exportId.
    /// If none exists, triggers a new one. Returns 202 Accepted when the workflow
    /// requires approval, or null when the export can proceed.
    /// </summary>
    private async Task<IActionResult?> ApplyWorkflowGateAsync(
        Guid exportId, string triggeredBy, object payload, CancellationToken ct)
    {
        // Check whether a pending gate already exists for this entity
        var existing = await _workflowEngine.GetActiveGateAsync(WorkflowTriggerType.Export, exportId, ct);
        if (existing is { Status: WorkflowStatus.Pending })
        {
            return Accepted(new
            {
                message            = "Export is pending workflow approval.",
                workflowInstanceId = existing.Id
            });
        }

        // Trigger a new workflow
        var instance = await _workflowEngine.TriggerAsync(
            WorkflowTriggerType.Export, nameof(ExportController), exportId, payload, triggeredBy, ct);

        if (instance.Status != WorkflowStatus.Approved)
        {
            return Accepted(new
            {
                message            = "Export submitted for workflow approval.",
                workflowInstanceId = instance.Id,
                status             = instance.Status.ToString()
            });
        }

        return null; // proceed with export
    }

    private static string BuildAuditCsv(IEnumerable<AuditLogDto> records)
    {
        var sb = new StringBuilder();
        sb.AppendLine("Id,EntityType,Action,UserId,UserName,IpAddress,EntityId,CreatedAt," +
                      "CorrelationId,CausationId,Source,ChangedFields");
        foreach (var r in records)
        {
            sb.AppendLine(string.Join(',',
                EscapeCsv(r.Id.ToString()),
                EscapeCsv(r.EntityType),
                EscapeCsv(r.Action),
                EscapeCsv(r.UserId?.ToString()),
                EscapeCsv(r.UserName),
                EscapeCsv(r.IpAddress),
                EscapeCsv(r.EntityId?.ToString()),
                EscapeCsv(r.CreatedAt.ToString("O")),
                EscapeCsv(r.CorrelationId?.ToString()),
                EscapeCsv(r.CausationId?.ToString()),
                EscapeCsv(r.Source),
                EscapeCsv(r.ChangedFields)));
        }
        return sb.ToString();
    }

    private static string EscapeCsv(string? value)
    {
        if (string.IsNullOrEmpty(value)) return string.Empty;
        if (value.Contains(',') || value.Contains('"') || value.Contains('\n'))
            return "\"" + value.Replace("\"", "\"\"") + "\"";
        return value;
    }
}
