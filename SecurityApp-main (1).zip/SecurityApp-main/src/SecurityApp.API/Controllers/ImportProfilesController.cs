﻿using SecurityApp.API.Authorization;
using Mediator;
using Microsoft.AspNetCore.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using SecurityApp.Core.Import.Entities;
using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Application.Import.DTOs;

namespace SecurityApp.API.Controllers;

/// <summary>
/// CRUD API for database-backed import profiles (column mappings and validation rules).
/// Profiles are consumed by the file connectors (FlatFile, JsonFile, XmlFile) at plugin init time
/// and by the file upload endpoint (<c>POST /api/import/file/securities?profileName=â€¦</c>).
/// </summary>
[ApiController]
[ApiVersion("1.0")]
[Route("api/import/profiles")]
[RequirePermission("imports:read")]
public class ImportProfilesController : ControllerBase
{
    private readonly IImportProfileService _profileService;
    private readonly ILogger<ImportProfilesController> _logger;

    public ImportProfilesController(
        IImportProfileService profileService,
        ILogger<ImportProfilesController> logger)
    {
        _profileService = profileService;
        _logger         = logger;
    }

    // -- List ------------------------------------------------------------------

    /// <summary>Returns all active profiles for a given connector source type.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<ImportProfileDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetProfiles([FromQuery] string? sourceType = null, CancellationToken ct = default)
    {
        if (!string.IsNullOrEmpty(sourceType))
        {
            var profiles = await _profileService.GetActiveProfilesAsync(sourceType, ct);
            return Ok(profiles.Select(Map));
        }

        // Return active profiles across all source types (3 calls, one per type)
        var all = new List<ImportProfileDto>();
        foreach (var type in new[] { "FlatFile", "JsonFile", "XmlFile" })
            all.AddRange((await _profileService.GetActiveProfilesAsync(type, ct)).Select(Map));
        return Ok(all);
    }

    /// <summary>Returns a single profile by id.</summary>
    [HttpGet("{id:guid}")]
    [ProducesResponseType(typeof(ImportProfileDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetProfile(Guid id, CancellationToken ct = default)
    {
        var profile = await _profileService.GetByIdAsync(id, ct);
        return profile is null ? NotFound() : Ok(Map(profile));
    }

    // -- Create ----------------------------------------------------------------

    [HttpPost]
    [RequirePermission("imports:manage")]
    [ProducesResponseType(typeof(ImportProfileDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> CreateProfile([FromBody] CreateImportProfileRequest request, CancellationToken ct = default)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);

        var profile = new ImportProfile
        {
            Name         = request.Name,
            Description  = request.Description,
            SourceType   = request.SourceType,
            FilePattern  = request.FilePattern,
            Folder       = request.Folder,
            Delimiter    = request.Delimiter,
            TextQualifier = request.TextQualifier,
            HasHeader    = request.HasHeader,
            SkipRows     = request.SkipRows,
            RecordsPath  = request.RecordsPath,
            RecordsXPath = request.RecordsXPath,
            IsActive     = true,
            Columns      = request.Columns.Select((c, idx) => new ImportProfileColumn
            {
                SourceColumn = c.SourceColumn,
                TargetField  = c.TargetField,
                SortOrder    = c.SortOrder == 0 ? idx : c.SortOrder,
                Validations  = c.Validations.Select(v => new ImportProfileColumnValidation
                {
                    RuleType     = v.RuleType,
                    RuleValue    = v.RuleValue,
                    Condition    = v.Condition,
                    ErrorMessage = v.ErrorMessage,
                    Severity     = v.Severity,
                    IsActive     = true
                }).ToList()
            }).ToList(),
            RowValidations = request.RowValidations.Select((r, idx) => new ImportProfileRowValidation
            {
                Expression   = r.Expression,
                ErrorMessage = r.ErrorMessage,
                Severity     = r.Severity,
                SortOrder    = r.SortOrder == 0 ? idx : r.SortOrder,
                IsActive     = true
            }).ToList()
        };

        var created = await _profileService.CreateAsync(profile, ct);
        var dto     = Map(created);
        return CreatedAtAction(nameof(GetProfile), new { id = created.Id }, dto);
    }

    // -- Update ----------------------------------------------------------------

    [HttpPatch("{id:guid}")]
    [RequirePermission("imports:manage")]
    [ProducesResponseType(typeof(ImportProfileDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateProfile(Guid id, [FromBody] UpdateImportProfileRequest request, CancellationToken ct = default)
    {
        var profile = await _profileService.GetByIdAsync(id, ct);
        if (profile is null) return NotFound();

        // Only update supplied fields
        if (request.Description   is not null) profile.Description   = request.Description;
        if (request.FilePattern   is not null) profile.FilePattern   = request.FilePattern;
        if (request.Folder        is not null) profile.Folder        = request.Folder;
        if (request.Delimiter     is not null) profile.Delimiter     = request.Delimiter;
        if (request.TextQualifier is not null) profile.TextQualifier = request.TextQualifier;
        if (request.HasHeader     is not null) profile.HasHeader     = request.HasHeader.Value;
        if (request.SkipRows      is not null) profile.SkipRows      = request.SkipRows.Value;
        if (request.RecordsPath   is not null) profile.RecordsPath   = request.RecordsPath;
        if (request.RecordsXPath  is not null) profile.RecordsXPath  = request.RecordsXPath;
        if (request.IsActive      is not null) profile.IsActive      = request.IsActive.Value;

        await _profileService.UpdateAsync(profile, ct);
        return Ok(Map(profile));
    }

    // -- Deactivate ------------------------------------------------------------

    [HttpDelete("{id:guid}")]
    [RequirePermission("imports:manage")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> DeactivateProfile(Guid id, CancellationToken ct = default)
    {
        var existing = await _profileService.GetByIdAsync(id, ct);
        if (existing is null) return NotFound();
        await _profileService.DeactivateAsync(id, ct);
        return NoContent();
    }

    // -- Column management -----------------------------------------------------

    /// <summary>Replaces all columns on a profile atomically.</summary>
    [HttpPut("{id:guid}/columns")]
    [RequirePermission("imports:manage")]
    [ProducesResponseType(typeof(ImportProfileDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> ReplaceColumns(Guid id, [FromBody] List<ImportProfileColumnRequest> columns, CancellationToken ct = default)
    {
        var existing = await _profileService.GetByIdAsync(id, ct);
        if (existing is null) return NotFound();

        var entities = columns.Select((c, idx) => new ImportProfileColumn
        {
            ProfileId    = id,
            SourceColumn = c.SourceColumn,
            TargetField  = c.TargetField,
            SortOrder    = c.SortOrder == 0 ? idx : c.SortOrder,
            Validations  = c.Validations.Select(v => new ImportProfileColumnValidation
            {
                RuleType     = v.RuleType,
                RuleValue    = v.RuleValue,
                Condition    = v.Condition,
                ErrorMessage = v.ErrorMessage,
                Severity     = v.Severity,
                IsActive     = true
            }).ToList()
        }).ToList();

        await _profileService.ReplaceColumnsAsync(id, entities, ct);
        var updated = await _profileService.GetByIdAsync(id, ct);
        return Ok(Map(updated!));
    }

    // -- Row validation management ---------------------------------------------

    [HttpPost("{id:guid}/row-validations")]
    [RequirePermission("imports:manage")]
    [ProducesResponseType(typeof(ImportProfileRowValidationDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> AddRowValidation(Guid id, [FromBody] ImportProfileRowValidationRequest request, CancellationToken ct = default)
    {
        var existing = await _profileService.GetByIdAsync(id, ct);
        if (existing is null) return NotFound();

        var entity = new ImportProfileRowValidation
        {
            ProfileId    = id,
            Expression   = request.Expression,
            ErrorMessage = request.ErrorMessage,
            Severity     = request.Severity,
            SortOrder    = request.SortOrder,
            IsActive     = true
        };

        var created = await _profileService.AddRowValidationAsync(entity, ct);
        return CreatedAtAction(nameof(GetProfile), new { id }, MapRowValidation(created));
    }

    [HttpDelete("{id:guid}/row-validations/{validationId:guid}")]
    [RequirePermission("imports:manage")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> RemoveRowValidation(Guid id, Guid validationId, CancellationToken ct = default)
    {
        await _profileService.RemoveRowValidationAsync(validationId, ct);
        return NoContent();
    }

    // -- Mapping helpers -------------------------------------------------------

    private static ImportProfileDto Map(ImportProfile p) => new()
    {
        Id           = p.Id,
        Name         = p.Name,
        Description  = p.Description,
        SourceType   = p.SourceType,
        FilePattern  = p.FilePattern,
        Folder       = p.Folder,
        Delimiter    = p.Delimiter,
        TextQualifier = p.TextQualifier,
        HasHeader    = p.HasHeader,
        SkipRows     = p.SkipRows,
        RecordsPath  = p.RecordsPath,
        RecordsXPath = p.RecordsXPath,
        IsActive     = p.IsActive,
        CreatedAt    = p.CreatedAt,
        LastModifiedAt = p.LastModifiedAt,
        Columns      = p.Columns.Select(c => new ImportProfileColumnDto
        {
            Id           = c.Id,
            SourceColumn = c.SourceColumn,
            TargetField  = c.TargetField,
            SortOrder    = c.SortOrder,
            Validations  = c.Validations.Select(v => new ImportProfileColumnValidationDto
            {
                Id           = v.Id,
                RuleType     = v.RuleType,
                RuleValue    = v.RuleValue,
                Condition    = v.Condition,
                ErrorMessage = v.ErrorMessage,
                Severity     = v.Severity,
                IsActive     = v.IsActive
            }).ToList()
        }).ToList(),
        RowValidations = p.RowValidations.Select(MapRowValidation).ToList()
    };

    private static ImportProfileRowValidationDto MapRowValidation(ImportProfileRowValidation r) => new()
    {
        Id           = r.Id,
        Expression   = r.Expression,
        ErrorMessage = r.ErrorMessage,
        Severity     = r.Severity,
        SortOrder    = r.SortOrder,
        IsActive     = r.IsActive
    };
}
