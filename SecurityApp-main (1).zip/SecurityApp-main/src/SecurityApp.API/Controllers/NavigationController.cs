using Mediator;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SecurityApp.Application.AppAuthorization.DTOs;
using SecurityApp.Application.AppAuthorization.Queries;

namespace SecurityApp.API.Controllers;

/// <summary>
/// Returns the navigation menu tree for the authenticated user.
/// Angular calls this once after login to build the sidebar dynamically.
/// Replaces the hardcoded NAV_ENTRIES constant in sidebar.component.ts.
/// </summary>
[ApiController]
[Route("api/navigation")]
[Authorize]
public class NavigationController(IMediator mediator) : ControllerBase
{
    /// <summary>
    /// Returns the full nav tree filtered to resources visible to the calling user.
    /// Response is safe to cache client-side for the duration of the session.
    /// </summary>
    [HttpGet("menu")]
    [ProducesResponseType(typeof(IReadOnlyList<NavGroupDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetMenu(CancellationToken ct)
    {
        var permissions = User.Claims
            .Where(c => c.Type is "permissions" or "permission")
            .Select(c => c.Value);

        var result = await mediator.Send(new GetNavigationMenuQuery(permissions), ct);
        return Ok(result);
    }
}
