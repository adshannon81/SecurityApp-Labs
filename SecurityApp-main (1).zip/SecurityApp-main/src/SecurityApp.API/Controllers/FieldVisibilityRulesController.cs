using Mediator;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using SecurityApp.API.Authorization;
using SecurityApp.API.Json;
using SecurityApp.Application.FieldVisibility.Commands;
using SecurityApp.Application.FieldVisibility.DTOs;
using SecurityApp.Application.FieldVisibility.Queries;

namespace SecurityApp.API.Controllers;

/// <summary>
/// CRUD management of dynamic field-visibility rules.
///
/// Required Keycloak client role: admin:field-visibility
/// Assign this role to any realm role that should be able to manage field rules
/// (e.g. your BackOffice or System-Admin composite role).
/// </summary>
[ApiController]
[ApiVersion("1.0")]
[Route("api/field-visibility-rules")]
[RequirePermission("admin:field-visibility")]
public class FieldVisibilityRulesController(IMediator mediator, FieldVisibilityRuleCache ruleCache)
    : ControllerBase
{
    [HttpGet]
    [ProducesResponseType(typeof(IReadOnlyList<FieldVisibilityRuleDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(CancellationToken ct)
    {
        var result = await mediator.Send(new GetAllFieldVisibilityRulesQuery(), ct);
        return Ok(result);
    }

    [HttpGet("{id:guid}")]
    [ProducesResponseType(typeof(FieldVisibilityRuleDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id, CancellationToken ct)
    {
        var result = await mediator.Send(new GetFieldVisibilityRuleByIdQuery(id), ct);
        return result is null ? NotFound() : Ok(result);
    }

    [HttpGet("by-field/{fieldId:guid}")]
    [ProducesResponseType(typeof(IReadOnlyList<FieldVisibilityRuleDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetByField(Guid fieldId, CancellationToken ct)
    {
        var result = await mediator.Send(new GetFieldVisibilityRulesByFieldQuery(fieldId), ct);
        return Ok(result);
    }

    [HttpPost]
    [ProducesResponseType(typeof(FieldVisibilityRuleDto), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create([FromBody] CreateFieldVisibilityRuleRequest request, CancellationToken ct)
    {
        var userId = User.FindFirst("sub")?.Value;
        var result = await mediator.Send(new CreateFieldVisibilityRuleCommand(request, userId), ct);
        ruleCache.Invalidate();
        return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
    }

    [HttpPut("{id:guid}")]
    [ProducesResponseType(typeof(FieldVisibilityRuleDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateFieldVisibilityRuleRequest request, CancellationToken ct)
    {
        try
        {
            var userId = User.FindFirst("sub")?.Value;
            var result = await mediator.Send(new UpdateFieldVisibilityRuleCommand(id, request, userId), ct);
            ruleCache.Invalidate();
            return Ok(result);
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
    }

    [HttpDelete("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        try
        {
            await mediator.Send(new DeleteFieldVisibilityRuleCommand(id), ct);
            ruleCache.Invalidate();
            return NoContent();
        }
        catch (KeyNotFoundException)
        {
            return NotFound();
        }
    }
}
