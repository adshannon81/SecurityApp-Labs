using Microsoft.AspNetCore.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using SecurityApp.Infrastructure.Persistence;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/[controller]")]
[Authorize]
[EnableRateLimiting("authenticated")]
public class CountriesController(ApplicationDbContext db) : ControllerBase
{
    /// <summary>Returns the list of countries, optionally filtered to active records only.</summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(
        [FromQuery] bool activeOnly = true,
        CancellationToken ct = default)
    {
        var query = db.Countries.AsNoTracking();

        if (activeOnly)
            query = query.Where(c => c.IsActive);

        var result = await query
            .OrderBy(c => c.Name)
            .Select(c => new
            {
                c.Alpha2,
                c.Alpha3,
                c.NumericCode,
                c.Name,
                c.Tld,
                c.IsActive,
            })
            .ToListAsync(ct);

        return Ok(result);
    }

    /// <summary>Returns a single country by its ISO 3166-1 alpha-2 code.</summary>
    [HttpGet("{alpha2}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetByAlpha2(string alpha2, CancellationToken ct)
    {
        var country = await db.Countries
            .AsNoTracking()
            .Where(c => c.Alpha2 == alpha2.ToUpperInvariant())
            .Select(c => new
            {
                c.Alpha2,
                c.Alpha3,
                c.NumericCode,
                c.Name,
                c.Tld,
                c.IsActive,
            })
            .FirstOrDefaultAsync(ct);

        return country is null ? NotFound() : Ok(country);
    }

    /// <summary>
    /// Returns all currency associations for a country, including the primary currency
    /// and any additional legal-tender / operational ones.
    /// </summary>
    [HttpGet("{alpha2}/currencies")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetCurrencies(string alpha2, CancellationToken ct)
    {
        var key = alpha2.ToUpperInvariant();
        var exists = await db.Countries.AnyAsync(c => c.Alpha2 == key, ct);
        if (!exists) return NotFound();

        var links = await db.CountryCurrencies
            .AsNoTracking()
            .Where(cc => cc.CountryAlpha2 == key)
            .OrderByDescending(cc => cc.IsPrimary)
            .ThenBy(cc => cc.CurrencyCode)
            .Select(cc => new
            {
                cc.CurrencyCode,
                cc.IsPrimary,
                cc.IsLegalTender,
                cc.IsOperational,
                Currency = db.Currencies
                    .Where(c => c.Code == cc.CurrencyCode)
                    .Select(c => new { c.Name, c.Symbol, c.DisplayDecimals })
                    .FirstOrDefault(),
            })
            .ToListAsync(ct);

        return Ok(links);
    }
}
