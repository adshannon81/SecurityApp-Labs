using Mediator;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using SecurityApp.API.Authorization;
using SecurityApp.Application.Portfolio.Commands;
using SecurityApp.Application.Portfolio.DTOs;
using SecurityApp.Application.Portfolio.Queries;
using SecurityApp.Application.Shared;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/clients")]
[RequirePermission("portfolios:read")]
public class ClientsController(IMediator mediator) : ControllerBase
{
    [HttpGet]
    [ProducesResponseType(typeof(PagedResult<ClientDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll([FromQuery] int page = 1, [FromQuery] int pageSize = 50, CancellationToken ct = default)
        => Ok(await mediator.Send(new GetAllClientsQuery(page, pageSize), ct));

    [HttpGet("{id:guid}")]
    [ProducesResponseType(typeof(ClientDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id, CancellationToken ct)
    {
        var result = await mediator.Send(new GetClientByIdQuery(id), ct);
        return result is null ? NotFound() : Ok(result);
    }

    [HttpPost]
    [RequirePermission("portfolios:write")]
    [ProducesResponseType(typeof(ClientDto), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create([FromBody] CreateClientRequest request, CancellationToken ct)
    {
        var userId = User.FindFirst("sub")?.Value;
        var result = await mediator.Send(new CreateClientCommand(request, userId), ct);
        return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
    }

    [HttpPut("{id:guid}")]
    [RequirePermission("portfolios:write")]
    [ProducesResponseType(typeof(ClientDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateClientRequest request, CancellationToken ct)
    {
        var userId = User.FindFirst("sub")?.Value;
        var result = await mediator.Send(new UpdateClientCommand(id, request, userId), ct);
        return Ok(result);
    }

    [HttpDelete("{id:guid}")]
    [RequirePermission("portfolios:write")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        await mediator.Send(new DeleteClientCommand(id), ct);
        return NoContent();
    }

    // ── Contacts ────────────────────────────────────────────────────────────

    [HttpPost("{clientId:guid}/contacts")]
    [RequirePermission("portfolios:write")]
    [ProducesResponseType(typeof(ClientContactDto), StatusCodes.Status201Created)]
    public async Task<IActionResult> AddContact(Guid clientId, [FromBody] CreateClientContactRequest request, CancellationToken ct)
    {
        var userId = User.FindFirst("sub")?.Value;
        var result = await mediator.Send(new AddClientContactCommand(clientId, request, userId), ct);
        return CreatedAtAction(nameof(GetById), new { id = clientId }, result);
    }

    [HttpPut("{clientId:guid}/contacts/{contactId:guid}")]
    [RequirePermission("portfolios:write")]
    [ProducesResponseType(typeof(ClientContactDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> UpdateContact(Guid clientId, Guid contactId, [FromBody] UpdateClientContactRequest request, CancellationToken ct)
    {
        var userId = User.FindFirst("sub")?.Value;
        var result = await mediator.Send(new UpdateClientContactCommand(contactId, request, userId), ct);
        return Ok(result);
    }

    [HttpDelete("{clientId:guid}/contacts/{contactId:guid}")]
    [RequirePermission("portfolios:write")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> RemoveContact(Guid clientId, Guid contactId, CancellationToken ct)
    {
        await mediator.Send(new RemoveClientContactCommand(contactId), ct);
        return NoContent();
    }
}

[ApiController]
[ApiVersion("1.0")]
[Route("api/portfolios")]
[RequirePermission("portfolios:read")]
public class PortfoliosController(IMediator mediator) : ControllerBase
{
    [HttpGet]
    [ProducesResponseType(typeof(PagedResult<PortfolioDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll([FromQuery] Guid? clientId, [FromQuery] int page = 1, [FromQuery] int pageSize = 50, CancellationToken ct = default)
        => Ok(await mediator.Send(new GetAllPortfoliosQuery(clientId, page, pageSize), ct));

    [HttpGet("{id:guid}")]
    [ProducesResponseType(typeof(PortfolioDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id, CancellationToken ct)
    {
        var result = await mediator.Send(new GetPortfolioByIdQuery(id), ct);
        return result is null ? NotFound() : Ok(result);
    }

    [HttpPost]
    [RequirePermission("portfolios:write")]
    [ProducesResponseType(typeof(PortfolioDto), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create([FromBody] CreatePortfolioRequest request, CancellationToken ct)
    {
        var userId = User.FindFirst("sub")?.Value;
        var result = await mediator.Send(new CreatePortfolioCommand(request, userId), ct);
        return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
    }

    [HttpPut("{id:guid}")]
    [RequirePermission("portfolios:write")]
    [ProducesResponseType(typeof(PortfolioDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdatePortfolioRequest request, CancellationToken ct)
    {
        var userId = User.FindFirst("sub")?.Value;
        var result = await mediator.Send(new UpdatePortfolioCommand(id, request, userId), ct);
        return Ok(result);
    }

    [HttpDelete("{id:guid}")]
    [RequirePermission("portfolios:write")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        await mediator.Send(new DeletePortfolioCommand(id), ct);
        return NoContent();
    }
}

[ApiController]
[ApiVersion("1.0")]
[Route("api/positions")]
[RequirePermission("portfolios:read")]
public class PositionsController(IMediator mediator) : ControllerBase
{
    [HttpGet]
    [ProducesResponseType(typeof(PagedResult<PositionDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(
        [FromQuery] Guid? portfolioId,
        [FromQuery] Guid? securityId,
        [FromQuery] DateOnly? asOfDate,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 50,
        CancellationToken ct = default)
        => Ok(await mediator.Send(new GetAllPositionsQuery(portfolioId, securityId, asOfDate, true, page, pageSize), ct));

    [HttpGet("{id:guid}")]
    [ProducesResponseType(typeof(PositionDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id, CancellationToken ct)
    {
        var result = await mediator.Send(new GetPositionByIdQuery(id), ct);
        return result is null ? NotFound() : Ok(result);
    }

    [HttpPost]
    [RequirePermission("portfolios:write")]
    [ProducesResponseType(typeof(PositionDto), StatusCodes.Status201Created)]
    public async Task<IActionResult> Create([FromBody] CreatePositionRequest request, CancellationToken ct)
    {
        var result = await mediator.Send(new CreatePositionCommand(request), ct);
        return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
    }

    [HttpPut("{id:guid}")]
    [RequirePermission("portfolios:write")]
    [ProducesResponseType(typeof(PositionDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdatePositionRequest request, CancellationToken ct)
    {
        var result = await mediator.Send(new UpdatePositionCommand(id, request), ct);
        return Ok(result);
    }

    [HttpDelete("{id:guid}")]
    [RequirePermission("portfolios:write")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
    {
        await mediator.Send(new DeletePositionCommand(id), ct);
        return NoContent();
    }
}
