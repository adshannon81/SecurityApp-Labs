using System.Security.Claims;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SecurityApp.API.Authorization;
using SecurityApp.Core.DeadLetters;
using SecurityApp.Core.DeadLetters.Entities;
using SecurityApp.Core.DeadLetters.Interfaces;
using Wolverine;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/dead-letters")]
[RequirePermission(AppPermissions.DeadLettersRead)]
[EnableRateLimiting("authenticated")]
public class DeadLetterController(
    IDeadLetterRepository repository,
    IMessageBus bus,
    ILogger<DeadLetterController> logger) : ControllerBase
{
    private static readonly int MaxPageSize = 200;

    [HttpGet]
    [ProducesResponseType(typeof(PagedDeadLetterResult), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(
        [FromQuery] string? status    = null,
        [FromQuery] string? eventType = null,
        [FromQuery] int pageNumber    = 1,
        [FromQuery] int pageSize      = 50,
        CancellationToken ct          = default)
    {
        pageNumber = Math.Max(1, pageNumber);
        pageSize   = Math.Clamp(pageSize, 1, MaxPageSize);

        var (items, totalCount) = await repository.GetPagedAsync(pageNumber, pageSize, status, eventType, ct);
        return Ok(new PagedDeadLetterResult(items, totalCount, pageNumber, pageSize));
    }

    [HttpGet("{id:guid}")]
    [ProducesResponseType(typeof(DeadLetterEvent), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id, CancellationToken ct = default)
    {
        var item = await repository.FindAsync(id, ct);
        return item is null ? NotFound() : Ok(item);
    }

    [HttpPost("{id:guid}/replay")]
    [RequirePermission(AppPermissions.DeadLettersManage)]
    [ProducesResponseType(StatusCodes.Status202Accepted)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Replay(Guid id, CancellationToken ct = default)
    {
        var item = await repository.FindAsync(id, ct);
        if (item is null) return NotFound();

        if (item.Status is DeadLetterStatus.Replayed or DeadLetterStatus.Discarded)
            return Conflict(new { error = $"Cannot replay a dead letter in status '{item.Status}'." });

        var actor = CurrentUser();

        try
        {
            // Deserialise and re-enqueue the original payload via Wolverine.
            // The concrete message type is resolved by event_type name; if not found, we
            // fall back to re-publishing as a raw envelope so at least it hits the DLQ again.
            var payloadObject = DeserialisePayload(item.EventType, item.Payload);
            if (payloadObject is null)
            {
                logger.LogWarning("DeadLetterController: cannot deserialise payload for event type {EventType} on {Id}", item.EventType, id);
                return UnprocessableEntity(new { error = $"Cannot deserialise payload for event type '{item.EventType}'." });
            }

            await bus.PublishAsync(payloadObject);
            await repository.MarkReplayedAsync(id, actor, ct);

            logger.LogInformation("DeadLetterController: replayed dead letter {Id} ({EventType}) by {Actor}", id, item.EventType, actor);
            return Accepted(new { message = "Dead letter re-enqueued.", id });
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "DeadLetterController: failed to replay dead letter {Id}", id);
            return StatusCode(StatusCodes.Status500InternalServerError, new { error = "Replay failed. See server logs." });
        }
    }

    [HttpPost("{id:guid}/discard")]
    [RequirePermission(AppPermissions.DeadLettersManage)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Discard(
        Guid id,
        [FromBody] ResolveDeadLetterRequest? body = null,
        CancellationToken ct = default)
    {
        var item = await repository.FindAsync(id, ct);
        if (item is null) return NotFound();

        var actor = CurrentUser();
        await repository.MarkDiscardedAsync(id, actor, body?.Notes, ct);

        logger.LogInformation("DeadLetterController: discarded dead letter {Id} by {Actor}", id, actor);
        return Ok(new { message = "Dead letter discarded.", id });
    }

    [HttpPost("{id:guid}/resolve")]
    [RequirePermission(AppPermissions.DeadLettersManage)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Resolve(
        Guid id,
        [FromBody] ResolveDeadLetterRequest? body = null,
        CancellationToken ct = default)
    {
        var item = await repository.FindAsync(id, ct);
        if (item is null) return NotFound();

        var actor = CurrentUser();
        await repository.MarkResolvedAsync(id, actor, body?.Notes, ct);

        logger.LogInformation("DeadLetterController: resolved dead letter {Id} by {Actor}", id, actor);
        return Ok(new { message = "Dead letter resolved.", id });
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private string CurrentUser()
        => User.FindFirstValue("sub")
        ?? User.FindFirstValue(ClaimTypes.NameIdentifier)
        ?? "system";

    /// <summary>
    /// Attempts to deserialise the JSON payload back to its original CLR type by looking
    /// up the <paramref name="eventType"/> name across all loaded assemblies.
    /// Returns null when no matching type is found.
    /// </summary>
    private static object? DeserialisePayload(string eventType, string payload)
    {
        var type = AppDomain.CurrentDomain.GetAssemblies()
            .SelectMany(a => a.GetTypes())
            .FirstOrDefault(t => t.Name == eventType || t.FullName == eventType);

        if (type is null) return null;

        return System.Text.Json.JsonSerializer.Deserialize(payload, type);
    }
}

public record PagedDeadLetterResult(
    IReadOnlyList<DeadLetterEvent> Items,
    int TotalCount,
    int PageNumber,
    int PageSize);

public record ResolveDeadLetterRequest(string? Notes);
