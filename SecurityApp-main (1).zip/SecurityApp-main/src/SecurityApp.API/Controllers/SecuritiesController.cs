using SecurityApp.API.Authorization;
using Microsoft.AspNetCore.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Mediator;
using SecurityApp.API.Middleware;
using SecurityApp.Application.Securities.DTOs;
using SecurityApp.Application.Securities.Commands;
using SecurityApp.Application.Securities.Queries;
using SecurityApp.Application.Shared;
using SecurityApp.Application.VendorSources.DTOs;
using SecurityApp.Application.VendorSources.Queries;
namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/[controller]")]
[RequirePermission("securities:read")]
[EnableRateLimiting("authenticated")]
public class SecuritiesController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly ILogger<SecuritiesController> _logger;

    public SecuritiesController(IMediator mediator, ILogger<SecuritiesController> logger)
    {
        _mediator = mediator;
        _logger = logger;
    }

    /// <summary>
    /// Get all securities
    /// </summary>
    [HttpGet]
    [ProducesResponseType(typeof(PagedResult<SecurityDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 50)
    {
        var query = new GetAllSecuritiesQuery(pageNumber, pageSize);
        var result = await _mediator.Send(query);
        return Ok(result);
    }

    /// <summary>
    /// Get security by ID
    /// </summary>
    [HttpGet("{id:guid}")]
    [ProducesResponseType(typeof(SecurityDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id)
    {
        var query = new GetSecurityByIdQuery(id);
        var result = await _mediator.Send(query);

        if (result == null)
            return NotFound(new { message = $"Security with ID {id} not found" });

        // Expose concurrency token as a quoted ETag for optimistic concurrency on PUT.
        // SQL Server: RowVersion bytes. PostgreSQL: xmin uint (4 bytes).
        if (result.RowVersion is { Length: > 0 })
            Response.Headers.ETag = $"\"{Convert.ToBase64String(result.RowVersion)}\"";
        else if (result.Xmin != 0)
            Response.Headers.ETag = $"\"{Convert.ToBase64String(BitConverter.GetBytes(result.Xmin))}\"";


        return Ok(result);
    }

    /// <summary>
    /// Create a new security
    /// </summary>
    [HttpPost]
    [RequirePermission("securities:write")]
    [ProducesResponseType(typeof(CreateSecurityResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create([FromBody] CreateSecurityDto dto)
    {
        var userId = User.FindFirst("sub")?.Value;
        var command = new CreateSecurityCommand(dto, userId);
        var result = await _mediator.Send(command);
        return CreatedAtAction(nameof(GetById), new { id = result.SecurityId }, result);
    }

    /// <summary>
    /// Update an existing security
    /// </summary>
    [HttpPut("{id:guid}")]
    [RequirePermission("securities:write")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status409Conflict)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Update(Guid id, [FromBody] CreateSecurityDto dto)
    {
        var userId = User.FindFirst("sub")?.Value;

        // Parse If-Match header (format: "<base64-encoded-rowversion>")
        byte[]? rowVersion = null;
        if (Request.Headers.TryGetValue("If-Match", out var ifMatch) && ifMatch.Count > 0)
        {
            var raw = ifMatch.ToString().Trim('"');
            if (!string.IsNullOrEmpty(raw))
            {
                try { rowVersion = Convert.FromBase64String(raw); }
                catch (FormatException) { /* malformed � treat as absent, no concurrency check */ }
            }
        }

        var command = new UpdateSecurityCommand(id, dto, userId, rowVersion);
        await _mediator.Send(command);
        return NoContent();
    }

    /// <summary>
    /// Get security reference data (statuses, asset classes, instrument types).
    /// </summary>
    [HttpGet("ref-data")]
    [ProducesResponseType(typeof(SecurityRefDataDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetRefData()
    {
        var result = await _mediator.Send(new GetSecurityRefDataQuery());
        return Ok(result);
    }

    /// <summary>
    /// Search securities by identifier value, name, type, and/or active status.
    /// </summary>
    [HttpGet("search")]
    [ProducesResponseType(typeof(PagedResult<SecurityDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Search(
        [FromQuery] string? identifierValue = null,
        [FromQuery] string? name = null,
        [FromQuery] string? type = null,
        [FromQuery] string? assetClassCode = null,
        [FromQuery] string? instrumentTypeCode = null,
        [FromQuery] string? statusCode = null,
        [FromQuery] bool? isActive = null,
        [FromQuery] int pageNumber = 1,
        [FromQuery] int pageSize = 50,
        [FromQuery] string? sortBy = null,
        [FromQuery] bool sortDescending = false)
    {
        var query = new SearchSecuritiesQuery(identifierValue, name, type, isActive, pageNumber, pageSize, sortBy, sortDescending)
        {
            AssetClassCode = assetClassCode,
            InstrumentTypeCode = instrumentTypeCode,
            StatusCode = statusCode,
        };
        var result = await _mediator.Send(query);
        return Ok(result);
    }

    /// <summary>
    /// Delete a security
    /// </summary>
    [HttpDelete("{id:guid}")]
    [RequirePermission("securities:delete")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(Guid id)
    {
        var command = new DeleteSecurityCommand(id);
        await _mediator.Send(command);
        return NoContent();
    }


    // -- M11: Vendor data snapshots ----------------------------------------------

    /// <summary>
    /// Returns paginated raw vendor field snapshots recorded for a security.
    /// Optionally filtered by field name, vendor source, or date range.
    /// </summary>
    [HttpGet("{id:guid}/vendor-data")]
    [RequirePermission("vendors:read")]
    [ProducesResponseType(typeof(PagedResult<SecurityVendorDataDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetVendorData(
        Guid      id,
        [FromQuery] string?   fieldName      = null,
        [FromQuery] Guid?     vendorSourceId = null,
        [FromQuery] DateTime? from           = null,
        [FromQuery] DateTime? to             = null,
        [FromQuery] int       pageNumber     = 1,
        [FromQuery] int       pageSize       = 50)
    {
        var result = await _mediator.Send(new GetSecurityVendorDataQuery(
            id, fieldName, vendorSourceId, from, to, pageNumber, pageSize));
        return Ok(result);
    }
}
