﻿using SecurityApp.API.Authorization;
using Microsoft.AspNetCore.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using SecurityApp.Core.Plugins.Interfaces;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/admin/[controller]")]
[RequirePermission("system:manage")]
public class PluginsController : ControllerBase
{
    private readonly IPluginLoader _pluginLoader;
    private readonly ILogger<PluginsController> _logger;

    public PluginsController(IPluginLoader pluginLoader, ILogger<PluginsController> logger)
    {
        _pluginLoader = pluginLoader;
        _logger = logger;
    }

    /// <summary>
    /// Get all loaded plugins
    /// </summary>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult GetLoadedPlugins()
    {
        var plugins = _pluginLoader.GetLoadedPlugins();
        return Ok(plugins);
    }

    /// <summary>
    /// Reload a specific plugin
    /// </summary>
    [HttpPost("reload/{pluginName}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> ReloadPlugin(string pluginName)
    {
        try
        {
            await _pluginLoader.ReloadPluginAsync(pluginName);
            return Ok(new { message = $"Plugin {pluginName} reloaded" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error reloading plugin");
            return BadRequest(new { error = ex.Message });
        }
    }

    /// <summary>
    /// Unload a specific plugin
    /// </summary>
    [HttpPost("unload/{pluginName}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult UnloadPlugin(string pluginName)
    {
        _pluginLoader.UnloadPlugin(pluginName);
        return Ok(new { message = $"Plugin {pluginName} unloaded" });
    }
}
