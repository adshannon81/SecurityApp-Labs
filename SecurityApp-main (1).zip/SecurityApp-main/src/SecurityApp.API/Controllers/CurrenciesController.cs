using Microsoft.AspNetCore.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using SecurityApp.Infrastructure.Persistence;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/[controller]")]
[Authorize]
[EnableRateLimiting("authenticated")]
public class CurrenciesController(ApplicationDbContext db) : ControllerBase
{
    /// <summary>
    /// Returns the list of currencies.
    /// </summary>
    /// <param name="activeOnly">When true (default) only active currencies are returned.</param>
    /// <param name="type">Optional filter: FIAT, CRYPTO, COMMODITY or OTHER. Omit for all types.</param>
    [HttpGet]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(
        [FromQuery] bool activeOnly = true,
        [FromQuery] string? type = null,
        CancellationToken ct = default)
    {
        var query = db.Currencies.AsNoTracking();

        if (activeOnly)
            query = query.Where(c => c.IsActive);

        if (!string.IsNullOrWhiteSpace(type))
        {
            var upper = type.Trim().ToUpperInvariant();
            query = query.Where(c => c.CurrencyType == Enum.Parse<SecurityApp.Core.Currencies.Enums.CurrencyType>(upper, true));
        }

        var result = await query
            .OrderBy(c => c.CurrencyType)
            .ThenBy(c => c.Name)
            .Select(c => new
            {
                c.Code,
                c.NumericCode,
                c.Name,
                c.Symbol,
                c.Decimals,
                c.DisplayDecimals,
                CurrencyType = c.CurrencyType.ToString(),
                c.IsActive,
            })
            .ToListAsync(ct);

        return Ok(result);
    }

    /// <summary>Returns a single currency by its alpha code.</summary>
    [HttpGet("{code}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetByCode(string code, CancellationToken ct)
    {
        var currency = await db.Currencies
            .AsNoTracking()
            .Where(c => c.Code == code.ToUpperInvariant())
            .Select(c => new
            {
                c.Code,
                c.NumericCode,
                c.Name,
                c.Symbol,
                c.Decimals,
                c.DisplayDecimals,
                CurrencyType = c.CurrencyType.ToString(),
                c.IsActive,
            })
            .FirstOrDefaultAsync(ct);

        return currency is null ? NotFound() : Ok(currency);
    }

    /// <summary>Returns all external codes for a given currency.</summary>
    [HttpGet("{code}/external-codes")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetExternalCodes(string code, CancellationToken ct)
    {
        var upperCode = code.ToUpperInvariant();

        var exists = await db.Currencies
            .AsNoTracking()
            .AnyAsync(c => c.Code == upperCode, ct);

        if (!exists)
            return NotFound();

        var result = await db.CurrencyExternalCodes
            .AsNoTracking()
            .Where(x => x.CurrencyCode == upperCode && !x.IsDeleted)
            .OrderBy(x => x.SystemName)
            .Select(x => new
            {
                x.Id,
                x.CurrencyCode,
                x.SystemName,
                x.ExternalCode,
            })
            .ToListAsync(ct);

        return Ok(result);
    }
}
