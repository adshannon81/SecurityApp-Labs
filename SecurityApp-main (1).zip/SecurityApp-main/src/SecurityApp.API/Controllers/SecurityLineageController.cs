using Mediator;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SecurityApp.API.Authorization;
using SecurityApp.Application.GoldenSource.DTOs;
using SecurityApp.Application.GoldenSource.Queries;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/securities/{securityId:guid}/lineage")]
[RequirePermission("securities:read")]
[EnableRateLimiting("authenticated")]
public class SecurityLineageController(IMediator mediator) : ControllerBase
{
    /// <summary>
    /// Returns the full field-level provenance (golden source lineage) for a security.
    /// Includes a summary of the current winning vendor per field and the full resolution history.
    /// </summary>
    [HttpGet]
    [ProducesResponseType(typeof(SecurityLineageDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetLineage(Guid securityId, CancellationToken cancellationToken)
    {
        var result = await mediator.Send(new GetSecurityLineageQuery(securityId), cancellationToken);
        return Ok(result);
    }
}
