﻿using SecurityApp.API.Authorization;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using SecurityApp.Core.Jobs.Interfaces;
using SecurityApp.Core.Jobs.Models;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/[controller]")]
[RequirePermission("jobs:read")]
[EnableRateLimiting("authenticated")]
public class JobsController(IJobService jobService) : ControllerBase
{
    // -- Legacy endpoints (kept for backward compatibility) --------------------

    /// <summary>Returns recent job execution history (latest 50 by default).</summary>
    [HttpGet("history")]
    [ProducesResponseType(typeof(IEnumerable<JobHistoryDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetHistory(
        [FromQuery] int take = 50, CancellationToken ct = default)
    {
        var history = await jobService.GetJobHistoryAsync(take, ct);
        return Ok(history);
    }

    /// <summary>Manually triggers the legacy nightly security update job.</summary>
    [HttpPost("nightly-update")]
    [RequirePermission("jobs:manage")]
    [ProducesResponseType(StatusCodes.Status202Accepted)]
    public async Task<IActionResult> TriggerNightlyUpdate(CancellationToken ct = default)
    {
        await jobService.TriggerNightlyUpdateAsync(ct);
        return Accepted(new { message = "Nightly update job enqueued." });
    }

    // -- Dynamic job management ------------------------------------------------

    /// <summary>Lists all registered jobs with their current schedule and state.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<JobStatusDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAllJobs(CancellationToken ct = default)
    {
        var jobs = await jobService.GetAllJobsAsync(ct);
        return Ok(jobs);
    }

    /// <summary>Manually triggers a job plugin by plugin name.</summary>
    [HttpPost("{pluginName}/trigger")]
    [RequirePermission("jobs:manage")]
    [ProducesResponseType(StatusCodes.Status202Accepted)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> TriggerJob(string pluginName, CancellationToken ct = default)
    {
        try
        {
            var triggeredBy = "manual:" + (User.FindFirstValue(ClaimTypes.Name)
                              ?? User.FindFirstValue(ClaimTypes.NameIdentifier)
                              ?? "unknown");
            await jobService.TriggerJobAsync(pluginName, triggeredBy, ct);
            return Accepted(new { message = $"Job '{pluginName}' triggered." });
        }
        catch (InvalidOperationException ex)
        {
            return NotFound(new { error = ex.Message });
        }
    }

    /// <summary>Pauses the cron trigger for the specified job.</summary>
    [HttpPost("{pluginName}/pause")]
    [RequirePermission("jobs:manage")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> PauseJob(string pluginName, CancellationToken ct = default)
    {
        try
        {
            await jobService.PauseJobAsync(pluginName, ct);
            return NoContent();
        }
        catch (InvalidOperationException ex)
        {
            return NotFound(new { error = ex.Message });
        }
    }

    /// <summary>Resumes the cron trigger for the specified job.</summary>
    [HttpPost("{pluginName}/resume")]
    [RequirePermission("jobs:manage")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> ResumeJob(string pluginName, CancellationToken ct = default)
    {
        try
        {
            await jobService.ResumeJobAsync(pluginName, ct);
            return NoContent();
        }
        catch (InvalidOperationException ex)
        {
            return NotFound(new { error = ex.Message });
        }
    }

    /// <summary>Creates or updates the cron schedule for a job. Changes survive restarts.</summary>
    [HttpPut("{pluginName}/schedule")]
    [RequirePermission("jobs:manage")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> UpsertSchedule(
        string pluginName,
        [FromBody] UpsertScheduleRequest request,
        CancellationToken ct = default)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);

        var userName = User.FindFirstValue(ClaimTypes.Name)
                       ?? User.FindFirstValue(ClaimTypes.NameIdentifier)
                       ?? "unknown";
        var userId   = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? string.Empty;

        var config = new JobScheduleConfig
        {
            PluginName     = pluginName,
            Group          = request.Group ?? string.Empty,
            CronExpression = request.CronExpression,
            Enabled        = request.Enabled,
            TimeZone       = request.TimeZone ?? "UTC"
        };

        await jobService.UpsertScheduleAsync(config, userId, ct);
        return NoContent();
    }

    /// <summary>Removes a job and its schedule from Quartz. Does not delete the plugin DLL.</summary>
    [HttpDelete("{pluginName}")]
    [RequirePermission("jobs:manage")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> DeleteJob(string pluginName, CancellationToken ct = default)
    {
        await jobService.DeleteJobAsync(pluginName, ct);
        return NoContent();
    }
}

/// <summary>Request body for <c>PUT /api/jobs/{pluginName}/schedule</c>.</summary>
public sealed class UpsertScheduleRequest
{
    public string CronExpression { get; set; } = string.Empty;
    public bool Enabled { get; set; } = true;
    public string? TimeZone { get; set; }
    public string? Group { get; set; }
}

