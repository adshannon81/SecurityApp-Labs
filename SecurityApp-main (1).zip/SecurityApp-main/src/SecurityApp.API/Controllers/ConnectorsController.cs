using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using SecurityApp.Core.Shared.Interfaces;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersionNeutral]
[Route("api/[controller]")]
public class ConnectorsController : ControllerBase
{
    /// <summary>
    /// Lists all enabled connectors with live health status and capability flags.
    /// </summary>
    [HttpGet("health")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetConnectors(
        [FromServices] IDataProviderService dataProviderService,
        CancellationToken cancellationToken)
    {
        var connectors = await dataProviderService.GetAllConnectorHealthAsync(cancellationToken);

        return Ok(new
        {
            connectors,
            healthyCount   = connectors.Count(c => c.IsHealthy),
            unhealthyCount = connectors.Count(c => !c.IsHealthy),
            timestamp      = DateTime.UtcNow
        });
    }

    /// <summary>
    /// Returns live health status for a single connector by name (e.g. "AlphaVantage", "FlatFile").
    /// </summary>
    [HttpGet("health/{name}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetConnectorHealth(
        string name,
        [FromServices] IDataProviderService dataProviderService,
        CancellationToken cancellationToken)
    {
        var connectors = await dataProviderService.GetAllConnectorHealthAsync(cancellationToken);
        var connector  = connectors.FirstOrDefault(c =>
            string.Equals(c.Name, name, StringComparison.OrdinalIgnoreCase));

        if (connector is null)
            return NotFound(new { error = $"No connector named '{name}' is currently enabled." });

        return Ok(connector);
    }
}
