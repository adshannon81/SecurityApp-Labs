using SecurityApp.API.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Mediator;
using SecurityApp.Application.Issuers.DTOs;
using SecurityApp.Application.Issuers.Commands;
using SecurityApp.Application.Issuers.Queries;
using SecurityApp.Application.Shared;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/[controller]")]
[RequirePermission("issuers:read")]
[EnableRateLimiting("authenticated")]
public class IssuersController : ControllerBase
{
    private readonly IMediator _mediator;

    public IssuersController(IMediator mediator) => _mediator = mediator;

    /// <summary>Search or list issuers (typeahead-friendly).</summary>
    [HttpGet]
    [ProducesResponseType(typeof(PagedResult<IssuerSummaryDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> Search(
        [FromQuery] string? search = null,
        [FromQuery] string? issuerType = null,
        [FromQuery] string? countryAlpha2 = null,
        [FromQuery] bool? isActive = null,
        [FromQuery] int pageNumber = 1,
        [FromQuery] int pageSize = 50)
    {
        var result = await _mediator.Send(
            new SearchIssuersQuery(search, issuerType, countryAlpha2, isActive, pageNumber, pageSize));
        return Ok(result);
    }

    /// <summary>Get a single issuer by ID.</summary>
    [HttpGet("{id:guid}")]
    [ProducesResponseType(typeof(IssuerDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id)
    {
        var result = await _mediator.Send(new GetIssuerByIdQuery(id));
        if (result is null) return NotFound(new { message = $"Issuer {id} not found" });
        return Ok(result);
    }

    /// <summary>Create a new issuer.</summary>
    [HttpPost]
    [RequirePermission("issuers:write")]
    [ProducesResponseType(typeof(CreateIssuerResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create([FromBody] CreateIssuerDto dto)
    {
        var userId = User.FindFirst("sub")?.Value;
        var result = await _mediator.Send(new CreateIssuerCommand(dto, userId));
        return CreatedAtAction(nameof(GetById), new { id = result.IssuerId }, result);
    }

    /// <summary>Update an existing issuer.</summary>
    [HttpPut("{id:guid}")]
    [RequirePermission("issuers:write")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Update(Guid id, [FromBody] CreateIssuerDto dto)
    {
        var userId = User.FindFirst("sub")?.Value;
        await _mediator.Send(new UpdateIssuerCommand(id, dto, userId));
        return NoContent();
    }

    /// <summary>Soft-delete an issuer.</summary>
    [HttpDelete("{id:guid}")]
    [RequirePermission("issuers:write")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(Guid id)
    {
        await _mediator.Send(new DeleteIssuerCommand(id));
        return NoContent();
    }

    // ── Relationship endpoints ────────────────────────────────────────────────

    /// <summary>Get all current relationships where the issuer is the child (parent relationships).</summary>
    [HttpGet("{id:guid}/relationships")]
    [ProducesResponseType(typeof(List<IssuerRelationshipDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetRelationships(Guid id)
    {
        var result = await _mediator.Send(new GetIssuerRelationshipsQuery(id));
        return Ok(result);
    }

    /// <summary>Get all current relationships where the issuer is the parent (child issuers).</summary>
    [HttpGet("{id:guid}/children")]
    [ProducesResponseType(typeof(List<IssuerRelationshipDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetChildren(Guid id)
    {
        var result = await _mediator.Send(new GetIssuerChildrenQuery(id));
        return Ok(result);
    }

    /// <summary>Add a new relationship to an issuer.</summary>
    [HttpPost("{id:guid}/relationships")]
    [RequirePermission("issuers:write")]
    [ProducesResponseType(typeof(AddIssuerRelationshipResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> AddRelationship(Guid id, [FromBody] CreateIssuerRelationshipDto dto)
    {
        var userId = User.FindFirst("sub")?.Value;
        try
        {
            var result = await _mediator.Send(new AddIssuerRelationshipCommand(id, dto, userId));
            return CreatedAtAction(nameof(GetRelationships), new { id }, result);
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    /// <summary>Update an existing issuer relationship.</summary>
    [HttpPut("{id:guid}/relationships/{relationshipId:guid}")]
    [RequirePermission("issuers:write")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateRelationship(
        Guid id, Guid relationshipId, [FromBody] CreateIssuerRelationshipDto dto)
    {
        var userId = User.FindFirst("sub")?.Value;
        try
        {
            await _mediator.Send(new UpdateIssuerRelationshipCommand(relationshipId, dto, userId));
            return NoContent();
        }
        catch (InvalidOperationException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    /// <summary>Soft-delete an issuer relationship.</summary>
    [HttpDelete("{id:guid}/relationships/{relationshipId:guid}")]
    [RequirePermission("issuers:write")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> DeleteRelationship(Guid id, Guid relationshipId)
    {
        await _mediator.Send(new DeleteIssuerRelationshipCommand(relationshipId));
        return NoContent();
    }
}
