using SecurityApp.API.Authorization;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Mediator;
using SecurityApp.Application.VendorSources.DTOs;
using SecurityApp.Application.VendorSources.Commands;
using SecurityApp.Application.VendorSources.Queries;

namespace SecurityApp.API.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/[controller]")]
[RequirePermission("vendors:read")]
[EnableRateLimiting("authenticated")]
public class VendorSourcesController : ControllerBase
{
    private readonly IMediator _mediator;

    public VendorSourcesController(IMediator mediator) => _mediator = mediator;

    // ── Vendor Sources ─────────────────────────────────────────────────────────

    /// <summary>List all vendor sources, ordered by global priority.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(List<VendorSourceDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll([FromQuery] bool includeInactive = false)
    {
        var result = await _mediator.Send(new GetAllVendorSourcesQuery(includeInactive));
        return Ok(result);
    }

    /// <summary>Get a single vendor source by ID.</summary>
    [HttpGet("{id:guid}")]
    [ProducesResponseType(typeof(VendorSourceDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(Guid id)
    {
        var result = await _mediator.Send(new GetVendorSourceByIdQuery(id));
        if (result is null) return NotFound(new { message = $"VendorSource {id} not found" });
        return Ok(result);
    }

    /// <summary>Create a new vendor source.</summary>
    [HttpPost]
    [RequirePermission("vendors:write")]
    [ProducesResponseType(typeof(CreateVendorSourceResponse), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Create([FromBody] CreateVendorSourceDto dto)
    {
        var userId = User.FindFirst("sub")?.Value;
        var result = await _mediator.Send(new CreateVendorSourceCommand(dto, userId));
        return CreatedAtAction(nameof(GetById), new { id = result.VendorSourceId }, result);
    }

    /// <summary>Update an existing vendor source.</summary>
    [HttpPut("{id:guid}")]
    [RequirePermission("vendors:write")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Update(Guid id, [FromBody] CreateVendorSourceDto dto)
    {
        var userId = User.FindFirst("sub")?.Value;
        await _mediator.Send(new UpdateVendorSourceCommand(id, dto, userId));
        return NoContent();
    }

    /// <summary>Soft-delete a vendor source.</summary>
    [HttpDelete("{id:guid}")]
    [RequirePermission("vendors:write")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(Guid id)
    {
        await _mediator.Send(new DeleteVendorSourceCommand(id));
        return NoContent();
    }

    // ── Field Priorities ───────────────────────────────────────────────────────

    /// <summary>List all field-priority overrides for a vendor source.</summary>
    [HttpGet("{id:guid}/priorities")]
    [ProducesResponseType(typeof(List<VendorFieldPriorityDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetPriorities(Guid id)
    {
        var result = await _mediator.Send(new GetFieldPrioritiesQuery(id));
        return Ok(result);
    }

    /// <summary>
    /// Create or update a field-priority override for a vendor source.
    /// If a row already exists for the (vendorSourceId, fieldName, assetClassCode) key, it is updated.
    /// </summary>
    [HttpPost("{id:guid}/priorities")]
    [RequirePermission("vendors:write")]
    [ProducesResponseType(typeof(UpsertFieldPriorityResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpsertPriority(Guid id, [FromBody] CreateVendorFieldPriorityDto dto)
    {
        var userId = User.FindFirst("sub")?.Value;
        var result = await _mediator.Send(new UpsertFieldPriorityCommand(id, dto, userId));
        return Ok(result);
    }

    /// <summary>Update a field-priority override by its own ID.</summary>
    [HttpPut("{id:guid}/priorities/{priorityId:guid}")]
    [RequirePermission("vendors:write")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdatePriority(Guid id, Guid priorityId, [FromBody] CreateVendorFieldPriorityDto dto)
    {
        var userId = User.FindFirst("sub")?.Value;
        await _mediator.Send(new UpdateFieldPriorityCommand(priorityId, dto, userId));
        return NoContent();
    }

    /// <summary>Soft-delete a field-priority override.</summary>
    [HttpDelete("{id:guid}/priorities/{priorityId:guid}")]
    [RequirePermission("vendors:write")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> DeletePriority(Guid id, Guid priorityId)
    {
        await _mediator.Send(new DeleteFieldPriorityCommand(priorityId));
        return NoContent();
    }
}
