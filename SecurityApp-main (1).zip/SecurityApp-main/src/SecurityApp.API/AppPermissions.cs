namespace SecurityApp.API;

/// <summary>
/// Permission strings emitted in the JWT "permissions" claim by Keycloak's client-role mapper.
/// Each constant matches the name of a client role on the "securityapp-api" Keycloak client.
///
/// Role → permission assignment is configured in Keycloak (composite realm roles).
/// Adding a new role requires no code changes — only Keycloak configuration.
/// </summary>
public static class AppPermissions
{
    // ── Securities ──────────────────────────────────────────────────────────
    public const string SecuritiesRead   = "securities:read";
    public const string SecuritiesWrite  = "securities:write";
    public const string SecuritiesDelete = "securities:delete";

    // ── Ratings ─────────────────────────────────────────────────────────────
    public const string RatingsRead   = "ratings:read";
    public const string RatingsWrite  = "ratings:write";
    public const string RatingsManage = "ratings:manage";

    // ── Pricing ─────────────────────────────────────────────────────────────
    public const string PricingRead   = "pricing:read";
    public const string PricingWrite  = "pricing:write";
    public const string PricingManage = "pricing:manage";

    // ── Imports ─────────────────────────────────────────────────────────────
    public const string ImportsRead   = "imports:read";
    public const string ImportsRun    = "imports:run";
    public const string ImportsManage = "imports:manage";

    // ── Exports ─────────────────────────────────────────────────────────────
    public const string ExportsRun = "exports:run";

    // ── Workflows ────────────────────────────────────────────────────────────
    public const string WorkflowsRead   = "workflows:read";
    public const string WorkflowsUse    = "workflows:use";
    public const string WorkflowsManage = "workflows:manage";

    // ── Jobs ─────────────────────────────────────────────────────────────────
    public const string JobsRead   = "jobs:read";
    public const string JobsManage = "jobs:manage";

    // ── Audit & System ───────────────────────────────────────────────────────
    public const string AuditRead    = "audit:read";
    public const string SystemManage = "system:manage";

    // ── Dead Letters ─────────────────────────────────────────────────────────
    public const string DeadLettersRead   = "dead-letters:read";
    public const string DeadLettersManage = "dead-letters:manage";

    // ── UI Authorization ─────────────────────────────────────────────────────
    public const string AdminFieldVisibility    = "admin:field-visibility";
    public const string AdminUiResources        = "admin:ui-resources";
    public const string AdminManageAuthorization = "admin:manage-authorization";
    public const string AdminManagePermissions  = "admin:manage-permissions";
    public const string AdminSuper              = "admin:super";

    // ── Vendors ──────────────────────────────────────────────────────────────
    public const string VendorsRead  = "vendors:read";
    public const string VendorsWrite = "vendors:write";

    // ── Portfolios ───────────────────────────────────────────────────────────
    public const string PortfoliosRead  = "portfolios:read";
    public const string PortfoliosWrite = "portfolios:write";

    // ── Issuers ──────────────────────────────────────────────────────────────
    public const string IssuersRead  = "issuers:read";
    public const string IssuersWrite = "issuers:write";
}

