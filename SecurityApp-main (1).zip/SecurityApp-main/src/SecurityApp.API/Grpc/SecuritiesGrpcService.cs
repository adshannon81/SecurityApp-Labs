using System.Text.Json;
using System.Threading.Channels;
using Grpc.Core;
using Mediator;
using StackExchange.Redis;
using SecurityApp.API.Grpc.Mapping;
using SecurityApp.API.Grpc.Proto;
using SecurityApp.Application.Securities.Queries;
using SecurityApp.Core.Grpc;

namespace SecurityApp.API.Grpc;

public class SecuritiesGrpcService(
    IMediator mediator,
    ILogger<SecuritiesGrpcService> _logger,
    IConnectionMultiplexer? multiplexer = null) : Proto.SecuritiesGrpcService.SecuritiesGrpcServiceBase
{
    private static readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web);
    // ── Unary ─────────────────────────────────────────────────────────────────

    public override async Task<SearchSecuritiesResponse> SearchSecurities(
        SearchSecuritiesRequest request,
        ServerCallContext context)
    {
        var pageNumber = request.PageNumber < 1 ? 1 : request.PageNumber;
        var pageSize   = request.PageSize   < 1 ? 50 : Math.Min(request.PageSize, 200);

        var query = new SearchSecuritiesQuery(
            string.IsNullOrWhiteSpace(request.IdentifierValue)     ? null : request.IdentifierValue,
            string.IsNullOrWhiteSpace(request.Name)                ? null : request.Name,
            string.IsNullOrWhiteSpace(request.Type)                ? null : request.Type,
            null,  // IsActive — not exposed; use StatusCode instead
            pageNumber,
            pageSize,
            StatusCode:          string.IsNullOrWhiteSpace(request.StatusCode)          ? null : request.StatusCode,
            AssetClassCode:      string.IsNullOrWhiteSpace(request.AssetClassCode)      ? null : request.AssetClassCode,
            InstrumentTypeCode:  string.IsNullOrWhiteSpace(request.InstrumentTypeCode)  ? null : request.InstrumentTypeCode);

        var paged = await mediator.Send(query, context.CancellationToken);

        var response = new SearchSecuritiesResponse
        {
            TotalCount = paged.TotalCount,
            PageNumber = paged.PageNumber,
            PageSize   = paged.PageSize
        };

        foreach (var item in paged.Items)
            response.Items.Add(item.ToProto());

        return response;
    }

    // ── Server-side streaming ─────────────────────────────────────────────────

    public override async Task StreamSecurityChanges(
        StreamSecurityChangesRequest request,
        IServerStreamWriter<SecurityChangeEvent> responseStream,
        ServerCallContext context)
    {
        if (multiplexer is null)
        {
            _logger.LogWarning("Securities gRPC stream requested but Redis is not configured");
            throw new RpcException(new Status(StatusCode.Unavailable,
                "gRPC streaming requires Redis. Configure ConnectionStrings:Redis."));
        }

        var pipe       = Channel.CreateUnbounded<SecurityChangeEvent>();
        var subscriber = multiplexer.GetSubscriber();
        var redisKey   = RedisChannel.Literal(GrpcStreamChannels.SecurityChanges);
        var typeFilter = string.IsNullOrWhiteSpace(request.Type) ? null : request.Type;

        await subscriber.SubscribeAsync(redisKey, (_, msg) =>
        {
            if (msg.IsNullOrEmpty) return;
            var payload = JsonSerializer.Deserialize<SecurityChangedPayload>((string)msg!, _json);
            if (payload is null) return;
            if (typeFilter is not null &&
                !string.Equals(payload.SecurityType, typeFilter, StringComparison.OrdinalIgnoreCase))
                return;
            pipe.Writer.TryWrite(payload.ToChangeEvent());
        });

        try
        {
            await foreach (var evt in pipe.Reader.ReadAllAsync(context.CancellationToken))
                await responseStream.WriteAsync(evt, context.CancellationToken);
        }
        catch (OperationCanceledException)
        {
            _logger.LogDebug("Securities change stream ended (client disconnected)");
        }
        finally
        {
            await subscriber.UnsubscribeAsync(redisKey);
            pipe.Writer.TryComplete();
        }
    }
}
