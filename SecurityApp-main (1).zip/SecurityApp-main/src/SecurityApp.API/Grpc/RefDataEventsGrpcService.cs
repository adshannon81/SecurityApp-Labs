using System.Text.Json;
using System.Threading.Channels;
using Grpc.Core;
using StackExchange.Redis;
using SecurityApp.API.Grpc.Proto;
using SecurityApp.Core.Grpc;

namespace SecurityApp.API.Grpc;

public class RefDataEventsGrpcService(
    ILogger<RefDataEventsGrpcService> _logger,
    IConnectionMultiplexer? multiplexer = null) : Proto.RefDataEventsGrpcService.RefDataEventsGrpcServiceBase
{
    private static readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web);

    public override async Task StreamRefDataChanged(
        StreamRefDataChangedRequest request,
        IServerStreamWriter<RefDataChangedEvent> responseStream,
        ServerCallContext context)
    {
        if (multiplexer is null)
        {
            _logger.LogWarning("RefData gRPC stream requested but Redis is not configured");
            throw new RpcException(new Status(StatusCode.Unavailable,
                "gRPC streaming requires Redis. Configure ConnectionStrings:Redis."));
        }

        var pipe       = Channel.CreateUnbounded<RefDataChangedEvent>();
        var subscriber = multiplexer.GetSubscriber();
        var redisKey   = RedisChannel.Literal(GrpcStreamChannels.RefDataChanged);

        await subscriber.SubscribeAsync(redisKey, (_, msg) =>
        {
            if (msg.IsNullOrEmpty) return;
            var payload = JsonSerializer.Deserialize<RefDataChangedPayload>((string)msg!, _json);
            if (payload is null) return;

            pipe.Writer.TryWrite(new RefDataChangedEvent
            {
                EntityType = payload.EntityType ?? string.Empty,
                ChangedBy  = payload.ChangedBy  ?? string.Empty,
            });
        });

        try
        {
            await foreach (var ev in pipe.Reader.ReadAllAsync(context.CancellationToken))
                await responseStream.WriteAsync(ev, context.CancellationToken);
        }
        catch (OperationCanceledException)
        {
            _logger.LogDebug("RefData stream ended (client disconnected)");
        }
        finally
        {
            await subscriber.UnsubscribeAsync(redisKey);
            pipe.Writer.TryComplete();
        }
    }
}
