using Google.Protobuf;
using Grpc.Core;
using Grpc.Core.Interceptors;
using Microsoft.EntityFrameworkCore;
using SecurityApp.Core.Idempotency;
using SecurityApp.Core.Idempotency.Entities;
using SecurityApp.Core.Idempotency.Interfaces;

namespace SecurityApp.API.Grpc.Interceptors;

/// <summary>
/// gRPC server interceptor that applies idempotency semantics to unary calls.
///
/// Clients include an <c>idempotency-key</c> metadata entry (≤ 200 chars).
/// If the metadata entry is absent the call passes through unchanged.
///
/// Key lifecycle mirrors the REST middleware:
///   PROCESSING — returns <see cref="StatusCode.AlreadyExists"/> (IDEMPOTENCY_CONFLICT).
///   COMPLETED  — deserialises and replays the stored proto-JSON response.
///   FAILED     — resets the key to PROCESSING and re-executes the call.
///
/// Only unary calls are intercepted. Streaming calls pass through.
/// </summary>
public sealed class IdempotencyServerInterceptor(
    IIdempotencyKeyRepository               repository,
    ILogger<IdempotencyServerInterceptor>   logger) : Interceptor
{
    private const string MetadataKey = "idempotency-key";

    public override async Task<TResponse> UnaryServerHandler<TRequest, TResponse>(
        TRequest                            request,
        ServerCallContext                   context,
        UnaryServerMethod<TRequest, TResponse> continuation)
    {
        var key = context.RequestHeaders.GetValue(MetadataKey);
        if (string.IsNullOrWhiteSpace(key))
            return await continuation(request, context);

        if (key.Length > 200)
            throw new RpcException(new Status(StatusCode.InvalidArgument,
                "idempotency-key must not exceed 200 characters."));

        var operationType = context.Method;
        var ct            = context.CancellationToken;

        var existing = await repository.FindAsync(key, ct);

        if (existing is not null)
        {
            switch (existing.Status)
            {
                case IdempotencyStatus.Processing:
                    logger.LogWarning(
                        "gRPC idempotency conflict: key {Key} is already being processed", key);
                    throw new RpcException(new Status(StatusCode.AlreadyExists,
                        "IDEMPOTENCY_CONFLICT: a request with this idempotency key is already being processed."));

                case IdempotencyStatus.Completed when !string.IsNullOrEmpty(existing.ResponseBody):
                    logger.LogDebug("Replaying gRPC idempotent response for key {Key}", key);
                    return DeserialiseResponse<TResponse>(existing.ResponseBody);

                case IdempotencyStatus.Failed:
                    logger.LogDebug("Resetting FAILED gRPC idempotency key {Key} to allow retry", key);
                    await repository.ResetToProcessingAsync(key, DateTime.UtcNow.AddHours(24), ct);
                    break;
            }
        }
        else
        {
            var entry = new IdempotencyKey
            {
                Key           = key,
                OperationType = operationType,
                Status        = IdempotencyStatus.Processing,
                CreatedAt     = DateTime.UtcNow,
                ExpiresAt     = DateTime.UtcNow.AddHours(24)
            };

            try
            {
                await repository.CreateAsync(entry, ct);
            }
            catch (DbUpdateException)
            {
                logger.LogWarning(
                    "gRPC idempotency race condition: key {Key} was inserted concurrently", key);
                throw new RpcException(new Status(StatusCode.AlreadyExists,
                    "IDEMPOTENCY_CONFLICT: a request with this idempotency key is already being processed."));
            }
        }

        try
        {
            var response = await continuation(request, context);
            var json     = JsonFormatter.Default.Format((IMessage)(object)response);
            await repository.MarkCompletedAsync(key, 200, json, ct);
            return response;
        }
        catch (RpcException)
        {
            try { await repository.MarkFailedAsync(key, ct); } catch { /* best-effort */ }
            throw;
        }
        catch
        {
            try { await repository.MarkFailedAsync(key, ct); } catch { /* best-effort */ }
            throw;
        }
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    private static TResponse DeserialiseResponse<TResponse>(string json) where TResponse : class
    {
        var prototype = (IMessage)Activator.CreateInstance<TResponse>()!;
        return (TResponse)(object)prototype.Descriptor.Parser.ParseJson(json);
    }
}
