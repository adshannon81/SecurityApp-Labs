using System.Text.Json;
using System.Threading.Channels;
using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using StackExchange.Redis;
using SecurityApp.API.Grpc.Proto;
using SecurityApp.Core.Grpc;

namespace SecurityApp.API.Grpc;

public class DashboardGrpcService(
    ILogger<DashboardGrpcService> _logger,
    IConnectionMultiplexer? multiplexer = null) : Proto.DashboardGrpcService.DashboardGrpcServiceBase
{
    private static readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web);
    // ── Server-side streaming ─────────────────────────────────────────────────

    public override async Task StreamDashboardMetrics(
        StreamDashboardMetricsRequest request,
        IServerStreamWriter<DashboardMetrics> responseStream,
        ServerCallContext context)
    {
        if (multiplexer is null)
        {
            _logger.LogWarning("Dashboard gRPC stream requested but Redis is not configured");
            throw new RpcException(new Status(StatusCode.Unavailable,
                "gRPC streaming requires Redis. Configure ConnectionStrings:Redis."));
        }

        var pipe       = Channel.CreateUnbounded<DashboardMetrics>();
        var subscriber = multiplexer.GetSubscriber();
        var redisKey   = RedisChannel.Literal(GrpcStreamChannels.DashboardMetrics);

        await subscriber.SubscribeAsync(redisKey, (_, msg) =>
        {
            if (msg.IsNullOrEmpty) return;
            var payload = JsonSerializer.Deserialize<DashboardMetricsPayload>((string)msg!, _json);
            if (payload is null) return;

            var metrics = new DashboardMetrics
            {
                TotalSecurities  = payload.TotalSecurities,
                ActiveSecurities = payload.ActiveSecurities,
                PendingApprovals = payload.PendingApprovals,
                AsOf             = Timestamp.FromDateTime(payload.AsOf.Kind == DateTimeKind.Utc
                    ? payload.AsOf : payload.AsOf.ToUniversalTime())
            };
            foreach (var c in payload.Connectors)
                metrics.ConnectorHealth.Add(new ConnectorHealth
                {
                    Name    = c.Name,
                    Status  = c.IsHealthy ? "Healthy" : "Unhealthy",
                    Message = c.Message
                });

            pipe.Writer.TryWrite(metrics);
        });

        try
        {
            await foreach (var m in pipe.Reader.ReadAllAsync(context.CancellationToken))
                await responseStream.WriteAsync(m, context.CancellationToken);
        }
        catch (OperationCanceledException)
        {
            _logger.LogDebug("Dashboard metrics stream ended (client disconnected)");
        }
        finally
        {
            await subscriber.UnsubscribeAsync(redisKey);
            pipe.Writer.TryComplete();
        }
    }
}
