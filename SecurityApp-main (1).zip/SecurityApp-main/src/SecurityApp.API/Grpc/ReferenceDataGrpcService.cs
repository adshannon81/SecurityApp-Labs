using Grpc.Core;
using Microsoft.EntityFrameworkCore;
using SecurityApp.API.Grpc.Mapping;
using SecurityApp.API.Grpc.Proto;
using SecurityApp.Infrastructure.Persistence;

namespace SecurityApp.API.Grpc;

public class ReferenceDataGrpcService(
    ApplicationDbContext db) : Proto.ReferenceDataGrpcService.ReferenceDataGrpcServiceBase
{
    // ── Currencies ────────────────────────────────────────────────────────────

    public override async Task<ListCurrenciesResponse> ListCurrencies(
        ListCurrenciesRequest request,
        ServerCallContext context)
    {
        var query = db.Currencies.AsNoTracking();

        if (request.ActiveOnly)
            query = query.Where(c => c.IsActive);

        if (!string.IsNullOrWhiteSpace(request.TypeFilter))
        {
            var typeFilter = Enum.Parse<SecurityApp.Core.Currencies.Enums.CurrencyType>(request.TypeFilter, ignoreCase: true);
            query = query.Where(c => c.CurrencyType == typeFilter);
        }

        var items = await query
            .OrderBy(c => c.CurrencyType)
            .ThenBy(c => c.Name)
            .ToListAsync(context.CancellationToken);

        var response = new ListCurrenciesResponse();
        response.Items.AddRange(items.Select(c => c.ToProto()));
        return response;
    }

    public override async Task<CurrencyMessage> GetCurrency(
        GetCurrencyRequest request,
        ServerCallContext context)
    {
        if (string.IsNullOrWhiteSpace(request.Code))
            throw new RpcException(new Status(StatusCode.InvalidArgument, "Currency code is required."));

        var currency = await db.Currencies
            .AsNoTracking()
            .FirstOrDefaultAsync(c => c.Code == request.Code.ToUpperInvariant(),
                context.CancellationToken);

        if (currency is null)
            throw new RpcException(new Status(StatusCode.NotFound,
                $"Currency '{request.Code}' not found."));

        return currency.ToProto();
    }

    public override async Task<ListCurrencyExternalCodesResponse> ListCurrencyExternalCodes(
        ListCurrencyExternalCodesRequest request,
        ServerCallContext context)
    {
        if (string.IsNullOrWhiteSpace(request.CurrencyCode))
            throw new RpcException(new Status(StatusCode.InvalidArgument, "Currency code is required."));

        var upperCode = request.CurrencyCode.ToUpperInvariant();

        var exists = await db.Currencies.AnyAsync(c => c.Code == upperCode, context.CancellationToken);
        if (!exists)
            throw new RpcException(new Status(StatusCode.NotFound,
                $"Currency '{request.CurrencyCode}' not found."));

        var items = await db.CurrencyExternalCodes
            .AsNoTracking()
            .Where(x => x.CurrencyCode == upperCode && !x.IsDeleted)
            .OrderBy(x => x.SystemName)
            .ToListAsync(context.CancellationToken);

        var response = new ListCurrencyExternalCodesResponse();
        response.Items.AddRange(items.Select(x => x.ToProto()));
        return response;
    }

    // ── Countries ─────────────────────────────────────────────────────────────

    public override async Task<ListCountriesResponse> ListCountries(
        ListCountriesRequest request,
        ServerCallContext context)
    {
        var query = db.Countries.AsNoTracking();

        if (request.ActiveOnly)
            query = query.Where(c => c.IsActive);

        var items = await query
            .OrderBy(c => c.Name)
            .ToListAsync(context.CancellationToken);

        var response = new ListCountriesResponse();
        response.Items.AddRange(items.Select(c => c.ToProto()));
        return response;
    }

    public override async Task<CountryWithCurrenciesResponse> GetCountry(
        GetCountryRequest request,
        ServerCallContext context)
    {
        if (string.IsNullOrWhiteSpace(request.Alpha2))
            throw new RpcException(new Status(StatusCode.InvalidArgument, "Alpha-2 code is required."));

        var key = request.Alpha2.ToUpperInvariant();

        var country = await db.Countries
            .AsNoTracking()
            .FirstOrDefaultAsync(c => c.Alpha2 == key, context.CancellationToken);

        if (country is null)
            throw new RpcException(new Status(StatusCode.NotFound,
                $"Country '{request.Alpha2}' not found."));

        var links = await db.CountryCurrencies
            .AsNoTracking()
            .Where(cc => cc.CountryAlpha2 == key)
            .Join(db.Currencies,
                cc => cc.CurrencyCode,
                cur => cur.Code,
                (cc, cur) => new { cc, cur })
            .OrderByDescending(x => x.cc.IsPrimary)
            .ThenBy(x => x.cc.CurrencyCode)
            .ToListAsync(context.CancellationToken);

        var response = new CountryWithCurrenciesResponse
        {
            Country = country.ToProto(),
        };

        response.Currencies.AddRange(links.Select(x => x.cc.ToProto(x.cur)));
        return response;
    }
}
