using System.Text.Json;
using System.Threading.Channels;
using Grpc.Core;
using Mediator;
using StackExchange.Redis;
using SecurityApp.API.Grpc.Mapping;
using SecurityApp.API.Grpc.Proto;
using SecurityApp.Application.Pricing.Queries;
using SecurityApp.Core.Grpc;

namespace SecurityApp.API.Grpc;

public class PricingGrpcService(
    IMediator mediator,
    ILogger<PricingGrpcService> _logger,
    IConnectionMultiplexer? multiplexer = null) : Proto.PricingGrpcService.PricingGrpcServiceBase
{
    private static readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web);
    // ── Unary ─────────────────────────────────────────────────────────────────

    public override async Task<PriceResponse> GetLatestPrice(
        GetLatestPriceRequest request,
        ServerCallContext context)
    {
        if (!Guid.TryParse(request.SecurityId, out var securityId))
            throw new RpcException(new Status(StatusCode.InvalidArgument, "Invalid security_id GUID."));

        var query = new GetLatestPriceQuery(
            securityId,
            string.IsNullOrWhiteSpace(request.Source) ? null : request.Source);

        var price = await mediator.Send(query, context.CancellationToken);

        if (price is null)
            return new PriceResponse { Found = false, SecurityId = request.SecurityId };

        return price.ToProto();
    }

    // ── Server-side streaming ─────────────────────────────────────────────────

    public override async Task StreamPriceTicks(
        StreamPriceTicksRequest request,
        IServerStreamWriter<PriceTick> responseStream,
        ServerCallContext context)
    {
        if (!Guid.TryParse(request.SecurityId, out var securityId))
            throw new RpcException(new Status(StatusCode.InvalidArgument, "Invalid security_id GUID."));

        if (multiplexer is null)
        {
            _logger.LogWarning("Price tick gRPC stream requested but Redis is not configured");
            throw new RpcException(new Status(StatusCode.Unavailable,
                "gRPC streaming requires Redis. Configure ConnectionStrings:Redis."));
        }

        var pipe       = Channel.CreateUnbounded<PriceTick>();
        var subscriber = multiplexer.GetSubscriber();
        var redisKey   = RedisChannel.Literal(GrpcStreamChannels.ForPrice(securityId));
        double? lastValue = null;

        await subscriber.SubscribeAsync(redisKey, (_, msg) =>
        {
            if (msg.IsNullOrEmpty) return;
            var payload = JsonSerializer.Deserialize<PriceChangedPayload>((string)msg!, _json);
            if (payload is null) return;
            var tick = payload.ToTickProto(lastValue);
            lastValue = (double)payload.Value;
            pipe.Writer.TryWrite(tick);
        });

        try
        {
            await foreach (var tick in pipe.Reader.ReadAllAsync(context.CancellationToken))
                await responseStream.WriteAsync(tick, context.CancellationToken);
        }
        catch (OperationCanceledException)
        {
            _logger.LogDebug("Price tick stream ended for security {SecurityId} (client disconnected)", securityId);
        }
        finally
        {
            await subscriber.UnsubscribeAsync(redisKey);
            pipe.Writer.TryComplete();
        }
    }
}
