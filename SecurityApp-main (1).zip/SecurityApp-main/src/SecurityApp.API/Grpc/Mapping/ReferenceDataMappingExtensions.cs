using SecurityApp.API.Grpc.Proto;
using SecurityApp.Core.Countries.Entities;
using SecurityApp.Core.Currencies.Entities;

namespace SecurityApp.API.Grpc.Mapping;

/// <summary>Converts reference-data domain entities to proto messages.</summary>
public static class ReferenceDataMappingExtensions
{
    public static CurrencyMessage ToProto(this Currency c) => new()
    {
        Code            = c.Code,
        NumericCode     = c.NumericCode     ?? string.Empty,
        Name            = c.Name,
        Symbol          = c.Symbol          ?? string.Empty,
        Decimals        = c.Decimals,
        DisplayDecimals = c.DisplayDecimals,
        CurrencyType    = c.CurrencyType.ToString().ToUpperInvariant(),
        IsActive        = c.IsActive,
    };

    public static CountryMessage ToProto(this Country c) => new()
    {
        Alpha2      = c.Alpha2,
        Alpha3      = c.Alpha3,
        NumericCode = c.NumericCode,
        Name        = c.Name,
        Tld         = c.Tld      ?? string.Empty,
        IsActive    = c.IsActive,
    };

    public static CountryCurrencyMessage ToProto(this CountryCurrency cc, Currency currency) => new()
    {
        CurrencyCode    = cc.CurrencyCode,
        CurrencyName    = currency.Name,
        Symbol          = currency.Symbol          ?? string.Empty,
        DisplayDecimals = currency.DisplayDecimals,
        IsPrimary       = cc.IsPrimary,
        IsLegalTender   = cc.IsLegalTender,
        IsOperational   = cc.IsOperational,
    };

    public static CurrencyExternalCodeMessage ToProto(this CurrencyExternalCode x) => new()
    {
        Id           = x.Id.ToString(),
        CurrencyCode = x.CurrencyCode,
        SystemName   = x.SystemName,
        ExternalCode = x.ExternalCode,
    };
}
