using Google.Protobuf.WellKnownTypes;
using SecurityApp.API.Grpc.Proto;
using SecurityApp.Core.Grpc;

namespace SecurityApp.API.Grpc.Mapping;

/// <summary>Converts workflow stream payloads to proto messages.</summary>
public static class WorkflowMappingExtensions
{
    public static WorkflowStatusUpdate ToProto(this WorkflowInstanceChangedPayload payload) => new()
    {
        InstanceId       = payload.InstanceId.ToString(),
        Status           = payload.Status,
        CurrentStepOrder = payload.StepOrder,
        LastDecision     = payload.LastDecision   ?? string.Empty,
        LastDecisionBy   = payload.LastDecisionBy ?? string.Empty,
        UpdatedAt        = Timestamp.FromDateTime(payload.OccurredAt.Kind == DateTimeKind.Utc
            ? payload.OccurredAt
            : payload.OccurredAt.ToUniversalTime())
    };
}
