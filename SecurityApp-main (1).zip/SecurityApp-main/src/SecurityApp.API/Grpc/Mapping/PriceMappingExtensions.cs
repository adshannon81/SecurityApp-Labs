using Google.Protobuf.WellKnownTypes;
using SecurityApp.API.Grpc.Proto;
using SecurityApp.Application.Pricing.DTOs;
using SecurityApp.Core.Grpc;

namespace SecurityApp.API.Grpc.Mapping;

/// <summary>Converts Price DTOs and stream payloads to proto messages.</summary>
public static class PriceMappingExtensions
{
    public static PriceResponse ToProto(this PriceDto dto) => new()
    {
        Found     = true,
        Id        = dto.Id.ToString(),
        SecurityId = dto.SecurityId.ToString(),
        Value     = (double)dto.Value,
        Source    = dto.Source.ToString(),
        PriceType = dto.PriceType ?? string.Empty,
        Currency  = dto.Currency  ?? string.Empty,
        PriceDate = Timestamp.FromDateTime(dto.PriceDate.ToUniversalTime()),
        CreatedAt = Timestamp.FromDateTime(dto.CreatedAt.ToUniversalTime())
    };

    public static PriceTick ToTickProto(this PriceChangedPayload payload, double? previousValue = null)
    {
        var current   = (double)payload.Value;
        var change    = previousValue.HasValue ? current - previousValue.Value : 0.0;
        var changePct = previousValue is > 0   ? change / previousValue.Value * 100.0 : 0.0;

        return new PriceTick
        {
            SecurityId = payload.SecurityId.ToString(),
            Value      = current,
            Change     = change,
            ChangePct  = changePct,
            Source     = payload.Source   ?? string.Empty,
            Currency   = payload.Currency ?? string.Empty,
            PriceDate  = Timestamp.FromDateTime(payload.PriceDate.Kind == DateTimeKind.Utc
                ? payload.PriceDate : payload.PriceDate.ToUniversalTime()),
            TickedAt   = Timestamp.FromDateTime(DateTime.UtcNow)
        };
    }
}
