using Google.Protobuf.WellKnownTypes;
using SecurityApp.API.Grpc.Proto;
using SecurityApp.Application.Securities.DTOs;
using SecurityApp.Core.Grpc;

namespace SecurityApp.API.Grpc.Mapping;

/// <summary>Converts Security DTOs and stream payloads to proto messages.</summary>
public static class SecurityMappingExtensions
{
    public static SecuritySummary ToProto(this SecurityDto dto)
    {
        var summary = new SecuritySummary
        {
            Id                 = dto.Id.ToString(),
            IdentifierType     = dto.IdentifierType.ToString(),
            IdentifierValue    = dto.IdentifierValue,
            Name               = dto.Name,
            Type               = dto.Type.ToString(),
            IsActive           = dto.IsActive,
            CurrencyCode       = dto.CurrencyCode       ?? string.Empty,
            Issuer             = dto.IssuerSummary?.LegalName ?? string.Empty,
            Description        = dto.Description        ?? string.Empty,
            StatusCode         = dto.StatusCode         ?? string.Empty,
            AssetClassCode     = dto.AssetClassCode     ?? string.Empty,
            InstrumentTypeCode = dto.InstrumentTypeCode ?? string.Empty
        };

        if (dto.Identifiers is { Count: > 0 })
            summary.Identifiers.AddRange(dto.Identifiers.Select(i => new SecurityIdentifierProto
            {
                Id              = i.Id.ToString(),
                IdentifierType  = i.IdentifierType,
                IdentifierValue = i.IdentifierValue,
                SourceSystem    = i.SourceSystem    ?? string.Empty,
                IsPrimary       = i.IsPrimary
            }));

        return summary;
    }

    public static SecuritySummary ToSummaryProto(this SecurityChangedPayload payload) => new()
    {
        Id                 = payload.SecurityId.ToString(),
        IdentifierType     = payload.IdentifierType,
        IdentifierValue    = payload.IdentifierValue,
        Name               = payload.Name,
        Type               = payload.SecurityType,
        IsActive           = payload.IsActive,
        CurrencyCode       = payload.Currency,
        Issuer             = payload.Issuer,
        Description        = payload.Description,
        StatusCode         = payload.StatusCode         ?? string.Empty,
        AssetClassCode     = payload.AssetClassCode     ?? string.Empty,
        InstrumentTypeCode = payload.InstrumentTypeCode ?? string.Empty
    };

    public static SecurityChangeEvent ToChangeEvent(this SecurityChangedPayload payload)
    {
        var evt = new SecurityChangeEvent
        {
            SecurityId = payload.SecurityId.ToString(),
            ChangeType = payload.ChangeType,
            OccurredAt = Timestamp.FromDateTime(payload.OccurredAt.Kind == DateTimeKind.Utc
                ? payload.OccurredAt
                : payload.OccurredAt.ToUniversalTime())
        };
        if (payload.ChangeType != "Deleted")
            evt.Security = payload.ToSummaryProto();
        return evt;
    }
}
