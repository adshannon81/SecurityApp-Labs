﻿using System.Text.Json;
using System.Threading.Channels;
using Grpc.Core;
using StackExchange.Redis;
using SecurityApp.API.Grpc.Mapping;
using SecurityApp.API.Grpc.Proto;
using SecurityApp.Core.Grpc;
using SecurityApp.Core.Workflow.Enums;
using SecurityApp.Core.Workflow.Interfaces;
using Google.Protobuf.WellKnownTypes;

namespace SecurityApp.API.Grpc;

public class WorkflowGrpcService(
    IWorkflowEngine workflowEngine,
    ILogger<WorkflowGrpcService> _logger,
    IConnectionMultiplexer? multiplexer = null) : Proto.WorkflowGrpcService.WorkflowGrpcServiceBase
{
    private static readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web);

    // ─── Unary ────────────────────────────────────────────────────────────────

    public override async Task<PendingCountResponse> GetPendingCount(
        GetPendingCountRequest request,
        ServerCallContext context)
    {
        var steps = await workflowEngine.GetPendingForRoleAsync(request.Role, context.CancellationToken);
        return new PendingCountResponse { Count = steps.Count() };
    }

    // ─── Server-side streaming ─────────────────────────────────────────────────

    public override async Task StreamPendingCount(
        StreamPendingCountRequest request,
        IServerStreamWriter<PendingCountUpdate> responseStream,
        ServerCallContext context)
    {
        if (multiplexer is null)
        {
            _logger.LogWarning("Workflow pending-count gRPC stream requested but Redis is not configured");
            throw new RpcException(new Status(StatusCode.Unavailable,
                "gRPC streaming requires Redis. Configure ConnectionStrings:Redis."));
        }

        var triggers   = Channel.CreateUnbounded<bool>();
        var subscriber = multiplexer.GetSubscriber();
        var redisKey   = RedisChannel.Literal(GrpcStreamChannels.WorkflowPendingChanged);

        await subscriber.SubscribeAsync(redisKey, (_, _) => triggers.Writer.TryWrite(true));

        int? lastCount = null;
        try
        {
            await foreach (var _ in triggers.Reader.ReadAllAsync(context.CancellationToken))
            {
                var steps   = await workflowEngine.GetPendingForRoleAsync(request.Role, context.CancellationToken);
                var current = steps.Count();
                if (lastCount != current)
                {
                    await responseStream.WriteAsync(new PendingCountUpdate
                    {
                        Count     = current,
                        CheckedAt = Timestamp.FromDateTime(DateTime.UtcNow)
                    }, context.CancellationToken);
                    lastCount = current;
                }
            }
        }
        catch (OperationCanceledException)
        {
            _logger.LogDebug("Workflow pending-count stream ended for role '{Role}' (client disconnected)", request.Role);
        }
        finally
        {
            await subscriber.UnsubscribeAsync(redisKey);
            triggers.Writer.TryComplete();
        }
    }

    public override async Task StreamInstanceStatus(
        StreamInstanceStatusRequest request,
        IServerStreamWriter<WorkflowStatusUpdate> responseStream,
        ServerCallContext context)
    {
        if (!Guid.TryParse(request.InstanceId, out var instanceId))
            throw new RpcException(new Status(StatusCode.InvalidArgument, "Invalid instance_id GUID."));

        if (multiplexer is null)
        {
            _logger.LogWarning("Workflow instance-status gRPC stream requested but Redis is not configured");
            throw new RpcException(new Status(StatusCode.Unavailable,
                "gRPC streaming requires Redis. Configure ConnectionStrings:Redis."));
        }

        var pipe       = Channel.CreateUnbounded<WorkflowInstanceChangedPayload>();
        var subscriber = multiplexer.GetSubscriber();
        var redisKey   = RedisChannel.Literal(GrpcStreamChannels.ForWorkflowInstance(instanceId));

        await subscriber.SubscribeAsync(redisKey, (_, msg) =>
        {
            if (msg.IsNullOrEmpty) return;
            var payload = JsonSerializer.Deserialize<WorkflowInstanceChangedPayload>((string)msg!, _json);
            if (payload is not null)
                pipe.Writer.TryWrite(payload);
        });

        try
        {
            await foreach (var payload in pipe.Reader.ReadAllAsync(context.CancellationToken))
            {
                await responseStream.WriteAsync(payload.ToProto(), context.CancellationToken);

                if (payload.Status is
                    nameof(WorkflowStatus.Approved) or
                    nameof(WorkflowStatus.Rejected) or
                    nameof(WorkflowStatus.Cancelled) or
                    nameof(WorkflowStatus.Expired))
                {
                    pipe.Writer.TryComplete();
                    break;
                }
            }
        }
        catch (OperationCanceledException)
        {
            _logger.LogDebug("Workflow instance-status stream ended for instance {InstanceId} (client disconnected)", instanceId);
        }
        finally
        {
            await subscriber.UnsubscribeAsync(redisKey);
            pipe.Writer.TryComplete();
        }
    }
}
