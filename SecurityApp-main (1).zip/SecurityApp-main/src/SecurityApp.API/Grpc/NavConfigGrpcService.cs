using System.Text.Json;
using System.Threading.Channels;
using Grpc.Core;
using StackExchange.Redis;
using SecurityApp.API.Grpc.Proto;
using SecurityApp.Core.Grpc;

namespace SecurityApp.API.Grpc;

public class NavConfigGrpcService(
    ILogger<NavConfigGrpcService> _logger,
    IConnectionMultiplexer? multiplexer = null) : Proto.NavConfigGrpcService.NavConfigGrpcServiceBase
{
    private static readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web);

    public override async Task StreamNavConfigChanged(
        StreamNavConfigRequest request,
        IServerStreamWriter<NavConfigChangedEvent> responseStream,
        ServerCallContext context)
    {
        if (multiplexer is null)
        {
            _logger.LogWarning("NavConfig gRPC stream requested but Redis is not configured");
            throw new RpcException(new Status(StatusCode.Unavailable,
                "gRPC streaming requires Redis. Configure ConnectionStrings:Redis."));
        }

        var pipe       = Channel.CreateUnbounded<NavConfigChangedEvent>();
        var subscriber = multiplexer.GetSubscriber();
        var redisKey   = RedisChannel.Literal(GrpcStreamChannels.NavConfigChanged);

        await subscriber.SubscribeAsync(redisKey, (_, msg) =>
        {
            if (msg.IsNullOrEmpty) return;
            var payload = JsonSerializer.Deserialize<NavConfigChangedPayload>((string)msg!, _json);
            if (payload is null) return;

            pipe.Writer.TryWrite(new NavConfigChangedEvent
            {
                ChangedBy = payload.ChangedBy ?? string.Empty,
            });
        });

        try
        {
            await foreach (var ev in pipe.Reader.ReadAllAsync(context.CancellationToken))
                await responseStream.WriteAsync(ev, context.CancellationToken);
        }
        catch (OperationCanceledException)
        {
            _logger.LogDebug("NavConfig stream ended (client disconnected)");
        }
        finally
        {
            await subscriber.UnsubscribeAsync(redisKey);
            pipe.Writer.TryComplete();
        }
    }
}
