using System.Buffers;
using System.Diagnostics;
using System.Text;
using Serilog.Context;

namespace SecurityApp.API.Middleware;

/// <summary>
/// First middleware in the pipeline. Responsibilities:
///
///   1. Correlation ID — resolved in this priority order:
///        a) X-Correlation-Id request header   (caller: UI, PowerShell, scheduler, another service)
///        b) W3C TraceId from Activity.Current  (set automatically by ASP.NET Core)
///        c) New GUID                           (no header, no active trace — always has a value)
///      The resolved ID is echoed back via X-Correlation-Id on the response so
///      callers can record it in their own logs.
///
///   2. Serilog enrichment — pushes CorrelationId and UserId into LogContext for the
///      entire request lifetime.  Every log line emitted downstream (handlers,
///      calculators, services) automatically carries these properties without any
///      extra code in those classes.
///
///   3. Request snapshot — logs method, path, query, User-Agent, Content-Type, and
///      the first 4 KB of the request body.  Reading is streaming (ArrayPool — no
///      heap allocation) and capped at MaxBodySnippetBytes.  Binary and multipart
///      bodies are skipped; the body stream is always rewound so controllers see
///      the full payload unchanged.
/// </summary>
public class CorrelationIdMiddleware(RequestDelegate next, ILogger<CorrelationIdMiddleware> logger)
{
    private const string CorrelationHeader   = "X-Correlation-Id";
    private const int    MaxBodySnippetBytes = 4096; // 4 KB streamed via ArrayPool

    public async Task InvokeAsync(HttpContext context)
    {
        // ── 1. Resolve or generate correlation ID ─────────────────────────────
        var correlationId =
            context.Request.Headers[CorrelationHeader].FirstOrDefault()
            ?? Activity.Current?.TraceId.ToString()
            ?? Guid.NewGuid().ToString("N");

        // Echo back so the caller can record it
        context.Response.Headers[CorrelationHeader] = correlationId;

        // ── 2. Enrich every subsequent log line in this request scope ─────────
        using var cidProp = LogContext.PushProperty("CorrelationId", correlationId);
        using var uidProp = LogContext.PushProperty("UserId",
            context.User?.Identity?.Name ?? "anonymous");

        // ── 3. Log the incoming request (body streamed, not buffered whole) ────
        await LogRequestAsync(context.Request, correlationId);

        await next(context);
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    private async Task LogRequestAsync(HttpRequest req, string correlationId)
    {
        var bodySnippet = await ReadBodySnippetAsync(req);

        logger.LogInformation(
            "[{CorrelationId}] ▶ {Method} {Path}{Query} | User: {User} | UA: {UserAgent} | Content-Type: {ContentType} | Body: {Body}",
            correlationId,
            req.Method,
            req.Path,
            req.QueryString.HasValue ? req.QueryString.ToString() : "",
            req.HttpContext.User?.Identity?.Name ?? "anonymous",
            req.Headers.UserAgent.ToString(),
            req.ContentType ?? "(none)",
            bodySnippet);
    }

    private static async Task<string> ReadBodySnippetAsync(HttpRequest req)
    {
        // Only attempt to read bodies that carry a payload
        if (!HasBody(req))
            return "(no body)";

        // Skip binary and multipart — logging those is noisy or meaningless
        if (!IsLoggableContentType(req.ContentType))
            return $"(binary/multipart — not logged, declared {req.ContentLength?.ToString() ?? "unknown"} bytes)";

        if (!req.Body.CanRead)
            return "(body not readable)";

        // EnableBuffering: small bodies stay in memory, large ones spill to a
        // temp file.  Either way the stream becomes seekable so the controller
        // still receives the full body after we seek back to 0.
        req.EnableBuffering();

        var buffer = ArrayPool<byte>.Shared.Rent(MaxBodySnippetBytes);
        try
        {
            var read = await req.Body.ReadAsync(buffer.AsMemory(0, MaxBodySnippetBytes));

            if (read == 0)
                return "(empty body)";

            var snippet = Encoding.UTF8.GetString(buffer, 0, read);
            if (read == MaxBodySnippetBytes)
                snippet += " …[truncated at 4 KB]";

            return snippet;
        }
        catch (Exception ex)
        {
            return $"(body read error: {ex.Message})";
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(buffer);
            // Always rewind — the controller must see the full body unchanged
            if (req.Body.CanSeek)
                req.Body.Seek(0, SeekOrigin.Begin);
        }
    }

    private static bool HasBody(HttpRequest req) =>
        req.ContentLength > 0
        || string.Equals(req.Method, HttpMethods.Post,   StringComparison.OrdinalIgnoreCase)
        || string.Equals(req.Method, HttpMethods.Put,    StringComparison.OrdinalIgnoreCase)
        || string.Equals(req.Method, HttpMethods.Patch,  StringComparison.OrdinalIgnoreCase);

    private static bool IsLoggableContentType(string? contentType) =>
        contentType is not null &&
        (contentType.Contains("json",                 StringComparison.OrdinalIgnoreCase) ||
         contentType.Contains("xml",                  StringComparison.OrdinalIgnoreCase) ||
         contentType.Contains("text/",                StringComparison.OrdinalIgnoreCase) ||
         contentType.Contains("x-www-form-urlencoded", StringComparison.OrdinalIgnoreCase));
}
