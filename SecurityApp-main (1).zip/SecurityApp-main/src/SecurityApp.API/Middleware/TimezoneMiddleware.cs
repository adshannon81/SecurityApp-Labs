namespace SecurityApp.API.Middleware;

/// <summary>
/// Resolves the caller's timezone and stores the resulting <see cref="TimeZoneInfo"/> in
/// <c>HttpContext.Items[<see cref="TimezoneItemKey"/>]</c>.
///
/// Resolution priority (first match wins):
/// <list type="number">
///   <item><description>
///     <b>Keycloak <c>zoneinfo</c> JWT claim</b> — standard OIDC claim populated from the
///     user's Keycloak profile.  Requires the <c>profile</c> scope to be included in the
///     token and a <em>User Attribute</em> mapper named <c>zoneinfo</c> configured on the
///     Keycloak client.
///   </description></item>
///   <item><description>
///     <b>UTC</b> — silent fallback when no recognisable timezone ID is found.
///   </description></item>
/// </list>
///
/// Downstream components (the JSON converter and the model binder) consult this value to:
/// <list type="bullet">
///   <item><description>convert incoming datetime strings (no Z / no offset) from the caller's
///   local time to UTC before the model is populated.</description></item>
///   <item><description>convert UTC datetime values stored in the database back to the caller's
///   local time before writing the JSON response.</description></item>
/// </list>
///
/// <para><b>Placement:</b> must be registered <em>after</em> <c>UseAuthentication()</c> so that
/// <c>HttpContext.User</c> is already populated when the middleware runs.</para>
/// </summary>
public sealed class TimezoneMiddleware(RequestDelegate next, ILogger<TimezoneMiddleware> logger)
{
    /// <summary>Key under which the resolved <see cref="TimeZoneInfo"/> is stored in <c>HttpContext.Items</c>.</summary>
    public const string TimezoneItemKey = "ClientTimezone";

    /// <summary>Standard OIDC claim name for timezone, populated from the Keycloak user profile.</summary>
    private const string ZoneinfoClaim = "zoneinfo";

    public async Task InvokeAsync(HttpContext context)
    {
        var tzId = context.User.FindFirst(ZoneinfoClaim)?.Value;

        if (!string.IsNullOrWhiteSpace(tzId))
        {
            if (TimeZoneInfo.TryFindSystemTimeZoneById(tzId, out var tz))
            {
                context.Items[TimezoneItemKey] = tz;
            }
            else
            {
                logger.LogWarning(
                    "Unknown timezone '{TzId}' in {Claim} claim — falling back to UTC",
                    tzId, ZoneinfoClaim);
            }
        }

        await next(context);
    }
}
