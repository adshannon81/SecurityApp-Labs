using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SecurityApp.Core.Idempotency;
using SecurityApp.Core.Idempotency.Entities;
using SecurityApp.Core.Idempotency.Interfaces;

namespace SecurityApp.API.Middleware;

/// <summary>
/// REST idempotency middleware. Applies to all mutating HTTP verbs (POST, PUT, PATCH, DELETE).
///
/// Clients include an <c>Idempotency-Key</c> request header (≤ 200 chars).
/// If the header is absent the request passes through unchanged.
///
/// Key lifecycle:
///   PROCESSING — key was seen; another in-flight request has the same key → 409 IDEMPOTENCY_CONFLICT.
///   COMPLETED  — request finished successfully; the stored response is replayed without re-processing.
///   FAILED     — request ended with a 5xx; the client may retry with the same key.
///
/// Keys expire after 24 hours and are cleaned up by <c>ExecutionHistoryCleanupJob</c>.
/// </summary>
public class IdempotencyMiddleware(RequestDelegate next, ILogger<IdempotencyMiddleware> logger)
{
    private const string IdempotencyHeader = "Idempotency-Key";

    private static readonly HashSet<string> MutatingMethods =
        new(StringComparer.OrdinalIgnoreCase) { "POST", "PUT", "PATCH", "DELETE" };

    public async Task InvokeAsync(HttpContext context, IIdempotencyKeyRepository repository)
    {
        if (!MutatingMethods.Contains(context.Request.Method))
        {
            await next(context);
            return;
        }

        var key = context.Request.Headers[IdempotencyHeader].FirstOrDefault();
        if (string.IsNullOrWhiteSpace(key))
        {
            await next(context);
            return;
        }

        if (key.Length > 200)
        {
            await WriteProblemAsync(context, StatusCodes.Status400BadRequest,
                "Bad Request", "Idempotency-Key must not exceed 200 characters.", null);
            return;
        }

        var operationType = $"{context.Request.Method}:{context.Request.Path}";

        var existing = await repository.FindAsync(key, context.RequestAborted);

        if (existing is not null)
        {
            switch (existing.Status)
            {
                case IdempotencyStatus.Processing:
                    logger.LogWarning(
                        "Idempotency conflict: key {Key} is already being processed", key);
                    await WriteProblemAsync(context, StatusCodes.Status409Conflict,
                        "Conflict",
                        "A request with this idempotency key is already being processed.",
                        "IDEMPOTENCY_CONFLICT");
                    return;

                case IdempotencyStatus.Completed:
                    logger.LogDebug("Replaying idempotent response for key {Key}", key);
                    context.Response.StatusCode  = existing.ResponseCode ?? 200;
                    context.Response.ContentType = "application/json";
                    context.Response.Headers["X-Idempotency-Replay"] = "true";
                    if (!string.IsNullOrEmpty(existing.ResponseBody))
                        await context.Response.WriteAsync(existing.ResponseBody,
                            context.RequestAborted);
                    return;

                case IdempotencyStatus.Failed:
                    // Allow retry: reset the failed entry back to PROCESSING.
                    logger.LogDebug("Resetting FAILED idempotency key {Key} to allow retry", key);
                    await repository.ResetToProcessingAsync(
                        key, DateTime.UtcNow.AddHours(24), context.RequestAborted);
                    break;
            }
        }
        else
        {
            var entry = new IdempotencyKey
            {
                Key           = key,
                OperationType = operationType,
                Status        = IdempotencyStatus.Processing,
                CreatedAt     = DateTime.UtcNow,
                ExpiresAt     = DateTime.UtcNow.AddHours(24)
            };

            try
            {
                await repository.CreateAsync(entry, context.RequestAborted);
            }
            catch (DbUpdateException)
            {
                // Race condition: a concurrent request already inserted this key.
                logger.LogWarning(
                    "Idempotency race condition: key {Key} was inserted concurrently", key);
                await WriteProblemAsync(context, StatusCodes.Status409Conflict,
                    "Conflict",
                    "A request with this idempotency key is already being processed.",
                    "IDEMPOTENCY_CONFLICT");
                return;
            }
        }

        // Buffer the response so we can capture it before forwarding to the client.
        var originalBody = context.Response.Body;
        using var buffer = new MemoryStream();
        context.Response.Body = buffer;

        var requestSucceeded = false;
        int capturedStatusCode = 0;
        string capturedBody    = string.Empty;

        try
        {
            await next(context);

            requestSucceeded   = true;
            capturedStatusCode = context.Response.StatusCode;

            buffer.Position = 0;
            capturedBody = await new StreamReader(buffer, leaveOpen: true).ReadToEndAsync(
                context.RequestAborted);

            // Forward buffered response to the client.
            buffer.Position = 0;
            await buffer.CopyToAsync(originalBody, context.RequestAborted);
        }
        catch
        {
            try { await repository.MarkFailedAsync(key); } catch { /* best-effort */ }
            throw;
        }
        finally
        {
            context.Response.Body = originalBody;
        }

        // Persist outcome (after response has been forwarded).
        if (requestSucceeded)
        {
            if (capturedStatusCode is >= 200 and < 500)
                await repository.MarkCompletedAsync(key, capturedStatusCode, capturedBody);
            else
                await repository.MarkFailedAsync(key);
        }
    }

    private static Task WriteProblemAsync(
        HttpContext context, int statusCode, string title, string detail, string? code)
    {
        context.Response.StatusCode  = statusCode;
        context.Response.ContentType = "application/problem+json";

        var problem = new ProblemDetails
        {
            Status   = statusCode,
            Title    = title,
            Detail   = detail,
            Instance = context.Request.Path
        };

        if (code is not null)
            problem.Extensions["code"] = code;

        return context.Response.WriteAsJsonAsync(problem);
    }
}
