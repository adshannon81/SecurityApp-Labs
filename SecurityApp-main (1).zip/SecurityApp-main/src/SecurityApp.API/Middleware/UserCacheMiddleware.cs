using SecurityApp.Core.Users;

namespace SecurityApp.API.Middleware;

/// <summary>
/// On every authenticated request, upserts the JWT sub UUID + display name into user_cache.
/// This keeps the cache fresh so display names remain correct even after LDAP/Keycloak changes.
/// </summary>
public class UserCacheMiddleware
{
    private readonly RequestDelegate _next;

    public UserCacheMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context, IUserCacheService userCacheService)
    {
        if (context.User.Identity?.IsAuthenticated == true)
        {
            var sub         = context.User.FindFirst("sub")?.Value;
            var displayName = context.User.FindFirst("name")?.Value;
            var email       = context.User.FindFirst("email")?.Value
                           ?? context.User.FindFirst("preferred_username")?.Value;

            if (!string.IsNullOrEmpty(sub) && !string.IsNullOrEmpty(displayName))
            {
                await userCacheService.UpsertAsync(sub, displayName, email, context.RequestAborted);
            }
        }

        await _next(context);
    }
}
