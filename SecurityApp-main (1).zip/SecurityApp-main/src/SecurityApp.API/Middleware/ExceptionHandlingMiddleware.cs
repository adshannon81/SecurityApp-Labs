﻿using Microsoft.AspNetCore.Mvc;
using SecurityApp.Core.Shared.Exceptions;
using SecurityApp.Core.Workflow.Entities;

namespace SecurityApp.API.Middleware;

/// <summary>
/// Global exception handler middleware. Catches all unhandled exceptions and returns
/// RFC 7807 ProblemDetails JSON responses so clients always receive a consistent error shape.
///
/// Mapping:
///   NotFoundException            - 404 Not Found
///   Any other Exception          - 500 Internal Server Error
///                                  (detail hidden in Production, exposed in Development)
/// </summary>
public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;
    private readonly IHostEnvironment _env;

    public ExceptionHandlingMiddleware(
        RequestDelegate next,
        ILogger<ExceptionHandlingMiddleware> logger,
        IHostEnvironment env)
    {
        _next = next;
        _logger = logger;
        _env = env;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (WorkflowPendingException ex)
        {
            context.Response.StatusCode  = StatusCodes.Status202Accepted;
            context.Response.ContentType = "application/json";
            await context.Response.WriteAsJsonAsync(new
            {
                message            = ex.Message,
                workflowInstanceId = ex.Instance.Id,
                status             = ex.Instance.Status.ToString()
            });
        }
        catch (NotFoundException ex)
        {
            _logger.LogWarning(ex, "Resource not found: {Message}", ex.Message);
            await WriteProblemAsync(context, StatusCodes.Status404NotFound, "Not Found", ex.Message);
        }
        catch (ConcurrencyConflictException ex)
        {
            _logger.LogWarning(ex, "Concurrency conflict: {Message}", ex.Message);
            await WriteProblemAsync(context, StatusCodes.Status409Conflict, "CONCURRENCY_CONFLICT", ex.Message);
        }
        catch (DuplicateKeyException ex)
        {
            _logger.LogWarning(ex, "Duplicate key: {Message}", ex.Message);
            await WriteProblemAsync(context, StatusCodes.Status409Conflict, "DUPLICATE_KEY", ex.Message);
        }
        catch (InvalidLifecycleTransitionException ex)
        {
            _logger.LogWarning(ex, "Invalid lifecycle transition: {Message}", ex.Message);
            await WriteProblemAsync(context, StatusCodes.Status422UnprocessableEntity, "INVALID_LIFECYCLE_TRANSITION", ex.Message);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled exception processing {Method} {Path}",
                context.Request.Method, context.Request.Path);

            var detail = _env.IsDevelopment()
                ? ex.ToString()
                : "An unexpected error occurred. Please contact support.";

            await WriteProblemAsync(context, StatusCodes.Status500InternalServerError,
                "Internal Server Error", detail);
        }
    }

    private static Task WriteProblemAsync(HttpContext context, int statusCode, string title, string detail)
    {
        context.Response.StatusCode = statusCode;
        context.Response.ContentType = "application/problem+json";

        var problem = new ProblemDetails
        {
            Status   = statusCode,
            Title    = title,
            Detail   = detail,
            Instance = context.Request.Path
        };

        return context.Response.WriteAsJsonAsync(problem);
    }
}
