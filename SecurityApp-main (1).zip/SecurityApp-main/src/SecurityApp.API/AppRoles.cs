﻿namespace SecurityApp.API;

/// <summary>
/// Application role name constants used throughout the API.
/// - Admin:       Full access - all endpoints including delete, plugin management, audit logs, role assignment.
/// - Contributor: Read + write - create/update securities and prices, trigger imports. Cannot delete or manage roles.
/// - Viewer:      Read only - GET endpoints only.
/// </summary>
public static class AppRoles
{
    public const string Admin = "Admin";
    public const string Contributor = "Contributor";
    public const string Viewer = "Viewer";

    // Compile-time combined strings for use in [Authorize(Roles = ...)] attributes
    public const string AdminOrContributor = Admin + "," + Contributor;
    public const string AnyRole = Admin + "," + Contributor + "," + Viewer;

    public static readonly IReadOnlyList<string> All = [Admin, Contributor, Viewer];
}
