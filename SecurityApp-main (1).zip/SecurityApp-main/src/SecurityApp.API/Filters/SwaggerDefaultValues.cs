using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.OpenApi;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace SecurityApp.API.Filters;

/// <summary>
/// Swashbuckle operation filter that removes media types the action does not
/// explicitly support, keeping Swagger UI output clean.
/// </summary>
public sealed class SwaggerDefaultValues : IOperationFilter
{
    public void Apply(OpenApiOperation operation, OperationFilterContext context)
    {
        foreach (var responseType in context.ApiDescription.SupportedResponseTypes)
        {
            var responseKey = responseType.IsDefaultResponse
                ? "default"
                : responseType.StatusCode.ToString();

            if (!operation.Responses.TryGetValue(responseKey, out var response)) continue;

            var contentKeys = response.Content.Keys.ToList();
            foreach (var contentType in contentKeys)
            {
                if (!responseType.ApiResponseFormats.Any(f => f.MediaType?.Equals(contentType, StringComparison.OrdinalIgnoreCase) == true))
                    response.Content.Remove(contentType);
            }
        }
    }
}
