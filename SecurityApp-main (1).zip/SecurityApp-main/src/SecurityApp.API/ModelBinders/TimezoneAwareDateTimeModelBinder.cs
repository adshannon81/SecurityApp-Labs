using System.Globalization;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using SecurityApp.API.Middleware;

namespace SecurityApp.API.ModelBinders;

/// <summary>
/// Model binder for <see cref="DateTime"/> and <see cref="Nullable{T}">DateTime?</see>
/// values arriving via query strings, route values, or form fields.
///
/// <para>If the parsed value has <c>DateTimeKind.Unspecified</c> — i.e. the string contained
/// no <c>Z</c> suffix and no UTC offset (e.g. <c>?asOf=2024-06-01T14:30:00</c>) — it is
/// treated as the caller's local time (resolved from the <c>X-Timezone</c> header via
/// <see cref="TimezoneMiddleware"/>) and converted to UTC before the action receives it.</para>
///
/// <para>Strings that already carry a <c>Z</c> or an explicit offset are accepted as-is and
/// normalised to UTC, matching the behaviour of the JSON converter for request bodies.</para>
/// </summary>
public sealed class TimezoneAwareDateTimeModelBinder : IModelBinder
{
    public Task BindModelAsync(ModelBindingContext bindingContext)
    {
        ArgumentNullException.ThrowIfNull(bindingContext);

        var valueResult = bindingContext.ValueProvider.GetValue(bindingContext.ModelName);
        if (valueResult == ValueProviderResult.None)
            return Task.CompletedTask;

        var raw = valueResult.FirstValue;
        if (string.IsNullOrWhiteSpace(raw))
            return Task.CompletedTask;

        // RoundtripKind: preserves Kind implied by "Z" or "+HH:mm" offset in the string.
        if (!DateTime.TryParse(raw, CultureInfo.InvariantCulture,
                DateTimeStyles.RoundtripKind | DateTimeStyles.AllowWhiteSpaces, out var dt))
        {
            bindingContext.ModelState.TryAddModelError(
                bindingContext.ModelName,
                $"'{raw}' is not a valid date/time value.");
            return Task.CompletedTask;
        }

        var utc = dt.Kind switch
        {
            DateTimeKind.Utc   => dt,
            DateTimeKind.Local => dt.ToUniversalTime(),
            _                  => ConvertToUtcUsingClientTimezone(bindingContext.HttpContext, dt)
        };

        bindingContext.Result = ModelBindingResult.Success(utc);
        return Task.CompletedTask;
    }

    private static DateTime ConvertToUtcUsingClientTimezone(HttpContext context, DateTime dt)
    {
        var tz = context.Items[TimezoneMiddleware.TimezoneItemKey] as TimeZoneInfo
                 ?? TimeZoneInfo.Utc;
        return TimeZoneInfo.ConvertTimeToUtc(dt, tz);
    }
}
