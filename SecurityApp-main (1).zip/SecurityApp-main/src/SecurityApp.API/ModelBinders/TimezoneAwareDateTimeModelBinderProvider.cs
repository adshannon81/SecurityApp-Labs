using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace SecurityApp.API.ModelBinders;

/// <summary>
/// Registers <see cref="TimezoneAwareDateTimeModelBinder"/> for <see cref="DateTime"/>
/// and <see cref="Nullable{T}">DateTime?</see> model types so that query-string and
/// route datetime values are run through timezone conversion automatically.
///
/// Insert this provider at index 0 in <c>MvcOptions.ModelBinderProviders</c> so it
/// takes priority over the framework's built-in <c>SimpleTypeModelBinder</c>.
/// </summary>
public sealed class TimezoneAwareDateTimeModelBinderProvider : IModelBinderProvider
{
    public IModelBinder? GetBinder(ModelBinderProviderContext context)
    {
        ArgumentNullException.ThrowIfNull(context);

        return context.Metadata.ModelType == typeof(DateTime)
            || context.Metadata.ModelType == typeof(DateTime?)
            ? new TimezoneAwareDateTimeModelBinder()
            : null;
    }
}
