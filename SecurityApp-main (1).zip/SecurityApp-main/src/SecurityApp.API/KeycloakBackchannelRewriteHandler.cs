namespace SecurityApp.API;

/// <summary>
/// Rewrites outgoing OIDC/JWKS requests from the public Keycloak hostname
/// (e.g. <c>http://localhost:4200/auth</c>) to the Docker-internal hostname
/// (e.g. <c>http://keycloak:8080/auth</c>) so the API can fetch signing keys
/// without exposing Keycloak's backchannel to dynamic host-header resolution.
/// </summary>
internal sealed class KeycloakBackchannelRewriteHandler : DelegatingHandler
{
    private readonly Uri _externalBase;
    private readonly Uri _internalBase;
    private const int MaxRedirects = 5;

    public KeycloakBackchannelRewriteHandler(string externalBase, string internalBase)
        : base(new HttpClientHandler { AllowAutoRedirect = false })
    {
        _externalBase = new Uri(externalBase.TrimEnd('/') + "/");
        _internalBase = new Uri(internalBase.TrimEnd('/') + "/");
    }

    protected override async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request, CancellationToken cancellationToken)
    {
        RewriteUri(request);

        var response = await base.SendAsync(request, cancellationToken);

        // Follow redirects manually so we can rewrite any Location header
        // that points back at the unreachable external hostname.
        var redirects = 0;
        while (IsRedirect(response.StatusCode) && redirects < MaxRedirects)
        {
            var location = response.Headers.Location;
            if (location is null) break;

            var target = location.IsAbsoluteUri
                ? location
                : new Uri(request.RequestUri ?? _internalBase, location);
            using var redirect = new HttpRequestMessage(HttpMethod.Get, target);
            RewriteUri(redirect);

            response.Dispose();
            response = await base.SendAsync(redirect, cancellationToken);
            redirects++;
        }

        return response;
    }

    private void RewriteUri(HttpRequestMessage request)
    {
        if (request.RequestUri is not null && _externalBase.IsBaseOf(request.RequestUri))
        {
            var relative = _externalBase.MakeRelativeUri(request.RequestUri).ToString();
            request.RequestUri = new Uri(_internalBase, relative);
        }
    }

    private static bool IsRedirect(System.Net.HttpStatusCode status) =>
        status is System.Net.HttpStatusCode.Moved
              or System.Net.HttpStatusCode.Found
              or System.Net.HttpStatusCode.SeeOther
              or System.Net.HttpStatusCode.TemporaryRedirect
              or (System.Net.HttpStatusCode)308;
}
