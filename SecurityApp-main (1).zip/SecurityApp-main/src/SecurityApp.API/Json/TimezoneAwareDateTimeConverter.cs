using System.Text.Json;
using System.Text.Json.Serialization;
using SecurityApp.API.Middleware;

namespace SecurityApp.API.Json;

/// <summary>
/// System.Text.Json converter that applies timezone-aware (de)serialisation for
/// <see cref="DateTime"/> values travelling through the MVC JSON pipeline.
///
/// <para><b>Deserialise (client → server / request body):</b><br/>
/// If the incoming JSON string carries no UTC offset and no <c>Z</c> suffix
/// (<c>DateTimeKind.Unspecified</c>), the value is interpreted as the caller's local
/// time (resolved from the <c>X-Timezone</c> header via <see cref="TimezoneMiddleware"/>)
/// and converted to UTC.  Strings that already carry a <c>Z</c> or an offset are
/// returned as UTC unchanged.</para>
///
/// <para><b>Serialise (server → client / response body):</b><br/>
/// UTC datetime values stored in the database are converted to the caller's local time
/// and written with the corresponding UTC offset so the client knows the exact instant
/// (e.g. <c>2024-06-01T14:30:00-04:00</c>).  When no <c>X-Timezone</c> header is
/// present the value is emitted as-is with a <c>Z</c> suffix
/// (e.g. <c>2024-06-01T10:30:00.000Z</c>).</para>
///
/// <para>This converter is registered for <c>DateTime</c>; System.Text.Json's built-in
/// nullable wrapper automatically applies it to <c>DateTime?</c> as well.</para>
/// </summary>
public sealed class TimezoneAwareDateTimeConverter(IHttpContextAccessor httpContextAccessor)
    : JsonConverter<DateTime>
{
    // ── Deserialise ───────────────────────────────────────────────────────────

    public override DateTime Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        var dt = reader.GetDateTime();

        return dt.Kind switch
        {
            DateTimeKind.Utc   => dt,
            DateTimeKind.Local => dt.ToUniversalTime(),
            _                  => TimeZoneInfo.ConvertTimeToUtc(dt, GetClientTimezone())
        };
    }

    // ── Serialise ─────────────────────────────────────────────────────────────

    public override void Write(Utf8JsonWriter writer, DateTime value, JsonSerializerOptions options)
    {
        // Normalise to UTC — values stored in the DB are always UTC; Kind may be
        // Unspecified if the value came directly from a SQL reader.
        var utc = value.Kind switch
        {
            DateTimeKind.Utc   => value,
            DateTimeKind.Local => value.ToUniversalTime(),
            _                  => DateTime.SpecifyKind(value, DateTimeKind.Utc)
        };

        var tz = GetClientTimezone();

        if (tz.Equals(TimeZoneInfo.Utc))
        {
            // ISO 8601 UTC, e.g. 2024-06-01T10:30:00.000Z
            writer.WriteStringValue(utc.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"));
        }
        else
        {
            // Convert to caller's local time and include the UTC offset so the client
            // can reconstruct the exact instant (e.g. 2024-06-01T14:30:00-04:00).
            var local  = TimeZoneInfo.ConvertTimeFromUtc(utc, tz);
            var offset = tz.GetUtcOffset(local);
            writer.WriteStringValue(new DateTimeOffset(local, offset).ToString("yyyy-MM-ddTHH:mm:sszzz"));
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private TimeZoneInfo GetClientTimezone()
        => httpContextAccessor.HttpContext?.Items[TimezoneMiddleware.TimezoneItemKey] as TimeZoneInfo
           ?? TimeZoneInfo.Utc;
}
