using SecurityApp.Core.FieldVisibility;

namespace SecurityApp.API.Json;

/// <summary>
/// Singleton in-memory cache of all active FieldVisibilityRules.
/// 
/// The JSON converter factory runs synchronously, so we load rules once and
/// keep them in memory. Call <see cref="Invalidate"/> after any admin mutation
/// so the next request reloads from the database.
/// </summary>
public sealed class FieldVisibilityRuleCache(IServiceScopeFactory scopeFactory)
{
    // Indexed by EntityType → ordered list (priority desc) for fast look-up.
    private volatile ILookup<string, FieldVisibilityRule>? _byEntityType;

    /// <summary>
    /// Returns all active rules indexed by EntityType.
    /// Loads from DB on first call; subsequent calls are O(1) in-memory.
    /// </summary>
    public ILookup<string, FieldVisibilityRule> GetAll()
        => _byEntityType ??= Load();

    /// <summary>Drops the cache so the next request re-reads from the database.</summary>
    public void Invalidate() => _byEntityType = null;

    // Sync-over-async is intentional here: this path is hit at most once per
    // application lifetime (until manually invalidated). The DB call is tiny.
    private ILookup<string, FieldVisibilityRule> Load()
    {
        using var scope = scopeFactory.CreateScope();
        var repo  = scope.ServiceProvider.GetRequiredService<IFieldVisibilityRuleRepository>();
        var rules = repo.GetAllAsync().GetAwaiter().GetResult();
        return rules
            .Where(r => r.IsActive && r.IsCurrent && !r.IsDeleted)
            .OrderByDescending(r => r.Priority)
            .ToLookup(r => r.Field?.Entity?.EntityType ?? string.Empty, StringComparer.Ordinal);
    }
}
