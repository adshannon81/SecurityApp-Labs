using SecurityApp.Core.FieldVisibility.Enums;

namespace SecurityApp.API.Json;

/// <summary>
/// Pure-static obfuscation strategies applied when a field visibility rule
/// has Visibility = Obfuscated. Always returns a string (or null), regardless
/// of the original property type, so the JSON value type may change.
/// The Angular frontend should treat obfuscated fields as display-only strings.
/// </summary>
public static class FieldObfuscator
{
    /// <summary>
    /// Applies the given obfuscation strategy to <paramref name="value"/>.
    /// Returns <c>null</c> when value is null.
    /// Returns the value unchanged when <paramref name="type"/> is None.
    /// Otherwise always returns a <c>string</c>.
    /// </summary>
    public static object? Apply(object? value, ObfuscationType type)
    {
        if (value is null) return null;
        return type switch
        {
            ObfuscationType.Email  => ObfuscateEmail(value.ToString() ?? ""),
            ObfuscationType.Text   => ObfuscateText(value.ToString() ?? ""),
            ObfuscationType.Name   => ObfuscateName(value.ToString() ?? ""),
            ObfuscationType.Date   => ObfuscateDate(value),
            ObfuscationType.Number => "***",
            _                      => value,
        };
    }

    // ── Strategies ────────────────────────────────────────────────────────────

    // john.doe@company.com  →  j***.d**@c******.com
    private static string ObfuscateEmail(string email)
    {
        var at = email.IndexOf('@');
        if (at <= 0) return ObfuscateText(email);

        var local      = email[..at];
        var domain     = email[(at + 1)..];
        var dotIdx     = domain.LastIndexOf('.');
        var domainName = dotIdx > 0 ? domain[..dotIdx] : domain;
        var tld        = dotIdx > 0 ? domain[dotIdx..] : "";

        return $"{MaskWord(local)}@{MaskWord(domainName)}{tld}";
    }

    // SomeValue → Som*****
    private static string ObfuscateText(string s) =>
        s.Length <= 3 ? "***" : s[..3] + new string('*', Math.Min(s.Length - 3, 5));

    // John Smith → J*** S****
    private static string ObfuscateName(string name)
    {
        var words = name.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        return string.Join(' ', words.Select(MaskWord));
    }

    // DateTime → "2024-**-**", anything else → "****"
    private static string ObfuscateDate(object value) =>
        value is DateTime dt   ? $"{dt.Year:0000}-**-**"  :
        value is DateTimeOffset d ? $"{d.Year:0000}-**-**" : "****";

    // Keeps first char + up to 3 stars
    private static string MaskWord(string s) =>
        s.Length == 0 ? s :
        s[0] + new string('*', Math.Min(s.Length - 1, 3));
}
