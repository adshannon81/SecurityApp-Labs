using System.Reflection;
using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Http;
using SecurityApp.Core.FieldVisibility;

namespace SecurityApp.API.Json;

/// <summary>
/// Converts Application-layer DTOs by applying DB-driven field visibility rules.
///
/// For each serialized property the serializer looks up the (EntityType, FieldName)
/// rules (ordered by priority desc) and applies the first rule whose required
/// permission is present in the caller's "permissions" JWT claim:
///
///   • Full       → serialize the value as-is
///   • Obfuscated → run the configured obfuscation strategy, emit as string
///
/// If no rule matches the caller's permissions → emit null (field hidden).
/// If a field has no rules at all → serialize unrestricted (always visible).
/// </summary>
public sealed class FieldPermissionConverterFactory(
    IHttpContextAccessor   httpContextAccessor,
    FieldVisibilityRuleCache ruleCache)
    : JsonConverterFactory
{
    /// <summary>
    /// Apply to concrete classes in the SecurityApp.Application namespace
    /// (DTOs). Primitives, enums, strings, and other types are excluded.
    /// </summary>
    public override bool CanConvert(Type typeToConvert) =>
        typeToConvert.IsClass &&
        !typeToConvert.IsAbstract &&
        typeToConvert != typeof(string) &&
        typeToConvert.Namespace?.StartsWith("SecurityApp.Application") == true;

    public override JsonConverter CreateConverter(Type typeToConvert, JsonSerializerOptions options)
    {
        var converterType = typeof(FieldVisibilityConverter<>).MakeGenericType(typeToConvert);
        return (JsonConverter)Activator.CreateInstance(
            converterType, httpContextAccessor, ruleCache)!;
    }
}

/// <summary>
/// Typed converter that enforces field visibility rules at serialization time.
/// </summary>
file sealed class FieldVisibilityConverter<T>(
    IHttpContextAccessor    httpContextAccessor,
    FieldVisibilityRuleCache ruleCache)
    : JsonConverter<T> where T : class
{
    private static readonly PropertyInfo[] Properties =
        typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

    private static readonly string EntityTypeName = typeof(T).Name;

    public override T? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        var inner = CloneWithoutSelf(options);
        return JsonSerializer.Deserialize<T>(ref reader, inner);
    }

    public override void Write(Utf8JsonWriter writer, T value, JsonSerializerOptions options)
    {
        var permissions  = GetPermissions();
        var allRules     = ruleCache.GetAll();
        var inner        = CloneWithoutSelf(options);

        writer.WriteStartObject();

        foreach (var prop in Properties)
        {
            if (!prop.CanRead) continue;

            var fieldRules = allRules[EntityTypeName]
                .Where(r => r.Field?.FieldName == prop.Name)
                .ToList(); // already ordered by priority desc

            var jsonName  = GetJsonName(prop, options);
            var propValue = prop.GetValue(value);

            if (fieldRules.Count == 0)
            {
                // No rules configured → unrestricted
                writer.WritePropertyName(jsonName);
                JsonSerializer.Serialize(writer, propValue, prop.PropertyType, inner);
                continue;
            }

            // Find first rule whose permission the caller holds
            var matchedRule = fieldRules
                .FirstOrDefault(r => permissions.Contains(r.PermissionDefinition.PermissionKey));

            if (matchedRule is null)
            {
                // No matching tier → hide (null)
                writer.WriteNull(jsonName);
                continue;
            }

            if (matchedRule.VisibilityState == "VISIBLE")
            {
                writer.WritePropertyName(jsonName);
                JsonSerializer.Serialize(writer, propValue, prop.PropertyType, inner);
            }
            else
            {
                // Obfuscated — always emits a string (type may differ from original)
                writer.WritePropertyName(jsonName);
                var obfuscated = FieldObfuscator.Apply(propValue, matchedRule.ObfuscationType);
                JsonSerializer.Serialize(writer, obfuscated, typeof(object), inner);
            }
        }

        writer.WriteEndObject();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private HashSet<string> GetPermissions()
    {
        var claims = httpContextAccessor.HttpContext?.User.FindAll("permissions");
        return claims == null
            ? []
            : new HashSet<string>(claims.Select(c => c.Value), StringComparer.Ordinal);
    }

    private static string GetJsonName(PropertyInfo prop, JsonSerializerOptions options)
    {
        var attr = prop.GetCustomAttribute<JsonPropertyNameAttribute>();
        if (attr != null) return attr.Name;
        return options.PropertyNamingPolicy?.ConvertName(prop.Name) ?? prop.Name;
    }

    private static JsonSerializerOptions CloneWithoutSelf(JsonSerializerOptions options)
    {
        var clone    = new JsonSerializerOptions(options);
        var toRemove = clone.Converters.OfType<FieldPermissionConverterFactory>().ToList();
        foreach (var c in toRemove) clone.Converters.Remove(c);
        return clone;
    }
}
