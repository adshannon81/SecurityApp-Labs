using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace SecurityApp.API.Json;

/// <summary>
/// Wires <see cref="TimezoneAwareDateTimeConverter"/> into MVC's <see cref="JsonOptions"/>
/// via the <see cref="IConfigureOptions{TOptions}"/> pattern.
///
/// Using <c>IConfigureOptions</c> instead of calling <c>.AddJsonOptions()</c> directly
/// allows the converter to receive <see cref="IHttpContextAccessor"/> through normal
/// constructor injection — avoiding the chicken-and-egg problem of needing a built
/// service provider during <c>AddControllers()</c>.
/// </summary>
internal sealed class ConfigureTimezoneJsonConverter(TimezoneAwareDateTimeConverter converter)
    : IConfigureOptions<JsonOptions>
{
    public void Configure(JsonOptions options)
        => options.JsonSerializerOptions.Converters.Insert(0, converter);
}
