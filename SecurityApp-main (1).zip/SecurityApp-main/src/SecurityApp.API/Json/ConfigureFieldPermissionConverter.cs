using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace SecurityApp.API.Json;

/// <summary>
/// Wires <see cref="FieldPermissionConverterFactory"/> into MVC's <see cref="JsonOptions"/>
/// via the <see cref="IConfigureOptions{TOptions}"/> pattern so that
/// <see cref="IHttpContextAccessor"/> and <see cref="FieldVisibilityRuleCache"/> are
/// available via constructor injection.
/// </summary>
internal sealed class ConfigureFieldPermissionConverter(
    IHttpContextAccessor    httpContextAccessor,
    FieldVisibilityRuleCache ruleCache)
    : IConfigureOptions<JsonOptions>
{
    public void Configure(JsonOptions options)
        => options.JsonSerializerOptions.Converters.Add(
               new FieldPermissionConverterFactory(httpContextAccessor, ruleCache));
}
