using Microsoft.AspNetCore.Authorization;

namespace SecurityApp.API.Authorization;

/// <summary>
/// Requires the authenticated user to hold a specific permission value
/// in the "permissions" JWT claim (populated by Keycloak's client-role mapper).
/// </summary>
public sealed class PermissionRequirement(string permission) : IAuthorizationRequirement
{
    public string Permission { get; } = permission;
}

public sealed class PermissionAuthorizationHandler
    : AuthorizationHandler<PermissionRequirement>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        PermissionRequirement requirement)
    {
        var values = context.User.FindAll("permissions")
                                 .Select(c => c.Value);

        if (values.Contains(requirement.Permission))
            context.Succeed(requirement);

        return Task.CompletedTask;
    }
}
