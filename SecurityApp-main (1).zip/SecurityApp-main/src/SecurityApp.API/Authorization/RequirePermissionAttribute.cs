using Microsoft.AspNetCore.Authorization;

namespace SecurityApp.API.Authorization;

/// <summary>
/// Declares that the endpoint requires the caller to hold a specific permission
/// in their "permissions" JWT claim.
///
/// Usage:
///   [RequirePermission("securities:read")]
///   [RequirePermission("plugins:manage")]   // no code change needed for new permissions
///
/// The permission string must match a Keycloak client role assigned to the user,
/// mapped into the token via the "permissions-mapper" protocol mapper on securityapp-api.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public sealed class RequirePermissionAttribute : AuthorizeAttribute
{
    public RequirePermissionAttribute(string permission)
        : base($"Permission:{permission}")
    {
    }
}
