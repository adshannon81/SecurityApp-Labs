﻿using Serilog;
using SecurityApp.API.DependencyInjection;
using SecurityApp.API.SecretManagement;
using SecurityApp.API.Startup;

var builder = WebApplication.CreateBuilder(args);

var databaseProvider = builder.Configuration["DatabaseProvider"] ?? "PostgreSQL";
var vaultMqHolder = new VaultRabbitMqCredentialHolder();

builder.Services.AddSingleton(vaultMqHolder);

builder.Host.ConfigureObservability(builder.Configuration);

builder.Services.AddSecretProviders(builder.Configuration);

builder.Services
    .AddApiCore(builder.Configuration, builder.Environment)
    .AddSecurity(builder.Configuration, builder.Environment)
    .AddPersistence(builder.Configuration)
    .AddAuthorizationData()
    .AddCachingAndRedis(builder.Configuration)
    .AddMessaging(builder.Host, builder.Configuration, databaseProvider, vaultMqHolder)
    .AddNotifications(builder.Configuration)
    .AddScheduling(builder.Configuration)
    .AddMediatorAndPipeline()
    .AddRatings()
    .AddPlugins(builder.Configuration, builder.Environment)
    .AddWorkflowEngine()
    .AddPlatformServices(builder.Configuration);

var app = builder.Build();

await app.BootstrapSecretsAsync(databaseProvider, vaultMqHolder);
await app.ConfigureQuartzListenersAsync();
await app.BootstrapPluginsAsync();

app.ConfigureHttpPipeline();
app.MapAppEndpoints();

Log.Information("SecurityApp API started successfully");

app.Run();

public partial class Program;
