using Microsoft.Extensions.Diagnostics.HealthChecks;
using SecurityApp.API.SecretManagement;

namespace SecurityApp.API.Health;

/// <summary>
/// Readiness health check: verifies the Vault connection is available.
/// Uses the already-authenticated <see cref="IVaultKvReader"/> to avoid
/// re-authenticating on every probe.
/// </summary>
public sealed class VaultHealthCheck(IVaultKvReader vaultKvReader) : IHealthCheck
{
    public Task<HealthCheckResult> CheckHealthAsync(
        HealthCheckContext context,
        CancellationToken cancellationToken = default)
    {
        try
        {
            return Task.FromResult(vaultKvReader.IsAvailable()
                ? HealthCheckResult.Healthy("Vault reachable")
                : HealthCheckResult.Unhealthy("Vault client not available"));
        }
        catch (Exception ex)
        {
            return Task.FromResult(HealthCheckResult.Unhealthy("Vault unreachable", ex));
        }
    }
}
