using Mediator;
using SecurityApp.Application.GoldenSource.DTOs;
using SecurityApp.Application.GoldenSource.Queries;
using SecurityApp.Core.GoldenSource;

namespace SecurityApp.Application.GoldenSource.Handlers;

public class GetSecurityLineageHandler(IDataLineageRepository repo)
    : IQueryHandler<GetSecurityLineageQuery, SecurityLineageDto?>
{
    public async ValueTask<SecurityLineageDto?> Handle(
        GetSecurityLineageQuery query,
        CancellationToken cancellationToken)
    {
        var events = await repo.GetBySecurityIdAsync(query.SecurityId, cancellationToken);

        if (events.Count == 0)
            return null;

        // Load vendor display details we already have on the events
        var history = events
            .Select(e => new LineageEventDto(
                e.Id,
                e.SecurityId,
                e.FieldName,
                e.FieldValue,
                e.SourceType,
                e.VendorSourceId,
                null,    // VendorCode — enriched below if needed (joins not required for MVP)
                null,    // VendorDisplayName
                e.FeedBatchId,
                e.ResolutionRule,
                e.RunnerUpVendorId,
                null,    // RunnerUpVendorCode
                e.RunnerUpValue,
                e.OverrideUserId,
                e.OverrideReason,
                e.ResolvedAt,
                e.CreatedAt))
            .ToList();

        // Latest event per field for the summary
        var fieldSummaries = events
            .GroupBy(e => e.FieldName, StringComparer.OrdinalIgnoreCase)
            .Select(g =>
            {
                var latest = g.OrderByDescending(e => e.ResolvedAt).First();
                return new LineageSummaryDto(
                    FieldName:       latest.FieldName,
                    CurrentValue:    latest.FieldValue,
                    CurrentVendorCode: null,   // vendor code join not needed for MVP read
                    SourceType:      latest.SourceType,
                    ResolutionRule:  latest.ResolutionRule,
                    LastResolvedAt:  latest.ResolvedAt,
                    EventCount:      g.Count());
            })
            .OrderBy(s => s.FieldName)
            .ToList();

        return new SecurityLineageDto(query.SecurityId, fieldSummaries, history);
    }
}
