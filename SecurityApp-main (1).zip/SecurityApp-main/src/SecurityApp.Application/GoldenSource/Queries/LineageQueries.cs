using Mediator;
using SecurityApp.Application.GoldenSource.DTOs;

namespace SecurityApp.Application.GoldenSource.Queries;

/// <summary>
/// Returns the full lineage history for a security.
/// </summary>
public record GetSecurityLineageQuery(Guid SecurityId) : IQuery<SecurityLineageDto?>;
