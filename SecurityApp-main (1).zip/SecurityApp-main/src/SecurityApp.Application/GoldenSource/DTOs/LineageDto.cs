namespace SecurityApp.Application.GoldenSource.DTOs;

/// <summary>
/// Read model returned by <c>GET /api/securities/{id}/lineage</c>.
/// </summary>
public record LineageEventDto(
    Guid     Id,
    Guid     SecurityId,
    string   FieldName,
    string?  FieldValue,
    string   SourceType,
    Guid?    VendorSourceId,
    string?  VendorCode,
    string?  VendorDisplayName,
    string?  FeedBatchId,
    string?  ResolutionRule,
    Guid?    RunnerUpVendorId,
    string?  RunnerUpVendorCode,
    string?  RunnerUpValue,
    string?  OverrideUserId,
    string?  OverrideReason,
    DateTime ResolvedAt,
    DateTime CreatedAt
);

/// <summary>
/// Groups lineage events by field for the summary view.
/// </summary>
public record LineageSummaryDto(
    string          FieldName,
    string?         CurrentValue,
    string?         CurrentVendorCode,
    string          SourceType,
    string?         ResolutionRule,
    DateTime        LastResolvedAt,
    int             EventCount
);

/// <summary>
/// Full lineage response for a security.
/// </summary>
public record SecurityLineageDto(
    Guid                      SecurityId,
    IReadOnlyList<LineageSummaryDto>  FieldSummaries,
    IReadOnlyList<LineageEventDto>    History
);
