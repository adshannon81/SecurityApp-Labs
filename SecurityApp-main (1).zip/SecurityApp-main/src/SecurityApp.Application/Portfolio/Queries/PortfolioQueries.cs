using Mediator;
using SecurityApp.Application.Portfolio.DTOs;
using SecurityApp.Application.Shared;

namespace SecurityApp.Application.Portfolio.Queries;

public record GetAllClientsQuery(int Page = 1, int PageSize = 50)
    : IQuery<PagedResult<ClientDto>>;

public record GetClientByIdQuery(Guid ClientId)
    : IQuery<ClientDto?>;

public record GetAllPortfoliosQuery(Guid? ClientId = null, int Page = 1, int PageSize = 50)
    : IQuery<PagedResult<PortfolioDto>>;

public record GetPortfolioByIdQuery(Guid PortfolioId)
    : IQuery<PortfolioDto?>;

public record GetAllPositionsQuery(
    Guid? PortfolioId = null,
    Guid? SecurityId  = null,
    DateOnly? AsOfDate = null,
    bool CurrentOnly  = true,
    int Page = 1,
    int PageSize = 50)
    : IQuery<PagedResult<PositionDto>>;

public record GetPositionByIdQuery(Guid PositionId)
    : IQuery<PositionDto?>;
