using Mediator;
using SecurityApp.Application.Portfolio.DTOs;
using SecurityApp.Application.Portfolio.Queries;
using SecurityApp.Application.Shared;
using SecurityApp.Core.Portfolio.Entities;
using SecurityApp.Core.Portfolio.Interfaces;
using SecurityApp.Core.Securities.Entities;
using SecurityApp.Core.Users;

namespace SecurityApp.Application.Portfolio.Handlers;

public class GetAllClientsHandler(IPortfolioUoW uow, IUserCacheService userCache)
    : IQueryHandler<GetAllClientsQuery, PagedResult<ClientDto>>
{
    public async ValueTask<PagedResult<ClientDto>> Handle(GetAllClientsQuery query, CancellationToken ct)
    {
        var (items, total) = await uow.Clients.GetPagedAsync(
            predicate:  null,
            orderBy:    c => c.Name,
            descending: false,
            page:       query.Page,
            pageSize:   query.PageSize,
            ct);

        var clientIds = items.Select(c => c.Id).ToHashSet();
        var allPortfolios = await uow.Portfolios.FindAsync(p => clientIds.Contains(p.ClientId), ct);
        var portfolioCountByClient = allPortfolios.GroupBy(p => p.ClientId)
            .ToDictionary(g => g.Key, g => g.Count());

        var allContacts = await uow.ClientContacts.FindAsync(cc => clientIds.Contains(cc.ClientId), ct);
        var contactsByClient = allContacts.GroupBy(cc => cc.ClientId)
            .ToDictionary(g => g.Key, g => g.ToList());

        var dtos = items.Select(c => new ClientDto
        {
            Id             = c.Id,
            Name           = c.Name,
            Code           = c.Code,
            IsActive       = c.IsActive,
            CreatedAt      = c.CreatedAt,
            CreatedBy      = userCache.ResolveDisplayName(c.CreatedBy),
            LastModifiedAt = c.LastModifiedAt,
            LastModifiedBy = userCache.ResolveDisplayName(c.LastModifiedBy),
            PortfolioCount = portfolioCountByClient.GetValueOrDefault(c.Id),
            Contacts       = contactsByClient.GetValueOrDefault(c.Id, new())
                                .Select(cc => new ClientContactDto
                                {
                                    Id             = cc.Id,
                                    ContactName    = cc.ContactName,
                                    Role           = cc.Role,
                                    Email          = cc.Email,
                                    Phone          = cc.Phone,
                                    IsPrimary      = cc.IsPrimary,
                                    IsActive       = cc.IsActive,
                                    CreatedAt      = cc.CreatedAt,
                                    CreatedBy      = userCache.ResolveDisplayName(cc.CreatedBy),
                                    LastModifiedAt = cc.LastModifiedAt,
                                    LastModifiedBy = userCache.ResolveDisplayName(cc.LastModifiedBy),
                                }).ToList()
        }).ToList();

        return new PagedResult<ClientDto>(dtos, total, query.Page, query.PageSize);
    }
}

public class GetClientByIdHandler(IPortfolioUoW uow, IUserCacheService userCache)
    : IQueryHandler<GetClientByIdQuery, ClientDto?>
{
    public async ValueTask<ClientDto?> Handle(GetClientByIdQuery query, CancellationToken ct)
    {
        var client = await uow.Clients.GetByIdAsync(query.ClientId, ct);
        if (client is null) return null;
        var portfolios = await uow.Portfolios.FindAsync(p => p.ClientId == client.Id, ct);
        var contacts   = await uow.ClientContacts.FindAsync(cc => cc.ClientId == client.Id, ct);
        return new ClientDto
        {
            Id             = client.Id,
            Name           = client.Name,
            Code           = client.Code,
            IsActive       = client.IsActive,
            CreatedAt      = client.CreatedAt,
            CreatedBy      = userCache.ResolveDisplayName(client.CreatedBy),
            LastModifiedAt = client.LastModifiedAt,
            LastModifiedBy = userCache.ResolveDisplayName(client.LastModifiedBy),
            PortfolioCount = portfolios.Count(),
            Contacts       = contacts.Select(cc => new ClientContactDto
            {
                Id             = cc.Id,
                ContactName    = cc.ContactName,
                Role           = cc.Role,
                Email          = cc.Email,
                Phone          = cc.Phone,
                IsPrimary      = cc.IsPrimary,
                IsActive       = cc.IsActive,
                CreatedAt      = cc.CreatedAt,
                CreatedBy      = userCache.ResolveDisplayName(cc.CreatedBy),
                LastModifiedAt = cc.LastModifiedAt,
                LastModifiedBy = userCache.ResolveDisplayName(cc.LastModifiedBy),
            }).ToList()
        };
    }
}

public class GetAllPortfoliosHandler(IPortfolioUoW uow, IUserCacheService userCache)
    : IQueryHandler<GetAllPortfoliosQuery, PagedResult<PortfolioDto>>
{
    public async ValueTask<PagedResult<PortfolioDto>> Handle(GetAllPortfoliosQuery query, CancellationToken ct)
    {
        var (items, total) = await uow.Portfolios.GetPagedAsync(
            predicate:  query.ClientId.HasValue ? p => p.ClientId == query.ClientId.Value : null,
            orderBy:    p => p.Name,
            descending: false,
            page:       query.Page,
            pageSize:   query.PageSize,
            ct);

        var portfolioIds = items.Select(p => p.Id).ToHashSet();
        var clientIds    = items.Select(p => p.ClientId).ToHashSet();

        var positions = await uow.Positions.FindAsync(p => portfolioIds.Contains(p.PortfolioId), ct);
        var posCountByPortfolio = positions.GroupBy(p => p.PortfolioId)
            .ToDictionary(g => g.Key, g => g.Count());

        var clients = await uow.Clients.FindAsync(c => clientIds.Contains(c.Id), ct);
        var clientById = clients.ToDictionary(c => c.Id);

        var dtos = items.Select(p =>
        {
            clientById.TryGetValue(p.ClientId, out var client);
            return new PortfolioDto
            {
                Id             = p.Id,
                ClientId       = p.ClientId,
                ClientName     = client?.Name ?? string.Empty,
                ClientCode     = client?.Code ?? string.Empty,
                Name           = p.Name,
                Code           = p.Code,
                Currency       = p.Currency,
                IsActive       = p.IsActive,
                CreatedAt      = p.CreatedAt,
                CreatedBy      = userCache.ResolveDisplayName(p.CreatedBy),
                LastModifiedAt = p.LastModifiedAt,
                LastModifiedBy = userCache.ResolveDisplayName(p.LastModifiedBy),
                PositionCount  = posCountByPortfolio.GetValueOrDefault(p.Id)
            };
        }).ToList();

        return new PagedResult<PortfolioDto>(dtos, total, query.Page, query.PageSize);
    }
}

public class GetPortfolioByIdHandler(IPortfolioUoW uow, IUserCacheService userCache)
    : IQueryHandler<GetPortfolioByIdQuery, PortfolioDto?>
{
    public async ValueTask<PortfolioDto?> Handle(GetPortfolioByIdQuery query, CancellationToken ct)
    {
        var portfolio = await uow.Portfolios.GetByIdAsync(query.PortfolioId, ct);
        if (portfolio is null) return null;
        var client    = await uow.Clients.GetByIdAsync(portfolio.ClientId, ct);
        var positions = await uow.Positions.FindAsync(p => p.PortfolioId == portfolio.Id, ct);
        return new PortfolioDto
        {
            Id             = portfolio.Id,
            ClientId       = portfolio.ClientId,
            ClientName     = client?.Name ?? string.Empty,
            ClientCode     = client?.Code ?? string.Empty,
            Name           = portfolio.Name,
            Code           = portfolio.Code,
            Currency       = portfolio.Currency,
            IsActive       = portfolio.IsActive,
            CreatedAt      = portfolio.CreatedAt,
            CreatedBy      = userCache.ResolveDisplayName(portfolio.CreatedBy),
            LastModifiedAt = portfolio.LastModifiedAt,
            LastModifiedBy = userCache.ResolveDisplayName(portfolio.LastModifiedBy),
            PositionCount  = positions.Count()
        };
    }
}

public class GetAllPositionsHandler(IPortfolioUoW uow)
    : IQueryHandler<GetAllPositionsQuery, PagedResult<PositionDto>>
{
    public async ValueTask<PagedResult<PositionDto>> Handle(GetAllPositionsQuery query, CancellationToken ct)
    {
        var (items, total) = await uow.Positions.GetPagedAsync(
            predicate: p =>
                (!query.PortfolioId.HasValue || p.PortfolioId == query.PortfolioId.Value) &&
                (!query.SecurityId.HasValue  || p.SecurityId  == query.SecurityId.Value)  &&
                (!query.AsOfDate.HasValue    || p.AsOfDate    == query.AsOfDate.Value),
            orderBy:    p => p.AsOfDate,
            descending: true,
            page:       query.Page,
            pageSize:   query.PageSize,
            ct);

        var portfolioIds = items.Select(p => p.PortfolioId).ToHashSet();
        var securityIds  = items.Select(p => p.SecurityId).ToHashSet();

        var portfolios    = await uow.Portfolios.FindAsync(p => portfolioIds.Contains(p.Id), ct);
        var portfolioById = portfolios.ToDictionary(p => p.Id);

        var clientIds  = portfolios.Select(p => p.ClientId).ToHashSet();
        var clients    = await uow.Clients.FindAsync(c => clientIds.Contains(c.Id), ct);
        var clientById = clients.ToDictionary(c => c.Id);

        var securities   = await uow.Securities.FindAsync(s => securityIds.Contains(s.Id), ct);
        var securityById = securities.ToDictionary(s => s.Id);

        var allIdentifiers   = await uow.SecurityIdentifiers.FindAsync(
            si => securityIds.Contains(si.SecurityId) && si.IsCurrent && !si.IsDeleted, ct);
        var identifiersBySecId = allIdentifiers
            .GroupBy(si => si.SecurityId)
            .ToDictionary(g => g.Key, g => g.FirstOrDefault(i => i.IsPrimary) ?? g.First());

        var dtos = items.Select(pos =>
        {
            portfolioById.TryGetValue(pos.PortfolioId, out var portfolio);
            securityById.TryGetValue(pos.SecurityId,   out var security);
            clientById.TryGetValue(portfolio?.ClientId ?? Guid.Empty, out var client);
            identifiersBySecId.TryGetValue(pos.SecurityId, out var primaryId);
            return new PositionDto
            {
                Id              = pos.Id,
                PortfolioId     = pos.PortfolioId,
                PortfolioName   = portfolio?.Name   ?? string.Empty,
                PortfolioCode   = portfolio?.Code   ?? string.Empty,
                ClientId        = client?.Id        ?? Guid.Empty,
                ClientName      = client?.Name      ?? string.Empty,
                SecurityId      = pos.SecurityId,
                SecurityName    = security?.Name    ?? string.Empty,
                SecurityType    = security?.Type.ToString() ?? string.Empty,
                IdentifierType  = primaryId?.IdentifierType  ?? string.Empty,
                IdentifierValue = primaryId?.IdentifierValue ?? string.Empty,
                AsOfDate        = pos.AsOfDate,
                Quantity        = pos.Quantity,
                MarketValue     = pos.MarketValue,
                BookValue       = pos.BookValue,
                CurrencyCode    = pos.CurrencyCode,
                SourceSystem    = pos.SourceSystem,
                ValidFrom       = pos.ValidFrom,
                ValidTo         = pos.ValidTo,
                IsCurrent       = pos.IsCurrent,
                CreatedAt       = pos.CreatedAt
            };
        }).ToList();

        return new PagedResult<PositionDto>(dtos, total, query.Page, query.PageSize);
    }
}

public class GetPositionByIdHandler(IPortfolioUoW uow)
    : IQueryHandler<GetPositionByIdQuery, PositionDto?>
{
    public async ValueTask<PositionDto?> Handle(GetPositionByIdQuery query, CancellationToken ct)
    {
        var pos = await uow.Positions.GetByIdAsync(query.PositionId, ct);
        if (pos is null) return null;
        var portfolio = await uow.Portfolios.GetByIdAsync(pos.PortfolioId, ct);
        var security  = await uow.Securities.GetByIdAsync(pos.SecurityId, ct);
        var client    = portfolio is not null ? await uow.Clients.GetByIdAsync(portfolio.ClientId, ct) : null;
        var identifiers = await uow.SecurityIdentifiers.FindAsync(
            si => si.SecurityId == pos.SecurityId && si.IsCurrent && !si.IsDeleted, ct);
        var primaryId = identifiers.FirstOrDefault(i => i.IsPrimary) ?? identifiers.FirstOrDefault();
        return new PositionDto
        {
            Id              = pos.Id,
            PortfolioId     = pos.PortfolioId,
            PortfolioName   = portfolio?.Name   ?? string.Empty,
            PortfolioCode   = portfolio?.Code   ?? string.Empty,
            ClientId        = client?.Id        ?? Guid.Empty,
            ClientName      = client?.Name      ?? string.Empty,
            SecurityId      = pos.SecurityId,
            SecurityName    = security?.Name    ?? string.Empty,
            SecurityType    = security?.Type.ToString() ?? string.Empty,
            IdentifierType  = primaryId?.IdentifierType  ?? string.Empty,
            IdentifierValue = primaryId?.IdentifierValue ?? string.Empty,
            AsOfDate        = pos.AsOfDate,
            Quantity        = pos.Quantity,
            MarketValue     = pos.MarketValue,
            BookValue       = pos.BookValue,
            CurrencyCode    = pos.CurrencyCode,
            SourceSystem    = pos.SourceSystem,
            ValidFrom       = pos.ValidFrom,
            ValidTo         = pos.ValidTo,
            IsCurrent       = pos.IsCurrent,
            CreatedAt       = pos.CreatedAt
        };
    }
}
