using Mediator;
using SecurityApp.Application.Portfolio.Commands;
using SecurityApp.Application.Portfolio.DTOs;
using SecurityApp.Core.Grpc;
using SecurityApp.Core.Portfolio.Entities;
using SecurityApp.Core.Portfolio.Interfaces;
using SecurityApp.Core.Securities.Entities;
using SecurityApp.Core.Shared.Exceptions;
using PortfolioEntity = SecurityApp.Core.Portfolio.Entities.Portfolio;

namespace SecurityApp.Application.Portfolio.Handlers;

public class CreateClientHandler(IPortfolioUoW uow, IGrpcEventPublisher grpc)
    : ICommandHandler<CreateClientCommand, ClientDto>
{
    public async ValueTask<ClientDto> Handle(CreateClientCommand command, CancellationToken ct)
    {
        var req = command.Request;
        var client = new Client
        {
            Name           = req.Name,
            Code           = req.Code.ToUpperInvariant(),
            LastModifiedBy = command.UserId
        };
        await uow.Clients.AddAsync(client, ct);
        await uow.SaveChangesAsync(ct);
        await grpc.PublishRefDataChangedAsync(new RefDataChangedPayload("Client", req.Name), ct);
        return PortfolioMappers.MapClient(client, 0);
    }
}

public class UpdateClientHandler(IPortfolioUoW uow, IGrpcEventPublisher grpc)
    : ICommandHandler<UpdateClientCommand, ClientDto>
{
    public async ValueTask<ClientDto> Handle(UpdateClientCommand command, CancellationToken ct)
    {
        var client = await uow.Clients.GetByIdAsync(command.ClientId, ct)
            ?? throw new NotFoundException($"Client {command.ClientId} not found.");
        var req = command.Request;
        client.Name           = req.Name;
        client.IsActive       = req.IsActive;
        client.LastModifiedAt  = DateTime.UtcNow;
        client.LastModifiedBy  = command.UserId;
        await uow.Clients.UpdateAsync(client, ct);
        await uow.SaveChangesAsync(ct);
        await grpc.PublishRefDataChangedAsync(new RefDataChangedPayload("Client", req.Name), ct);
        var portfolioCount = (await uow.Portfolios.FindAsync(p => p.ClientId == client.Id, ct)).Count();
        return PortfolioMappers.MapClient(client, portfolioCount);
    }
}

public class DeleteClientHandler(IPortfolioUoW uow, IGrpcEventPublisher grpc)
    : ICommandHandler<DeleteClientCommand>
{
    public async ValueTask<Unit> Handle(DeleteClientCommand command, CancellationToken ct)
    {
        var client = await uow.Clients.GetByIdAsync(command.ClientId, ct)
            ?? throw new NotFoundException($"Client {command.ClientId} not found.");
        var hasPortfolios = (await uow.Portfolios.FindAsync(p => p.ClientId == client.Id, ct)).Any();
        if (hasPortfolios)
            throw new InvalidOperationException("Cannot delete a client that has portfolios. Remove portfolios first.");
        await uow.Clients.DeleteAsync(command.ClientId, ct);
        await uow.SaveChangesAsync(ct);
        await grpc.PublishRefDataChangedAsync(new RefDataChangedPayload("Client", string.Empty), ct);
        return Unit.Value;
    }
}

// ── Client Contacts ───────────────────────────────────────────────────────────

public class AddClientContactHandler(IPortfolioUoW uow)
    : ICommandHandler<AddClientContactCommand, ClientContactDto>
{
    public async ValueTask<ClientContactDto> Handle(AddClientContactCommand command, CancellationToken ct)
    {
        _ = await uow.Clients.GetByIdAsync(command.ClientId, ct)
            ?? throw new NotFoundException($"Client {command.ClientId} not found.");
        var req = command.Request;
        var contact = new ClientContact
        {
            ClientId       = command.ClientId,
            ContactName    = req.ContactName,
            Role           = req.Role,
            Email          = req.Email,
            Phone          = req.Phone,
            IsPrimary      = req.IsPrimary,
            IsActive       = true,
            LastModifiedBy = command.UserId
        };
        await uow.ClientContacts.AddAsync(contact, ct);
        await uow.SaveChangesAsync(ct);
        return PortfolioMappers.MapContact(contact);
    }
}

public class UpdateClientContactHandler(IPortfolioUoW uow)
    : ICommandHandler<UpdateClientContactCommand, ClientContactDto>
{
    public async ValueTask<ClientContactDto> Handle(UpdateClientContactCommand command, CancellationToken ct)
    {
        var contact = await uow.ClientContacts.GetByIdAsync(command.ContactId, ct)
            ?? throw new NotFoundException($"Contact {command.ContactId} not found.");
        var req = command.Request;
        contact.ContactName    = req.ContactName;
        contact.Role           = req.Role;
        contact.Email          = req.Email;
        contact.Phone          = req.Phone;
        contact.IsPrimary      = req.IsPrimary;
        contact.IsActive       = req.IsActive;
        contact.LastModifiedAt = DateTime.UtcNow;
        contact.LastModifiedBy = command.UserId;
        await uow.ClientContacts.UpdateAsync(contact, ct);
        await uow.SaveChangesAsync(ct);
        return PortfolioMappers.MapContact(contact);
    }
}

public class RemoveClientContactHandler(IPortfolioUoW uow)
    : ICommandHandler<RemoveClientContactCommand>
{
    public async ValueTask<Unit> Handle(RemoveClientContactCommand command, CancellationToken ct)
    {
        _ = await uow.ClientContacts.GetByIdAsync(command.ContactId, ct)
            ?? throw new NotFoundException($"Contact {command.ContactId} not found.");
        await uow.ClientContacts.DeleteAsync(command.ContactId, ct);
        await uow.SaveChangesAsync(ct);
        return Unit.Value;
    }
}

// ── Portfolio ──────────────────────────────────────────────────────────────────

public class CreatePortfolioHandler(IPortfolioUoW uow, IGrpcEventPublisher grpc)
    : ICommandHandler<CreatePortfolioCommand, PortfolioDto>
{
    public async ValueTask<PortfolioDto> Handle(CreatePortfolioCommand command, CancellationToken ct)
    {
        var req = command.Request;
        var client = await uow.Clients.GetByIdAsync(req.ClientId, ct)
            ?? throw new NotFoundException($"Client {req.ClientId} not found.");
        var portfolio = new PortfolioEntity
        {
            ClientId       = req.ClientId,
            Name           = req.Name,
            Code           = req.Code.ToUpperInvariant(),
            Currency       = req.Currency,
            LastModifiedBy = command.UserId
        };
        await uow.Portfolios.AddAsync(portfolio, ct);
        await uow.SaveChangesAsync(ct);
        await grpc.PublishRefDataChangedAsync(new RefDataChangedPayload("Portfolio", req.Name), ct);
        return PortfolioMappers.MapPortfolio(portfolio, client.Name, client.Code, 0);
    }
}

public class UpdatePortfolioHandler(IPortfolioUoW uow, IGrpcEventPublisher grpc)
    : ICommandHandler<UpdatePortfolioCommand, PortfolioDto>
{
    public async ValueTask<PortfolioDto> Handle(UpdatePortfolioCommand command, CancellationToken ct)
    {
        var portfolio = await uow.Portfolios.GetByIdAsync(command.PortfolioId, ct)
            ?? throw new NotFoundException($"Portfolio {command.PortfolioId} not found.");
        var client = await uow.Clients.GetByIdAsync(portfolio.ClientId, ct)
            ?? throw new NotFoundException($"Client {portfolio.ClientId} not found.");
        var req = command.Request;
        portfolio.Name           = req.Name;
        portfolio.Currency        = req.Currency;
        portfolio.IsActive        = req.IsActive;
        portfolio.LastModifiedAt  = DateTime.UtcNow;
        portfolio.LastModifiedBy  = command.UserId;
        await uow.Portfolios.UpdateAsync(portfolio, ct);
        await uow.SaveChangesAsync(ct);
        await grpc.PublishRefDataChangedAsync(new RefDataChangedPayload("Portfolio", req.Name), ct);
        var posCount = (await uow.Positions.FindAsync(p => p.PortfolioId == portfolio.Id, ct)).Count();
        return PortfolioMappers.MapPortfolio(portfolio, client.Name, client.Code, posCount);
    }
}

public class DeletePortfolioHandler(IPortfolioUoW uow, IGrpcEventPublisher grpc)
    : ICommandHandler<DeletePortfolioCommand>
{
    public async ValueTask<Unit> Handle(DeletePortfolioCommand command, CancellationToken ct)
    {
        var portfolio = await uow.Portfolios.GetByIdAsync(command.PortfolioId, ct)
            ?? throw new NotFoundException($"Portfolio {command.PortfolioId} not found.");
        var hasPositions = (await uow.Positions.FindAsync(p => p.PortfolioId == portfolio.Id, ct)).Any();
        if (hasPositions)
            throw new InvalidOperationException("Cannot delete a portfolio that has positions. Close positions first.");
        await uow.Portfolios.DeleteAsync(command.PortfolioId, ct);
        await uow.SaveChangesAsync(ct);
        await grpc.PublishRefDataChangedAsync(new RefDataChangedPayload("Portfolio", string.Empty), ct);
        return Unit.Value;
    }
}

// ── Position ───────────────────────────────────────────────────────────────────

public class CreatePositionHandler(IPortfolioUoW uow)
    : ICommandHandler<CreatePositionCommand, PositionDto>
{
    public async ValueTask<PositionDto> Handle(CreatePositionCommand command, CancellationToken ct)
    {
        var req = command.Request;

        var portfolio = await uow.Portfolios.GetByIdAsync(req.PortfolioId, ct)
            ?? throw new NotFoundException($"Portfolio {req.PortfolioId} not found.");
        var security  = await uow.Securities.GetByIdAsync(req.SecurityId, ct)
            ?? throw new NotFoundException($"Security {req.SecurityId} not found.");
        var client    = await uow.Clients.GetByIdAsync(portfolio.ClientId, ct)
            ?? throw new NotFoundException($"Client {portfolio.ClientId} not found.");

        var position = new Position
        {
            PortfolioId  = req.PortfolioId,
            SecurityId   = req.SecurityId,
            AsOfDate     = req.AsOfDate,
            Quantity     = req.Quantity,
            MarketValue  = req.MarketValue,
            BookValue    = req.BookValue,
            CurrencyCode = req.CurrencyCode,
            SourceSystem = req.SourceSystem
        };
        await uow.Positions.AddAsync(position, ct);

        // Update denormalised flag on Security
        if (!security.HasOpenPosition && req.Quantity != 0m)
        {
            security.HasOpenPosition = true;
            security.LastModifiedAt = DateTime.UtcNow;
            await uow.Securities.UpdateAsync(security, ct);
        }

        await uow.SaveChangesAsync(ct);
        var identifiers = await uow.SecurityIdentifiers.FindAsync(
            si => si.SecurityId == security.Id && si.IsCurrent && !si.IsDeleted, ct);
        var primaryId = identifiers.FirstOrDefault(i => i.IsPrimary) ?? identifiers.FirstOrDefault();
        return PortfolioMappers.MapPosition(position, portfolio, client, security, primaryId);
    }
}

public class UpdatePositionHandler(IPortfolioUoW uow)
    : ICommandHandler<UpdatePositionCommand, PositionDto>
{
    public async ValueTask<PositionDto> Handle(UpdatePositionCommand command, CancellationToken ct)
    {
        var position = await uow.Positions.GetByIdAsync(command.PositionId, ct)
            ?? throw new NotFoundException($"Position {command.PositionId} not found.");

        var portfolio = await uow.Portfolios.GetByIdAsync(position.PortfolioId, ct)!;
        var security  = await uow.Securities.GetByIdAsync(position.SecurityId,  ct)!;
        var client    = await uow.Clients.GetByIdAsync(portfolio!.ClientId, ct)!;

        var req = command.Request;
        position.Quantity     = req.Quantity;
        position.MarketValue  = req.MarketValue;
        position.BookValue    = req.BookValue;
        position.CurrencyCode = req.CurrencyCode;
        position.SourceSystem = req.SourceSystem;
        position.LastModifiedAt    = DateTime.UtcNow;
        await uow.Positions.UpdateAsync(position, ct);

        // Refresh HasOpenPosition in case quantity changed to/from zero
        await RefreshHasOpenPositionAsync(security!, position.Id, ct);

        await uow.SaveChangesAsync(ct);
        var identifiers2 = await uow.SecurityIdentifiers.FindAsync(
            si => si.SecurityId == security!.Id && si.IsCurrent && !si.IsDeleted, ct);
        var primaryId2 = identifiers2.FirstOrDefault(i => i.IsPrimary) ?? identifiers2.FirstOrDefault();
        return PortfolioMappers.MapPosition(position, portfolio!, client!, security!, primaryId2);
    }

    private async Task RefreshHasOpenPositionAsync(
        SecurityApp.Core.Securities.Entities.Security security,
        Guid excludePositionId,
        CancellationToken ct)
    {
        var hasOpen = (await uow.Positions.FindAsync(
            p => p.SecurityId == security.Id
              && p.Quantity    != 0m
              && p.Id          != excludePositionId, ct)).Any();

        if (security.HasOpenPosition != hasOpen)
        {
            security.HasOpenPosition = hasOpen;
            security.LastModifiedAt = DateTime.UtcNow;
            await uow.Securities.UpdateAsync(security, ct);
        }
    }
}

public class DeletePositionHandler(IPortfolioUoW uow)
    : ICommandHandler<DeletePositionCommand>
{
    public async ValueTask<Unit> Handle(DeletePositionCommand command, CancellationToken ct)
    {
        var position = await uow.Positions.GetByIdAsync(command.PositionId, ct)
            ?? throw new NotFoundException($"Position {command.PositionId} not found.");
        var security = await uow.Securities.GetByIdAsync(position.SecurityId, ct);

        await uow.Positions.DeleteAsync(command.PositionId, ct);

        // Recompute HasOpenPosition after deletion
        if (security is not null && position.Quantity != 0m)
        {
            var otherOpen = (await uow.Positions.FindAsync(
                p => p.SecurityId == security.Id
                  && p.Quantity   != 0m
                  && p.Id         != command.PositionId, ct)).Any();

            if (!otherOpen && security.HasOpenPosition)
            {
                security.HasOpenPosition = false;
                security.LastModifiedAt = DateTime.UtcNow;
                await uow.Securities.UpdateAsync(security, ct);
            }
        }

        await uow.SaveChangesAsync(ct);
        return Unit.Value;
    }
}

// ── Mapping helpers ────────────────────────────────────────────────────────────

file static class PortfolioMappers
{
    internal static DTOs.ClientDto MapClient(Client c, int portfolioCount, Func<string?, string>? resolver = null, IEnumerable<ClientContact>? contacts = null) => new()
    {
        Id             = c.Id,
        Name           = c.Name,
        Code           = c.Code,
        IsActive       = c.IsActive,
        CreatedAt      = c.CreatedAt,
        CreatedBy      = resolver != null ? resolver(c.CreatedBy) : c.CreatedBy,
        LastModifiedAt = c.LastModifiedAt,
        LastModifiedBy = resolver != null ? resolver(c.LastModifiedBy) : c.LastModifiedBy,
        PortfolioCount = portfolioCount,
        Contacts       = (contacts ?? c.Contacts).Select(cc => MapContact(cc, resolver)).ToList()
    };

    internal static DTOs.ClientContactDto MapContact(ClientContact cc, Func<string?, string>? resolver = null) => new()
    {
        Id             = cc.Id,
        ContactName    = cc.ContactName,
        Role           = cc.Role,
        Email          = cc.Email,
        Phone          = cc.Phone,
        IsPrimary      = cc.IsPrimary,
        IsActive       = cc.IsActive,
        CreatedAt      = cc.CreatedAt,
        CreatedBy      = resolver != null ? resolver(cc.CreatedBy) : cc.CreatedBy,
        LastModifiedAt = cc.LastModifiedAt,
        LastModifiedBy = resolver != null ? resolver(cc.LastModifiedBy) : cc.LastModifiedBy,
    };

    internal static DTOs.PortfolioDto MapPortfolio(PortfolioEntity p, string clientName, string clientCode, int positionCount, Func<string?, string>? resolver = null) => new()
    {
        Id             = p.Id,
        ClientId       = p.ClientId,
        ClientName     = clientName,
        ClientCode     = clientCode,
        Name           = p.Name,
        Code           = p.Code,
        Currency       = p.Currency,
        IsActive       = p.IsActive,
        CreatedAt      = p.CreatedAt,
        CreatedBy      = resolver != null ? resolver(p.CreatedBy) : p.CreatedBy,
        LastModifiedAt = p.LastModifiedAt,
        LastModifiedBy = resolver != null ? resolver(p.LastModifiedBy) : p.LastModifiedBy,
        PositionCount  = positionCount
    };

    internal static DTOs.PositionDto MapPosition(
        Position pos,
        PortfolioEntity portfolio,
        Client client,
        SecurityApp.Core.Securities.Entities.Security security,
        SecurityIdentifier? primaryId = null) => new()
    {
        Id              = pos.Id,
        PortfolioId     = pos.PortfolioId,
        PortfolioName   = portfolio.Name,
        PortfolioCode   = portfolio.Code,
        ClientId        = client.Id,
        ClientName      = client.Name,
        SecurityId      = pos.SecurityId,
        SecurityName    = security.Name,
        SecurityType    = security.Type.ToString(),
        IdentifierType  = primaryId?.IdentifierType  ?? string.Empty,
        IdentifierValue = primaryId?.IdentifierValue ?? string.Empty,
        AsOfDate        = pos.AsOfDate,
        Quantity        = pos.Quantity,
        MarketValue     = pos.MarketValue,
        BookValue       = pos.BookValue,
        CurrencyCode    = pos.CurrencyCode,
        SourceSystem    = pos.SourceSystem,
        ValidFrom       = pos.ValidFrom,
        ValidTo         = pos.ValidTo,
        IsCurrent       = pos.IsCurrent,
        CreatedAt       = pos.CreatedAt
    };
}
