namespace SecurityApp.Application.Portfolio.DTOs;

public class PortfolioDto
{
    public Guid    Id            { get; set; }
    public Guid    ClientId      { get; set; }
    public string  ClientName    { get; set; } = string.Empty;
    public string  ClientCode    { get; set; } = string.Empty;
    public string  Name          { get; set; } = string.Empty;
    public string  Code          { get; set; } = string.Empty;
    public string  Currency      { get; set; } = string.Empty;
    public bool    IsActive      { get; set; }
    public DateTime  CreatedAt     { get; set; }
    public string?   CreatedBy     { get; set; }
    public DateTime? LastModifiedAt { get; set; }
    public string?   LastModifiedBy { get; set; }
    public int       PositionCount  { get; set; }
}

public class CreatePortfolioRequest
{
    public Guid    ClientId { get; set; }
    public string  Name     { get; set; } = string.Empty;
    public string  Code     { get; set; } = string.Empty;
    public string  Currency { get; set; } = "USD";
}

public class UpdatePortfolioRequest
{
    public string  Name     { get; set; } = string.Empty;
    public string  Currency { get; set; } = "USD";
    public bool    IsActive { get; set; }
}
