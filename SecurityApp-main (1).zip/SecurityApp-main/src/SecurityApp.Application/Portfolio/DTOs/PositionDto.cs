namespace SecurityApp.Application.Portfolio.DTOs;

public class PositionDto
{
    public Guid    Id              { get; set; }
    public Guid    PortfolioId     { get; set; }
    public string  PortfolioName   { get; set; } = string.Empty;
    public string  PortfolioCode   { get; set; } = string.Empty;
    public Guid    ClientId        { get; set; }
    public string  ClientName      { get; set; } = string.Empty;
    public Guid    SecurityId      { get; set; }
    public string  SecurityName    { get; set; } = string.Empty;
    public string  SecurityType    { get; set; } = string.Empty;
    public string  IdentifierType  { get; set; } = string.Empty;
    public string  IdentifierValue { get; set; } = string.Empty;
    public DateOnly AsOfDate       { get; set; }
    public decimal Quantity        { get; set; }
    public decimal? MarketValue    { get; set; }
    public decimal? BookValue      { get; set; }
    public string  CurrencyCode    { get; set; } = string.Empty;
    public string  SourceSystem    { get; set; } = string.Empty;
    public DateTime ValidFrom      { get; set; }
    public DateTime ValidTo        { get; set; }
    public bool    IsCurrent       { get; set; }
    public DateTime CreatedAt      { get; set; }
}

public class CreatePositionRequest
{
    public Guid     PortfolioId  { get; set; }
    public Guid     SecurityId   { get; set; }
    public DateOnly AsOfDate     { get; set; }
    public decimal  Quantity     { get; set; }
    public decimal? MarketValue  { get; set; }
    public decimal? BookValue    { get; set; }
    public string   CurrencyCode { get; set; } = "USD";
    public string   SourceSystem { get; set; } = string.Empty;
}

public class UpdatePositionRequest
{
    public decimal  Quantity     { get; set; }
    public decimal? MarketValue  { get; set; }
    public decimal? BookValue    { get; set; }
    public string   CurrencyCode { get; set; } = "USD";
    public string   SourceSystem { get; set; } = string.Empty;
}


public class ClosePositionRequest
{
    public string? Notes { get; set; }
}
