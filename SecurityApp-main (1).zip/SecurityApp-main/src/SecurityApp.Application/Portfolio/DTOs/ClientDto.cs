namespace SecurityApp.Application.Portfolio.DTOs;

public class ClientContactDto
{
    public Guid    Id          { get; set; }
    public string  ContactName { get; set; } = string.Empty;
    public string? Role        { get; set; }
    public string? Email       { get; set; }
    public string? Phone       { get; set; }
    public bool    IsPrimary   { get; set; }
    public bool    IsActive    { get; set; }
    public DateTime  CreatedAt      { get; set; }
    public string?   CreatedBy      { get; set; }
    public DateTime? LastModifiedAt { get; set; }
    public string?   LastModifiedBy { get; set; }
}

public class CreateClientContactRequest
{
    public string  ContactName { get; set; } = string.Empty;
    public string? Role        { get; set; }
    public string? Email       { get; set; }
    public string? Phone       { get; set; }
    public bool    IsPrimary   { get; set; } = false;
}

public class UpdateClientContactRequest
{
    public string  ContactName { get; set; } = string.Empty;
    public string? Role        { get; set; }
    public string? Email       { get; set; }
    public string? Phone       { get; set; }
    public bool    IsPrimary   { get; set; }
    public bool    IsActive    { get; set; }
}

public class ClientDto
{
    public Guid    Id             { get; set; }
    public string  Name           { get; set; } = string.Empty;
    public string  Code           { get; set; } = string.Empty;
    public bool    IsActive       { get; set; }
    public DateTime  CreatedAt      { get; set; }
    public string?   CreatedBy      { get; set; }
    public DateTime? LastModifiedAt  { get; set; }
    public string?   LastModifiedBy  { get; set; }
    public int       PortfolioCount  { get; set; }
    public List<ClientContactDto> Contacts { get; set; } = new();
}

public class CreateClientRequest
{
    public string  Name { get; set; } = string.Empty;
    public string  Code { get; set; } = string.Empty;
}

public class UpdateClientRequest
{
    public string  Name     { get; set; } = string.Empty;
    public bool    IsActive { get; set; }
}
