using Mediator;
using SecurityApp.Application.Portfolio.DTOs;

namespace SecurityApp.Application.Portfolio.Commands;

public record CreateClientCommand(CreateClientRequest Request, string? UserId = null) : ICommand<ClientDto>;

public record UpdateClientCommand(Guid ClientId, UpdateClientRequest Request, string? UserId = null) : ICommand<ClientDto>;

public record DeleteClientCommand(Guid ClientId) : ICommand;

public record AddClientContactCommand(Guid ClientId, CreateClientContactRequest Request, string? UserId = null) : ICommand<ClientContactDto>;

public record UpdateClientContactCommand(Guid ContactId, UpdateClientContactRequest Request, string? UserId = null) : ICommand<ClientContactDto>;

public record RemoveClientContactCommand(Guid ContactId) : ICommand;

public record CreatePortfolioCommand(CreatePortfolioRequest Request, string? UserId = null) : ICommand<PortfolioDto>;

public record UpdatePortfolioCommand(Guid PortfolioId, UpdatePortfolioRequest Request, string? UserId = null) : ICommand<PortfolioDto>;

public record DeletePortfolioCommand(Guid PortfolioId) : ICommand;

public record CreatePositionCommand(CreatePositionRequest Request) : ICommand<PositionDto>;

public record UpdatePositionCommand(Guid PositionId, UpdatePositionRequest Request) : ICommand<PositionDto>;

public record DeletePositionCommand(Guid PositionId) : ICommand;
