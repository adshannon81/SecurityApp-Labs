using Mediator;
using SecurityApp.Application.Issuers.DTOs;

namespace SecurityApp.Application.Issuers.Commands;

// ── Issuer CRUD ───────────────────────────────────────────────────────────────

public record CreateIssuerCommand(CreateIssuerDto Issuer, string? UserId = null)
    : ICommand<CreateIssuerResponse>;

public record CreateIssuerResponse(Guid IssuerId, string Message);

public record UpdateIssuerCommand(Guid IssuerId, CreateIssuerDto Issuer, string? UserId = null)
    : ICommand;

public record DeleteIssuerCommand(Guid IssuerId)
    : ICommand;

// ── Relationship management ───────────────────────────────────────────────────

public record AddIssuerRelationshipCommand(
    Guid IssuerId,
    CreateIssuerRelationshipDto Relationship,
    string? UserId = null)
    : ICommand<AddIssuerRelationshipResponse>;

public record AddIssuerRelationshipResponse(Guid RelationshipId, string Message);

public record UpdateIssuerRelationshipCommand(
    Guid RelationshipId,
    CreateIssuerRelationshipDto Relationship,
    string? UserId = null)
    : ICommand;

public record DeleteIssuerRelationshipCommand(Guid RelationshipId)
    : ICommand;
