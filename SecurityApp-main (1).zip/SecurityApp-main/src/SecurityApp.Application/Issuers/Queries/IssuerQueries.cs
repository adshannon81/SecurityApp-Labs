using Mediator;
using SecurityApp.Application.Issuers.DTOs;
using SecurityApp.Application.Shared;

namespace SecurityApp.Application.Issuers.Queries;

public record GetIssuerByIdQuery(Guid IssuerId) : IQuery<IssuerDto?>;

public record SearchIssuersQuery(
    string? Search = null,
    string? IssuerType = null,
    string? CountryAlpha2 = null,
    bool? IsActive = null,
    int PageNumber = 1,
    int PageSize = 50) : IQuery<PagedResult<IssuerSummaryDto>>;

/// <summary>Returns all current relationships where the issuer is the child (parent relationships).</summary>
public record GetIssuerRelationshipsQuery(Guid IssuerId) : IQuery<List<IssuerRelationshipDto>>;

/// <summary>Returns all current relationships where the issuer is the parent (child issuers).</summary>
public record GetIssuerChildrenQuery(Guid IssuerId) : IQuery<List<IssuerRelationshipDto>>;
