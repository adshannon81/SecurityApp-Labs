using System.ComponentModel.DataAnnotations;
using SecurityApp.Core.Issuers.Entities;

namespace SecurityApp.Application.Issuers.DTOs;

// â”€â”€ Read DTOs â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

public class IssuerSummaryDto
{
    public Guid    Id            { get; set; }
    public string  LegalName     { get; set; } = string.Empty;
    public string? DisplayName   { get; set; }
    public string? LeiCode       { get; set; }
    public string? CountryAlpha2 { get; set; }
    public string? IssuerType    { get; set; }
    /// <summary>Cached direct accounting parent â€” source of truth is Relationships collection.</summary>
    public IssuerSummaryDto? DirectAccountingParent   { get; set; }
    /// <summary>Cached ultimate accounting parent â€” source of truth is Relationships collection.</summary>
    public IssuerSummaryDto? UltimateAccountingParent { get; set; }
}

public class IssuerDto : IssuerSummaryDto
{
    public string? ShortName { get; set; }
    public bool    IsActive  { get; set; }
    public DateTime  CreatedAt  { get; set; }
    public string?   CreatedBy { get; set; }
    public DateTime? LastModifiedAt  { get; set; }
    public string?   LastModifiedBy { get; set; }
    public string?   ContentHash { get; set; }
    public List<IssuerIdentifierDto>   Identifiers   { get; set; } = new();
    public List<IssuerRelationshipDto> Relationships { get; set; } = new();
    /// <summary>Derived from direct-parent chain when not explicitly stored.</summary>
    public IssuerSummaryDto? DerivedUltimateAccountingParent { get; set; }
}

public class IssuerIdentifierDto
{
    public Guid    Id              { get; set; }
    public string  IdentifierType  { get; set; } = string.Empty;
    public string  IdentifierValue { get; set; } = string.Empty;
    public string? SourceSystem    { get; set; }
    public bool    IsPrimary       { get; set; }
}

public class IssuerRelationshipDto
{
    public Guid     Id               { get; set; }
    public string   RelationshipType { get; set; } = string.Empty;
    public Guid     ParentIssuerId   { get; set; }
    public string   ParentLegalName  { get; set; } = string.Empty;
    public string?  ParentDisplayName { get; set; }
    public decimal? OwnershipPercent { get; set; }
    public string?  ControlBasis     { get; set; }
    public string?  SourceSystem     { get; set; }
    public string?  SourceReference  { get; set; }
    public bool     IsPrimary        { get; set; }
    public string?  Notes            { get; set; }
    public DateTime ValidFrom        { get; set; }
    public DateTime ValidTo          { get; set; }
    public bool     IsCurrent        { get; set; }
}

// â”€â”€ Write DTOs â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

public class CreateIssuerDto
{
    [Required(ErrorMessage = "LegalName is required.")]
    [StringLength(255, MinimumLength = 1)]
    public string LegalName { get; set; } = string.Empty;

    [StringLength(255)]
    public string? DisplayName { get; set; }

    [StringLength(100)]
    public string? ShortName { get; set; }

    [StringLength(20)]
    public string? LeiCode { get; set; }

    [StringLength(50)]
    public string? IssuerType { get; set; }

    [StringLength(2, MinimumLength = 2)]
    public string? CountryAlpha2 { get; set; }

    public bool IsActive { get; set; } = true;

    public List<CreateIssuerIdentifierDto>?   Identifiers   { get; set; }
    public List<CreateIssuerRelationshipDto>? Relationships { get; set; }
}

public class CreateIssuerIdentifierDto
{
    public string  IdentifierType  { get; set; } = string.Empty;
    public string  IdentifierValue { get; set; } = string.Empty;
    public string? SourceSystem    { get; set; }
    public bool    IsPrimary       { get; set; }
}

public class CreateIssuerRelationshipDto
{
    [Required]
    public Guid   ParentIssuerId { get; set; }

    [Required, StringLength(50)]
    public string RelationshipType { get; set; } = string.Empty;

    public decimal? OwnershipPercent { get; set; }

    [StringLength(100)]
    public string? ControlBasis { get; set; }

    [StringLength(50)]
    public string? SourceSystem { get; set; }

    [StringLength(255)]
    public string? SourceReference { get; set; }

    public bool IsPrimary { get; set; }

    [StringLength(1000)]
    public string? Notes { get; set; }

    public DateTimeOffset? ValidFrom { get; set; }
    public DateTimeOffset? ValidTo   { get; set; }
}
