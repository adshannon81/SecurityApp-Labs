using Mediator;
using SecurityApp.Core.Issuers.Entities;
using SecurityApp.Core.Issuers.Interfaces;
using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Core.Users;
using SecurityApp.Application.Issuers.Queries;
using SecurityApp.Application.Issuers.DTOs;
using SecurityApp.Application.Shared;

namespace SecurityApp.Application.Issuers.Handlers;

// -- GetIssuerById -------------------------------------------------------------

public class GetIssuerByIdHandler : IQueryHandler<GetIssuerByIdQuery, IssuerDto?>
{
    private readonly IIssuersUoW _uow;
    private readonly ICacheService _cacheService;
    private readonly IUserCacheService _userCache;

    public GetIssuerByIdHandler(IIssuersUoW uow, ICacheService cacheService, IUserCacheService userCache)
    {
        _uow          = uow;
        _cacheService = cacheService;
        _userCache    = userCache;
    }

    public async ValueTask<IssuerDto?> Handle(GetIssuerByIdQuery query, CancellationToken cancellationToken)
    {
        var key    = $"issuer:{query.IssuerId}";
        var cached = await _cacheService.GetAsync<IssuerDto>(key, cancellationToken);
        if (cached is not null) return cached;

        var issuer = await _uow.Issuers.GetByIdAsync(query.IssuerId, cancellationToken);
        if (issuer is null) return null;

        issuer.Identifiers = (await _uow.IssuerIdentifiers.FindAsync(
            ii => ii.IssuerId == query.IssuerId, cancellationToken)).ToList();

        var relationships = (await _uow.IssuerRelationships.FindAsync(
            r => r.ChildIssuerId == query.IssuerId && r.IsCurrent && !r.IsDeleted,
            cancellationToken)).ToList();

        // Resolve parent names in batch
        var parentIds = relationships.Select(r => r.ParentIssuerId).Distinct().ToList();
        var parents   = new Dictionary<Guid, Issuer>();
        foreach (var pid in parentIds)
        {
            var p = await _uow.Issuers.GetByIdAsync(pid, cancellationToken);
            if (p != null) parents[pid] = p;
        }

        IssuerSummaryDto? directParentDto   = null;
        IssuerSummaryDto? ultimateParentDto  = null;
        IssuerSummaryDto? derivedUltimateDto = null;

        if (issuer.DirectAccountingParentIssuerId.HasValue &&
            parents.TryGetValue(issuer.DirectAccountingParentIssuerId.Value, out var dp))
        {
            directParentDto = IssuerMappings.MapToSummaryDto(dp);
        }

        if (issuer.UltimateAccountingParentIssuerId.HasValue &&
            parents.TryGetValue(issuer.UltimateAccountingParentIssuerId.Value, out var up))
        {
            ultimateParentDto = IssuerMappings.MapToSummaryDto(up);
        }

        // Derived ultimate (from explicit ACCOUNTING_ULTIMATE_PARENT row if present)
        var ultimateRel = relationships.FirstOrDefault(
            r => r.RelationshipType == IssuerRelationshipTypes.AccountingUltimateParent);
        if (ultimateRel != null && parents.TryGetValue(ultimateRel.ParentIssuerId, out var dup))
        {
            derivedUltimateDto = IssuerMappings.MapToSummaryDto(dup);
        }

        var dto = IssuerMappings.MapToDto(
            issuer, relationships, parents, directParentDto, ultimateParentDto, derivedUltimateDto, _userCache.ResolveDisplayName);

        await _cacheService.SetAsync(key, dto, TimeSpan.FromMinutes(5), cancellationToken);
        return dto;
    }
}

// -- SearchIssuers -------------------------------------------------------------

public class SearchIssuersHandler : IQueryHandler<SearchIssuersQuery, PagedResult<IssuerSummaryDto>>
{
    private readonly IIssuersUoW _uow;
    private readonly ICacheService _cacheService;

    public SearchIssuersHandler(IIssuersUoW uow, ICacheService cacheService)
    {
        _uow          = uow;
        _cacheService = cacheService;
    }

    public async ValueTask<PagedResult<IssuerSummaryDto>> Handle(
        SearchIssuersQuery query, CancellationToken cancellationToken)
    {
        var (items, total) = await _uow.Issuers.GetPagedAsync(
            predicate: i =>
                (query.Search       == null || i.LegalName.Contains(query.Search) || (i.DisplayName != null && i.DisplayName.Contains(query.Search)) || (i.LeiCode != null && i.LeiCode.Contains(query.Search))) &&
                (query.IssuerType   == null || i.IssuerType   == query.IssuerType) &&
                (query.CountryAlpha2 == null || i.CountryAlpha2 == query.CountryAlpha2) &&
                (query.IsActive     == null || i.IsActive     == query.IsActive),
            orderBy:    i => i.LegalName,
            descending: false,
            page:       query.PageNumber,
            pageSize:   query.PageSize,
            cancellationToken: cancellationToken);

        // Resolve cached parent summaries in one pass
        var parentIds = items
            .SelectMany(i => new[] { i.DirectAccountingParentIssuerId, i.UltimateAccountingParentIssuerId })
            .Where(id => id.HasValue).Select(id => id!.Value).Distinct().ToList();

        var parents = new Dictionary<Guid, Issuer>();
        foreach (var pid in parentIds)
        {
            var p = await _uow.Issuers.GetByIdAsync(pid, cancellationToken);
            if (p != null) parents[pid] = p;
        }

        return new PagedResult<IssuerSummaryDto>(
            Items:       items.Select(i => IssuerMappings.MapToSummaryDtoWithParents(i, parents)).ToList(),
            TotalCount:  total,
            PageNumber:  query.PageNumber,
            PageSize:    query.PageSize);
    }
}

// -- GetIssuerRelationships ----------------------------------------------------

public class GetIssuerRelationshipsHandler : IQueryHandler<GetIssuerRelationshipsQuery, List<IssuerRelationshipDto>>
{
    private readonly IIssuersUoW _uow;

    public GetIssuerRelationshipsHandler(IIssuersUoW uow) => _uow = uow;

    public async ValueTask<List<IssuerRelationshipDto>> Handle(
        GetIssuerRelationshipsQuery query, CancellationToken cancellationToken)
    {
        var rels = (await _uow.IssuerRelationships.FindAsync(
            r => r.ChildIssuerId == query.IssuerId && !r.IsDeleted,
            cancellationToken)).ToList();

        return await IssuerMappings.MapRelationshipsAsync(_uow, rels, cancellationToken);
    }
}

// -- GetIssuerChildren ---------------------------------------------------------

public class GetIssuerChildrenHandler : IQueryHandler<GetIssuerChildrenQuery, List<IssuerRelationshipDto>>
{
    private readonly IIssuersUoW _uow;

    public GetIssuerChildrenHandler(IIssuersUoW uow) => _uow = uow;

    public async ValueTask<List<IssuerRelationshipDto>> Handle(
        GetIssuerChildrenQuery query, CancellationToken cancellationToken)
    {
        var rels = (await _uow.IssuerRelationships.FindAsync(
            r => r.ParentIssuerId == query.IssuerId && r.IsCurrent && !r.IsDeleted,
            cancellationToken)).ToList();

        return await IssuerMappings.MapRelationshipsAsync(_uow, rels, cancellationToken);
    }
}

// -- Mappings ------------------------------------------------------------------

internal static class IssuerMappings
{
    internal static IssuerSummaryDto MapToSummaryDto(Issuer i) => new()
    {
        Id            = i.Id,
        LegalName     = i.LegalName,
        DisplayName   = i.DisplayName,
        LeiCode       = i.LeiCode,
        CountryAlpha2 = i.CountryAlpha2,
        IssuerType    = i.IssuerType,
    };

    internal static IssuerSummaryDto MapToSummaryDtoWithParents(
        Issuer i, Dictionary<Guid, Issuer> parents) => new()
    {
        Id            = i.Id,
        LegalName     = i.LegalName,
        DisplayName   = i.DisplayName,
        LeiCode       = i.LeiCode,
        CountryAlpha2 = i.CountryAlpha2,
        IssuerType    = i.IssuerType,
        DirectAccountingParent   = i.DirectAccountingParentIssuerId.HasValue &&
                                   parents.TryGetValue(i.DirectAccountingParentIssuerId.Value, out var dp)
                                   ? MapToSummaryDto(dp) : null,
        UltimateAccountingParent = i.UltimateAccountingParentIssuerId.HasValue &&
                                   parents.TryGetValue(i.UltimateAccountingParentIssuerId.Value, out var up)
                                   ? MapToSummaryDto(up) : null,
    };

    internal static IssuerDto MapToDto(
        Issuer i,
        List<IssuerRelationship> relationships,
        Dictionary<Guid, Issuer> parents,
        IssuerSummaryDto? directParent,
        IssuerSummaryDto? ultimateParent,
        IssuerSummaryDto? derivedUltimate,
        Func<string?, string>? resolver = null) => new()
    {
        Id                       = i.Id,
        LegalName                = i.LegalName,
        DisplayName              = i.DisplayName,
        ShortName                = i.ShortName,
        LeiCode                  = i.LeiCode,
        CountryAlpha2            = i.CountryAlpha2,
        IssuerType               = i.IssuerType,
        IsActive                 = i.IsActive,
        CreatedAt                = i.CreatedAt,
        CreatedBy                = resolver != null ? resolver(i.CreatedBy) : i.CreatedBy,
        LastModifiedAt                = i.LastModifiedAt,
        LastModifiedBy               = resolver != null ? resolver(i.LastModifiedBy) : i.LastModifiedBy,
        ContentHash              = i.ContentHash,
        DirectAccountingParent   = directParent,
        UltimateAccountingParent = ultimateParent,
        DerivedUltimateAccountingParent = derivedUltimate,
        Identifiers = i.Identifiers
            .Where(ii => ii.IsCurrent && !ii.IsDeleted)
            .Select(ii => new IssuerIdentifierDto
            {
                Id              = ii.Id,
                IdentifierType  = ii.IdentifierType,
                IdentifierValue = ii.IdentifierValue,
                SourceSystem    = ii.SourceSystem,
                IsPrimary       = ii.IsPrimary,
            }).ToList(),
        Relationships = relationships
            .Select(r => MapRelationshipDto(r, parents))
            .ToList(),
    };

    internal static async Task<List<IssuerRelationshipDto>> MapRelationshipsAsync(
        IIssuersUoW uow, List<IssuerRelationship> rels, CancellationToken ct)
    {
        var parentIds = rels.Select(r => r.ParentIssuerId).Distinct().ToList();
        var parents = new Dictionary<Guid, Issuer>();
        foreach (var pid in parentIds)
        {
            var p = await uow.Issuers.GetByIdAsync(pid, ct);
            if (p != null) parents[pid] = p;
        }

        return rels.Select(r => MapRelationshipDto(r, parents)).ToList();
    }

    private static IssuerRelationshipDto MapRelationshipDto(
        IssuerRelationship r, Dictionary<Guid, Issuer> parents)
    {
        parents.TryGetValue(r.ParentIssuerId, out var parent);
        return new IssuerRelationshipDto
        {
            Id               = r.Id,
            RelationshipType = r.RelationshipType,
            ParentIssuerId   = r.ParentIssuerId,
            ParentLegalName  = parent?.LegalName ?? string.Empty,
            ParentDisplayName = parent?.DisplayName,
            OwnershipPercent = r.OwnershipPercent,
            ControlBasis     = r.ControlBasis,
            SourceSystem     = r.SourceSystem,
            SourceReference  = r.SourceReference,
            IsPrimary        = r.IsPrimary,
            Notes            = r.Notes,
            ValidFrom        = r.ValidFrom,
            ValidTo          = r.ValidTo,
            IsCurrent        = r.IsCurrent,
        };
    }
}
