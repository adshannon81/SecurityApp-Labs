using Mediator;
using SecurityApp.Core.Grpc;
using SecurityApp.Core.Issuers.Entities;
using SecurityApp.Core.Issuers.Interfaces;
using SecurityApp.Core.Shared.Exceptions;
using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Application.Issuers.Commands;
using SecurityApp.Application.Issuers.DTOs;

namespace SecurityApp.Application.Issuers.Handlers;

// -- Issuer CRUD handlers ------------------------------------------------------

public class CreateIssuerHandler : ICommandHandler<CreateIssuerCommand, CreateIssuerResponse>
{
    private readonly IIssuersUoW _uow;
    private readonly ICacheService _cacheService;
    private readonly IGrpcEventPublisher _grpc;

    public CreateIssuerHandler(IIssuersUoW uow, ICacheService cacheService, IGrpcEventPublisher grpc)
    {
        _uow          = uow;
        _cacheService = cacheService;
        _grpc         = grpc;
    }

    public async ValueTask<CreateIssuerResponse> Handle(CreateIssuerCommand command, CancellationToken cancellationToken)
    {
        var issuer = new Issuer
        {
            LegalName    = command.Issuer.LegalName.Trim(),
            DisplayName  = command.Issuer.DisplayName?.Trim(),
            ShortName    = command.Issuer.ShortName?.Trim(),
            LeiCode      = command.Issuer.LeiCode?.Trim(),
            IssuerType   = command.Issuer.IssuerType,
            CountryAlpha2 = command.Issuer.CountryAlpha2,
            IsActive     = command.Issuer.IsActive,
            LastModifiedBy   = command.UserId,
        };

        if (command.Issuer.Identifiers is { Count: > 0 })
        {
            foreach (var id in command.Issuer.Identifiers)
            {
                issuer.Identifiers.Add(new IssuerIdentifier
                {
                    IssuerId        = issuer.Id,
                    IdentifierType  = id.IdentifierType,
                    IdentifierValue = id.IdentifierValue,
                    SourceSystem    = id.SourceSystem,
                    IsPrimary       = id.IsPrimary,
                });
            }
        }

        await _uow.Issuers.AddAsync(issuer, cancellationToken);
        await _uow.SaveChangesAsync(cancellationToken);

        // Persist initial relationships now that the issuer has an ID
        if (command.Issuer.Relationships is { Count: > 0 })
        {
            foreach (var rel in command.Issuer.Relationships)
            {
                await IssuerRelationshipHelper.ValidateNoCycleAsync(
                    _uow, issuer.Id, rel.ParentIssuerId, rel.RelationshipType, cancellationToken);

                await _uow.IssuerRelationships.AddAsync(new IssuerRelationship
                {
                    ChildIssuerId    = issuer.Id,
                    ParentIssuerId   = rel.ParentIssuerId,
                    RelationshipType = rel.RelationshipType,
                    OwnershipPercent = rel.OwnershipPercent,
                    ControlBasis     = rel.ControlBasis,
                    SourceSystem     = rel.SourceSystem,
                    SourceReference  = rel.SourceReference,
                    IsPrimary        = rel.IsPrimary,
                    Notes            = rel.Notes,
                    ValidFrom        = rel.ValidFrom?.UtcDateTime ?? DateTime.UtcNow,
                    ValidTo          = rel.ValidTo?.UtcDateTime   ?? new DateTime(9999, 12, 31, 23, 59, 59, DateTimeKind.Utc),
                    LastModifiedBy       = command.UserId,
                }, cancellationToken);
            }

            await _uow.SaveChangesAsync(cancellationToken);
            await IssuerRelationshipHelper.UpdateCachedParentsAsync(_uow, issuer, cancellationToken);
        }

        await _cacheService.RemoveByPatternAsync("issuer:*", cancellationToken);
        await _grpc.PublishRefDataChangedAsync(new RefDataChangedPayload("Issuer", command.UserId ?? string.Empty), cancellationToken);
        return new CreateIssuerResponse(issuer.Id, "Created");
    }
}

public class UpdateIssuerHandler : ICommandHandler<UpdateIssuerCommand>
{
    private readonly IIssuersUoW _uow;
    private readonly ICacheService _cacheService;
    private readonly IGrpcEventPublisher _grpc;

    public UpdateIssuerHandler(IIssuersUoW uow, ICacheService cacheService, IGrpcEventPublisher grpc)
    {
        _uow          = uow;
        _cacheService = cacheService;
        _grpc         = grpc;
    }

    public async ValueTask<Unit> Handle(UpdateIssuerCommand command, CancellationToken cancellationToken)
    {
        var issuer = await _uow.Issuers.GetByIdAsync(command.IssuerId, cancellationToken)
            ?? throw new NotFoundException(nameof(Issuer), command.IssuerId);

        issuer.LegalName    = command.Issuer.LegalName.Trim();
        issuer.DisplayName  = command.Issuer.DisplayName?.Trim();
        issuer.ShortName    = command.Issuer.ShortName?.Trim();
        issuer.LeiCode      = command.Issuer.LeiCode?.Trim();
        issuer.IssuerType   = command.Issuer.IssuerType;
        issuer.CountryAlpha2 = command.Issuer.CountryAlpha2;
        issuer.IsActive     = command.Issuer.IsActive;
        issuer.LastModifiedAt    = DateTime.UtcNow;
        issuer.LastModifiedBy   = command.UserId;

        await _uow.Issuers.UpdateAsync(issuer, cancellationToken);
        await _uow.SaveChangesAsync(cancellationToken);

        await _cacheService.RemoveByPatternAsync("issuer:*", cancellationToken);
        await _grpc.PublishRefDataChangedAsync(new RefDataChangedPayload("Issuer", command.UserId ?? string.Empty), cancellationToken);
        return Unit.Value;
    }
}

public class DeleteIssuerHandler : ICommandHandler<DeleteIssuerCommand>
{
    private readonly IIssuersUoW _uow;
    private readonly ICacheService _cacheService;
    private readonly IGrpcEventPublisher _grpc;

    public DeleteIssuerHandler(IIssuersUoW uow, ICacheService cacheService, IGrpcEventPublisher grpc)
    {
        _uow          = uow;
        _cacheService = cacheService;
        _grpc         = grpc;
    }

    public async ValueTask<Unit> Handle(DeleteIssuerCommand command, CancellationToken cancellationToken)
    {
        var issuer = await _uow.Issuers.GetByIdAsync(command.IssuerId, cancellationToken)
            ?? throw new NotFoundException(nameof(Issuer), command.IssuerId);

        issuer.IsDeleted = true;
        issuer.IsCurrent = false;
        issuer.LastModifiedAt = DateTime.UtcNow;

        await _uow.Issuers.UpdateAsync(issuer, cancellationToken);
        await _uow.SaveChangesAsync(cancellationToken);

        await _cacheService.RemoveByPatternAsync("issuer:*", cancellationToken);
        await _grpc.PublishRefDataChangedAsync(new RefDataChangedPayload("Issuer", string.Empty), cancellationToken);
        return Unit.Value;
    }
}

// -- Relationship handlers -----------------------------------------------------

public class AddIssuerRelationshipHandler : ICommandHandler<AddIssuerRelationshipCommand, AddIssuerRelationshipResponse>
{
    private readonly IIssuersUoW _uow;
    private readonly ICacheService _cacheService;

    public AddIssuerRelationshipHandler(IIssuersUoW uow, ICacheService cacheService)
    {
        _uow          = uow;
        _cacheService = cacheService;
    }

    public async ValueTask<AddIssuerRelationshipResponse> Handle(
        AddIssuerRelationshipCommand command, CancellationToken cancellationToken)
    {
        _ = await _uow.Issuers.GetByIdAsync(command.IssuerId, cancellationToken)
            ?? throw new NotFoundException(nameof(Issuer), command.IssuerId);

        var dto = command.Relationship;

        await IssuerRelationshipHelper.ValidateNoCycleAsync(
            _uow, command.IssuerId, dto.ParentIssuerId, dto.RelationshipType, cancellationToken);

        var rel = new IssuerRelationship
        {
            ChildIssuerId    = command.IssuerId,
            ParentIssuerId   = dto.ParentIssuerId,
            RelationshipType = dto.RelationshipType,
            OwnershipPercent = dto.OwnershipPercent,
            ControlBasis     = dto.ControlBasis,
            SourceSystem     = dto.SourceSystem,
            SourceReference  = dto.SourceReference,
            IsPrimary        = dto.IsPrimary,
            Notes            = dto.Notes,
            ValidFrom        = dto.ValidFrom?.UtcDateTime ?? DateTime.UtcNow,
            ValidTo          = dto.ValidTo?.UtcDateTime   ?? new DateTime(9999, 12, 31, 23, 59, 59, DateTimeKind.Utc),
            LastModifiedBy       = command.UserId,
        };

        await _uow.IssuerRelationships.AddAsync(rel, cancellationToken);
        await _uow.SaveChangesAsync(cancellationToken);

        var issuer = await _uow.Issuers.GetByIdAsync(command.IssuerId, cancellationToken);
        if (issuer != null)
            await IssuerRelationshipHelper.UpdateCachedParentsAsync(_uow, issuer, cancellationToken);

        await _cacheService.RemoveByPatternAsync("issuer:*", cancellationToken);
        return new AddIssuerRelationshipResponse(rel.Id, "Created");
    }
}

public class UpdateIssuerRelationshipHandler : ICommandHandler<UpdateIssuerRelationshipCommand>
{
    private readonly IIssuersUoW _uow;
    private readonly ICacheService _cacheService;

    public UpdateIssuerRelationshipHandler(IIssuersUoW uow, ICacheService cacheService)
    {
        _uow          = uow;
        _cacheService = cacheService;
    }

    public async ValueTask<Unit> Handle(UpdateIssuerRelationshipCommand command, CancellationToken cancellationToken)
    {
        var rel = await _uow.IssuerRelationships.GetByIdAsync(command.RelationshipId, cancellationToken)
            ?? throw new NotFoundException(nameof(IssuerRelationship), command.RelationshipId);

        var dto = command.Relationship;

        if (rel.ParentIssuerId != dto.ParentIssuerId)
        {
            await IssuerRelationshipHelper.ValidateNoCycleAsync(
                _uow, rel.ChildIssuerId, dto.ParentIssuerId, dto.RelationshipType, cancellationToken);
        }

        rel.ParentIssuerId   = dto.ParentIssuerId;
        rel.RelationshipType = dto.RelationshipType;
        rel.OwnershipPercent = dto.OwnershipPercent;
        rel.ControlBasis     = dto.ControlBasis;
        rel.SourceSystem     = dto.SourceSystem;
        rel.SourceReference  = dto.SourceReference;
        rel.IsPrimary        = dto.IsPrimary;
        rel.Notes            = dto.Notes;
        rel.ValidFrom        = dto.ValidFrom?.UtcDateTime ?? DateTime.UtcNow;
        rel.ValidTo          = dto.ValidTo?.UtcDateTime   ?? new DateTime(9999, 12, 31, 23, 59, 59, DateTimeKind.Utc);
        rel.LastModifiedAt        = DateTime.UtcNow;
        rel.LastModifiedBy       = command.UserId;

        await _uow.IssuerRelationships.UpdateAsync(rel, cancellationToken);
        await _uow.SaveChangesAsync(cancellationToken);

        var issuer = await _uow.Issuers.GetByIdAsync(rel.ChildIssuerId, cancellationToken);
        if (issuer != null)
            await IssuerRelationshipHelper.UpdateCachedParentsAsync(_uow, issuer, cancellationToken);

        await _cacheService.RemoveByPatternAsync("issuer:*", cancellationToken);
        return Unit.Value;
    }
}

public class DeleteIssuerRelationshipHandler : ICommandHandler<DeleteIssuerRelationshipCommand>
{
    private readonly IIssuersUoW _uow;
    private readonly ICacheService _cacheService;

    public DeleteIssuerRelationshipHandler(IIssuersUoW uow, ICacheService cacheService)
    {
        _uow          = uow;
        _cacheService = cacheService;
    }

    public async ValueTask<Unit> Handle(DeleteIssuerRelationshipCommand command, CancellationToken cancellationToken)
    {
        var rel = await _uow.IssuerRelationships.GetByIdAsync(command.RelationshipId, cancellationToken)
            ?? throw new NotFoundException(nameof(IssuerRelationship), command.RelationshipId);

        rel.IsDeleted = true;
        rel.IsCurrent = false;
        rel.LastModifiedAt = DateTime.UtcNow;

        await _uow.IssuerRelationships.UpdateAsync(rel, cancellationToken);
        await _uow.SaveChangesAsync(cancellationToken);

        var issuer = await _uow.Issuers.GetByIdAsync(rel.ChildIssuerId, cancellationToken);
        if (issuer != null)
            await IssuerRelationshipHelper.UpdateCachedParentsAsync(_uow, issuer, cancellationToken);

        await _cacheService.RemoveByPatternAsync("issuer:*", cancellationToken);
        return Unit.Value;
    }
}

// -- Helper: cycle detection + cache update ------------------------------------

internal static class IssuerRelationshipHelper
{
    /// <summary>
    /// Validates that adding <paramref name="parentId"/> as a parent of <paramref name="childId"/>
    /// (for accounting-type relationships) does not create a cycle.
    /// Walks the existing ACCOUNTING_DIRECT_PARENT chain upward from <paramref name="parentId"/>.
    /// </summary>
    internal static async Task ValidateNoCycleAsync(
        IIssuersUoW uow,
        Guid childId,
        Guid parentId,
        string relationshipType,
        CancellationToken ct)
    {
        if (childId == parentId)
            throw new InvalidOperationException("An issuer cannot be its own parent.");

        // Cycle detection is most relevant for accounting hierarchy types
        if (relationshipType is not (IssuerRelationshipTypes.AccountingDirectParent
                                  or IssuerRelationshipTypes.AccountingUltimateParent
                                  or IssuerRelationshipTypes.OwnershipParent
                                  or IssuerRelationshipTypes.ControlParent))
        {
            return;
        }

        var visited = new HashSet<Guid> { childId };
        var current = parentId;
        const int maxDepth = 50;
        int depth = 0;

        while (depth++ < maxDepth)
        {
            if (!visited.Add(current))
                throw new InvalidOperationException(
                    $"Adding this relationship would create a cycle in the issuer hierarchy (repeated issuer {current}).");

            var parents = await uow.IssuerRelationships.FindAsync(
                r => r.ChildIssuerId   == current
                  && r.RelationshipType == relationshipType
                  && r.IsCurrent
                  && !r.IsDeleted, ct);

            var parent = parents.FirstOrDefault();
            if (parent is null) break;
            current = parent.ParentIssuerId;
        }
    }

    /// <summary>
    /// Refreshes the cached <c>DirectAccountingParentIssuerId</c> and
    /// <c>UltimateAccountingParentIssuerId</c> columns on the issuer row.
    /// </summary>
    internal static async Task UpdateCachedParentsAsync(
        IIssuersUoW uow, Issuer issuer, CancellationToken ct)
    {
        var directRels = await uow.IssuerRelationships.FindAsync(
            r => r.ChildIssuerId    == issuer.Id
              && r.RelationshipType == IssuerRelationshipTypes.AccountingDirectParent
              && r.IsCurrent
              && !r.IsDeleted, ct);

        var directRel = directRels.FirstOrDefault();
        issuer.DirectAccountingParentIssuerId = directRel?.ParentIssuerId;

        // Prefer explicitly stored ultimate parent
        var ultimateRels = await uow.IssuerRelationships.FindAsync(
            r => r.ChildIssuerId    == issuer.Id
              && r.RelationshipType == IssuerRelationshipTypes.AccountingUltimateParent
              && r.IsCurrent
              && !r.IsDeleted, ct);

        var ultimateRel = ultimateRels.FirstOrDefault();
        if (ultimateRel != null)
        {
            issuer.UltimateAccountingParentIssuerId = ultimateRel.ParentIssuerId;
        }
        else if (directRel != null)
        {
            // Derive ultimate by walking the direct chain
            issuer.UltimateAccountingParentIssuerId =
                await DeriveUltimateParentAsync(uow, directRel.ParentIssuerId, ct);
        }
        else
        {
            issuer.UltimateAccountingParentIssuerId = null;
        }

        issuer.LastModifiedAt = DateTime.UtcNow;
        await uow.Issuers.UpdateAsync(issuer, ct);
        await uow.SaveChangesAsync(ct);
    }

    private static async Task<Guid?> DeriveUltimateParentAsync(
        IIssuersUoW uow, Guid startId, CancellationToken ct)
    {
        var visited = new HashSet<Guid>();
        var current = startId;
        const int maxDepth = 50;
        int depth = 0;

        while (depth++ < maxDepth)
        {
            if (!visited.Add(current)) break;

            var parents = await uow.IssuerRelationships.FindAsync(
                r => r.ChildIssuerId    == current
                  && r.RelationshipType == IssuerRelationshipTypes.AccountingDirectParent
                  && r.IsCurrent
                  && !r.IsDeleted, ct);

            var parent = parents.FirstOrDefault();
            if (parent is null) return current;
            current = parent.ParentIssuerId;
        }

        return current;
    }
}
