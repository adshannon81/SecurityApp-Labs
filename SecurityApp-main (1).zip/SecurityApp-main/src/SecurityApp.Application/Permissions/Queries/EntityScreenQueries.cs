using Mediator;
using SecurityApp.Application.Permissions.DTOs;

namespace SecurityApp.Application.Permissions.Queries;

public record GetAllEntityScreensQuery : IQuery<IReadOnlyList<EntityScreenDto>>;

public record GetEntityScreenByIdQuery(Guid Id) : IQuery<EntityScreenDto?>;
