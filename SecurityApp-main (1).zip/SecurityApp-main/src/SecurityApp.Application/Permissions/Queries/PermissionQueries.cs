using Mediator;
using SecurityApp.Application.Permissions.DTOs;

namespace SecurityApp.Application.Permissions.Queries;

// ── Permission Definition ─────────────────────────────────────────────────────

public record GetAllPermissionDefinitionsQuery : IQuery<IReadOnlyList<PermissionDefinitionDto>>;

public record GetPermissionDefinitionByIdQuery(Guid Id) : IQuery<PermissionDefinitionDto?>;

public record GetPermissionDefinitionByKeyQuery(string PermissionKey) : IQuery<PermissionDefinitionDto?>;

// ── Permission Bundle ─────────────────────────────────────────────────────────

public record GetAllPermissionBundlesQuery : IQuery<IReadOnlyList<PermissionBundleDto>>;

public record GetPermissionBundleByIdQuery(Guid Id) : IQuery<PermissionBundleDto?>;

public record GetPermissionBundleWithMembersQuery(Guid Id) : IQuery<PermissionBundleWithMembersDto?>;

public record GetPermissionBundleMembersQuery(Guid BundleId) : IQuery<IReadOnlyList<PermissionBundleMemberDto>>;

// ── Policy Template ───────────────────────────────────────────────────────────

public record GetAllPolicyTemplatesQuery : IQuery<IReadOnlyList<PolicyTemplateDto>>;

public record GetPolicyTemplateByIdQuery(Guid Id) : IQuery<PolicyTemplateDto?>;
