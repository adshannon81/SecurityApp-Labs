namespace SecurityApp.Application.Permissions.DTOs;

// â”€â”€ Permission Definition â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

public record PermissionDefinitionDto(
    Guid      Id,
    string    PermissionKey,
    string    DisplayName,
    string    PermissionGroup,
    string?   Description,
    bool      IsAssignable,
    bool      IsSystem,
    int       SortOrder,
    bool      IsActive,
    DateTime  CreatedAt,
    DateTime? LastModifiedAt);

public record CreatePermissionDefinitionRequest(
    string  PermissionKey,
    string  DisplayName,
    string  PermissionGroup,
    string? Description,
    bool    IsAssignable = true,
    bool    IsSystem     = false,
    int     SortOrder    = 0,
    bool    IsActive     = true);

public record UpdatePermissionDefinitionRequest(
    string  PermissionKey,
    string  DisplayName,
    string  PermissionGroup,
    string? Description,
    bool    IsAssignable,
    bool    IsSystem,
    int     SortOrder,
    bool    IsActive);

// ── Permission Bundle ─────────────────────────────────────────────────────────

public record PermissionBundleDto(
    Guid      Id,
    string    BundleKey,
    string    DisplayName,
    string?   Description,
    bool      IsActive,
    DateTime  CreatedAt,
    DateTime? LastModifiedAt);

public record PermissionBundleMemberDto(
    Guid   Id,
    Guid   PermissionBundleId,
    Guid   PermissionDefinitionId,
    string PermissionKey,
    string DisplayName,
    string PermissionGroup);

public record PermissionBundleWithMembersDto(
    Guid      Id,
    string    BundleKey,
    string    DisplayName,
    string?   Description,
    bool      IsActive,
    DateTime  CreatedAt,
    DateTime? LastModifiedAt,
    IReadOnlyList<PermissionBundleMemberDto> Members);

public record CreatePermissionBundleRequest(
    string  BundleKey,
    string  DisplayName,
    string? Description,
    bool    IsActive = true);

public record UpdatePermissionBundleRequest(
    string  BundleKey,
    string  DisplayName,
    string? Description,
    bool    IsActive);

public record AddPermissionBundleMemberRequest(
    Guid PermissionBundleId,
    Guid PermissionDefinitionId);

// ── Policy Template ───────────────────────────────────────────────────────────

public record PolicyTemplateDto(
    Guid      Id,
    string    TemplateKey,
    string    TemplateName,
    string    TargetType,
    string?   Description,
    string    TemplateJson,
    bool      IsActive,
    DateTime  CreatedAt,
    DateTime? LastModifiedAt);

public record CreatePolicyTemplateRequest(
    string  TemplateKey,
    string  TemplateName,
    string  TargetType,
    string? Description,
    string  TemplateJson,
    bool    IsActive = true);

public record UpdatePolicyTemplateRequest(
    string  TemplateKey,
    string  TemplateName,
    string  TargetType,
    string? Description,
    string  TemplateJson,
    bool    IsActive);
