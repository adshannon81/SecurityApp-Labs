namespace SecurityApp.Application.Permissions.DTOs;

public record EntityScreenDto(
    Guid      Id,
    string    ScreenKey,
    string    DisplayName,
    string?   EntityType,
    Guid?     AppResourceId,
    string?   Description,
    int       SortOrder,
    bool      IsActive,
    DateTime  CreatedAt,
    DateTime? LastModifiedAt);

public record CreateEntityScreenRequest(
    string  ScreenKey,
    string  DisplayName,
    string? EntityType,
    Guid?   AppResourceId,
    string? Description,
    int     SortOrder,
    bool    IsActive = true);

public record UpdateEntityScreenRequest(
    string  ScreenKey,
    string  DisplayName,
    string? EntityType,
    Guid?   AppResourceId,
    string? Description,
    int     SortOrder,
    bool    IsActive);
