﻿using Mediator;
using SecurityApp.Application.Permissions.DTOs;

namespace SecurityApp.Application.Permissions.Commands;

// -- Permission Definition -----------------------------------------------------

public record CreatePermissionDefinitionCommand(CreatePermissionDefinitionRequest Request, string? UserId)
    : ICommand<PermissionDefinitionDto>;

public record UpdatePermissionDefinitionCommand(Guid Id, UpdatePermissionDefinitionRequest Request, string? UserId)
    : ICommand<PermissionDefinitionDto>;

public record DeletePermissionDefinitionCommand(Guid Id) : ICommand;

// -- Permission Bundle ---------------------------------------------------------

public record CreatePermissionBundleCommand(CreatePermissionBundleRequest Request, string? UserId)
    : ICommand<PermissionBundleDto>;

public record UpdatePermissionBundleCommand(Guid Id, UpdatePermissionBundleRequest Request, string? UserId)
    : ICommand<PermissionBundleDto>;

public record DeletePermissionBundleCommand(Guid Id) : ICommand;

public record AddPermissionBundleMemberCommand(AddPermissionBundleMemberRequest Request, string? UserId)
    : ICommand<PermissionBundleMemberDto>;

public record RemovePermissionBundleMemberCommand(Guid MemberId) : ICommand;

// -- Policy Template -----------------------------------------------------------

public record CreatePolicyTemplateCommand(CreatePolicyTemplateRequest Request, string? UserId)
    : ICommand<PolicyTemplateDto>;

public record UpdatePolicyTemplateCommand(Guid Id, UpdatePolicyTemplateRequest Request, string? UserId)
    : ICommand<PolicyTemplateDto>;

public record DeletePolicyTemplateCommand(Guid Id) : ICommand;
