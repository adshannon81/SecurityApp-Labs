using Mediator;
using SecurityApp.Application.Permissions.DTOs;

namespace SecurityApp.Application.Permissions.Commands;

public record CreateEntityScreenCommand(CreateEntityScreenRequest Request, string? UserId)
    : ICommand<EntityScreenDto>;

public record UpdateEntityScreenCommand(Guid Id, UpdateEntityScreenRequest Request, string? UserId)
    : ICommand<EntityScreenDto>;

public record DeleteEntityScreenCommand(Guid Id) : ICommand;
