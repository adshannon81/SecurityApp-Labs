using Mediator;
using SecurityApp.Application.Permissions.Commands;
using SecurityApp.Application.Permissions.DTOs;
using SecurityApp.Application.Permissions.Queries;
using SecurityApp.Core.Permissions;

namespace SecurityApp.Application.Permissions.Handlers;

// ══════════════════════════════════════════════════════════════════════════════
// Policy Template — Queries
// ══════════════════════════════════════════════════════════════════════════════

public class GetAllPolicyTemplatesHandler(IPolicyTemplateRepository repo)
    : IQueryHandler<GetAllPolicyTemplatesQuery, IReadOnlyList<PolicyTemplateDto>>
{
    public async ValueTask<IReadOnlyList<PolicyTemplateDto>> Handle(
        GetAllPolicyTemplatesQuery query, CancellationToken ct)
    {
        var items = await repo.GetAllAsync(ct);
        return items.Select(PolicyTemplateMappings.ToDto).ToList();
    }
}

public class GetPolicyTemplateByIdHandler(IPolicyTemplateRepository repo)
    : IQueryHandler<GetPolicyTemplateByIdQuery, PolicyTemplateDto?>
{
    public async ValueTask<PolicyTemplateDto?> Handle(
        GetPolicyTemplateByIdQuery query, CancellationToken ct)
    {
        var item = await repo.GetByIdAsync(query.Id, ct);
        return item is null ? null : PolicyTemplateMappings.ToDto(item);
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Policy Template — Commands
// ══════════════════════════════════════════════════════════════════════════════

public class CreatePolicyTemplateHandler(IPolicyTemplateRepository repo)
    : ICommandHandler<CreatePolicyTemplateCommand, PolicyTemplateDto>
{
    public async ValueTask<PolicyTemplateDto> Handle(
        CreatePolicyTemplateCommand command, CancellationToken ct)
    {
        var req = command.Request;
        var entity = new PolicyTemplate
        {
            TemplateKey    = req.TemplateKey,
            TemplateName   = req.TemplateName,
            TargetType     = req.TargetType,
            Description    = req.Description,
            TemplateJson   = req.TemplateJson,
            IsActive       = req.IsActive,
            LastModifiedBy = command.UserId,
        };
        var created = await repo.CreateAsync(entity, ct);
        return PolicyTemplateMappings.ToDto(created);
    }
}

public class UpdatePolicyTemplateHandler(IPolicyTemplateRepository repo)
    : ICommandHandler<UpdatePolicyTemplateCommand, PolicyTemplateDto>
{
    public async ValueTask<PolicyTemplateDto> Handle(
        UpdatePolicyTemplateCommand command, CancellationToken ct)
    {
        var existing = await repo.GetByIdAsync(command.Id, ct)
            ?? throw new KeyNotFoundException($"PolicyTemplate {command.Id} not found.");
        var req = command.Request;
        existing.TemplateKey    = req.TemplateKey;
        existing.TemplateName   = req.TemplateName;
        existing.TargetType     = req.TargetType;
        existing.Description    = req.Description;
        existing.TemplateJson   = req.TemplateJson;
        existing.IsActive       = req.IsActive;
        existing.LastModifiedAt = DateTime.UtcNow;
        existing.LastModifiedBy = command.UserId;
        var updated = await repo.UpdateAsync(existing, ct);
        return PolicyTemplateMappings.ToDto(updated);
    }
}

public class DeletePolicyTemplateHandler(IPolicyTemplateRepository repo)
    : ICommandHandler<DeletePolicyTemplateCommand, Unit>
{
    public async ValueTask<Unit> Handle(
        DeletePolicyTemplateCommand command, CancellationToken ct)
    {
        await repo.DeleteAsync(command.Id, ct);
        return Unit.Value;
    }
}

// Mappings

internal static class PolicyTemplateMappings
{
    internal static PolicyTemplateDto ToDto(PolicyTemplate e) => new(
        e.Id, e.TemplateKey, e.TemplateName, e.TargetType,
        e.Description, e.TemplateJson, e.IsActive,
        e.CreatedAt, e.LastModifiedAt);
}
