using Mediator;
using SecurityApp.Application.Permissions.Commands;
using SecurityApp.Application.Permissions.DTOs;
using SecurityApp.Application.Permissions.Queries;
using SecurityApp.Core.Permissions;

namespace SecurityApp.Application.Permissions.Handlers;

// ══════════════════════════════════════════════════════════════════════════════
// Permission Definition
// ══════════════════════════════════════════════════════════════════════════════

public class GetAllPermissionDefinitionsHandler(IPermissionDefinitionRepository repo)
    : IQueryHandler<GetAllPermissionDefinitionsQuery, IReadOnlyList<PermissionDefinitionDto>>
{
    public async ValueTask<IReadOnlyList<PermissionDefinitionDto>> Handle(
        GetAllPermissionDefinitionsQuery query, CancellationToken ct)
    {
        var items = await repo.GetAllAsync(ct);
        return items.Select(PermissionDefinitionMappings.ToDto).ToList();
    }
}

public class GetPermissionDefinitionByIdHandler(IPermissionDefinitionRepository repo)
    : IQueryHandler<GetPermissionDefinitionByIdQuery, PermissionDefinitionDto?>
{
    public async ValueTask<PermissionDefinitionDto?> Handle(
        GetPermissionDefinitionByIdQuery query, CancellationToken ct)
    {
        var item = await repo.GetByIdAsync(query.Id, ct);
        return item is null ? null : PermissionDefinitionMappings.ToDto(item);
    }
}

public class GetPermissionDefinitionByKeyHandler(IPermissionDefinitionRepository repo)
    : IQueryHandler<GetPermissionDefinitionByKeyQuery, PermissionDefinitionDto?>
{
    public async ValueTask<PermissionDefinitionDto?> Handle(
        GetPermissionDefinitionByKeyQuery query, CancellationToken ct)
    {
        var item = await repo.GetByKeyAsync(query.PermissionKey, ct);
        return item is null ? null : PermissionDefinitionMappings.ToDto(item);
    }
}

public class CreatePermissionDefinitionHandler(IPermissionDefinitionRepository repo)
    : ICommandHandler<CreatePermissionDefinitionCommand, PermissionDefinitionDto>
{
    public async ValueTask<PermissionDefinitionDto> Handle(
        CreatePermissionDefinitionCommand command, CancellationToken ct)
    {
        var req = command.Request;
        var entity = new PermissionDefinition
        {
            PermissionKey   = req.PermissionKey,
            DisplayName     = req.DisplayName,
            PermissionGroup = req.PermissionGroup,
            Description     = req.Description,
            IsAssignable    = req.IsAssignable,
            IsSystem        = req.IsSystem,
            SortOrder       = req.SortOrder,
            IsActive        = req.IsActive,
            LastModifiedBy      = command.UserId,
        };
        var created = await repo.CreateAsync(entity, ct);
        return PermissionDefinitionMappings.ToDto(created);
    }
}

public class UpdatePermissionDefinitionHandler(IPermissionDefinitionRepository repo)
    : ICommandHandler<UpdatePermissionDefinitionCommand, PermissionDefinitionDto>
{
    public async ValueTask<PermissionDefinitionDto> Handle(
        UpdatePermissionDefinitionCommand command, CancellationToken ct)
    {
        var existing = await repo.GetByIdAsync(command.Id, ct)
            ?? throw new KeyNotFoundException($"PermissionDefinition {command.Id} not found.");
        var req = command.Request;
        existing.PermissionKey   = req.PermissionKey;
        existing.DisplayName     = req.DisplayName;
        existing.PermissionGroup = req.PermissionGroup;
        existing.Description     = req.Description;
        existing.IsAssignable    = req.IsAssignable;
        existing.IsSystem        = req.IsSystem;
        existing.SortOrder       = req.SortOrder;
        existing.IsActive        = req.IsActive;
        existing.LastModifiedAt       = DateTime.UtcNow;
        existing.LastModifiedBy      = command.UserId;
        var updated = await repo.UpdateAsync(existing, ct);
        return PermissionDefinitionMappings.ToDto(updated);
    }
}

public class DeletePermissionDefinitionHandler(IPermissionDefinitionRepository repo)
    : ICommandHandler<DeletePermissionDefinitionCommand, Unit>
{
    public async ValueTask<Unit> Handle(
        DeletePermissionDefinitionCommand command, CancellationToken ct)
    {
        await repo.DeleteAsync(command.Id, ct);
        return Unit.Value;
    }
}

// Mappings

internal static class PermissionDefinitionMappings
{
    internal static PermissionDefinitionDto ToDto(PermissionDefinition e) => new(
        e.Id, e.PermissionKey, e.DisplayName, e.PermissionGroup,
        e.Description, e.IsAssignable, e.IsSystem, e.SortOrder,
        e.IsActive, e.CreatedAt, e.LastModifiedAt);
}
