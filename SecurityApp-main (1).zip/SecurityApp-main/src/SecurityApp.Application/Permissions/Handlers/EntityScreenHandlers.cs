using Mediator;
using SecurityApp.Application.Permissions.Commands;
using SecurityApp.Application.Permissions.DTOs;
using SecurityApp.Application.Permissions.Queries;
using SecurityApp.Core.Permissions;

namespace SecurityApp.Application.Permissions.Handlers;

// ── Query handlers ────────────────────────────────────────────────────────────

public class GetAllEntityScreensHandler(IEntityScreenRepository repo)
    : IQueryHandler<GetAllEntityScreensQuery, IReadOnlyList<EntityScreenDto>>
{
    public async ValueTask<IReadOnlyList<EntityScreenDto>> Handle(
        GetAllEntityScreensQuery query, CancellationToken ct)
    {
        var screens = await repo.GetAllAsync(ct);
        return screens.Select(EntityScreenMappings.ToDto).ToList();
    }
}

public class GetEntityScreenByIdHandler(IEntityScreenRepository repo)
    : IQueryHandler<GetEntityScreenByIdQuery, EntityScreenDto?>
{
    public async ValueTask<EntityScreenDto?> Handle(
        GetEntityScreenByIdQuery query, CancellationToken ct)
    {
        var screen = await repo.GetByIdAsync(query.Id, ct);
        return screen is null ? null : EntityScreenMappings.ToDto(screen);
    }
}

// ── Command handlers ──────────────────────────────────────────────────────────

public class CreateEntityScreenHandler(IEntityScreenRepository repo)
    : ICommandHandler<CreateEntityScreenCommand, EntityScreenDto>
{
    public async ValueTask<EntityScreenDto> Handle(
        CreateEntityScreenCommand command, CancellationToken ct)
    {
        var req = command.Request;
        var screen = new EntityScreen
        {
            ScreenKey     = req.ScreenKey,
            DisplayName   = req.DisplayName,
            EntityType    = req.EntityType,
            AppResourceId = req.AppResourceId,
            Description   = req.Description,
            SortOrder     = req.SortOrder,
            IsActive      = req.IsActive,
            LastModifiedBy    = command.UserId,
        };
        var created = await repo.CreateAsync(screen, ct);
        return EntityScreenMappings.ToDto(created);
    }
}

public class UpdateEntityScreenHandler(IEntityScreenRepository repo)
    : ICommandHandler<UpdateEntityScreenCommand, EntityScreenDto>
{
    public async ValueTask<EntityScreenDto> Handle(
        UpdateEntityScreenCommand command, CancellationToken ct)
    {
        var existing = await repo.GetByIdAsync(command.Id, ct)
            ?? throw new KeyNotFoundException($"EntityScreen {command.Id} not found.");

        var req = command.Request;
        existing.ScreenKey     = req.ScreenKey;
        existing.DisplayName   = req.DisplayName;
        existing.EntityType    = req.EntityType;
        existing.AppResourceId = req.AppResourceId;
        existing.Description   = req.Description;
        existing.SortOrder     = req.SortOrder;
        existing.IsActive      = req.IsActive;
        existing.LastModifiedAt     = DateTime.UtcNow;
        existing.LastModifiedBy    = command.UserId;

        var updated = await repo.UpdateAsync(existing, ct);
        return EntityScreenMappings.ToDto(updated);
    }
}

public class DeleteEntityScreenHandler(IEntityScreenRepository repo)
    : ICommandHandler<DeleteEntityScreenCommand, Unit>
{
    public async ValueTask<Unit> Handle(
        DeleteEntityScreenCommand command, CancellationToken ct)
    {
        await repo.DeleteAsync(command.Id, ct);
        return Unit.Value;
    }
}

// ── Mappings ──────────────────────────────────────────────────────────────────

internal static class EntityScreenMappings
{
    internal static EntityScreenDto ToDto(EntityScreen s) => new(
        s.Id,
        s.ScreenKey,
        s.DisplayName,
        s.EntityType,
        s.AppResourceId,
        s.Description,
        s.SortOrder,
        s.IsActive,
        s.CreatedAt,
        s.LastModifiedAt);
}
