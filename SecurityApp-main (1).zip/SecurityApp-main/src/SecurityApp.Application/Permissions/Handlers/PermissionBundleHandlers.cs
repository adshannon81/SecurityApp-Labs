using Mediator;
using SecurityApp.Application.Permissions.Commands;
using SecurityApp.Application.Permissions.DTOs;
using SecurityApp.Application.Permissions.Queries;
using SecurityApp.Core.Permissions;

namespace SecurityApp.Application.Permissions.Handlers;

// ══════════════════════════════════════════════════════════════════════════════
// Permission Bundle — Queries
// ══════════════════════════════════════════════════════════════════════════════

public class GetAllPermissionBundlesHandler(IPermissionBundleRepository repo)
    : IQueryHandler<GetAllPermissionBundlesQuery, IReadOnlyList<PermissionBundleDto>>
{
    public async ValueTask<IReadOnlyList<PermissionBundleDto>> Handle(
        GetAllPermissionBundlesQuery query, CancellationToken ct)
    {
        var items = await repo.GetAllAsync(ct);
        return items.Select(PermissionBundleMappings.ToDto).ToList();
    }
}

public class GetPermissionBundleByIdHandler(IPermissionBundleRepository repo)
    : IQueryHandler<GetPermissionBundleByIdQuery, PermissionBundleDto?>
{
    public async ValueTask<PermissionBundleDto?> Handle(
        GetPermissionBundleByIdQuery query, CancellationToken ct)
    {
        var item = await repo.GetByIdAsync(query.Id, ct);
        return item is null ? null : PermissionBundleMappings.ToDto(item);
    }
}

public class GetPermissionBundleWithMembersHandler(IPermissionBundleRepository repo)
    : IQueryHandler<GetPermissionBundleWithMembersQuery, PermissionBundleWithMembersDto?>
{
    public async ValueTask<PermissionBundleWithMembersDto?> Handle(
        GetPermissionBundleWithMembersQuery query, CancellationToken ct)
    {
        var bundle = await repo.GetWithMembersAsync(query.Id, ct);
        return bundle is null ? null : PermissionBundleMappings.ToWithMembersDto(bundle);
    }
}

public class GetPermissionBundleMembersHandler(IPermissionBundleRepository repo)
    : IQueryHandler<GetPermissionBundleMembersQuery, IReadOnlyList<PermissionBundleMemberDto>>
{
    public async ValueTask<IReadOnlyList<PermissionBundleMemberDto>> Handle(
        GetPermissionBundleMembersQuery query, CancellationToken ct)
    {
        var members = await repo.GetMembersAsync(query.BundleId, ct);
        return members.Select(PermissionBundleMappings.ToMemberDto).ToList();
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// Permission Bundle — Commands
// ══════════════════════════════════════════════════════════════════════════════

public class CreatePermissionBundleHandler(IPermissionBundleRepository repo)
    : ICommandHandler<CreatePermissionBundleCommand, PermissionBundleDto>
{
    public async ValueTask<PermissionBundleDto> Handle(
        CreatePermissionBundleCommand command, CancellationToken ct)
    {
        var req = command.Request;
        var entity = new PermissionBundle
        {
            BundleKey      = req.BundleKey,
            DisplayName    = req.DisplayName,
            Description    = req.Description,
            IsActive       = req.IsActive,
            LastModifiedBy = command.UserId,
        };
        var created = await repo.CreateAsync(entity, ct);
        return PermissionBundleMappings.ToDto(created);
    }
}

public class UpdatePermissionBundleHandler(IPermissionBundleRepository repo)
    : ICommandHandler<UpdatePermissionBundleCommand, PermissionBundleDto>
{
    public async ValueTask<PermissionBundleDto> Handle(
        UpdatePermissionBundleCommand command, CancellationToken ct)
    {
        var existing = await repo.GetByIdAsync(command.Id, ct)
            ?? throw new KeyNotFoundException($"PermissionBundle {command.Id} not found.");
        var req = command.Request;
        existing.BundleKey      = req.BundleKey;
        existing.DisplayName    = req.DisplayName;
        existing.Description    = req.Description;
        existing.IsActive       = req.IsActive;
        existing.LastModifiedAt = DateTime.UtcNow;
        existing.LastModifiedBy = command.UserId;
        var updated = await repo.UpdateAsync(existing, ct);
        return PermissionBundleMappings.ToDto(updated);
    }
}

public class DeletePermissionBundleHandler(IPermissionBundleRepository repo)
    : ICommandHandler<DeletePermissionBundleCommand, Unit>
{
    public async ValueTask<Unit> Handle(
        DeletePermissionBundleCommand command, CancellationToken ct)
    {
        await repo.DeleteAsync(command.Id, ct);
        return Unit.Value;
    }
}

public class AddPermissionBundleMemberHandler(IPermissionBundleRepository repo)
    : ICommandHandler<AddPermissionBundleMemberCommand, PermissionBundleMemberDto>
{
    public async ValueTask<PermissionBundleMemberDto> Handle(
        AddPermissionBundleMemberCommand command, CancellationToken ct)
    {
        var member = new PermissionBundleMember
        {
            PermissionBundleId     = command.Request.PermissionBundleId,
            PermissionDefinitionId = command.Request.PermissionDefinitionId,
        };
        var created = await repo.AddMemberAsync(member, ct);
        return PermissionBundleMappings.ToMemberDto(created);
    }
}

public class RemovePermissionBundleMemberHandler(IPermissionBundleRepository repo)
    : ICommandHandler<RemovePermissionBundleMemberCommand, Unit>
{
    public async ValueTask<Unit> Handle(
        RemovePermissionBundleMemberCommand command, CancellationToken ct)
    {
        await repo.RemoveMemberAsync(command.MemberId, ct);
        return Unit.Value;
    }
}

// Mappings

internal static class PermissionBundleMappings
{
    internal static PermissionBundleDto ToDto(PermissionBundle e) => new(
        e.Id, e.BundleKey, e.DisplayName, e.Description,
        e.IsActive, e.CreatedAt, e.LastModifiedAt);

    internal static PermissionBundleWithMembersDto ToWithMembersDto(PermissionBundle e) => new(
        e.Id, e.BundleKey, e.DisplayName, e.Description,
        e.IsActive, e.CreatedAt, e.LastModifiedAt,
        e.Members.Select(ToMemberDto).ToList());

    internal static PermissionBundleMemberDto ToMemberDto(PermissionBundleMember m) => new(
        m.Id,
        m.PermissionBundleId,
        m.PermissionDefinitionId,
        m.Permission?.PermissionKey   ?? string.Empty,
        m.Permission?.DisplayName     ?? string.Empty,
        m.Permission?.PermissionGroup ?? string.Empty);
}
