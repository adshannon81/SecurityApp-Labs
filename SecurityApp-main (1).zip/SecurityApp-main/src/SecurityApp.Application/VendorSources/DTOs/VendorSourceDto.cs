using System.ComponentModel.DataAnnotations;
using SecurityApp.Core.VendorSources.Entities;
using SecurityApp.Core.Users;

namespace SecurityApp.Application.VendorSources.DTOs;

// â”€â”€ Read DTOs â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

public class VendorSourceDto
{
    public Guid   Id                      { get; set; }
    public string Code                    { get; set; } = string.Empty;
    public string DisplayName             { get; set; } = string.Empty;
    public int    GlobalPriority          { get; set; }
    public int    StalenessThresholdHours { get; set; }
    public bool   IsActive                { get; set; }
    public DateTime  CreatedAt  { get; set; }
    public string?   CreatedBy  { get; set; }
    public DateTime? LastModifiedAt  { get; set; }
    public string?   LastModifiedBy { get; set; }
    public List<VendorFieldPriorityDto> FieldPriorities { get; set; } = new();

    public static VendorSourceDto FromEntity(VendorSource v, Func<string?, string>? resolver = null) => new()
    {
        Id                      = v.Id,
        Code                    = v.Code,
        DisplayName             = v.DisplayName,
        GlobalPriority          = v.GlobalPriority,
        StalenessThresholdHours = v.StalenessThresholdHours,
        IsActive                = v.IsActive,
        CreatedAt               = v.CreatedAt,
        CreatedBy               = resolver != null ? resolver(v.CreatedBy) : v.CreatedBy,
        LastModifiedAt               = v.LastModifiedAt,
        LastModifiedBy              = resolver != null ? resolver(v.LastModifiedBy) : v.LastModifiedBy,
        FieldPriorities         = v.FieldPriorities.Select(VendorFieldPriorityDto.FromEntity).ToList(),
    };
}

public class VendorFieldPriorityDto
{
    public Guid    Id               { get; set; }
    public Guid    VendorSourceId   { get; set; }
    public string  FieldName        { get; set; } = string.Empty;
    public string? AssetClassCode   { get; set; }
    public int     Priority         { get; set; }
    public bool    IsActive         { get; set; }
    public DateTime  CreatedAt  { get; set; }
    public DateTime? LastModifiedAt  { get; set; }
    public string?   LastModifiedBy { get; set; }

    public static VendorFieldPriorityDto FromEntity(VendorFieldPriority fp) => new()
    {
        Id             = fp.Id,
        VendorSourceId = fp.VendorSourceId,
        FieldName      = fp.FieldName,
        AssetClassCode = fp.AssetClassCode,
        Priority       = fp.Priority,
        IsActive       = fp.IsActive,
        CreatedAt      = fp.CreatedAt,
        LastModifiedAt      = fp.LastModifiedAt,
        LastModifiedBy     = fp.LastModifiedBy,
    };
}

// â”€â”€ Write DTOs â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

public class CreateVendorSourceDto
{
    [Required]
    [StringLength(50)]
    public string Code { get; set; } = string.Empty;

    [Required]
    [StringLength(100)]
    public string DisplayName { get; set; } = string.Empty;

    [Range(1, int.MaxValue)]
    public int GlobalPriority { get; set; } = 100;

    [Range(0, int.MaxValue)]
    public int StalenessThresholdHours { get; set; } = 24;

    public bool IsActive { get; set; } = true;
}

public class CreateVendorFieldPriorityDto
{
    [Required]
    [StringLength(100)]
    public string FieldName { get; set; } = string.Empty;

    [StringLength(50)]
    public string? AssetClassCode { get; set; }

    [Range(1, int.MaxValue)]
    public int Priority { get; set; } = 100;

    public bool IsActive { get; set; } = true;
}
