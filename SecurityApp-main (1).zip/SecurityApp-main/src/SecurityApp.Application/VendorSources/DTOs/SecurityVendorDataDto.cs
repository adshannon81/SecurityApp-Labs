using SecurityApp.Core.VendorSources.Entities;

namespace SecurityApp.Application.VendorSources.DTOs;

public class SecurityVendorDataDto
{
    public Guid     Id             { get; set; }
    public Guid     SecurityId     { get; set; }
    public Guid     VendorSourceId { get; set; }
    public string?  VendorCode     { get; set; }
    public string?  VendorName     { get; set; }
    public string   FieldName      { get; set; } = string.Empty;
    public string?  RawValue       { get; set; }
    public string?  FeedBatchId    { get; set; }
    public DateTime ReceivedAt     { get; set; }
    public DateTime CreatedAt      { get; set; }

    internal static SecurityVendorDataDto From(SecurityVendorData e) => new()
    {
        Id             = e.Id,
        SecurityId     = e.SecurityId,
        VendorSourceId = e.VendorSourceId,
        VendorCode     = e.VendorSource?.Code,
        VendorName     = e.VendorSource?.DisplayName,
        FieldName      = e.FieldName,
        RawValue       = e.RawValue,
        FeedBatchId    = e.FeedBatchId,
        ReceivedAt     = e.ReceivedAt,
        CreatedAt      = e.CreatedAt
    };
}
