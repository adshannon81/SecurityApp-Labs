using Mediator;
using SecurityApp.Application.VendorSources.DTOs;

namespace SecurityApp.Application.VendorSources.Commands;

// ── VendorSource CRUD ──────────────────────────────────────────────────────────

public record CreateVendorSourceCommand(CreateVendorSourceDto Dto, string? UserId = null)
    : ICommand<CreateVendorSourceResponse>;

public record CreateVendorSourceResponse(Guid VendorSourceId, string Message);

public record UpdateVendorSourceCommand(Guid VendorSourceId, CreateVendorSourceDto Dto, string? UserId = null)
    : ICommand;

public record DeleteVendorSourceCommand(Guid VendorSourceId)
    : ICommand;

// ── VendorFieldPriority CRUD ──────────────────────────────────────────────────

public record UpsertFieldPriorityCommand(
    Guid VendorSourceId,
    CreateVendorFieldPriorityDto Dto,
    string? UserId = null)
    : ICommand<UpsertFieldPriorityResponse>;

public record UpsertFieldPriorityResponse(Guid FieldPriorityId, string Message);

public record UpdateFieldPriorityCommand(
    Guid FieldPriorityId,
    CreateVendorFieldPriorityDto Dto,
    string? UserId = null)
    : ICommand;

public record DeleteFieldPriorityCommand(Guid FieldPriorityId)
    : ICommand;
