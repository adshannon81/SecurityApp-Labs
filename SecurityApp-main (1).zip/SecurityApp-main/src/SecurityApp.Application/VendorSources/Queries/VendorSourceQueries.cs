using Mediator;
using SecurityApp.Application.VendorSources.DTOs;

namespace SecurityApp.Application.VendorSources.Queries;

public record GetAllVendorSourcesQuery(bool IncludeInactive = false)
    : IQuery<List<VendorSourceDto>>;

public record GetVendorSourceByIdQuery(Guid VendorSourceId)
    : IQuery<VendorSourceDto?>;

public record GetFieldPrioritiesQuery(Guid VendorSourceId)
    : IQuery<List<VendorFieldPriorityDto>>;
