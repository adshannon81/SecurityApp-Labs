using Mediator;
using SecurityApp.Application.Shared;
using SecurityApp.Application.VendorSources.DTOs;

namespace SecurityApp.Application.VendorSources.Queries;

/// <summary>
/// Returns a paginated list of raw vendor field snapshots for a given security.
/// Optionally filtered by field name, vendor source, or date range.
/// </summary>
public record GetSecurityVendorDataQuery(
    Guid     SecurityId,
    string?  FieldName      = null,
    Guid?    VendorSourceId = null,
    DateTime? From          = null,
    DateTime? To            = null,
    int      PageNumber     = 1,
    int      PageSize       = 50) : IQuery<PagedResult<SecurityVendorDataDto>>;
