using Mediator;
using SecurityApp.Core.VendorSources.Entities;
using SecurityApp.Core.VendorSources.Interfaces;
using SecurityApp.Core.Shared.Exceptions;
using SecurityApp.Application.VendorSources.Commands;
using SecurityApp.Application.VendorSources.DTOs;

namespace SecurityApp.Application.VendorSources.Handlers;

// -- CreateVendorSource --------------------------------------------------------

public class CreateVendorSourceHandler : ICommandHandler<CreateVendorSourceCommand, CreateVendorSourceResponse>
{
    private readonly IVendorSourcesUoW _uow;

    public CreateVendorSourceHandler(IVendorSourcesUoW uow) => _uow = uow;

    public async ValueTask<CreateVendorSourceResponse> Handle(CreateVendorSourceCommand command, CancellationToken cancellationToken)
    {
        var existing = await _uow.VendorSources.FindAsync(
            v => v.Code == command.Dto.Code.ToUpperInvariant() && v.IsCurrent && !v.IsDeleted,
            cancellationToken);

        if (existing.Any())
            throw new DuplicateKeyException($"A vendor source with code '{command.Dto.Code}' already exists.");

        var vendor = new VendorSource
        {
            Code                    = command.Dto.Code.Trim().ToUpperInvariant(),
            DisplayName             = command.Dto.DisplayName.Trim(),
            GlobalPriority          = command.Dto.GlobalPriority,
            StalenessThresholdHours = command.Dto.StalenessThresholdHours,
            IsActive                = command.Dto.IsActive,
            LastModifiedBy              = command.UserId,
        };

        await _uow.VendorSources.AddAsync(vendor, cancellationToken);
        await _uow.SaveChangesAsync(cancellationToken);

        return new CreateVendorSourceResponse(vendor.Id, "Created");
    }
}

// -- UpdateVendorSource --------------------------------------------------------

public class UpdateVendorSourceHandler : ICommandHandler<UpdateVendorSourceCommand>
{
    private readonly IVendorSourcesUoW _uow;

    public UpdateVendorSourceHandler(IVendorSourcesUoW uow) => _uow = uow;

    public async ValueTask<Unit> Handle(UpdateVendorSourceCommand command, CancellationToken cancellationToken)
    {
        var vendor = await _uow.VendorSources.GetByIdAsync(command.VendorSourceId, cancellationToken)
            ?? throw new NotFoundException($"VendorSource {command.VendorSourceId} not found.");

        var upperCode = command.Dto.Code.Trim().ToUpperInvariant();
        if (!string.Equals(vendor.Code, upperCode, StringComparison.Ordinal))
        {
            var conflict = await _uow.VendorSources.FindAsync(
                v => v.Code == upperCode && v.IsCurrent && !v.IsDeleted && v.Id != command.VendorSourceId,
                cancellationToken);
            if (conflict.Any())
                throw new DuplicateKeyException($"A vendor source with code '{upperCode}' already exists.");
        }

        vendor.Code                    = upperCode;
        vendor.DisplayName             = command.Dto.DisplayName.Trim();
        vendor.GlobalPriority          = command.Dto.GlobalPriority;
        vendor.StalenessThresholdHours = command.Dto.StalenessThresholdHours;
        vendor.IsActive                = command.Dto.IsActive;
        vendor.LastModifiedBy              = command.UserId;
        vendor.LastModifiedAt               = DateTime.UtcNow;

        await _uow.VendorSources.UpdateAsync(vendor, cancellationToken);
        await _uow.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

// -- DeleteVendorSource --------------------------------------------------------

public class DeleteVendorSourceHandler : ICommandHandler<DeleteVendorSourceCommand>
{
    private readonly IVendorSourcesUoW _uow;

    public DeleteVendorSourceHandler(IVendorSourcesUoW uow) => _uow = uow;

    public async ValueTask<Unit> Handle(DeleteVendorSourceCommand command, CancellationToken cancellationToken)
    {
        var vendor = await _uow.VendorSources.GetByIdAsync(command.VendorSourceId, cancellationToken)
            ?? throw new NotFoundException($"VendorSource {command.VendorSourceId} not found.");

        vendor.IsDeleted  = true;
        vendor.IsCurrent  = false;
        vendor.LastModifiedAt  = DateTime.UtcNow;

        await _uow.VendorSources.UpdateAsync(vendor, cancellationToken);
        await _uow.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

// -- UpsertFieldPriority -------------------------------------------------------

public class UpsertFieldPriorityHandler : ICommandHandler<UpsertFieldPriorityCommand, UpsertFieldPriorityResponse>
{
    private readonly IVendorSourcesUoW _uow;

    public UpsertFieldPriorityHandler(IVendorSourcesUoW uow) => _uow = uow;

    public async ValueTask<UpsertFieldPriorityResponse> Handle(UpsertFieldPriorityCommand command, CancellationToken cancellationToken)
    {
        var vendor = await _uow.VendorSources.GetByIdAsync(command.VendorSourceId, cancellationToken)
            ?? throw new NotFoundException($"VendorSource {command.VendorSourceId} not found.");

        var existing = (await _uow.VendorFieldPriorities.FindAsync(
            fp => fp.VendorSourceId   == command.VendorSourceId
               && fp.FieldName        == command.Dto.FieldName
               && fp.AssetClassCode   == command.Dto.AssetClassCode
               && fp.IsCurrent && !fp.IsDeleted,
            cancellationToken)).FirstOrDefault();

        if (existing is not null)
        {
            existing.Priority      = command.Dto.Priority;
            existing.IsActive      = command.Dto.IsActive;
            existing.LastModifiedBy    = command.UserId;
            existing.LastModifiedAt     = DateTime.UtcNow;

            await _uow.VendorFieldPriorities.UpdateAsync(existing, cancellationToken);
            await _uow.SaveChangesAsync(cancellationToken);
            return new UpsertFieldPriorityResponse(existing.Id, "Updated");
        }

        var fp = new VendorFieldPriority
        {
            VendorSourceId = command.VendorSourceId,
            FieldName      = command.Dto.FieldName.Trim(),
            AssetClassCode = command.Dto.AssetClassCode?.Trim(),
            Priority       = command.Dto.Priority,
            IsActive       = command.Dto.IsActive,
            LastModifiedBy     = command.UserId,
        };

        await _uow.VendorFieldPriorities.AddAsync(fp, cancellationToken);
        await _uow.SaveChangesAsync(cancellationToken);
        return new UpsertFieldPriorityResponse(fp.Id, "Created");
    }
}

// -- UpdateFieldPriority -------------------------------------------------------

public class UpdateFieldPriorityHandler : ICommandHandler<UpdateFieldPriorityCommand>
{
    private readonly IVendorSourcesUoW _uow;

    public UpdateFieldPriorityHandler(IVendorSourcesUoW uow) => _uow = uow;

    public async ValueTask<Unit> Handle(UpdateFieldPriorityCommand command, CancellationToken cancellationToken)
    {
        var fp = await _uow.VendorFieldPriorities.GetByIdAsync(command.FieldPriorityId, cancellationToken)
            ?? throw new NotFoundException($"VendorFieldPriority {command.FieldPriorityId} not found.");

        fp.FieldName      = command.Dto.FieldName.Trim();
        fp.AssetClassCode = command.Dto.AssetClassCode?.Trim();
        fp.Priority       = command.Dto.Priority;
        fp.IsActive       = command.Dto.IsActive;
        fp.LastModifiedBy     = command.UserId;
        fp.LastModifiedAt      = DateTime.UtcNow;

        await _uow.VendorFieldPriorities.UpdateAsync(fp, cancellationToken);
        await _uow.SaveChangesAsync(cancellationToken);
        return Unit.Value;
    }
}

// -- DeleteFieldPriority -------------------------------------------------------

public class DeleteFieldPriorityHandler : ICommandHandler<DeleteFieldPriorityCommand>
{
    private readonly IVendorSourcesUoW _uow;

    public DeleteFieldPriorityHandler(IVendorSourcesUoW uow) => _uow = uow;

    public async ValueTask<Unit> Handle(DeleteFieldPriorityCommand command, CancellationToken cancellationToken)
    {
        var fp = await _uow.VendorFieldPriorities.GetByIdAsync(command.FieldPriorityId, cancellationToken)
            ?? throw new NotFoundException($"VendorFieldPriority {command.FieldPriorityId} not found.");

        fp.IsDeleted = true;
        fp.IsCurrent = false;
        fp.LastModifiedAt = DateTime.UtcNow;

        await _uow.VendorFieldPriorities.UpdateAsync(fp, cancellationToken);
        await _uow.SaveChangesAsync(cancellationToken);
        return Unit.Value;
    }
}
