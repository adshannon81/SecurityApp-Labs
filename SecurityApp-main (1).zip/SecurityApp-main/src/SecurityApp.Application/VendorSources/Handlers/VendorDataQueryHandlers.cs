using Mediator;
using SecurityApp.Application.Shared;
using SecurityApp.Application.VendorSources.DTOs;
using SecurityApp.Application.VendorSources.Queries;
using SecurityApp.Core.VendorSources.Interfaces;

namespace SecurityApp.Application.VendorSources.Handlers;

public sealed class GetSecurityVendorDataHandler
    : IQueryHandler<GetSecurityVendorDataQuery, PagedResult<SecurityVendorDataDto>>
{
    private readonly IVendorSourcesUoW _uow;

    public GetSecurityVendorDataHandler(IVendorSourcesUoW uow) => _uow = uow;

    public async ValueTask<PagedResult<SecurityVendorDataDto>> Handle(
        GetSecurityVendorDataQuery query,
        CancellationToken cancellationToken)
    {
        var (items, totalCount) = await _uow.SecurityVendorData.GetPagedAsync(
            predicate: r => r.SecurityId == query.SecurityId
                         && (query.FieldName      == null || r.FieldName      == query.FieldName)
                         && (query.VendorSourceId == null || r.VendorSourceId == query.VendorSourceId)
                         && (query.From           == null || r.ReceivedAt     >= query.From)
                         && (query.To             == null || r.ReceivedAt     <= query.To),
            orderBy:    r => r.ReceivedAt,
            descending: true,
            page:       query.PageNumber,
            pageSize:   query.PageSize,
            cancellationToken);

        // Resolve vendor source names for the fetched rows
        var vendorIds = items.Select(r => r.VendorSourceId).Distinct().ToList();
        var vendors   = (await _uow.VendorSources.FindAsync(
                            v => vendorIds.Contains(v.Id), cancellationToken))
                        .ToDictionary(v => v.Id);

        var dtos = items.Select(r =>
        {
            vendors.TryGetValue(r.VendorSourceId, out var vs);
            return new SecurityVendorDataDto
            {
                Id             = r.Id,
                SecurityId     = r.SecurityId,
                VendorSourceId = r.VendorSourceId,
                VendorCode     = vs?.Code,
                VendorName     = vs?.DisplayName,
                FieldName      = r.FieldName,
                RawValue       = r.RawValue,
                FeedBatchId    = r.FeedBatchId,
                ReceivedAt     = r.ReceivedAt,
                CreatedAt      = r.CreatedAt
            };
        }).ToList();

        return new PagedResult<SecurityVendorDataDto>(
            Items:      dtos,
            TotalCount: totalCount,
            PageNumber: query.PageNumber,
            PageSize:   query.PageSize);
    }
}
