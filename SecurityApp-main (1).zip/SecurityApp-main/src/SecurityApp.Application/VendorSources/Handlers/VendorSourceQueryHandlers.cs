using Mediator;
using SecurityApp.Core.VendorSources.Interfaces;
using SecurityApp.Core.Users;
using SecurityApp.Application.VendorSources.Queries;
using SecurityApp.Application.VendorSources.DTOs;

namespace SecurityApp.Application.VendorSources.Handlers;

// -- GetAllVendorSources -------------------------------------------------------

public class GetAllVendorSourcesHandler : IQueryHandler<GetAllVendorSourcesQuery, List<VendorSourceDto>>
{
    private readonly IVendorSourcesUoW _uow;
    private readonly IUserCacheService _userCache;

    public GetAllVendorSourcesHandler(IVendorSourcesUoW uow, IUserCacheService userCache)
    {
        _uow = uow;
        _userCache = userCache;
    }

    public async ValueTask<List<VendorSourceDto>> Handle(GetAllVendorSourcesQuery query, CancellationToken cancellationToken)
    {
        var vendors = await _uow.VendorSources.FindAsync(
            v => query.IncludeInactive || v.IsActive,
            cancellationToken);

        var result = new List<VendorSourceDto>();
        foreach (var v in vendors.OrderBy(v => v.GlobalPriority))
        {
            var dto = VendorSourceDto.FromEntity(v, _userCache.ResolveDisplayName);
            dto.FieldPriorities = (await _uow.VendorFieldPriorities.FindAsync(
                fp => fp.VendorSourceId == v.Id,
                cancellationToken))
                .Select(VendorFieldPriorityDto.FromEntity)
                .ToList();
            result.Add(dto);
        }
        return result;
    }
}

// -- GetVendorSourceById -------------------------------------------------------

public class GetVendorSourceByIdHandler : IQueryHandler<GetVendorSourceByIdQuery, VendorSourceDto?>
{
    private readonly IVendorSourcesUoW _uow;
    private readonly IUserCacheService _userCache;

    public GetVendorSourceByIdHandler(IVendorSourcesUoW uow, IUserCacheService userCache)
    {
        _uow = uow;
        _userCache = userCache;
    }

    public async ValueTask<VendorSourceDto?> Handle(GetVendorSourceByIdQuery query, CancellationToken cancellationToken)
    {
        var vendor = await _uow.VendorSources.GetByIdAsync(query.VendorSourceId, cancellationToken);
        if (vendor is null) return null;

        var dto = VendorSourceDto.FromEntity(vendor, _userCache.ResolveDisplayName);
        dto.FieldPriorities = (await _uow.VendorFieldPriorities.FindAsync(
            fp => fp.VendorSourceId == vendor.Id,
            cancellationToken))
            .Select(VendorFieldPriorityDto.FromEntity)
            .ToList();
        return dto;
    }
}

// -- GetFieldPriorities --------------------------------------------------------

public class GetFieldPrioritiesHandler : IQueryHandler<GetFieldPrioritiesQuery, List<VendorFieldPriorityDto>>
{
    private readonly IVendorSourcesUoW _uow;

    public GetFieldPrioritiesHandler(IVendorSourcesUoW uow) => _uow = uow;

    public async ValueTask<List<VendorFieldPriorityDto>> Handle(GetFieldPrioritiesQuery query, CancellationToken cancellationToken)
    {
        var priorities = await _uow.VendorFieldPriorities.FindAsync(
            fp => fp.VendorSourceId == query.VendorSourceId,
            cancellationToken);

        return priorities
            .OrderBy(fp => fp.Priority)
            .Select(VendorFieldPriorityDto.FromEntity)
            .ToList();
    }
}
