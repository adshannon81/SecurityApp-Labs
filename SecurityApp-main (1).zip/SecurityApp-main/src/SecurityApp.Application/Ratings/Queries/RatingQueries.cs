﻿using Mediator;
using SecurityApp.Application.Ratings.DTOs;
using SecurityApp.Application.Shared;

namespace SecurityApp.Application.Ratings.Queries;

/// <summary>Gets the current derived rating for a security, rendered in one or more agency notations.</summary>
public record GetDerivedRatingQuery(
    Guid SecurityId,
    /// <summary>Comma-separated agency names, e.g. "SP,Moodys,Fitch". Null â†’ use configured default.</summary>
    string? Agencies = null) : IQuery<DerivedRatingDto?>;

/// <summary>Gets the paginated audit trail for a security's rating history.</summary>
public record GetRatingAuditLogQuery(
    Guid SecurityId,
    int PageNumber = 1,
    int PageSize = 20) : IQuery<PagedResult<RatingAuditLogDto>>;

/// <summary>Returns the raw JSON config for a named rating model.</summary>
public record GetRatingModelConfigQuery(
    string ModelName) : IQuery<string>;

/// <summary>
/// Returns all current derivation rules, optionally filtered by model name.
/// Pass <paramref name="AsOf"/> to query the rules that were effective on a historical date.
/// </summary>
public record GetRatingDerivationRulesQuery(
    string? ModelName = null,
    DateTime? AsOf    = null) : IQuery<IEnumerable<RatingDerivationRuleDto>>;

/// <summary>
/// Returns all current scale entries, optionally filtered by agency.
/// </summary>
public record GetRatingScalesQuery(
    string? Agency = null) : IQuery<IEnumerable<RatingScaleEntryDto>>;
