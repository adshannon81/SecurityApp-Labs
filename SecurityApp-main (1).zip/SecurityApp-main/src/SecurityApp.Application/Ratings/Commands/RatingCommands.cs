﻿using Mediator;
using SecurityApp.Application.Ratings.DTOs;
using SecurityApp.Core.Workflow.Enums;
using SecurityApp.Core.Workflow.Interfaces;

namespace SecurityApp.Application.Ratings.Commands;

/// <summary>Triggers the full rating pipeline (MICR + VPM + Fundamental + Composite) for one security.</summary>
public record CalculateDerivedRatingCommand(
    Guid SecurityId,
    string? UserId,
    DateTime? EvaluationDate = null) : ICommand<DerivedRatingDto>, IWorkflowGuardedCommand
{
    public WorkflowTriggerType WorkflowTrigger   => WorkflowTriggerType.CreditRatingUpdate;
    public Guid                WorkflowEntityId  => SecurityId;
    public string              WorkflowEntityType => "Security";
}

/// <summary>Runs the pipeline for multiple securities; returns a summary per security.</summary>
public record CalculateBatchDerivedRatingsCommand(
    IReadOnlyList<Guid> SecurityIds,
    string? UserId,
    DateTime? EvaluationDate = null) : ICommand<BatchRatingResultDto>;

/// <summary>Hot-reloads a model config JSON without restarting the application.</summary>
public record UpdateRatingModelConfigCommand(
    string ModelName,
    string Json,
    string? UserId) : ICommand;

/// <summary>
/// Creates a new version of a derivation rule for a given model / security-type combination.
/// The previous current version is expired (bi-temporal insert-only pattern).
/// </summary>
public record UpsertRatingDerivationRuleCommand(
    string ModelName,
    string? SecurityType,
    DateTime EffectiveFrom,
    DateTime EffectiveTo,
    string ConfigJson,
    string? Description,
    string? UserId) : ICommand<RatingDerivationRuleDto>;

/// <summary>
/// Soft-expires a derivation rule by ID (sets IsCurrent=false, ValidTo=now).
/// No data is physically deleted.
/// </summary>
public record DeleteRatingDerivationRuleCommand(
    Guid RuleId,
    string? UserId) : ICommand;

/// <summary>
/// Bulk-replaces all current rating scale entries from a JSON payload
/// (same format as rating-scales.json). Existing rows are expired bi-temporally.
/// </summary>
public record SeedRatingScalesCommand(
    string Json,
    string? UserId) : ICommand;

/// <summary>Creates a single rating scale entry (bi-temporal, IsCurrent=true).</summary>
public record CreateRatingScaleEntryCommand(
    string Agency,
    int Score,
    string Label,
    bool IsInvestmentGrade,
    DateTime ValidFrom,
    DateTime ValidTo,
    string? UserId) : ICommand<RatingScaleEntryDto>;

/// <summary>Replaces the label / grade flag on an existing entry (bi-temporal update).</summary>
public record UpdateRatingScaleEntryCommand(
    Guid EntryId,
    string Label,
    bool IsInvestmentGrade,
    DateTime ValidFrom,
    DateTime ValidTo,
    string? UserId) : ICommand<RatingScaleEntryDto>;

/// <summary>Soft-expires a single scale entry by ID.</summary>
public record DeleteRatingScaleEntryCommand(
    Guid EntryId,
    string? UserId) : ICommand;
