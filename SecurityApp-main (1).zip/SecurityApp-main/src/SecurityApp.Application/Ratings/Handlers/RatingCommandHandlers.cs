using System.Collections.Concurrent;
using Mediator;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using SecurityApp.Core.Grpc;
using SecurityApp.Core.Ratings.Models;
using SecurityApp.Core.Ratings.Interfaces;
using SecurityApp.Application.Ratings.Commands;
using SecurityApp.Application.Ratings.DTOs;
using SecurityApp.Core.Audit.Entities;
using SecurityApp.Core.Ratings.Entities;
using SecurityApp.Core.Audit.Enums;

namespace SecurityApp.Application.Ratings.Handlers;

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// CalculateDerivedRatingHandler
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

public sealed class CalculateDerivedRatingHandler
    : ICommandHandler<CalculateDerivedRatingCommand, DerivedRatingDto>
{
    private readonly IRatingPipelineRunner _pipeline;
    private readonly IRatingScaleService _scales;
    private readonly ILogger<CalculateDerivedRatingHandler> _logger;

    public CalculateDerivedRatingHandler(
        IRatingPipelineRunner pipeline,
        IRatingScaleService scales,
        ILogger<CalculateDerivedRatingHandler> logger)
    {
        _pipeline = pipeline;
        _scales   = scales;
        _logger   = logger;
    }

    public async ValueTask<DerivedRatingDto> Handle(
        CalculateDerivedRatingCommand command,
        CancellationToken cancellationToken)
    {
        var result = await _pipeline.RunAsync(
            command.SecurityId, command.UserId, command.EvaluationDate, cancellationToken);

        return MapToDto(result, null);
    }

    internal DerivedRatingDto MapToDto(DerivedRatingResult result, string[]? requestedAgencies)
    {
        var agencies = requestedAgencies?.Length > 0
            ? requestedAgencies
            : new[] { result.OutputAgency };

        return new DerivedRatingDto
        {
            SecurityId               = result.SecurityId,
            ImpliedRatingScore       = result.Micr?.Score,
            VpmRatingScore           = result.Vpm?.Score,
            FundamentalRatingScore   = result.Fundamental?.Score,
            CompositeRatingScore     = result.Composite?.Score,
            ImpliedPd                = result.Micr?.ImpliedPd is double ipd ? (decimal?)Convert.ToDecimal(ipd) : null,
            ModelPd                  = result.Fundamental?.EstimatedPd is double epd ? (decimal?)Convert.ToDecimal(epd) : null,
            FairPrice                = result.Micr?.FairPrice,
            IsInvestmentGrade        = result.Composite is not null && _scales.IsInvestmentGrade(result.Composite.Score),
            WasSkipped               = result.WasSkipped,
            LastCalculatedUtc        = result.CalculatedAt,
            OutputAgency             = result.OutputAgency,
            CompositeRatingsByAgency = result.Composite is null ? []
                : agencies.ToDictionary(a => a, a => (string?)_scales.GetLabel(a, result.Composite.Score)),
            ImpliedRatingsByAgency   = result.Micr is null ? []
                : agencies.ToDictionary(a => a, a => (string?)_scales.GetLabel(a, result.Micr.Score)),
            VpmRatingsByAgency       = result.Vpm is null ? []
                : agencies.ToDictionary(a => a, a => (string?)_scales.GetLabel(a, result.Vpm.Score)),
            FundamentalRatingsByAgency = result.Fundamental is null ? []
                : agencies.ToDictionary(a => a, a => (string?)_scales.GetLabel(a, result.Fundamental.Score))
        };
    }
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// CalculateBatchDerivedRatingsHandler
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

public sealed class CalculateBatchDerivedRatingsHandler
    : ICommandHandler<CalculateBatchDerivedRatingsCommand, BatchRatingResultDto>
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<CalculateBatchDerivedRatingsHandler> _logger;

    public CalculateBatchDerivedRatingsHandler(
        IServiceScopeFactory scopeFactory,
        ILogger<CalculateBatchDerivedRatingsHandler> logger)
    {
        _scopeFactory = scopeFactory;
        _logger       = logger;
    }

    public async ValueTask<BatchRatingResultDto> Handle(
        CalculateBatchDerivedRatingsCommand command,
        CancellationToken cancellationToken)
    {
        int succeeded = 0, skipped = 0, failed = 0;
        var items = new ConcurrentBag<BatchRatingItemDto>();
        var sem   = new SemaphoreSlim(20, 20);

        var tasks = command.SecurityIds.Select(async id =>
        {
            await sem.WaitAsync(cancellationToken);
            try
            {
                // Each parallel branch gets its own DI scope (and therefore its own DbContext)
                using var scope    = _scopeFactory.CreateScope();
                var pipeline       = scope.ServiceProvider.GetRequiredService<IRatingPipelineRunner>();
                var r              = await pipeline.RunAsync(id, command.UserId, command.EvaluationDate, cancellationToken);

                if (r.WasSkipped) Interlocked.Increment(ref skipped);
                else              Interlocked.Increment(ref succeeded);

                items.Add(new BatchRatingItemDto
                {
                    SecurityId     = id,
                    Succeeded      = true,
                    Skipped        = r.WasSkipped,
                    CompositeScore = r.Composite?.Score,
                    CompositeLabel = r.CompositeRatingLabel
                });
            }
            catch (Exception ex)
            {
                Interlocked.Increment(ref failed);
                _logger.LogWarning(ex, "Batch rating failed for security {SecurityId}", id);
                items.Add(new BatchRatingItemDto { SecurityId = id, Succeeded = false, Error = ex.Message });
            }
            finally
            {
                sem.Release();
            }
        });

        await Task.WhenAll(tasks);

        return new BatchRatingResultDto
        {
            Total     = command.SecurityIds.Count,
            Succeeded = succeeded,
            Skipped   = skipped,
            Failed    = failed,
            Items     = items.ToList()
        };
    }
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// UpdateRatingModelConfigHandler
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

public sealed class UpdateRatingModelConfigHandler
    : ICommandHandler<UpdateRatingModelConfigCommand>
{
    private readonly IRatingModelConfigService _configs;

    public UpdateRatingModelConfigHandler(IRatingModelConfigService configs)
        => _configs = configs;

    public async ValueTask<Unit> Handle(
        UpdateRatingModelConfigCommand command,
        CancellationToken cancellationToken)
    {
        await _configs.ReloadAsync(command.ModelName, command.Json, command.UserId, cancellationToken);
        return Unit.Value;
    }
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// UpsertRatingDerivationRuleHandler
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

public sealed class UpsertRatingDerivationRuleHandler
    : ICommandHandler<UpsertRatingDerivationRuleCommand, RatingDerivationRuleDto>
{
    private readonly IRatingModelConfigService _configs;
    private readonly IGrpcEventPublisher _grpc;
    private readonly ILogger<UpsertRatingDerivationRuleHandler> _logger;

    public UpsertRatingDerivationRuleHandler(
        IRatingModelConfigService configs,
        IGrpcEventPublisher grpc,
        ILogger<UpsertRatingDerivationRuleHandler> logger)
    {
        _configs = configs;
        _grpc    = grpc;
        _logger  = logger;
    }

    public async ValueTask<RatingDerivationRuleDto> Handle(
        UpsertRatingDerivationRuleCommand command,
        CancellationToken cancellationToken)
    {
        // Delegate to ReloadAsync with a synthetic flat-config JSON
        // (the command's ConfigJson is the flat model config blob).
        // This handles bi-temporal expiry + audit automatically.
        await _configs.ReloadAsync(
            command.ModelName,
            BuildVersionedJson(command),
            command.UserId,
            cancellationToken);

        _logger.LogInformation(
            "Derivation rule upserted for model={Model}, securityType={Type}, effectiveFrom={From}",
            command.ModelName, command.SecurityType ?? "<all>", command.EffectiveFrom);

        await _grpc.PublishRefDataChangedAsync(new RefDataChangedPayload("DerivationRule", command.UserId ?? string.Empty), cancellationToken);

        return new RatingDerivationRuleDto
        {
            ModelName     = command.ModelName,
            SecurityType  = command.SecurityType,
            EffectiveFrom = command.EffectiveFrom,
            EffectiveTo   = command.EffectiveTo,
            ConfigJson    = command.ConfigJson,
            Description   = command.Description,
            CreatedAt     = DateTime.UtcNow,
            LastModifiedBy    = command.UserId
        };
    }

    private static string BuildVersionedJson(UpsertRatingDerivationRuleCommand cmd)
    {
        // Wrap the flat config in the versioned structure so ReloadAsync handles it uniformly.
        var secTypes = cmd.SecurityType is null ? "[]" : $"[\"{cmd.SecurityType}\"]";
        var from     = cmd.EffectiveFrom.ToString("yyyy-MM-dd");
        var to       = cmd.EffectiveTo == DateTime.MaxValue ? "9999-12-31" : cmd.EffectiveTo.ToString("yyyy-MM-dd");
        return $$"""
            {
              "versions": [
                {
                  "effectiveFrom": "{{from}}",
                  "effectiveTo":   "{{to}}",
                  "securityTypes": {{secTypes}},
                  "config": {{cmd.ConfigJson}}
                }
              ]
            }
            """;
    }
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// DeleteRatingDerivationRuleHandler
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

public sealed class DeleteRatingDerivationRuleHandler
    : ICommandHandler<DeleteRatingDerivationRuleCommand>
{
    private readonly IRatingsUoW _uow;
    private readonly IGrpcEventPublisher _grpc;

    public DeleteRatingDerivationRuleHandler(IRatingsUoW uow, IGrpcEventPublisher grpc) { _uow = uow; _grpc = grpc; }

    public async ValueTask<Unit> Handle(
        DeleteRatingDerivationRuleCommand command,
        CancellationToken cancellationToken)
    {
        var rule = (await _uow.RatingDerivationRules.FindAsync(
            r => r.Id == command.RuleId, cancellationToken))
            .FirstOrDefault()
            ?? throw new KeyNotFoundException($"Derivation rule {command.RuleId} not found.");

        var now = DateTime.UtcNow;
        rule.IsCurrent  = false;
        rule.ValidTo    = now;
        rule.SystemTo   = now;
        rule.LastModifiedBy = command.UserId;
        await _uow.RatingDerivationRules.UpdateAsync(rule, cancellationToken);

        await _uow.AuditLogs.AddAsync(new AuditLog
        {
            EntityType = nameof(RatingDerivationRule),
            Action     = AuditAction.Delete,
            UserName   = command.UserId,
            EntityId   = command.RuleId,
            Details    = $"Rule {command.RuleId} (model={rule.ModelName}, type={rule.SecurityType}) expired."
        }, cancellationToken);

        await _uow.SaveChangesAsync(cancellationToken);
        await _grpc.PublishRefDataChangedAsync(new RefDataChangedPayload("DerivationRule", command.UserId ?? string.Empty), cancellationToken);
        return Unit.Value;
    }
}

// --------------------------------------------------------------------------------------
// SeedRatingScalesHandler
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

public sealed class SeedRatingScalesHandler
    : ICommandHandler<SeedRatingScalesCommand>
{
    private readonly IRatingScaleService _scales;

    public SeedRatingScalesHandler(IRatingScaleService scales) => _scales = scales;

    public async ValueTask<Unit> Handle(
        SeedRatingScalesCommand command,
        CancellationToken cancellationToken)
    {
        await _scales.ReloadAsync(command.Json, command.UserId, cancellationToken);
        return Unit.Value;
    }
}

// --------------------------------------------------------------------------------------
// CreateRatingScaleEntryHandler
// --------------------------------------------------------------------------------------

public sealed class CreateRatingScaleEntryHandler
    : ICommandHandler<CreateRatingScaleEntryCommand, RatingScaleEntryDto>
{
    private readonly IRatingsUoW _uow;
    private readonly IGrpcEventPublisher _grpc;

    public CreateRatingScaleEntryHandler(IRatingsUoW uow, IGrpcEventPublisher grpc) { _uow = uow; _grpc = grpc; }

    public async ValueTask<RatingScaleEntryDto> Handle(
        CreateRatingScaleEntryCommand command,
        CancellationToken cancellationToken)
    {
        var entry = new RatingScaleEntry
        {
            Agency            = command.Agency,
            Score             = command.Score,
            Label             = command.Label,
            IsInvestmentGrade = command.IsInvestmentGrade,
            ValidFrom         = command.ValidFrom,
            ValidTo           = command.ValidTo,
            SystemFrom        = DateTime.UtcNow,
            IsCurrent         = true,
            LastModifiedBy        = command.UserId,
        };

        await _uow.RatingScaleEntries.AddAsync(entry, cancellationToken);
        await _uow.SaveChangesAsync(cancellationToken);
        await _grpc.PublishRefDataChangedAsync(new RefDataChangedPayload("RatingScale", command.UserId ?? string.Empty), cancellationToken);

        return new RatingScaleEntryDto
        {
            Id                = entry.Id,
            Agency            = entry.Agency,
            Score             = entry.Score,
            Label             = entry.Label,
            IsInvestmentGrade = entry.IsInvestmentGrade,
            ValidFrom         = entry.ValidFrom,
            ValidTo           = entry.ValidTo,
            CreatedAt         = entry.CreatedAt,
            CreatedBy         = entry.CreatedBy,
            LastModifiedAt    = entry.LastModifiedAt,
            LastModifiedBy    = entry.LastModifiedBy,
        };
    }
}

// --------------------------------------------------------------------------------------
// UpdateRatingScaleEntryHandler
// --------------------------------------------------------------------------------------

public sealed class UpdateRatingScaleEntryHandler
    : ICommandHandler<UpdateRatingScaleEntryCommand, RatingScaleEntryDto>
{
    private readonly IRatingsUoW _uow;
    private readonly IGrpcEventPublisher _grpc;

    public UpdateRatingScaleEntryHandler(IRatingsUoW uow, IGrpcEventPublisher grpc) { _uow = uow; _grpc = grpc; }

    public async ValueTask<RatingScaleEntryDto> Handle(
        UpdateRatingScaleEntryCommand command,
        CancellationToken cancellationToken)
    {
        var entry = (await _uow.RatingScaleEntries.FindAsync(
            e => e.Id == command.EntryId, cancellationToken))
            .FirstOrDefault()
            ?? throw new KeyNotFoundException($"RatingScaleEntry {command.EntryId} not found.");

        // Bi-temporal: expire the old row and update in-place (IsCurrent remains true)
        entry.Label             = command.Label;
        entry.IsInvestmentGrade = command.IsInvestmentGrade;
        entry.ValidFrom         = command.ValidFrom;
        entry.ValidTo           = command.ValidTo;
        entry.SystemFrom        = DateTime.UtcNow;
        entry.LastModifiedBy        = command.UserId;

        await _uow.RatingScaleEntries.UpdateAsync(entry, cancellationToken);
        await _uow.SaveChangesAsync(cancellationToken);
        await _grpc.PublishRefDataChangedAsync(new RefDataChangedPayload("RatingScale", command.UserId ?? string.Empty), cancellationToken);

        return new RatingScaleEntryDto
        {
            Id                = entry.Id,
            Agency            = entry.Agency,
            Score             = entry.Score,
            Label             = entry.Label,
            IsInvestmentGrade = entry.IsInvestmentGrade,
            ValidFrom         = entry.ValidFrom,
            ValidTo           = entry.ValidTo,
            CreatedAt         = entry.CreatedAt,
            CreatedBy         = entry.CreatedBy,
            LastModifiedAt    = entry.LastModifiedAt,
            LastModifiedBy    = entry.LastModifiedBy,
        };
    }
}

// --------------------------------------------------------------------------------------
// DeleteRatingScaleEntryHandler
// --------------------------------------------------------------------------------------

public sealed class DeleteRatingScaleEntryHandler
    : ICommandHandler<DeleteRatingScaleEntryCommand>
{
    private readonly IRatingsUoW _uow;
    private readonly IGrpcEventPublisher _grpc;

    public DeleteRatingScaleEntryHandler(IRatingsUoW uow, IGrpcEventPublisher grpc) { _uow = uow; _grpc = grpc; }

    public async ValueTask<Unit> Handle(
        DeleteRatingScaleEntryCommand command,
        CancellationToken cancellationToken)
    {
        var entry = (await _uow.RatingScaleEntries.FindAsync(
            e => e.Id == command.EntryId, cancellationToken))
            .FirstOrDefault()
            ?? throw new KeyNotFoundException($"RatingScaleEntry {command.EntryId} not found.");

        var now = DateTime.UtcNow;
        entry.IsCurrent  = false;
        entry.IsDeleted  = true;
        entry.ValidTo    = now;
        entry.SystemTo   = now;
        entry.LastModifiedBy = command.UserId;

        await _uow.RatingScaleEntries.UpdateAsync(entry, cancellationToken);
        await _uow.SaveChangesAsync(cancellationToken);
        await _grpc.PublishRefDataChangedAsync(new RefDataChangedPayload("RatingScale", command.UserId ?? string.Empty), cancellationToken);
        return Unit.Value;
    }
}
