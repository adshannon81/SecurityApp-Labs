using Mediator;
using SecurityApp.Core.Ratings.Interfaces;
using SecurityApp.Core.Users;
using SecurityApp.Application.Ratings.Queries;
using SecurityApp.Application.Ratings.DTOs;
using SecurityApp.Application.Shared;

namespace SecurityApp.Application.Ratings.Handlers;

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// GetDerivedRatingHandler
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

public sealed class GetDerivedRatingHandler
    : IQueryHandler<GetDerivedRatingQuery, DerivedRatingDto?>
{
    private readonly IRatingsUoW _uow;
    private readonly IRatingScaleService _scales;

    public GetDerivedRatingHandler(IRatingsUoW uow, IRatingScaleService scales)
    {
        _uow    = uow;
        _scales = scales;
    }

    public async ValueTask<DerivedRatingDto?> Handle(
        GetDerivedRatingQuery query,
        CancellationToken cancellationToken)
    {
        var matches = await _uow.DerivedRatings.FindAsync(
            d => d.SecurityId == query.SecurityId && d.IsCurrent,
            cancellationToken);
        var current = matches.FirstOrDefault();

        if (current is null) return null;

        var agencies = string.IsNullOrWhiteSpace(query.Agencies)
            ? new[] { current.OutputAgency }
            : query.Agencies.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        return new DerivedRatingDto
        {
            SecurityId             = current.SecurityId,
            ImpliedRatingScore     = current.ImpliedRatingScore,
            VpmRatingScore         = current.VpmRatingScore,
            FundamentalRatingScore = current.FundamentalRatingScore,
            CompositeRatingScore   = current.CompositeRatingScore,
            ImpliedPd              = current.ImpliedPd,
            ModelPd                = current.ModelPd,
            FairPrice              = current.FairPrice,
            IsInvestmentGrade      = current.CompositeRatingScore.HasValue
                                     && _scales.IsInvestmentGrade(current.CompositeRatingScore.Value),
            WasSkipped             = false,
            LastCalculatedUtc      = current.LastCalculatedUtc,
            OutputAgency           = current.OutputAgency,
            CompositeRatingsByAgency = current.CompositeRatingScore.HasValue
                ? agencies.ToDictionary(a => a, a => (string?)_scales.GetLabel(a, current.CompositeRatingScore.Value))
                : [],
            ImpliedRatingsByAgency = current.ImpliedRatingScore.HasValue
                ? agencies.ToDictionary(a => a, a => (string?)_scales.GetLabel(a, current.ImpliedRatingScore.Value))
                : [],
            VpmRatingsByAgency = current.VpmRatingScore.HasValue
                ? agencies.ToDictionary(a => a, a => (string?)_scales.GetLabel(a, current.VpmRatingScore.Value))
                : [],
            FundamentalRatingsByAgency = current.FundamentalRatingScore.HasValue
                ? agencies.ToDictionary(a => a, a => (string?)_scales.GetLabel(a, current.FundamentalRatingScore.Value))
                : []
        };
    }
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// GetRatingAuditLogHandler
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

public sealed class GetRatingAuditLogHandler
    : IQueryHandler<GetRatingAuditLogQuery, PagedResult<RatingAuditLogDto>>
{
    private readonly IRatingsUoW _uow;

    public GetRatingAuditLogHandler(IRatingsUoW uow) => _uow = uow;

    public async ValueTask<PagedResult<RatingAuditLogDto>> Handle(
        GetRatingAuditLogQuery query,
        CancellationToken cancellationToken)
    {
        var (items, total) = await _uow.AuditLogs.GetPagedAsync<DateTime>(
            l => l.EntityType == "DerivedRating" && l.EntityId == query.SecurityId,
            l => l.CreatedAt,
            descending: true,
            query.PageNumber,
            query.PageSize,
            cancellationToken);

        var dtos = items.Select(l => new RatingAuditLogDto
        {
            Id           = l.Id,
            SecurityId   = l.EntityId ?? query.SecurityId,
            ModelName    = l.Details ?? string.Empty,
            OldValues    = l.BeforeState,
            NewValues    = l.AfterState,
            ChangedFields = l.ChangedFields,
            Source       = l.Source,
            UserId       = l.UserId?.ToString(),
            TimestampUtc = l.CreatedAt
        });

        return new PagedResult<RatingAuditLogDto>(dtos, total, query.PageNumber, query.PageSize);
    }
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// GetRatingModelConfigHandler
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

public sealed class GetRatingModelConfigHandler
    : IQueryHandler<GetRatingModelConfigQuery, string>
{
    private readonly IRatingModelConfigService _configs;

    public GetRatingModelConfigHandler(IRatingModelConfigService configs)
        => _configs = configs;

    public async ValueTask<string> Handle(
        GetRatingModelConfigQuery query,
        CancellationToken cancellationToken)
    {
        var json = await _configs.GetJsonAsync(query.ModelName, cancellationToken);
        return json;
    }
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// GetRatingDerivationRulesHandler
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

public sealed class GetRatingDerivationRulesHandler
    : IQueryHandler<GetRatingDerivationRulesQuery, IEnumerable<RatingDerivationRuleDto>>
{
    private readonly IRatingsUoW _uow;
    private readonly IUserCacheService _userCache;

    public GetRatingDerivationRulesHandler(IRatingsUoW uow, IUserCacheService userCache)
    {
        _uow = uow;
        _userCache = userCache;
    }

    public async ValueTask<IEnumerable<RatingDerivationRuleDto>> Handle(
        GetRatingDerivationRulesQuery query,
        CancellationToken cancellationToken)
    {
        var rules = await _uow.RatingDerivationRules.GetAllAsync(cancellationToken);

        if (!string.IsNullOrEmpty(query.ModelName))
            rules = rules.Where(r => r.ModelName.Equals(query.ModelName, StringComparison.OrdinalIgnoreCase));

        if (query.AsOf.HasValue)
        {
            var date = query.AsOf.Value.ToUniversalTime();
            rules = rules.Where(r => r.ValidFrom <= date && date <= r.ValidTo);
        }

        return rules
            .OrderBy(r => r.ModelName)
            .ThenBy(r => r.SecurityType)
            .ThenByDescending(r => r.ValidFrom)
            .Select(r => new RatingDerivationRuleDto
            {
                Id            = r.Id,
                ModelName     = r.ModelName,
                SecurityType  = r.SecurityType,
                EffectiveFrom = r.ValidFrom,
                EffectiveTo   = r.ValidTo,
                ConfigJson    = r.ConfigJson,
                Description   = r.Description,
                CreatedAt     = r.CreatedAt,
                CreatedBy     = _userCache.ResolveDisplayName(r.CreatedBy),
                LastModifiedAt = r.LastModifiedAt,
                LastModifiedBy    = _userCache.ResolveDisplayName(r.LastModifiedBy)
            });
    }
}

// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
// GetRatingScalesHandler
// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

public sealed class GetRatingScalesHandler
    : IQueryHandler<GetRatingScalesQuery, IEnumerable<RatingScaleEntryDto>>
{
    private readonly IRatingsUoW _uow;

    public GetRatingScalesHandler(IRatingsUoW uow) => _uow = uow;

    public async ValueTask<IEnumerable<RatingScaleEntryDto>> Handle(
        GetRatingScalesQuery query,
        CancellationToken cancellationToken)
    {
        var scales = await _uow.RatingScaleEntries.GetAllAsync(cancellationToken);

        if (!string.IsNullOrEmpty(query.Agency))
            scales = scales.Where(e => e.Agency.Equals(query.Agency, StringComparison.OrdinalIgnoreCase));

        return scales
            .OrderBy(e => e.Agency)
            .ThenBy(e => e.Score)
            .Select(e => new RatingScaleEntryDto
            {
                Id               = e.Id,
                Agency           = e.Agency,
                Score            = e.Score,
                Label            = e.Label,
                IsInvestmentGrade = e.IsInvestmentGrade,
                ValidFrom        = e.ValidFrom,
                ValidTo          = e.ValidTo,
                CreatedAt        = e.CreatedAt,
                CreatedBy        = e.CreatedBy,
                LastModifiedAt   = e.LastModifiedAt,
                LastModifiedBy   = e.LastModifiedBy
            });
    }
}
