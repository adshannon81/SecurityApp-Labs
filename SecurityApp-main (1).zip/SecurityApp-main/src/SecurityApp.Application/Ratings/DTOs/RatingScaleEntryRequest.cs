namespace SecurityApp.Application.Ratings.DTOs;

/// <summary>Payload for creating or updating a single rating scale entry.</summary>
public class RatingScaleEntryRequest
{
    public string Agency { get; set; } = string.Empty;
    public int Score { get; set; }
    public string Label { get; set; } = string.Empty;
    public bool IsInvestmentGrade { get; set; }
    public DateTime ValidFrom { get; set; } = new DateTime(2000, 1, 1, 0, 0, 0, DateTimeKind.Utc);
    public DateTime ValidTo { get; set; } = new DateTime(9999, 12, 31, 23, 59, 59, DateTimeKind.Utc);
}
