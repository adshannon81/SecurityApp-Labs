namespace SecurityApp.Application.Ratings.DTOs;

/// <summary>One versioned rating derivation rule as returned by the API.</summary>
public class RatingDerivationRuleDto
{
    public Guid Id { get; set; }
    public string ModelName { get; set; } = string.Empty;
    /// <summary>Null = applies to all security types (generic fallback).</summary>
    public string? SecurityType { get; set; }
    /// <summary>When this configuration becomes effective (valid time).</summary>
    public DateTime EffectiveFrom { get; set; }
    /// <summary>When this configuration ceases to be effective (9999-12-31 = open-ended).</summary>
    public DateTime EffectiveTo { get; set; }
    /// <summary>The flat model config JSON (e.g. MicrConfig, CompositeRatingConfig).</summary>
    public string ConfigJson { get; set; } = "{}";
    public string? Description { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? LastModifiedAt { get; set; }
    public string? LastModifiedBy { get; set; }
}
