namespace SecurityApp.Application.Ratings.DTOs;

/// <summary>One entry in a rating agency's scale as returned/accepted by the API.</summary>
public class RatingScaleEntryDto
{
    public Guid Id { get; set; }
    public string Agency { get; set; } = string.Empty;
    public int Score { get; set; }
    public string Label { get; set; } = string.Empty;
    public bool IsInvestmentGrade { get; set; }
    public DateTime ValidFrom { get; set; }
    public DateTime ValidTo { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? LastModifiedAt { get; set; }
    public string? LastModifiedBy { get; set; }
}
