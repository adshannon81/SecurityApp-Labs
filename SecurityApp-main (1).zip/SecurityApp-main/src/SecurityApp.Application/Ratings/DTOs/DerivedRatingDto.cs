namespace SecurityApp.Application.Ratings.DTOs;

/// <summary>
/// Full derived rating result for a security.
/// Scores are agency-agnostic (1–21); labels are rendered per requested agency.
/// </summary>
public class DerivedRatingDto
{
    public Guid SecurityId { get; set; }

    // ── Numeric scores (agency-agnostic) ─────────────────────────────────────────────
    public int? ImpliedRatingScore { get; set; }
    public int? VpmRatingScore { get; set; }
    public int? FundamentalRatingScore { get; set; }
    public int? CompositeRatingScore { get; set; }

    // ── Labels per agency (keyed by agency name) ──────────────────────────────────────
    /// <summary>
    /// Dictionary of agency → label for the composite score,
    /// e.g. { "SP": "BBB", "Moodys": "Baa2", "Fitch": "BBB" }.
    /// </summary>
    public Dictionary<string, string?> CompositeRatingsByAgency { get; set; } = [];
    public Dictionary<string, string?> ImpliedRatingsByAgency { get; set; } = [];
    public Dictionary<string, string?> VpmRatingsByAgency { get; set; } = [];
    public Dictionary<string, string?> FundamentalRatingsByAgency { get; set; } = [];

    // ── Additional outputs ────────────────────────────────────────────────────────────
    public decimal? ImpliedPd { get; set; }
    public decimal? ModelPd { get; set; }
    public decimal? FairPrice { get; set; }

    // ── Metadata ─────────────────────────────────────────────────────────────────────
    public bool IsInvestmentGrade { get; set; }
    public bool WasSkipped { get; set; }
    public DateTime LastCalculatedUtc { get; set; }
    public string OutputAgency { get; set; } = "SP";
}
