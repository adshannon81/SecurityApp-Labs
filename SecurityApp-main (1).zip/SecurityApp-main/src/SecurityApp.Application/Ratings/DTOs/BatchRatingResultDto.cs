namespace SecurityApp.Application.Ratings.DTOs;

/// <summary>Result entry for a batch calculation.</summary>
public class BatchRatingResultDto
{
    public int Total { get; set; }
    public int Succeeded { get; set; }
    public int Skipped { get; set; }
    public int Failed { get; set; }
    public List<BatchRatingItemDto> Items { get; set; } = [];
}

public class BatchRatingItemDto
{
    public Guid SecurityId { get; set; }
    public bool Succeeded { get; set; }
    public bool Skipped { get; set; }
    public int? CompositeScore { get; set; }
    public string? CompositeLabel { get; set; }
    public string? Error { get; set; }
}
