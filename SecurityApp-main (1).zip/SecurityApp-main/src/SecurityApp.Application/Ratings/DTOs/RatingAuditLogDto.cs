namespace SecurityApp.Application.Ratings.DTOs;

/// <summary>Single row in a rating audit log.</summary>
public class RatingAuditLogDto
{
    public Guid Id { get; set; }
    public Guid SecurityId { get; set; }
    public string ModelName { get; set; } = string.Empty;
    public string? OldValue { get; set; }
    public string? NewValue { get; set; }
    public string? OldValues { get; set; }
    public string? NewValues { get; set; }
    public string? ChangedFields { get; set; }
    public string? Source { get; set; }
    public string? UserId { get; set; }
    public DateTime TimestampUtc { get; set; }
}
