namespace SecurityApp.Application.Ratings.DTOs;

/// <summary>Payload for creating a new derivation rule version.</summary>
public class UpsertRatingDerivationRuleRequest
{
    public string ModelName { get; set; } = string.Empty;
    public string? SecurityType { get; set; }
    public DateTime EffectiveFrom { get; set; } = new DateTime(2000, 1, 1, 0, 0, 0, DateTimeKind.Utc);
    public DateTime EffectiveTo { get; set; } = DateTime.MaxValue;
    public string ConfigJson { get; set; } = "{}";
    public string? Description { get; set; }
}
