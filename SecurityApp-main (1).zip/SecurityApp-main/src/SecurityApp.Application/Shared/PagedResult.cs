namespace SecurityApp.Application.Shared;

/// <summary>
/// Wraps a page of items together with total-count metadata so API clients
/// can render pagination controls without a separate COUNT request.
/// </summary>
public record PagedResult<T>(
    IEnumerable<T> Items,
    int TotalCount,
    int PageNumber,
    int PageSize)
{
    public int TotalPages      => PageSize > 0 ? (int)Math.Ceiling((double)TotalCount / PageSize) : 0;
    public bool HasNextPage     => PageNumber < TotalPages;
    public bool HasPreviousPage => PageNumber > 1;
}
