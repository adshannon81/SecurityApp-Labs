using Mediator;
using SecurityApp.Application.Audit.DTOs;
using SecurityApp.Application.Shared;

namespace SecurityApp.Application.Audit.Queries;

/// <summary>
/// Query to retrieve audit logs with optional filters.
/// </summary>
public record GetAuditLogsQuery(
    DateTime? From = null,
    DateTime? To = null,
    Guid? UserId = null,
    string? EntityType = null,
    int PageNumber = 1,
    int PageSize = 50) : IQuery<PagedResult<AuditLogDto>>;

/// <summary>
/// Query to stream all matching audit log rows for export (unbounded — no paging).
/// </summary>
public record ExportAuditLogsQuery(
    DateTime? DateFrom = null,
    DateTime? DateTo = null,
    string? EntityType = null,
    Guid? EntityId = null) : IQuery<IEnumerable<AuditLogDto>>;

