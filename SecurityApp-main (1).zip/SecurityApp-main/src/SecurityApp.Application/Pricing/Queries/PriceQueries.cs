﻿using Mediator;
using SecurityApp.Application.Pricing.DTOs;

namespace SecurityApp.Application.Pricing.Queries;

/// <summary>Get all prices for a security, optionally filtered by source and date range.</summary>
public record GetPricesForSecurityQuery(
    Guid SecurityId,
    DateTime? FromDate = null,
    DateTime? ToDate = null,
    string? Source = null) : IQuery<IEnumerable<PriceDto>>;

/// <summary>Get the latest price for a security from a specific or any source.</summary>
public record GetLatestPriceQuery(
    Guid SecurityId,
    string? Source = null) : IQuery<PriceDto?>;

/// <summary>Get all stale golden prices (is_stale = true and is_golden = true), paged.</summary>
public record GetStalePricesQuery(
    int Page = 1,
    int PageSize = 50) : IQuery<IEnumerable<PriceDto>>;

// ---------------------------------------------------------------------------
// Pricing Rule queries
// ---------------------------------------------------------------------------

/// <summary>Get all (non-deleted) pricing rules.</summary>
public record GetAllPricingRulesQuery : IQuery<IEnumerable<PricingRuleDto>>;

/// <summary>Get a single pricing rule by ID.</summary>
public record GetPricingRuleByIdQuery(Guid RuleId) : IQuery<PricingRuleDto?>;

// ---------------------------------------------------------------------------
// Derived Price queries
// ---------------------------------------------------------------------------

/// <summary>
/// Get derived prices, optionally filtered by security and/or rule.
/// Returns most-recent calculation per security+rule combination.
/// </summary>
public record GetDerivedPricesQuery(
    Guid? SecurityId = null,
    Guid? RuleId = null) : IQuery<IEnumerable<DerivedPriceDto>>;
