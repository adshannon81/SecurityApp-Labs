﻿using Mediator;
using SecurityApp.Application.Pricing.DTOs;
using SecurityApp.Core.Workflow.Enums;
using SecurityApp.Core.Workflow.Interfaces;

namespace SecurityApp.Application.Pricing.Commands;

/// <summary>Create a new pricing rule.</summary>
public record CreatePricingRuleCommand(
    CreatePricingRuleDto Rule,
    string? UserId) : ICommand<PricingRuleDto>, IWorkflowGuardedCommand
{
    public WorkflowTriggerType WorkflowTrigger   => WorkflowTriggerType.PricingRuleChange;
    public Guid                WorkflowEntityId  => Guid.Empty;
    public string              WorkflowEntityType => "PricingRule";
}

/// <summary>Update an existing pricing rule.</summary>
public record UpdatePricingRuleCommand(
    Guid RuleId,
    CreatePricingRuleDto Rule,
    string? UserId) : ICommand, IWorkflowGuardedCommand
{
    public WorkflowTriggerType WorkflowTrigger   => WorkflowTriggerType.PricingRuleChange;
    public Guid                WorkflowEntityId  => RuleId;
    public string              WorkflowEntityType => "PricingRule";
}

/// <summary>Soft-delete a pricing rule.</summary>
public record DeletePricingRuleCommand(
    Guid RuleId,
    string? UserId) : ICommand, IWorkflowGuardedCommand
{
    public WorkflowTriggerType WorkflowTrigger   => WorkflowTriggerType.PricingRuleChange;
    public Guid                WorkflowEntityId  => RuleId;
    public string              WorkflowEntityType => "PricingRule";
}

/// <summary>
/// Applies a manual override to an existing price row.
/// Sets IsOverride = true, promotes to golden, demotes previous golden for the same
/// SecurityId + PriceType, and writes a MANUAL_OVERRIDE lineage event.
/// If a PriceOverride workflow definition is configured for the asset class, the
/// command returns 202 (workflow pending) and the price is applied only after approval.
/// </summary>
public record OverridePriceCommand(
    Guid PriceId,
    decimal NewValue,
    string OverrideReason,
    string? UserId) : ICommand<PriceDto>, IWorkflowGuardedCommand
{
    public WorkflowTriggerType WorkflowTrigger   => WorkflowTriggerType.PriceOverride;
    public Guid                WorkflowEntityId  => PriceId;
    public string              WorkflowEntityType => "Price";
}

/// <summary>
/// Calculate (or recalculate) derived prices for a given rule.
///
/// Behaviour:
///   - If SecurityId is supplied: calculate only for that security (must match rule's SecurityType if set).
///   - If SecurityId is null:    calculate for every security whose type matches the rule's SecurityType
///                                (or all securities when the rule has no SecurityType filter).
///
/// For each target security the handler:
///   1. Finds the latest source price matching the rule definition (Source + PriceType).
///   2. Upserts a DerivedPrice row (one per security+rule).
///   3. Writes an audit log entry.
/// </summary>
public record CalculateDerivedPriceCommand(
    Guid RuleId,
    Guid? SecurityId,
    string? UserId) : ICommand<CalculationResult>;
