using System.Data;
using System.Globalization;
using System.Text.Json;
using Mediator;
using Microsoft.Extensions.Logging;
using SecurityApp.Core.Pricing.Entities;
using SecurityApp.Core.Pricing.Interfaces;
using SecurityApp.Core.Securities.Interfaces;
using SecurityApp.Application.Pricing.Commands;
using SecurityApp.Application.Pricing.DTOs;
using SecurityApp.Core.Shared.Enums;
using SecurityApp.Core.Securities.Enums;

namespace SecurityApp.Application.Pricing.Handlers;

// ---------------------------------------------------------------------------
// Pricing Rule CRUD handlers
// ---------------------------------------------------------------------------

/// <summary>
/// Creates a new pricing rule.  The rule definition (Source + PriceType) is
/// stored as JSON in PricingRule.RuleDefinitionJson so the schema stays flexible.
/// </summary>
public sealed class CreatePricingRuleHandler : ICommandHandler<CreatePricingRuleCommand, PricingRuleDto>
{
    private readonly IPricingUoW _unitOfWork;

    public CreatePricingRuleHandler(IPricingUoW unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    public async ValueTask<PricingRuleDto> Handle(CreatePricingRuleCommand command, CancellationToken cancellationToken)
    {
        var dto = command.Rule;

        var rule = new PricingRule
        {
            RuleName       = dto.RuleName,
            SecurityType   = dto.SecurityType,
            Description    = dto.Description,
            RuleDefinitionJson = JsonSerializer.Serialize(new { source = dto.Source, priceType = dto.PriceType, formula = dto.Formula }),
            CreatedByUserId   = Guid.TryParse(command.UserId, out var uid) ? uid : null,
            LastModifiedBy     = command.UserId
        };

        await _unitOfWork.PricingRules.AddAsync(rule, cancellationToken);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return MapToDto(rule, dto.Source, dto.PriceType, dto.Formula);
    }

    private static PricingRuleDto MapToDto(PricingRule rule, string source, string? priceType, string? formula) => new()
    {
        Id           = rule.Id,
        RuleName     = rule.RuleName,
        SecurityType = rule.SecurityType,
        Source       = source,
        PriceType    = priceType,
        Formula      = formula,
        Description  = rule.Description,
        IsActive     = rule.IsCurrent,
        CreatedAt    = rule.CreatedAt,
        LastModifiedAt    = rule.LastModifiedAt
    };
}

/// <summary>
/// Updates an existing pricing rule.
/// Bi-temporal history is managed automatically by TemporalInterceptor on SaveChanges —
/// it clones the pre-modification row as a history record and advances SystemFrom on the live row.
/// </summary>
public sealed class UpdatePricingRuleHandler : ICommandHandler<UpdatePricingRuleCommand>
{
    private readonly IPricingUoW _unitOfWork;

    public UpdatePricingRuleHandler(IPricingUoW unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    public async ValueTask<Unit> Handle(UpdatePricingRuleCommand command, CancellationToken cancellationToken)
    {
        var rules = await _unitOfWork.PricingRules.GetAllAsync(cancellationToken);
        var rule = rules.FirstOrDefault(r => r.Id == command.RuleId && r.IsCurrent && !r.IsDeleted)
            ?? throw new InvalidOperationException($"Pricing rule {command.RuleId} not found.");

        var dto = command.Rule;
        rule.RuleName       = dto.RuleName;
        rule.SecurityType   = dto.SecurityType;
        rule.Description    = dto.Description;
        rule.RuleDefinitionJson = JsonSerializer.Serialize(new { source = dto.Source, priceType = dto.PriceType, formula = dto.Formula });
        rule.LastModifiedBy     = command.UserId;
        rule.LastModifiedAt      = DateTime.UtcNow;

        await _unitOfWork.PricingRules.UpdateAsync(rule, cancellationToken);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

/// <summary>Soft-deletes a pricing rule.</summary>
public sealed class DeletePricingRuleHandler : ICommandHandler<DeletePricingRuleCommand>
{
    private readonly IPricingUoW _unitOfWork;

    public DeletePricingRuleHandler(IPricingUoW unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    public async ValueTask<Unit> Handle(DeletePricingRuleCommand command, CancellationToken cancellationToken)
    {
        var rules = await _unitOfWork.PricingRules.GetAllAsync(cancellationToken);
        var rule = rules.FirstOrDefault(r => r.Id == command.RuleId && !r.IsDeleted)
            ?? throw new InvalidOperationException($"Pricing rule {command.RuleId} not found.");

        rule.IsDeleted  = true;
        rule.IsCurrent  = false;
        rule.ValidTo    = DateTime.UtcNow;
        rule.LastModifiedBy = command.UserId;
        rule.LastModifiedAt  = DateTime.UtcNow;

        await _unitOfWork.PricingRules.UpdateAsync(rule, cancellationToken);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return Unit.Value;
    }
}

// ---------------------------------------------------------------------------
// Derived price calculation handler
// ---------------------------------------------------------------------------

/// <summary>
/// Rule definition stored in PricingRule.RuleDefinitionJson:
/// { "source": "Bloomberg", "priceType": "Mid", "formula": "price * 1.005" }
/// Formula is optional; when present it is evaluated with 'price' substituted for the source price value.
/// </summary>
file record RuleDefinition(string Source, string? PriceType, string? Formula);

/// <summary>
/// Evaluates a pricing rule against stored source prices and writes
/// DerivedPrice rows - one per security + rule.
///
/// Algorithm:
///   1. Load the rule; parse its JSON definition.
///   2. Determine target securities (filtered by rule's SecurityType, or a
///      specific SecurityId when supplied).
///   3. For each security find its latest price matching Source (+ PriceType
///      when specified).
///   4. Upsert a DerivedPrice row and write an audit entry.
/// </summary>
public sealed class CalculateDerivedPriceHandler : ICommandHandler<CalculateDerivedPriceCommand, CalculationResult>
{
    private readonly IPricingUoW _pricingUoW;
    private readonly ISecuritiesUoW _securitiesUoW;
    private readonly ILogger<CalculateDerivedPriceHandler> _logger;

    public CalculateDerivedPriceHandler(
        IPricingUoW pricingUoW,
        ISecuritiesUoW securitiesUoW,
        ILogger<CalculateDerivedPriceHandler> logger)
    {
        _pricingUoW    = pricingUoW;
        _securitiesUoW = securitiesUoW;
        _logger        = logger;
    }

    public async ValueTask<CalculationResult> Handle(
        CalculateDerivedPriceCommand command,
        CancellationToken cancellationToken)
    {
        // 1. Load rule
        var allRules = await _pricingUoW.PricingRules.GetAllAsync(cancellationToken);
        var rule = allRules.FirstOrDefault(r => r.Id == command.RuleId && !r.IsDeleted);
        if (rule == null)
            return new CalculationResult { Success = false, Message = $"Pricing rule {command.RuleId} not found." };

        // 2. Parse rule definition
        RuleDefinition? def = null;
        try
        {
            using var doc = JsonDocument.Parse(rule.RuleDefinitionJson);
            var root = doc.RootElement;
            var src = root.TryGetProperty("source", out var sp) ? sp.GetString() : null;
            var pt  = root.TryGetProperty("priceType", out var pp) ? pp.GetString() : null;
            var fm  = root.TryGetProperty("formula",   out var fp) ? fp.GetString() : null;
            if (!string.IsNullOrWhiteSpace(src))
                def = new RuleDefinition(src, pt, fm);
        }
        catch (Exception ex)
        {
            return new CalculationResult { Success = false, Message = $"Invalid rule definition JSON: {ex.Message}" };
        }

        if (def == null || !Enum.TryParse<DataSourceType>(def.Source, ignoreCase: true, out var sourceEnum))
            return new CalculationResult { Success = false, Message = $"Rule definition has unknown or missing source '{def?.Source}'." };

        // 3. Determine target securities
        var allSecurities = await _securitiesUoW.Securities.GetAllAsync(cancellationToken);
        var targets = allSecurities.Where(s => s.IsCurrent && !s.IsDeleted).AsEnumerable();

        if (command.SecurityId.HasValue)
        {
            targets = targets.Where(s => s.Id == command.SecurityId.Value);
        }
        else if (!string.IsNullOrWhiteSpace(rule.SecurityType) &&
                 Enum.TryParse<SecurityType>(rule.SecurityType, ignoreCase: true, out var ruleSecType))
        {
            targets = targets.Where(s => s.Type == ruleSecType);
        }

        var targetList = targets.ToList();
        if (targetList.Count == 0)
            return new CalculationResult { Success = true, Calculated = 0, Skipped = 0, Message = "No matching securities found." };

        // 4. Load prices and existing derived prices once
        var allPrices        = await _pricingUoW.Prices.GetAllAsync(cancellationToken);
        var allDerivedPrices = await _pricingUoW.DerivedPrices.GetAllAsync(cancellationToken);

        int calculated = 0, skipped = 0;
        var errors = new List<string>();
        var userId = Guid.TryParse(command.UserId, out var uid) ? uid : (Guid?)null;
        var now    = DateTime.UtcNow;

        foreach (var security in targetList)
        {
            // Find best matching source price
            var candidatePrices = allPrices
                .Where(p => p.SecurityId == security.Id && p.Source == sourceEnum);

            if (!string.IsNullOrWhiteSpace(def.PriceType))
                candidatePrices = candidatePrices.Where(p =>
                    string.Equals(p.PriceType, def.PriceType, StringComparison.OrdinalIgnoreCase));

            var sourcePrice = candidatePrices.OrderByDescending(p => p.PriceDate).FirstOrDefault();

            if (sourcePrice == null)
            {
                _logger.LogDebug("No {Source} {PriceType} price for security {Id} - skipping",
                    def.Source, def.PriceType, security.Id);
                skipped++;
                continue;
            }

            // Upsert derived price (one row per security + rule)
            var existing = allDerivedPrices.FirstOrDefault(d =>
                d.SecurityId == security.Id && d.PricingRuleId == command.RuleId && !d.IsDeleted);

            // Apply optional formula (e.g. "price * 1.005")
            decimal derivedValue = sourcePrice.Value;
            string? formulaError = null;
            if (!string.IsNullOrWhiteSpace(def.Formula))
            {
                try
                {
                    var expression = def.Formula.Replace(
                        "price",
                        sourcePrice.Value.ToString(CultureInfo.InvariantCulture),
                        StringComparison.OrdinalIgnoreCase);
                    derivedValue = Convert.ToDecimal(
                        new DataTable().Compute(expression, null),
                        CultureInfo.InvariantCulture);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Formula evaluation failed for rule {RuleId} security {SecId} - using source price",
                        command.RuleId, security.Id);
                    formulaError = ex.Message;
                    derivedValue = sourcePrice.Value;
                }
            }

            var details = JsonSerializer.Serialize(new
            {
                sourcePrice.Source,
                sourcePrice.PriceType,
                sourcePriceDate  = sourcePrice.PriceDate,
                sourcePriceId    = sourcePrice.Id,
                formula          = def.Formula,
                formulaError
            });

            if (existing != null)
            {
                existing.CalculatedPrice     = derivedValue;
                existing.CalculatedAt        = now;
                existing.CalculationDetails  = details;
                existing.LastModifiedBy          = command.UserId;
                existing.LastModifiedAt           = now;
                await _pricingUoW.DerivedPrices.UpdateAsync(existing, cancellationToken);
            }
            else
            {
                await _pricingUoW.DerivedPrices.AddAsync(new DerivedPrice
                {
                    SecurityId          = security.Id,
                    PricingRuleId       = command.RuleId,
                    CalculatedPrice     = derivedValue,
                    CalculatedAt        = now,
                    CalculationDetails  = details,
                    LastModifiedBy          = command.UserId
                }, cancellationToken);
            }

            calculated++;
        }

        await _pricingUoW.SaveChangesAsync(cancellationToken);

        _logger.LogInformation(
            "Rule {RuleId} ({Name}): calculated {Calculated}, skipped {Skipped}",
            command.RuleId, rule.RuleName, calculated, skipped);

        return new CalculationResult
        {
            Success    = true,
            Calculated = calculated,
            Skipped    = skipped,
            Message    = $"Calculated {calculated} derived price(s), skipped {skipped} (no matching source price).",
            Errors     = errors
        };
    }
}

// ---------------------------------------------------------------------------
// Price override handler  (M17)
// ---------------------------------------------------------------------------

/// <summary>
/// Applies a manual price override.
/// - Loads the target price row; returns 404 if not found.
/// - Demotes any existing golden price for the same SecurityId + PriceType.
/// - Stamps the target row: Value = NewValue, IsOverride = true, IsGolden = true,
///   OverrideReason, LastModifiedBy, LastModifiedAt.
/// - Writes a DataLineageEvent with SourceType = "MANUAL_OVERRIDE".
/// - WorkflowGateBehavior intercepts this command before Handle runs, so if a
///   PriceOverride workflow definition exists the command never reaches here until approved.
/// </summary>
public sealed class OverridePriceHandler(
    IPricingUoW pricingUoW,
    SecurityApp.Core.GoldenSource.IDataLineageRepository lineageRepo,
    ILogger<OverridePriceHandler> logger)
    : ICommandHandler<OverridePriceCommand, PriceDto>
{
    public async ValueTask<PriceDto> Handle(OverridePriceCommand command, CancellationToken cancellationToken)
    {
        var allPrices = await pricingUoW.Prices.GetAllAsync(cancellationToken);

        var target = allPrices.FirstOrDefault(p => p.Id == command.PriceId);
        if (target is null)
            throw new KeyNotFoundException($"Price row {command.PriceId} not found.");

        // Demote any existing golden for this security + priceType
        var siblings = allPrices
            .Where(p => p.SecurityId == target.SecurityId
                     && p.PriceType  == target.PriceType
                     && p.IsGolden
                     && p.Id != target.Id);

        foreach (var sibling in siblings)
        {
            sibling.IsGolden   = false;
            sibling.LastModifiedAt  = DateTime.UtcNow;
            sibling.LastModifiedBy = command.UserId;
        }

        // Apply override
        target.Value          = command.NewValue;
        target.IsOverride     = true;
        target.IsGolden       = true;
        target.IsStale        = false;
        target.OverrideReason = command.OverrideReason;
        target.LastModifiedBy     = command.UserId;
        target.LastModifiedAt      = DateTime.UtcNow;

        await pricingUoW.SaveChangesAsync(cancellationToken);

        // Write lineage event
        var lineageEvent = new SecurityApp.Core.GoldenSource.Entities.DataLineageEvent
        {
            SecurityId     = target.SecurityId,
            FieldName      = $"price:{target.PriceType ?? "Close"}",
            FieldValue     = command.NewValue.ToString(System.Globalization.CultureInfo.InvariantCulture),
            SourceType     = "MANUAL_OVERRIDE",
            OverrideUserId = command.UserId,
            OverrideReason = command.OverrideReason,
            ResolvedAt     = DateTime.UtcNow,
            CreatedAt      = DateTime.UtcNow,
        };
        await lineageRepo.AddAsync(lineageEvent, cancellationToken);

        logger.LogInformation(
            "Price {PriceId} overridden for Security {SecurityId} by {User}: {Value}",
            command.PriceId, target.SecurityId, command.UserId, command.NewValue);

        return new PriceDto
        {
            Id             = target.Id,
            SecurityId     = target.SecurityId,
            Value          = target.Value,
            Source         = target.Source,
            PriceDate      = target.PriceDate,
            PriceType      = target.PriceType,
            Currency       = target.Currency,
            CreatedAt      = target.CreatedAt,
            IsGolden       = target.IsGolden,
            IsStale        = target.IsStale,
            IsOverride     = target.IsOverride,
            OverrideReason = target.OverrideReason,
            VendorSourceId = target.VendorSourceId,
        };
    }
}
