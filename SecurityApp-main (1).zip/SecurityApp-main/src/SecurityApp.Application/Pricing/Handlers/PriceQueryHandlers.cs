using System.Text.Json;
using Mediator;
using SecurityApp.Core.Pricing.Interfaces;
using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Core.Pricing.Entities;
using SecurityApp.Application.Pricing.Queries;
using SecurityApp.Application.Pricing.DTOs;
using SecurityApp.Core.Shared.Enums;

namespace SecurityApp.Application.Pricing.Handlers;

public sealed class GetPricesForSecurityHandler : IQueryHandler<GetPricesForSecurityQuery, IEnumerable<PriceDto>>
{
    private readonly IPricingUoW _unitOfWork;
    private readonly ICacheService _cacheService;

    public GetPricesForSecurityHandler(IPricingUoW unitOfWork, ICacheService cacheService)
    {
        _unitOfWork   = unitOfWork;
        _cacheService = cacheService;
    }

    public async ValueTask<IEnumerable<PriceDto>> Handle(GetPricesForSecurityQuery query, CancellationToken cancellationToken)
    {
        var from = query.FromDate?.ToString("yyyyMMdd") ?? "";
        var to   = query.ToDate?.ToString("yyyyMMdd") ?? "";
        var src  = query.Source ?? "";
        var key  = $"price:list:{query.SecurityId}:{from}:{to}:{src}";

        var cached = await _cacheService.GetAsync<List<PriceDto>>(key, cancellationToken);
        if (cached is not null) return cached;

        var allPrices = await _unitOfWork.Prices.GetAllAsync(cancellationToken);

        var filtered = allPrices.Where(p => p.SecurityId == query.SecurityId);

        if (query.FromDate.HasValue)
            filtered = filtered.Where(p => p.PriceDate >= query.FromDate.Value);

        if (query.ToDate.HasValue)
            filtered = filtered.Where(p => p.PriceDate <= query.ToDate.Value);

        if (!string.IsNullOrWhiteSpace(query.Source) && Enum.TryParse<DataSourceType>(query.Source, true, out var sourceEnum))
            filtered = filtered.Where(p => p.Source == sourceEnum);

        var result = filtered
            .OrderByDescending(p => p.PriceDate)
            .Select(p => new PriceDto
            {
                Id = p.Id,
                SecurityId = p.SecurityId,
                Value = p.Value,
                Source = p.Source,
                PriceDate = p.PriceDate,
                PriceType = p.PriceType,
                Currency = p.Currency,
                CreatedAt = p.CreatedAt,
                IsGolden = p.IsGolden,
                IsStale = p.IsStale,
                IsOverride = p.IsOverride,
                OverrideReason = p.OverrideReason,
                VendorSourceId = p.VendorSourceId
            })
            .ToList();

        await _cacheService.SetAsync(key, result, TimeSpan.FromMinutes(2), cancellationToken);
        return result;
    }
}

public sealed class GetLatestPriceHandler : IQueryHandler<GetLatestPriceQuery, PriceDto?>
{
    private readonly IPricingUoW _unitOfWork;
    private readonly ICacheService _cacheService;

    public GetLatestPriceHandler(IPricingUoW unitOfWork, ICacheService cacheService)
    {
        _unitOfWork   = unitOfWork;
        _cacheService = cacheService;
    }

    public async ValueTask<PriceDto?> Handle(GetLatestPriceQuery query, CancellationToken cancellationToken)
    {
        var src = query.Source ?? "";
        var key = $"price:latest:{query.SecurityId}:{src}";

        var cached = await _cacheService.GetAsync<PriceDto>(key, cancellationToken);
        if (cached is not null) return cached;

        var allPrices = await _unitOfWork.Prices.GetAllAsync(cancellationToken);

        var filtered = allPrices.Where(p => p.SecurityId == query.SecurityId);

        if (!string.IsNullOrWhiteSpace(query.Source) && Enum.TryParse<DataSourceType>(query.Source, true, out var sourceEnum))
            filtered = filtered.Where(p => p.Source == sourceEnum);

        var latest = filtered.OrderByDescending(p => p.PriceDate).FirstOrDefault();
        if (latest is null) return null;

        var dto = new PriceDto
        {
            Id = latest.Id,
            SecurityId = latest.SecurityId,
            Value = latest.Value,
            Source = latest.Source,
            PriceDate = latest.PriceDate,
            PriceType = latest.PriceType,
            Currency = latest.Currency,
            CreatedAt = latest.CreatedAt,
            IsGolden = latest.IsGolden,
            IsStale = latest.IsStale,
            IsOverride = latest.IsOverride,
            OverrideReason = latest.OverrideReason,
            VendorSourceId = latest.VendorSourceId
        };

        await _cacheService.SetAsync(key, dto, TimeSpan.FromMinutes(2), cancellationToken);
        return dto;
    }
}

// ---------------------------------------------------------------------------
// Stale prices query handler  (M15)
// ---------------------------------------------------------------------------

public sealed class GetStalePricesHandler : IQueryHandler<GetStalePricesQuery, IEnumerable<PriceDto>>
{
    private readonly IPricingUoW _unitOfWork;
    public GetStalePricesHandler(IPricingUoW unitOfWork) => _unitOfWork = unitOfWork;

    public async ValueTask<IEnumerable<PriceDto>> Handle(
        GetStalePricesQuery query, CancellationToken cancellationToken)
    {
        var all = await _unitOfWork.Prices.GetAllAsync(cancellationToken);
        return all
            .Where(p => p.IsStale && p.IsGolden)
            .OrderByDescending(p => p.PriceDate)
            .Skip((query.Page - 1) * query.PageSize)
            .Take(query.PageSize)
            .Select(p => new PriceDto
            {
                Id             = p.Id,
                SecurityId     = p.SecurityId,
                Value          = p.Value,
                Source         = p.Source,
                PriceDate      = p.PriceDate,
                PriceType      = p.PriceType,
                Currency       = p.Currency,
                CreatedAt      = p.CreatedAt,
                IsGolden       = p.IsGolden,
                IsStale        = p.IsStale,
                IsOverride     = p.IsOverride,
                OverrideReason = p.OverrideReason,
                VendorSourceId = p.VendorSourceId
            })
            .ToList();
    }
}

// ---------------------------------------------------------------------------
// Pricing Rule query handlers
// ---------------------------------------------------------------------------

public sealed class GetAllPricingRulesHandler : IQueryHandler<GetAllPricingRulesQuery, IEnumerable<PricingRuleDto>>
{
    private readonly IPricingUoW _unitOfWork;
    public GetAllPricingRulesHandler(IPricingUoW unitOfWork) => _unitOfWork = unitOfWork;

    public async ValueTask<IEnumerable<PricingRuleDto>> Handle(
        GetAllPricingRulesQuery query, CancellationToken cancellationToken)
    {
        var rules = await _unitOfWork.PricingRules.GetAllAsync(cancellationToken);
        return rules
            .Where(r => !r.IsDeleted)
            .OrderBy(r => r.RuleName)
            .Select(MapToDto);
    }

    internal static PricingRuleDto MapToDto(PricingRule rule)
    {
        string source = string.Empty;
        string? priceType = null;
        string? formula = null;
        try
        {
            using var doc = JsonDocument.Parse(rule.RuleDefinitionJson);
            var root = doc.RootElement;
            source    = root.TryGetProperty("source",    out var sp) ? sp.GetString() ?? string.Empty : string.Empty;
            priceType = root.TryGetProperty("priceType", out var pp) ? pp.GetString() : null;
            formula   = root.TryGetProperty("formula",   out var fp) ? fp.GetString() : null;
        }
        catch { /* leave defaults */ }

        return new PricingRuleDto
        {
            Id           = rule.Id,
            RuleName     = rule.RuleName,
            SecurityType = rule.SecurityType,
            Source       = source,
            PriceType    = priceType,
            Formula      = formula,
            Description  = rule.Description,
            IsActive     = rule.IsCurrent,
            CreatedAt    = rule.CreatedAt,
            LastModifiedAt    = rule.LastModifiedAt
        };
    }
}

public sealed class GetPricingRuleByIdHandler : IQueryHandler<GetPricingRuleByIdQuery, PricingRuleDto?>
{
    private readonly IPricingUoW _unitOfWork;
    public GetPricingRuleByIdHandler(IPricingUoW unitOfWork) => _unitOfWork = unitOfWork;

    public async ValueTask<PricingRuleDto?> Handle(
        GetPricingRuleByIdQuery query, CancellationToken cancellationToken)
    {
        var rules = await _unitOfWork.PricingRules.GetAllAsync(cancellationToken);
        var rule = rules.FirstOrDefault(r => r.Id == query.RuleId && !r.IsDeleted);
        return rule == null ? null : GetAllPricingRulesHandler.MapToDto(rule);
    }
}

// ---------------------------------------------------------------------------
// Derived Price query handler
// ---------------------------------------------------------------------------

public sealed class GetDerivedPricesHandler : IQueryHandler<GetDerivedPricesQuery, IEnumerable<DerivedPriceDto>>
{
    private readonly IPricingUoW _unitOfWork;
    public GetDerivedPricesHandler(IPricingUoW unitOfWork) => _unitOfWork = unitOfWork;

    public async ValueTask<IEnumerable<DerivedPriceDto>> Handle(
        GetDerivedPricesQuery query, CancellationToken cancellationToken)
    {
        var ruleLookup = (await _unitOfWork.PricingRules.GetAllAsync(cancellationToken)).ToDictionary(r => r.Id, r => r.RuleName);
        var derived    = (await _unitOfWork.DerivedPrices.GetAllAsync(cancellationToken)).Where(d => !d.IsDeleted).AsEnumerable();

        if (query.SecurityId.HasValue)
            derived = derived.Where(d => d.SecurityId == query.SecurityId.Value);

        if (query.RuleId.HasValue)
            derived = derived.Where(d => d.PricingRuleId == query.RuleId.Value);

        return derived
            .OrderByDescending(d => d.CalculatedAt)
            .Select(d => new DerivedPriceDto
            {
                Id                 = d.Id,
                SecurityId         = d.SecurityId,
                PricingRuleId      = d.PricingRuleId,
                RuleName           = ruleLookup.TryGetValue(d.PricingRuleId, out var n) ? n : string.Empty,
                CalculatedPrice    = d.CalculatedPrice,
                CalculatedAt       = d.CalculatedAt,
                CalculationDetails = d.CalculationDetails
            });
    }
}
