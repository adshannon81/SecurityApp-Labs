using SecurityApp.Core.Shared.Enums;

namespace SecurityApp.Application.Pricing.DTOs;

/// <summary>Price data point for a security.</summary>
public class PriceDto
{
    public Guid Id { get; set; }
    public Guid SecurityId { get; set; }
    public decimal Value { get; set; }
    public DataSourceType Source { get; set; }
    public DateTime PriceDate { get; set; }
    public string? PriceType { get; set; }
    public string? Currency { get; set; }
    public DateTime CreatedAt { get; set; }

    // Golden source (M15)
    public bool IsGolden { get; set; }
    public bool IsStale { get; set; }
    public bool IsOverride { get; set; }
    public string? OverrideReason { get; set; }
    public Guid? VendorSourceId { get; set; }
}
