namespace SecurityApp.Application.Pricing.DTOs;

/// <summary>Result of a derived price calculation run.</summary>
public class CalculationResult
{
    public bool Success { get; set; }
    public int Calculated { get; set; }
    public int Skipped { get; set; }
    public string Message { get; set; } = string.Empty;
    public List<string> Errors { get; set; } = new();
}
