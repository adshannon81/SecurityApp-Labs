using System.ComponentModel.DataAnnotations;
using SecurityApp.Core.Shared.Enums;

namespace SecurityApp.Application.Pricing.DTOs;

/// <summary>
/// Request body for creating or updating a pricing rule.
/// The rule definition specifies which source price to use (e.g. Bloomberg Mid).
/// SecurityType is optional: when set, the rule only applies to securities of that type.
/// </summary>
public class CreatePricingRuleDto
{
    [Required, StringLength(200, MinimumLength = 1)]
    public string RuleName { get; set; } = string.Empty;

    /// <summary>Optional: ABS, Bond, Equity, Loan, etc. Null means rule applies to all types.</summary>
    public string? SecurityType { get; set; }

    /// <summary>
    /// Source of the price to use: Bloomberg, Markit, IDC, AlphaVantage, etc.
    /// Must be a valid DataSourceType enum name.
    /// </summary>
    [Required]
    public string Source { get; set; } = string.Empty;

    /// <summary>Price type to select: Mid, Bid, Ask, Close, etc. Null means any type.</summary>
    public string? PriceType { get; set; }

    [StringLength(500)]
    public string? Description { get; set; }

    /// <summary>
    /// Optional arithmetic formula applied to the source price before storing as a DerivedPrice.
    /// Use 'price' as the placeholder for the source value. Basic arithmetic is supported.
    /// Examples: "price * 1.005", "price - 0.02", "(price + 100) / 2"
    /// When null/empty the source price is passed through unchanged.
    /// </summary>
    [StringLength(500)]
    public string? Formula { get; set; }
}
