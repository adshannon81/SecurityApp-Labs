using SecurityApp.Core.Shared.Enums;

namespace SecurityApp.Application.Pricing.DTOs;

/// <summary>Request body for recording a new price data point.</summary>
public class CreatePriceDto
{
    public Guid SecurityId { get; set; }
    public decimal Value { get; set; }
    public DataSourceType Source { get; set; }
    public DateTime PriceDate { get; set; }
    public string? PriceType { get; set; }
    public string? Currency { get; set; }
}
