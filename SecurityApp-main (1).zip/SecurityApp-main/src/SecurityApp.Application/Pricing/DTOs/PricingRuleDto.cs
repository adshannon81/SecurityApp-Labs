namespace SecurityApp.Application.Pricing.DTOs;

/// <summary>Pricing rule response DTO.</summary>
public class PricingRuleDto
{
    public Guid Id { get; set; }
    public string RuleName { get; set; } = string.Empty;
    public string? SecurityType { get; set; }
    public string Source { get; set; } = string.Empty;
    public string? PriceType { get; set; }
    public string? Description { get; set; }
    public string? Formula { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? LastModifiedAt { get; set; }
}
