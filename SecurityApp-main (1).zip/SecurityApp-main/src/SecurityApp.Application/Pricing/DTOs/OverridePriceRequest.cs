using System.ComponentModel.DataAnnotations;

namespace SecurityApp.Application.Pricing.DTOs;

/// <summary>
/// Request body for POST /api/pricing/{priceId}/override.
/// </summary>
public class OverridePriceRequest
{
    /// <summary>The new price value to set on the row.</summary>
    [Required]
    [Range(0.000001, double.MaxValue, ErrorMessage = "NewValue must be positive.")]
    public decimal NewValue { get; init; }

    /// <summary>Business justification for the override, stored for audit purposes.</summary>
    [Required(AllowEmptyStrings = false)]
    [MaxLength(1000)]
    public string Reason { get; init; } = string.Empty;
}
