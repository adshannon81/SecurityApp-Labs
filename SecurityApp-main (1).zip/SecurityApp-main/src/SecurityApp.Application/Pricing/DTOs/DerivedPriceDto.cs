namespace SecurityApp.Application.Pricing.DTOs;

/// <summary>Derived price calculated by applying a pricing rule to a source price.</summary>
public class DerivedPriceDto
{
    public Guid Id { get; set; }
    public Guid SecurityId { get; set; }
    public Guid PricingRuleId { get; set; }
    public string RuleName { get; set; } = string.Empty;
    public decimal CalculatedPrice { get; set; }
    public DateTime CalculatedAt { get; set; }
    public string? CalculationDetails { get; set; }
}
