namespace SecurityApp.Application.Dashboard.DTOs;

public record ConnectorHealthDto(string Name, string Status, string Message);

public record DashboardSummaryDto(
    int TotalSecurities,
    int ActiveSecurities,
    int PendingApprovals,
    int FailedImports,
    int RunningJobs,
    IReadOnlyList<ConnectorHealthDto> ConnectorHealth,
    DateTime AsOf);
