using Mediator;
using SecurityApp.Application.Dashboard.DTOs;
using SecurityApp.Application.Dashboard.Queries;
using SecurityApp.Core.Dashboard;
using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Core.Workflow.Interfaces;

namespace SecurityApp.Application.Dashboard.Handlers;

public class GetDashboardSummaryHandler : IQueryHandler<GetDashboardSummaryQuery, DashboardSummaryDto>
{
    private readonly IDashboardRepository _repo;
    private readonly IWorkflowEngine _workflow;
    private readonly IDataProviderService _dataProvider;
    private readonly ICacheService _cache;

    public GetDashboardSummaryHandler(
        IDashboardRepository repo,
        IWorkflowEngine workflow,
        IDataProviderService dataProvider,
        ICacheService cache)
    {
        _repo         = repo;
        _workflow     = workflow;
        _dataProvider = dataProvider;
        _cache        = cache;
    }

    public async ValueTask<DashboardSummaryDto> Handle(GetDashboardSummaryQuery query, CancellationToken ct)
    {
        const string key = "dashboard:summary";

        var cached = await _cache.GetAsync<DashboardSummaryDto>(key, ct);
        if (cached is not null) return cached;

        // GetCountsAsync uses its own DbContextFactory-created context, so all
        // three calls can run concurrently without EF concurrency issues.
        var countsTask  = _repo.GetCountsAsync(ct);
        var pendingTask = _workflow.GetPendingForRoleAsync(string.Empty, ct);
        var healthTask  = _dataProvider.GetAllConnectorHealthAsync(ct);

        await Task.WhenAll(countsTask, pendingTask, healthTask);

        var counts  = countsTask.Result;
        var pending = pendingTask.Result;
        var health  = healthTask.Result;

        var dto = new DashboardSummaryDto(
            TotalSecurities:  counts.TotalSecurities,
            ActiveSecurities: counts.ActiveSecurities,
            PendingApprovals: pending.Count(),
            FailedImports:    counts.FailedImports,
            RunningJobs:      counts.RunningJobs,
            ConnectorHealth:  health
                .Select(c => new ConnectorHealthDto(c.Name, c.IsHealthy ? "Healthy" : "Unhealthy", c.Message))
                .ToList(),
            AsOf: DateTime.UtcNow);

        await _cache.SetAsync(key, dto, TimeSpan.FromSeconds(30), ct);
        return dto;
    }
}
