using Mediator;
using SecurityApp.Application.Dashboard.DTOs;

namespace SecurityApp.Application.Dashboard.Queries;

public record GetDashboardSummaryQuery : IQuery<DashboardSummaryDto>;
