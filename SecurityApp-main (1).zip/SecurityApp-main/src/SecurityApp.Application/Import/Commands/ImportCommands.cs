﻿using Mediator;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Application.Import.DTOs;
using SecurityApp.Core.Workflow.Enums;
using SecurityApp.Core.Workflow.Interfaces;

namespace SecurityApp.Application.Import.Commands;

/// <summary>Import a single security from an external provider by identifier.</summary>
public record ImportSecurityCommand(
    string IdentifierValue,
    IdentifierType IdentifierType,
    string? ProviderName,
    string? UserId,
    int AttemptNumber = 0) : ICommand<ImportResult>, IWorkflowGuardedCommand
{
    public WorkflowTriggerType WorkflowTrigger   => WorkflowTriggerType.Import;
    public Guid                WorkflowEntityId  => Guid.Empty;
    public string              WorkflowEntityType => "Import";
}

/// <summary>
/// Batch import a list of securities from an external provider.
/// Processes items in parallel (bounded concurrency) with a single aggregating ImportRequest.
/// Each item may override the default provider via <see cref="ImportSecurityRequest.ProviderName"/>.
/// </summary>
public record BatchImportSecuritiesCommand(
    List<ImportSecurityRequest> Securities,
    string? ProviderName,
    string? UserId) : ICommand<BatchImportResult>, IWorkflowGuardedCommand
{
    public WorkflowTriggerType WorkflowTrigger   => WorkflowTriggerType.Import;
    public Guid                WorkflowEntityId  => Guid.Empty;
    public string              WorkflowEntityType => "Import";
}

/// <summary>Import securities from a CSV stream, optionally using a named import profile.</summary>
public record ImportSecuritiesFromFileCommand(
    Stream FileStream,
    string FileName,
    string? ProfileName,
    string? UserId) : ICommand<BatchImportResult>, IWorkflowGuardedCommand
{
    public WorkflowTriggerType WorkflowTrigger   => WorkflowTriggerType.Import;
    public Guid                WorkflowEntityId  => Guid.Empty;
    public string              WorkflowEntityType => "Import";
}

/// <summary>Import prices from a CSV stream.</summary>
public record ImportPricesFromFileCommand(
    Stream FileStream,
    string FileName,
    string? UserId) : ICommand<BatchImportResult>, IWorkflowGuardedCommand
{
    public WorkflowTriggerType WorkflowTrigger   => WorkflowTriggerType.Import;
    public Guid                WorkflowEntityId  => Guid.Empty;
    public string              WorkflowEntityType => "Import";
}

/// <summary>
/// Import current or historical prices for a security from an external provider.
/// When FromDate and ToDate are both supplied the provider's historical endpoint is used;
/// otherwise only the current price is fetched.
/// </summary>
public record BatchImportPricesCommand(
    Guid SecurityId,
    string Symbol,
    DateTime? FromDate,
    DateTime? ToDate,
    string? ProviderName,
    string? UserId) : ICommand<BatchImportResult>, IWorkflowGuardedCommand
{
    public WorkflowTriggerType WorkflowTrigger   => WorkflowTriggerType.Import;
    public Guid                WorkflowEntityId  => SecurityId;
    public string              WorkflowEntityType => "Import";
}
