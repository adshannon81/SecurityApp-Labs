﻿using Mediator;
using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Application.Audit.Queries;
using SecurityApp.Application.Audit.DTOs;
using SecurityApp.Application.Import.DTOs;
using SecurityApp.Application.Import.Queries;
using SecurityApp.Application.Shared;

namespace SecurityApp.Application.Import.Handlers;

public sealed class GetAuditLogsHandler : IQueryHandler<GetAuditLogsQuery, PagedResult<AuditLogDto>>
{
    private readonly IImportUoW _unitOfWork;

    public GetAuditLogsHandler(IImportUoW unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    public async ValueTask<PagedResult<AuditLogDto>> Handle(GetAuditLogsQuery query, CancellationToken cancellationToken)
    {
        var (items, totalCount) = await _unitOfWork.AuditLogs.GetPagedAsync(
            predicate: l => (query.From       == null || l.CreatedAt   >= query.From)
                         && (query.To         == null || l.CreatedAt   <= query.To)
                         && (query.UserId     == null || l.UserId      == query.UserId)
                         && (query.EntityType == null || l.EntityType  == query.EntityType),
            orderBy:    l => l.CreatedAt,
            descending: true,
            page:       query.PageNumber,
            pageSize:   query.PageSize,
            cancellationToken);

        return new PagedResult<AuditLogDto>(
            Items: items.Select(l => new AuditLogDto
            {
                Id            = l.Id,
                EntityType    = l.EntityType,
                Action        = l.Action.ToString(),
                UserId        = l.UserId,
                UserName      = l.UserName,
                Details       = l.Details,
                IpAddress     = l.IpAddress,
                EntityId      = l.EntityId,
                CreatedAt     = l.CreatedAt,
                BeforeState   = l.BeforeState,
                AfterState    = l.AfterState,
                OldValues     = l.BeforeState,
                NewValues     = l.AfterState,
                ChangedFields = l.ChangedFields,
                CorrelationId = l.CorrelationId,
                CausationId   = l.CausationId,
                Source        = l.Source
            }).ToList(),
            TotalCount: totalCount,
            PageNumber: query.PageNumber,
            PageSize:   query.PageSize);
    }
}

public sealed class SearchExternalSecuritiesHandler : IQueryHandler<SearchExternalSecuritiesQuery, IEnumerable<SecuritySearchResult>>
{
    private readonly IDataProviderService _dataProviderService;

    public SearchExternalSecuritiesHandler(IDataProviderService dataProviderService)
    {
        _dataProviderService = dataProviderService;
    }

    public async ValueTask<IEnumerable<SecuritySearchResult>> Handle(SearchExternalSecuritiesQuery query, CancellationToken cancellationToken)
    {
        var results = await _dataProviderService.SearchSecuritiesAsync(query.Keyword, query.ProviderName, cancellationToken);

        return results.Select(r => new SecuritySearchResult
        {
            Symbol = r.Symbol,
            Name = r.Name,
            SecurityType = r.SecurityType.ToString(),
            Exchange = r.Exchange,
            Currency = r.Currency,
            Source = r.Source.ToString()
        });
    }
}

public sealed class GetImportRequestsHandler : IQueryHandler<GetImportRequestsQuery, PagedResult<ImportRequestDto>>
{
    private readonly IImportUoW _unitOfWork;

    public GetImportRequestsHandler(IImportUoW unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    public async ValueTask<PagedResult<ImportRequestDto>> Handle(GetImportRequestsQuery query, CancellationToken cancellationToken)
    {
        var (items, totalCount) = await _unitOfWork.ImportRequests.GetPagedAsync(
            predicate:  null,
            orderBy:    r => r.CreatedAt,
            descending: true,
            page:       query.PageNumber,
            pageSize:   query.PageSize,
            cancellationToken);

        return new PagedResult<ImportRequestDto>(
            Items: items.Select(r => new ImportRequestDto
            {
                Id               = r.Id,
                RequestType      = r.RequestType.ToString(),
                SourceSystem     = r.SourceSystem?.ToString(),
                TargetSystem     = r.TargetSystem?.ToString(),
                Status           = r.Status.ToString(),
                TotalRecords     = r.TotalRecords,
                ProcessedRecords = r.ProcessedRecords,
                FailedRecords    = r.FailedRecords,
                ErrorMessage     = r.ErrorMessage,
                CreatedAt        = r.CreatedAt,
                CompletedAt      = r.CompletedAt
            }).ToList(),
            TotalCount: totalCount,
            PageNumber: query.PageNumber,
            PageSize:   query.PageSize);
    }
}

public sealed class GetImportRequestByIdHandler : IQueryHandler<GetImportRequestByIdQuery, ImportRequestDto?>
{
    private readonly IImportUoW _unitOfWork;

    public GetImportRequestByIdHandler(IImportUoW unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    public async ValueTask<ImportRequestDto?> Handle(GetImportRequestByIdQuery query, CancellationToken cancellationToken)
    {
        var r = await _unitOfWork.ImportRequests.GetByIdAsync(query.ImportRequestId, cancellationToken);
        if (r == null) return null;

        return new ImportRequestDto
        {
            Id = r.Id,
            RequestType = r.RequestType.ToString(),
            SourceSystem = r.SourceSystem?.ToString(),
            TargetSystem = r.TargetSystem?.ToString(),
            Status = r.Status.ToString(),
            TotalRecords = r.TotalRecords,
            ProcessedRecords = r.ProcessedRecords,
            FailedRecords = r.FailedRecords,
            ErrorMessage = r.ErrorMessage,
            CreatedAt = r.CreatedAt,
            CompletedAt = r.CompletedAt
        };
    }
}

public sealed class ExportAuditLogsHandler : IQueryHandler<ExportAuditLogsQuery, IEnumerable<AuditLogDto>>
{
    private readonly IImportUoW _unitOfWork;

    public ExportAuditLogsHandler(IImportUoW unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    public async ValueTask<IEnumerable<AuditLogDto>> Handle(ExportAuditLogsQuery query, CancellationToken cancellationToken)
    {
        var items = await _unitOfWork.AuditLogs.FindAsync(
            l => (query.DateFrom   == null || l.CreatedAt  >= query.DateFrom)
              && (query.DateTo     == null || l.CreatedAt  <= query.DateTo)
              && (query.EntityType == null || l.EntityType == query.EntityType)
              && (query.EntityId   == null || l.EntityId   == query.EntityId),
            cancellationToken);

        return items
            .OrderBy(l => l.CreatedAt)
            .Select(l => new AuditLogDto
            {
                Id            = l.Id,
                EntityType    = l.EntityType,
                Action        = l.Action.ToString(),
                UserId        = l.UserId,
                UserName      = l.UserName,
                Details       = l.Details,
                IpAddress     = l.IpAddress,
                EntityId      = l.EntityId,
                CreatedAt     = l.CreatedAt,
                BeforeState   = l.BeforeState,
                AfterState    = l.AfterState,
                OldValues     = l.BeforeState,
                NewValues     = l.AfterState,
                ChangedFields = l.ChangedFields,
                CorrelationId = l.CorrelationId,
                CausationId   = l.CausationId,
                Source        = l.Source
            });
    }
}
