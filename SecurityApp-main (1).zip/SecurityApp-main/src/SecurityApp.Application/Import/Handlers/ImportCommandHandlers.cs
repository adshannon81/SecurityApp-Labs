﻿using ExcelDataReader;
using Mediator;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SecurityApp.Core.Shared.Configuration;
using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using SecurityApp.Core.Grpc;
using SecurityApp.Core.Securities.Models;
using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Core.Securities.Interfaces;
using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Core.Import.Entities;
using SecurityApp.Core.Pricing.Interfaces;
using SecurityApp.Application.Import.Commands;
using SecurityApp.Application.Import.DTOs;
using SecurityApp.Core.Import.Messages;
using SecurityApp.Core.Import.Models;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Securities.Entities;
using SecurityApp.Core.Pricing.Models;
using SecurityApp.Core.Pricing.Entities;
using SecurityApp.Core.Import.Enums;
using SecurityApp.Core.Shared.Enums;
using SecurityApp.Core.VendorSources.Interfaces;

namespace SecurityApp.Application.Import.Handlers;

/// <summary>
/// Imports a single security from an external provider.
/// <para>
/// This handler owns the <see cref="Core.Entities.ImportRequest"/> lifecycle only.
/// After a successful provider fetch it publishes <see cref="ImportCompletedEvent"/> so that
/// <see cref="SecurityApp.Infrastructure.Messaging.SecurityImportedHandler"/> (in the Securities slice)
/// performs the actual Security / SecurityAttribute / CreditRating upsert.
/// The Securities domain tables are therefore written exclusively from the Securities slice.
/// </para>
/// </summary>
public sealed class ImportSecurityHandler : ICommandHandler<ImportSecurityCommand, ImportResult>
{
    private readonly IImportUoW _importUoW;
    // Read-only view of Securities: needed for delta detection and to obtain the existing ID.
    // Per cross-slice rules, reads from another slice are permitted via a scoped interface.
    private readonly ISecuritiesUoW _securitiesUoW;
    private readonly IDataProviderService _dataProviderService;
    private readonly IVendorSnapshotService _vendorSnapshot;
    private readonly IEventBus _eventBus;
    private readonly ILogger<ImportSecurityHandler> _logger;

    public ImportSecurityHandler(
        IImportUoW importUoW,
        ISecuritiesUoW securitiesUoW,
        IDataProviderService dataProviderService,
        IVendorSnapshotService vendorSnapshot,
        IEventBus eventBus,
        ILogger<ImportSecurityHandler> logger)
    {
        _importUoW           = importUoW;
        _securitiesUoW       = securitiesUoW;
        _dataProviderService = dataProviderService;
        _vendorSnapshot      = vendorSnapshot;
        _eventBus            = eventBus;
        _logger              = logger;
    }

    public async ValueTask<ImportResult> Handle(ImportSecurityCommand command, CancellationToken cancellationToken)
    {
        var importRequest = new ImportRequest
        {
            RequestType      = RequestType.Import,
            SourceSystem     = DataSourceType.Other,  // updated after provider resolves
            Status           = RequestStatus.InProgress,
            UserId           = Guid.TryParse(command.UserId, out var uid1) ? uid1 : null,
            TotalRecords     = 1,
            ProcessedRecords = 0,
            FailedRecords    = 0,
            AttemptNumber    = command.AttemptNumber
        };
        await _importUoW.ImportRequests.AddAsync(importRequest, cancellationToken);
        await _importUoW.SaveChangesAsync(cancellationToken);

        try
        {
            var externalData = await _dataProviderService.GetSecurityAsync(
                command.IdentifierValue, command.IdentifierType, command.ProviderName, cancellationToken);

            if (externalData != null)
                importRequest.SourceSystem = externalData.Source;

            if (externalData == null)
            {
                importRequest.Status        = RequestStatus.Failed;
                importRequest.FailedRecords = 1;
                importRequest.ErrorMessage  = $"Security '{command.IdentifierValue}' not found in provider '{command.ProviderName ?? "Primary"}'.";
                importRequest.CompletedAt   = DateTime.UtcNow;
                await _importUoW.SaveChangesAsync(cancellationToken);
                return new ImportResult { Success = false, Message = importRequest.ErrorMessage, ImportRequestId = importRequest.Id };
            }

            // -- Read-only: find existing security for delta check and ID resolution --
            var matchingIdentifiers = await _securitiesUoW.SecurityIdentifiers.FindAsync(
                si => si.IdentifierType == command.IdentifierType.ToString() &&
                      si.IdentifierValue.ToLower() == command.IdentifierValue.ToLower() &&
                      si.IsCurrent && !si.IsDeleted,
                cancellationToken);
            var existingSecurityId = matchingIdentifiers.FirstOrDefault()?.SecurityId;
            var existing = existingSecurityId.HasValue
                ? await _securitiesUoW.Securities.GetByIdAsync(existingSecurityId.Value, cancellationToken)
                : null;

            // -- M4: Delta detection -------------------------------------------
            var newHash = ComputeContentHash(externalData);
            if (existing != null && existing.ContentHash == newHash)
            {
                // Nothing changed - skip DB write and count as skipped
                importRequest.Status           = RequestStatus.Completed;
                importRequest.ProcessedRecords = 0;
                importRequest.SkippedRecords   = 1;
                importRequest.CompletedAt      = DateTime.UtcNow;
                await _importUoW.SaveChangesAsync(cancellationToken);
                return new ImportResult
                {
                    Success         = true,
                    Message         = $"Security '{command.IdentifierValue}' unchanged - skipped.",
                    SecurityId      = existing.Id,
                    ImportRequestId = importRequest.Id
                };
            }

            // Pre-determine SecurityId so the caller can use it immediately.
            var securityId = existing?.Id ?? Guid.NewGuid();
            var isNew      = existing is null;

            // -- Publish event - Securities slice performs the actual upsert --
            await _eventBus.PublishAsync(new ImportCompletedEvent(
                securityId,
                isNew,
                command.IdentifierType,
                command.IdentifierValue,
                externalData,
                newHash,
                command.UserId), cancellationToken);

            // -- M11: persist raw vendor field snapshot --
            if (externalData.RawData.Count > 0)
            {
                await _vendorSnapshot.WriteSnapshotsAsync(
                    securityId,
                    externalData.Source,
                    externalData.RawData,
                    feedBatchId: importRequest.Id.ToString(),
                    receivedAt: externalData.FetchedAt,
                    cancellationToken);
            }

            importRequest.Status           = RequestStatus.Completed;
            importRequest.ProcessedRecords = 1;
            importRequest.CompletedAt      = DateTime.UtcNow;
            await _importUoW.SaveChangesAsync(cancellationToken);

            return new ImportResult
            {
                Success         = true,
                Message         = $"Security '{externalData.Name}' ({command.IdentifierValue}) imported successfully.",
                SecurityId      = securityId,
                ImportRequestId = importRequest.Id
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to import security {IdentifierValue}", command.IdentifierValue);
            importRequest.Status        = RequestStatus.Failed;
            importRequest.FailedRecords = 1;
            importRequest.ErrorMessage  = ex.Message;
            importRequest.CompletedAt   = DateTime.UtcNow;
            await _importUoW.SaveChangesAsync(cancellationToken);

            // Publish retry event for transient failures (network errors, rate-limiting, etc.).
            // ImportRetryConsumer handles exponential back-off; after MaxAttempts it dead-letters.
            // "Not found" failures (externalData == null above) are NOT retried - they return early.
            await _eventBus.PublishAsync(new ImportFailedEvent(
                importRequest.Id,
                command.IdentifierValue,
                command.IdentifierType,
                command.ProviderName,
                command.UserId,
                command.AttemptNumber), cancellationToken);

            return new ImportResult { Success = false, Message = ex.Message, ImportRequestId = importRequest.Id, Errors = [ex.Message] };
        }
    }

    // -- Content-hash helper (M4 delta detection) ------------------------------

    private static string ComputeContentHash(ExternalSecurityData data)
    {
        var content = string.Join("|",
            data.Symbol        ?? "",
            data.Name          ?? "",
            data.SecurityType.ToString(),
            data.Description   ?? "",
            data.Currency      ?? "",
            data.CouponRate?.ToString("G") ?? "",
            data.MaturityDate?.ToString("O") ?? "",
            data.IssueDate?.ToString("O")    ?? "",
            data.Rating        ?? "");
        var hash = SHA256.HashData(Encoding.UTF8.GetBytes(content));
        return Convert.ToHexString(hash).ToLowerInvariant();
    }
}

/// <summary>
/// Parses and imports securities from a file, optionally using a named import profile from the database.
/// When a profile is found, its delimiter, qualifier, HasHeader, SkipRows, column mappings, and
/// validation rules are applied. Rows with Error-level validation failures are reported but not imported.
/// Falls back to the values in Import:FileDefaults (appsettings.json) when no profile is specified.
/// </summary>
public sealed class ImportSecuritiesFromFileHandler : ICommandHandler<ImportSecuritiesFromFileCommand, BatchImportResult>
{
    private readonly IImportUoW _importUoW;
    private readonly ISecuritiesUoW _securitiesUoW;
    private readonly IImportProfileService _profileService;
    private readonly IImportValidationRunner _validationRunner;
    private readonly ICacheService _cacheService;
    private readonly ILogger<ImportSecuritiesFromFileHandler> _logger;
    private readonly ImportFileDefaultsOptions _fileDefaults;

    public ImportSecuritiesFromFileHandler(
        IImportUoW importUoW,
        ISecuritiesUoW securitiesUoW,
        IImportProfileService profileService,
        IImportValidationRunner validationRunner,
        ICacheService cacheService,
        ILogger<ImportSecuritiesFromFileHandler> logger,
        IOptions<ImportFileDefaultsOptions> fileDefaults)
    {
        _importUoW        = importUoW;
        _securitiesUoW    = securitiesUoW;
        _profileService   = profileService;
        _validationRunner = validationRunner;
        _cacheService     = cacheService;
        _logger           = logger;
        _fileDefaults     = fileDefaults.Value;
    }

    public async ValueTask<BatchImportResult> Handle(ImportSecuritiesFromFileCommand command, CancellationToken cancellationToken)
    {
        var bulkRequest = new ImportRequest
        {
            RequestType  = RequestType.Import,
            SourceSystem = DataSourceType.FlatFile,
            Status       = RequestStatus.InProgress
        };
        await _importUoW.ImportRequests.AddAsync(bulkRequest, cancellationToken);
        await _importUoW.SaveChangesAsync(cancellationToken);

        // Load import profile if specified
        ImportProfile? profile = null;
        if (!string.IsNullOrEmpty(command.ProfileName))
        {
            profile = await _profileService.GetByNameAsync(command.ProfileName, "FlatFile", cancellationToken);
            if (profile is null)
                _logger.LogWarning("Import profile '{ProfileName}' not found; falling back to default CSV parsing.", command.ProfileName);
        }

        // Parse file using profile settings (or defaults)
        var (rows, parseErrors) = await ParseFileAsync(command.FileStream, command.FileName, profile, cancellationToken);

        var allResults = new List<ImportResult>();
        int totalErrors = 0, totalWarnings = 0;

        // Promote parse errors to failure results immediately
        foreach (var pe in parseErrors)
        {
            allResults.Add(new ImportResult { Success = false, Message = pe, Errors = [pe] });
            totalErrors++;
        }

        // Load all existing identifiers once to build a lookup map (identifier_type, identifier_value) -> SecurityId.
        var allIdentifiers = await _securitiesUoW.SecurityIdentifiers.FindAsync(
            si => si.IsCurrent && !si.IsDeleted, cancellationToken);
        var identifierToSecurityId = allIdentifiers.ToDictionary(
            si => (si.IdentifierType, si.IdentifierValue.ToLowerInvariant()),
            si => si.SecurityId);
        // Load all existing securities by their IDs for content-hash delta detection.
        var referencedIds = identifierToSecurityId.Values.Distinct().ToHashSet();
        var allSecurities = await _securitiesUoW.Securities.GetAllAsync(cancellationToken);
        var existingById = allSecurities.Where(s => referencedIds.Contains(s.Id)).ToDictionary(s => s.Id);

        int rowNumber = 0;
        foreach (var row in rows)
        {
            rowNumber++;

            // Run per-row validation when profile has validation rules
            var validationErrors = new List<ImportValidationError>();
            if (profile != null)
            {
                validationErrors = await _validationRunner.ValidateRowAsync(profile, row, rowNumber, cancellationToken);
                totalErrors   += validationErrors.Count(e => e.Severity == "Error");
                totalWarnings += validationErrors.Count(e => e.Severity == "Warning");
            }

            var hasBlockingError = validationErrors.Any(e => e.Severity == "Error");

            if (!row.TryGetValue("identifiervalue", out var identifierValue) || string.IsNullOrWhiteSpace(identifierValue))
            {
                allResults.Add(new ImportResult
                {
                    Success          = false,
                    Message          = hasBlockingError
                        ? $"Row {rowNumber}: blocked by {validationErrors.Count(e => e.Severity == "Error")} validation error(s)."
                        : $"Row {rowNumber}: missing IdentifierValue.",
                    ValidationErrors = validationErrors
                });
                continue;
            }

            if (hasBlockingError)
            {
                allResults.Add(new ImportResult
                {
                    Success          = false,
                    Message          = $"Row {rowNumber}: blocked by {validationErrors.Count(e => e.Severity == "Error")} validation error(s).",
                    ValidationErrors = validationErrors
                });
                continue;
            }

            var idTypeRaw = row.GetValueOrDefault("identifiertype", "Ticker");
            var identifierType = Enum.TryParse<IdentifierType>(idTypeRaw, true, out var idType)
                ? idType : IdentifierType.Ticker;

            // Extract all available fields from the CSV row and upsert directly.
            // This avoids routing through a data-provider connector (which reads from
            // physical files on disk) - the uploaded file IS the data source.
            var name         = row.GetValueOrDefault("name");
            var typeStr      = row.GetValueOrDefault("type", "Other");
            var currency     = row.GetValueOrDefault("currency");
            var description  = row.GetValueOrDefault("description");
            var securityType = Enum.TryParse<SecurityType>(typeStr, true, out var st) ? st : SecurityType.Other;

            try
            {
                identifierToSecurityId.TryGetValue((identifierType.ToString(), identifierValue.Trim().ToLowerInvariant()), out var existingId);
                var existing = existingId != Guid.Empty && existingById.TryGetValue(existingId, out var s) ? s : null;

                // Delta detection: hash ALL mapped row values so any column change triggers a re-import,
                // regardless of which columns the active profile maps.
                var incomingHash = ComputeRowHash(row);
                if (existing?.ContentHash != null && existing.ContentHash == incomingHash)
                {
                    allResults.Add(new ImportResult
                    {
                        Success          = true,
                        Skipped          = true,
                        SecurityId       = existing.Id,
                        Message          = $"Row {rowNumber}: {identifierType}/{identifierValue} — unchanged, skipped.",
                        ValidationErrors = validationErrors,
                    });
                    continue;
                }

                Guid securityId;
                if (existing != null)
                {
                    if (name        != null) existing.Name        = name;
                    if (currency    != null) existing.CurrencyCode = currency;
                    if (description != null) existing.Description = description;
                    existing.Type        = securityType;
                    existing.DataSource  = DataSourceType.FlatFile;
                    existing.LastModifiedBy  = command.UserId;
                    existing.ContentHash = incomingHash;
                    await _securitiesUoW.Securities.UpdateAsync(existing, cancellationToken);
                    securityId = existing.Id;
                }
                else
                {
                    var security = new Security
                    {
                        Name            = name ?? identifierValue.Trim(),
                        Type            = securityType,
                        CurrencyCode    = currency,
                        Description     = description,
                        DataSource      = DataSourceType.FlatFile,
                        LastModifiedBy      = command.UserId,
                        ContentHash     = incomingHash
                    };
                    await _securitiesUoW.Securities.AddAsync(security, cancellationToken);
                    var identifier = new SecurityApp.Core.Securities.Entities.SecurityIdentifier
                    {
                        SecurityId      = security.Id,
                        IdentifierType  = identifierType.ToString(),
                        IdentifierValue = identifierValue.Trim(),
                        SourceSystem    = DataSourceType.FlatFile.ToString(),
                        IsPrimary       = true,
                    };
                    await _securitiesUoW.SecurityIdentifiers.AddAsync(identifier, cancellationToken);
                    // Add to lookup so duplicate rows within the same file resolve correctly.
                    identifierToSecurityId[(identifierType.ToString(), identifierValue.Trim().ToLowerInvariant())] = security.Id;
                    existingById[security.Id] = security;
                    securityId = security.Id;
                }
                allResults.Add(new ImportResult { Success = true, SecurityId = securityId, ValidationErrors = validationErrors });
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Row {RowNumber}: failed to upsert security {IdentifierValue}", rowNumber, identifierValue);
                allResults.Add(new ImportResult { Success = false, Message = ex.Message, Errors = [ex.Message] });
            }
        }

        await _securitiesUoW.SaveChangesAsync(cancellationToken);
        await _cacheService.RemoveByPatternAsync("security:all:*", cancellationToken);

        var skipped   = allResults.Count(r => r.Skipped);
        var succeeded = allResults.Count(r => r.Success && !r.Skipped);
        var failed    = allResults.Count(r => !r.Success);

        bulkRequest.TotalRecords     = allResults.Count;
        bulkRequest.ProcessedRecords = succeeded;
        bulkRequest.FailedRecords    = failed;
        bulkRequest.SkippedRecords   = skipped;
        bulkRequest.Status           = failed == 0 ? RequestStatus.Completed : RequestStatus.PartiallyCompleted;
        bulkRequest.CompletedAt      = DateTime.UtcNow;
        await _importUoW.SaveChangesAsync(cancellationToken);

        return new BatchImportResult
        {
            Total           = rows.Count + parseErrors.Count,
            Succeeded               = succeeded,
            Failed                  = failed,
            Skipped                 = skipped,
            Results                 = allResults,
            TotalValidationErrors   = totalErrors,
            TotalValidationWarnings = totalWarnings,
            ImportRequestId         = bulkRequest.Id
        };
    }

    /// <summary>
    /// Hashes all key-value pairs present in a parsed row so that any field change
    /// (regardless of which columns the active profile maps) invalidates the hash.
    /// Keys are sorted for determinism; values are trimmed.
    /// </summary>
    private static string ComputeRowHash(Dictionary<string, string> row)
    {
        var content = string.Join("|",
            row.OrderBy(kv => kv.Key, StringComparer.OrdinalIgnoreCase)
               .Select(kv => $"{kv.Key}={kv.Value.Trim()}"));
        var hash = SHA256.HashData(Encoding.UTF8.GetBytes(content));
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    // ── Format dispatcher ─────────────────────────────────────────────────────

    private async Task<(List<Dictionary<string, string>> rows, List<string> errors)> ParseFileAsync(
        Stream stream, string fileName, ImportProfile? profile, CancellationToken ct)
    {
        var ext = Path.GetExtension(fileName).ToLowerInvariant();
        return ext switch
        {
            ".xlsx" or ".xls" => ParseExcel(stream, profile, _fileDefaults),
            ".json"           => await ParseJsonAsync(stream, profile, ct),
            ".xml"            => await ParseXmlAsync(stream, profile, ct),
            _                 => await ParseCsvAsync(stream, profile, ct),
        };
    }

    // ── CSV / TXT ─────────────────────────────────────────────────────────────

    private async Task<(List<Dictionary<string, string>> rows, List<string> errors)> ParseCsvAsync(
        Stream stream, ImportProfile? profile, CancellationToken ct)
    {
        var errors = new List<string>();
        var rows   = new List<Dictionary<string, string>>();

        using var reader = new StreamReader(stream, leaveOpen: true);

        var delimiter = ParseDelimiterChar(profile?.Delimiter ?? _fileDefaults.Delimiter);
        var qualifier = ParseQualifierChar(profile?.TextQualifier ?? _fileDefaults.TextQualifier);
        var hasHeader = profile?.HasHeader ?? _fileDefaults.HasHeader;
        var skipRows  = profile?.SkipRows  ?? _fileDefaults.SkipRows;
        var cols      = profile?.Columns   ?? (ICollection<ImportProfileColumn>)new List<ImportProfileColumn>();

        var allLines = new List<string>();
        string? line;
        while ((line = await reader.ReadLineAsync(ct)) != null)
            allLines.Add(line);

        if (allLines.Count == 0) return (rows, errors);

        string[] headers;
        int startLine;
        if (hasHeader)
        {
            var headerFields = SplitLine(allLines[0], delimiter, qualifier);
            headers   = MapHeadersByName(headerFields, cols);
            startLine = 1 + skipRows;
        }
        else
        {
            var firstFields = SplitLine(allLines[0], delimiter, qualifier);
            headers   = MapHeadersByOrdinal(firstFields.Count, cols);
            startLine = skipRows;
        }

        for (int i = startLine; i < allLines.Count; i++)
        {
            if (string.IsNullOrWhiteSpace(allLines[i])) continue;
            var fields = SplitLine(allLines[i], delimiter, qualifier);
            var row    = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            for (int j = 0; j < headers.Length && j < fields.Count; j++)
                row[headers[j]] = fields[j];
            rows.Add(row);
        }

        return (rows, errors);
    }

    // ── Excel (.xlsx / .xls) ──────────────────────────────────────────────────

    private static (List<Dictionary<string, string>> rows, List<string> errors) ParseExcel(
        Stream stream, ImportProfile? profile, ImportFileDefaultsOptions fileDefaults)
    {
        // Required once to support non-Unicode encodings in older .xls files
        System.Text.Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

        var errors    = new List<string>();
        var rows      = new List<Dictionary<string, string>>();
        var hasHeader = profile?.HasHeader ?? fileDefaults.HasHeader;
        var skipRows  = profile?.SkipRows  ?? fileDefaults.SkipRows;
        var cols      = profile?.Columns   ?? new List<ImportProfileColumn>();

        using var excelReader = ExcelReaderFactory.CreateReader(stream);
        var dataSet = excelReader.AsDataSet(new ExcelDataSetConfiguration
        {
            ConfigureDataTable = _ => new ExcelDataTableConfiguration { UseHeaderRow = false }
        });

        if (dataSet.Tables.Count == 0) return (rows, errors);
        var table = dataSet.Tables[0];
        if (table.Rows.Count == 0) return (rows, errors);

        string[] headers;
        int startRow;
        if (hasHeader)
        {
            var headerCells = Enumerable.Range(0, table.Columns.Count)
                .Select(i => table.Rows[0][i]?.ToString() ?? string.Empty)
                .ToList();
            headers  = MapHeadersByName(headerCells, cols);
            startRow = 1 + skipRows;
        }
        else
        {
            headers  = MapHeadersByOrdinal(table.Columns.Count, cols);
            startRow = skipRows;
        }

        for (int r = startRow; r < table.Rows.Count; r++)
        {
            var dataRow = table.Rows[r];
            var allEmpty = Enumerable.Range(0, table.Columns.Count)
                .All(c => string.IsNullOrWhiteSpace(dataRow[c]?.ToString()));
            if (allEmpty) continue;

            var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            for (int c = 0; c < headers.Length && c < table.Columns.Count; c++)
                row[headers[c]] = dataRow[c]?.ToString() ?? string.Empty;
            rows.Add(row);
        }

        return (rows, errors);
    }

    // ── JSON ──────────────────────────────────────────────────────────────────

    private static async Task<(List<Dictionary<string, string>> rows, List<string> errors)> ParseJsonAsync(
        Stream stream, ImportProfile? profile, CancellationToken ct)
    {
        var errors = new List<string>();
        var rows   = new List<Dictionary<string, string>>();
        var cols   = profile?.Columns ?? new List<ImportProfileColumn>();

        using var doc = await JsonDocument.ParseAsync(stream, cancellationToken: ct);
        var root = doc.RootElement;

        // Navigate to records array via RecordsPath (dot-separated property path)
        if (!string.IsNullOrEmpty(profile?.RecordsPath))
        {
            foreach (var segment in profile.RecordsPath.Split('.', StringSplitOptions.RemoveEmptyEntries))
            {
                if (root.ValueKind == JsonValueKind.Object && root.TryGetProperty(segment, out var child))
                    root = child;
                else
                {
                    errors.Add($"JSON records path '{profile.RecordsPath}' could not be resolved.");
                    return (rows, errors);
                }
            }
        }

        if (root.ValueKind != JsonValueKind.Array)
        {
            errors.Add("JSON root (or resolved records path) is not an array.");
            return (rows, errors);
        }

        foreach (var element in root.EnumerateArray())
        {
            if (element.ValueKind != JsonValueKind.Object) continue;
            var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (var prop in element.EnumerateObject())
            {
                // Apply column mapping if defined; otherwise use property name as-is
                var mapping = cols.FirstOrDefault(c =>
                    string.Equals(c.SourceColumn, prop.Name, StringComparison.OrdinalIgnoreCase));
                var key = mapping?.TargetField.ToLowerInvariant() ?? prop.Name.ToLowerInvariant();
                row[key] = prop.Value.ValueKind == JsonValueKind.String
                    ? prop.Value.GetString() ?? string.Empty
                    : prop.Value.ToString();
            }
            rows.Add(row);
        }

        return (rows, errors);
    }

    // ── XML ───────────────────────────────────────────────────────────────────

    private static async Task<(List<Dictionary<string, string>> rows, List<string> errors)> ParseXmlAsync(
        Stream stream, ImportProfile? profile, CancellationToken ct)
    {
        var errors = new List<string>();
        var rows   = new List<Dictionary<string, string>>();
        var cols   = profile?.Columns ?? new List<ImportProfileColumn>();

        XDocument xdoc;
        try { xdoc = await XDocument.LoadAsync(stream, LoadOptions.None, ct); }
        catch (Exception ex) { errors.Add($"XML parse error: {ex.Message}"); return (rows, errors); }

        // Navigate to record elements via XPath-style slash path (e.g. "Securities/Security")
        IEnumerable<XElement> records;
        var xpath = profile?.RecordsXPath;
        if (!string.IsNullOrEmpty(xpath))
        {
            var segments = xpath.Split('/', StringSplitOptions.RemoveEmptyEntries);
            IEnumerable<XElement> current = xdoc.Root is not null ? new[] { xdoc.Root } : Enumerable.Empty<XElement>();
            // Skip first segment if it matches root name
            var start = string.Equals(segments[0], xdoc.Root?.Name.LocalName, StringComparison.OrdinalIgnoreCase) ? 1 : 0;
            for (int i = start; i < segments.Length - 1; i++)
            {
                var seg = segments[i];
                current = current.SelectMany(e => e.Elements().Where(c =>
                    string.Equals(c.Name.LocalName, seg, StringComparison.OrdinalIgnoreCase)));
            }
            var leafSeg = segments[^1];
            records = current.SelectMany(e => e.Elements().Where(c =>
                string.Equals(c.Name.LocalName, leafSeg, StringComparison.OrdinalIgnoreCase)));
        }
        else
        {
            // Default: all direct children of root
            records = xdoc.Root?.Elements() ?? Enumerable.Empty<XElement>();
        }

        foreach (var el in records)
        {
            var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            // Try child elements first, then attributes
            foreach (var child in el.Elements())
            {
                var mapping = cols.FirstOrDefault(c =>
                    string.Equals(c.SourceColumn, child.Name.LocalName, StringComparison.OrdinalIgnoreCase));
                var key = mapping?.TargetField.ToLowerInvariant() ?? child.Name.LocalName.ToLowerInvariant();
                row[key] = child.Value;
            }
            foreach (var attr in el.Attributes())
            {
                if (row.ContainsKey(attr.Name.LocalName.ToLowerInvariant())) continue;
                var mapping = cols.FirstOrDefault(c =>
                    string.Equals(c.SourceColumn, attr.Name.LocalName, StringComparison.OrdinalIgnoreCase));
                var key = mapping?.TargetField.ToLowerInvariant() ?? attr.Name.LocalName.ToLowerInvariant();
                row[key] = attr.Value;
            }
            if (row.Count > 0) rows.Add(row);
        }

        return (rows, errors);
    }

    // ── Shared header-mapping helpers ─────────────────────────────────────────

    private static string[] MapHeadersByName(IList<string> rawHeaders, ICollection<ImportProfileColumn> cols)
        => rawHeaders.Select(h =>
        {
            if (cols.Count == 0) return h.ToLowerInvariant();
            var mapping = cols.FirstOrDefault(c =>
                string.Equals(c.SourceColumn, h, StringComparison.OrdinalIgnoreCase));
            return mapping?.TargetField.ToLowerInvariant() ?? h.ToLowerInvariant();
        }).ToArray();

    private static string[] MapHeadersByOrdinal(int count, ICollection<ImportProfileColumn> cols)
        => Enumerable.Range(0, count).Select(i =>
        {
            if (cols.Count == 0) return i.ToString();
            var mapping = cols.FirstOrDefault(c => c.SourceColumn == i.ToString());
            return mapping?.TargetField.ToLowerInvariant() ?? i.ToString();
        }).ToArray();

    // -- RFC-4180 compatible CSV parser (same as FlatFileConnector) ------------

    private static List<string> SplitLine(string line, char delimiter, char? qualifier)
    {
        var fields = new List<string>();

        if (qualifier is null)
        {
            foreach (var f in line.Split(delimiter))
                fields.Add(f.Trim());
            return fields;
        }

        char q = qualifier.Value;
        var field = new System.Text.StringBuilder();
        bool inQuoted = false;
        int i = 0;

        while (i < line.Length)
        {
            char c = line[i];
            if (inQuoted)
            {
                if (c == q && i + 1 < line.Length && line[i + 1] == q)
                    { field.Append(q); i += 2; }
                else if (c == q)
                    { inQuoted = false; i++; }
                else
                    { field.Append(c); i++; }
            }
            else
            {
                if (c == q)               { inQuoted = true; i++; }
                else if (c == delimiter)  { fields.Add(field.ToString().Trim()); field.Clear(); i++; }
                else                      { field.Append(c); i++; }
            }
        }
        fields.Add(field.ToString().Trim());
        return fields;
    }

    private static char ParseDelimiterChar(string? delimiter)
    {
        if (string.IsNullOrEmpty(delimiter)) return ',';
        if (delimiter == "\\t" || delimiter == "\t") return '\t';
        return delimiter[0];
    }

    private static char? ParseQualifierChar(string? qualifier)
    {
        if (string.IsNullOrEmpty(qualifier)) return null;
        if (qualifier == "none") return null;
        if (qualifier == "\\\"" || qualifier == "\"") return '"';
        return qualifier[0];
    }
}

/// <summary>
/// Parses and imports prices from a CSV file.
/// Expected columns: SecurityId,Symbol,Price,PriceType,PriceDate,Currency
/// </summary>
public sealed class ImportPricesFromFileHandler : ICommandHandler<ImportPricesFromFileCommand, BatchImportResult>
{
    private readonly IMediator _mediator;
    private readonly IImportUoW _importUoW;
    private readonly ILogger<ImportPricesFromFileHandler> _logger;

    public ImportPricesFromFileHandler(IMediator mediator, IImportUoW importUoW, ILogger<ImportPricesFromFileHandler> logger)
    {
        _mediator  = mediator;
        _importUoW = importUoW;
        _logger    = logger;
    }

    public async ValueTask<BatchImportResult> Handle(ImportPricesFromFileCommand command, CancellationToken cancellationToken)
    {
        var bulkRequest = new ImportRequest
        {
            RequestType  = RequestType.Import,
            SourceSystem = DataSourceType.FlatFile,
            TargetSystem = DataSourceType.Other,
            Status       = RequestStatus.InProgress
        };
        await _importUoW.ImportRequests.AddAsync(bulkRequest, cancellationToken);
        await _importUoW.SaveChangesAsync(cancellationToken);

        var rows = ParseCsv(command.FileStream);
        var bulkResults = new List<BatchImportResult>();

        foreach (var row in rows)
        {
            if (!row.TryGetValue("SecurityId", out var secIdStr) || !Guid.TryParse(secIdStr, out var secId))
                continue;
            if (!row.TryGetValue("Symbol", out var symbol) || string.IsNullOrWhiteSpace(symbol))
                continue;

            var result = await _mediator.Send(
                new BatchImportPricesCommand(secId, symbol.Trim(), null, null, "FlatFile", command.UserId),
                cancellationToken);
            bulkResults.Add(result);
        }

        bulkRequest.TotalRecords     = rows.Count;
        bulkRequest.ProcessedRecords = bulkResults.Sum(r => r.Succeeded);
        bulkRequest.FailedRecords    = bulkResults.Sum(r => r.Failed);
        bulkRequest.Status           = bulkRequest.FailedRecords == 0 ? RequestStatus.Completed : RequestStatus.PartiallyCompleted;
        bulkRequest.CompletedAt      = DateTime.UtcNow;
        await _importUoW.SaveChangesAsync(cancellationToken);

        return new BatchImportResult
        {
            Total = rows.Count,
            Succeeded = bulkResults.Sum(r => r.Succeeded),
            Failed = bulkResults.Sum(r => r.Failed),
            Results = bulkResults.SelectMany(r => r.Results).ToList(),
            ImportRequestId = bulkRequest.Id
        };
    }

    private static List<Dictionary<string, string>> ParseCsv(Stream stream)
    {
        var rows = new List<Dictionary<string, string>>();
        using var reader = new StreamReader(stream, leaveOpen: true);
        var headerLine = reader.ReadLine();
        if (headerLine == null) return rows;
        var headers = headerLine.Split(',').Select(h => h.Trim()).ToArray();
        string? line;
        while ((line = reader.ReadLine()) != null)
        {
            if (string.IsNullOrWhiteSpace(line)) continue;
            var values = line.Split(',');
            var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < headers.Length && i < values.Length; i++)
                row[headers[i]] = values[i].Trim();
            rows.Add(row);
        }
        return rows;
    }
}

/// <summary>
/// Imports current or historical prices for a security from an external provider and persists them.
/// When both FromDate and ToDate are provided the provider's historical endpoint is used;
/// otherwise only the current price is fetched.
/// </summary>
public sealed class BatchImportPricesHandler : ICommandHandler<BatchImportPricesCommand, BatchImportResult>
{
    private readonly IImportUoW _importUoW;
    private readonly IPricingUoW _pricingUoW;
    // Read-only: verify the target security exists before attempting a price import.
    // Cross-slice reads are permitted per the vertical-slicing cross-slice rules.
    private readonly ISecuritiesUoW _securitiesUoW;
    private readonly IDataProviderService _dataProviderService;
    private readonly IVendorSnapshotService _vendorSnapshot;
    private readonly ICacheService _cacheService;
    private readonly IGrpcEventPublisher _grpcPublisher;
    private readonly ILogger<BatchImportPricesHandler> _logger;

    public BatchImportPricesHandler(
        IImportUoW importUoW,
        IPricingUoW pricingUoW,
        ISecuritiesUoW securitiesUoW,
        IDataProviderService dataProviderService,
        IVendorSnapshotService vendorSnapshot,
        ICacheService cacheService,
        IGrpcEventPublisher grpcPublisher,
        ILogger<BatchImportPricesHandler> logger)
    {
        _importUoW           = importUoW;
        _pricingUoW          = pricingUoW;
        _securitiesUoW       = securitiesUoW;
        _dataProviderService = dataProviderService;
        _vendorSnapshot      = vendorSnapshot;
        _cacheService        = cacheService;
        _grpcPublisher       = grpcPublisher;
        _logger              = logger;
    }

    public async ValueTask<BatchImportResult> Handle(BatchImportPricesCommand command, CancellationToken cancellationToken)
    {
        var importRequest = new ImportRequest
        {
            RequestType  = RequestType.Import,
            SourceSystem = DataSourceType.Other,
            TargetSystem = DataSourceType.Other,
            Status       = RequestStatus.InProgress
        };
        await _importUoW.ImportRequests.AddAsync(importRequest, cancellationToken);
        await _importUoW.SaveChangesAsync(cancellationToken);

        IEnumerable<ExternalPriceData> priceDatas;
        try
        {
            if (command.FromDate.HasValue && command.ToDate.HasValue)
            {
                priceDatas = await _dataProviderService.GetHistoricalPricesAsync(
                    command.Symbol,
                    command.FromDate.Value,
                    command.ToDate.Value,
                    command.ProviderName,
                    cancellationToken);
            }
            else
            {
                var single = await _dataProviderService.GetCurrentPriceAsync(
                    command.Symbol, command.ProviderName, cancellationToken);
                priceDatas = single != null ? [single] : [];
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Provider fetch failed for symbol {Symbol}", command.Symbol);
            importRequest.Status       = RequestStatus.Failed;
            importRequest.ErrorMessage = ex.Message;
            importRequest.CompletedAt  = DateTime.UtcNow;
            await _importUoW.SaveChangesAsync(cancellationToken);
            return new BatchImportResult { Total = 0, ImportRequestId = importRequest.Id };
        }

        var list = priceDatas.ToList();
        importRequest.TotalRecords = list.Count;

        // Guard: verify the target security exists (cross-slice read, allowed per slicing rules)
        if (list.Count > 0)
        {
            var security = await _securitiesUoW.Securities.GetByIdAsync(command.SecurityId, cancellationToken);
            if (security is null)
            {
                _logger.LogWarning("Security {SecurityId} not found; cannot import prices for symbol {Symbol}",
                    command.SecurityId, command.Symbol);
                importRequest.Status        = RequestStatus.Failed;
                importRequest.FailedRecords = list.Count;
                importRequest.ErrorMessage  = $"Security {command.SecurityId} not found.";
                importRequest.CompletedAt   = DateTime.UtcNow;
                await _importUoW.SaveChangesAsync(cancellationToken);
                return new BatchImportResult
                {
                    Total           = list.Count,
                    Succeeded       = 0,
                    Failed          = list.Count,
                    Results         = list.Select(_ => new ImportResult
                    {
                        Success = false,
                        Message = $"Security {command.SecurityId} not found.",
                        Errors  = [$"Security {command.SecurityId} not found."]
                    }).ToList(),
                    ImportRequestId = importRequest.Id
                };
            }
        }

        int succeeded = 0, failed = 0;
        var results = new List<ImportResult>();

        foreach (var pd in list)
        {
            try
            {
                var price = new Price
                {
                    SecurityId = command.SecurityId,
                    Value      = pd.Price,
                    Source     = pd.Source,
                    PriceDate  = pd.PriceDate,
                    PriceType  = pd.PriceType,
                    Currency   = pd.Currency,
                    LastModifiedBy = command.UserId
                };
                await _pricingUoW.Prices.AddAsync(price, cancellationToken);
                results.Add(new ImportResult { Success = true, Message = $"Price {pd.Price} ({pd.PriceDate:yyyy-MM-dd}) imported.", ImportRequestId = importRequest.Id });
                succeeded++;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to persist price for {Symbol} on {Date}", command.Symbol, pd.PriceDate);
                results.Add(new ImportResult { Success = false, Message = ex.Message, Errors = [ex.Message], ImportRequestId = importRequest.Id });
                failed++;
            }
        }

        await _pricingUoW.SaveChangesAsync(cancellationToken);

        // -- M11: persist raw price field snapshots for each fetched price --
        foreach (var pd in list)
        {
            var priceFields = new Dictionary<string, string?>
            {
                ["Price"]     = pd.Price.ToString("G"),
                ["PriceType"] = pd.PriceType,
                ["PriceDate"] = pd.PriceDate.ToString("O"),
                ["Currency"]  = pd.Currency,
                ["OpenPrice"] = pd.OpenPrice?.ToString("G"),
                ["HighPrice"] = pd.HighPrice?.ToString("G"),
                ["LowPrice"]  = pd.LowPrice?.ToString("G"),
                ["BidPrice"]  = pd.BidPrice?.ToString("G"),
                ["AskPrice"]  = pd.AskPrice?.ToString("G"),
                ["Volume"]    = pd.Volume?.ToString()
            };
            await _vendorSnapshot.WriteSnapshotsAsync(
                command.SecurityId,
                pd.Source,
                priceFields,
                feedBatchId: importRequest.Id.ToString(),
                receivedAt: pd.FetchedAt,
                cancellationToken);
        }

        importRequest.ProcessedRecords = succeeded;
        importRequest.FailedRecords    = failed;
        importRequest.Status           = failed == 0 ? RequestStatus.Completed : RequestStatus.PartiallyCompleted;
        importRequest.CompletedAt      = DateTime.UtcNow;
        await _importUoW.SaveChangesAsync(cancellationToken);

        if (succeeded > 0)
        {
            _logger.LogInformation(
                "BatchImportPrices: imported {Count} price(s) for {Symbol}",
                succeeded, command.Symbol);

            await _cacheService.RemoveByPatternAsync($"price:list:{command.SecurityId}:*", cancellationToken);
            await _cacheService.RemoveByPatternAsync($"price:latest:{command.SecurityId}:*", cancellationToken);

            // Publish the most recently dated successful price to gRPC price-tick streams
            var latestPd = list.MaxBy(p => p.PriceDate);
            if (latestPd is not null)
            {
                await _grpcPublisher.PublishPriceChangedAsync(new PriceChangedPayload(
                    command.SecurityId, latestPd.Price, latestPd.Currency,
                    latestPd.Source.ToString(), latestPd.PriceType,
                    latestPd.PriceDate, DateTime.UtcNow), cancellationToken);
            }
        }

        return new BatchImportResult
        {
            Total           = list.Count,
            Succeeded       = succeeded,
            Failed          = failed,
            Results         = results,
            ImportRequestId = importRequest.Id
        };
    }
}

/// <summary>
/// Batch-imports a list of securities in parallel (bounded to 10 concurrent tasks).
/// Every parallel branch gets its own DI scope so each dispatch of
/// <see cref="ImportSecurityCommand"/> uses an isolated DbContext.
/// A single parent <see cref="ImportRequest"/> aggregates the final totals.
/// </summary>
public sealed class BatchImportSecuritiesHandler : ICommandHandler<BatchImportSecuritiesCommand, BatchImportResult>
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly IImportUoW _importUoW;
    private readonly IEventBus _eventBus;
    private readonly ILogger<BatchImportSecuritiesHandler> _logger;

    public BatchImportSecuritiesHandler(
        IServiceScopeFactory scopeFactory,
        IImportUoW importUoW,
        IEventBus eventBus,
        ILogger<BatchImportSecuritiesHandler> logger)
    {
        _scopeFactory = scopeFactory;
        _importUoW    = importUoW;
        _eventBus     = eventBus;
        _logger       = logger;
    }

    public async ValueTask<BatchImportResult> Handle(
        BatchImportSecuritiesCommand command,
        CancellationToken cancellationToken)
    {
        var batchRequest = new ImportRequest
        {
            RequestType      = RequestType.Import,
            SourceSystem     = DataSourceType.Other,
            Status           = RequestStatus.InProgress,
            TotalRecords     = command.Securities.Count,
            ProcessedRecords = 0,
            FailedRecords    = 0
        };
        await _importUoW.ImportRequests.AddAsync(batchRequest, cancellationToken);
        await _importUoW.SaveChangesAsync(cancellationToken);

        var results = new ConcurrentBag<ImportResult>();
        var sem     = new SemaphoreSlim(10, 10);

        var tasks = command.Securities.Select(async req =>
        {
            await sem.WaitAsync(cancellationToken);
            try
            {
                using var scope  = _scopeFactory.CreateScope();
                var mediator     = scope.ServiceProvider.GetRequiredService<IMediator>();
                var providerName = req.ProviderName ?? command.ProviderName;
                var result       = await mediator.Send(
                    new ImportSecurityCommand(req.IdentifierValue, req.IdentifierType, providerName, command.UserId),
                    cancellationToken);
                results.Add(result);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Batch import failed for identifier {IdentifierValue}", req.IdentifierValue);
                results.Add(new ImportResult
                {
                    Success = false,
                    Message = ex.Message,
                    Errors  = [ex.Message]
                });
            }
            finally
            {
                sem.Release();
            }
        });

        await Task.WhenAll(tasks);

        var resultList = results.ToList();

        batchRequest.ProcessedRecords = resultList.Count(r => r.Success);
        batchRequest.SkippedRecords   = resultList.Count(r => r.Success && r.Message?.Contains("unchanged") == true);
        batchRequest.FailedRecords    = resultList.Count(r => !r.Success);
        batchRequest.Status           = batchRequest.FailedRecords == 0
            ? RequestStatus.Completed
            : RequestStatus.PartiallyCompleted;
        batchRequest.CompletedAt = DateTime.UtcNow;
        await _importUoW.SaveChangesAsync(cancellationToken);

        return new BatchImportResult
        {
            Total           = command.Securities.Count,
            Succeeded       = resultList.Count(r => r.Success),
            Failed          = resultList.Count(r => !r.Success),
            Results         = resultList,
            ImportRequestId = batchRequest.Id
        };
    }
}
