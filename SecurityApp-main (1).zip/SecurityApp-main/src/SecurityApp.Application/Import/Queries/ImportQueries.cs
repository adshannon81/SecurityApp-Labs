﻿using Mediator;
using SecurityApp.Application.Import.DTOs;
using SecurityApp.Application.Shared;

namespace SecurityApp.Application.Import.Queries;

/// <summary>Search an external provider for securities by keyword (does not save to DB).</summary>
public record SearchExternalSecuritiesQuery(
    string Keyword,
    string? ProviderName) : IQuery<IEnumerable<SecuritySearchResult>>;

/// <summary>Get paginated list of import request history.</summary>
public record GetImportRequestsQuery(
    int PageNumber = 1,
    int PageSize = 50) : IQuery<PagedResult<ImportRequestDto>>;

/// <summary>Get a single import request by ID.</summary>
public record GetImportRequestByIdQuery(Guid ImportRequestId) : IQuery<ImportRequestDto?>;
