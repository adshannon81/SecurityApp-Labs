namespace SecurityApp.Application.Import.DTOs;

public class SecuritySearchResult
{
    public string Symbol { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string SecurityType { get; set; } = string.Empty;
    public string? Exchange { get; set; }
    public string? Currency { get; set; }
    public string Source { get; set; } = string.Empty;
}
