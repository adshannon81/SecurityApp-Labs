namespace SecurityApp.Application.Import.DTOs;

public class ImportProfileColumnDto
{
    public Guid Id { get; set; }
    public string SourceColumn { get; set; } = string.Empty;
    public string TargetField { get; set; } = string.Empty;
    public int SortOrder { get; set; }
    public List<ImportProfileColumnValidationDto> Validations { get; set; } = new();
}
