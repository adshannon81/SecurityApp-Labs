namespace SecurityApp.Application.Import.DTOs;

public class CreateImportProfileRequest
{
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string SourceType { get; set; } = string.Empty;
    public string FilePattern { get; set; } = "*.csv";
    public string? Folder { get; set; }

    // FlatFile
    public string? Delimiter { get; set; }
    public string? TextQualifier { get; set; }
    public bool HasHeader { get; set; } = true;
    public int SkipRows { get; set; }

    // JsonFile
    public string? RecordsPath { get; set; }

    // XmlFile
    public string? RecordsXPath { get; set; }

    public List<ImportProfileColumnRequest> Columns { get; set; } = new();
    public List<ImportProfileRowValidationRequest> RowValidations { get; set; } = new();
}
