namespace SecurityApp.Application.Import.DTOs;

public class ImportProfileColumnRequest
{
    public string SourceColumn { get; set; } = string.Empty;
    public string TargetField { get; set; } = string.Empty;
    public int SortOrder { get; set; }
    public List<ImportProfileColumnValidationRequest> Validations { get; set; } = new();
}
