namespace SecurityApp.Application.Import.DTOs;

public class ImportProfileRowValidationDto
{
    public Guid Id { get; set; }
    public string Expression { get; set; } = string.Empty;
    public string ErrorMessage { get; set; } = string.Empty;
    public string Severity { get; set; } = string.Empty;
    public int SortOrder { get; set; }
    public bool IsActive { get; set; }
}
