namespace SecurityApp.Application.Import.DTOs;

public class ImportProfileDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string SourceType { get; set; } = string.Empty;
    public string FilePattern { get; set; } = string.Empty;
    public string? Folder { get; set; }
    public string? Delimiter { get; set; }
    public string? TextQualifier { get; set; }
    public bool HasHeader { get; set; }
    public int SkipRows { get; set; }
    public string? RecordsPath { get; set; }
    public string? RecordsXPath { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? LastModifiedAt { get; set; }
    public List<ImportProfileColumnDto> Columns { get; set; } = new();
    public List<ImportProfileRowValidationDto> RowValidations { get; set; } = new();
}
