using SecurityApp.Core.Securities.Enums;

namespace SecurityApp.Application.Import.DTOs;

public class ImportSecurityRequest
{
    public string IdentifierValue { get; set; } = string.Empty;
    public IdentifierType IdentifierType { get; set; } = IdentifierType.Ticker;
    public string? ProviderName { get; set; }
}
