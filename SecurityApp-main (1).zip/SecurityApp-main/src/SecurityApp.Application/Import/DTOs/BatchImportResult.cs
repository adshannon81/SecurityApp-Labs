namespace SecurityApp.Application.Import.DTOs;

public class BatchImportResult
{
    public int Total { get; set; }
    public int Succeeded { get; set; }
    public int Failed { get; set; }
    public int Skipped { get; set; }
    public List<ImportResult> Results { get; set; } = new();
    public Guid ImportRequestId { get; set; }
    public int TotalValidationErrors { get; set; }
    public int TotalValidationWarnings { get; set; }
}
