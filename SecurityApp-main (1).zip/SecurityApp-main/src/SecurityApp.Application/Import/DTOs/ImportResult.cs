using SecurityApp.Core.Import.Models;

namespace SecurityApp.Application.Import.DTOs;

public class ImportResult
{
    public bool Success { get; set; }
    public bool Skipped { get; set; }
    public string Message { get; set; } = string.Empty;
    public Guid? SecurityId { get; set; }
    public Guid? ImportRequestId { get; set; }
    public List<string> Errors { get; set; } = new();
    public List<ImportValidationError> ValidationErrors { get; set; } = new();
}
