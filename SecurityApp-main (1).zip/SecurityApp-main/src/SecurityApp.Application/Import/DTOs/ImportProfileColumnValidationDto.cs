namespace SecurityApp.Application.Import.DTOs;

public class ImportProfileColumnValidationDto
{
    public Guid Id { get; set; }
    public string RuleType { get; set; } = string.Empty;
    public string? RuleValue { get; set; }
    public string? Condition { get; set; }
    public string? ErrorMessage { get; set; }
    public string Severity { get; set; } = string.Empty;
    public bool IsActive { get; set; }
}
