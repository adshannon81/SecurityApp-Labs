namespace SecurityApp.Application.Import.DTOs;

public class ImportRequestDto
{
    public Guid Id { get; set; }
    public string RequestType { get; set; } = string.Empty;
    public string? SourceSystem { get; set; }
    public string? TargetSystem { get; set; }
    public string Status { get; set; } = string.Empty;
    public int? TotalRecords { get; set; }
    public int? ProcessedRecords { get; set; }
    public int? FailedRecords { get; set; }
    public string? ErrorMessage { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
}
