namespace SecurityApp.Application.Import.DTOs;

public class ImportProfileColumnValidationRequest
{
    public string RuleType { get; set; } = string.Empty;
    public string? RuleValue { get; set; }
    public string? Condition { get; set; }
    public string? ErrorMessage { get; set; }
    public string Severity { get; set; } = "Error";
}
