namespace SecurityApp.Application.Import.DTOs;

public class ImportProfileRowValidationRequest
{
    public string Expression { get; set; } = string.Empty;
    public string ErrorMessage { get; set; } = string.Empty;
    public string Severity { get; set; } = "Error";
    public int SortOrder { get; set; }
}
