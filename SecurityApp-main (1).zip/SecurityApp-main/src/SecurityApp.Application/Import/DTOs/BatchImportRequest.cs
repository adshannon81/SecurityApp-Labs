namespace SecurityApp.Application.Import.DTOs;

public class BatchImportRequest
{
    public List<ImportSecurityRequest> Securities { get; set; } = new();
    public string? ProviderName { get; set; }
}
