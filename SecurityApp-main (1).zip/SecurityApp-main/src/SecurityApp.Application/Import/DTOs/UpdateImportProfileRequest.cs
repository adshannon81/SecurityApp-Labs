namespace SecurityApp.Application.Import.DTOs;

public class UpdateImportProfileRequest
{
    public string? Description { get; set; }
    public string? FilePattern { get; set; }
    public string? Folder { get; set; }
    public string? Delimiter { get; set; }
    public string? TextQualifier { get; set; }
    public bool? HasHeader { get; set; }
    public int? SkipRows { get; set; }
    public string? RecordsPath { get; set; }
    public string? RecordsXPath { get; set; }
    public bool? IsActive { get; set; }
}
