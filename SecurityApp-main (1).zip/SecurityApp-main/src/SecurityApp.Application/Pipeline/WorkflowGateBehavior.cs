using Mediator;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using SecurityApp.Core.Shared.Exceptions;
using SecurityApp.Core.Workflow.Entities;
using SecurityApp.Core.Workflow.Enums;
using SecurityApp.Core.Workflow.Interfaces;

namespace SecurityApp.Application.Pipeline;

/// <summary>
/// Mediator pipeline behavior that intercepts every command implementing
/// <see cref="IWorkflowGuardedCommand"/> and enforces a workflow gate before
/// allowing the handler to run.
///
/// Logic:
///   1. If an existing Pending instance exists for this entity + trigger → 202 (throw WorkflowPendingException).
///   2. Trigger a new workflow instance.
///      - If the instance is immediately Approved (no definition matched, or all steps are automated) → proceed.
///      - Otherwise → 202 (throw WorkflowPendingException).
///
/// When no WorkflowDefinition is configured for the trigger the engine returns
/// an auto-approved stub and the command executes normally — zero ceremony for
/// unconfigured triggers.
/// </summary>
public sealed class WorkflowGateBehavior<TMessage, TResponse>(
    IWorkflowEngine workflowEngine,
    IHttpContextAccessor httpContextAccessor,
    ILogger<WorkflowGateBehavior<TMessage, TResponse>> logger)
    : IPipelineBehavior<TMessage, TResponse>
    where TMessage : IMessage
{
    public async ValueTask<TResponse> Handle(
        TMessage message,
        MessageHandlerDelegate<TMessage, TResponse> next,
        CancellationToken cancellationToken)
    {
        if (message is not IWorkflowGuardedCommand guarded)
            return await next(message, cancellationToken);

        var triggeredBy = httpContextAccessor.HttpContext?.User?.Identity?.Name
                          ?? httpContextAccessor.HttpContext?.User?.FindFirst("sub")?.Value
                          ?? "system";

        var entityId   = guarded.WorkflowEntityId == Guid.Empty ? Guid.NewGuid() : guarded.WorkflowEntityId;
        var trigger    = guarded.WorkflowTrigger;
        var entityType = guarded.WorkflowEntityType;

        // Check for an already-pending gate on this entity
        if (guarded.WorkflowEntityId != Guid.Empty)
        {
            var existing = await workflowEngine.GetActiveGateAsync(trigger, entityId, cancellationToken);
            if (existing is { Status: WorkflowStatus.Pending })
            {
                logger.LogInformation(
                    "Command {Command} blocked by existing workflow gate {InstanceId} for {EntityType}/{EntityId}",
                    typeof(TMessage).Name, existing.Id, entityType, entityId);
                throw new WorkflowPendingException(existing);
            }
        }

        // Trigger a new workflow evaluation.
        // Pass a minimal serializable payload rather than the command itself,
        // since commands may contain non-serializable members (e.g. Stream).
        var safePayload = new { entityId, entityType, trigger = trigger.ToString() };
        var instance = await workflowEngine.TriggerAsync(
            trigger, entityType, entityId, safePayload, triggeredBy, cancellationToken);

        if (instance.Status != WorkflowStatus.Approved)
        {
            logger.LogInformation(
                "Command {Command} requires workflow approval — instance {InstanceId} status {Status}",
                typeof(TMessage).Name, instance.Id, instance.Status);
            throw new WorkflowPendingException(instance);
        }

        logger.LogDebug(
            "Command {Command} workflow gate passed (auto-approved) for {EntityType}/{EntityId}",
            typeof(TMessage).Name, entityType, entityId);

        return await next(message, cancellationToken);
    }
}
