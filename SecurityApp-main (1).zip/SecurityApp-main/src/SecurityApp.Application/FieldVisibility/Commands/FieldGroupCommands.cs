using Mediator;
using SecurityApp.Application.FieldVisibility.DTOs;

namespace SecurityApp.Application.FieldVisibility.Commands;

public record CreateFieldGroupCommand(CreateFieldGroupRequest Request, string? UserId)
    : ICommand<FieldGroupDto>;

public record UpdateFieldGroupCommand(Guid Id, UpdateFieldGroupRequest Request, string? UserId)
    : ICommand<FieldGroupDto>;

public record DeleteFieldGroupCommand(Guid Id) : ICommand;

public record AddFieldGroupMemberCommand(Guid GroupId, AddFieldGroupMemberRequest Request, string? UserId)
    : ICommand<FieldGroupMemberDto>;

public record RemoveFieldGroupMemberCommand(Guid MemberId) : ICommand;
