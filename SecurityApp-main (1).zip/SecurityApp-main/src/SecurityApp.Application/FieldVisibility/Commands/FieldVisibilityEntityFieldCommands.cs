using Mediator;
using SecurityApp.Application.FieldVisibility.DTOs;

namespace SecurityApp.Application.FieldVisibility.Commands;

public record CreateFieldVisibilityEntityCommand(CreateFieldVisibilityEntityRequest Request, string? UserId)
    : ICommand<FieldVisibilityEntityDto>;

public record UpdateFieldVisibilityEntityCommand(Guid Id, UpdateFieldVisibilityEntityRequest Request, string? UserId)
    : ICommand<FieldVisibilityEntityDto>;

public record DeleteFieldVisibilityEntityCommand(Guid Id) : ICommand;

public record CreateFieldVisibilityFieldCommand(CreateFieldVisibilityFieldRequest Request, string? UserId)
    : ICommand<FieldVisibilityFieldDto>;

public record UpdateFieldVisibilityFieldCommand(Guid Id, UpdateFieldVisibilityFieldRequest Request, string? UserId)
    : ICommand<FieldVisibilityFieldDto>;

public record DeleteFieldVisibilityFieldCommand(Guid Id) : ICommand;
