using Mediator;
using SecurityApp.Application.FieldVisibility.DTOs;

namespace SecurityApp.Application.FieldVisibility.Commands;

public record CreateFieldVisibilityRuleCommand(CreateFieldVisibilityRuleRequest Request, string? UserId)
    : ICommand<FieldVisibilityRuleDto>;

public record UpdateFieldVisibilityRuleCommand(Guid Id, UpdateFieldVisibilityRuleRequest Request, string? UserId)
    : ICommand<FieldVisibilityRuleDto>;

public record DeleteFieldVisibilityRuleCommand(Guid Id) : ICommand;
