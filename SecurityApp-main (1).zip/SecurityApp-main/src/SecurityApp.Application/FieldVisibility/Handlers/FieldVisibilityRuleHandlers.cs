using Mediator;
using SecurityApp.Application.FieldVisibility.Commands;
using SecurityApp.Application.FieldVisibility.DTOs;
using SecurityApp.Application.FieldVisibility.Queries;
using SecurityApp.Core.FieldVisibility;
using SecurityApp.Core.FieldVisibility.Enums;

namespace SecurityApp.Application.FieldVisibility.Handlers;

public class GetAllFieldVisibilityRulesHandler(IFieldVisibilityRuleRepository repo)
    : IQueryHandler<GetAllFieldVisibilityRulesQuery, IReadOnlyList<FieldVisibilityRuleDto>>
{
    public async ValueTask<IReadOnlyList<FieldVisibilityRuleDto>> Handle(
        GetAllFieldVisibilityRulesQuery query, CancellationToken ct)
    {
        var rules = await repo.GetAllAsync(ct);
        return rules.Select(FieldVisibilityRuleMappings.ToDto).ToList();
    }
}

public class GetFieldVisibilityRuleByIdHandler(IFieldVisibilityRuleRepository repo)
    : IQueryHandler<GetFieldVisibilityRuleByIdQuery, FieldVisibilityRuleDto?>
{
    public async ValueTask<FieldVisibilityRuleDto?> Handle(
        GetFieldVisibilityRuleByIdQuery query, CancellationToken ct)
    {
        var rule = await repo.GetByIdAsync(query.Id, ct);
        return rule is null ? null : FieldVisibilityRuleMappings.ToDto(rule);
    }
}

public class GetFieldVisibilityRulesByFieldHandler(IFieldVisibilityRuleRepository repo)
    : IQueryHandler<GetFieldVisibilityRulesByFieldQuery, IReadOnlyList<FieldVisibilityRuleDto>>
{
    public async ValueTask<IReadOnlyList<FieldVisibilityRuleDto>> Handle(
        GetFieldVisibilityRulesByFieldQuery query, CancellationToken ct)
    {
        var rules = await repo.GetByFieldIdAsync(query.FieldId, ct);
        return rules.Select(FieldVisibilityRuleMappings.ToDto).ToList();
    }
}

public class CreateFieldVisibilityRuleHandler(IFieldVisibilityRuleRepository repo)
    : ICommandHandler<CreateFieldVisibilityRuleCommand, FieldVisibilityRuleDto>
{
    public async ValueTask<FieldVisibilityRuleDto> Handle(
        CreateFieldVisibilityRuleCommand command, CancellationToken ct)
    {
        var req  = command.Request;
        var rule = new FieldVisibilityRule
        {
            FieldVisibilityFieldId = req.FieldVisibilityFieldId,
            PermissionDefinitionId = req.PermissionDefinitionId,
            VisibilityState        = req.VisibilityState,
            ObfuscationType        = Enum.Parse<ObfuscationType>(req.ObfuscationType, ignoreCase: true),
            Priority               = req.Priority,
            IsActive               = true,
            EffectiveFrom          = req.EffectiveFrom,
            EffectiveTo            = req.EffectiveTo,
            LastModifiedBy             = command.UserId,
        };
        var created = await repo.CreateAsync(rule, ct);
        return FieldVisibilityRuleMappings.ToDto(created);
    }
}

public class UpdateFieldVisibilityRuleHandler(IFieldVisibilityRuleRepository repo)
    : ICommandHandler<UpdateFieldVisibilityRuleCommand, FieldVisibilityRuleDto>
{
    public async ValueTask<FieldVisibilityRuleDto> Handle(
        UpdateFieldVisibilityRuleCommand command, CancellationToken ct)
    {
        var existing = await repo.GetByIdAsync(command.Id, ct)
            ?? throw new KeyNotFoundException($"FieldVisibilityRule {command.Id} not found.");

        var req = command.Request;
        existing.FieldVisibilityFieldId = req.FieldVisibilityFieldId;
        existing.PermissionDefinitionId = req.PermissionDefinitionId;
        existing.VisibilityState        = req.VisibilityState;
        existing.ObfuscationType        = Enum.Parse<ObfuscationType>(req.ObfuscationType, ignoreCase: true);
        existing.Priority               = req.Priority;
        existing.IsActive               = req.IsActive;
        existing.EffectiveFrom          = req.EffectiveFrom;
        existing.EffectiveTo            = req.EffectiveTo;
        existing.LastModifiedAt              = DateTime.UtcNow;
        existing.LastModifiedBy             = command.UserId;

        var updated = await repo.UpdateAsync(existing, ct);
        return FieldVisibilityRuleMappings.ToDto(updated);
    }
}

public class DeleteFieldVisibilityRuleHandler(IFieldVisibilityRuleRepository repo)
    : ICommandHandler<DeleteFieldVisibilityRuleCommand, Unit>
{
    public async ValueTask<Unit> Handle(DeleteFieldVisibilityRuleCommand command, CancellationToken ct)
    {
        await repo.DeleteAsync(command.Id, ct);
        return Unit.Value;
    }
}

// ── Shared mapping ──────────────────────────────────────────────────────────
internal static class FieldVisibilityRuleMappings
{
    internal static FieldVisibilityRuleDto ToDto(FieldVisibilityRule r) => new(
        r.Id,
        r.FieldVisibilityFieldId,
        r.Field?.Entity?.EntityType,
        r.Field?.FieldName,
        r.PermissionDefinitionId,
        r.PermissionDefinition?.PermissionKey,
        r.VisibilityState,
        r.ObfuscationType.ToString(),
        r.Priority,
        r.IsActive,
        r.EffectiveFrom,
        r.EffectiveTo,
        r.LastModifiedBy,
        r.CreatedAt,
        r.LastModifiedAt);
}
