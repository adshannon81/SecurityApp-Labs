using Mediator;
using SecurityApp.Application.FieldVisibility.Commands;
using SecurityApp.Application.FieldVisibility.DTOs;
using SecurityApp.Application.FieldVisibility.Queries;
using SecurityApp.Core.FieldVisibility;

namespace SecurityApp.Application.FieldVisibility.Handlers;

// ── Entity handlers ──────────────────────────────────────────────────────────

public class GetAllFieldVisibilityEntitiesHandler(IFieldVisibilityEntityRepository repo)
    : IQueryHandler<GetAllFieldVisibilityEntitiesQuery, IReadOnlyList<FieldVisibilityEntityDto>>
{
    public async ValueTask<IReadOnlyList<FieldVisibilityEntityDto>> Handle(
        GetAllFieldVisibilityEntitiesQuery query, CancellationToken ct)
    {
        var entities = await repo.GetAllAsync(ct);
        return entities.Select(EntityMappings.ToDto).ToList();
    }
}

public class GetFieldVisibilityEntityByIdHandler(IFieldVisibilityEntityRepository repo)
    : IQueryHandler<GetFieldVisibilityEntityByIdQuery, FieldVisibilityEntityDto?>
{
    public async ValueTask<FieldVisibilityEntityDto?> Handle(
        GetFieldVisibilityEntityByIdQuery query, CancellationToken ct)
    {
        var entity = await repo.GetByIdAsync(query.Id, ct);
        return entity is null ? null : EntityMappings.ToDto(entity);
    }
}

public class CreateFieldVisibilityEntityHandler(IFieldVisibilityEntityRepository repo)
    : ICommandHandler<CreateFieldVisibilityEntityCommand, FieldVisibilityEntityDto>
{
    public async ValueTask<FieldVisibilityEntityDto> Handle(
        CreateFieldVisibilityEntityCommand command, CancellationToken ct)
    {
        var req = command.Request;
        var entity = new FieldVisibilityEntity
        {
            EntityType  = req.EntityType,
            DisplayName = req.DisplayName,
            Description = req.Description,
            IsActive    = req.IsActive,
            LastModifiedBy  = command.UserId,
        };
        var created = await repo.CreateAsync(entity, ct);
        return EntityMappings.ToDto(created);
    }
}

public class UpdateFieldVisibilityEntityHandler(IFieldVisibilityEntityRepository repo)
    : ICommandHandler<UpdateFieldVisibilityEntityCommand, FieldVisibilityEntityDto>
{
    public async ValueTask<FieldVisibilityEntityDto> Handle(
        UpdateFieldVisibilityEntityCommand command, CancellationToken ct)
    {
        var existing = await repo.GetByIdAsync(command.Id, ct)
            ?? throw new KeyNotFoundException($"FieldVisibilityEntity {command.Id} not found.");

        var req = command.Request;
        existing.EntityType  = req.EntityType;
        existing.DisplayName = req.DisplayName;
        existing.Description = req.Description;
        existing.IsActive    = req.IsActive;
        existing.LastModifiedAt   = DateTime.UtcNow;
        existing.LastModifiedBy  = command.UserId;

        var updated = await repo.UpdateAsync(existing, ct);
        return EntityMappings.ToDto(updated);
    }
}

public class DeleteFieldVisibilityEntityHandler(IFieldVisibilityEntityRepository repo)
    : ICommandHandler<DeleteFieldVisibilityEntityCommand, Unit>
{
    public async ValueTask<Unit> Handle(
        DeleteFieldVisibilityEntityCommand command, CancellationToken ct)
    {
        await repo.DeleteAsync(command.Id, ct);
        return Unit.Value;
    }
}

// ── Field handlers ───────────────────────────────────────────────────────────

public class GetAllFieldVisibilityFieldsHandler(IFieldVisibilityFieldRepository repo)
    : IQueryHandler<GetAllFieldVisibilityFieldsQuery, IReadOnlyList<FieldVisibilityFieldDto>>
{
    public async ValueTask<IReadOnlyList<FieldVisibilityFieldDto>> Handle(
        GetAllFieldVisibilityFieldsQuery query, CancellationToken ct)
    {
        var fields = await repo.GetAllAsync(ct);
        return fields.Select(FieldMappings.ToDto).ToList();
    }
}

public class GetFieldVisibilityFieldsByEntityHandler(IFieldVisibilityFieldRepository repo)
    : IQueryHandler<GetFieldVisibilityFieldsByEntityQuery, IReadOnlyList<FieldVisibilityFieldDto>>
{
    public async ValueTask<IReadOnlyList<FieldVisibilityFieldDto>> Handle(
        GetFieldVisibilityFieldsByEntityQuery query, CancellationToken ct)
    {
        var fields = await repo.GetByEntityIdAsync(query.EntityId, ct);
        return fields.Select(FieldMappings.ToDto).ToList();
    }
}

public class GetFieldVisibilityFieldByIdHandler(IFieldVisibilityFieldRepository repo)
    : IQueryHandler<GetFieldVisibilityFieldByIdQuery, FieldVisibilityFieldDto?>
{
    public async ValueTask<FieldVisibilityFieldDto?> Handle(
        GetFieldVisibilityFieldByIdQuery query, CancellationToken ct)
    {
        var field = await repo.GetByIdAsync(query.Id, ct);
        return field is null ? null : FieldMappings.ToDto(field);
    }
}

public class CreateFieldVisibilityFieldHandler(IFieldVisibilityFieldRepository repo)
    : ICommandHandler<CreateFieldVisibilityFieldCommand, FieldVisibilityFieldDto>
{
    public async ValueTask<FieldVisibilityFieldDto> Handle(
        CreateFieldVisibilityFieldCommand command, CancellationToken ct)
    {
        var req = command.Request;
        var field = new FieldVisibilityField
        {
            FieldVisibilityEntityId = req.FieldVisibilityEntityId,
            FieldName               = req.FieldName,
            DisplayName             = req.DisplayName,
            DataType                = req.DataType,
            SensitivityLevel        = req.SensitivityLevel,
            DefaultVisibilityState   = req.DefaultVisibilityState,
            DefaultObfuscationType   = req.DefaultObfuscationType,
            SortOrder               = req.SortOrder,
            IsActive                = req.IsActive,
            LastModifiedBy              = command.UserId,
        };
        var created = await repo.CreateAsync(field, ct);
        return FieldMappings.ToDto(created);
    }
}

public class UpdateFieldVisibilityFieldHandler(IFieldVisibilityFieldRepository repo)
    : ICommandHandler<UpdateFieldVisibilityFieldCommand, FieldVisibilityFieldDto>
{
    public async ValueTask<FieldVisibilityFieldDto> Handle(
        UpdateFieldVisibilityFieldCommand command, CancellationToken ct)
    {
        var existing = await repo.GetByIdAsync(command.Id, ct)
            ?? throw new KeyNotFoundException($"FieldVisibilityField {command.Id} not found.");

        var req = command.Request;
        existing.FieldVisibilityEntityId = req.FieldVisibilityEntityId;
        existing.FieldName               = req.FieldName;
        existing.DisplayName             = req.DisplayName;
        existing.DataType                = req.DataType;
        existing.SensitivityLevel        = req.SensitivityLevel;
        existing.DefaultVisibilityState   = req.DefaultVisibilityState;
        existing.DefaultObfuscationType   = req.DefaultObfuscationType;
        existing.SortOrder               = req.SortOrder;
        existing.IsActive                = req.IsActive;
        existing.LastModifiedAt               = DateTime.UtcNow;
        existing.LastModifiedBy              = command.UserId;

        var updated = await repo.UpdateAsync(existing, ct);
        return FieldMappings.ToDto(updated);
    }
}

public class DeleteFieldVisibilityFieldHandler(IFieldVisibilityFieldRepository repo)
    : ICommandHandler<DeleteFieldVisibilityFieldCommand, Unit>
{
    public async ValueTask<Unit> Handle(
        DeleteFieldVisibilityFieldCommand command, CancellationToken ct)
    {
        await repo.DeleteAsync(command.Id, ct);
        return Unit.Value;
    }
}

// ── Shared mappings ──────────────────────────────────────────────────────────

internal static class EntityMappings
{
    internal static FieldVisibilityEntityDto ToDto(FieldVisibilityEntity e) => new(
        e.Id,
        e.EntityType,
        e.DisplayName,
        e.Description,
        e.IsActive,
        e.CreatedAt,
        e.LastModifiedAt);
}

internal static class FieldMappings
{
    internal static FieldVisibilityFieldDto ToDto(FieldVisibilityField f) => new(
        f.Id,
        f.FieldVisibilityEntityId,
        f.Entity?.EntityType,
        f.FieldName,
        f.DisplayName,
        f.DataType,
        f.SensitivityLevel,
        f.DefaultVisibilityState,
        f.DefaultObfuscationType,
        f.SortOrder,
        f.IsActive,
        f.CreatedAt,
        f.LastModifiedAt);
}
