using Mediator;
using SecurityApp.Application.FieldVisibility.Commands;
using SecurityApp.Application.FieldVisibility.DTOs;
using SecurityApp.Application.FieldVisibility.Queries;
using SecurityApp.Core.FieldVisibility;

namespace SecurityApp.Application.FieldVisibility.Handlers;

// ── Query handlers ────────────────────────────────────────────────────────────

public class GetAllFieldGroupsHandler(IFieldGroupRepository repo)
    : IQueryHandler<GetAllFieldGroupsQuery, IReadOnlyList<FieldGroupDto>>
{
    public async ValueTask<IReadOnlyList<FieldGroupDto>> Handle(
        GetAllFieldGroupsQuery query, CancellationToken ct)
    {
        var groups = await repo.GetAllAsync(ct);
        return groups.Select(FieldGroupMappings.ToDto).ToList();
    }
}

public class GetFieldGroupsByEntityHandler(IFieldGroupRepository repo)
    : IQueryHandler<GetFieldGroupsByEntityQuery, IReadOnlyList<FieldGroupDto>>
{
    public async ValueTask<IReadOnlyList<FieldGroupDto>> Handle(
        GetFieldGroupsByEntityQuery query, CancellationToken ct)
    {
        var groups = await repo.GetByEntityAsync(query.EntityId, ct);
        return groups.Select(FieldGroupMappings.ToDto).ToList();
    }
}

public class GetFieldGroupByIdHandler(IFieldGroupRepository repo)
    : IQueryHandler<GetFieldGroupByIdQuery, FieldGroupDto?>
{
    public async ValueTask<FieldGroupDto?> Handle(
        GetFieldGroupByIdQuery query, CancellationToken ct)
    {
        var group = await repo.GetByIdAsync(query.Id, ct);
        return group is null ? null : FieldGroupMappings.ToDto(group);
    }
}

public class GetFieldGroupWithMembersHandler(IFieldGroupRepository repo)
    : IQueryHandler<GetFieldGroupWithMembersQuery, FieldGroupWithMembersDto?>
{
    public async ValueTask<FieldGroupWithMembersDto?> Handle(
        GetFieldGroupWithMembersQuery query, CancellationToken ct)
    {
        var group = await repo.GetWithMembersAsync(query.Id, ct);
        return group is null ? null : FieldGroupMappings.ToWithMembersDto(group);
    }
}

public class GetFieldGroupMembersHandler(IFieldGroupRepository repo)
    : IQueryHandler<GetFieldGroupMembersQuery, IReadOnlyList<FieldGroupMemberDto>>
{
    public async ValueTask<IReadOnlyList<FieldGroupMemberDto>> Handle(
        GetFieldGroupMembersQuery query, CancellationToken ct)
    {
        var members = await repo.GetMembersAsync(query.GroupId, ct);
        return members.Select(FieldGroupMappings.ToMemberDto).ToList();
    }
}

// ── Command handlers ──────────────────────────────────────────────────────────

public class CreateFieldGroupHandler(IFieldGroupRepository repo)
    : ICommandHandler<CreateFieldGroupCommand, FieldGroupDto>
{
    public async ValueTask<FieldGroupDto> Handle(
        CreateFieldGroupCommand command, CancellationToken ct)
    {
        var req = command.Request;
        var group = new FieldGroup
        {
            FieldVisibilityEntityId = req.FieldVisibilityEntityId,
            GroupKey                = req.GroupKey,
            DisplayName             = req.DisplayName,
            Description             = req.Description,
            SortOrder               = req.SortOrder,
            IsActive                = req.IsActive,
            LastModifiedBy              = command.UserId,
        };
        var created = await repo.CreateAsync(group, ct);
        return FieldGroupMappings.ToDto(created);
    }
}

public class UpdateFieldGroupHandler(IFieldGroupRepository repo)
    : ICommandHandler<UpdateFieldGroupCommand, FieldGroupDto>
{
    public async ValueTask<FieldGroupDto> Handle(
        UpdateFieldGroupCommand command, CancellationToken ct)
    {
        var existing = await repo.GetByIdAsync(command.Id, ct)
            ?? throw new KeyNotFoundException($"FieldGroup {command.Id} not found.");

        var req = command.Request;
        existing.FieldVisibilityEntityId = req.FieldVisibilityEntityId;
        existing.GroupKey                = req.GroupKey;
        existing.DisplayName             = req.DisplayName;
        existing.Description             = req.Description;
        existing.SortOrder               = req.SortOrder;
        existing.IsActive                = req.IsActive;
        existing.LastModifiedAt               = DateTime.UtcNow;
        existing.LastModifiedBy              = command.UserId;

        var updated = await repo.UpdateAsync(existing, ct);
        return FieldGroupMappings.ToDto(updated);
    }
}

public class DeleteFieldGroupHandler(IFieldGroupRepository repo)
    : ICommandHandler<DeleteFieldGroupCommand, Unit>
{
    public async ValueTask<Unit> Handle(
        DeleteFieldGroupCommand command, CancellationToken ct)
    {
        await repo.DeleteAsync(command.Id, ct);
        return Unit.Value;
    }
}

public class AddFieldGroupMemberHandler(IFieldGroupRepository repo)
    : ICommandHandler<AddFieldGroupMemberCommand, FieldGroupMemberDto>
{
    public async ValueTask<FieldGroupMemberDto> Handle(
        AddFieldGroupMemberCommand command, CancellationToken ct)
    {
        var req = command.Request;
        var member = new FieldGroupMember
        {
            FieldGroupId            = command.GroupId,
            FieldVisibilityFieldId  = req.FieldVisibilityFieldId,
            LastModifiedBy              = command.UserId,
        };
        var created = await repo.AddMemberAsync(member, ct);
        return FieldGroupMappings.ToMemberDto(created);
    }
}

public class RemoveFieldGroupMemberHandler(IFieldGroupRepository repo)
    : ICommandHandler<RemoveFieldGroupMemberCommand, Unit>
{
    public async ValueTask<Unit> Handle(
        RemoveFieldGroupMemberCommand command, CancellationToken ct)
    {
        await repo.RemoveMemberAsync(command.MemberId, ct);
        return Unit.Value;
    }
}

// ── Mappings ──────────────────────────────────────────────────────────────────

internal static class FieldGroupMappings
{
    internal static FieldGroupDto ToDto(FieldGroup g) => new(
        g.Id,
        g.FieldVisibilityEntityId,
        g.GroupKey,
        g.DisplayName,
        g.Description,
        g.SortOrder,
        g.IsActive,
        g.CreatedAt,
        g.LastModifiedAt);

    internal static FieldGroupWithMembersDto ToWithMembersDto(FieldGroup g) => new(
        g.Id,
        g.FieldVisibilityEntityId,
        g.GroupKey,
        g.DisplayName,
        g.Description,
        g.SortOrder,
        g.IsActive,
        g.CreatedAt,
        g.LastModifiedAt,
        g.Members
            .Where(m => m.IsCurrent && !m.IsDeleted)
            .Select(ToMemberDto)
            .ToList()
            .AsReadOnly());

    internal static FieldGroupMemberDto ToMemberDto(FieldGroupMember m) => new(
        m.Id,
        m.FieldGroupId,
        m.FieldVisibilityFieldId,
        m.Field?.FieldName   ?? string.Empty,
        m.Field?.DisplayName ?? string.Empty);
}
