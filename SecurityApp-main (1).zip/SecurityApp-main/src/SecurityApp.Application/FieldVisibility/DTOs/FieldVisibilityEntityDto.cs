namespace SecurityApp.Application.FieldVisibility.DTOs;

public record FieldVisibilityEntityDto(
    Guid      Id,
    string    EntityType,
    string    DisplayName,
    string?   Description,
    bool      IsActive,
    DateTime  CreatedAt,
    DateTime? LastModifiedAt);

public record CreateFieldVisibilityEntityRequest(
    string  EntityType,
    string  DisplayName,
    string? Description,
    bool    IsActive = true);

public record UpdateFieldVisibilityEntityRequest(
    string  EntityType,
    string  DisplayName,
    string? Description,
    bool    IsActive);
