namespace SecurityApp.Application.FieldVisibility.DTOs;

public record FieldVisibilityRuleDto(
    Guid      Id,
    Guid      FieldVisibilityFieldId,
    // Denormalized for display convenience
    string?   EntityType,
    string?   FieldName,
    Guid?     PermissionDefinitionId,
    string?   RequiredPermission,
    string    VisibilityState,
    string    ObfuscationType,
    int       Priority,
    bool      IsActive,
    DateTime? EffectiveFrom,
    DateTime? EffectiveTo,
    string?   LastModifiedBy,
    DateTime  CreatedAt,
    DateTime? LastModifiedAt);

public record CreateFieldVisibilityRuleRequest(
    Guid   FieldVisibilityFieldId,
    Guid   PermissionDefinitionId,
    string VisibilityState,
    string ObfuscationType,
    int    Priority,
    DateTime? EffectiveFrom,
    DateTime? EffectiveTo);

public record UpdateFieldVisibilityRuleRequest(
    Guid   FieldVisibilityFieldId,
    Guid   PermissionDefinitionId,
    string VisibilityState,
    string ObfuscationType,
    int    Priority,
    bool   IsActive,
    DateTime? EffectiveFrom,
    DateTime? EffectiveTo);
