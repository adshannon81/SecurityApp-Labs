namespace SecurityApp.Application.FieldVisibility.DTOs;

// â”€â”€ FieldGroup â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

public record FieldGroupDto(
    Guid      Id,
    Guid      FieldVisibilityEntityId,
    string    GroupKey,
    string    DisplayName,
    string?   Description,
    int       SortOrder,
    bool      IsActive,
    DateTime  CreatedAt,
    DateTime? LastModifiedAt);

public record FieldGroupWithMembersDto(
    Guid      Id,
    Guid      FieldVisibilityEntityId,
    string    GroupKey,
    string    DisplayName,
    string?   Description,
    int       SortOrder,
    bool      IsActive,
    DateTime  CreatedAt,
    DateTime? LastModifiedAt,
    IReadOnlyList<FieldGroupMemberDto> Members);

public record FieldGroupMemberDto(
    Guid    Id,
    Guid    FieldGroupId,
    Guid    FieldVisibilityFieldId,
    string  FieldName,
    string  DisplayName);

public record CreateFieldGroupRequest(
    Guid    FieldVisibilityEntityId,
    string  GroupKey,
    string  DisplayName,
    string? Description,
    int     SortOrder,
    bool    IsActive = true);

public record UpdateFieldGroupRequest(
    Guid    FieldVisibilityEntityId,
    string  GroupKey,
    string  DisplayName,
    string? Description,
    int     SortOrder,
    bool    IsActive);

public record AddFieldGroupMemberRequest(
    Guid FieldGroupId,
    Guid FieldVisibilityFieldId);
