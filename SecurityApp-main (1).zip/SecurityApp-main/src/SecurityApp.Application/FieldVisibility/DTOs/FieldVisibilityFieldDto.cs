namespace SecurityApp.Application.FieldVisibility.DTOs;

public record FieldVisibilityFieldDto(
    Guid      Id,
    Guid      FieldVisibilityEntityId,
    string?   EntityType,
    string    FieldName,
    string    DisplayName,
    string?   DataType,
    string?   SensitivityLevel,
    string    DefaultVisibilityState,
    string    DefaultObfuscationType,
    int       SortOrder,
    bool      IsActive,
    DateTime  CreatedAt,
    DateTime? LastModifiedAt);

public record CreateFieldVisibilityFieldRequest(
    Guid    FieldVisibilityEntityId,
    string  FieldName,
    string  DisplayName,
    string? DataType,
    string? SensitivityLevel,
    string  DefaultVisibilityState,
    string  DefaultObfuscationType,
    int     SortOrder,
    bool    IsActive = true);

public record UpdateFieldVisibilityFieldRequest(
    Guid    FieldVisibilityEntityId,
    string  FieldName,
    string  DisplayName,
    string? DataType,
    string? SensitivityLevel,
    string  DefaultVisibilityState,
    string  DefaultObfuscationType,
    int     SortOrder,
    bool    IsActive);
