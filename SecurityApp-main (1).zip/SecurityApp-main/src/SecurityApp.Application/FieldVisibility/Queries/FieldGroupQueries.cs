using Mediator;
using SecurityApp.Application.FieldVisibility.DTOs;

namespace SecurityApp.Application.FieldVisibility.Queries;

public record GetAllFieldGroupsQuery : IQuery<IReadOnlyList<FieldGroupDto>>;

public record GetFieldGroupsByEntityQuery(Guid EntityId) : IQuery<IReadOnlyList<FieldGroupDto>>;

public record GetFieldGroupByIdQuery(Guid Id) : IQuery<FieldGroupDto?>;

public record GetFieldGroupWithMembersQuery(Guid Id) : IQuery<FieldGroupWithMembersDto?>;

public record GetFieldGroupMembersQuery(Guid GroupId) : IQuery<IReadOnlyList<FieldGroupMemberDto>>;
