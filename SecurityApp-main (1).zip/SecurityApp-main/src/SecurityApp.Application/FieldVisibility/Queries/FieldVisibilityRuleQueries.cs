using Mediator;
using SecurityApp.Application.FieldVisibility.DTOs;

namespace SecurityApp.Application.FieldVisibility.Queries;

public record GetAllFieldVisibilityRulesQuery : IQuery<IReadOnlyList<FieldVisibilityRuleDto>>;

public record GetFieldVisibilityRuleByIdQuery(Guid Id) : IQuery<FieldVisibilityRuleDto?>;

public record GetFieldVisibilityRulesByFieldQuery(Guid FieldId) : IQuery<IReadOnlyList<FieldVisibilityRuleDto>>;
