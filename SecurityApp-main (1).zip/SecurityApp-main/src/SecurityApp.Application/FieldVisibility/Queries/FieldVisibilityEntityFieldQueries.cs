using Mediator;
using SecurityApp.Application.FieldVisibility.DTOs;

namespace SecurityApp.Application.FieldVisibility.Queries;

public record GetAllFieldVisibilityEntitiesQuery : IQuery<IReadOnlyList<FieldVisibilityEntityDto>>;

public record GetFieldVisibilityEntityByIdQuery(Guid Id) : IQuery<FieldVisibilityEntityDto?>;

public record GetAllFieldVisibilityFieldsQuery : IQuery<IReadOnlyList<FieldVisibilityFieldDto>>;

public record GetFieldVisibilityFieldsByEntityQuery(Guid EntityId) : IQuery<IReadOnlyList<FieldVisibilityFieldDto>>;

public record GetFieldVisibilityFieldByIdQuery(Guid Id) : IQuery<FieldVisibilityFieldDto?>;
