namespace SecurityApp.Application.AppAuthorization.DTOs;

// â”€â”€ App Resource â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

public record AppResourceDto(
    Guid    Id,
    string  ResourceType,
    string  ResourceKey,
    Guid?   ParentAppResourceId,
    string  DisplayName,
    string? RoutePath,
    string? IconName,
    string? Description,
    string  DefaultVisibilityState,
    string  DefaultExecutionState,
    bool    IsSecuritySensitive,
    int     SortOrder,
    bool    IsActive,
    DateTime  CreatedAt,
    DateTime? LastModifiedAt);

public record CreateAppResourceRequest(
    string  ResourceType,
    string  ResourceKey,
    Guid?   ParentAppResourceId,
    string  DisplayName,
    string? RoutePath,
    string? IconName,
    string? Description,
    string  DefaultVisibilityState,
    string  DefaultExecutionState,
    bool    IsSecuritySensitive,
    int     SortOrder,
    bool    IsActive = true);

public record UpdateAppResourceRequest(
    string  ResourceType,
    string  ResourceKey,
    Guid?   ParentAppResourceId,
    string  DisplayName,
    string? RoutePath,
    string? IconName,
    string? Description,
    string  DefaultVisibilityState,
    string  DefaultExecutionState,
    bool    IsSecuritySensitive,
    int     SortOrder,
    bool    IsActive);

// â”€â”€ App Resource Rule â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

public record AppResourceRuleDto(
    Guid      Id,
    Guid      AppResourceId,
    string?   ResourceKey,
    Guid?     PermissionDefinitionId,
    string?   RequiredPermission,
    string    VisibilityState,
    string    ExecutionState,
    int       Priority,
    bool      IsActive,
    DateTime? EffectiveFrom,
    DateTime? EffectiveTo,
    string?   LastModifiedBy,
    DateTime  CreatedAt,
    DateTime? LastModifiedAt);

public record CreateAppResourceRuleRequest(
    Guid      AppResourceId,
    Guid?     PermissionDefinitionId,
    string?   RequiredPermission,
    string    VisibilityState,
    string    ExecutionState,
    int       Priority,
    DateTime? EffectiveFrom,
    DateTime? EffectiveTo,
    bool      IsActive = true);

public record UpdateAppResourceRuleRequest(
    Guid      AppResourceId,
    Guid?     PermissionDefinitionId,
    string?   RequiredPermission,
    string    VisibilityState,
    string    ExecutionState,
    int       Priority,
    bool      IsActive,
    DateTime? EffectiveFrom,
    DateTime? EffectiveTo);

// â”€â”€ Authorization state (served to Angular) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

public record ResourceStateDto(
    string ResourceKey,
    string VisibilityState,
    string ExecutionState);

public record AppAuthorizationStateDto(
    IReadOnlyList<ResourceStateDto> ResourceStates);

// â”€â”€ Navigation menu tree (served to Angular sidebar) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€

public record NavLeafDto(
    string  ResourceKey,
    string  Label,
    string  Route,
    string? Icon,
    int     SortOrder);

public record NavSectionDto(
    string              Label,
    string              ResourceKey,
    int                 SortOrder,
    IReadOnlyList<NavLeafDto> Children);

public record NavGroupDto(
    string  Kind,           // "group" | "leaf"
    string  ResourceKey,
    string  Label,
    string? Icon,
    string? Route,          // null for groups
    int     SortOrder,
    IReadOnlyList<NavSectionDto>? Sections,   // null for leaves
    IReadOnlyList<NavLeafDto>?    ExtraLinks); // direct children not in a section

// ── App Resource Group ────────────────────────────────────────────────────────

public record AppResourceGroupDto(
    Guid      Id,
    string    GroupKey,
    string    DisplayName,
    string?   Description,
    string?   IconName,
    int       SortOrder,
    bool      IsActive,
    DateTime  CreatedAt,
    DateTime? LastModifiedAt);

public record CreateAppResourceGroupRequest(
    string  GroupKey,
    string  DisplayName,
    string? Description,
    string? IconName,
    int     SortOrder,
    bool    IsActive = true);

public record UpdateAppResourceGroupRequest(
    string  GroupKey,
    string  DisplayName,
    string? Description,
    string? IconName,
    int     SortOrder,
    bool    IsActive);
