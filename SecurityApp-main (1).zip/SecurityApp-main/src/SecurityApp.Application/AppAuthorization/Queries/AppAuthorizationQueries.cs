using Mediator;
using SecurityApp.Application.AppAuthorization.DTOs;

namespace SecurityApp.Application.AppAuthorization.Queries;

// ── Resources ────────────────────────────────────────────────────────────────

public record GetAllAppResourcesQuery : IQuery<IReadOnlyList<AppResourceDto>>;

public record GetAppResourceByIdQuery(Guid Id) : IQuery<AppResourceDto?>;

// ── Rules ────────────────────────────────────────────────────────────────────

public record GetAllAppResourceRulesQuery : IQuery<IReadOnlyList<AppResourceRuleDto>>;

public record GetAppResourceRulesByResourceQuery(Guid ResourceId) : IQuery<IReadOnlyList<AppResourceRuleDto>>;

public record GetAppResourceRuleByIdQuery(Guid Id) : IQuery<AppResourceRuleDto?>;

// ── Authorization state ──────────────────────────────────────────────────────

public record GetMyAppAuthorizationStateQuery(IEnumerable<string> UserPermissions)
    : IQuery<AppAuthorizationStateDto>;

/// <summary>
/// Returns the full nav tree for the calling user, filtered to only
/// resources whose effective visibility is VISIBLE given their permissions.
/// </summary>
public record GetNavigationMenuQuery(IEnumerable<string> UserPermissions)
    : IQuery<IReadOnlyList<NavGroupDto>>;

// ── Resource Groups ──────────────────────────────────────────────────────────

public record GetAllAppResourceGroupsQuery : IQuery<IReadOnlyList<AppResourceGroupDto>>;

public record GetAppResourceGroupByIdQuery(Guid Id) : IQuery<AppResourceGroupDto?>;
