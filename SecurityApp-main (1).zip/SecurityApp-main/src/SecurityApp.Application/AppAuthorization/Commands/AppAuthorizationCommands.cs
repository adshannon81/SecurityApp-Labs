using Mediator;
using SecurityApp.Application.AppAuthorization.DTOs;

namespace SecurityApp.Application.AppAuthorization.Commands;

// ── Resources ────────────────────────────────────────────────────────────────

public record CreateAppResourceCommand(CreateAppResourceRequest Request, string? UserId)
    : ICommand<AppResourceDto>;

public record UpdateAppResourceCommand(Guid Id, UpdateAppResourceRequest Request, string? UserId)
    : ICommand<AppResourceDto>;

public record DeleteAppResourceCommand(Guid Id) : ICommand;

// ── Rules ────────────────────────────────────────────────────────────────────

public record CreateAppResourceRuleCommand(CreateAppResourceRuleRequest Request, string? UserId)
    : ICommand<AppResourceRuleDto>;

public record UpdateAppResourceRuleCommand(Guid Id, UpdateAppResourceRuleRequest Request, string? UserId)
    : ICommand<AppResourceRuleDto>;

public record DeleteAppResourceRuleCommand(Guid Id) : ICommand;

// ── Resource Groups ──────────────────────────────────────────────────────────

public record CreateAppResourceGroupCommand(CreateAppResourceGroupRequest Request, string? UserId)
    : ICommand<AppResourceGroupDto>;

public record UpdateAppResourceGroupCommand(Guid Id, UpdateAppResourceGroupRequest Request, string? UserId)
    : ICommand<AppResourceGroupDto>;

public record DeleteAppResourceGroupCommand(Guid Id) : ICommand;
