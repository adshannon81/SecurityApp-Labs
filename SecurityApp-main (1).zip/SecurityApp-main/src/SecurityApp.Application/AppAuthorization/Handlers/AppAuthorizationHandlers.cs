﻿using Mediator;
using SecurityApp.Application.AppAuthorization.Commands;
using SecurityApp.Application.AppAuthorization.DTOs;
using SecurityApp.Application.AppAuthorization.Queries;
using SecurityApp.Core.AppAuthorization;
using SecurityApp.Core.AppAuthorization.Enums;

namespace SecurityApp.Application.AppAuthorization.Handlers;

// ── Resource handlers ─────────────────────────────────────────────────────────

public class GetAllAppResourcesHandler(IAppResourceRepository repo)
    : IQueryHandler<GetAllAppResourcesQuery, IReadOnlyList<AppResourceDto>>
{
    public async ValueTask<IReadOnlyList<AppResourceDto>> Handle(
        GetAllAppResourcesQuery query, CancellationToken ct)
    {
        var resources = await repo.GetAllAsync(ct);
        return resources.Select(ResourceMappings.ToDto).ToList();
    }
}

public class GetAppResourceByIdHandler(IAppResourceRepository repo)
    : IQueryHandler<GetAppResourceByIdQuery, AppResourceDto?>
{
    public async ValueTask<AppResourceDto?> Handle(
        GetAppResourceByIdQuery query, CancellationToken ct)
    {
        var resource = await repo.GetByIdAsync(query.Id, ct);
        return resource is null ? null : ResourceMappings.ToDto(resource);
    }
}

public class CreateAppResourceHandler(IAppResourceRepository repo)
    : ICommandHandler<CreateAppResourceCommand, AppResourceDto>
{
    public async ValueTask<AppResourceDto> Handle(
        CreateAppResourceCommand command, CancellationToken ct)
    {
        var req = command.Request;
        var resource = new AppResource
        {
            ResourceType            = Enum.Parse<AppResourceType>(req.ResourceType, ignoreCase: true),
            ResourceKey             = req.ResourceKey,
            ParentAppResourceId     = req.ParentAppResourceId,
            DisplayName             = req.DisplayName,
            RoutePath               = req.RoutePath,
            IconName                = req.IconName,
            Description             = req.Description,
            DefaultVisibilityState  = Enum.Parse<VisibilityState>(req.DefaultVisibilityState, ignoreCase: true),
            DefaultExecutionState   = Enum.Parse<AppExecutionState>(req.DefaultExecutionState, ignoreCase: true),
            IsSecuritySensitive     = req.IsSecuritySensitive,
            SortOrder               = req.SortOrder,
            IsActive                = req.IsActive,
            LastModifiedBy              = command.UserId,
        };
        var created = await repo.CreateAsync(resource, ct);
        return ResourceMappings.ToDto(created);
    }
}

public class UpdateAppResourceHandler(IAppResourceRepository repo)
    : ICommandHandler<UpdateAppResourceCommand, AppResourceDto>
{
    public async ValueTask<AppResourceDto> Handle(
        UpdateAppResourceCommand command, CancellationToken ct)
    {
        var existing = await repo.GetByIdAsync(command.Id, ct)
            ?? throw new KeyNotFoundException($"AppResource {command.Id} not found.");

        var req = command.Request;
        existing.ResourceType            = Enum.Parse<AppResourceType>(req.ResourceType, ignoreCase: true);
        existing.ResourceKey             = req.ResourceKey;
        existing.ParentAppResourceId     = req.ParentAppResourceId;
        existing.DisplayName             = req.DisplayName;
        existing.RoutePath               = req.RoutePath;
        existing.IconName                = req.IconName;
        existing.Description             = req.Description;
        existing.DefaultVisibilityState  = Enum.Parse<VisibilityState>(req.DefaultVisibilityState, ignoreCase: true);
        existing.DefaultExecutionState   = Enum.Parse<AppExecutionState>(req.DefaultExecutionState, ignoreCase: true);
        existing.IsSecuritySensitive     = req.IsSecuritySensitive;
        existing.SortOrder               = req.SortOrder;
        existing.IsActive                = req.IsActive;
        existing.LastModifiedAt               = DateTime.UtcNow;
        existing.LastModifiedBy              = command.UserId;

        var updated = await repo.UpdateAsync(existing, ct);
        return ResourceMappings.ToDto(updated);
    }
}

public class DeleteAppResourceHandler(IAppResourceRepository repo)
    : ICommandHandler<DeleteAppResourceCommand, Unit>
{
    public async ValueTask<Unit> Handle(
        DeleteAppResourceCommand command, CancellationToken ct)
    {
        await repo.DeleteAsync(command.Id, ct);
        return Unit.Value;
    }
}

// ── Rule handlers ─────────────────────────────────────────────────────────────

public class GetAllAppResourceRulesHandler(IAppResourceRuleRepository repo)
    : IQueryHandler<GetAllAppResourceRulesQuery, IReadOnlyList<AppResourceRuleDto>>
{
    public async ValueTask<IReadOnlyList<AppResourceRuleDto>> Handle(
        GetAllAppResourceRulesQuery query, CancellationToken ct)
    {
        var rules = await repo.GetAllAsync(ct);
        return rules.Select(RuleMappings.ToDto).ToList();
    }
}

public class GetAppResourceRulesByResourceHandler(IAppResourceRuleRepository repo)
    : IQueryHandler<GetAppResourceRulesByResourceQuery, IReadOnlyList<AppResourceRuleDto>>
{
    public async ValueTask<IReadOnlyList<AppResourceRuleDto>> Handle(
        GetAppResourceRulesByResourceQuery query, CancellationToken ct)
    {
        var rules = await repo.GetByResourceAsync(query.ResourceId, ct);
        return rules.Select(RuleMappings.ToDto).ToList();
    }
}

public class GetAppResourceRuleByIdHandler(IAppResourceRuleRepository repo)
    : IQueryHandler<GetAppResourceRuleByIdQuery, AppResourceRuleDto?>
{
    public async ValueTask<AppResourceRuleDto?> Handle(
        GetAppResourceRuleByIdQuery query, CancellationToken ct)
    {
        var rule = await repo.GetByIdAsync(query.Id, ct);
        return rule is null ? null : RuleMappings.ToDto(rule);
    }
}

public class CreateAppResourceRuleHandler(IAppResourceRuleRepository repo)
    : ICommandHandler<CreateAppResourceRuleCommand, AppResourceRuleDto>
{
    public async ValueTask<AppResourceRuleDto> Handle(
        CreateAppResourceRuleCommand command, CancellationToken ct)
    {
        var req = command.Request;
        var rule = new AppResourceRule
        {
            AppResourceId          = req.AppResourceId,
            PermissionDefinitionId = req.PermissionDefinitionId ?? Guid.Empty,
            VisibilityState        = Enum.Parse<VisibilityState>(req.VisibilityState, ignoreCase: true),
            ExecutionState         = Enum.Parse<AppExecutionState>(req.ExecutionState, ignoreCase: true),
            Priority           = req.Priority,
            IsActive           = req.IsActive,
            EffectiveFrom      = req.EffectiveFrom,
            EffectiveTo        = req.EffectiveTo,
            LastModifiedBy         = command.UserId,
        };
        var created = await repo.CreateAsync(rule, ct);
        return RuleMappings.ToDto(created);
    }
}

public class UpdateAppResourceRuleHandler(IAppResourceRuleRepository repo)
    : ICommandHandler<UpdateAppResourceRuleCommand, AppResourceRuleDto>
{
    public async ValueTask<AppResourceRuleDto> Handle(
        UpdateAppResourceRuleCommand command, CancellationToken ct)
    {
        var existing = await repo.GetByIdAsync(command.Id, ct)
            ?? throw new KeyNotFoundException($"AppResourceRule {command.Id} not found.");

        var req = command.Request;
        existing.AppResourceId          = req.AppResourceId;
        existing.PermissionDefinitionId = req.PermissionDefinitionId ?? Guid.Empty;
        existing.VisibilityState        = Enum.Parse<VisibilityState>(req.VisibilityState, ignoreCase: true);
        existing.ExecutionState     = Enum.Parse<AppExecutionState>(req.ExecutionState, ignoreCase: true);
        existing.Priority           = req.Priority;
        existing.IsActive           = req.IsActive;
        existing.EffectiveFrom      = req.EffectiveFrom;
        existing.EffectiveTo        = req.EffectiveTo;
        existing.LastModifiedAt          = DateTime.UtcNow;
        existing.LastModifiedBy         = command.UserId;

        var updated = await repo.UpdateAsync(existing, ct);
        return RuleMappings.ToDto(updated);
    }
}

public class DeleteAppResourceRuleHandler(IAppResourceRuleRepository repo)
    : ICommandHandler<DeleteAppResourceRuleCommand, Unit>
{
    public async ValueTask<Unit> Handle(
        DeleteAppResourceRuleCommand command, CancellationToken ct)
    {
        await repo.DeleteAsync(command.Id, ct);
        return Unit.Value;
    }
}

// ── Authorization state handler ───────────────────────────────────────────────

public class GetMyAppAuthorizationStateHandler(IAppResourceRepository resourceRepo)
    : IQueryHandler<GetMyAppAuthorizationStateQuery, AppAuthorizationStateDto>
{
    public async ValueTask<AppAuthorizationStateDto> Handle(
        GetMyAppAuthorizationStateQuery query, CancellationToken ct)
    {
        var permissions = query.UserPermissions.ToHashSet(StringComparer.Ordinal);
        var resources   = await resourceRepo.GetAllAsync(ct);

        var states = resources
            .Where(r => r.IsActive && r.IsCurrent && !r.IsDeleted)
            .Select(r =>
            {
                var matched = r.Rules
                    .Where(rule => rule.IsActive && rule.IsCurrent && !rule.IsDeleted
                                   && rule.Permission?.PermissionKey is not null
                                   && permissions.Contains(rule.Permission.PermissionKey))
                    .OrderByDescending(rule => rule.Priority)
                    .FirstOrDefault();

                var visibility = matched?.VisibilityState ?? r.DefaultVisibilityState;
                var execution  = matched?.ExecutionState  ?? r.DefaultExecutionState;

                return new ResourceStateDto(
                    r.ResourceKey,
                    visibility.ToString(),
                    execution.ToString());
            })
            .ToList();

        return new AppAuthorizationStateDto(states);
    }
}

public class GetNavigationMenuHandler(IAppResourceRepository repo)
    : IQueryHandler<GetNavigationMenuQuery, IReadOnlyList<NavGroupDto>>
{
    public async ValueTask<IReadOnlyList<NavGroupDto>> Handle(
        GetNavigationMenuQuery query, CancellationToken ct)
    {
        var permissions = query.UserPermissions.ToHashSet(StringComparer.Ordinal);

        var all = await repo.GetAllWithChildrenAsync(ct);

        var topLevel = all
            .Where(r => r.IsActive && r.IsCurrent && !r.IsDeleted
                     && r.ParentAppResourceId == null
                     && r.ResourceKey != "group.main"
                     && r.ResourceKey != "group.admin"
                     && (r.ResourceType == AppResourceType.MenuItem
                      || r.ResourceType == AppResourceType.MenuGroup))
            .Where(r => IsVisible(r, permissions))
            .OrderBy(r => r.SortOrder)
            .ToList();

        return topLevel.Select(r => BuildEntry(r, permissions)).ToList();
    }

    private static NavGroupDto BuildEntry(AppResource r, HashSet<string> perms)
    {
        if (r.ResourceType == AppResourceType.MenuItem)
        {
            return new NavGroupDto(
                Kind:        "leaf",
                ResourceKey: r.ResourceKey,
                Label:       r.DisplayName,
                Icon:        r.IconName,
                Route:       r.RoutePath,
                SortOrder:   r.SortOrder,
                Sections:    null,
                ExtraLinks:  null);
        }

        var activeChildren = r.Children
            .Where(c => c.IsActive && c.IsCurrent && !c.IsDeleted
                     && IsVisible(c, perms)
                     && (c.ResourceType == AppResourceType.MenuItem
                      || c.ResourceType == AppResourceType.MenuGroup
                      || c.ResourceType == AppResourceType.Section))
            .OrderBy(c => c.SortOrder)
            .ToList();

        var sections = activeChildren
            .Where(c => c.ResourceType == AppResourceType.Section)
            .Select(s => new NavSectionDto(
                Label:       s.DisplayName,
                ResourceKey: s.ResourceKey,
                SortOrder:   s.SortOrder,
                Children: s.Children
                    .Where(leaf => leaf.IsActive && leaf.IsCurrent && !leaf.IsDeleted
                                && IsVisible(leaf, perms)
                                && leaf.ResourceType == AppResourceType.MenuItem)
                    .OrderBy(leaf => leaf.SortOrder)
                    .Select(leaf => new NavLeafDto(leaf.ResourceKey, leaf.DisplayName, leaf.RoutePath!, leaf.IconName, leaf.SortOrder))
                    .ToList()
                    .AsReadOnly()))
            .ToList()
            .AsReadOnly();

        var extraLinks = activeChildren
            .Where(c => c.ResourceType == AppResourceType.MenuItem)
            .Select(c => new NavLeafDto(c.ResourceKey, c.DisplayName, c.RoutePath!, c.IconName, c.SortOrder))
            .ToList()
            .AsReadOnly();

        return new NavGroupDto(
            Kind:        "group",
            ResourceKey: r.ResourceKey,
            Label:       r.DisplayName,
            Icon:        r.IconName,
            Route:       null,
            SortOrder:   r.SortOrder,
            Sections:    sections,
            ExtraLinks:  extraLinks);
    }

    private static bool IsVisible(AppResource r, HashSet<string> perms)
    {
        var matchedRule = r.Rules
            .Where(rule => rule.IsActive && rule.IsCurrent && !rule.IsDeleted
                        && rule.Permission?.PermissionKey is not null
                        && perms.Contains(rule.Permission.PermissionKey))
            .OrderByDescending(rule => rule.Priority)
            .FirstOrDefault();

        var state = matchedRule?.VisibilityState ?? r.DefaultVisibilityState;
        return state == VisibilityState.Visible;
    }
}

// ── Shared mappings ───────────────────────────────────────────────────────────

internal static class ResourceMappings
{
    internal static AppResourceDto ToDto(AppResource r) => new(
        r.Id,
        r.ResourceType.ToString(),
        r.ResourceKey,
        r.ParentAppResourceId,
        r.DisplayName,
        r.RoutePath,
        r.IconName,
        r.Description,
        r.DefaultVisibilityState.ToString(),
        r.DefaultExecutionState.ToString(),
        r.IsSecuritySensitive,
        r.SortOrder,
        r.IsActive,
        r.CreatedAt,
        r.LastModifiedAt);
}

internal static class RuleMappings
{
    internal static AppResourceRuleDto ToDto(AppResourceRule r) => new(
        r.Id,
        r.AppResourceId,
        r.Resource?.ResourceKey,
        r.PermissionDefinitionId,
        r.Permission?.PermissionKey,
        r.VisibilityState.ToString(),
        r.ExecutionState.ToString(),
        r.Priority,
        r.IsActive,
        r.EffectiveFrom,
        r.EffectiveTo,
        r.LastModifiedBy,
        r.CreatedAt,
        r.LastModifiedAt);
}

// ── Resource Group handlers ───────────────────────────────────────────────────

public class GetAllAppResourceGroupsHandler(IAppResourceGroupRepository repo)
    : IQueryHandler<GetAllAppResourceGroupsQuery, IReadOnlyList<AppResourceGroupDto>>
{
    public async ValueTask<IReadOnlyList<AppResourceGroupDto>> Handle(
        GetAllAppResourceGroupsQuery query, CancellationToken ct)
    {
        var groups = await repo.GetAllAsync(ct);
        return groups.Select(GroupMappings.ToDto).ToList();
    }
}

public class GetAppResourceGroupByIdHandler(IAppResourceGroupRepository repo)
    : IQueryHandler<GetAppResourceGroupByIdQuery, AppResourceGroupDto?>
{
    public async ValueTask<AppResourceGroupDto?> Handle(
        GetAppResourceGroupByIdQuery query, CancellationToken ct)
    {
        var group = await repo.GetByIdAsync(query.Id, ct);
        return group is null ? null : GroupMappings.ToDto(group);
    }
}

public class CreateAppResourceGroupHandler(IAppResourceGroupRepository repo)
    : ICommandHandler<CreateAppResourceGroupCommand, AppResourceGroupDto>
{
    public async ValueTask<AppResourceGroupDto> Handle(
        CreateAppResourceGroupCommand command, CancellationToken ct)
    {
        var req = command.Request;
        var group = new AppResourceGroup
        {
            GroupKey     = req.GroupKey,
            DisplayName  = req.DisplayName,
            Description  = req.Description,
            IconName     = req.IconName,
            SortOrder    = req.SortOrder,
            IsActive     = req.IsActive,
            LastModifiedBy = command.UserId,
        };
        var created = await repo.CreateAsync(group, ct);
        return GroupMappings.ToDto(created);
    }
}

public class UpdateAppResourceGroupHandler(IAppResourceGroupRepository repo)
    : ICommandHandler<UpdateAppResourceGroupCommand, AppResourceGroupDto>
{
    public async ValueTask<AppResourceGroupDto> Handle(
        UpdateAppResourceGroupCommand command, CancellationToken ct)
    {
        var req = command.Request;
        var patch = new AppResourceGroup
        {
            Id           = command.Id,
            GroupKey     = req.GroupKey,
            DisplayName  = req.DisplayName,
            Description  = req.Description,
            IconName     = req.IconName,
            SortOrder    = req.SortOrder,
            IsActive     = req.IsActive,
            LastModifiedBy = command.UserId,
        };
        var updated = await repo.UpdateAsync(patch, ct);
        return GroupMappings.ToDto(updated);
    }
}

public class DeleteAppResourceGroupHandler(IAppResourceGroupRepository repo)
    : ICommandHandler<DeleteAppResourceGroupCommand, Unit>
{
    public async ValueTask<Unit> Handle(
        DeleteAppResourceGroupCommand command, CancellationToken ct)
    {
        await repo.DeleteAsync(command.Id, ct);
        return Unit.Value;
    }
}

internal static class GroupMappings
{
    internal static AppResourceGroupDto ToDto(AppResourceGroup g) => new(
        g.Id,
        g.GroupKey,
        g.DisplayName,
        g.Description,
        g.IconName,
        g.SortOrder,
        g.IsActive,
        g.CreatedAt,
        g.LastModifiedAt);
}
