using Mediator;
using SecurityApp.Application.Securities.DTOs;
using SecurityApp.Application.Securities.Queries;
using SecurityApp.Core.Securities.Interfaces;
using SecurityApp.Core.Shared.Interfaces;

namespace SecurityApp.Application.Securities.Handlers;

public class GetSecurityRefDataHandler : IQueryHandler<GetSecurityRefDataQuery, SecurityRefDataDto>
{
    private readonly ISecurityRefDataRepository _repo;
    private readonly ICacheService              _cache;

    public GetSecurityRefDataHandler(ISecurityRefDataRepository repo, ICacheService cache)
    {
        _repo  = repo;
        _cache = cache;
    }

    public async ValueTask<SecurityRefDataDto> Handle(GetSecurityRefDataQuery query, CancellationToken cancellationToken)
    {
        const string cacheKey = "security:ref-data";
        var cached = await _cache.GetAsync<SecurityRefDataDto>(cacheKey, cancellationToken);
        if (cached is not null) return cached;

        var statuses     = await _repo.GetStatusesAsync(cancellationToken);
        var assetClasses = await _repo.GetAssetClassesWithTypesAsync(cancellationToken);

        var dto = new SecurityRefDataDto(
            Statuses: statuses.Select(s => new SecurityStatusRefDto(s.Code, s.Description)).ToList(),
            AssetClasses: assetClasses.Select(ac => new AssetClassRefDto(
                ac.Code,
                ac.Name,
                ac.Description,
                ac.InstrumentTypes
                    .OrderBy(it => it.Code)
                    .Select(it => new InstrumentTypeRefDto(it.Code, it.AssetClassCode, it.Description))
                    .ToList()
            )).OrderBy(ac => ac.Name).ToList()
        );

        // Reference data changes rarely — cache for 30 minutes
        await _cache.SetAsync(cacheKey, dto, TimeSpan.FromMinutes(30), cancellationToken);
        return dto;
    }
}
