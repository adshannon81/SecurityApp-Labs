﻿using Mediator;
using SecurityApp.Core.Securities.Models;
using SecurityApp.Core.Securities.Interfaces;
using SecurityApp.Core.Ratings.Interfaces;
using SecurityApp.Application.Securities.Queries;

namespace SecurityApp.Application.Securities.Handlers;

/// <summary>
/// Handles <see cref="ExportSecuritiesQuery"/>.
/// Loads securities, their attributes and primary credit ratings in three
/// parallel queries then joins in memory to produce flat export records.
/// </summary>
public class ExportSecuritiesHandler
    : IQueryHandler<ExportSecuritiesQuery, IEnumerable<SecurityExportRecord>>
{
    private readonly ISecuritiesUoW _securitiesUoW;
    private readonly IRatingsUoW _ratingsUoW;

    public ExportSecuritiesHandler(ISecuritiesUoW securitiesUoW, IRatingsUoW ratingsUoW)
    {
        _securitiesUoW = securitiesUoW;
        _ratingsUoW    = ratingsUoW;
    }

    public async ValueTask<IEnumerable<SecurityExportRecord>> Handle(
        ExportSecuritiesQuery query,
        CancellationToken cancellationToken)
    {
        // Sequential queries: all three share the same scoped DbContext via UnitOfWork
        var securities   = (await _securitiesUoW.Securities.GetAllAsync(cancellationToken)).ToList();
        var attrLookup   = (await _securitiesUoW.SecurityCoreAttributes.GetAllAsync(cancellationToken))
            .ToDictionary(a => a.SecurityId);
        var ratingLookup = (await _ratingsUoW.CreditRatings.GetAllAsync(cancellationToken))
            .Where(r => r.IsCurrent && !r.IsDeleted)
            .GroupBy(r => r.SecurityId)
            .ToDictionary(g => g.Key, g => g.First());

        var securityIds = securities.Select(s => s.Id).ToHashSet();
        var allIdentifiers = (await _securitiesUoW.SecurityIdentifiers.FindAsync(
            si => securityIds.Contains(si.SecurityId) && si.IsCurrent && !si.IsDeleted,
            cancellationToken)).ToList();
        var primaryIdentifierBySecId = allIdentifiers
            .GroupBy(si => si.SecurityId)
            .ToDictionary(g => g.Key,
                g => g.FirstOrDefault(i => i.IsPrimary) ?? g.First());

        IEnumerable<SecurityApp.Core.Securities.Entities.Security> filteredSecurities = securities;

        // Targeting filter: Identifiers (CUSIP, ISIN, SEDOL, Ticker, Bloomberg, Reuters RIC)
        if (query.Identifiers is { Count: > 0 })
        {
            var matchingSecIds = allIdentifiers
                .Where(si => query.Identifiers.Any(i =>
                    string.Equals(i.IdentifierType.ToString(), si.IdentifierType, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(i.IdentifierValue, si.IdentifierValue, StringComparison.OrdinalIgnoreCase)))
                .Select(si => si.SecurityId)
                .ToHashSet();
            filteredSecurities = filteredSecurities.Where(s => matchingSecIds.Contains(s.Id));
        }

        if (!string.IsNullOrWhiteSpace(query.Type))
            filteredSecurities = filteredSecurities.Where(s => s.InstrumentTypeCode == query.Type
                || string.Equals(s.Type.ToString(), query.Type, StringComparison.OrdinalIgnoreCase));

        if (query.IsActive.HasValue)
            filteredSecurities = filteredSecurities.Where(s => s.IsCurrent == query.IsActive.Value);

        var exportedAt = DateTime.UtcNow;

        return filteredSecurities.Select(s =>
        {
            attrLookup.TryGetValue(s.Id, out var attr);
            ratingLookup.TryGetValue(s.Id, out var rating);
            primaryIdentifierBySecId.TryGetValue(s.Id, out var primaryId);

            return new SecurityExportRecord
            {
                Id                   = s.Id,
                IdentifierType       = primaryId?.IdentifierType  ?? string.Empty,
                IdentifierValue      = primaryId?.IdentifierValue ?? string.Empty,
                SecurityType         = s.InstrumentTypeCode,
                Name                 = s.Name,
                IsActive             = s.IsCurrent,
                Description          = s.Description,
                Issuer               = s.IssuerNav?.LegalName ?? s.IssuerNav?.DisplayName,
                Currency             = s.CurrencyCode,
                CouponRate           = attr?.CouponRate,
                FactorRate           = attr?.FactorRate,
                MaturityDate         = attr?.MaturityDate,
                IssueDate            = attr?.IssueDate,
                FaceValue            = attr?.FaceValue,
                PrimaryRating        = rating?.Rating,
                PrimaryRatingAgency  = rating?.Agency.ToString(),
                ExportedAt           = exportedAt
            };
        });
    }
}
