﻿using Mediator;
using SecurityApp.Core.Grpc;
using SecurityApp.Core.Securities.Interfaces;
using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Core.Securities.Services;
using SecurityApp.Application.Securities.Commands;
using SecurityApp.Core.Securities.Entities;
using SecurityApp.Application.Securities.DTOs;
using SecurityApp.Core.Ratings.Entities;
using SecurityApp.Core.Shared.Enums;
using SecurityApp.Core.Shared.Exceptions;
using System.Security.Cryptography;
using System.Text;

namespace SecurityApp.Application.Securities.Handlers;

/// <summary>
/// Handler for CreateSecurityCommand using Mediator
/// </summary>
public class CreateSecurityHandler : ICommandHandler<CreateSecurityCommand, CreateSecurityResponse>
{
    private readonly ISecuritiesUoW _securitiesUoW;
    private readonly ICacheService _cacheService;
    private readonly IGrpcEventPublisher _grpcPublisher;

    public CreateSecurityHandler(ISecuritiesUoW securitiesUoW, ICacheService cacheService, IGrpcEventPublisher grpcPublisher)
    {
        _securitiesUoW = securitiesUoW;
        _cacheService  = cacheService;
        _grpcPublisher = grpcPublisher;
    }

    public async ValueTask<CreateSecurityResponse> Handle(CreateSecurityCommand command, CancellationToken cancellationToken)
    {
        var security = new Security
        {
            Type             = command.Security.Type,
            Name             = command.Security.Name,
            Description      = command.Security.Description,
            IssuerId         = command.Security.IssuerId,
            CurrencyCode     = command.Security.CurrencyCode,
            IsCurrent        = command.Security.IsActive,
            AssetClassCode   = command.Security.AssetClassCode,
            InstrumentTypeCode = command.Security.InstrumentTypeCode,
            StatusCode       = command.Security.StatusCode,
            DataSource       = DataSourceType.Manual,
            CreatedBy        = command.UserId,
            LastModifiedBy   = command.UserId,
        };

        // Seed identifiers: either from the Identifiers collection or from the legacy single-identifier fields
        if (command.Security.Identifiers is { Count: > 0 })
        {
            foreach (var id in command.Security.Identifiers)
            {
                security.Identifiers.Add(new SecurityIdentifier
                {
                    SecurityId      = security.Id,
                    IdentifierType  = id.IdentifierType,
                    IdentifierValue = id.IdentifierValue,
                    SourceSystem    = string.IsNullOrWhiteSpace(id.SourceSystem) ? "Manual" : id.SourceSystem,
                    IsPrimary       = id.IsPrimary,
                    LastModifiedBy      = command.UserId,
                });
            }
        }
        else if (!string.IsNullOrWhiteSpace(command.Security.IdentifierValue))
        {
            security.Identifiers.Add(new SecurityIdentifier
            {
                SecurityId      = security.Id,
                IdentifierType  = command.Security.IdentifierType.ToString(),
                IdentifierValue = command.Security.IdentifierValue,
                SourceSystem    = DataSourceType.Manual.ToString(),
                IsPrimary       = true,
                LastModifiedBy      = command.UserId,
            });
        }

        if (command.Security.Attributes != null)
        {
            security.Attributes = new SecurityCoreAttribute
            {
                SecurityId   = security.Id,
                CouponRate   = command.Security.Attributes.CouponRate,
                FactorRate   = command.Security.Attributes.FactorRate,
                MaturityDate = command.Security.Attributes.MaturityDate,
                IssueDate    = command.Security.Attributes.IssueDate,
                FaceValue    = command.Security.Attributes.FaceValue,
                LastModifiedBy   = command.UserId,
            };
        }

        // Initial ratings are part of the Security aggregate; adding them to the
        // navigation collection lets EF Core persist them atomically in the same
        // SaveChangesAsync call with no cross-slice write.
        if (command.Security.Ratings != null)
        {
            foreach (var r in command.Security.Ratings)
            {
                security.CreditRatings.Add(new CreditRating
                {
                    SecurityId = security.Id,
                    Agency     = r.Agency,
                    Rating     = r.Rating,
                    RatingType = r.RatingType,
                    RatingDate = r.RatingDate
                });
            }
        }

        await _securitiesUoW.Securities.AddAsync(security, cancellationToken);
        await _securitiesUoW.SaveChangesAsync(cancellationToken);

        await _cacheService.RemoveByPatternAsync("security:all:*",    cancellationToken);
        await _cacheService.RemoveByPatternAsync("security:search:*", cancellationToken);

        var primaryId = security.Identifiers.FirstOrDefault(i => i.IsPrimary) ?? security.Identifiers.FirstOrDefault();
        await _grpcPublisher.PublishSecurityChangedAsync(new SecurityChangedPayload(
            security.Id, "Created",
            primaryId?.IdentifierType ?? "INTERNAL", primaryId?.IdentifierValue ?? security.Name,
            security.Name, security.Type.ToString(), security.IsActive(),
            security.CurrencyCode ?? string.Empty, string.Empty,
            security.Description ?? string.Empty,
            DateTime.UtcNow,
            security.StatusCode, security.AssetClassCode, security.InstrumentTypeCode), cancellationToken);

        return new CreateSecurityResponse(security.Id, "Created");
    }
}

/// <summary>
/// Handler for UpdateSecurityCommand
/// </summary>
public class UpdateSecurityHandler : ICommandHandler<UpdateSecurityCommand>
{
    private readonly ISecuritiesUoW _unitOfWork;
    private readonly ICacheService _cacheService;
    private readonly IGrpcEventPublisher _grpcPublisher;

    public UpdateSecurityHandler(ISecuritiesUoW unitOfWork, ICacheService cacheService, IGrpcEventPublisher grpcPublisher)
    {
        _unitOfWork    = unitOfWork;
        _cacheService  = cacheService;
        _grpcPublisher = grpcPublisher;
    }

    public async ValueTask<Unit> Handle(UpdateSecurityCommand command, CancellationToken cancellationToken)
    {
        var security = await _unitOfWork.Securities.GetByIdAsync(command.SecurityId, cancellationToken)
            ?? throw new NotFoundException(nameof(Security), command.SecurityId);

        // Optimistic concurrency (SQL Server path): if the caller supplied a RowVersion (ETag)
        // and the entity has a populated RowVersion, they must match.
        // On PostgreSQL, RowVersion is empty and xmin is used instead — EF throws
        // DbUpdateConcurrencyException at SaveChangesAsync time (caught below).
        if (command.RowVersion is { Length: > 0 }
            && security.RowVersion is { Length: > 0 }
            && !command.RowVersion.SequenceEqual(security.RowVersion))
            throw new ConcurrencyConflictException(nameof(Security), command.SecurityId);

        // Validate lifecycle transition (both forward and backward moves are permitted).
        if (!string.IsNullOrWhiteSpace(command.Security.StatusCode) &&
            !string.Equals(command.Security.StatusCode, security.StatusCode, StringComparison.OrdinalIgnoreCase))
        {
            LifecycleGuard.GuardTransition(security.StatusCode, command.Security.StatusCode);
        }

        security.Name              = command.Security.Name;
        security.Description       = command.Security.Description;
        security.IssuerId          = command.Security.IssuerId;
        security.CurrencyCode      = command.Security.CurrencyCode;
        security.IsCurrent         = command.Security.IsActive;
        security.AssetClassCode    = command.Security.AssetClassCode;
        security.InstrumentTypeCode = command.Security.InstrumentTypeCode;
        security.StatusCode        = command.Security.StatusCode;
        security.DataSource        = DataSourceType.Manual;
        security.LastModifiedAt   = DateTime.UtcNow;
        security.LastModifiedBy  = command.UserId;

        await _unitOfWork.Securities.UpdateAsync(security, cancellationToken);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        // ── Identifier upsert ──────────────────────────────────────────────────────────────────
        if (command.Security.Identifiers is { Count: > 0 })
        {
            // Soft-delete existing identifiers not present in the new set
            var existing = (await _unitOfWork.SecurityIdentifiers.FindAsync(
                si => si.SecurityId == command.SecurityId, cancellationToken)).ToList();

            foreach (var old in existing)
            {
                var keep = command.Security.Identifiers.Any(i =>
                    i.IdentifierType  == old.IdentifierType &&
                    i.IdentifierValue == old.IdentifierValue);
                if (!keep)
                {
                    old.IsDeleted = true;
                    old.IsCurrent = false;
                    old.LastModifiedAt = DateTime.UtcNow;
                    await _unitOfWork.SecurityIdentifiers.UpdateAsync(old, cancellationToken);
                }
            }

            // Add new identifiers that don't already exist
            foreach (var id in command.Security.Identifiers)
            {
                var alreadyExists = existing.Any(e =>
                    e.IdentifierType  == id.IdentifierType &&
                    e.IdentifierValue == id.IdentifierValue);
                if (!alreadyExists)
                {
                    await _unitOfWork.SecurityIdentifiers.AddAsync(new SecurityIdentifier
                    {
                        SecurityId      = command.SecurityId,
                        IdentifierType  = id.IdentifierType,
                        IdentifierValue = id.IdentifierValue,
                        SourceSystem    = string.IsNullOrWhiteSpace(id.SourceSystem) ? "Manual" : id.SourceSystem,
                        IsPrimary       = id.IsPrimary,
                        LastModifiedBy      = command.UserId,
                    }, cancellationToken);
                }
            }
            await _unitOfWork.SaveChangesAsync(cancellationToken);
        }

        // ── Core attributes upsert ────────────────────────────────────────────
        if (command.Security.Attributes is not null)
        {
            var existingList = await _unitOfWork.SecurityCoreAttributes.FindAsync(
                a => a.SecurityId == command.SecurityId, cancellationToken);
            var existing = existingList.FirstOrDefault();
            if (existing is null)
            {
                await _unitOfWork.SecurityCoreAttributes.AddAsync(new SecurityCoreAttribute
                {
                    SecurityId   = command.SecurityId,
                    CouponRate   = command.Security.Attributes.CouponRate,
                    FactorRate   = command.Security.Attributes.FactorRate,
                    MaturityDate = command.Security.Attributes.MaturityDate,
                    IssueDate    = command.Security.Attributes.IssueDate,
                    FaceValue    = command.Security.Attributes.FaceValue,
                    LastModifiedBy   = command.UserId,
                }, cancellationToken);
            }
            else
            {
                existing.CouponRate   = command.Security.Attributes.CouponRate;
                existing.FactorRate   = command.Security.Attributes.FactorRate;
                existing.MaturityDate = command.Security.Attributes.MaturityDate;
                existing.IssueDate    = command.Security.Attributes.IssueDate;
                existing.FaceValue    = command.Security.Attributes.FaceValue;
                existing.LastModifiedAt    = DateTime.UtcNow;
                existing.LastModifiedBy   = command.UserId;
                await _unitOfWork.SecurityCoreAttributes.UpdateAsync(existing, cancellationToken);
            }
            await _unitOfWork.SaveChangesAsync(cancellationToken);
        }

        // ── Loan attributes upsert ────────────────────────────────────────────
        if (command.Security.LoanAttributes is not null)
        {
            var existingList = await _unitOfWork.SecurityLoanAttributes.FindAsync(
                a => a.SecurityId == command.SecurityId, cancellationToken);
            var existing = existingList.FirstOrDefault();
            var src = command.Security.LoanAttributes;
            if (existing is null)
            {
                await _unitOfWork.SecurityLoanAttributes.AddAsync(new SecurityLoanAttribute
                {
                    SecurityId     = command.SecurityId,
                    LoanType       = src.LoanType,
                    CollateralType = src.CollateralType,
                    Seniority      = src.Seniority,
                    Amortization   = src.Amortization,
                    PaymentFreq    = src.PaymentFreq,
                    DayCount       = src.DayCount,
                    MarginBps      = src.MarginBps,
                    ReferenceIndex = src.ReferenceIndex,
                    MaturityDate   = src.MaturityDate,
                    DrawdownLimit  = src.DrawdownLimit,
                    LastModifiedBy     = command.UserId,
                }, cancellationToken);
            }
            else
            {
                existing.LoanType       = src.LoanType;
                existing.CollateralType = src.CollateralType;
                existing.Seniority      = src.Seniority;
                existing.Amortization   = src.Amortization;
                existing.PaymentFreq    = src.PaymentFreq;
                existing.DayCount       = src.DayCount;
                existing.MarginBps      = src.MarginBps;
                existing.ReferenceIndex = src.ReferenceIndex;
                existing.MaturityDate   = src.MaturityDate;
                existing.DrawdownLimit  = src.DrawdownLimit;
                existing.LastModifiedAt      = DateTime.UtcNow;
                existing.LastModifiedBy     = command.UserId;
                await _unitOfWork.SecurityLoanAttributes.UpdateAsync(existing, cancellationToken);
            }
            await _unitOfWork.SaveChangesAsync(cancellationToken);
        }

        // ── Derivative attributes upsert ──────────────────────────────────────
        if (command.Security.DerivativeAttributes is not null)
        {
            var existingList = await _unitOfWork.SecurityDerivativeAttributes.FindAsync(
                a => a.SecurityId == command.SecurityId, cancellationToken);
            var existing = existingList.FirstOrDefault();
            var src = command.Security.DerivativeAttributes;
            if (existing is null)
            {
                await _unitOfWork.SecurityDerivativeAttributes.AddAsync(new SecurityDerivativeAttribute
                {
                    SecurityId     = command.SecurityId,
                    UnderlyingType = src.UnderlyingType,
                    UnderlyingId   = src.UnderlyingId,
                    Notional       = src.Notional,
                    NotionalCcy    = src.NotionalCcy,
                    StrikePrice    = src.StrikePrice,
                    StrikeCcy      = src.StrikeCcy,
                    OptionStyle    = src.OptionStyle,
                    OptionType     = src.OptionType,
                    ExpiryDate     = src.ExpiryDate,
                    SettlementType = src.SettlementType,
                    LegCount       = src.LegCount,
                    LastModifiedBy     = command.UserId,
                }, cancellationToken);
            }
            else
            {
                existing.UnderlyingType = src.UnderlyingType;
                existing.UnderlyingId   = src.UnderlyingId;
                existing.Notional       = src.Notional;
                existing.NotionalCcy    = src.NotionalCcy;
                existing.StrikePrice    = src.StrikePrice;
                existing.StrikeCcy      = src.StrikeCcy;
                existing.OptionStyle    = src.OptionStyle;
                existing.OptionType     = src.OptionType;
                existing.ExpiryDate     = src.ExpiryDate;
                existing.SettlementType = src.SettlementType;
                existing.LegCount       = src.LegCount;
                existing.LastModifiedAt      = DateTime.UtcNow;
                existing.LastModifiedBy     = command.UserId;
                await _unitOfWork.SecurityDerivativeAttributes.UpdateAsync(existing, cancellationToken);
            }
            await _unitOfWork.SaveChangesAsync(cancellationToken);
        }

        // ── Securitized attributes upsert ─────────────────────────────────────
        if (command.Security.SecuritizedAttributes is not null)
        {
            var existingList = await _unitOfWork.SecuritySecuritizedAttributes.FindAsync(
                a => a.SecurityId == command.SecurityId, cancellationToken);
            var existing = existingList.FirstOrDefault();
            var src = command.Security.SecuritizedAttributes;
            if (existing is null)
            {
                await _unitOfWork.SecuritySecuritizedAttributes.AddAsync(new SecuritySecuritizedAttribute
                {
                    SecurityId        = command.SecurityId,
                    PoolId            = src.PoolId,
                    TrancheLabel      = src.TrancheLabel,
                    TrancheSeniority  = src.TrancheSeniority,
                    OriginalBalance   = src.OriginalBalance,
                    CurrentBalance    = src.CurrentBalance,
                    CreditEnhancement = src.CreditEnhancement,
                    Callable          = src.Callable,
                    CallDate          = src.CallDate,
                    LastModifiedBy        = command.UserId,
                }, cancellationToken);
            }
            else
            {
                existing.PoolId            = src.PoolId;
                existing.TrancheLabel      = src.TrancheLabel;
                existing.TrancheSeniority  = src.TrancheSeniority;
                existing.OriginalBalance   = src.OriginalBalance;
                existing.CurrentBalance    = src.CurrentBalance;
                existing.CreditEnhancement = src.CreditEnhancement;
                existing.Callable          = src.Callable;
                existing.CallDate          = src.CallDate;
                existing.LastModifiedAt         = DateTime.UtcNow;
                existing.LastModifiedBy        = command.UserId;
                await _unitOfWork.SecuritySecuritizedAttributes.UpdateAsync(existing, cancellationToken);
            }
            await _unitOfWork.SaveChangesAsync(cancellationToken);
        }

        await _cacheService.RemoveAsync($"security:{command.SecurityId}",  cancellationToken);
        await _cacheService.RemoveByPatternAsync("security:all:*",    cancellationToken);
        await _cacheService.RemoveByPatternAsync("security:search:*", cancellationToken);

        var updatedIdentifiers = (await _unitOfWork.SecurityIdentifiers.FindAsync(
            si => si.SecurityId == command.SecurityId && si.IsCurrent && !si.IsDeleted, cancellationToken)).ToList();
        var updatedPrimary = updatedIdentifiers.FirstOrDefault(i => i.IsPrimary) ?? updatedIdentifiers.FirstOrDefault();
        await _grpcPublisher.PublishSecurityChangedAsync(new SecurityChangedPayload(
            security.Id, "Updated",
            updatedPrimary?.IdentifierType ?? "INTERNAL", updatedPrimary?.IdentifierValue ?? security.Name,
            security.Name, security.Type.ToString(), security.IsActive(),
            security.CurrencyCode ?? string.Empty, string.Empty,
            security.Description ?? string.Empty,
            DateTime.UtcNow,
            security.StatusCode, security.AssetClassCode, security.InstrumentTypeCode), cancellationToken);

        return Unit.Value;
    }
}

/// <summary>
/// Handler for DeleteSecurityCommand
/// </summary>
public class DeleteSecurityHandler : ICommandHandler<DeleteSecurityCommand>
{
    private readonly ISecuritiesUoW _unitOfWork;
    private readonly ICacheService _cacheService;
    private readonly IGrpcEventPublisher _grpcPublisher;

    public DeleteSecurityHandler(ISecuritiesUoW unitOfWork, ICacheService cacheService, IGrpcEventPublisher grpcPublisher)
    {
        _unitOfWork    = unitOfWork;
        _cacheService  = cacheService;
        _grpcPublisher = grpcPublisher;
    }

    public async ValueTask<Unit> Handle(DeleteSecurityCommand command, CancellationToken cancellationToken)
    {
        var security = await _unitOfWork.Securities.GetByIdAsync(command.SecurityId, cancellationToken)
            ?? throw new NotFoundException(nameof(Security), command.SecurityId);

        await _unitOfWork.Securities.DeleteAsync(command.SecurityId, cancellationToken);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        await _cacheService.RemoveAsync($"security:{command.SecurityId}",  cancellationToken);
        await _cacheService.RemoveByPatternAsync("security:all:*",    cancellationToken);
        await _cacheService.RemoveByPatternAsync("security:search:*", cancellationToken);

        await _grpcPublisher.PublishSecurityChangedAsync(new SecurityChangedPayload(
            command.SecurityId, "Deleted",
            "INTERNAL", security.Name,
            security.Name, security.Type.ToString(), security.IsActive(),
            security.CurrencyCode ?? string.Empty, string.Empty,
            security.Description ?? string.Empty,
            DateTime.UtcNow,
            security.StatusCode, security.AssetClassCode, security.InstrumentTypeCode), cancellationToken);

        return Unit.Value;
    }
}

/// <summary>
/// Shared helper for computing a deterministic content hash across security command handlers.
/// </summary>
internal static class SecurityHashHelper
{
    internal static string ComputeContentHash(
        string? identifierType, string? identifierValue, string? type,
        string? name, string? description, string? issuer, string? currency)
    {
        var raw = $"{identifierType}|{identifierValue}|{type}|{name}|{description}|{issuer}|{currency}";
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(raw));
        return Convert.ToHexString(bytes).ToLowerInvariant();
    }
}
