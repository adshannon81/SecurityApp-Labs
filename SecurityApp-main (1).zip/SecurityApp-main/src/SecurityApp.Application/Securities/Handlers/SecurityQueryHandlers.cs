using Mediator;
using SecurityApp.Core.Securities.Entities;
using SecurityApp.Core.Securities.Interfaces;
using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Core.Securities.Services;
using SecurityApp.Core.Users;
using SecurityApp.Application.Securities.Queries;
using SecurityApp.Application.Securities.DTOs;
using SecurityApp.Application.Issuers.DTOs;
using SecurityApp.Application.Shared;
using SecurityApp.Core.Securities.Enums;

namespace SecurityApp.Application.Securities.Handlers;

/// <summary>
/// Handler for GetSecurityByIdQuery
/// </summary>
public class GetSecurityByIdHandler : IQueryHandler<GetSecurityByIdQuery, SecurityDto?>
{
    private readonly ISecuritiesUoW _unitOfWork;
    private readonly ICacheService _cacheService;
    private readonly IUserCacheService _userCache;

    public GetSecurityByIdHandler(ISecuritiesUoW unitOfWork, ICacheService cacheService, IUserCacheService userCache)
    {
        _unitOfWork   = unitOfWork;
        _cacheService = cacheService;
        _userCache    = userCache;
    }

    public async ValueTask<SecurityDto?> Handle(GetSecurityByIdQuery query, CancellationToken cancellationToken)
    {
        var key    = $"security:{query.SecurityId}";
        var cached = await _cacheService.GetAsync<SecurityDto>(key, cancellationToken);
        if (cached is not null) return cached;

        var security = await _unitOfWork.Securities.GetByIdAsync(query.SecurityId, cancellationToken);
        if (security is null) return null;

        var attrs = await _unitOfWork.SecurityCoreAttributes.FindAsync(
            a => a.SecurityId == query.SecurityId, cancellationToken);
        security.Attributes = attrs.FirstOrDefault();
        var loanAttrs = await _unitOfWork.SecurityLoanAttributes.FindAsync(
            a => a.SecurityId == query.SecurityId, cancellationToken);
        security.LoanAttributes = loanAttrs.FirstOrDefault();

        var derivAttrs = await _unitOfWork.SecurityDerivativeAttributes.FindAsync(
            a => a.SecurityId == query.SecurityId, cancellationToken);
        security.DerivativeAttributes = derivAttrs.FirstOrDefault();

        var secAttrs = await _unitOfWork.SecuritySecuritizedAttributes.FindAsync(
            a => a.SecurityId == query.SecurityId, cancellationToken);
        security.SecuritizedAttributes = secAttrs.FirstOrDefault();

        security.Kv = (await _unitOfWork.SecurityAttributeKvs.FindAsync(
            a => a.SecurityId == query.SecurityId, cancellationToken)).ToList();
        security.Identifiers = (await _unitOfWork.SecurityIdentifiers.FindAsync(
            si => si.SecurityId == query.SecurityId, cancellationToken)).ToList();
        var dto = SecurityMappings.MapToDto(security, _userCache.ResolveDisplayName);
        await _cacheService.SetAsync(key, dto, TimeSpan.FromMinutes(5), cancellationToken);
        return dto;
    }
}

/// <summary>
/// Handler for GetAllSecuritiesQuery
/// </summary>
public class GetAllSecuritiesHandler : IQueryHandler<GetAllSecuritiesQuery, PagedResult<SecurityDto>>
{
    private readonly ISecuritiesUoW _unitOfWork;
    private readonly ICacheService _cacheService;
    private readonly IUserCacheService _userCache;

    public GetAllSecuritiesHandler(ISecuritiesUoW unitOfWork, ICacheService cacheService, IUserCacheService userCache)
    {
        _unitOfWork   = unitOfWork;
        _cacheService = cacheService;
        _userCache    = userCache;
    }

    public async ValueTask<PagedResult<SecurityDto>> Handle(GetAllSecuritiesQuery query, CancellationToken cancellationToken)
    {
        var key    = $"security:all:page{query.PageNumber}:size{query.PageSize}";
        var cached = await _cacheService.GetAsync<PagedResult<SecurityDto>>(key, cancellationToken);
        if (cached is not null) return cached;

        var (items, totalCount) = await _unitOfWork.Securities.GetPagedAsync(
            predicate:  null,
            orderBy:    s => s.Name,
            descending: false,
            page:       query.PageNumber,
            pageSize:   query.PageSize,
            cancellationToken);

        var result = new PagedResult<SecurityDto>(
            Items:       items.Select(s => SecurityMappings.MapToDto(s, _userCache.ResolveDisplayName)).ToList(),
            TotalCount:  totalCount,
            PageNumber:  query.PageNumber,
            PageSize:    query.PageSize);

        await _cacheService.SetAsync(key, result, TimeSpan.FromMinutes(5), cancellationToken);
        return result;
    }
}

/// <summary>
/// Handler for SearchSecuritiesQuery - filters the local database by identifier, name, type, or active status.
/// </summary>
public class SearchSecuritiesHandler : IQueryHandler<SearchSecuritiesQuery, PagedResult<SecurityDto>>
{
    private readonly ISecuritiesUoW _unitOfWork;
    private readonly ICacheService _cacheService;
    private readonly IUserCacheService _userCache;

    public SearchSecuritiesHandler(ISecuritiesUoW unitOfWork, ICacheService cacheService, IUserCacheService userCache)
    {
        _unitOfWork   = unitOfWork;
        _cacheService = cacheService;
        _userCache    = userCache;
    }

    public async ValueTask<PagedResult<SecurityDto>> Handle(SearchSecuritiesQuery query, CancellationToken cancellationToken)
    {
        var key    = $"security:search:{query.IdentifierValue}:{query.Name}:{query.Type}:{query.InstrumentTypeCode}:{query.AssetClassCode}:{query.StatusCode}:{query.IsActive}:{query.PageNumber}:{query.PageSize}:{query.SortBy}:{query.Descending}";
        var cached = await _cacheService.GetAsync<PagedResult<SecurityDto>>(key, cancellationToken);
        if (cached is not null) return cached;

        // Legacy Type param falls through to InstrumentTypeCode filter when no explicit InstrumentTypeCode is given
        var instrFilter = query.InstrumentTypeCode ?? query.Type;

        System.Linq.Expressions.Expression<Func<Security, object>> orderBy = query.SortBy?.ToLowerInvariant() switch
        {
            "type"              => s => s.InstrumentTypeCode,
            "instrumenttype"    => s => s.InstrumentTypeCode,
            "assetclass"        => s => s.AssetClassCode,
            "statuscode"        => s => s.StatusCode,
            "currency"          => s => s.CurrencyCode ?? string.Empty,
            "status"            => s => s.IsCurrent,
            "createdat"         => s => s.CreatedAt,
            "LastModifiedAt"         => s => s.LastModifiedAt ?? DateTime.MinValue,
            _                   => s => s.Name,
        };

        var (items, totalCount) = await _unitOfWork.Securities.GetPagedAsync(
            predicate:  s => (query.IdentifierValue == null || s.Identifiers.Any(i => i.IsCurrent && !i.IsDeleted && i.IdentifierValue.ToLower().Contains(query.IdentifierValue.ToLower())))
                          && (query.Name            == null || s.Name.ToLower().Contains(query.Name.ToLower()))
                          && (instrFilter           == null || s.InstrumentTypeCode == instrFilter)
                          && (query.AssetClassCode  == null || s.AssetClassCode     == query.AssetClassCode)
                          && (query.StatusCode      == null || s.StatusCode         == query.StatusCode)
                          && (query.IsActive        == null || s.IsCurrent == query.IsActive.Value),
            orderBy:    orderBy,
            descending: query.Descending,
            page:       query.PageNumber,
            pageSize:   query.PageSize,
            cancellationToken);

        var result = new PagedResult<SecurityDto>(
            Items:      items.Select(s => SecurityMappings.MapToDto(s, _userCache.ResolveDisplayName)).ToList(),
            TotalCount: totalCount,
            PageNumber: query.PageNumber,
            PageSize:   query.PageSize);

        await _cacheService.SetAsync(key, result, TimeSpan.FromMinutes(2), cancellationToken);
        return result;
    }
}

internal static class SecurityMappings
{
    internal static SecurityDto MapToDto(Security s, Func<string?, string>? resolver = null)
    {
        // Derive legacy single-identifier fields from the primary identifier in the child table.
        var primary = s.Identifiers.FirstOrDefault(i => i.IsCurrent && !i.IsDeleted && i.IsPrimary)
                   ?? s.Identifiers.FirstOrDefault(i => i.IsCurrent && !i.IsDeleted);
        var primaryType  = Enum.TryParse<IdentifierType>(primary?.IdentifierType, ignoreCase: true, out var pt) ? pt : IdentifierType.Internal;
        var primaryValue = primary?.IdentifierValue ?? string.Empty;

        return new SecurityDto
        {
            Id               = s.Id,
            IdentifierType   = primaryType,
            IdentifierValue  = primaryValue,
        Type             = s.Type,
        Name             = s.Name,
        IsActive         = s.IsCurrent,
        Description      = s.Description,
        IssuerId         = s.IssuerId,
        IssuerSummary    = s.IssuerNav != null ? new IssuerSummaryDto
        {
            Id           = s.IssuerNav.Id,
            LegalName    = s.IssuerNav.LegalName,
            DisplayName  = s.IssuerNav.DisplayName,
            LeiCode      = s.IssuerNav.LeiCode,
            CountryAlpha2 = s.IssuerNav.CountryAlpha2,
            IssuerType   = s.IssuerNav.IssuerType,
            DirectAccountingParent   = null,  // not loaded in list queries for performance
            UltimateAccountingParent = null,
        } : null,
        CurrencyCode     = s.CurrencyCode,
        StatusCode       = s.StatusCode,
        AssetClassCode   = s.AssetClassCode,
        InstrumentTypeCode = s.InstrumentTypeCode,
        CreatedAt        = s.CreatedAt,
        CreatedBy        = resolver != null ? resolver(s.CreatedBy) : s.CreatedBy,
        LastModifiedAt        = s.LastModifiedAt,
        LastModifiedBy       = resolver != null ? resolver(s.LastModifiedBy) : s.LastModifiedBy,
        ContentHash      = s.ContentHash,
        RowVersion       = s.RowVersion,
        Xmin             = s.Xmin,
        IsTradeable      = LifecycleGuard.IsTradeable(s.StatusCode),
        IsPriceable      = LifecycleGuard.IsPriceable(s.StatusCode),
        IsEligible       = LifecycleGuard.IsEligible(s.StatusCode),
        IsReportable     = LifecycleGuard.IsReportable(s.StatusCode),
        Identifiers      = s.Identifiers
            .Where(i => i.IsCurrent && !i.IsDeleted)
            .Select(i => new SecurityIdentifierDto
            {
                Id             = i.Id,
                IdentifierType = i.IdentifierType,
                IdentifierValue = i.IdentifierValue,
                SourceSystem   = i.SourceSystem,
                IsPrimary      = i.IsPrimary,
            }).ToList(),
        Attributes      = s.Attributes != null ? new SecurityAttributeDto
        {
            CouponRate   = s.Attributes.CouponRate,
            FactorRate   = s.Attributes.FactorRate,
            MaturityDate = s.Attributes.MaturityDate,
            IssueDate    = s.Attributes.IssueDate,
            FaceValue    = s.Attributes.FaceValue
        } : null,
        LoanAttributes = s.LoanAttributes != null ? new SecurityLoanAttributeDto
        {
            LoanType       = s.LoanAttributes.LoanType,
            CollateralType = s.LoanAttributes.CollateralType,
            Seniority      = s.LoanAttributes.Seniority,
            Amortization   = s.LoanAttributes.Amortization,
            PaymentFreq    = s.LoanAttributes.PaymentFreq,
            DayCount       = s.LoanAttributes.DayCount,
            MarginBps      = s.LoanAttributes.MarginBps,
            ReferenceIndex = s.LoanAttributes.ReferenceIndex,
            MaturityDate   = s.LoanAttributes.MaturityDate,
            DrawdownLimit  = s.LoanAttributes.DrawdownLimit,
        } : null,
        DerivativeAttributes = s.DerivativeAttributes != null ? new SecurityDerivativeAttributeDto
        {
            UnderlyingType  = s.DerivativeAttributes.UnderlyingType,
            UnderlyingId    = s.DerivativeAttributes.UnderlyingId,
            Notional        = s.DerivativeAttributes.Notional,
            NotionalCcy     = s.DerivativeAttributes.NotionalCcy,
            StrikePrice     = s.DerivativeAttributes.StrikePrice,
            StrikeCcy       = s.DerivativeAttributes.StrikeCcy,
            OptionStyle     = s.DerivativeAttributes.OptionStyle,
            OptionType      = s.DerivativeAttributes.OptionType,
            ExpiryDate      = s.DerivativeAttributes.ExpiryDate,
            SettlementType  = s.DerivativeAttributes.SettlementType,
            LegCount        = s.DerivativeAttributes.LegCount,
        } : null,
        SecuritizedAttributes = s.SecuritizedAttributes != null ? new SecuritySecuritizedAttributeDto
        {
            PoolId             = s.SecuritizedAttributes.PoolId,
            TrancheLabel       = s.SecuritizedAttributes.TrancheLabel,
            TrancheSeniority   = s.SecuritizedAttributes.TrancheSeniority,
            OriginalBalance    = s.SecuritizedAttributes.OriginalBalance,
            CurrentBalance     = s.SecuritizedAttributes.CurrentBalance,
            CreditEnhancement  = s.SecuritizedAttributes.CreditEnhancement,
            Callable           = s.SecuritizedAttributes.Callable,
            CallDate           = s.SecuritizedAttributes.CallDate,
        } : null,
        Kv = s.Kv
            .Where(kv => kv.IsCurrent && !kv.IsDeleted)
            .Select(kv => new SecurityAttributeKvDto
            {
                AttributeName = kv.AttributeName,
                AttributeType = kv.AttributeType,
                ValueString   = kv.ValueString,
                ValueDecimal  = kv.ValueDecimal,
                ValueInt      = kv.ValueInt,
                ValueDate     = kv.ValueDate,
                ValueBool     = kv.ValueBool,
                SourceSystem  = kv.SourceSystem,
            }).ToList(),
        CreditRatings = s.CreditRatings
            .Where(cr => cr.IsCurrent && !cr.IsDeleted)
            .Select(cr => new CreditRatingDto
            {
                Id          = cr.Id,
                Agency      = cr.Agency,
                AgencyLabel = cr.Agency.ToString(),
                Rating      = cr.Rating,
                RatingType  = cr.RatingType,
                RatingDate  = cr.RatingDate,
                ContentHash = cr.ContentHash
            }).ToList()
        };
    }
}
