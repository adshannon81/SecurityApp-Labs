﻿using Mediator;
using SecurityApp.Application.Securities.DTOs;
using SecurityApp.Core.Workflow.Enums;
using SecurityApp.Core.Workflow.Interfaces;

namespace SecurityApp.Application.Securities.Commands;

/// <summary>
/// Command to create a new security
/// </summary>
public record CreateSecurityCommand(CreateSecurityDto Security, string? UserId = null)
    : ICommand<CreateSecurityResponse>, IWorkflowGuardedCommand
{
    public WorkflowTriggerType WorkflowTrigger   => WorkflowTriggerType.SecurityInsert;
    public Guid                WorkflowEntityId  => Guid.Empty; // entity does not exist yet
    public string              WorkflowEntityType => "Security";
}

/// <summary>
/// Response from creating a security
/// </summary>
public record CreateSecurityResponse(Guid SecurityId, string Message);

/// <summary>
/// Command to update a security
/// </summary>
public record UpdateSecurityCommand(Guid SecurityId, CreateSecurityDto Security, string? UserId = null, byte[]? RowVersion = null)
    : ICommand, IWorkflowGuardedCommand
{
    public WorkflowTriggerType WorkflowTrigger   => WorkflowTriggerType.SecurityUpdate;
    public Guid                WorkflowEntityId  => SecurityId;
    public string              WorkflowEntityType => "Security";
}

/// <summary>
/// Command to delete a security
/// </summary>
public record DeleteSecurityCommand(Guid SecurityId)
    : ICommand, IWorkflowGuardedCommand
{
    public WorkflowTriggerType WorkflowTrigger   => WorkflowTriggerType.SecurityDelete;
    public Guid                WorkflowEntityId  => SecurityId;
    public string              WorkflowEntityType => "Security";
}
