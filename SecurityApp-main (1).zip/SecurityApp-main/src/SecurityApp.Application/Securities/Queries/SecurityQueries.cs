﻿using Mediator;
using SecurityApp.Application.Securities.DTOs;
using SecurityApp.Application.Shared;

namespace SecurityApp.Application.Securities.Queries;

/// <summary>
/// Query to get a security by ID
/// </summary>
public record GetSecurityByIdQuery(Guid SecurityId) : IQuery<SecurityDto?>;

/// <summary>
/// Query to get all securities
/// </summary>
public record GetAllSecuritiesQuery(int PageNumber = 1, int PageSize = 50) : IQuery<PagedResult<SecurityDto>>;

/// <summary>
/// Query to search securities
/// </summary>
public record SearchSecuritiesQuery(
    string? IdentifierValue    = null,
    string? Name               = null,
    string? Type               = null,   // legacy: maps to InstrumentTypeCode
    bool?   IsActive           = null,
    int     PageNumber         = 1,
    int     PageSize           = 50,
    string? SortBy             = null,
    bool    Descending         = false,
    string? AssetClassCode     = null,
    string? InstrumentTypeCode = null,
    string? StatusCode         = null) : IQuery<PagedResult<SecurityDto>>;
