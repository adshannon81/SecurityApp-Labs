﻿using Mediator;
using SecurityApp.Core.Securities.Models;
using SecurityApp.Application.Securities.DTOs;

namespace SecurityApp.Application.Securities.Queries;

/// <summary>
/// Retrieves securities (with their attributes and primary credit rating)
/// as flat <see cref="SecurityExportRecord"/> objects ready for serialisation.
/// <para>
/// Targeting: supply <paramref name="Ids"/> (GUIDs) and/or <paramref name="Identifiers"/>
/// (IdentifierType + IdentifierValue pairs). Both sets are unioned - a security is included
/// if it matches <em>any</em> of the supplied IDs or any of the supplied identifier pairs.
/// When neither is supplied, all securities are returned (subject to Type / IsActive filters).
/// </para>
/// </summary>
public record ExportSecuritiesQuery(
    string?                              Type        = null,
    bool?                                IsActive    = null,
    IReadOnlyList<ExportIdentifierRequest>? Identifiers = null) : IQuery<IEnumerable<SecurityExportRecord>>;
