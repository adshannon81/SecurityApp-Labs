using Mediator;
using SecurityApp.Application.Securities.DTOs;

namespace SecurityApp.Application.Securities.Queries;

/// <summary>
/// Returns all security reference / lookup data in a single round-trip:
/// statuses, asset classes, and instrument types (grouped under each asset class).
/// </summary>
public record GetSecurityRefDataQuery : IQuery<SecurityRefDataDto>;
