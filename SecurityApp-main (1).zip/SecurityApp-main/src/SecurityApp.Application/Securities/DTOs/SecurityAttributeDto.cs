using System.ComponentModel.DataAnnotations;

namespace SecurityApp.Application.Securities.DTOs;

/// <summary>
/// DTO for security attributes (bond/loan-specific fields)
/// </summary>
public class SecurityAttributeDto
{
    [Range(0, 100, ErrorMessage = "CouponRate must be between 0 and 100.")]
    public decimal? CouponRate { get; set; }

    [Range(0, 10, ErrorMessage = "FactorRate must be between 0 and 10.")]
    public decimal? FactorRate { get; set; }

    public DateTime? MaturityDate { get; set; }
    public DateTime? IssueDate { get; set; }

    [Range(0, double.MaxValue, ErrorMessage = "FaceValue must be a non-negative number.")]
    public decimal? FaceValue { get; set; }
}
