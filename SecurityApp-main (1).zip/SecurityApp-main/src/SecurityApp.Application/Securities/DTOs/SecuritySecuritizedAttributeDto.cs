namespace SecurityApp.Application.Securities.DTOs;

public class SecuritySecuritizedAttributeDto
{
    public string? PoolId             { get; set; }
    public string? TrancheLabel       { get; set; }
    public string? TrancheSeniority   { get; set; }
    public decimal? OriginalBalance   { get; set; }
    public decimal? CurrentBalance    { get; set; }
    public decimal? CreditEnhancement { get; set; }
    public bool? Callable             { get; set; }
    public DateTime? CallDate         { get; set; }
}
