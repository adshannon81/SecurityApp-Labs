namespace SecurityApp.Application.Securities.DTOs;

/// <summary>
/// DTO for a single security identifier (ISIN, CUSIP, SEDOL, etc.).
/// </summary>
public class SecurityIdentifierDto
{
    public Guid    Id              { get; set; }
    public string  IdentifierType  { get; set; } = string.Empty;
    public string  IdentifierValue { get; set; } = string.Empty;
    public string? SourceSystem    { get; set; }
    public bool    IsPrimary       { get; set; }
}

/// <summary>
/// DTO for creating or updating a security identifier within a create/update command.
/// </summary>
public class CreateSecurityIdentifierDto
{
    public string  IdentifierType  { get; set; } = string.Empty;
    public string  IdentifierValue { get; set; } = string.Empty;
    public string? SourceSystem    { get; set; }
    public bool    IsPrimary       { get; set; }
}
