namespace SecurityApp.Application.Securities.DTOs;

public class SecurityAttributeKvDto
{
    public string AttributeName  { get; set; } = string.Empty;
    public string AttributeType  { get; set; } = string.Empty;
    public string? ValueString   { get; set; }
    public decimal? ValueDecimal { get; set; }
    public long? ValueInt        { get; set; }
    public DateTime? ValueDate   { get; set; }
    public bool? ValueBool       { get; set; }
    public string? SourceSystem  { get; set; }
}
