using SecurityApp.Core.Securities.Enums;
using SecurityApp.Application.Issuers.DTOs;

namespace SecurityApp.Application.Securities.DTOs;

/// <summary>
/// DTO for security response.
/// Field visibility is controlled dynamically via FieldVisibilityRules in the database.
/// </summary>
public class SecurityDto
{
    public Guid Id { get; set; }
    public IdentifierType IdentifierType { get; set; }
    public string IdentifierValue { get; set; } = string.Empty;
    /// <summary>Legacy type field kept for backward compat with gRPC consumers.</summary>
    public SecurityType Type { get; set; }
    public string Name { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public string? Description { get; set; }
    /// <summary>FK to the normalized issuer entity.</summary>
    public Guid? IssuerId { get; set; }
    /// <summary>Issuer summary â€” populated when an issuer record exists.</summary>
    public IssuerSummaryDto? IssuerSummary { get; set; }
    /// <summary>ISO 4217 currency code (FK to currency reference table).</summary>
    public string? CurrencyCode { get; set; }
    // â”€â”€ New classification + status â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    public string StatusCode         { get; set; } = "ACTIVE";
    public string AssetClassCode     { get; set; } = "OTHER";
    public string InstrumentTypeCode { get; set; } = "Other";
    // â”€â”€ Audit â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? LastModifiedAt { get; set; }
    public string? LastModifiedBy { get; set; }
    public string? ContentHash { get; set; }
    public SecurityAttributeDto?             Attributes            { get; set; }
    public SecurityLoanAttributeDto?          LoanAttributes        { get; set; }
    public SecurityDerivativeAttributeDto?    DerivativeAttributes  { get; set; }
    public SecuritySecuritizedAttributeDto?   SecuritizedAttributes { get; set; }
    public List<SecurityIdentifierDto>        Identifiers           { get; set; } = new();
    public List<SecurityAttributeKvDto>       Kv                    { get; set; } = new();
    public List<CreditRatingDto> CreditRatings { get; set; } = new();
    /// <summary>SQL Server ROWVERSION bytes. Returned as base64-encoded ETag on GET; send back via If-Match on PUT.</summary>
    public byte[]? RowVersion { get; set; }

    /// <summary>PostgreSQL xmin concurrency token. Used to build the ETag on PostgreSQL deployments.</summary>
    public uint Xmin { get; set; }

    // â”€â”€ Lifecycle capability flags (computed, never stored) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
    /// <summary>True when the security can be used in trading (status = ACTIVE).</summary>
    public bool IsTradeable { get; set; }
    /// <summary>True when the security can receive a market price (status = ACTIVE or SUSPENDED).</summary>
    public bool IsPriceable { get; set; }
    /// <summary>True when the security is eligible for new allocations (status = ACTIVE).</summary>
    public bool IsEligible { get; set; }
    /// <summary>True when the security must appear in regulatory reports (status â‰  DRAFT, CANCELLED).</summary>
    public bool IsReportable { get; set; }
}
