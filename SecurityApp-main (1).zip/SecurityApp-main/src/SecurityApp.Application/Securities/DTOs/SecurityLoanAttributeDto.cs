namespace SecurityApp.Application.Securities.DTOs;

public class SecurityLoanAttributeDto
{
    public string? LoanType       { get; set; }
    public string? CollateralType { get; set; }
    public string? Seniority      { get; set; }
    public string? Amortization   { get; set; }
    public string? PaymentFreq    { get; set; }
    public string? DayCount       { get; set; }
    public decimal? MarginBps     { get; set; }
    public string? ReferenceIndex { get; set; }
    public DateTime? MaturityDate  { get; set; }
    public decimal? DrawdownLimit { get; set; }
}
