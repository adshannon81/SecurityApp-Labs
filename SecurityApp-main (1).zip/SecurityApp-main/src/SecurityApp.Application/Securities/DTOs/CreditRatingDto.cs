using SecurityApp.Core.Ratings.Enums;

namespace SecurityApp.Application.Securities.DTOs;

/// <summary>
/// DTO for a credit rating response
/// </summary>
public class CreditRatingDto
{
    public Guid Id { get; set; }
    public RatingAgency Agency { get; set; }
    public string AgencyLabel { get; set; } = string.Empty;
    public string Rating { get; set; } = string.Empty;
    public RatingType RatingType { get; set; }
    public DateTime? RatingDate { get; set; }
    public string? ContentHash { get; set; }
}
