using System.ComponentModel.DataAnnotations;
using SecurityApp.Core.Ratings.Enums;

namespace SecurityApp.Application.Securities.DTOs;

/// <summary>
/// DTO for creating a credit rating
/// </summary>
public class CreateCreditRatingDto
{
    public RatingAgency Agency { get; set; }

    [Required(ErrorMessage = "Rating is required.")]
    [StringLength(10, MinimumLength = 1, ErrorMessage = "Rating must be between 1 and 10 characters.")]
    public string Rating { get; set; } = string.Empty;

    public RatingType RatingType { get; set; } = RatingType.LongTerm;
    public DateTime? RatingDate { get; set; }
}
