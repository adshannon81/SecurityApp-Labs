namespace SecurityApp.Application.Securities.DTOs;

/// <summary>
/// Request body for a targeted export via POST /api/export/securities.
/// Supply one or more <see cref="Identifiers"/> (CUSIP, ISIN, SEDOL, Ticker, Bloomberg, Reuters RIC).
/// Omit to export all securities (subject to <see cref="Type"/> and <see cref="IsActive"/> filters).
/// </summary>
public class ExportSecuritiesRequest
{
    /// <summary>Export by market identifiers (Ticker, ISIN, CUSIP, SEDOL, Bloomberg, Reuters RIC).</summary>
    public List<ExportIdentifierRequest>? Identifiers { get; set; }

    /// <summary>Optional security type filter applied on top of the ID/identifier match (e.g. "Bond", "Equity").</summary>
    public string? Type { get; set; }

    /// <summary>Optional active-status filter applied on top of the ID/identifier match.</summary>
    public bool? IsActive { get; set; }

    /// <summary>Output format: json (default), xml, or csv.</summary>
    public string Format { get; set; } = "json";

    /// <summary>Column delimiter for CSV output. Use "," (default), "|", ";" or "\t" for tab.</summary>
    public string Delimiter { get; set; } = ",";

    /// <summary>Named export profile from ColumnMappings:Export in appsettings.json (default: "Default").</summary>
    public string Profile { get; set; } = "Default";
}
