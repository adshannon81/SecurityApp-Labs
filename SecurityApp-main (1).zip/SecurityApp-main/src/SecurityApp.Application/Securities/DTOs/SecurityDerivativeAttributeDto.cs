namespace SecurityApp.Application.Securities.DTOs;

public class SecurityDerivativeAttributeDto
{
    public string? UnderlyingType  { get; set; }
    public Guid? UnderlyingId     { get; set; }
    public decimal? Notional       { get; set; }
    public string? NotionalCcy     { get; set; }
    public decimal? StrikePrice    { get; set; }
    public string? StrikeCcy       { get; set; }
    public string? OptionStyle     { get; set; }
    public string? OptionType      { get; set; }
    public DateTime? ExpiryDate    { get; set; }
    public string? SettlementType  { get; set; }
    public int? LegCount           { get; set; }
}
