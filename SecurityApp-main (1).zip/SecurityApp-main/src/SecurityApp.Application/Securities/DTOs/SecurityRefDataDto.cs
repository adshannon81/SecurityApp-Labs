namespace SecurityApp.Application.Securities.DTOs;

public record SecurityStatusRefDto(string Code, string Description);

public record InstrumentTypeRefDto(string Code, string AssetClassCode, string? Description);

public record AssetClassRefDto(
    string Code,
    string Name,
    string? Description,
    IList<InstrumentTypeRefDto> InstrumentTypes);

public record SecurityRefDataDto(
    IList<SecurityStatusRefDto> Statuses,
    IList<AssetClassRefDto>     AssetClasses);
