using SecurityApp.Core.Securities.Enums;

namespace SecurityApp.Application.Securities.DTOs;

/// <summary>Identifies a single security for targeted export by IdentifierType + IdentifierValue.</summary>
public class ExportIdentifierRequest
{
    public IdentifierType IdentifierType { get; set; } = IdentifierType.Ticker;
    public string IdentifierValue { get; set; } = string.Empty;
}
