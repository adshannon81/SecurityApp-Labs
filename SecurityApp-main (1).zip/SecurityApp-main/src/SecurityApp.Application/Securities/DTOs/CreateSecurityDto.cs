using System.ComponentModel.DataAnnotations;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Ratings.Enums;

namespace SecurityApp.Application.Securities.DTOs;

/// <summary>
/// DTO for creating a new security
/// </summary>
public class CreateSecurityDto
{
    public IdentifierType IdentifierType { get; set; }

    [Required(ErrorMessage = "IdentifierValue is required.")]
    [StringLength(100, MinimumLength = 1, ErrorMessage = "IdentifierValue must be between 1 and 100 characters.")]
    public string IdentifierValue { get; set; } = string.Empty;

    public SecurityType Type { get; set; }

    [Required(ErrorMessage = "Name is required.")]
    [StringLength(255, MinimumLength = 1, ErrorMessage = "Name must be between 1 and 255 characters.")]
    public string Name { get; set; } = string.Empty;

    public string? Description { get; set; }

    /// <summary>FK to the normalized issuer master.</summary>
    public Guid? IssuerId { get; set; }

    /// <summary>ISO 4217 currency code (FK to currency reference table), e.g. USD, EUR, GBP.</summary>
    [StringLength(10, MinimumLength = 3, ErrorMessage = "CurrencyCode must be a 3-letter ISO 4217 code (e.g. USD).")]
    public string? CurrencyCode { get; set; }

    /// <summary>Whether the security is active. Defaults to true.</summary>
    public bool IsActive { get; set; } = true;

    // ── New classification + status ───────────────────────────────────────────
    [Required(ErrorMessage = "AssetClassCode is required.")]
    [StringLength(32, MinimumLength = 1)]
    public string AssetClassCode { get; set; } = "OTHER";

    [Required(ErrorMessage = "InstrumentTypeCode is required.")]
    [StringLength(64, MinimumLength = 1)]
    public string InstrumentTypeCode { get; set; } = "Other";

    [StringLength(32)]
    public string StatusCode { get; set; } = "ACTIVE";

    public SecurityAttributeDto?            Attributes            { get; set; }
    public SecurityLoanAttributeDto?         LoanAttributes        { get; set; }
    public SecurityDerivativeAttributeDto?   DerivativeAttributes  { get; set; }
    public SecuritySecuritizedAttributeDto?  SecuritizedAttributes { get; set; }
    public List<CreateSecurityIdentifierDto>? Identifiers           { get; set; }
    public List<SecurityAttributeKvDto>?      Kv                    { get; set; }
    public List<CreateCreditRatingDto>?        Ratings               { get; set; }
}
