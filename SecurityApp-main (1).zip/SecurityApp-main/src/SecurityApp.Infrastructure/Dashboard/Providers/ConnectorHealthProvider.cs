using SecurityApp.Core.Dashboard;
using SecurityApp.Core.Shared.Interfaces;

namespace SecurityApp.Infrastructure.Dashboard.Providers;

/// <summary>
/// Widget: connector-health
/// Returns health status for all registered data connectors.
/// </summary>
public sealed class ConnectorHealthProvider(IDataProviderService dataProvider)
    : IDashboardWidgetProvider
{
    public string WidgetId => "connector-health";

    public async Task<object> GetDataAsync(CancellationToken ct = default)
    {
        var connectors = await dataProvider.GetAllConnectorHealthAsync(ct);
        return connectors
            .Select(c => new { name = c.Name, healthy = c.IsHealthy, message = c.Message })
            .ToList();
    }
}
