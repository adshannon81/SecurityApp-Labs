using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SecurityApp.Core.AppAuthorization;

namespace SecurityApp.Infrastructure.AppAuthorization.Persistence.Configurations;

public class AppResourceRuleConfiguration : IEntityTypeConfiguration<AppResourceRule>
{
    public void Configure(EntityTypeBuilder<AppResourceRule> builder)
    {
        builder.ToTable("app_resource_rule");
        builder.HasKey(r => r.Id);

        // ─── BaseEntity ──────────────────────────────────────────────────────
        builder.Property(r => r.CreatedAt).IsRequired();
        builder.Property(r => r.LastModifiedAt);

        // ─── TemporalEntity ──────────────────────────────────────────────────
        builder.Property(r => r.ValidFrom).IsRequired();
        builder.Property(r => r.ValidTo).IsRequired();
        builder.Property(r => r.SystemFrom).IsRequired();
        builder.Property(r => r.SystemTo).IsRequired();
        builder.Property(r => r.IsCurrent).IsRequired();
        builder.Property(r => r.IsDeleted).IsRequired();
        builder.Property(r => r.CreatedBy).HasMaxLength(255);
        builder.Property(r => r.LastModifiedBy).HasMaxLength(255);

        // ─── Domain ──────────────────────────────────────────────────────────
        builder.Property(r => r.AppResourceId).IsRequired();
        builder.Property(r => r.PermissionDefinitionId).IsRequired();
        builder.Property(r => r.VisibilityState).HasConversion<string>().HasMaxLength(20).IsRequired();

        builder.HasOne(r => r.Permission)
            .WithMany()
            .HasForeignKey(r => r.PermissionDefinitionId)
            .OnDelete(DeleteBehavior.Restrict);
        builder.Property(r => r.ExecutionState).HasConversion<string>().HasMaxLength(20).IsRequired();
        builder.Property(r => r.Priority).IsRequired();
        builder.Property(r => r.IsActive).IsRequired();
        builder.Property(r => r.EffectiveFrom);
        builder.Property(r => r.EffectiveTo);

        builder.HasIndex(r => new { r.AppResourceId, r.PermissionDefinitionId })
            .IsUnique()
            .HasDatabaseName("uq_app_resource_rule_resource_permission");

        builder.HasIndex(r => r.AppResourceId)
            .HasDatabaseName("ix_app_resource_rule_resource_id");

        builder.HasIndex(r => r.IsCurrent)
            .HasDatabaseName("ix_app_resource_rule_is_current");

        builder.HasIndex(r => r.IsDeleted)
            .HasDatabaseName("ix_app_resource_rule_is_deleted");

        builder.HasIndex(r => new { r.ValidFrom, r.ValidTo })
            .HasDatabaseName("ix_app_resource_rule_valid_time");
    }
}
