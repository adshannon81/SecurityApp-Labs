using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SecurityApp.Core.AppAuthorization;

namespace SecurityApp.Infrastructure.AppAuthorization.Persistence.Configurations;

public class AppResourceGroupConfiguration : IEntityTypeConfiguration<AppResourceGroup>
{
    public void Configure(EntityTypeBuilder<AppResourceGroup> builder)
    {
        builder.ToTable("app_resource_group");
        builder.HasKey(g => g.Id);

        // ─── BaseEntity ──────────────────────────────────────────────────────
        builder.Property(g => g.CreatedAt).IsRequired();
        builder.Property(g => g.LastModifiedAt);
        builder.Property(g => g.CreatedBy).HasMaxLength(255);
        builder.Property(g => g.LastModifiedBy).HasMaxLength(255);

        // ─── TemporalEntity ──────────────────────────────────────────────────
        builder.Property(g => g.ValidFrom).IsRequired();
        builder.Property(g => g.ValidTo).IsRequired();
        builder.Property(g => g.SystemFrom).IsRequired();
        builder.Property(g => g.SystemTo).IsRequired();
        builder.Property(g => g.IsCurrent).IsRequired();
        builder.Property(g => g.IsDeleted).IsRequired();

        // ─── Domain ──────────────────────────────────────────────────────────
        builder.Property(g => g.GroupKey).HasMaxLength(200).IsRequired();
        builder.Property(g => g.DisplayName).HasMaxLength(200).IsRequired();
        builder.Property(g => g.Description).HasMaxLength(1000);
        builder.Property(g => g.IconName).HasMaxLength(100);
        builder.Property(g => g.SortOrder).IsRequired();
        builder.Property(g => g.IsActive).IsRequired();

        builder.HasIndex(g => g.GroupKey)
               .HasDatabaseName("uq_app_resource_group_key")
               .IsUnique()
               .HasFilter("is_current = true AND is_deleted = false");

        builder.HasIndex(g => g.IsCurrent).HasDatabaseName("ix_arg_is_current");
    }
}
