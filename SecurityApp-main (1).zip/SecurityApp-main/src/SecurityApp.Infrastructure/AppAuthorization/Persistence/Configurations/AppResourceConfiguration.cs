using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using SecurityApp.Core.AppAuthorization;
using SecurityApp.Core.AppAuthorization.Enums;

namespace SecurityApp.Infrastructure.AppAuthorization.Persistence.Configurations;

public class AppResourceConfiguration : IEntityTypeConfiguration<AppResource>
{
    // The DB stores UPPER_SNAKE_CASE (e.g. "MENU_ITEM", "ALLOW", "NOT_APPLICABLE").
    // EF Core's default HasConversion<string>() uses the enum member name (PascalCase)
    // which violates the DB check constraints.  Use explicit converters for all three enums.
    private static readonly ValueConverter<AppResourceType, string> ResourceTypeConverter = new(
        v => ResourceTypeToDb(v),
        s => ResourceTypeFromDb(s));

    private static string ResourceTypeToDb(AppResourceType v)
    {
        if (v == AppResourceType.MenuGroup) return "MENU_GROUP";
        if (v == AppResourceType.MenuItem)  return "MENU_ITEM";
        return v.ToString().ToUpperInvariant();
    }

    private static AppResourceType ResourceTypeFromDb(string s)
    {
        if (s == "MENU_GROUP") return AppResourceType.MenuGroup;
        if (s == "MENU_ITEM")  return AppResourceType.MenuItem;
        return Enum.Parse<AppResourceType>(s, ignoreCase: true);
    }

    private static readonly ValueConverter<AppExecutionState, string> ExecutionStateConverter = new(
        v => v == AppExecutionState.NotApplicable ? "NOT_APPLICABLE" : v.ToString().ToUpperInvariant(),
        s => s == "NOT_APPLICABLE" ? AppExecutionState.NotApplicable : Enum.Parse<AppExecutionState>(s, ignoreCase: true));

    private static readonly ValueConverter<VisibilityState, string> VisibilityStateConverter = new(
        v => v == VisibilityState.NotApplicable ? "NOT_APPLICABLE" : v.ToString().ToUpperInvariant(),
        s => s == "NOT_APPLICABLE" ? VisibilityState.NotApplicable : Enum.Parse<VisibilityState>(s, ignoreCase: true));

    public void Configure(EntityTypeBuilder<AppResource> builder)
    {
        builder.ToTable("app_resource");
        builder.HasKey(r => r.Id);

        // ─── BaseEntity ──────────────────────────────────────────────────────
        builder.Property(r => r.CreatedAt).IsRequired();
        builder.Property(r => r.LastModifiedAt);

        // ─── TemporalEntity ──────────────────────────────────────────────────
        builder.Property(r => r.ValidFrom).IsRequired();
        builder.Property(r => r.ValidTo).IsRequired();
        builder.Property(r => r.SystemFrom).IsRequired();
        builder.Property(r => r.SystemTo).IsRequired();
        builder.Property(r => r.IsCurrent).IsRequired();
        builder.Property(r => r.IsDeleted).IsRequired();
        builder.Property(r => r.CreatedBy).HasMaxLength(255);
        builder.Property(r => r.LastModifiedBy).HasMaxLength(255);

        // ─── Domain ──────────────────────────────────────────────────────────
        builder.Property(r => r.ResourceType).HasConversion(ResourceTypeConverter).HasMaxLength(30).IsRequired();
        builder.Property(r => r.ResourceKey).HasMaxLength(300).IsRequired();
        builder.Property(r => r.ParentAppResourceId);
        builder.Property(r => r.DisplayName).HasMaxLength(200).IsRequired();
        builder.Property(r => r.RoutePath).HasMaxLength(300);
        builder.Property(r => r.IconName).HasMaxLength(100);
        builder.Property(r => r.Description).HasMaxLength(1000);
        builder.Property(r => r.DefaultVisibilityState).HasConversion(VisibilityStateConverter).HasMaxLength(20).IsRequired();
        builder.Property(r => r.DefaultExecutionState).HasConversion(ExecutionStateConverter).HasMaxLength(20).IsRequired();
        builder.Property(r => r.IsSecuritySensitive).IsRequired();
        builder.Property(r => r.SortOrder).IsRequired();
        builder.Property(r => r.IsActive).IsRequired();

        builder.HasIndex(r => r.ResourceKey)
            .IsUnique()
            .HasFilter("is_current = true")
            .HasDatabaseName("uq_app_resource_key");

        // Self-referencing parent-child
        builder.HasOne(r => r.Parent)
            .WithMany(r => r.Children)
            .HasForeignKey(r => r.ParentAppResourceId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasMany(r => r.Rules)
            .WithOne(r => r.Resource)
            .HasForeignKey(r => r.AppResourceId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
