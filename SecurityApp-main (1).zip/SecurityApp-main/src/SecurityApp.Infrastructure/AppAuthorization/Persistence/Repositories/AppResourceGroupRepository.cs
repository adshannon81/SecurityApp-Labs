using Microsoft.EntityFrameworkCore;
using SecurityApp.Core.AppAuthorization;
using SecurityApp.Infrastructure.Persistence;

namespace SecurityApp.Infrastructure.AppAuthorization.Persistence.Repositories;

public class AppResourceGroupRepository(ApplicationDbContext db) : IAppResourceGroupRepository
{
    public async Task<IReadOnlyList<AppResourceGroup>> GetAllAsync(CancellationToken ct = default)
        => await db.AppResourceGroups
            .Where(g => g.IsCurrent && !g.IsDeleted)
            .OrderBy(g => g.SortOrder)
            .ThenBy(g => g.DisplayName)
            .ToListAsync(ct);

    public async Task<AppResourceGroup?> GetByIdAsync(Guid id, CancellationToken ct = default)
        => await db.AppResourceGroups
            .FirstOrDefaultAsync(g => g.Id == id && g.IsCurrent && !g.IsDeleted, ct);

    public async Task<AppResourceGroup> CreateAsync(AppResourceGroup group, CancellationToken ct = default)
    {
        db.AppResourceGroups.Add(group);
        await db.SaveChangesAsync(ct);
        return group;
    }

    public async Task<AppResourceGroup> UpdateAsync(AppResourceGroup group, CancellationToken ct = default)
    {
        var existing = await db.AppResourceGroups
            .FirstOrDefaultAsync(g => g.Id == group.Id && g.IsCurrent && !g.IsDeleted, ct)
            ?? throw new KeyNotFoundException($"AppResourceGroup {group.Id} not found.");

        existing.GroupKey    = group.GroupKey;
        existing.DisplayName = group.DisplayName;
        existing.Description = group.Description;
        existing.IconName    = group.IconName;
        existing.SortOrder   = group.SortOrder;
        existing.IsActive    = group.IsActive;
        existing.LastModifiedBy = group.LastModifiedBy;

        await db.SaveChangesAsync(ct);
        return existing;
    }

    public async Task DeleteAsync(Guid id, CancellationToken ct = default)
    {
        var existing = await db.AppResourceGroups
            .FirstOrDefaultAsync(g => g.Id == id && g.IsCurrent && !g.IsDeleted, ct)
            ?? throw new KeyNotFoundException($"AppResourceGroup {id} not found.");

        existing.IsCurrent  = false;
        existing.IsDeleted  = true;
        await db.SaveChangesAsync(ct);
    }
}
