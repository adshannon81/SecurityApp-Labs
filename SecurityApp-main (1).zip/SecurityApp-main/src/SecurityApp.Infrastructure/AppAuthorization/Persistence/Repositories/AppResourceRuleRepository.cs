using Microsoft.EntityFrameworkCore;
using SecurityApp.Core.AppAuthorization;
using SecurityApp.Infrastructure.Persistence;

namespace SecurityApp.Infrastructure.AppAuthorization.Persistence.Repositories;

public class AppResourceRuleRepository(ApplicationDbContext db) : IAppResourceRuleRepository
{
    public async Task<IReadOnlyList<AppResourceRule>> GetAllAsync(CancellationToken ct = default)
        => await db.AppResourceRules
            .Include(r => r.Resource)
            .Include(r => r.Permission)
            .Where(r => r.IsCurrent && !r.IsDeleted)
            .OrderBy(r => r.Resource!.ResourceKey)
            .ThenByDescending(r => r.Priority)
            .ToListAsync(ct);

    public async Task<IReadOnlyList<AppResourceRule>> GetByResourceAsync(Guid resourceId, CancellationToken ct = default)
        => await db.AppResourceRules
            .Include(r => r.Permission)
            .Where(r => r.AppResourceId == resourceId && r.IsCurrent && !r.IsDeleted)
            .OrderByDescending(r => r.Priority)
            .ToListAsync(ct);

    public async Task<AppResourceRule?> GetByIdAsync(Guid id, CancellationToken ct = default)
        => await db.AppResourceRules
            .Include(r => r.Resource)
            .FirstOrDefaultAsync(r => r.Id == id && r.IsCurrent && !r.IsDeleted, ct);

    public async Task<AppResourceRule> CreateAsync(AppResourceRule rule, CancellationToken ct = default)
    {
        db.AppResourceRules.Add(rule);
        await db.SaveChangesAsync(ct);
        return rule;
    }

    public async Task<AppResourceRule> UpdateAsync(AppResourceRule rule, CancellationToken ct = default)
    {
        db.AppResourceRules.Update(rule);
        await db.SaveChangesAsync(ct);
        return rule;
    }

    public async Task DeleteAsync(Guid id, CancellationToken ct = default)
    {
        var rule = await db.AppResourceRules
            .FirstOrDefaultAsync(r => r.Id == id && r.IsCurrent && !r.IsDeleted, ct)
            ?? throw new KeyNotFoundException($"AppResourceRule {id} not found.");
        rule.IsDeleted = true;
        rule.IsCurrent = false;
        rule.LastModifiedAt = DateTime.UtcNow;
        await db.SaveChangesAsync(ct);
    }
}
