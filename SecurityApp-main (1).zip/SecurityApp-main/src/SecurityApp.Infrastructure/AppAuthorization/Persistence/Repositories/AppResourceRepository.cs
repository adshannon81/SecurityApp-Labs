using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using SecurityApp.Core.AppAuthorization;
using SecurityApp.Core.AppAuthorization.Enums;
using SecurityApp.Core.Grpc;
using SecurityApp.Infrastructure.Persistence;

namespace SecurityApp.Infrastructure.AppAuthorization.Persistence.Repositories;

public class AppResourceRepository(
    ApplicationDbContext db,
    IHttpContextAccessor httpContextAccessor,
    IGrpcEventPublisher grpcPublisher) : IAppResourceRepository
{
    private string? CallerName =>
        httpContextAccessor.HttpContext?.User?.Identity?.Name;
    public async Task<IReadOnlyList<AppResource>> GetAllAsync(CancellationToken ct = default)
        => await db.AppResources
            .Include(r => r.Rules.Where(ru => ru.IsCurrent && !ru.IsDeleted && ru.IsActive))
                .ThenInclude(ru => ru.Permission)
            .Where(r => r.IsCurrent && !r.IsDeleted)
            .OrderBy(r => r.SortOrder)
            .ThenBy(r => r.DisplayName)
            .ToListAsync(ct);

    public async Task<AppResource?> GetByIdAsync(Guid id, CancellationToken ct = default)
        => await db.AppResources
            .Include(r => r.Parent)
            .FirstOrDefaultAsync(r => r.Id == id && r.IsCurrent && !r.IsDeleted, ct);

    public async Task<AppResource?> GetByKeyAsync(string resourceKey, CancellationToken ct = default)
        => await db.AppResources
            .Include(r => r.Rules.Where(ru => ru.IsCurrent && !ru.IsDeleted && ru.IsActive))
                .ThenInclude(ru => ru.Permission)
            .FirstOrDefaultAsync(r => r.ResourceKey == resourceKey && r.IsCurrent && !r.IsDeleted, ct);

    public async Task<AppResource> CreateAsync(AppResource resource, CancellationToken ct = default)
    {
        db.AppResources.Add(resource);
        await db.SaveChangesAsync(ct);
        await grpcPublisher.PublishNavConfigChangedAsync(
            new NavConfigChangedPayload(CallerName ?? "system", DateTime.UtcNow), ct);
        return resource;
    }

    public async Task<AppResource> UpdateAsync(AppResource resource, CancellationToken ct = default)
    {
        var existing = await db.AppResources
            .FirstOrDefaultAsync(r => r.Id == resource.Id && r.IsCurrent && !r.IsDeleted, ct)
            ?? throw new KeyNotFoundException($"AppResource {resource.Id} not found.");

        existing.ResourceType           = resource.ResourceType;
        existing.ResourceKey            = resource.ResourceKey;
        existing.ParentAppResourceId    = resource.ParentAppResourceId;
        existing.DisplayName            = resource.DisplayName;
        existing.RoutePath              = resource.RoutePath;
        existing.IconName               = resource.IconName;
        existing.Description            = resource.Description;
        existing.DefaultVisibilityState = resource.DefaultVisibilityState;
        existing.DefaultExecutionState  = resource.DefaultExecutionState;
        existing.IsSecuritySensitive    = resource.IsSecuritySensitive;
        existing.SortOrder              = resource.SortOrder;
        existing.IsActive               = resource.IsActive;
        existing.LastModifiedAt              = DateTime.UtcNow;
        existing.LastModifiedBy             = CallerName;

        await db.SaveChangesAsync(ct);
        await grpcPublisher.PublishNavConfigChangedAsync(
            new NavConfigChangedPayload(CallerName ?? "system", DateTime.UtcNow), ct);
        return existing;
    }

    public async Task DeleteAsync(Guid id, CancellationToken ct = default)
    {
        var resource = await db.AppResources
            .FirstOrDefaultAsync(r => r.Id == id && r.IsCurrent && !r.IsDeleted, ct)
            ?? throw new KeyNotFoundException($"AppResource {id} not found.");
        resource.IsDeleted = true;
        resource.IsCurrent = false;
        resource.LastModifiedAt = DateTime.UtcNow;
        resource.LastModifiedBy = CallerName;
        await db.SaveChangesAsync(ct);
        await grpcPublisher.PublishNavConfigChangedAsync(
            new NavConfigChangedPayload(CallerName ?? "system", DateTime.UtcNow), ct);
    }

    public async Task<IReadOnlyList<AppResource>> GetAllWithChildrenAsync(CancellationToken ct = default)
    {
        return await db.AppResources
            .Where(r => r.IsCurrent && !r.IsDeleted)
            .Include(r => r.Rules)
                .ThenInclude(rule => rule.Permission)
            .Include(r => r.Children.Where(c => c.IsCurrent && !c.IsDeleted))
                .ThenInclude(c => c.Rules)
                    .ThenInclude(rule => rule.Permission)
            .Include(r => r.Children.Where(c => c.IsCurrent && !c.IsDeleted))
                .ThenInclude(c => c.Children.Where(cc => cc.IsCurrent && !cc.IsDeleted))
                    .ThenInclude(cc => cc.Rules)
                        .ThenInclude(rule => rule.Permission)
            .AsNoTracking()
            .ToListAsync(ct);
    }
}
