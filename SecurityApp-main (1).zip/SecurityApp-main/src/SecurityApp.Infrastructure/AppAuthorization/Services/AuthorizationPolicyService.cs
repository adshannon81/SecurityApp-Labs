using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using SecurityApp.Core.AppAuthorization;
using SecurityApp.Core.AppAuthorization.Enums;
using SecurityApp.Core.FieldVisibility;
using SecurityApp.Core.FieldVisibility.Enums;
using SecurityApp.Infrastructure.Persistence;
using FieldVisibilityValue = SecurityApp.Core.FieldVisibility.Enums.FieldVisibility;

namespace SecurityApp.Infrastructure.AppAuthorization.Services;

/// <summary>
/// Central authorization policy service — evaluates both field visibility rules
/// and app resource rules against the current user's permissions.
///
/// Decision rules:
///   1. No matching field rule → use field default visibility.
///   2. No matching app resource rule → use resource defaults.
///   3. Security-sensitive resources default to HIDDEN / DENY.
///   4. Multiple matching rules → highest priority wins.
///   5. Empty resource groups are excluded from the visible menu.
/// </summary>
public class AuthorizationPolicyService(ApplicationDbContext db) : IAuthorizationPolicyService
{
    // ─── Field visibility ─────────────────────────────────────────────────────

    public FieldVisibilityResult ResolveFieldVisibility(
        ClaimsPrincipal user, string entityType, string fieldName)
    {
        var permissions = GetPermissions(user);

        var field = db.FieldVisibilityFields
            .Include(f => f.Entity)
            .Include(f => f.Rules.Where(r => r.IsCurrent && !r.IsDeleted && r.IsActive))
                .ThenInclude(r => r.PermissionDefinition)
            .AsNoTracking()
            .Where(f => f.IsCurrent && !f.IsDeleted && f.IsActive
                        && f.Entity!.EntityType == entityType
                        && f.FieldName == fieldName)
            .FirstOrDefault();

        if (field is null)
            return new FieldVisibilityResult("HIDDEN", "NONE");

        var match = field.Rules
            .Where(r => IsEffective(r.EffectiveFrom, r.EffectiveTo))
            .OrderByDescending(r => r.Priority)
            .FirstOrDefault(r => permissions.Contains(r.PermissionDefinition.PermissionKey, StringComparer.OrdinalIgnoreCase));

        if (match is null)
            return new FieldVisibilityResult(field.DefaultVisibilityState, "NONE");

        return new FieldVisibilityResult(
            match.VisibilityState,
            match.ObfuscationType.ToString().ToUpperInvariant());
    }

    // ─── App resource policy ──────────────────────────────────────────────────

    public ResourcePolicyResult ResolveResourcePolicy(ClaimsPrincipal user, string resourceKey)
    {
        var permissions = GetPermissions(user);

        var resource = db.AppResources
            .Include(r => r.Rules.Where(r => r.IsCurrent && !r.IsDeleted && r.IsActive))
                .ThenInclude(r => r.Permission)
            .AsNoTracking()
            .Where(r => r.ResourceKey == resourceKey && r.IsCurrent && !r.IsDeleted)
            .FirstOrDefault();

        if (resource is null)
            return new ResourcePolicyResult("HIDDEN", "DENY");

        var match = resource.Rules
            .Where(r => IsEffective(r.EffectiveFrom, r.EffectiveTo))
            .OrderByDescending(r => r.Priority)
            .FirstOrDefault(r => r.Permission != null && permissions.Contains(r.Permission.PermissionKey, StringComparer.OrdinalIgnoreCase));

        return match is null
            ? new ResourcePolicyResult(
                resource.DefaultVisibilityState.ToString().ToUpperInvariant(),
                resource.DefaultExecutionState.ToString().ToUpperInvariant())
            : new ResourcePolicyResult(
                match.VisibilityState.ToString().ToUpperInvariant(),
                match.ExecutionState.ToString().ToUpperInvariant());
    }

    public bool CanExecuteResource(ClaimsPrincipal user, string resourceKey)
    {
        var policy = ResolveResourcePolicy(user, resourceKey);
        return policy.ExecutionState == "ALLOW";
    }

    // ─── Visible menu tree ────────────────────────────────────────────────────

    public IReadOnlyList<MenuNodeDto> GetVisibleMenu(ClaimsPrincipal user)
    {
        var permissions = GetPermissions(user);

        var allResources = db.AppResources
            .Include(r => r.Rules.Where(r => r.IsCurrent && !r.IsDeleted && r.IsActive))
                .ThenInclude(r => r.Permission)
            .Where(r => r.IsCurrent && !r.IsDeleted && r.IsActive
                        && (r.ResourceType == AppResourceType.MenuGroup
                            || r.ResourceType == AppResourceType.MenuItem))
            .OrderBy(r => r.SortOrder)
            .AsNoTracking()
            .ToList();

        var topLevelGroups = allResources
            .Where(r => r.ResourceType == AppResourceType.MenuGroup && r.ParentAppResourceId == null)
            .ToList();

        var result = new List<MenuNodeDto>();

        foreach (var group in topLevelGroups)
        {
            var groupChildren = allResources
                .Where(r => r.ParentAppResourceId == group.Id)
                .ToList();

            var items = BuildMenuItems(groupChildren, allResources, permissions);

            if (items.Count == 0) continue; // rule 6: no visible items → skip group

            result.Add(new MenuNodeDto(
                group.Id,
                group.ResourceKey,
                group.DisplayName,
                group.Description,
                group.IconName,
                group.SortOrder,
                items));
        }

        return result;
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private static IReadOnlyList<MenuItemNodeDto> BuildMenuItems(
        IEnumerable<AppResource> siblings,
        IReadOnlyList<AppResource> allResources,
        IReadOnlyList<string> permissions)
    {
        var result = new List<MenuItemNodeDto>();

        foreach (var resource in siblings)
        {
            var effectiveVisibility = ResolveVisibility(resource, permissions);
            if (effectiveVisibility == "HIDDEN") continue;

            var children = allResources
                .Where(r => r.ParentAppResourceId == resource.Id)
                .OrderBy(r => r.SortOrder)
                .ToList();

            var childNodes = BuildMenuItems(children, allResources, permissions);

            // If this is a MENU_GROUP type item with no visible children, skip it
            if (resource.ResourceType == AppResourceType.MenuGroup && childNodes.Count == 0)
                continue;

            result.Add(new MenuItemNodeDto(
                resource.Id,
                resource.ResourceKey,
                resource.DisplayName,
                resource.RoutePath,
                resource.IconName,
                resource.SortOrder,
                childNodes));
        }

        return result;
    }

    private static string ResolveVisibility(AppResource resource, IReadOnlyList<string> permissions)
    {
        var match = resource.Rules
            .Where(r => IsEffective(r.EffectiveFrom, r.EffectiveTo))
            .OrderByDescending(r => r.Priority)
            .FirstOrDefault(r => r.Permission != null && permissions.Contains(r.Permission.PermissionKey, StringComparer.OrdinalIgnoreCase));

        return match is null
            ? resource.DefaultVisibilityState.ToString().ToUpperInvariant()
            : match.VisibilityState.ToString().ToUpperInvariant();
    }

    private static bool IsEffective(DateTime? from, DateTime? to)
    {
        var now = DateTime.UtcNow;
        return (from is null || from <= now) && (to is null || to >= now);
    }

    private static IReadOnlyList<string> GetPermissions(ClaimsPrincipal user)
        => user.Claims
            .Where(c => c.Type == "permissions" || c.Type == "permission")
            .Select(c => c.Value)
            .ToList();
}
