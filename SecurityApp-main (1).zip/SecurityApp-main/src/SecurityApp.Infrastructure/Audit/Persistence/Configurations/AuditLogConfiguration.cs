﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SecurityApp.Core.Audit.Entities;

namespace SecurityApp.Infrastructure.Audit.Persistence.Configurations;

public class AuditLogConfiguration : IEntityTypeConfiguration<AuditLog>
{
    public void Configure(EntityTypeBuilder<AuditLog> builder)
    {
        builder.ToTable("audit_log");

        builder.HasKey(al => al.Id);

        // --- BaseEntity -----------------------------------------------------
        builder.Property(al => al.CreatedAt).IsRequired();
        // AuditLogs are append-only — no updated-at / created-by / modified-by columns exist
        builder.Ignore(al => al.LastModifiedAt);
        builder.Ignore(al => al.CreatedBy);
        builder.Ignore(al => al.LastModifiedBy);

        // --- AuditLog-specific -----------------------------------------------
        builder.Property(al => al.EntityType)
            .HasMaxLength(50)
            .IsRequired();

        builder.Property(al => al.Action)
            .HasConversion<string>()
            .HasMaxLength(50)
            .IsRequired();

        builder.Property(al => al.UserName)
            .HasMaxLength(255);

        builder.Property(al => al.Details)
            .HasColumnType("text");

        builder.Property(al => al.IpAddress)
            .HasMaxLength(45);

        builder.Property(al => al.BeforeState)
            .HasColumnName("before_state")
            .HasColumnType("text");

        builder.Property(al => al.AfterState)
            .HasColumnName("after_state")
            .HasColumnType("text");

        builder.Property(al => al.ChangedFields)
            .HasColumnName("changed_fields")
            .HasColumnType("text");

        // CorrelationId / CausationId are UNIQUEIDENTIFIER — no max-length constraint
        builder.Property(al => al.CorrelationId)
            .HasColumnName("correlation_id");

        builder.Property(al => al.CausationId)
            .HasColumnName("causation_id");

        builder.Property(al => al.Source)
            .HasMaxLength(50)
            .IsRequired()
            .HasDefaultValue("Http");

        // Indexes for efficient querying
        builder.HasIndex(al => al.CreatedAt)
            .HasDatabaseName("ix_audit_logs_created_at");

        builder.HasIndex(al => al.UserId)
            .HasDatabaseName("ix_audit_logs_user_id");

        builder.HasIndex(al => new { al.EntityType, al.EntityId })
            .HasDatabaseName("ix_audit_logs_entity_type_entity_id");

        builder.HasIndex(al => al.CorrelationId)
            .HasDatabaseName("ix_audit_log_correlation_id")
            .HasFilter("correlation_id IS NOT NULL");
    }
}
