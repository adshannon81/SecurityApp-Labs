# apply-permissions.ps1
# Applies permission client roles, composite role mappings, and the
# permissions-mapper protocol mapper to an existing Keycloak realm via
# the Admin REST API.  Safe to run multiple times — everything is idempotent.
#
# Usage:
#   .\keycloak\apply-permissions.ps1 -AdminPassword "YourAdminPassword"

param(
    [string] $KeycloakUrl   = "http://localhost:8180/auth",
    [string] $Realm         = "securityapp",
    [string] $AdminUser     = "admin",
    [string] $ApiClientId   = "securityapp-api",
    [string] $UiClientId    = "securityapp-ui",
    [Parameter(Mandatory)]
    [string] $AdminPassword
)

$ErrorActionPreference = "Stop"

# ── Helpers ──────────────────────────────────────────────────────────────────
function Invoke-KC {
    param([string]$Method, [string]$Path, $Body)
    $uri = "$KeycloakUrl$Path"
    $params = @{ Method = $Method; Uri = $uri; Headers = $script:Headers }
    if ($Body) {
        $params.Body        = $Body | ConvertTo-Json -Depth 10
        $params.ContentType = "application/json"
    }
    try {
        Invoke-RestMethod @params
    } catch {
        # 409 = already exists — treat as success
        if ($_.Exception.Response.StatusCode.value__ -eq 409) { return }
        throw
    }
}

# ── 1. Get admin token ────────────────────────────────────────────────────────
Write-Host "Authenticating..."
$tokenResp = Invoke-RestMethod -Method Post `
    -Uri "$KeycloakUrl/realms/master/protocol/openid-connect/token" `
    -ContentType "application/x-www-form-urlencoded" `
    -Body @{
        grant_type = "password"
        client_id  = "admin-cli"
        username   = $AdminUser
        password   = $AdminPassword
    }

$script:Headers = @{ Authorization = "Bearer $($tokenResp.access_token)" }
Write-Host "Authenticated."

# ── 2. Resolve client UUIDs ───────────────────────────────────────────────────
$apiClient = (Invoke-KC GET "/admin/realms/$Realm/clients?clientId=$ApiClientId") | Where-Object { $_.clientId -eq $ApiClientId }
$uiClient  = (Invoke-KC GET "/admin/realms/$Realm/clients?clientId=$UiClientId")  | Where-Object { $_.clientId -eq $UiClientId }

if (-not $apiClient) { throw "Client '$ApiClientId' not found in realm '$Realm'" }
if (-not $uiClient)  { throw "Client '$UiClientId' not found in realm '$Realm'" }

$apiUUID = $apiClient.id
$uiUUID  = $uiClient.id
Write-Host "Resolved $ApiClientId => $apiUUID"
Write-Host "Resolved $UiClientId  => $uiUUID"

# ── 3. Create client roles on securityapp-api ─────────────────────────────────
$clientRoles = @(
    @{ name = "securities:read";   description = "View securities" },
    @{ name = "securities:write";  description = "Create and update securities" },
    @{ name = "securities:delete"; description = "Delete securities" },
    @{ name = "ratings:read";      description = "View ratings and audit trail" },
    @{ name = "ratings:write";     description = "Trigger rating calculations" },
    @{ name = "ratings:manage";    description = "Manage rating models, rules, and scales" },
    @{ name = "pricing:read";      description = "View prices and pricing rules" },
    @{ name = "pricing:write";     description = "Import prices and run derivations" },
    @{ name = "pricing:manage";    description = "Create, update, and delete pricing rules" },
    @{ name = "imports:read";      description = "View import requests and profiles" },
    @{ name = "imports:run";       description = "Trigger imports" },
    @{ name = "imports:manage";    description = "Manage import profiles and retry failed imports" },
    @{ name = "exports:run";       description = "Export securities data" },
    @{ name = "workflows:read";    description = "View workflow instances" },
    @{ name = "workflows:use";     description = "Submit workflow step decisions" },
    @{ name = "workflows:manage";  description = "Create, cancel, and delete workflow definitions" },
    @{ name = "jobs:read";         description = "View job status and history" },
    @{ name = "jobs:manage";       description = "Trigger, pause, resume, and schedule jobs" },
    @{ name = "audit:read";        description = "View audit logs" },
    @{ name = "system:manage";     description = "Manage plugins and system settings" },
    @{ name = "issuers:read";      description = "View issuers and their relationships" },
    @{ name = "issuers:write";     description = "Create, update, and delete issuers" },
    @{ name = "vendors:read";              description = "View vendor sources and vendor data" },
    @{ name = "vendors:write";             description = "Create and update vendor sources" },
    @{ name = "dead-letters:read";         description = "View dead letter events" },
    @{ name = "dead-letters:manage";       description = "Replay or discard dead letter events" },
    @{ name = "admin:ui-resources";        description = "Manage app resources and permission matrix" },
    @{ name = "admin:field-visibility";    description = "Manage field visibility rules" },
    @{ name = "admin:manage-permissions";  description = "Manage permission bundles, templates and entity screens" },
    @{ name = "admin:manage-authorization"; description = "Manage authorization settings" },
    @{ name = "admin:super";               description = "Full super-admin access" }
)

Write-Host "`nCreating client roles on $ApiClientId..."
foreach ($role in $clientRoles) {
    Invoke-KC POST "/admin/realms/$Realm/clients/$apiUUID/roles" $role
    Write-Host "  OK: $($role.name)"
}

# Fetch all created roles indexed by name for composite assignment
$allClientRoles = Invoke-KC GET "/admin/realms/$Realm/clients/$apiUUID/roles"
$roleByName     = @{}
foreach ($r in $allClientRoles) { $roleByName[$r.name] = $r }

# ── 4. Wire composite realm roles ─────────────────────────────────────────────
$composites = @{
    "Admin" = @(
        "securities:read","securities:write","securities:delete",
        "ratings:read","ratings:write","ratings:manage",
        "pricing:read","pricing:write","pricing:manage",
        "imports:read","imports:run","imports:manage",
        "exports:run",
        "workflows:read","workflows:use","workflows:manage",
        "jobs:read","jobs:manage",
        "audit:read","system:manage",
        "issuers:read","issuers:write",
        "vendors:read","vendors:write",
        "dead-letters:read","dead-letters:manage",
        "admin:ui-resources","admin:field-visibility",
        "admin:manage-permissions","admin:manage-authorization",
        "admin:super"
    )
    "Contributor" = @(
        "securities:read","securities:write",
        "ratings:read","ratings:write",
        "pricing:read","pricing:write",
        "imports:read","imports:run",
        "exports:run",
        "workflows:read","workflows:use",
        "jobs:read",
        "issuers:read","issuers:write"
    )
    "Viewer" = @(
        "securities:read",
        "ratings:read",
        "pricing:read",
        "imports:read",
        "workflows:read",
        "jobs:read",
        "issuers:read"
    )
}

Write-Host "`nAssigning composite roles..."
foreach ($realmRoleName in $composites.Keys) {
    $roleReps = $composites[$realmRoleName] | ForEach-Object { $roleByName[$_] } | Where-Object { $_ }

    # Make realm role composite if not already
    $realmRole = Invoke-KC GET "/admin/realms/$Realm/roles/$realmRoleName"
    if (-not $realmRole.composite) {
        $realmRole.composite = $true
        Invoke-KC PUT "/admin/realms/$Realm/roles/$realmRoleName" $realmRole
    }

    # Add composites (idempotent — POST to composites adds missing ones)
    Invoke-KC POST "/admin/realms/$Realm/roles/$realmRoleName/composites" $roleReps
    Write-Host "  $realmRoleName => $($roleReps.Count) permissions"
}

# ── 5. Add permissions-mapper to both clients ─────────────────────────────────
$mapper = @{
    name           = "permissions-mapper"
    protocol       = "openid-connect"
    protocolMapper = "oidc-usermodel-client-role-mapper"
    consentRequired = $false
    config = @{
        "multivalued"                              = "true"
        "userinfo.token.claim"                     = "true"
        "id.token.claim"                           = "true"
        "access.token.claim"                       = "true"
        "claim.name"                               = "permissions"
        "jsonType.label"                           = "String"
        "usermodel.clientRoleMapping.clientId"     = $ApiClientId
    }
}

Write-Host "`nAdding permissions-mapper protocol mapper..."
Invoke-KC POST "/admin/realms/$Realm/clients/$apiUUID/protocol-mappers/models" $mapper
Write-Host "  OK: $ApiClientId"
Invoke-KC POST "/admin/realms/$Realm/clients/$uiUUID/protocol-mappers/models" $mapper
Write-Host "  OK: $UiClientId"

# ── 6. Add full-name-mapper to securityapp-api ────────────────────────────────
$fullNameMapper = @{
    name            = "full-name-mapper"
    protocol        = "openid-connect"
    protocolMapper  = "oidc-full-name-mapper"
    consentRequired = $false
    config = @{
        "id.token.claim"     = "true"
        "access.token.claim" = "true"
        "userinfo.token.claim" = "true"
    }
}

Write-Host "`nAdding full-name-mapper to $ApiClientId..."
Invoke-KC POST "/admin/realms/$Realm/clients/$apiUUID/protocol-mappers/models" $fullNameMapper
Write-Host "  OK: full-name-mapper added (name claim will appear in access tokens)"

Write-Host "`nDone. Log out and back in to get a fresh token with the 'permissions' and 'name' claims."
