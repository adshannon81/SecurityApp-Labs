<#import "template.ftl" as layout>

<@layout.registrationLayout
    displayMessage=!messagesPerField.existsError('username','password')
    displayInfo=realm.password && realm.registrationAllowed && !registrationDisabled??; section>

  <#if section = "header">
    ${msg("loginAccountTitle")}

  <#elseif section = "form">
    <#if realm.password>
      <form id="kc-form-login"
            onsubmit="document.getElementById('kc-login').disabled = true; return true;"
            action="${url.loginAction}"
            method="post">

        <#if !usernameHidden??>
          <div class="sa-field">
            <label class="sa-label" for="username">
              <#if !realm.loginWithEmailAllowed>
                ${msg("username")}
              <#elseif !realm.registrationEmailAsUsername>
                ${msg("usernameOrEmail")}
              <#else>
                ${msg("email")}
              </#if>
            </label>
            <div class="sa-input-wrap">
              <svg class="sa-input-icon" viewBox="0 0 20 20" fill="currentColor" width="16" height="16" aria-hidden="true">
                <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/>
              </svg>
              <input tabindex="1"
                     id="username"
                     class="sa-input"
                     name="username"
                     type="text"
                     autocomplete="username"
                     value="${(login.username!'')}"
                     autofocus
                     aria-invalid="<#if messagesPerField.existsError('username','password')>true</#if>" />
            </div>
            <#if messagesPerField.existsError('username','password')>
              <span class="sa-field-error" aria-live="polite">
                ${kcSanitize(messagesPerField.getFirstError('username','password'))?no_esc}
              </span>
            </#if>
          </div>
        </#if>

        <div class="sa-field">
          <label class="sa-label" for="password">${msg("password")}</label>
          <div class="sa-input-wrap">
            <svg class="sa-input-icon" viewBox="0 0 20 20" fill="currentColor" width="16" height="16" aria-hidden="true">
              <path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"/>
            </svg>
            <input tabindex="2"
                   id="password"
                   class="sa-input"
                   name="password"
                   type="password"
                   autocomplete="current-password"
                   aria-invalid="<#if messagesPerField.existsError('username','password')>true</#if>" />
            <button type="button"
                    class="sa-eye"
                    tabindex="-1"
                    aria-label="${msg('showPassword')}"
                    onclick="(function(btn){var i=document.getElementById('password');i.type=i.type==='password'?'text':'password';btn.classList.toggle('sa-eye--on');btn.setAttribute('aria-pressed',i.type==='text');})(this)">
              <svg class="sa-eye__show" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                   stroke-linecap="round" stroke-linejoin="round" width="17" height="17" aria-hidden="true">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                <circle cx="12" cy="12" r="3"/>
              </svg>
              <svg class="sa-eye__hide" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                   stroke-linecap="round" stroke-linejoin="round" width="17" height="17" aria-hidden="true">
                <path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/>
                <line x1="1" y1="1" x2="23" y2="23"/>
              </svg>
            </button>
          </div>
        </div>

        <div class="sa-row">
          <#if realm.rememberMe && !usernameHidden??>
            <label class="sa-checkbox">
              <input tabindex="3" id="rememberMe" name="rememberMe" type="checkbox"
                     <#if login.rememberMe??>checked</#if> />
              <span class="sa-checkbox__box"></span>
              <span>${msg("rememberMe")}</span>
            </label>
          </#if>
          <#if realm.resetPasswordAllowed>
            <a tabindex="6" href="${url.loginResetCredentialsUrl}" class="sa-link sa-link--subtle">
              ${msg("doForgotPassword")}
            </a>
          </#if>
        </div>

        <input type="hidden" id="id-hidden-input" name="credentialId"
               <#if auth.selectedCredential?has_content>value="${auth.selectedCredential}"</#if> />

        <button tabindex="4" id="kc-login" class="sa-btn" name="login" type="submit">
          <span>${msg("doLogIn")}</span>
          <svg viewBox="0 0 20 20" fill="currentColor" width="17" height="17" aria-hidden="true">
            <path fill-rule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 102 0V4a1 1 0 00-1-1zm10.293 9.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L14.586 9H7a1 1 0 100 2h7.586l-1.293 1.293z" clip-rule="evenodd"/>
          </svg>
        </button>

      </form>
    </#if>

    <#if realm.password && social?? && social.providers?? && social.providers?has_content>
      <div class="sa-divider"><span>${msg("identity-provider-login-label")}</span></div>
      <ul class="sa-social" id="kc-social-providers">
        <#list social.providers as p>
          <li>
            <a id="social-${p.alias}" class="sa-social__btn" href="${p.loginUrl}" rel="nofollow noreferrer">
              <#if p.iconClasses?has_content>
                <i class="${p.iconClasses}" aria-hidden="true"></i>
              </#if>
              <span>${p.displayName!}</span>
            </a>
          </li>
        </#list>
      </ul>
    </#if>

  <#elseif section = "info">
    <#if realm.password && realm.registrationAllowed && !registrationDisabled??>
      <span>${msg("noAccount")}
        <a class="sa-link" href="${url.registrationUrl}">${msg("doRegister")}</a>
      </span>
    </#if>

  </#if>

</@layout.registrationLayout>
