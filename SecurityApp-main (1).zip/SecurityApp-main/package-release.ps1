# package-release.ps1
# -----------------------------------------------------------------------------
# Developer tool: builds the SecurityApp API Docker image, saves it as a tar,
# and assembles a self-contained release package in the dist/ folder.
#
# Run this from the project root BEFORE shipping to a customer:
#   .\package-release.ps1
#   .\package-release.ps1 -Version "1.2.0"
#   .\package-release.ps1 -OutputDir "D:\releases"
#
# The resulting dist\ folder contains everything the customer needs.
# Zip it and send it -- the customer runs .\deploy.ps1 inside it.
# -----------------------------------------------------------------------------

param(
    [string]$Version    = (Get-Date -Format 'yyyy.MM.dd'),
    [string]$OutputDir  = (Join-Path $PSScriptRoot 'dist'),
    [string]$ImageName  = 'securityapp-api',
    [string]$ImageTag   = 'latest'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-Step([string]$n, [string]$msg) { Write-Host "`nStep $n`: $msg" -ForegroundColor Cyan }
function Write-OK([string]$msg)   { Write-Host "  [OK]   $msg" -ForegroundColor Green  }
function Write-Warn([string]$msg) { Write-Host "  [WARN] $msg" -ForegroundColor Yellow }
function Write-Fail([string]$msg) { Write-Host "  [FAIL] $msg" -ForegroundColor Red; exit 1 }

$Root    = $PSScriptRoot
$DistDir = $OutputDir

Write-Host ""
Write-Host "+================================================================+" -ForegroundColor Cyan
Write-Host "|           SecurityApp - Package Release v$Version              |" -ForegroundColor Cyan
Write-Host "+================================================================+" -ForegroundColor Cyan
Write-Host ""

# -- Step 1: Prerequisites ----------------------------------------------------
Write-Step 1 "Checking prerequisites"

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Write-Fail "Docker not found in PATH."
}
docker info 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) { Write-Fail "Docker Desktop is not running." }
Write-OK "Docker is running."

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    Write-Fail ".NET SDK not found. Required to verify build before packaging."
}
Write-OK ".NET SDK found."

# -- Step 2: Build Docker image -----------------------------------------------
Write-Step 2 "Building Docker image ${ImageName}:${ImageTag}"

$fullTag = "${ImageName}:${ImageTag}"
docker build -t $fullTag -f (Join-Path $Root 'docker\Dockerfile') $Root
if ($LASTEXITCODE -ne 0) { Write-Fail "Docker build failed." }
Write-OK "Image built: $fullTag"

# -- Step 3: Create dist folder -----------------------------------------------
Write-Step 3 "Creating distribution folder: $DistDir"

if (Test-Path $DistDir) {
    Write-Warn "dist\ already exists -- clearing it."
    Remove-Item $DistDir -Recurse -Force
}
New-Item -ItemType Directory -Path $DistDir | Out-Null
Write-OK "dist\ created."

# -- Step 4a: Build UI image -------------------------------------------------
Write-Step 4 "Building UI Docker image securityapp-ui:latest"

docker build -t 'securityapp-ui:latest' -f (Join-Path $Root 'ui-angular\Dockerfile') $Root
if ($LASTEXITCODE -ne 0) { Write-Fail "UI Docker build failed." }
Write-OK "UI image built: securityapp-ui:latest"

# -- Step 4b: Save API image to tar -------------------------------------------
Write-Step "4b" "Saving API image to securityapp-api.tar (this may take a minute)"

$tarPath = Join-Path $DistDir 'securityapp-api.tar'
docker save -o $tarPath $fullTag
if ($LASTEXITCODE -ne 0) { Write-Fail "docker save failed." }
$sizeMb = [math]::Round((Get-Item $tarPath).Length / 1MB, 0)
Write-OK "Image saved: securityapp-api.tar (${sizeMb} MB)"

# -- Step 5: Copy required runtime files -------------------------------------
Write-Step 5 "Copying runtime files"

$copies = @(
    # Compose files
    'docker-compose.yml',
    'docker-compose.release.yml',
    'docker-compose.sqlserver.yml',
    'docker-compose.postgres.yml',
    '.env.example',

    # Customer install script
    'deploy.ps1',

    # Vault
    'vault\entrypoint.sh',
    'vault\config\vault.hcl',

    # Vault + DB init scripts
    'scripts\vault-init.sh',
    'scripts\backup\backup-volumes.ps1',
    'scripts\backup\restore-volumes.ps1',

    # Keycloak realm import + permissions script
    'keycloak\realm-export.json',
    'keycloak\apply-permissions.ps1'
)

foreach ($rel in $copies) {
    $src = Join-Path $Root $rel
    $dst = Join-Path $DistDir $rel
    if (-not (Test-Path $src)) {
        Write-Warn "Not found (skipping): $rel"
        continue
    }
    $dstDir = Split-Path $dst -Parent
    if (-not (Test-Path $dstDir)) { New-Item -ItemType Directory -Path $dstDir | Out-Null }
    Copy-Item $src $dst
    Write-Host "  Copied: $rel" -ForegroundColor DarkGray
}

# Copy directories that need recursive copy
$dirCopies = @(
    @{ Src = 'database\scripts\postgresql\init'; Dst = 'database\scripts\postgresql\init' },
    @{ Src = 'database\scripts\sqlserver';       Dst = 'database\scripts\sqlserver'       },
    @{ Src = 'database\scripts\postgresql';      Dst = 'database\scripts\postgresql'      },
    @{ Src = 'database\scripts\mysql';           Dst = 'database\scripts\mysql'           },
    @{ Src = 'database\schema';                  Dst = 'database\schema'                  },
    @{ Src = 'keycloak\themes';                  Dst = 'keycloak\themes'                  },
    @{ Src = 'ldap';                              Dst = 'ldap'                              }
)

foreach ($d in $dirCopies) {
    $src = Join-Path $Root $d.Src
    $dst = Join-Path $DistDir $d.Dst
    if (-not (Test-Path $src)) {
        Write-Warn "Directory not found (skipping): $($d.Src)"
        continue
    }
    if (-not (Test-Path $dst)) { New-Item -ItemType Directory -Path $dst | Out-Null }
    Copy-Item "$src\*" $dst -Recurse -Force
    Write-Host "  Copied dir: $($d.Src)" -ForegroundColor DarkGray
}

Write-OK "All runtime files copied."

# -- Step 5b: Save UI image to tar -------------------------------------------
Write-Step "5b" "Saving UI image to securityapp-ui.tar (this may take a minute)"

$uiTarPath = Join-Path $DistDir 'securityapp-ui.tar'
docker save -o $uiTarPath 'securityapp-ui:latest'
if ($LASTEXITCODE -ne 0) { Write-Fail "docker save failed for UI image." }
$uiSizeMb = [math]::Round((Get-Item $uiTarPath).Length / 1MB, 0)
Write-OK "UI image saved: securityapp-ui.tar (${uiSizeMb} MB)"

# -- Step 6: Write version file -----------------------------------------------
Write-Step 6 "Writing version info"

$versionContent  = "SecurityApp Release Package`n"
$versionContent += "Version:   $Version`n"
$versionContent += "Built:     $(Get-Date -Format 'yyyy-MM-dd HH:mm')`n"
$versionContent += "Image:     ${fullTag}`n"
Set-Content -Path (Join-Path $DistDir 'VERSION.txt') -Value $versionContent -Encoding UTF8
Write-OK "VERSION.txt written."

# -- Summary ------------------------------------------------------------------
Write-Host ""
Write-Host "+================================================================+" -ForegroundColor Green
Write-Host "|              Release Package Ready                             |" -ForegroundColor Green
Write-Host "+================================================================+" -ForegroundColor Green
Write-Host ""
Write-Host "  Location: $DistDir" -ForegroundColor White
Write-Host ""
Write-Host "  Contents:" -ForegroundColor DarkGray

Get-ChildItem $DistDir -Recurse | Where-Object { -not $_.PSIsContainer } | ForEach-Object {
    $rel = $_.FullName.Substring($DistDir.Length + 1)
    $sizeMb2 = [math]::Round($_.Length / 1KB, 0)
    Write-Host "    $rel  (${sizeMb2} KB)" -ForegroundColor DarkGray
}

Write-Host ""
Write-Host "  Next steps:" -ForegroundColor Cyan
Write-Host "    1. Zip the dist\ folder and deliver to customer" -ForegroundColor Gray
Write-Host "    2. Customer extracts and runs:  .\deploy.ps1" -ForegroundColor Gray
Write-Host "    3. Source code (src\) is NOT included -- binaries only" -ForegroundColor Gray
Write-Host ""
