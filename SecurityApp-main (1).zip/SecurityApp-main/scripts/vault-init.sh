#!/usr/bin/env bash
# =============================================================================
# vault-init.sh — Initialise HashiCorp Vault for local SecurityApp development
#
# Run once after `docker compose up -d vault` to seed secrets and configure
# the JWT auth method so the API can authenticate without a static token.
#
# Usage (from project root):
#   docker exec -e VAULT_TOKEN=Vt!1DevRoot2026LocalDev \
#               securityapp-vault \
#               sh /scripts/vault-init.sh
#
# Or locally with a running Vault on localhost:8200:
#   VAULT_ADDR=http://localhost:8200 VAULT_TOKEN=Vt!1DevRoot2026LocalDev bash scripts/vault-init.sh
# =============================================================================
set -eu 

VAULT_ADDR="${VAULT_ADDR:-http://localhost:8200}"
VAULT_TOKEN="${VAULT_TOKEN:-Vt!1DevRoot2026LocalDev}"
KEYCLOAK_URL="${KEYCLOAK_URL:-http://keycloak:8080}"

export VAULT_ADDR VAULT_TOKEN

# ── Wait for Vault ─────────────────────────────────────────────────────────
echo "Waiting for Vault at $VAULT_ADDR ..."
for i in $(seq 1 30); do
    if vault status >/dev/null 2>&1; then break; fi
    echo "  attempt $i/30 ..."
    sleep 2
done
echo "Vault is ready."

# ── Enable KV v2 at 'secret/' ──────────────────────────────────────────────
if vault secrets list 2>/dev/null | grep -q '^secret/'; then
    echo "KV v2 already enabled at secret/ — skipping."
else
    vault secrets enable -path=secret kv-v2
    echo "KV v2 enabled at secret/."
fi

# ── Write application secrets ──────────────────────────────────────────────
# Values are read from environment variables so this script can be sourced
# by a CI pipeline or docker-compose exec without hard-coding credentials.
# The Vault CLI treats any value starting with '@' as a file-path reference.
# New-RandomPassword includes '@' in its special character set, so any generated
# password can start with '@' and trigger this. Write all generated passwords to
# temp files and use key=@file syntax to bypass the '@' interpretation entirely.
_VAULT_SA_TMP=$(mktemp)
_VAULT_RMQPASS_TMP=$(mktemp)

printf '%s' "${VAULT_SERVICE_ACCOUNT_SECRET:-Vault!1ServiceAccount2026}" > "$_VAULT_SA_TMP"
printf '%s' "${RABBITMQ_DEFAULT_PASS:-}"                                  > "$_VAULT_RMQPASS_TMP"

vault kv put secret/securityapp \
    "ConnectionStrings__SqlServer=${CONNECTION_STRINGS__SQLSERVER:-}" \
    "ConnectionStrings__PostgreSQL=${CONNECTION_STRINGS__POSTGRESQL:-}" \
    "ConnectionStrings__Redis=${CONNECTION_STRINGS__REDIS:-redis:6379}" \
    "RabbitMQ__Username=${RABBITMQ_DEFAULT_USER:-}" \
  "RabbitMQ__Password=@${_VAULT_RMQPASS_TMP}" \
    "DataConnectors__AlphaVantage__ApiKey=${ALPHAVANTAGE_API_KEY:-}" \
    "VaultServiceAccountClientSecret=@${_VAULT_SA_TMP}"

rm -f "$_VAULT_SA_TMP" "$_VAULT_RMQPASS_TMP"

echo "Secrets written to secret/securityapp."

# ── Transport credential secrets ───────────────────────────────────────────
# Each remote transport profile stores its credentials here.
# DB column values reference these paths with the syntax:  vault:{path}#{field}
#
# Example entries — replace placeholder values before running in production:
#   TransportHost          = "vault:sftp/bloomberg#host"
#   TransportUsername      = "vault:sftp/bloomberg#username"
#   TransportPasswordSecret= "vault:sftp/bloomberg#password"
#   TransportPort          = "vault:sftp/bloomberg#port"       (optional; falls back if blank)
#
# ── Seed a sample SFTP profile (Bloomberg) ────────────────────────────────
vault kv put secret/sftp/bloomberg \
    "host=${SFTP_BLOOMBERG_HOST:-sftp.bloomberg.com}" \
    "port=${SFTP_BLOOMBERG_PORT:-22}" \
    "username=${SFTP_BLOOMBERG_USER:-feed-user}" \
    "password=${SFTP_BLOOMBERG_PASS:-}"

echo "Transport secrets written to secret/sftp/bloomberg."

# ── Seed a sample FTPS profile (generic vendor) ───────────────────────────
vault kv put secret/ftps/vendor \
    "host=${FTPS_VENDOR_HOST:-ftps.vendor.com}" \
    "port=${FTPS_VENDOR_PORT:-21}" \
    "username=${FTPS_VENDOR_USER:-feed-user}" \
    "password=${FTPS_VENDOR_PASS:-}"

echo "Transport secrets written to secret/ftps/vendor."

# ── Policy ─────────────────────────────────────────────────────────────────
vault policy write securityapp-policy - <<'EOF'
# Allow the securityapp API to read its own KV secrets
path "secret/data/securityapp" {
  capabilities = ["read"]
}
path "secret/metadata/securityapp" {
  capabilities = ["read"]
}
# Allow reading arbitrary transport credential paths (sftp/*, ftps/*, ftp/*, https/*)
path "secret/data/sftp/*" {
  capabilities = ["read"]
}
path "secret/data/ftps/*" {
  capabilities = ["read"]
}
path "secret/data/ftp/*" {
  capabilities = ["read"]
}
path "secret/data/https/*" {
  capabilities = ["read"]
}
path "secret/metadata/sftp/*" {
  capabilities = ["read"]
}
path "secret/metadata/ftps/*" {
  capabilities = ["read"]
}
path "secret/metadata/ftp/*" {
  capabilities = ["read"]
}
path "secret/metadata/https/*" {
  capabilities = ["read"]
}
# Allow reading dynamic database credentials issued by the Vault database engine
path "database/creds/securityapp-api-db" {
  capabilities = ["read"]
}
# Allow reading dynamic RabbitMQ credentials issued by the Vault RabbitMQ engine
path "rabbitmq/creds/securityapp-api" {
  capabilities = ["read"]
}
# Explicitly deny admin secrets - the API must never read sa/admin credentials
path "secret/data/admin/*" {
  capabilities = ["deny"]
}
path "secret/metadata/admin/*" {
  capabilities = ["deny"]
}
EOF
echo "Policy 'securityapp-policy' written."

# ── Database secrets engine (dynamic credentials) ────────────────────────
# Configures the appropriate database plugin based on which admin password
# is present: ADMIN_PG_PASSWORD → PostgreSQL, ADMIN_SA_PASSWORD → SQL Server.
# verify_connection=false allows setup before the DB container is available.
#
# SOX/ISO 27001: every credential issuance is recorded in the Vault audit log
# (AU-2, A.12.4.1). Automatic lease revocation prevents stale privileged logins.
if vault secrets list 2>/dev/null | grep -q '^database/'; then
    echo "Database secrets engine already enabled — updating config."
else
    vault secrets enable database
    echo "Database secrets engine enabled."
fi

if [ -n "${ADMIN_PG_PASSWORD:-}" ]; then
    # ── PostgreSQL ──────────────────────────────────────────────────────────
    vault write database/config/securityapp-db \
        plugin_name=postgresql-database-plugin \
        connection_url="postgresql://{{username}}:{{password}}@postgres:5432/securityapp_db" \
        allowed_roles="securityapp-api-db" \
        username="securityapp" \
        "password=${ADMIN_PG_PASSWORD}" \
        verify_connection=false
    echo "Database engine configured (securityapp-db → postgres:5432/securityapp_db)."

    vault write database/roles/securityapp-api-db \
        db_name=securityapp-db \
        "creation_statements=CREATE ROLE \"{{name}}\" WITH LOGIN PASSWORD '{{password}}' VALID UNTIL '{{expiration}}'; GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO \"{{name}}\"; GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO \"{{name}}\"; GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO \"{{name}}\"; ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO \"{{name}}\"; ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE ON SEQUENCES TO \"{{name}}\";" \
        "revocation_statements=REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA public FROM \"{{name}}\"; REVOKE ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public FROM \"{{name}}\"; DROP ROLE IF EXISTS \"{{name}}\";" \
        default_ttl="2h" \
        max_ttl="8h"
    echo "Database role 'securityapp-api-db' configured for PostgreSQL (2h TTL, 8h max)."

elif [ -n "${ADMIN_SA_PASSWORD:-}" ]; then
    # ── SQL Server ──────────────────────────────────────────────────────────
    vault write database/config/securityapp-db \
        plugin_name=mssql-database-plugin \
        connection_url="sqlserver://{{username}}:{{password}}@sqlserver:1433?database=securityapp_db" \
        allowed_roles="securityapp-api-db" \
        username="sa" \
        "password=${ADMIN_SA_PASSWORD}" \
        verify_connection=false
    echo "Database engine configured (securityapp-db → sqlserver:1433/securityapp_db)."

    vault write database/roles/securityapp-api-db \
        db_name=securityapp-db \
        "creation_statements=CREATE LOGIN [{{name}}] WITH PASSWORD = '{{password}}'" \
        "creation_statements=CREATE USER [{{name}}] FOR LOGIN [{{name}}]" \
        "creation_statements=ALTER ROLE db_datareader ADD MEMBER [{{name}}]" \
        "creation_statements=ALTER ROLE db_datawriter ADD MEMBER [{{name}}]" \
        "creation_statements=GRANT EXECUTE TO [{{name}}]" \
        "revocation_statements=DROP USER IF EXISTS [{{name}}]" \
        "revocation_statements=DROP LOGIN IF EXISTS [{{name}}]" \
        default_ttl="2h" \
        max_ttl="8h"
    echo "Database role 'securityapp-api-db' configured for SQL Server (2h TTL, 8h max)."

else
    echo "WARNING: Neither ADMIN_PG_PASSWORD nor ADMIN_SA_PASSWORD set — skipping database secrets engine config."
fi

# ── RabbitMQ secrets engine (dynamic credentials) ─────────────────────
# Issues ephemeral RabbitMQ users with 1h TTL for the API.
# Vault connects to the RabbitMQ management API to create/delete users.
# The admin user (RABBITMQ_DEFAULT_USER) must have the 'administrator' tag —
# this is set automatically when created via the RABBITMQ_DEFAULT_USER env var.
if vault secrets list 2>/dev/null | grep -q '^rabbitmq/'; then
    echo "RabbitMQ secrets engine already enabled — updating config."
else
    vault secrets enable rabbitmq
    echo "RabbitMQ secrets engine enabled."
fi

vault write rabbitmq/config/connection \
    connection_uri="http://rabbitmq:15672" \
    username="${RABBITMQ_DEFAULT_USER:-}" \
    password="${RABBITMQ_DEFAULT_PASS:-}" \
    verify_connection=false
echo "RabbitMQ engine configured (management API at rabbitmq:15672)."

vault write rabbitmq/roles/securityapp-api \
    vhosts='{"/":{"write":".*","read":".*","configure":".*"}}' \
    default_ttl=2h \
    max_ttl=8h
echo "RabbitMQ role 'securityapp-api' configured (2h TTL, 8h max)."

# ── AppRole auth method ────────────────────────────────────────────────────
# AppRole replaces the old static service-account token with a two-part
# credential: a permanent RoleID (non-secret, like a username) and a
# SecretID stored in .env / docker-compose.override.yml.
# The API exchanges these for a 1-hour Vault token at startup.
#
# secret_id_num_uses=0  — unlimited uses so the API container can restart
#                         without needing a fresh SecretID each time.
# secret_id_ttl=0       — no TTL expiry; rotate manually via deploy.ps1
#                         or scripts/vault-rotate.ps1 -Action RefreshSecretId.
if vault auth list 2>/dev/null | grep -q '^approle/'; then
    echo "AppRole already enabled — reconfiguring role ..."
else
    vault auth enable approle
    echo "AppRole auth method enabled."
fi

vault write auth/approle/role/securityapp-api \
    token_policies="securityapp-policy" \
    token_ttl=1h \
    token_max_ttl=24h \
    secret_id_ttl=0 \
    secret_id_num_uses=0  # unlimited uses so the API can re-authenticate after Vault token expiry

ROLE_ID=$(vault read -field=role_id auth/approle/role/securityapp-api/role-id)
if [ -z "$ROLE_ID" ]; then
    echo "ERROR: vault read returned empty RoleID — aborting vault-init.sh."
    exit 1
fi
echo "$ROLE_ID" > /vault/data/approle.roleid
chmod 600 /vault/data/approle.roleid
echo "AppRole RoleID saved to /vault/data/approle.roleid (in vault_data volume)."
echo "  RoleID: $ROLE_ID"

# ── JWT auth method (Keycloak → Vault passwordless auth) ───────────────────
# Wait for Keycloak here — this is the only section that needs it.
# AppRole, KV, policies, and DB engine above do not require Keycloak.
# KEYCLOAK_URL is passed in from docker-compose.yml via the vault service environment.
# Wait for Keycloak — required for JWT auth JWKS config.
# Uses bash /dev/tcp (nc is not available in this container image).
if [ -n "${KEYCLOAK_URL:-}" ]; then
    KC_HOST=$(echo "$KEYCLOAK_URL" | sed 's|.*://||; s|[:/].*||')
    KC_PORT=$(echo "$KEYCLOAK_URL" | grep -oE ':[0-9]+' | tr -d ':')
    KC_PORT="${KC_PORT:-8080}"
    echo "Waiting for Keycloak at $KC_HOST:$KC_PORT (required for JWT auth JWKS config)..."
    REACHED=0
    for i in $(seq 1 60); do
        if (echo "" > /dev/tcp/"$KC_HOST"/"$KC_PORT") 2>/dev/null; then
            REACHED=1; break
        fi
        sleep 3
    done
    if [ "$REACHED" -eq 1 ]; then
        echo "Keycloak is reachable."
    else
        echo "WARNING: Keycloak not reachable after 3 minutes — JWT auth method will be skipped."
        echo "Run 'docker exec securityapp-vault rm /vault/data/.seeded && docker restart securityapp-vault' after Keycloak is healthy to retry."
    fi
fi

# Reference: https://developer.hashicorp.com/vault/docs/auth/jwt
if vault auth list 2>/dev/null | grep -q '^jwt/'; then
    echo "JWT auth already enabled — reconfiguring ..."
else
    vault auth enable jwt
fi

if vault write auth/jwt/config \
    jwks_url="$KEYCLOAK_URL/realms/securityapp/protocol/openid-connect/certs" \
    bound_issuer="$KEYCLOAK_URL/realms/securityapp"; then

    vault write auth/jwt/role/securityapp-api \
    role_type="jwt" \
        bound_audiences="securityapp-vault" \
        user_claim="sub" \
        policies="securityapp-policy" \
        ttl="1h"

    echo "JWT auth method configured against Keycloak at $KEYCLOAK_URL."
else
    echo "ERROR: vault write auth/jwt/config failed — check KEYCLOAK_URL and Keycloak health."
    exit 1
fi

# ── Admin credentials (DB admin passwords, accessible via root token only) ──
# Stored so migration scripts can retrieve them without needing plaintext in .env
if [ -n "${ADMIN_SA_PASSWORD:-}" ] || [ -n "${ADMIN_PG_PASSWORD:-}" ]; then
    vault kv put secret/admin/database \
        "saPassword=${ADMIN_SA_PASSWORD:-}" \
        "pgPassword=${ADMIN_PG_PASSWORD:-}" \
        "kcDbPassword=${ADMIN_KC_DB_PASSWORD:-}"
    echo "Admin database credentials stored at secret/admin/database."
fi

# ── Restart token (least-privilege, periodic, orphan) ────────────────────
# Allows entrypoint.sh to update AppRole, DB engine config, and RabbitMQ engine
# config on every container/host restart WITHOUT needing the root token.
# Once this token is in place the root token can be safely revoked.
#
# The token is:
#   - orphan=true    : not a child of the root token; survives root token revocation
#   - period=24h     : auto-renews itself every 24h while Vault is running
#   - renewable=true : entrypoint.sh renews it on every start before use
#
# Policy: write-only to the three paths entrypoint.sh touches — nothing else.
vault policy write vault-restart-policy - <<'RESTART_POLICY'
# Update AppRole role settings (token_ttl, secret_id_num_uses, etc.)
path "auth/approle/role/securityapp-api" {
  capabilities = ["create", "update"]
}
# Update Database secrets engine connection config (rotate SA password)
path "database/config/securityapp-mssql" {
  capabilities = ["create", "update"]
}
# Update RabbitMQ secrets engine connection config (rotate RMQ password)
path "rabbitmq/config/connection" {
  capabilities = ["create", "update"]
}
# Allow the token to renew itself
path "auth/token/renew-self" {
  capabilities = ["update"]
}
RESTART_POLICY
echo "Policy 'vault-restart-policy' written."

RESTART_TOKEN=$(vault token create \
    -policy=vault-restart-policy \
    -period=168h \
    -orphan \
    -renewable=true \
    -display-name="vault-restart-entrypoint" \
    -field=token)
if [ -n "$RESTART_TOKEN" ]; then
    echo "$RESTART_TOKEN" > /vault/data/.restart-token
    chmod 600 /vault/data/.restart-token
    echo "Restart token created and saved to /vault/data/.restart-token"
    echo "  The root token can now be safely revoked — entrypoint.sh will use this token on all future restarts."
else
    echo "WARNING: Could not create restart token. entrypoint.sh will fall back to root token."
fi

# ── LDAP auth method (human Vault UI access via OpenLDAP) ─────────────────
# Allows Admin users to log into the Vault UI with their LDAP credentials.
# The API itself continues to use AppRole; this is human-access only.
if vault auth list 2>/dev/null | grep -q '^ldap/'; then
  echo "LDAP auth already enabled — reconfiguring ..."
else
  vault auth enable ldap
  echo "LDAP auth method enabled."
fi

vault write auth/ldap/config \
  url="ldap://openldap:389" \
  binddn="cn=admin,dc=securityapp,dc=local" \
  "bindpass=${LDAP_ADMIN_PASSWORD:-}" \
  userdn="ou=Users,dc=securityapp,dc=local" \
  userattr="uid" \
  groupdn="ou=Groups,dc=securityapp,dc=local" \
  groupattr="cn" \
  groupfilter="(&(objectClass=groupOfNames)(member={{.UserDN}}))" \
  insecure_tls=true \
  starttls=false

# Map LDAP Admin group to the Vault admin policy (root-equivalent for local dev)
vault write auth/ldap/groups/Admin \
  policies=root

echo "Vault LDAP auth configured — Admins can log in at http://localhost:8200 with LDAP credentials."

# ── Audit log (file device) ───────────────────────────────────────────────
# Writes a tamper-evident JSON record of every Vault operation to
# /vault/logs/audit.log, which is mounted to a named Docker volume so logs
# survive container restarts and can be shipped to a SIEM.
#
# log_raw=false (default) ensures secret values are never written to the log.
# Each record contains: timestamp, token accessor, operation, path, status.
# This satisfies SOX AU-2/AU-9 and ISO 27001 A.12.4.1.
if vault audit list 2>/dev/null | grep -q '^file/'; then
    echo "Audit file device already enabled — skipping."
else
    vault audit enable file file_path=/vault/logs/audit.log \
      && echo "Audit log enabled at /vault/logs/audit.log." \
      || echo "WARNING: Could not enable audit log (may lack permissions or /vault/logs not writable)."
fi

# ── Summary ────────────────────────────────────────────────────────────────
echo ""
echo "=========================================================="
echo " Vault initialisation complete."
echo " To enable Vault AppRole auth in the API add to docker-compose.override.yml:"
echo "   api:"
echo "     environment:"
echo "       SecretProviders__EnableHashiCorpVault: \"true\""
echo "       SecretProviders__VaultAddress:         \"http://vault:8200\""
echo "       SecretProviders__EnableAppRoleAuth:     \"true\""
echo "       SecretProviders__VaultRoleId:           \"\${VAULT_ROLE_ID}\""
echo "       SecretProviders__VaultSecretId:         \"\${VAULT_SECRET_ID}\""
echo ""
echo " RoleID is stored in the vault_data volume at /vault/data/approle.roleid"
echo " The SecretID in .env is reusable — the API container can restart freely."
echo " Rotate it manually with: deploy.ps1 -Resume  (or vault-rotate.ps1 -Action RefreshSecretId)"
echo ""
echo " For passwordless Keycloak auth instead, add:"
echo "       SecretProviders__EnableKeycloakVaultAuth:          \"true\""
echo "       SecretProviders__KeycloakAuthority: \"$KEYCLOAK_URL/realms/securityapp\""
echo "       SecretProviders__VaultServiceAccountClientId:     \"securityapp-vault\""
echo "       SecretProviders__VaultServiceAccountClientSecret: \"<client-secret>\""
echo "=========================================================="
