# vault-rotate.ps1 - Vault credential management for SecurityApp
# -----------------------------------------------------------------------------
# Run this script any time you need to:
#   - Rotate the API service-account token
#   - Update a secret stored in Vault (DB password, RabbitMQ password, etc.)
#   - View current Vault secrets (admin audit)
#
# Prerequisites:
#   - SecurityApp containers must already be running (docker compose up -d)
#   - You need the Vault root token (from credentials.txt or .env)
#
# Usage:
#   .\scripts\vault-rotate.ps1                    # interactive menu
#   .\scripts\vault-rotate.ps1 -Action RotateToken
#   .\scripts\vault-rotate.ps1 -Action UpdateSecret -SecretKey RabbitMQ__Password -SecretValue "newpass"
#   .\scripts\vault-rotate.ps1 -Action ViewSecrets
# -----------------------------------------------------------------------------

param(
    [ValidateSet('RotateToken', 'UpdateSecret', 'ViewSecrets', 'RefreshSecretId', 'GenerateBreakGlassSecretId', 'RevokeBreakGlassSecretId', 'RotateKcDbPassword', 'RevokeRootToken', 'Menu')]
    [string]$Action = 'Menu',

    [string]$SecretKey   = '',
    [string]$SecretValue = '',

    # Override root token on the command line (otherwise read from .env / credentials.txt)
    [string]$RootToken = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$Root = Split-Path $PSScriptRoot -Parent   # project root (one level up from scripts/)

function Write-Head([string]$msg) { Write-Host "`n$msg" -ForegroundColor Cyan }
function Write-OK([string]$msg)   { Write-Host "  [OK]   $msg" -ForegroundColor Green  }
function Write-Warn([string]$msg) { Write-Host "  [WARN] $msg" -ForegroundColor Yellow }
function Write-Fail([string]$msg) { Write-Host "  [FAIL] $msg" -ForegroundColor Red; exit 1 }

# Read a quoted value from docker-compose.override.yml by key name
function Read-OverrideValue([string]$Key) {
    $f = Join-Path $Root 'docker-compose.override.yml'
    if (-not (Test-Path $f)) { return $null }
    $content = Get-Content $f -Raw
    if ($content -match "(?m)^\s+${Key}:\s+`"([^`"]+)`"") { return $Matches[1] }
    return $null
}

function New-RotatePass([int]$Length = 24) {
    $upper   = 'ABCDEFGHJKLMNPQRSTUVWXYZ'
    $lower   = 'abcdefghjkmnpqrstuvwxyz'
    $digits  = '23456789'
    $special = '!@#%^*()-_=+[]{}:;<>,.?'
    $all     = $upper + $lower + $digits + $special
    $rng     = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    do {
        $bytes = New-Object byte[] $Length
        $rng.GetBytes($bytes)
        $chars = $bytes | ForEach-Object { $all[$_ % $all.Length] }
        $pwd   = -join $chars
    } until (
        ($pwd -cmatch '[A-Z]') -and ($pwd -cmatch '[a-z]') -and
        ($pwd -match '\d')     -and ($pwd -match '[!@#%^*()\-_=+\[\]{}:;<>,.?]')
    )
    return $pwd
}

# -- Locate root token --------------------------------------------------------
function Get-VaultRootToken {
    if (-not [string]::IsNullOrWhiteSpace($RootToken)) { return $RootToken }

    # Try reading from credentials.txt first (most user-friendly)
    $credFile = Join-Path $Root 'credentials.txt'
    if (Test-Path $credFile) {
        $line = Get-Content $credFile | Select-String 'Root token:' | Select-Object -First 1
        if ($line -and $line -match 'Root token:\s+(\S+)') {
            return $Matches[1]
        }
    }

    # Try reading directly from the Vault container's init file
    $token = docker exec securityapp-vault cat /vault/data/.init.json 2>&1 |
        Select-String '"root_token"' |
        ForEach-Object { if ($_ -match '"root_token"\s*:\s*"([^"]+)"') { $Matches[1] } }
    if ($token) { return $token }

    # Last resort: ask
    Write-Warn "Root token not found automatically."
    return (Read-Host "  Enter the Vault root token")
}

# -- Check containers are up --------------------------------------------------
function Assert-VaultRunning {
    $state = docker inspect --format='{{.State.Status}}' securityapp-vault 2>&1
    if ($state -ne 'running') {
        Write-Fail "securityapp-vault container is not running. Start it with: docker compose up -d vault"
    }
}

# -- Run a vault command inside the container ---------------------------------
function Invoke-Vault([string[]]$VaultArgs, [string]$Token) {
    $result = docker exec -e "VAULT_TOKEN=$Token" securityapp-vault vault @VaultArgs 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Fail "Vault command failed: vault $($VaultArgs -join ' ')`n  $result"
    }
    return $result
}

# =============================================================================
# Action: View Secrets
# =============================================================================
function Invoke-ViewSecrets {
    Write-Head "--- Viewing secrets in secret/securityapp ---"
    $token = Get-VaultRootToken
    Assert-VaultRunning

    $json = Invoke-Vault @('kv', 'get', '-format=json', 'secret/securityapp') -Token $token |
        Out-String
    try {
        $parsed = $json | ConvertFrom-Json
        $data   = $parsed.data.data
        Write-Host "`n  Current secrets in secret/securityapp:`n" -ForegroundColor White
        $data.PSObject.Properties | ForEach-Object {
            $val = if ($_.Value) { $_.Value } else { '(empty)' }
            Write-Host ("  {0,-45} = {1}" -f $_.Name, $val)
        }
    } catch {
        Write-Host $json
    }
    Write-Host ""
}

# =============================================================================
# Action: Update Secret
# =============================================================================
function Invoke-UpdateSecret([string]$Key, [string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Key)) {
        Write-Host "`n  Which secret key do you want to update?" -ForegroundColor Gray
        Write-Host "  Examples: RabbitMQ__Password, ConnectionStrings__SqlServer," -ForegroundColor DarkGray
        Write-Host "            ConnectionStrings__Redis, DataConnectors__AlphaVantage__ApiKey" -ForegroundColor DarkGray
        $Key = Read-Host "  Key"
    }
    if ([string]::IsNullOrWhiteSpace($Key)) { Write-Fail "Key cannot be empty." }

    if ([string]::IsNullOrWhiteSpace($Value)) {
        $secure = Read-Host "  New value for '$Key'" -AsSecureString
        $Value  = [System.Net.NetworkCredential]::new('', $secure).Password
    }
    if ([string]::IsNullOrWhiteSpace($Value)) { Write-Fail "Value cannot be empty." }

    Write-Head "--- Updating secret: $Key ---"
    $token = Get-VaultRootToken
    Assert-VaultRunning

    # vault kv patch only updates specified keys, leaving others untouched
    Invoke-Vault -VaultArgs @('kv', 'patch', 'secret/securityapp', "$Key=$Value") -Token $token | Out-Null
    Write-OK "Secret '$Key' updated in Vault."

    # If it's a connection string or RabbitMQ credential, the API needs a restart
    # to pick up the change (the API reads secrets at startup via IVaultKvReader)
    $needsRestart = $Key -match 'ConnectionStrings|RabbitMQ'
    if ($needsRestart) {
        Write-Warn "The API reads these secrets at startup."
        $restart = Read-Host "  Restart the API container now? (Y/n)"
        if ($restart -ne 'n' -and $restart -ne 'N') {
            Write-Head "--- Restarting API ---"
            docker compose --project-directory $Root restart api 2>&1 |
                ForEach-Object { Write-Host "  $_" -ForegroundColor DarkGray }
            Write-OK "API restarted. New secret is now active."
        } else {
            Write-Warn "Remember to restart the API when ready: docker compose restart api"
        }
    }
    Write-OK "Done."
}

# =============================================================================
# Action: Refresh AppRole SecretID
# =============================================================================
function Invoke-RefreshSecretId {
    Write-Head "--- Generating a fresh wrapped AppRole SecretID ---"
    Write-Host "  This generates a single-use, 5-minute response-wrapped SecretID and writes" -ForegroundColor DarkGray
    Write-Host "  VAULT_ROLE_ID + VAULT_WRAP_TOKEN to .env, then restarts the API." -ForegroundColor DarkGray
    Write-Host "  The API unwraps it on startup to get the real SecretID, then exchanges" -ForegroundColor DarkGray
    Write-Host "  RoleID + SecretID for a 1-hour Vault token. Every restart = an audit event." -ForegroundColor DarkGray

    $rootToken = Get-VaultRootToken
    Assert-VaultRunning

    # Read RoleID from vault volume (single source of truth)
    $roleId = docker exec securityapp-vault cat /vault/data/approle.roleid 2>&1
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($roleId)) {
        Write-Fail "Could not read RoleID from /vault/data/approle.roleid. Re-run deploy.ps1 to reinitialise Vault."
    }
    $roleId = $roleId.Trim()
    Write-OK "RoleID: $roleId"

    # Generate a response-wrapped SecretID (single-use wrapping token, 5-min TTL)
    $wrapJson = docker exec -e "VAULT_TOKEN=$rootToken" `
        securityapp-vault vault write -wrap-ttl=5m -f auth/approle/role/securityapp-api/secret-id -format=json 2>&1 | Out-String

    $newWrapToken = ''
    try   { $newWrapToken = ($wrapJson | ConvertFrom-Json).wrap_info.token }
    catch { if ($wrapJson -match '"token"\s*:\s*"([^"]+)"') { $newWrapToken = $Matches[1] } }

    if ([string]::IsNullOrWhiteSpace($newWrapToken)) {
        Write-Fail "Failed to generate wrapped SecretID. Check: docker logs securityapp-vault"
    }
    Write-OK "Wrapped SecretID generated (single-use, 5-min TTL)."

    # Update .env
    $envFile    = Join-Path $Root '.env'
    $envContent = Get-Content $envFile -Raw
    if ($envContent -notmatch '(?m)^VAULT_ROLE_ID=') {
        $envContent += "`nVAULT_ROLE_ID=$roleId`n"
    } else {
        $envContent = $envContent -replace '(?m)^VAULT_ROLE_ID=.*$', "VAULT_ROLE_ID=$roleId"
    }
    if ($envContent -notmatch '(?m)^VAULT_WRAP_TOKEN=') {
        $envContent += "VAULT_WRAP_TOKEN=$newWrapToken`n"
    } else {
        $envContent = $envContent -replace '(?m)^VAULT_WRAP_TOKEN=.*$', "VAULT_WRAP_TOKEN=$newWrapToken"
    }
    Set-Content -Path $envFile -Value $envContent -Encoding UTF8
    Write-OK ".env updated with VAULT_ROLE_ID and VAULT_WRAP_TOKEN."

    # Restart API so it picks up the fresh wrapping token before it expires (5 min window)
    Write-Head "--- Restarting API to consume the new wrapped SecretID ---"
    docker compose --project-directory $Root up -d api 2>&1 |
        ForEach-Object { Write-Host "  $_" -ForegroundColor DarkGray }
    Write-OK "API container restarted. It will unwrap the token and exchange for a 1h Vault token now."

    Write-Host "`n  RoleID:     $roleId" -ForegroundColor Yellow
    Write-Host "  WrapToken:  $newWrapToken  (5-min TTL, already being consumed)" -ForegroundColor Yellow
    Write-Host "  (also saved in .env)`n" -ForegroundColor DarkGray
}

# =============================================================================
# Action: Rotate Service-Account Token (legacy - pre-AppRole deployments only)
# =============================================================================
function Invoke-RotateToken {
    Write-Head "--- Rotating the API service-account token ---"
    Write-Host "  This creates a new token bound to 'securityapp-policy' and updates" -ForegroundColor DarkGray
    Write-Host "  .env, then restarts the API container." -ForegroundColor DarkGray

    $rootToken = Get-VaultRootToken
    Assert-VaultRunning

    # Read current SA token from .env to revoke it afterwards
    $envFile    = Join-Path $Root '.env'
    $envContent = Get-Content $envFile -Raw
    $oldToken   = ''
    if ($envContent -match '(?m)^VAULT_SERVICE_ACCOUNT_TOKEN=(.+)$') {
        $oldToken = $Matches[1].Trim()
    }

    # Create new periodic token
    $newTokenJson = Invoke-Vault -VaultArgs @(
        'token', 'create',
        '-policy=securityapp-policy',
        '-period=8760h',
        '-orphan',
        '-format=json'
    ) -Token $rootToken | Out-String

    $newToken = ''
    try {
        $newToken = ($newTokenJson | ConvertFrom-Json).auth.client_token
    } catch {
        # Fallback: parse with regex
        if ($newTokenJson -match '"client_token"\s*:\s*"([^"]+)"') {
            $newToken = $Matches[1]
        }
    }
    if ([string]::IsNullOrWhiteSpace($newToken)) {
        Write-Fail "Failed to parse the new token from Vault response."
    }
    Write-OK "New service-account token created."

    # Write to container's data volume (mirrors what vault-init.sh does)
    docker exec securityapp-vault sh -c "echo '$newToken' > /vault/data/service-account.token" 2>&1 | Out-Null
    Write-OK "Token written to Vault data volume."

    # Update .env
    $envContent = $envContent -replace '(?m)^VAULT_SERVICE_ACCOUNT_TOKEN=.*$', "VAULT_SERVICE_ACCOUNT_TOKEN=$newToken"
    Set-Content -Path $envFile -Value $envContent -Encoding UTF8
    Write-OK ".env updated."

    # Revoke old token (best-effort - don't fail if already gone)
    if (-not [string]::IsNullOrWhiteSpace($oldToken)) {
        docker exec -e "VAULT_TOKEN=$rootToken" securityapp-vault vault token revoke $oldToken 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0) {
            Write-OK "Old token revoked."
        } else {
            Write-Warn "Could not revoke old token (may already be expired - that is OK)."
        }
    }

    # Update credentials.txt if it exists
    $credFile = Join-Path $Root 'credentials.txt'
    if (Test-Path $credFile) {
        $credContent = Get-Content $credFile -Raw
        $credContent = $credContent -replace '(?m)^  SA token:.*$', "  SA token:    $newToken"
        Set-Content -Path $credFile -Value $credContent -Encoding UTF8
        Write-OK "credentials.txt updated."
    }

    # Restart API
    Write-Head "--- Restarting API to apply new token ---"
    docker compose --project-directory $Root restart api 2>&1 |
        ForEach-Object { Write-Host "  $_" -ForegroundColor DarkGray }
    Write-OK "API restarted with new Vault token."

    Write-Host "`n  New SA token: $newToken" -ForegroundColor Yellow
    Write-Host "  (also saved in .env and credentials.txt)`n" -ForegroundColor DarkGray
}

# =============================================================================
# Action: Revoke Root Token
# =============================================================================
function Invoke-RevokeRootToken {
    Write-Head "--- Revoking the Vault root token ---"
    Write-Host "  After revocation all restarts use the least-privilege restart token." -ForegroundColor DarkGray
    Write-Host "  If the restart token ever expires, entrypoint.sh auto-recovers using" -ForegroundColor DarkGray
    Write-Host "  the unseal key stored in /vault/data/.init.json (no human action needed)." -ForegroundColor DarkGray
    Write-Host ""

    Assert-VaultRunning

    # Read root token from init file
    $initRaw = docker exec securityapp-vault cat /vault/data/.init.json 2>&1 | Out-String
    $rootToken = ''
    if ($initRaw -match '"root_token"\s*:\s*"([^"]+)"') { $rootToken = $Matches[1] }
    if ([string]::IsNullOrWhiteSpace($rootToken)) {
        Write-Fail "Could not read root token from /vault/data/.init.json. Already revoked?"
    }

    # Confirm restart token is in place and valid before proceeding
    Write-Host "  Verifying restart token is present and valid..." -ForegroundColor DarkGray
    $rtCheck = docker exec securityapp-vault sh -c '
        if [ -f /vault/data/.restart-token ]; then
            tok=$(cat /vault/data/.restart-token)
            VAULT_ADDR=http://127.0.0.1:8200 VAULT_TOKEN="$tok" vault token lookup -format=json 2>/dev/null \
                | grep -o "\"display_name\":\"[^\"]*\"" | head -1
        else
            echo "MISSING"
        fi' 2>&1 | Out-String

    if ($rtCheck -match 'MISSING') {
        Write-Fail "Restart token file not found at /vault/data/.restart-token.`n  Re-seed Vault first: docker exec -e VAULT_TOKEN=`"$rootToken`" securityapp-vault sh /vault/scripts/vault-init.sh"
    }
    if ($rtCheck -notmatch 'vault-restart-entrypoint') {
        Write-Fail "Restart token lookup failed - it may be expired or invalid.`n  Re-seed Vault: docker exec -e VAULT_TOKEN=`"$rootToken`" securityapp-vault sh /vault/scripts/vault-init.sh"
    }
    Write-OK "Restart token is present and valid."

    # Final confirmation
    Write-Host ""
    Write-Host "  This will permanently revoke the root token." -ForegroundColor Yellow
    Write-Host "  The unseal key in .init.json is the only way to generate a new one." -ForegroundColor Yellow
    Write-Host "  Restarts are fully automatic - no manual intervention ever needed." -ForegroundColor Yellow
    Write-Host ""
    $confirm = Read-Host "  Type 'yes' to confirm"
    if ($confirm -ne 'yes') { Write-Host "  Cancelled."; return }

    # Revoke it
    docker exec -e "VAULT_TOKEN=$rootToken" securityapp-vault `
        vault token revoke $rootToken 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) {
        Write-OK "Root token revoked. entrypoint.sh will use the restart token from now on."
    } else {
        Write-Warn "Vault returned a non-zero exit - the token may already be revoked."
    }

    # Update credentials.txt to note revocation
    $credFile = Join-Path $Root 'credentials.txt'
    if (Test-Path $credFile) {
        $credContent = Get-Content $credFile -Raw
        $ts = Get-Date -Format 'yyyy-MM-dd HH:mm'
        $credContent = $credContent -replace '(?m)(^\s+Root token:\s+)(\S+)', "`${1}REVOKED on $ts (was: `${2})"
        Set-Content -Path $credFile -Value $credContent -Encoding UTF8
        Write-OK "credentials.txt updated."
    }

    Write-Host ""
    Write-Host "  Unseal key is still in /vault/data/.init.json (vault_data volume)." -ForegroundColor DarkGray
    Write-Host "  Guard the host volume - it is now the sole recovery credential.`n" -ForegroundColor DarkGray
}

# =============================================================================
# Action: Rotate Keycloak DB Password (Phase 5)
# =============================================================================
function Invoke-RotateKcDbPassword {
    Write-Head "--- Phase 5: Rotating Keycloak database password ---"
    Write-Host "  Generates a new password, updates SQL Server, Vault, and docker-compose.override.yml," -ForegroundColor DarkGray
    Write-Host "  then restarts Keycloak to pick up the new credential." -ForegroundColor DarkGray

    $rootToken = Get-VaultRootToken
    Assert-VaultRunning

    # Read SA password needed for sqlcmd
    $saPass = Read-OverrideValue 'MSSQL_SA_PASSWORD'
    if ([string]::IsNullOrWhiteSpace($saPass)) { $saPass = Read-OverrideValue 'ADMIN_SA_PASSWORD' }
    if ([string]::IsNullOrWhiteSpace($saPass)) {
        Write-Fail "Cannot read SA password from docker-compose.override.yml. Is the file present?"
    }

    $newPass = New-RotatePass
    Write-OK "New password generated."

    # Step 1: Update SQL Server 'keycloak' login
    Write-Host "  Updating SQL Server keycloak login..." -ForegroundColor DarkGray
    $escapedPass = $newPass -replace "'", "''"
    $sqlScript   = "ALTER LOGIN [keycloak] WITH PASSWORD = '$escapedPass', CHECK_POLICY = OFF;"
    $sqlB64      = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($sqlScript))
    docker exec securityapp-sqlserver bash -c "echo $sqlB64 | base64 -d > /tmp/rotate-kc-db.sql" 2>&1 | Out-Null
    $sqlOut = docker exec securityapp-sqlserver `
        /opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P $saPass `
        -i /tmp/rotate-kc-db.sql -b -No 2>&1 | Out-String
    docker exec securityapp-sqlserver bash -c "rm -f /tmp/rotate-kc-db.sql" 2>&1 | Out-Null
    if ($sqlOut -match 'Msg \d|Error|error|FAIL') {
        Write-Fail "SQL Server update failed: $($sqlOut.Trim())`n  (Keycloak login may not exist yet - run deploy.ps1 first.)"
    }
    Write-OK "SQL Server 'keycloak' login password updated."

    # Step 2: Update Vault KV (patch only kcDbPassword, leave saPassword/pgPassword intact)
    Invoke-Vault @('kv', 'patch', 'secret/admin/database', "kcDbPassword=$newPass") -Token $rootToken | Out-Null
    Write-OK "Vault secret/admin/database.kcDbPassword updated."

    # Step 3: Update docker-compose.override.yml
    $overrideFile = Join-Path $Root 'docker-compose.override.yml'
    if (-not (Test-Path $overrideFile)) { Write-Fail "docker-compose.override.yml not found." }
    $content = Get-Content $overrideFile -Raw
    $content = $content -replace '(?m)^(\s+KC_DB_PASSWORD:\s+)"[^"]*"',     "`${1}`"$newPass`""
    $content = $content -replace '(?m)^(\s+ADMIN_KC_DB_PASSWORD:\s+)"[^"]*"', "`${1}`"$newPass`""
    Set-Content -Path $overrideFile -Value $content -Encoding UTF8
    Write-OK "docker-compose.override.yml updated (KC_DB_PASSWORD + ADMIN_KC_DB_PASSWORD)."

    # Step 4: Update credentials.txt if present
    $credFile = Join-Path $Root 'credentials.txt'
    if (Test-Path $credFile) {
        $credContent = Get-Content $credFile -Raw
        # Replace password on the KC login line: "  KC login:      keycloak  /  <pass>  ("
        $credContent = $credContent -replace '(?m)(^\s+KC login:\s+keycloak\s+/\s+)\S+', "`${1}$newPass"
        Set-Content -Path $credFile -Value $credContent -Encoding UTF8
        Write-OK "credentials.txt updated."
    }

    # Step 5: Restart Keycloak
    Write-Host "  Restarting Keycloak..." -ForegroundColor DarkGray
    docker compose --project-directory $Root restart keycloak 2>&1 | ForEach-Object { Write-Host "  $_" -ForegroundColor DarkGray }
    Write-OK "Keycloak restarted with new KC_DB_PASSWORD."

    Write-Host "`n  New KC_DB_PASSWORD : $newPass" -ForegroundColor Yellow
    Write-Host "  Stored in          : Vault (secret/admin/database), docker-compose.override.yml`n" -ForegroundColor DarkGray
}

# =============================================================================
# Interactive menu
# =============================================================================
# Action: Generate break-glass SecretID
# =============================================================================
function Invoke-GenerateBreakGlassSecretId {
    Write-Head "--- Generating a break-glass AppRole SecretID ---"
    Write-Host "  BREAK-GLASS credentials are for emergency use ONLY." -ForegroundColor Yellow
    Write-Host "  The generated SecretID never expires and has unlimited uses." -ForegroundColor Yellow
    Write-Host "  It will be written COMMENTED-OUT to .env and must be manually uncommented." -ForegroundColor Yellow
    Write-Host "  Every API startup using this credential logs CRITICAL in the API." -ForegroundColor Yellow
    Write-Host "  Revoke it in Vault and re-comment .env as soon as the incident is resolved." -ForegroundColor Yellow
    Write-Host ""

    $rootToken = Get-VaultRootToken
    Assert-VaultRunning

    # Generate a plain (non-wrapped) SecretID
    $secretJson = docker exec -e "VAULT_TOKEN=$rootToken" `
        securityapp-vault vault write -f auth/approle/role/securityapp-api/secret-id -format=json 2>&1 | Out-String

    $secretId       = ''
    $secretAccessor = ''
    try {
        $parsed         = $secretJson | ConvertFrom-Json
        $secretId       = $parsed.data.secret_id
        $secretAccessor = $parsed.data.secret_id_accessor
    } catch {
        if ($secretJson -match '"secret_id"\s*:\s*"([^"]+)"')          { $secretId       = $Matches[1] }
        if ($secretJson -match '"secret_id_accessor"\s*:\s*"([^"]+)"') { $secretAccessor = $Matches[1] }
    }

    if ([string]::IsNullOrWhiteSpace($secretId)) {
        Write-Fail "Failed to generate SecretID. Check: docker logs securityapp-vault"
    }
    Write-OK "Break-glass SecretID generated (TTL: never, uses: unlimited)."

    # Upsert break-glass block in .env
    $envFile    = Join-Path $Root '.env'
    $envContent = Get-Content $envFile -Raw

    $block = @"

# =============================================================================
# BREAK-GLASS: Emergency Vault authentication fallback
# Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm')
# HOW TO USE:
#   1. Uncomment VAULT_SECRET_ID below
#   2. docker compose --project-directory `$Root up -d api
#   3. Investigate and resolve the root cause
#   4. Re-comment VAULT_SECRET_ID, then run: .\scripts\vault-rotate.ps1 -Action RevokeBreakGlassSecretId
#      (revokes the SecretID in Vault and clears this block from .env)
# =============================================================================
# VAULT_SECRET_ID=$secretId
# VAULT_SECRET_ID_ACCESSOR=$secretAccessor
"@

    # Remove any previous break-glass block before writing the new one
    $envContent = $envContent -replace '(?ms)\r?\n# =============================================================================\r?\n# BREAK-GLASS:.*?# VAULT_SECRET_ID_ACCESSOR=[^\r\n]*', ''
    $envContent = $envContent.TrimEnd() + $block
    Set-Content -Path $envFile -Value $envContent -Encoding UTF8 -NoNewline
    Write-OK "Break-glass block written to .env (commented out)."

    Write-Host ""
    Write-Host "  SecretID:          $secretId" -ForegroundColor Cyan
    Write-Host "  SecretID Accessor: $secretAccessor" -ForegroundColor Cyan
    Write-Host "  Stored in .env as commented-out VAULT_SECRET_ID / VAULT_SECRET_ID_ACCESSOR" -ForegroundColor DarkGray
    Write-Host "  To activate: uncomment VAULT_SECRET_ID in .env, then restart the API." -ForegroundColor Yellow
    Write-Host "  To revoke after incident: .\scripts\vault-rotate.ps1 -Action RevokeBreakGlassSecretId" -ForegroundColor Yellow
    Write-Host ""
}

# =============================================================================
# Action: Revoke break-glass SecretID
# =============================================================================
function Invoke-RevokeBreakGlassSecretId {
    Write-Head "--- Revoking break-glass AppRole SecretID ---"

    $envFile    = Join-Path $Root '.env'
    $envContent = Get-Content $envFile -Raw

    # Extract accessor from the (possibly commented) .env line
    $accessor = ''
    if ($envContent -match '(?m)^#?\s*VAULT_SECRET_ID_ACCESSOR=(.+)$') {
        $accessor = $Matches[1].Trim()
    }

    if ([string]::IsNullOrWhiteSpace($accessor)) {
        Write-Warn "No VAULT_SECRET_ID_ACCESSOR found in .env. Nothing to revoke."
    } else {
        $rootToken = Get-VaultRootToken
        Assert-VaultRunning

        $result = docker exec -e "VAULT_TOKEN=$rootToken" `
            securityapp-vault vault write -f `
            "auth/approle/role/securityapp-api/secret-id-accessor/destroy" `
            "secret_id_accessor=$accessor" 2>&1 | Out-String

        if ($LASTEXITCODE -eq 0) {
            Write-OK "Break-glass SecretID (accessor: $accessor) has been destroyed in Vault."
        } else {
            Write-Warn "Vault revocation returned a non-zero exit code. Response:`n$result"
            Write-Host "  You may need to revoke manually: vault write auth/approle/role/securityapp-api/secret-id-accessor/destroy secret_id_accessor=$accessor" -ForegroundColor Yellow
        }
    }

    # Remove break-glass block from .env regardless
    $envContent = $envContent -replace '(?ms)\r?\n# =============================================================================\r?\n# BREAK-GLASS:.*?# VAULT_SECRET_ID_ACCESSOR=[^\r\n]*', ''
    Set-Content -Path $envFile -Value $envContent.TrimEnd() -Encoding UTF8 -NoNewline
    Write-OK "Break-glass block removed from .env."

    Write-Host ""
    Write-Host "  Run .\scripts\vault-rotate.ps1 -Action RefreshSecretId to restore normal wrap-token auth." -ForegroundColor Cyan
    Write-Host ""
}

# =============================================================================
function Show-Menu {
    Write-Host ""
    Write-Host "+==================================================+" -ForegroundColor Cyan
    Write-Host "|    SecurityApp - Vault Management                |" -ForegroundColor Cyan
    Write-Host "+==================================================+" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  [1]  Refresh AppRole SecretID (restart API with fresh credentials)" -ForegroundColor White
    Write-Host "  [7]  Generate break-glass SecretID (emergency fallback -- stores in .env commented out)" -ForegroundColor Yellow
    Write-Host "  [8]  Revoke break-glass SecretID (destroys in Vault + clears .env after incident)" -ForegroundColor Yellow
    Write-Host "  [2]  Update an application secret (DB conn str, RabbitMQ pass, etc.)" -ForegroundColor White
    Write-Host "  [3]  View current application secrets" -ForegroundColor White
    Write-Host "  [5]  Rotate Keycloak DB password (Phase 5 - update SQL Server + Vault + override)" -ForegroundColor White
    Write-Host "  [6]  Revoke root token (hardening - restart token takes over permanently)" -ForegroundColor White
    Write-Host "  [4]  Rotate legacy service-account token (pre-AppRole deployments)" -ForegroundColor DarkGray
    Write-Host "  [Q]  Quit" -ForegroundColor White
    Write-Host ""
    $choice = Read-Host "  Choice"

    switch ($choice) {
        '1' { Invoke-RefreshSecretId }
        '7' { Invoke-GenerateBreakGlassSecretId }
        '8' { Invoke-RevokeBreakGlassSecretId }
        '2' { Invoke-UpdateSecret -Key $SecretKey -Value $SecretValue }
        '3' { Invoke-ViewSecrets   }
        '4' { Invoke-RotateToken   }
        '5' { Invoke-RotateKcDbPassword }
        '6' { Invoke-RevokeRootToken }
        'q' { Write-Host "  Bye."; exit 0 }
        'Q' { Write-Host "  Bye."; exit 0 }
        default { Write-Warn "Unknown choice '$choice'."; Show-Menu }
    }
}

# =============================================================================
# Entry point
# =============================================================================
switch ($Action) {
    'RotateToken'        { Invoke-RotateToken }
    'UpdateSecret'       { Invoke-UpdateSecret -Key $SecretKey -Value $SecretValue }
    'ViewSecrets'        { Invoke-ViewSecrets }
    'RefreshSecretId'              { Invoke-RefreshSecretId }
    'GenerateBreakGlassSecretId'   { Invoke-GenerateBreakGlassSecretId }
    'RevokeBreakGlassSecretId'     { Invoke-RevokeBreakGlassSecretId }
    'RotateKcDbPassword' { Invoke-RotateKcDbPassword }
    'RevokeRootToken'    { Invoke-RevokeRootToken }
    'Menu'               { Show-Menu }
}
