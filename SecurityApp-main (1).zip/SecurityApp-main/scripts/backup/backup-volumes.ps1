<#
.SYNOPSIS
    Backup Docker volumes for SecurityApp infrastructure
.DESCRIPTION
    Creates timestamped backups of all Docker volumes (PostgreSQL, RabbitMQ, Redis, Azurite)
    Backups are saved as .tar.gz files in C:\docker-backups\
.PARAMETER BackupPath
    Custom backup directory path (default: C:\docker-backups)
.PARAMETER StopContainers
    Stop containers before backup for data consistency (default: true)
.EXAMPLE
    .\backup-volumes.ps1
.EXAMPLE
    .\backup-volumes.ps1 -BackupPath "D:\my-backups" -StopContainers $false
#>

param(
    [string]$BackupPath = "C:\docker-backups",
    [bool]$StopContainers = $true
)

# Color output functions
function Write-Success { Write-Host $args -ForegroundColor Green }
function Write-Info { Write-Host $args -ForegroundColor Cyan }
function Write-Warning { Write-Host $args -ForegroundColor Yellow }
function Write-Failure { Write-Host $args -ForegroundColor Red }

# Header
Write-Host ""
Write-Host "+=========================================================+" -ForegroundColor Blue
Write-Host "|   SecurityApp Docker Volume Backup                      |" -ForegroundColor Blue
Write-Host "+=========================================================+" -ForegroundColor Blue
Write-Host ""

# Create timestamped backup directory
$timestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$backupDir = Join-Path $BackupPath $timestamp

Write-Info "Creating backup directory: $backupDir"
try {
    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
    Write-Success "✓ Backup directory created"
} catch {
    Write-Failure "✗ Failed to create backup directory: $_"
    exit 1
}

# Check if Docker is running
Write-Info "Checking Docker status..."
try {
    docker ps | Out-Null
    Write-Success "✓ Docker is running"
} catch {
    Write-Failure "✗ Docker is not running. Please start Docker Desktop."
    exit 1
}

# Stop containers if requested
$containersWereStopped = $false
if ($StopContainers) {
    Write-Warning "Stopping containers for consistent backup..."
    try {
        docker compose down 2>&1 | Out-Null
        $containersWereStopped = $true
        Write-Success "[OK] Containers stopped"
    } catch {
        Write-Warning "Warning: Could not stop containers: $_"
        Write-Info "Continuing with backup (may have inconsistent data)..."
    }
}

# Define volumes to backup
$volumes = @(
    @{ Name = "securityapp_postgres_data";  File = "postgres_backup.tar.gz";  Description = "PostgreSQL Database" },
    @{ Name = "securityapp_sqlserver_data"; File = "sqlserver_backup.tar.gz"; Description = "SQL Server Database" },
    @{ Name = "securityapp_mysql_data";     File = "mysql_backup.tar.gz";     Description = "MySQL Database" },
    @{ Name = "securityapp_rabbitmq_data";  File = "rabbitmq_backup.tar.gz";  Description = "RabbitMQ Messages" },
    @{ Name = "securityapp_redis_data";     File = "redis_backup.tar.gz";     Description = "Redis Cache" },
    @{ Name = "securityapp_vault_data";     File = "vault_backup.tar.gz";     Description = "Vault Secrets" },
    @{ Name = "securityapp_azurite_data";   File = "azurite_backup.tar.gz";   Description = "Azurite Blob Storage" }
)

Write-Host ""
Write-Info "Backing up volumes..."
Write-Host ""

$successCount = 0
$failCount = 0

foreach ($volume in $volumes) {
    $volumeName = $volume.Name
    $fileName = $volume.File
    $description = $volume.Description
    $outputPath = Join-Path $backupDir $fileName
    
    Write-Host "  Backing up: " -NoNewline
    Write-Host "$description" -ForegroundColor White -NoNewline
    Write-Host " ($volumeName)" -ForegroundColor DarkGray
    
    try {
        # Check if volume exists
        $volumeExists = docker volume ls --format "{{.Name}}" | Select-String -Pattern "^$volumeName$"
        
        if (-not $volumeExists) {
            Write-Warning "  [SKIP] Volume not found: $volumeName (skipping)"
            $failCount++
            continue
        }
        
        # Backup volume using alpine container
        $result = docker run --rm `
            -v "${volumeName}:/data" `
            -v "${backupDir}:/backup" `
            alpine tar czf "/backup/$fileName" -C /data . 2>&1
        
        if ($LASTEXITCODE -eq 0) {
            # Get file size
            $fileInfo = Get-Item $outputPath
            $sizeMB = [math]::Round($fileInfo.Length / 1MB, 2)
            Write-Success "  [OK] Backed up successfully ($sizeMB MB)"
            $successCount++
        } else {
            Write-Failure "  [FAIL] Backup failed: $result"
            $failCount++
        }
    } catch {
        Write-Failure "  ✗ Error: $_"
        $failCount++
    }
}

# Restart containers if they were stopped
if ($containersWereStopped) {
    Write-Host ""
    Write-Info "Restarting containers..."
    try {
        docker compose up -d 2>&1 | Out-Null
        Write-Success "[OK] Containers restarted"
    } catch {
        Write-Warning "Warning: Could not restart containers: $_"
        Write-Info "Run 'docker compose up -d' manually to start containers"
    }
}

# Summary
Write-Host ""
Write-Host "+=========================================================+" -ForegroundColor Blue
Write-Host "|   Backup Summary                                        |" -ForegroundColor Blue
Write-Host "+=========================================================+" -ForegroundColor Blue
Write-Host ""

if ($failCount -eq 0) {
    Write-Success "All backups completed successfully!"
} else {
    Write-Warning "$successCount successful, $failCount failed"
}

Write-Host ""
Write-Info "Backup Location: $backupDir"
Write-Host ""

# List backup files
Write-Info "Backup Files:"
Get-ChildItem $backupDir -Filter *.tar.gz | ForEach-Object {
    $sizeMB = [math]::Round($_.Length / 1MB, 2)
    Write-Host "  • $($_.Name)" -NoNewline
    Write-Host " ($sizeMB MB)" -ForegroundColor DarkGray
}

# Total size
$totalSize = (Get-ChildItem $backupDir -Filter *.tar.gz | Measure-Object -Property Length -Sum).Sum
$totalSizeMB = [math]::Round($totalSize / 1MB, 2)
Write-Host ""
Write-Info "Total Backup Size: $totalSizeMB MB"

# Next steps
Write-Host ""
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Blue
Write-Info "To restore from this backup, run:"
Write-Host ""
Write-Host "  .\scripts\backup\restore-volumes.ps1 -BackupPath `"$backupDir`"" -ForegroundColor Yellow
Write-Host ""
Write-Host "═══════════════════════════════════════════════════════════" -ForegroundColor Blue
Write-Host ""

# Exit with appropriate code
exit $failCount
