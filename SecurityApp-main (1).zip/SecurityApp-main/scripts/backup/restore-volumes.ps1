<#
.SYNOPSIS
    Restore Docker volumes for SecurityApp infrastructure
.DESCRIPTION
    Restores Docker volumes from backup files created by backup-volumes.ps1
    WARNING: This will DELETE existing volumes and restore from backup!
.PARAMETER BackupPath
    Path to the backup directory containing .tar.gz files (required)
.PARAMETER Force
    Skip confirmation prompts (use with caution!)
.EXAMPLE
    .\restore-volumes.ps1 -BackupPath "C:\docker-backups\2026-03-16_23-30-00"
.EXAMPLE
    .\restore-volumes.ps1 -BackupPath "C:\docker-backups\2026-03-16_23-30-00" -Force
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$BackupPath,
    
    [switch]$Force
)

# Color output functions
function Write-Success { Write-Host $args -ForegroundColor Green }
function Write-Info { Write-Host $args -ForegroundColor Cyan }
function Write-Warning { Write-Host $args -ForegroundColor Yellow }
function Write-Failure { Write-Host $args -ForegroundColor Red }

# Header
Write-Host ""
Write-Host "+=========================================================+" -ForegroundColor Blue
Write-Host "|   SecurityApp Docker Volume Restore                     |" -ForegroundColor Blue
Write-Host "+=========================================================+" -ForegroundColor Blue
Write-Host ""

# Validate backup path
if (-not (Test-Path $BackupPath)) {
    Write-Failure "✗ Backup path not found: $BackupPath"
    Write-Info "Please provide a valid backup directory path."
    exit 1
}

Write-Info "Backup Location: $BackupPath"
Write-Host ""

# List available backup files
Write-Info "Available Backup Files:"
$backupFiles = Get-ChildItem $BackupPath -Filter *.tar.gz
if ($backupFiles.Count -eq 0) {
    Write-Failure "✗ No backup files (.tar.gz) found in $BackupPath"
    exit 1
}

foreach ($file in $backupFiles) {
    $sizeMB = [math]::Round($file.Length / 1MB, 2)
    Write-Host "  - $($file.Name)" -NoNewline
    Write-Host " ($sizeMB MB)" -ForegroundColor DarkGray
}

Write-Host ""

# Warning
Write-Warning "WARNING: This operation will:"
Write-Warning "  1. Stop all running containers"
Write-Warning "  2. DELETE existing volumes (all current data will be lost!)"
Write-Warning "  3. Restore volumes from backup files"
Write-Warning "  4. Restart containers"
Write-Host ""

# Confirmation
if (-not $Force) {
    $confirmation = Read-Host "Are you sure you want to continue? (yes/no)"
    if ($confirmation -ne "yes") {
        Write-Info "Restore cancelled."
        exit 0
    }
}

# Check if Docker is running
Write-Info "Checking Docker status..."
try {
    docker ps | Out-Null
    Write-Success "[OK] Docker is running"
} catch {
    Write-Failure "[FAIL] Docker is not running. Please start Docker Desktop."
    exit 1
}

# Stop containers
Write-Host ""
Write-Info "Stopping containers..."
try {
    docker compose down 2>&1 | Out-Null
    Write-Success "[OK] Containers stopped"
} catch {
    Write-Warning "Warning: Could not stop containers: $_"
}

# Define volumes to restore
$volumes = @(
    @{ Name = "securityapp_postgres_data";  File = "postgres_backup.tar.gz";  Description = "PostgreSQL Database" },
    @{ Name = "securityapp_sqlserver_data"; File = "sqlserver_backup.tar.gz"; Description = "SQL Server Database" },
    @{ Name = "securityapp_mysql_data";     File = "mysql_backup.tar.gz";     Description = "MySQL Database" },
    @{ Name = "securityapp_rabbitmq_data";  File = "rabbitmq_backup.tar.gz";  Description = "RabbitMQ Messages" },
    @{ Name = "securityapp_redis_data";     File = "redis_backup.tar.gz";     Description = "Redis Cache" },
    @{ Name = "securityapp_vault_data";     File = "vault_backup.tar.gz";     Description = "Vault Secrets" },
    @{ Name = "securityapp_azurite_data";   File = "azurite_backup.tar.gz";   Description = "Azurite Blob Storage" }
)

Write-Host ""
Write-Info "Restoring volumes..."
Write-Host ""

$successCount = 0
$failCount = 0

foreach ($volume in $volumes) {
    $volumeName = $volume.Name
    $fileName = $volume.File
    $description = $volume.Description
    $backupFile = Join-Path $BackupPath $fileName
    
    Write-Host "  Restoring: " -NoNewline
    Write-Host "$description" -ForegroundColor White -NoNewline
    Write-Host " ($volumeName)" -ForegroundColor DarkGray
    
    try {
        # Check if backup file exists
        if (-not (Test-Path $backupFile)) {
            Write-Warning "  [SKIP] Backup file not found: $fileName (skipping)"
            $failCount++
            continue
        }
        
        # Remove existing volume if it exists
        Write-Host "    Removing existing volume..." -ForegroundColor DarkGray
        docker volume rm $volumeName -f 2>&1 | Out-Null
        
        # Create fresh volume
        Write-Host "    Creating new volume..." -ForegroundColor DarkGray
        docker volume create $volumeName 2>&1 | Out-Null
        
        if ($LASTEXITCODE -ne 0) {
            Write-Failure "  ✗ Failed to create volume"
            $failCount++
            continue
        }
        
        # Restore from backup
        Write-Host "    Extracting backup data..." -ForegroundColor DarkGray
        $result = docker run --rm `
            -v "${volumeName}:/data" `
            -v "${BackupPath}:/backup" `
            alpine tar xzf "/backup/$fileName" -C /data 2>&1
        
        if ($LASTEXITCODE -eq 0) {
            Write-Success "  [OK] Restored successfully"
            $successCount++
        } else {
            Write-Failure "  [FAIL] Restore failed: $result"
            $failCount++
        }
    } catch {
        Write-Failure "  ✗ Error: $_"
        $failCount++
    }
}

# Restart containers
Write-Host ""
Write-Info "Starting containers..."
try {
    docker compose up -d 2>&1 | Out-Null
    Start-Sleep -Seconds 5
    Write-Success "[OK] Containers started"
} catch {
    Write-Warning "Warning: Could not start containers: $_"
    Write-Info "Run 'docker compose up -d' manually to start containers"
}

# Verify containers
Write-Host ""
Write-Info "Verifying container health..."
Start-Sleep -Seconds 10

try {
    $containers = docker ps --filter "name=securityapp-" --format "table {{.Names}}\t{{.Status}}"
    if ($containers) {
        Write-Success "[OK] Containers running:"
        $containers | ForEach-Object {
            $parts = $_ -split "`t"
            Write-Host "  - $($parts[0])" -NoNewline
            Write-Host " - $($parts[1])" -ForegroundColor DarkGray
        }
    } else {
        Write-Warning "No containers found running"
    }
} catch {
    Write-Warning "Could not verify containers"
}

# Summary
Write-Host ""
Write-Host "+=========================================================+" -ForegroundColor Blue
Write-Host "|   Restore Summary                                       |" -ForegroundColor Blue
Write-Host "+=========================================================+" -ForegroundColor Blue
Write-Host ""

if ($failCount -eq 0) {
    Write-Success "All volumes restored successfully!"
} else {
    Write-Warning "$successCount successful, $failCount failed"
}

# Verification commands
Write-Host ""
Write-Info "Verification Commands:"
Write-Host ""
Write-Host "  # Check PostgreSQL data" -ForegroundColor Yellow
Write-Host "  docker exec -it securityapp-postgres psql -U securityapp -d securityapp_db -c `"\dt`""
Write-Host ""
Write-Host "  # Check Redis data" -ForegroundColor Yellow
Write-Host "  docker exec -it securityapp-redis redis-cli DBSIZE"
Write-Host ""
Write-Host "  # Check RabbitMQ queues" -ForegroundColor Yellow
Write-Host "  docker exec -it securityapp-rabbitmq rabbitmqctl list_queues"
Write-Host ""
Write-Host "  # Test API health" -ForegroundColor Yellow
Write-Host "  curl https://localhost:7256/health"
Write-Host ""

Write-Host "+=========================================================+" -ForegroundColor Blue
Write-Host ""

# Exit with appropriate code
exit $failCount
