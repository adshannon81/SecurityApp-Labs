param(
    [string]$Configuration = "Release"
)

$ErrorActionPreference = "Stop"
$RepoRoot = Split-Path -Parent $PSScriptRoot
$DropDir  = Join-Path $RepoRoot "plugins"

$plugins = @(
    @{ Name = "AlphaVantagePlugin";             Project = "plugins\src\AlphaVantagePlugin\AlphaVantagePlugin.csproj"                               },
    @{ Name = "FlatFilePlugin";                 Project = "plugins\src\FlatFilePlugin\FlatFilePlugin.csproj"                                       },
    @{ Name = "CreditFunctionsPlugin";          Project = "plugins\src\CreditFunctionsPlugin\CreditFunctionsPlugin.csproj"                         },
    @{ Name = "MacroRiskPlugin";                Project = "plugins\src\MacroRiskPlugin\MacroRiskPlugin.csproj"                                     },
    # Job plugins
    @{ Name = "SecurityUpdateJobPlugin";        Project = "plugins\src\SecurityUpdateJobPlugin\SecurityUpdateJobPlugin.csproj"                     },
    @{ Name = "ExecutionHistoryCleanupJobPlugin"; Project = "plugins\src\ExecutionHistoryCleanupJobPlugin\ExecutionHistoryCleanupJobPlugin.csproj" },
    @{ Name = "AuditArchiveJobPlugin";          Project = "plugins\src\AuditArchiveJobPlugin\AuditArchiveJobPlugin.csproj"                         },
    @{ Name = "ScriptRunnerJobPlugin";          Project = "plugins\src\ScriptRunnerJobPlugin\ScriptRunnerJobPlugin.csproj"                         }
)

foreach ($plugin in $plugins) {
    $projectPath = Join-Path $RepoRoot $plugin.Project
    $binDir      = Join-Path $RepoRoot "plugins\bin\$($plugin.Name)"

    Write-Host ""
    Write-Host "==> Building $($plugin.Name) ($Configuration)..." -ForegroundColor Cyan
    dotnet build $projectPath -c $Configuration --nologo
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Build failed for $($plugin.Name)"
    }

    # Deploy into a dedicated subfolder so PluginLoadContext can find deps.json
    # and resolve any plugin-specific dependencies via AssemblyDependencyResolver.
    $pluginDropDir = Join-Path $DropDir $plugin.Name
    if (Test-Path $pluginDropDir) { Remove-Item $pluginDropDir -Recurse -Force }
    New-Item -ItemType Directory -Path $pluginDropDir | Out-Null

    Write-Host "==> Deploying $($plugin.Name) to $pluginDropDir ..." -ForegroundColor Cyan

    # Copy everything from bin EXCEPT SecurityApp.Core/Application/Infrastructure
    # (already loaded by host — copying them causes type identity conflicts in ALC)
    Get-ChildItem $binDir | Where-Object {
        $_.Name -notlike "SecurityApp.Core*"          -and
        $_.Name -notlike "SecurityApp.Application*"   -and
        $_.Name -notlike "SecurityApp.Infrastructure*"
    } | ForEach-Object {
        Copy-Item $_.FullName $pluginDropDir -Force
        Write-Host "    Copied $($_.Name)" -ForegroundColor DarkGreen
    }
}

Write-Host ""
Write-Host "All plugins built and staged in: $DropDir" -ForegroundColor Green


