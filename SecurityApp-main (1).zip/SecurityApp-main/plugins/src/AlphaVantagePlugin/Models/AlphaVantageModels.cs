using System.Text.Json.Serialization;

namespace SecurityApp.Plugin.AlphaVantage.Models;

// SYMBOL_SEARCH response
public class SymbolSearchResponse
{
    [JsonPropertyName("bestMatches")]
    public List<SymbolMatch>? BestMatches { get; set; }
}

public class SymbolMatch
{
    [JsonPropertyName("1. symbol")]
    public string Symbol { get; set; } = string.Empty;

    [JsonPropertyName("2. name")]
    public string Name { get; set; } = string.Empty;

    [JsonPropertyName("3. type")]
    public string Type { get; set; } = string.Empty;

    [JsonPropertyName("4. region")]
    public string Region { get; set; } = string.Empty;

    [JsonPropertyName("5. marketOpen")]
    public string MarketOpen { get; set; } = string.Empty;

    [JsonPropertyName("6. marketClose")]
    public string MarketClose { get; set; } = string.Empty;

    [JsonPropertyName("7. timezone")]
    public string Timezone { get; set; } = string.Empty;

    [JsonPropertyName("8. currency")]
    public string Currency { get; set; } = string.Empty;

    [JsonPropertyName("9. matchScore")]
    public string MatchScore { get; set; } = string.Empty;
}

// OVERVIEW response
public class CompanyOverviewResponse
{
    [JsonPropertyName("Symbol")]
    public string Symbol { get; set; } = string.Empty;

    [JsonPropertyName("AssetType")]
    public string AssetType { get; set; } = string.Empty;

    [JsonPropertyName("Name")]
    public string Name { get; set; } = string.Empty;

    [JsonPropertyName("Description")]
    public string Description { get; set; } = string.Empty;

    [JsonPropertyName("Exchange")]
    public string Exchange { get; set; } = string.Empty;

    [JsonPropertyName("Currency")]
    public string Currency { get; set; } = string.Empty;

    [JsonPropertyName("Country")]
    public string Country { get; set; } = string.Empty;

    [JsonPropertyName("Sector")]
    public string Sector { get; set; } = string.Empty;

    [JsonPropertyName("Industry")]
    public string Industry { get; set; } = string.Empty;

    [JsonPropertyName("Address")]
    public string Address { get; set; } = string.Empty;

    [JsonPropertyName("DividendYield")]
    public string DividendYield { get; set; } = string.Empty;

    [JsonPropertyName("52WeekHigh")]
    public string WeekHigh52 { get; set; } = string.Empty;

    [JsonPropertyName("52WeekLow")]
    public string WeekLow52 { get; set; } = string.Empty;

    [JsonPropertyName("Information")]
    public string? Information { get; set; }

    [JsonPropertyName("Note")]
    public string? Note { get; set; }
}

// GLOBAL_QUOTE response
public class GlobalQuoteResponse
{
    [JsonPropertyName("Global Quote")]
    public GlobalQuote? GlobalQuote { get; set; }

    [JsonPropertyName("Information")]
    public string? Information { get; set; }

    [JsonPropertyName("Note")]
    public string? Note { get; set; }
}

public class GlobalQuote
{
    [JsonPropertyName("01. symbol")]
    public string Symbol { get; set; } = string.Empty;

    [JsonPropertyName("02. open")]
    public string Open { get; set; } = string.Empty;

    [JsonPropertyName("03. high")]
    public string High { get; set; } = string.Empty;

    [JsonPropertyName("04. low")]
    public string Low { get; set; } = string.Empty;

    [JsonPropertyName("05. price")]
    public string Price { get; set; } = string.Empty;

    [JsonPropertyName("06. volume")]
    public string Volume { get; set; } = string.Empty;

    [JsonPropertyName("07. latest trading day")]
    public string LatestTradingDay { get; set; } = string.Empty;

    [JsonPropertyName("08. previous close")]
    public string PreviousClose { get; set; } = string.Empty;

    [JsonPropertyName("09. change")]
    public string Change { get; set; } = string.Empty;

    [JsonPropertyName("10. change percent")]
    public string ChangePercent { get; set; } = string.Empty;
}

// TIME_SERIES_DAILY response
public class TimeSeriesDailyResponse
{
    [JsonPropertyName("Meta Data")]
    public Dictionary<string, string>? MetaData { get; set; }

    [JsonPropertyName("Time Series (Daily)")]
    public Dictionary<string, DailyPriceData>? TimeSeries { get; set; }

    [JsonPropertyName("Information")]
    public string? Information { get; set; }

    [JsonPropertyName("Note")]
    public string? Note { get; set; }
}

public class DailyPriceData
{
    [JsonPropertyName("1. open")]
    public string Open { get; set; } = string.Empty;

    [JsonPropertyName("2. high")]
    public string High { get; set; } = string.Empty;

    [JsonPropertyName("3. low")]
    public string Low { get; set; } = string.Empty;

    [JsonPropertyName("4. close")]
    public string Close { get; set; } = string.Empty;

    [JsonPropertyName("5. volume")]
    public string Volume { get; set; } = string.Empty;
}
