using Microsoft.Extensions.Logging;
using SecurityApp.Plugin.AlphaVantage.Models;
using System.Net.Http.Json;

namespace SecurityApp.Plugin.AlphaVantage;

/// <summary>
/// Low-level HTTP client for the Alpha Vantage API.
/// Free tier: 25 requests/day. Use apiKey = "demo" for limited IBM data.
/// </summary>
public class AlphaVantageClient
{
    private readonly HttpClient _httpClient;
    private readonly string _apiKey;
    private readonly ILogger<AlphaVantageClient> _logger;
    private readonly int _maxRetryAttempts;

    public AlphaVantageClient(HttpClient httpClient, string apiKey, ILogger<AlphaVantageClient> logger, int maxRetryAttempts = 3)
    {
        _httpClient = httpClient;
        _apiKey = apiKey;
        _logger = logger;
        _maxRetryAttempts = maxRetryAttempts;
    }

    public async Task<SymbolSearchResponse?> SearchSymbolAsync(string keywords, CancellationToken cancellationToken = default)
    {
        var url = $"query?function=SYMBOL_SEARCH&keywords={Uri.EscapeDataString(keywords)}&apikey={_apiKey}";
        _logger.LogDebug("AlphaVantage SYMBOL_SEARCH: {Keywords}", keywords);
        return await GetAsync<SymbolSearchResponse>(url, cancellationToken);
    }

    public async Task<CompanyOverviewResponse?> GetOverviewAsync(string symbol, CancellationToken cancellationToken = default)
    {
        var url = $"query?function=OVERVIEW&symbol={Uri.EscapeDataString(symbol)}&apikey={_apiKey}";
        _logger.LogDebug("AlphaVantage OVERVIEW: {Symbol}", symbol);
        return await GetAsync<CompanyOverviewResponse>(url, cancellationToken);
    }

    public async Task<GlobalQuoteResponse?> GetGlobalQuoteAsync(string symbol, CancellationToken cancellationToken = default)
    {
        var url = $"query?function=GLOBAL_QUOTE&symbol={Uri.EscapeDataString(symbol)}&apikey={_apiKey}";
        _logger.LogDebug("AlphaVantage GLOBAL_QUOTE: {Symbol}", symbol);
        return await GetAsync<GlobalQuoteResponse>(url, cancellationToken);
    }

    public async Task<TimeSeriesDailyResponse?> GetTimeSeriesDailyAsync(string symbol, CancellationToken cancellationToken = default)
    {
        var url = $"query?function=TIME_SERIES_DAILY&symbol={Uri.EscapeDataString(symbol)}&outputsize=compact&apikey={_apiKey}";
        _logger.LogDebug("AlphaVantage TIME_SERIES_DAILY: {Symbol}", symbol);
        return await GetAsync<TimeSeriesDailyResponse>(url, cancellationToken);
    }

    private async Task<T?> GetAsync<T>(string url, CancellationToken cancellationToken)
    {
        var delay = TimeSpan.FromSeconds(2);

        for (int attempt = 1; attempt <= _maxRetryAttempts; attempt++)
        {
            try
            {
                var response = await _httpClient.GetAsync(url, cancellationToken);

                if (response.StatusCode == System.Net.HttpStatusCode.TooManyRequests && attempt < _maxRetryAttempts)
                {
                    var retryAfter = response.Headers.RetryAfter?.Delta ?? delay;
                    _logger.LogWarning(
                        "AlphaVantage rate-limited; retrying after {Delay:F1}s (attempt {Attempt}/{Max})",
                        retryAfter.TotalSeconds, attempt, _maxRetryAttempts);
                    await Task.Delay(retryAfter + Jitter(retryAfter), cancellationToken);
                    delay = TimeSpan.FromTicks(delay.Ticks * 2);
                    continue;
                }

                response.EnsureSuccessStatusCode();
                return await response.Content.ReadFromJsonAsync<T>(cancellationToken: cancellationToken);
            }
            catch (HttpRequestException ex) when (attempt < _maxRetryAttempts)
            {
                _logger.LogWarning(ex,
                    "AlphaVantage request failed (attempt {Attempt}/{Max}); retrying in {Delay:F1}s",
                    attempt, _maxRetryAttempts, delay.TotalSeconds);
                await Task.Delay(delay + Jitter(delay), cancellationToken);
                delay = TimeSpan.FromTicks(delay.Ticks * 2);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "AlphaVantage API request failed: {Url}", url);
                return default;
            }
        }

        _logger.LogError("AlphaVantage API request failed after {Max} attempts: {Url}", _maxRetryAttempts, url);
        return default;
    }

    private static TimeSpan Jitter(TimeSpan delay) =>
        TimeSpan.FromMilliseconds(Random.Shared.Next(0, (int)(delay.TotalMilliseconds * 0.5)));
}
