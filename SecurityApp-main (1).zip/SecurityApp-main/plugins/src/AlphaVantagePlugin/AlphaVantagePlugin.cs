﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using SecurityApp.Core.Plugins.Interfaces;
using SecurityApp.Core.Shared.Enums;

namespace SecurityApp.Plugin.AlphaVantage;

/// <summary>
/// Plugin entry point for the Alpha Vantage connector.
/// The PluginLoader discovers this class by scanning for IConnectorPlugin implementations.
/// </summary>
public class AlphaVantagePlugin : IConnectorPlugin
{
    private AlphaVantageConnector? _connector;
    private bool _disposed;

    public PluginMetadata Metadata => new()
    {
        Name = "AlphaVantage",
        Version = "1.0.0",
        Author = "SecurityApp",
        Description = "Alpha Vantage free-tier market data connector (equities, FX, crypto).",
        ConnectorType = DataSourceType.AlphaVantage
    };

    public bool IsCompatible() => true;

    public Task InitializeAsync(IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        var config = (IConfiguration?)serviceProvider.GetService(typeof(IConfiguration))
                     ?? throw new InvalidOperationException("IConfiguration not available in plugin service provider.");

        var section = config.GetSection("DataConnectors:AlphaVantage");
        var apiKey = section["ApiKey"];
        if (string.IsNullOrEmpty(apiKey))
            throw new InvalidOperationException(
                "DataConnectors:AlphaVantage:ApiKey is required. " +
                "Set it via environment variable, dotnet user-secrets, or Vault (DataConnectors__AlphaVantage__ApiKey).");

        var baseUrl = section["BaseUrl"];
        if (string.IsNullOrEmpty(baseUrl))
            throw new InvalidOperationException(
                "DataConnectors:AlphaVantage:BaseUrl is required. " +
                "Expected value: https://www.alphavantage.co/");
        var timeoutSeconds = section.GetValue<int>("TimeoutSeconds", 30);
        var maxRetries = section.GetValue<int>("MaxRetries", 3);

        var httpClient = new HttpClient
        {
            BaseAddress = new Uri(baseUrl),
            Timeout = TimeSpan.FromSeconds(timeoutSeconds)
        };

        // Try to resolve a typed logger from the host; fall back to NullLogger if not available.
        var loggerFactory = (ILoggerFactory?)serviceProvider.GetService(typeof(ILoggerFactory))
                            ?? NullLoggerFactory.Instance;

        var clientLogger = loggerFactory.CreateLogger<AlphaVantageClient>();
        var connectorLogger = loggerFactory.CreateLogger<AlphaVantageConnector>();

        var client = new AlphaVantageClient(httpClient, apiKey, clientLogger, maxRetries);
        _connector = new AlphaVantageConnector(client, connectorLogger);

        return Task.CompletedTask;
    }

    /// <summary>
    /// Returns the AlphaVantageConnector which implements both ISecurityDataProvider and IPricingDataProvider.
    /// Cast as needed: <c>plugin.GetConnector() as ISecurityDataProvider</c>
    /// </summary>
    public IDataConnector GetConnector()
    {
        if (_connector == null)
            throw new InvalidOperationException("AlphaVantagePlugin has not been initialized. Call InitializeAsync first.");
        return _connector;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        // HttpClient created here; nothing else to dispose.
    }
}
