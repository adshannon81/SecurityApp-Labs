﻿using Microsoft.Extensions.Logging;
using SecurityApp.Plugin.AlphaVantage.Models;
using SecurityApp.Core.Securities.Interfaces;
using SecurityApp.Core.Pricing.Interfaces;
using SecurityApp.Core.Shared.Enums;
using SecurityApp.Core.Plugins.Interfaces;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Securities.Models;
using SecurityApp.Core.Pricing.Models;

namespace SecurityApp.Plugin.AlphaVantage;

/// <summary>
/// Combined connector implementing both ISecurityDataProvider and IPricingDataProvider.
/// A single instance is returned by AlphaVantagePlugin.GetConnector() and can be cast
/// to either interface by the DataProviderService.
/// </summary>
public class AlphaVantageConnector : ISecurityDataProvider, IPricingDataProvider
{
    private readonly AlphaVantageClient _client;
    private readonly ILogger<AlphaVantageConnector> _logger;

    // IDataConnector
    public DataSourceType SourceType => DataSourceType.AlphaVantage;
    public string SourceName => "AlphaVantage";

    // ISecurityDataProvider / IPricingDataProvider
    public int Priority => 50;

    public AlphaVantageConnector(AlphaVantageClient client, ILogger<AlphaVantageConnector> logger)
    {
        _client = client;
        _logger = logger;
    }

    // ------------------------------------------
    // IDataConnector
    // ------------------------------------------

    public async Task<bool> IsAvailableAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            var result = await _client.GetGlobalQuoteAsync("IBM", cancellationToken);
            return result != null && result.Information == null && result.Note == null;
        }
        catch
        {
            return false;
        }
    }

    public async Task<HealthStatus> GetHealthStatusAsync(CancellationToken cancellationToken = default)
    {
        var isAvailable = await IsAvailableAsync(cancellationToken);
        return new HealthStatus
        {
            IsHealthy = isAvailable,
            Message = isAvailable
                ? "Alpha Vantage API is reachable."
                : "Alpha Vantage API unavailable or rate-limited.",
            CheckedAt = DateTime.UtcNow
        };
    }

    // ------------------------------------------
    // ISecurityDataProvider
    // ------------------------------------------

    public bool SupportsIdentifierType(IdentifierType identifierType) =>
        identifierType is IdentifierType.Ticker or IdentifierType.Other;

    public async Task<ExternalSecurityData?> GetSecurityAsync(
        string identifierValue,
        IdentifierType identifierType,
        CancellationToken cancellationToken = default)
    {
        var overview = await _client.GetOverviewAsync(identifierValue, cancellationToken);

        if (overview == null || string.IsNullOrWhiteSpace(overview.Symbol))
        {
            _logger.LogWarning("AlphaVantage: no overview found for {Identifier}", identifierValue);
            return null;
        }

        if (!string.IsNullOrWhiteSpace(overview.Information) || !string.IsNullOrWhiteSpace(overview.Note))
        {
            _logger.LogWarning("AlphaVantage rate limit or info message: {Msg}", overview.Information ?? overview.Note);
            return null;
        }

        return MapOverviewToExternalData(overview, identifierType, identifierValue);
    }

    public async Task<IEnumerable<ExternalSecurityData>> SearchSecuritiesAsync(
        string keyword,
        CancellationToken cancellationToken = default)
    {
        var searchResult = await _client.SearchSymbolAsync(keyword, cancellationToken);
        if (searchResult?.BestMatches == null)
            return Enumerable.Empty<ExternalSecurityData>();

        return searchResult.BestMatches.Select(m => new ExternalSecurityData
        {
            Symbol = m.Symbol,
            Name = m.Name,
            IdentifierType = IdentifierType.Ticker,
            IdentifierValue = m.Symbol,
            SecurityType = MapAssetType(m.Type),
            Currency = m.Currency,
            Exchange = m.Region,
            Source = DataSourceType.AlphaVantage,
            RawData = new Dictionary<string, string?>
            {
                ["Type"] = m.Type,
                ["Region"] = m.Region,
                ["MatchScore"] = m.MatchScore,
                ["MarketOpen"] = m.MarketOpen,
                ["MarketClose"] = m.MarketClose
            }
        });
    }

    // ------------------------------------------
    // IPricingDataProvider
    // ------------------------------------------

    public async Task<ExternalPriceData?> GetCurrentPriceAsync(
        string symbol,
        CancellationToken cancellationToken = default)
    {
        var response = await _client.GetGlobalQuoteAsync(symbol, cancellationToken);

        if (response?.GlobalQuote == null || string.IsNullOrWhiteSpace(response.GlobalQuote.Symbol))
        {
            _logger.LogWarning("AlphaVantage: no quote found for {Symbol}", symbol);
            return null;
        }

        if (!string.IsNullOrWhiteSpace(response.Information) || !string.IsNullOrWhiteSpace(response.Note))
        {
            _logger.LogWarning("AlphaVantage rate limit or info: {Msg}", response.Information ?? response.Note);
            return null;
        }

        var q = response.GlobalQuote;

        _ = decimal.TryParse(q.Price, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var price);
        _ = decimal.TryParse(q.Open, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var open);
        _ = decimal.TryParse(q.High, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var high);
        _ = decimal.TryParse(q.Low, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var low);
        _ = long.TryParse(q.Volume, out var volume);
        _ = DateTime.TryParse(q.LatestTradingDay, out var priceDate);

        return new ExternalPriceData
        {
            Symbol = q.Symbol,
            Price = price,
            PriceType = "Last",
            OpenPrice = open,
            HighPrice = high,
            LowPrice = low,
            Volume = volume,
            PriceDate = priceDate == default ? DateTime.UtcNow.Date : priceDate,
            Source = DataSourceType.AlphaVantage
        };
    }

    public async Task<IEnumerable<ExternalPriceData>> GetHistoricalPricesAsync(
        string symbol,
        DateTime fromDate,
        DateTime toDate,
        CancellationToken cancellationToken = default)
    {
        var response = await _client.GetTimeSeriesDailyAsync(symbol, cancellationToken);

        if (response?.TimeSeries == null)
        {
            _logger.LogWarning("AlphaVantage: no historical data for {Symbol}", symbol);
            return Enumerable.Empty<ExternalPriceData>();
        }

        if (!string.IsNullOrWhiteSpace(response.Information) || !string.IsNullOrWhiteSpace(response.Note))
        {
            _logger.LogWarning("AlphaVantage rate limit or info: {Msg}", response.Information ?? response.Note);
            return Enumerable.Empty<ExternalPriceData>();
        }

        var results = new List<ExternalPriceData>();

        foreach (var (dateStr, data) in response.TimeSeries)
        {
            if (!DateTime.TryParse(dateStr, out var date))
                continue;

            if (date < fromDate || date > toDate)
                continue;

            _ = decimal.TryParse(data.Close, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var close);
            _ = decimal.TryParse(data.Open, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var open);
            _ = decimal.TryParse(data.High, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var high);
            _ = decimal.TryParse(data.Low, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var low);
            _ = long.TryParse(data.Volume, out var volume);

            results.Add(new ExternalPriceData
            {
                Symbol = symbol,
                Price = close,
                PriceType = "Close",
                OpenPrice = open,
                HighPrice = high,
                LowPrice = low,
                Volume = volume,
                PriceDate = date,
                Source = DataSourceType.AlphaVantage
            });
        }

        return results.OrderByDescending(p => p.PriceDate);
    }

    // ------------------------------------------
    // Helpers
    // ------------------------------------------

    private static ExternalSecurityData MapOverviewToExternalData(
        CompanyOverviewResponse overview,
        IdentifierType identifierType,
        string identifierValue)
    {
        return new ExternalSecurityData
        {
            Symbol = overview.Symbol,
            Name = overview.Name,
            Description = overview.Description,
            IdentifierType = identifierType,
            IdentifierValue = identifierValue,
            SecurityType = MapAssetType(overview.AssetType),
            Exchange = overview.Exchange,
            Currency = overview.Currency,
            Country = overview.Country,
            Sector = overview.Sector,
            Industry = overview.Industry,
            Issuer = overview.Name,
            Source = DataSourceType.AlphaVantage,
            RawData = new Dictionary<string, string?>
            {
                ["AssetType"] = overview.AssetType,
                ["Exchange"] = overview.Exchange,
                ["Sector"] = overview.Sector,
                ["Industry"] = overview.Industry,
                ["52WeekHigh"] = overview.WeekHigh52,
                ["52WeekLow"] = overview.WeekLow52
            }
        };
    }

    private static SecurityType MapAssetType(string assetType) =>
        assetType.ToLowerInvariant() switch
        {
            "common stock" or "equity" => SecurityType.Equity,
            "etf" => SecurityType.Equity,
            "bond" => SecurityType.Bond,
            "corporate bond" => SecurityType.CorporateBond,
            "municipal bond" => SecurityType.MunicipalBond,
            "treasury bond" => SecurityType.TreasuryBond,
            _ => SecurityType.Other
        };
}
