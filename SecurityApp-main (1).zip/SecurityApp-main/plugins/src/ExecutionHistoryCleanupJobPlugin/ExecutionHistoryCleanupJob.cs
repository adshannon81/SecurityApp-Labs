﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Quartz;
using IJobExecutionContext = Quartz.IJobExecutionContext;
using SecurityApp.Core.Idempotency.Interfaces;
using SecurityApp.Core.Jobs.Interfaces;

namespace ExecutionHistoryCleanupJobPlugin;

[DisallowConcurrentExecution]
public sealed class ExecutionHistoryCleanupJob(
    IJobHistoryRepository                historyRepository,
    IIdempotencyKeyRepository            idempotencyRepository,
    IConfiguration                       config,
    ILogger<ExecutionHistoryCleanupJob>  logger) : IJob
{
    public async Task Execute(IJobExecutionContext context)
    {
        var ct = context.CancellationToken;

        if (!int.TryParse(config["Jobs:HistoryRetentionDays"], out var retentionDays) || retentionDays < 1)
            retentionDays = 90;

        var cutoff = DateTime.UtcNow.AddDays(-retentionDays);
        logger.LogInformation(
            "Cleaning up job execution history older than {Cutoff:u} ({Days} days)", cutoff, retentionDays);

        try
        {
            await historyRepository.DeleteOlderThanAsync(cutoff, ct);
            logger.LogInformation("Job execution history cleanup completed");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Failed to clean up job execution history");
            throw new JobExecutionException(ex) { RefireImmediately = false };
        }

        logger.LogInformation("Cleaning up expired idempotency keys");

        try
        {
            await idempotencyRepository.DeleteExpiredAsync(ct);
            logger.LogInformation("Idempotency key cleanup completed");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Failed to clean up expired idempotency keys");
            throw new JobExecutionException(ex) { RefireImmediately = false };
        }
    }
}
