﻿using SecurityApp.Core.Plugins.Interfaces;


namespace ExecutionHistoryCleanupJobPlugin;

public sealed class ExecutionHistoryCleanupJobPlugin : IJobPlugin
{
    public Type    JobType     => typeof(ExecutionHistoryCleanupJob);
    public string  Name        => "execution-history-cleanup";
    public string  Group       => "maintenance";
    public string? DefaultCron => "0 0 3 * * ?";   // 3 AM UTC daily
    public string  Description =>
        "Deletes job execution history records older than the configured retention period " +
        "(Jobs:HistoryRetentionDays in appsettings, default 90 days).";
}
