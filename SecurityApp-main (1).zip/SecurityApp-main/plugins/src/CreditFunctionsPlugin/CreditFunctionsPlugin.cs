﻿using SecurityApp.Core.Ratings.Interfaces;


namespace SecurityApp.Plugin.CreditFunctions;

// -------------------------------------------------------------------------------
// CreditFunctionsPlugin
//
// A drop-in NCalc-only plugin ï¿½ no data connector, pure formula functions.
//
// How it works
// ------------
// The PluginLoader scans every DLL in the plugins/ directory for types that
// implement INCalcFunction.  Functions found here are registered into the
// singleton INCalcFunctionRegistry at startup and are immediately callable from
// any formula string:
//
//   ï¿½ Derivation-rule formulas stored in RatingDerivationRules
//   ï¿½ Model config JSON (MICR / VPM / Fundamental / Composite)
//   ï¿½ @MacroName bodies stored in FormulaMacros
//
// Plugin functions are registered AFTER built-ins, so a plugin function with
// the same name as a built-in will SHADOW the built-in. Use this to override
// stock behaviour without recompiling the API.
//
// Functions provided by this plugin
// ----------------------------------
//   Normalize(value, inMin, inMax, outMin, outMax)
//     -> Linear range mapping with clamping and inverted-range support.
//        Moved here from built-ins so it is optionally deployable.
//
//   PdToScore(pd)
//     ? Converts a probability-of-default [0, 1] to an ordinal score [1, 21]
//       using a log-linear mapping calibrated to Basel credit buckets.
//
//   SpreadToScore(spreadBps)
//     ? Direct z-spread bucketing aligned with standard IG/HY thresholds.
//       Bucket table: =50?3, =100?5, =175?7, =250?9, =400?12,
//                     =600?14, =900?17, =1500?19, >1500?21.
//       Equivalent to calling ScoreBucket([spread], 50,3, 100,5, ï¿½) every
//       time, but encoded once here so all models share one auditable table.
//
//   CdsImpliedPd(spreadBps, recoveryRate, maturityYears)
//     ? Hazard-rate model: PD = 1 - exp(-s / (1 - R) / 10 000 ï¿½ T)
//       Returns a PD in [0, 1].
//
//   LeveragePenalty(debtToEquity, threshold)
//     ? Additive score penalty (0ï¿½4) when D/E exceeds the threshold.
//       Formula: Round(Clamp((D/E - threshold) ï¿½ 2, 0, 4))
//
// Deployment
// ----------
//   1. Run Build-Plugins.ps1 to compile this project and stage the DLL under
//      plugins/bin/CreditFunctionsPlugin/.
//   2. The API will auto-discover and register all five functions at startup.
//   3. Reference the functions by name in any formula string ï¿½ no API restart
//      other than the one that loads the plugin directory is required.
//
// -------------------------------------------------------------------------------

// --- PdToScoreFunction --------------------------------------------------------

/// <summary>
/// Converts a probability-of-default (PD) value [0, 1] to an ordinal credit
/// score [1, 21] using a log-linear mapping calibrated to Basel credit buckets.
///
/// Signature: <c>PdToScore(pd)</c>
///
/// Calibration (approximate):
/// <list type="table">
///   <listheader><term>PD</term><description>Score</description></listheader>
///   <item><term>0.0001 (0.01%)</term><description> 1 ï¿½ AAA equivalent</description></item>
///   <item><term>0.0020 (0.2%) </term><description> 7 ï¿½ A equivalent</description></item>
///   <item><term>0.0100 (1%)   </term><description>12 ï¿½ BB equivalent</description></item>
///   <item><term>0.0500 (5%)   </term><description>17 ï¿½ CCC equivalent</description></item>
///   <item><term>0.2000+ (20%+)</term><description>21 ï¿½ D equivalent</description></item>
/// </list>
///
/// Typical usage ï¿½ compose with <c>CdsImpliedPd</c> in a Fundamental formula:
/// <code>PdToScore(CdsImpliedPd([spread], [recovery], [maturity]))</code>
/// </summary>
public sealed class PdToScoreFunction : INCalcFunction
{
    public string Name => "PdToScore";

    public ValueTask<object?> EvaluateAsync(object?[] args)
    {
        if (args.Length != 1)
            throw new ArgumentException("PdToScore(pd) requires exactly 1 argument.");

        double pd    = Math.Clamp(Convert.ToDouble(args[0]), 0.0, 1.0);
        // Log-linear: 1 + 20 ï¿½ log(1 + pd ï¿½ 20) / log(21)
        // At pd=0 ? 1;  at pd=1 ? 21.
        double raw   = 1.0 + 20.0 * Math.Log(1.0 + pd * 20.0) / Math.Log(21.0);
        double score = Math.Round(Math.Clamp(raw, 1.0, 21.0), MidpointRounding.AwayFromZero);
        return new ValueTask<object?>((object?)score);
    }
}

// --- SpreadToScoreFunction ---------------------------------------------------

/// <summary>
/// Maps a z-spread in basis points to an ordinal credit score [1, 21] using a
/// standard IG/HY bucket table.
///
/// Signature: <c>SpreadToScore(spreadBps)</c>
///
/// Bucket table:
/// <list type="table">
///   <listheader><term>Max spread (bps)</term><description>Score</description></listheader>
///   <item><term>=   50</term><description> 3 ï¿½ AAAï¿½AA</description></item>
///   <item><term>=  100</term><description> 5 ï¿½ A</description></item>
///   <item><term>=  175</term><description> 7 ï¿½ BBB+/BBB</description></item>
///   <item><term>=  250</term><description> 9 ï¿½ BBB-</description></item>
///   <item><term>=  400</term><description>12 ï¿½ BB</description></item>
///   <item><term>=  600</term><description>14 ï¿½ B</description></item>
///   <item><term>=  900</term><description>17 ï¿½ CCC</description></item>
///   <item><term>= 1500</term><description>19 ï¿½ CCï¿½C</description></item>
///   <item><term>&gt; 1500</term><description>21 ï¿½ D</description></item>
/// </list>
///
/// Example in a MICR derivation-rule formula:
/// <code>SpreadToScore([zSpread])</code>
/// </summary>
public sealed class SpreadToScoreFunction : INCalcFunction
{
    public string Name => "SpreadToScore";

    // (maxBps inclusive, score) ï¿½ sorted ascending by maxBps
    private static readonly (double MaxBps, double Score)[] Buckets =
    [
        (  50,  3),
        ( 100,  5),
        ( 175,  7),
        ( 250,  9),
        ( 400, 12),
        ( 600, 14),
        ( 900, 17),
        (1500, 19),
        (double.MaxValue, 21)
    ];

    public ValueTask<object?> EvaluateAsync(object?[] args)
    {
        if (args.Length != 1)
            throw new ArgumentException("SpreadToScore(spreadBps) requires exactly 1 argument.");

        double spread = Convert.ToDouble(args[0]);
        foreach (var (maxBps, score) in Buckets)
        {
            if (spread <= maxBps)
                return new ValueTask<object?>((object?)score);
        }
        return new ValueTask<object?>((object?)21.0);
    }
}

// --- CdsImpliedPdFunction -----------------------------------------------------

/// <summary>
/// Computes the risk-neutral probability of default from a CDS / bond z-spread
/// using the standard constant-hazard-rate model.
///
/// Signature: <c>CdsImpliedPd(spreadBps, recoveryRate, maturityYears)</c>
///
/// Formula: PD = 1 - exp(-s / (1 - R) / 10 000 ï¿½ T)
/// <list type="bullet">
///   <item><term>spreadBps</term><description>Z-spread in basis points (e.g. 250).</description></item>
///   <item><term>recoveryRate</term><description>Recovery rate as a decimal (e.g. 0.40 for 40%).</description></item>
///   <item><term>maturityYears</term><description>Time horizon in years (e.g. 5.0).</description></item>
/// </list>
///
/// Returns a PD in [0, 1].
///
/// Example ï¿½ pipe into <c>PdToScore</c>:
/// <code>PdToScore(CdsImpliedPd([spread], [recovery], [maturity]))</code>
///
/// Example ï¿½ use directly as a MICR PdFormula override:
/// <code>CdsImpliedPd([spread], [recovery], [maturity])</code>
/// </summary>
public sealed class CdsImpliedPdFunction : INCalcFunction
{
    public string Name => "CdsImpliedPd";

    public ValueTask<object?> EvaluateAsync(object?[] args)
    {
        if (args.Length != 3)
            throw new ArgumentException(
                "CdsImpliedPd(spreadBps, recoveryRate, maturityYears) requires exactly 3 arguments.");

        double spreadBps    = Convert.ToDouble(args[0]);
        double recoveryRate = Convert.ToDouble(args[1]);
        double maturity     = Convert.ToDouble(args[2]);

        double lgd    = 1.0 - Math.Clamp(recoveryRate, 0.0, 1.0);
        if (lgd < 1e-10) lgd = 1e-10;    // guard against 100% recovery assumption

        double hazard = spreadBps / lgd / 10_000.0;
        double pd     = Math.Clamp(1.0 - Math.Exp(-hazard * maturity), 0.0, 1.0);
        return new ValueTask<object?>((object?)pd);
    }
}

// --- LeveragePenaltyFunction --------------------------------------------------

/// <summary>
/// Returns an additive score penalty (integer 0ï¿½4) when debt-to-equity exceeds
/// a configurable threshold.
///
/// Signature: <c>LeveragePenalty(debtToEquity, threshold)</c>
///
/// Formula: penalty = Round(Clamp((D/E - threshold) ï¿½ 2, 0, 4))
///
/// Examples:
/// <list type="bullet">
///   <item>D/E = 3.0, threshold = 4.0 ? under threshold ? 0</item>
///   <item>D/E = 5.0, threshold = 4.0 ? excess 1.0 ï¿½ 2 = 2 ? 2</item>
///   <item>D/E = 8.0, threshold = 4.0 ? excess 4.0 ï¿½ 2 = 8, capped at 4 ? 4</item>
/// </list>
///
/// Typical usage in a Composite or Fundamental formula:
/// <code>Clamp([baseScore] + LeveragePenalty([debtToEquity], 4.0), 1, 21)</code>
/// </summary>
public sealed class LeveragePenaltyFunction : INCalcFunction
{
    public string Name => "LeveragePenalty";

    public ValueTask<object?> EvaluateAsync(object?[] args)
    {
        if (args.Length != 2)
            throw new ArgumentException(
                "LeveragePenalty(debtToEquity, threshold) requires exactly 2 arguments.");

        double dte       = Convert.ToDouble(args[0]);
        double threshold = Convert.ToDouble(args[1]);

        double excess  = Math.Max(0.0, dte - threshold);
        double penalty = Math.Round(Math.Clamp(excess * 2.0, 0.0, 4.0),
                                    MidpointRounding.AwayFromZero);
        return new ValueTask<object?>((object?)penalty);
    }
}

// --- NormalizeFunction -------------------------------------------------------

/// <summary>
/// Maps a numeric value from one range to another linearly, with clamping.
///
/// Signature: <c>Normalize(value, inMin, inMax, outMin, outMax)</c>
///
/// Computes the normalised position of <c>value</c> within [inMin, inMax]
/// (clamped to [0, 1]) and maps that position linearly onto [outMin, outMax].
/// Inverted output ranges are supported: pass outMin &gt; outMax to make higher
/// input values produce lower output values.
///
/// Examples:
/// <list type="bullet">
///   <item><c>Normalize([spread], 0, 1000, 1, 21)</c> â€” z-spread to score.</item>
///   <item><c>Normalize([debtToEquity], 0, 8, 1, 21)</c> â€” D/E ratio to score.</item>
///   <item><c>Normalize([coverage], 15, 0.5, 1, 21)</c> â€” inverted: high coverage â†’ score 1.</item>
///   <item><c>[quality] * Normalize([priceDeviation], 0, 0.1, 1, 0.1)</c> â€” VPM weight.</item>
/// </list>
///
/// This function was previously a hardcoded built-in. It now lives here so it
/// can be deployed or updated independently without recompiling the API.
/// </summary>
public sealed class NormalizeFunction : INCalcFunction
{
    public string Name => "Normalize";

    public ValueTask<object?> EvaluateAsync(object?[] args)
    {
        if (args.Length != 5)
            throw new ArgumentException(
                "Normalize(value, inMin, inMax, outMin, outMax) requires exactly 5 arguments.");

        double value  = Convert.ToDouble(args[0]);
        double inMin  = Convert.ToDouble(args[1]);
        double inMax  = Convert.ToDouble(args[2]);
        double outMin = Convert.ToDouble(args[3]);
        double outMax = Convert.ToDouble(args[4]);

        if (Math.Abs(inMax - inMin) < 1e-15)
            throw new ArgumentException(
                "Normalize: inMin and inMax must be different (degenerate input range).");

        double t      = Math.Clamp((value - inMin) / (inMax - inMin), 0.0, 1.0);
        double result = outMin + t * (outMax - outMin);
        return new ValueTask<object?>((object?)result);
    }
}
