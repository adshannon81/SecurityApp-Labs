using System.Diagnostics;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Quartz;
using IJobExecutionContext = Quartz.IJobExecutionContext;

namespace ScriptRunnerJobPlugin;

/// <summary>
/// Executes an admin-supplied PowerShell script or SQL query on demand.
/// <para>
/// <b>JobDataMap keys:</b>
/// <list type="bullet">
///   <item><term>ScriptType</term><description>"PowerShell" (default) or "Sql"</description></item>
///   <item><term>Script</term><description>The script body to execute</description></item>
///   <item><term>ConnectionStringName</term><description>
///       SQL mode only — name of the connection string in appsettings (default: "DefaultConnection")
///   </description></item>
/// </list>
/// </para>
/// </summary>
[DisallowConcurrentExecution]
public sealed class ScriptRunnerJob(
    IConfiguration         config,
    ILogger<ScriptRunnerJob> logger) : IJob
{
    public async Task Execute(IJobExecutionContext context)
    {
        var ct      = context.CancellationToken;
        var jobData = context.MergedJobDataMap;

        var scriptType = jobData.GetString("ScriptType") ?? "PowerShell";
        var script     = jobData.GetString("Script") ?? string.Empty;

        if (string.IsNullOrWhiteSpace(script))
        {
            logger.LogWarning("ScriptRunnerJob: no script body found in JobDataMap[\"Script\"] — skipping");
            return;
        }

        switch (scriptType.Trim())
        {
            case "PowerShell":
                await RunPowerShellAsync(script, ct);
                break;

            case "Sql":
                var connName = jobData.GetString("ConnectionStringName") ?? "DefaultConnection";
                await RunSqlAsync(script, connName, ct);
                break;

            default:
                throw new InvalidOperationException(
                    $"Unknown ScriptType '{scriptType}'. Supported values: PowerShell, Sql.");
        }
    }

    // ── PowerShell ────────────────────────────────────────────────────────────

    private async Task RunPowerShellAsync(string script, CancellationToken ct)
    {
        var tempFile = Path.Combine(Path.GetTempPath(), $"job_{Guid.NewGuid():N}.ps1");
        try
        {
            await File.WriteAllTextAsync(tempFile, script, ct);
            logger.LogInformation("Executing PowerShell script (temp: {TempFile})", tempFile);

            using var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName               = "pwsh",
                    Arguments              = $"-NonInteractive -NoProfile -File \"{tempFile}\"",
                    RedirectStandardOutput = true,
                    RedirectStandardError  = true,
                    UseShellExecute        = false,
                    CreateNoWindow         = true
                }
            };

            process.Start();

            var stdoutTask = process.StandardOutput.ReadToEndAsync(ct);
            var stderrTask = process.StandardError.ReadToEndAsync(ct);

            try
            {
                await process.WaitForExitAsync(ct);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                if (!process.HasExited) process.Kill(entireProcessTree: true);
                logger.LogWarning("PowerShell script was cancelled");
                throw;
            }

            var stdout = await stdoutTask;
            var stderr = await stderrTask;

            if (!string.IsNullOrWhiteSpace(stdout))
                logger.LogInformation("Script output:{NewLine}{Output}", Environment.NewLine, stdout.Trim());

            if (!string.IsNullOrWhiteSpace(stderr))
                logger.LogWarning("Script stderr:{NewLine}{Errors}", Environment.NewLine, stderr.Trim());

            if (process.ExitCode != 0)
                throw new JobExecutionException(
                    new InvalidOperationException($"Script exited with code {process.ExitCode}"))
                { RefireImmediately = false };

            logger.LogInformation("PowerShell script completed (exit code 0)");
        }
        finally
        {
            if (File.Exists(tempFile))
                try { File.Delete(tempFile); } catch { /* best-effort cleanup */ }
        }
    }

    // ── SQL ───────────────────────────────────────────────────────────────────

    private async Task RunSqlAsync(string sql, string connectionStringName, CancellationToken ct)
    {
        var connectionString = config.GetConnectionString(connectionStringName);
        if (string.IsNullOrWhiteSpace(connectionString))
            throw new InvalidOperationException(
                $"Connection string '{connectionStringName}' not found in configuration.");

        logger.LogInformation("Executing SQL script via '{ConnectionStringName}'", connectionStringName);

        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync(ct);

        await using var command = new SqlCommand(sql, connection) { CommandTimeout = 300 };
        await using var reader  = await command.ExecuteReaderAsync(ct);

        int rowCount = 0;
        while (await reader.ReadAsync(ct)) rowCount++;

        logger.LogInformation("SQL script completed — read {RowCount} row(s)", rowCount);
    }
}
