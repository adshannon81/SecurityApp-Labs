﻿using SecurityApp.Core.Plugins.Interfaces;


namespace ScriptRunnerJobPlugin;

public sealed class ScriptRunnerJobPlugin : IJobPlugin
{
    public Type    JobType     => typeof(ScriptRunnerJob);
    public string  Name        => "script-runner";
    public string  Group       => "scripting";
    public string? DefaultCron => null;   // No default â€” must be scheduled explicitly via the admin API
    public string  Description =>
        "Executes an admin-supplied PowerShell script or SQL query. " +
        "Set JobDataMap keys: ScriptType (PowerShell|Sql), Script (body), " +
        "ConnectionStringName (SQL mode, default: DefaultConnection).";
}
