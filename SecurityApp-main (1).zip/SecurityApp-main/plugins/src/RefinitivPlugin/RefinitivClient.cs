using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using SecurityApp.Plugin.Refinitiv.Models;

namespace SecurityApp.Plugin.Refinitiv;

/// <summary>
/// Low-level HTTP client for the LSEG Refinitiv Elektron Data Platform (EDP) REST API.
///
/// Endpoint overview:
///   Auth    POST /auth/oauth2/v1/token            (client_credentials or password grant)
///   Ref     POST /data/daas/v1/data/EDP/...       (instrument field data)
///   Search  GET  /discovery/search/v1/search       (symbol/ISIN/CUSIP lookup)
///   Pricing POST /data/daas/v1/data/EDP/...       (snapshot pricing)
///   History POST /data/daas/v1/data/EDP/...       (DSWS historical)
///
/// Authentication uses the Resource Owner Password Credentials grant (username + password +
/// client_id + client_secret) that Refinitiv EDP provides for server-to-server access.
/// Tokens are cached and auto-refreshed 60 seconds before expiry.
/// </summary>
public sealed class RefinitivClient : IDisposable
{
    private readonly HttpClient _http;
    private readonly string _username;
    private readonly string _password;
    private readonly string _clientId;
    private readonly string _clientSecret;
    private readonly ILogger<RefinitivClient> _logger;
    private readonly int _maxRetries;

    private string? _accessToken;
    private DateTime _tokenExpiry = DateTime.MinValue;
    private readonly SemaphoreSlim _tokenLock = new(1, 1);
    private bool _disposed;

    // EDP field list for reference data
    private static readonly string[] ReferenceFields =
    [
        "TR.CommonName", "TR.ISIN", "TR.CUSIP", "TR.SEDOL", "TR.RIC",
        "TR.ExchangeName", "TR.ExchangeCode", "TR.Currency", "TR.CountryCode",
        "TR.TRBCIndustry", "TR.TRBCBusinessSector", "TR.CompanyName",
        "TR.IssueName", "TR.AssetType", "TR.CouponRate", "TR.MaturityDate",
        "TR.FaceValue", "TR.PEInclExtraItems"
    ];

    // EDP field list for pricing snapshot
    private static readonly string[] PricingFields =
    [
        "TR.PriceLast", "TR.PriceOpen", "TR.PriceHigh", "TR.PriceLow",
        "TR.Volume", "TR.CloseDate"
    ];

    public RefinitivClient(
        HttpClient httpClient,
        string username,
        string password,
        string clientId,
        string clientSecret,
        ILogger<RefinitivClient> logger,
        int maxRetries = 3)
    {
        _http         = httpClient;
        _username     = username;
        _password     = password;
        _clientId     = clientId;
        _clientSecret = clientSecret;
        _logger       = logger;
        _maxRetries   = maxRetries;
    }

    // ── Token management ──────────────────────────────────────────────────

    private async Task EnsureTokenAsync(CancellationToken ct)
    {
        if (_accessToken != null && DateTime.UtcNow < _tokenExpiry)
            return;

        await _tokenLock.WaitAsync(ct);
        try
        {
            // Double-checked locking
            if (_accessToken != null && DateTime.UtcNow < _tokenExpiry)
                return;

            var form = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["grant_type"]    = "password",
                ["username"]      = _username,
                ["password"]      = _password,
                ["client_id"]     = _clientId,
                ["client_secret"] = _clientSecret,
                ["scope"]         = "trapi"
            });

            var response = await _http.PostAsync("/auth/oauth2/v1/token", form, ct);
            response.EnsureSuccessStatusCode();

            var token = await response.Content.ReadFromJsonAsync<RefinitivTokenResponse>(
                cancellationToken: ct);

            if (token == null || string.IsNullOrEmpty(token.AccessToken))
                throw new InvalidOperationException("Refinitiv EDP returned an empty access token.");

            _accessToken = token.AccessToken;
            _tokenExpiry = DateTime.UtcNow.AddSeconds(token.ExpiresIn - 60);

            _logger.LogInformation("Refinitiv EDP token acquired, expires ~{Expiry:HH:mm:ss} UTC", _tokenExpiry);
        }
        finally
        {
            _tokenLock.Release();
        }
    }

    // ── Public API ────────────────────────────────────────────────────────

    /// <summary>Gets reference / fundamental data for a single instrument.</summary>
    public async Task<RefinitivInstrumentData?> GetReferenceDataAsync(
        string identifierValue,
        string identifierType,
        CancellationToken ct = default)
    {
        await EnsureTokenAsync(ct);

        var normalised = NormaliseIdentifier(identifierValue, identifierType);
        var body       = BuildFieldRequest(new[] { normalised }, ReferenceFields);
        var result     = await PostWithRetryAsync<RefinitivInstrumentResponse>(
            "/data/daas/v1/data/EDP/Fields", body, ct);

        return result?.Universe?.FirstOrDefault(u =>
            string.Equals(u.Instrument, normalised, StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>Searches for securities by keyword (name, RIC, ISIN, CUSIP).</summary>
    public async Task<RefinitivSearchResponse?> SearchAsync(string keyword, CancellationToken ct = default)
    {
        await EnsureTokenAsync(ct);

        var url = $"/discovery/search/v1/search?query={Uri.EscapeDataString(keyword)}" +
                  "&type=Quotes&search=true&top=20";

        var request = new HttpRequestMessage(HttpMethod.Get, url);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _accessToken);

        var response = await SendWithRetryAsync(request, ct);
        if (!response.IsSuccessStatusCode)
        {
            _logger.LogWarning("Refinitiv search returned {Code} for '{Keyword}'",
                (int)response.StatusCode, keyword);
            return null;
        }

        return await response.Content.ReadFromJsonAsync<RefinitivSearchResponse>(cancellationToken: ct);
    }

    /// <summary>Gets the latest pricing snapshot for an instrument.</summary>
    public async Task<RefinitivPricingData?> GetCurrentPriceAsync(
        string identifierValue,
        string identifierType,
        CancellationToken ct = default)
    {
        await EnsureTokenAsync(ct);

        var normalised = NormaliseIdentifier(identifierValue, identifierType);
        var body       = BuildFieldRequest(new[] { normalised }, PricingFields);
        var result     = await PostWithRetryAsync<RefinitivPricingResponse>(
            "/data/daas/v1/data/EDP/Fields", body, ct);

        return result?.Universe?.FirstOrDefault(u =>
            string.Equals(u.Instrument, normalised, StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>Gets daily OHLCV bars for a date range via DSWS.</summary>
    public async Task<List<RefinitivHistoricalBar>> GetHistoricalPricesAsync(
        string identifierValue,
        string identifierType,
        DateTime fromDate,
        DateTime toDate,
        CancellationToken ct = default)
    {
        await EnsureTokenAsync(ct);

        var ric  = NormaliseIdentifier(identifierValue, identifierType);
        var body = new
        {
            universe     = new[] { ric },
            interval     = "P1D",
            start        = fromDate.ToString("yyyy-MM-dd"),
            end          = toDate.ToString("yyyy-MM-dd"),
            adjustments  = new[] { "exchangeCorrection", "manualCorrection" },
            fields       = new[] { "OPEN_PRC", "HIGH_1", "LOW_1", "TRDPRC_1", "ACVOL_UNS" }
        };

        var hist = await PostWithRetryAsync<RefinitivHistoricalResponse>(
            "/data/daas/v1/data/EDP/TimeSeries", body, ct);

        if (hist?.Dates == null || hist.DataTypeValues == null)
            return [];

        return MapHistoricalBars(ric, hist);
    }

    /// <summary>Checks if the EDP API is reachable and credentials are valid.</summary>
    public async Task<bool> IsAvailableAsync(CancellationToken ct = default)
    {
        try
        {
            await EnsureTokenAsync(ct);
            return !string.IsNullOrEmpty(_accessToken);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Refinitiv EDP availability check failed.");
            return false;
        }
    }

    // ── Private helpers ───────────────────────────────────────────────────

    private static object BuildFieldRequest(string[] universe, string[] fields) =>
        new
        {
            universe,
            fields
        };

    private async Task<T?> PostWithRetryAsync<T>(string path, object body, CancellationToken ct)
    {
        var json = JsonSerializer.Serialize(body);

        for (var attempt = 0; attempt <= _maxRetries; attempt++)
        {
            var request = new HttpRequestMessage(HttpMethod.Post, path)
            {
                Content = new StringContent(json, Encoding.UTF8, "application/json")
            };
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _accessToken);

            var response = await SendWithRetryAsync(request, ct);

            if (response.IsSuccessStatusCode)
                return await response.Content.ReadFromJsonAsync<T>(cancellationToken: ct);

            if (response.StatusCode == HttpStatusCode.Unauthorized && attempt < _maxRetries)
            {
                _logger.LogWarning("Refinitiv 401 — refreshing token (attempt {N})", attempt + 1);
                _accessToken = null;
                await EnsureTokenAsync(ct);
                continue;
            }

            _logger.LogWarning("Refinitiv POST {Path} returned {Code}", path, (int)response.StatusCode);
            return default;
        }

        return default;
    }

    private async Task<HttpResponseMessage> SendWithRetryAsync(
        HttpRequestMessage request,
        CancellationToken ct)
    {
        for (var attempt = 0; attempt <= _maxRetries; attempt++)
        {
            HttpResponseMessage response;
            try
            {
                // HttpRequestMessage can only be sent once — clone for retries
                var toSend = attempt == 0 ? request : CloneRequest(request);
                response = await _http.SendAsync(toSend, ct);
            }
            catch (HttpRequestException ex) when (attempt < _maxRetries)
            {
                _logger.LogWarning(ex, "Refinitiv HTTP error on attempt {N}, retrying…", attempt + 1);
                await Task.Delay(TimeSpan.FromSeconds(Math.Pow(2, attempt)), ct);
                continue;
            }

            if (response.StatusCode == HttpStatusCode.TooManyRequests && attempt < _maxRetries)
            {
                var retryAfter = response.Headers.RetryAfter?.Delta ?? TimeSpan.FromSeconds(Math.Pow(2, attempt + 1));
                _logger.LogWarning("Refinitiv 429 — backing off {Delay:g}", retryAfter);
                await Task.Delay(retryAfter, ct);
                continue;
            }

            return response;
        }

        throw new HttpRequestException("Refinitiv API request failed after maximum retries.");
    }

    private static HttpRequestMessage CloneRequest(HttpRequestMessage original)
    {
        var clone = new HttpRequestMessage(original.Method, original.RequestUri);

        foreach (var header in original.Headers)
            clone.Headers.TryAddWithoutValidation(header.Key, header.Value);

        if (original.Content != null)
        {
            var body    = original.Content.ReadAsStringAsync().GetAwaiter().GetResult();
            var content = new StringContent(body, Encoding.UTF8, "application/json");
            foreach (var header in original.Content.Headers)
                content.Headers.TryAddWithoutValidation(header.Key, header.Value);
            clone.Content = content;
        }

        return clone;
    }

    private static string NormaliseIdentifier(string value, string type) =>
        type.ToUpperInvariant() switch
        {
            "ISIN"    => $"ISIN/{value}",
            "CUSIP"   => $"CUSIP/{value}",
            "SEDOL"   => $"SEDOL/{value}",
            "REUTERS" => value,   // RIC is used directly
            _         => value    // Ticker / RIC — pass through
        };

    private static List<RefinitivHistoricalBar> MapHistoricalBars(
        string ric,
        RefinitivHistoricalResponse hist)
    {
        // Build field-name → value-list map from DataTypeValues
        var fieldValues = new Dictionary<string, List<object?>>
        (StringComparer.OrdinalIgnoreCase);

        if (hist.DataTypeValues != null)
        {
            foreach (var dtv in hist.DataTypeValues)
            {
                if (dtv.DataType == null) continue;
                var symbolEntry = dtv.SymbolValues?.FirstOrDefault(
                    s => string.Equals(s.Symbol, ric, StringComparison.OrdinalIgnoreCase));
                if (symbolEntry?.Value != null)
                    fieldValues[dtv.DataType] = symbolEntry.Value;
            }
        }

        var bars = new List<RefinitivHistoricalBar>();
        if (hist.Dates == null) return bars;

        for (var i = 0; i < hist.Dates.Count; i++)
        {
            if (hist.Dates[i] == null) continue;

            T? Field<T>(string name)
            {
                if (!fieldValues.TryGetValue(name, out var values) || i >= values.Count)
                    return default;
                var v = values[i];
                if (v is null) return default;
                try { return (T)Convert.ChangeType(v, typeof(T)); } catch { return default; }
            }

            bars.Add(new RefinitivHistoricalBar
            {
                Date   = hist.Dates[i]!,
                Open   = Field<double?>("OPEN_PRC")?.ToString(),
                High   = Field<double?>("HIGH_1")?.ToString(),
                Low    = Field<double?>("LOW_1")?.ToString(),
                Close  = Field<double?>("TRDPRC_1")?.ToString(),
                Volume = Field<double?>("ACVOL_UNS")?.ToString()
            });
        }

        return bars;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _tokenLock.Dispose();
    }
}
