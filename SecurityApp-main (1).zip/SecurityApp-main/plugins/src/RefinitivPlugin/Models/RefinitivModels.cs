using System.Text.Json.Serialization;

namespace SecurityApp.Plugin.Refinitiv.Models;

// ── Authentication ─────────────────────────────────────────────────────────

/// <summary>
/// Response from the LSEG EDP /auth/oauth2/v1/token endpoint.
/// </summary>
public class RefinitivTokenResponse
{
    [JsonPropertyName("access_token")]
    public string AccessToken { get; set; } = string.Empty;

    [JsonPropertyName("refresh_token")]
    public string? RefreshToken { get; set; }

    [JsonPropertyName("token_type")]
    public string TokenType { get; set; } = "Bearer";

    [JsonPropertyName("expires_in")]
    public int ExpiresIn { get; set; }

    [JsonPropertyName("scope")]
    public string? Scope { get; set; }
}

// ── Instrument / Reference Data ────────────────────────────────────────────

/// <summary>
/// Response from the EDP Pricing Streaming or DSWS request – instrument data.
/// </summary>
public class RefinitivInstrumentResponse
{
    [JsonPropertyName("universe")]
    public List<RefinitivInstrumentData>? Universe { get; set; }
}

public class RefinitivInstrumentData
{
    [JsonPropertyName("Instrument")]
    public string? Instrument { get; set; }

    [JsonPropertyName("Error")]
    public RefinitivError? Error { get; set; }

    [JsonPropertyName("data")]
    public List<Dictionary<string, object?>>? Data { get; set; }

    [JsonPropertyName("headers")]
    public List<RefinitivHeader>? Headers { get; set; }
}

public class RefinitivHeader
{
    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("title")]
    public string? Title { get; set; }

    [JsonPropertyName("type")]
    public string? Type { get; set; }
}

public class RefinitivError
{
    [JsonPropertyName("code")]
    public int Code { get; set; }

    [JsonPropertyName("message")]
    public string? Message { get; set; }
}

// ── Symbol Search ──────────────────────────────────────────────────────────

/// <summary>
/// Response from the EDP Search/SymbolSearch endpoint.
/// </summary>
public class RefinitivSearchResponse
{
    [JsonPropertyName("GuidType")]
    public string? GuidType { get; set; }

    [JsonPropertyName("Hits")]
    public List<RefinitivSearchHit>? Hits { get; set; }

    [JsonPropertyName("total")]
    public int Total { get; set; }
}

public class RefinitivSearchHit
{
    [JsonPropertyName("_source")]
    public RefinitivSearchSource? Source { get; set; }
}

public class RefinitivSearchSource
{
    [JsonPropertyName("PermID")]
    public string? PermId { get; set; }

    [JsonPropertyName("RIC")]
    public string? Ric { get; set; }

    [JsonPropertyName("DocumentTitle")]
    public string? DocumentTitle { get; set; }

    [JsonPropertyName("AssetClass")]
    public string? AssetClass { get; set; }

    [JsonPropertyName("AssetState")]
    public string? AssetState { get; set; }

    [JsonPropertyName("ExchangeName")]
    public string? ExchangeName { get; set; }

    [JsonPropertyName("RCSAssetCategoryLeaf")]
    public string? RcsAssetCategoryLeaf { get; set; }

    [JsonPropertyName("ISIN")]
    public string? Isin { get; set; }

    [JsonPropertyName("CUSIP")]
    public string? Cusip { get; set; }

    [JsonPropertyName("SEDOL")]
    public string? Sedol { get; set; }

    [JsonPropertyName("Currency")]
    public string? Currency { get; set; }

    [JsonPropertyName("PrimaryRIC")]
    public string? PrimaryRic { get; set; }
}

// ── Pricing ────────────────────────────────────────────────────────────────

/// <summary>
/// Response from the EDP Pricing Snapshot endpoint.
/// </summary>
public class RefinitivPricingResponse
{
    [JsonPropertyName("universe")]
    public List<RefinitivPricingData>? Universe { get; set; }
}

public class RefinitivPricingData
{
    [JsonPropertyName("Instrument")]
    public string? Instrument { get; set; }

    [JsonPropertyName("Error")]
    public RefinitivError? Error { get; set; }

    [JsonPropertyName("data")]
    public List<Dictionary<string, object?>>? Data { get; set; }

    [JsonPropertyName("headers")]
    public List<RefinitivHeader>? Headers { get; set; }
}

// ── Historical Pricing (DSWS / Workspace) ─────────────────────────────────

/// <summary>
/// Response from the DSWS DataService / historical pricing endpoint.
/// </summary>
public class RefinitivHistoricalResponse
{
    [JsonPropertyName("DataTypeValues")]
    public List<RefinitivDataTypeValue>? DataTypeValues { get; set; }

    [JsonPropertyName("Dates")]
    public List<string?>? Dates { get; set; }

    [JsonPropertyName("SymbolValues")]
    public List<RefinitivSymbolValue>? SymbolValues { get; set; }
}

public class RefinitivDataTypeValue
{
    [JsonPropertyName("DataType")]
    public string? DataType { get; set; }

    [JsonPropertyName("SymbolValues")]
    public List<RefinitivSymbolValue>? SymbolValues { get; set; }
}

public class RefinitivSymbolValue
{
    [JsonPropertyName("Symbol")]
    public string? Symbol { get; set; }

    [JsonPropertyName("Type")]
    public int Type { get; set; }

    [JsonPropertyName("Value")]
    public List<object?>? Value { get; set; }
}

/// <summary>
/// Flattened historical bar (OHLCV) used internally after mapping DSWS response.
/// </summary>
public class RefinitivHistoricalBar
{
    public string Date   { get; set; } = string.Empty;
    public string? Open  { get; set; }
    public string? High  { get; set; }
    public string? Low   { get; set; }
    public string? Close { get; set; }
    public string? Volume { get; set; }
}
