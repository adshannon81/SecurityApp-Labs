using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using SecurityApp.Core.Plugins.Interfaces;
using SecurityApp.Core.Shared.Enums;

namespace SecurityApp.Plugin.Refinitiv;

/// <summary>
/// Plugin entry point for the Refinitiv / LSEG EDP connector.
/// The PluginLoader discovers this class by scanning for IConnectorPlugin implementations.
///
/// Required configuration (appsettings / env / Vault):
///   DataConnectors:Refinitiv:BaseUrl       — e.g. https://api.refinitiv.com/
///   DataConnectors:Refinitiv:Username      — EDP/Workspace username
///   DataConnectors:Refinitiv:Password      — EDP/Workspace password (inject from Vault in prod)
///   DataConnectors:Refinitiv:ClientId      — application (app-key) from the developer portal
///   DataConnectors:Refinitiv:ClientSecret  — app secret (inject from Vault in prod)
///   DataConnectors:Refinitiv:TimeoutSeconds (optional, default 30)
///   DataConnectors:Refinitiv:MaxRetries    (optional, default 3)
/// </summary>
public sealed class RefinitivPlugin : IConnectorPlugin
{
    private RefinitivConnector? _connector;
    private bool _disposed;

    public PluginMetadata Metadata => new()
    {
        Name          = "Refinitiv",
        Version       = "1.0.0",
        Author        = "SecurityApp",
        Description   = "Refinitiv / LSEG Elektron Data Platform (EDP) REST connector for security reference data and pricing.",
        ConnectorType = DataSourceType.Reuters
    };

    public bool IsCompatible() => true;

    public Task InitializeAsync(IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        var config = (IConfiguration?)serviceProvider.GetService(typeof(IConfiguration))
            ?? throw new InvalidOperationException("IConfiguration not available in plugin service provider.");

        var section = config.GetSection("DataConnectors:Refinitiv");

        var baseUrl = section["BaseUrl"];
        if (string.IsNullOrEmpty(baseUrl))
            throw new InvalidOperationException(
                "DataConnectors:Refinitiv:BaseUrl is required. " +
                "Expected value: https://api.refinitiv.com/");

        var username = section["Username"];
        if (string.IsNullOrEmpty(username))
            throw new InvalidOperationException(
                "DataConnectors:Refinitiv:Username is required. " +
                "Use your LSEG Workspace / EDP username.");

        var password = section["Password"];
        if (string.IsNullOrEmpty(password))
            throw new InvalidOperationException(
                "DataConnectors:Refinitiv:Password is required. " +
                "Store in Vault: DataConnectors__Refinitiv__Password");

        var clientId = section["ClientId"];
        if (string.IsNullOrEmpty(clientId))
            throw new InvalidOperationException(
                "DataConnectors:Refinitiv:ClientId is required. " +
                "Obtain the App-Key from the Refinitiv developer portal.");

        var clientSecret = section["ClientSecret"];
        if (string.IsNullOrEmpty(clientSecret))
            throw new InvalidOperationException(
                "DataConnectors:Refinitiv:ClientSecret is required. " +
                "Store in Vault: DataConnectors__Refinitiv__ClientSecret");

        var timeoutSeconds = section.GetValue<int>("TimeoutSeconds", 30);
        var maxRetries     = section.GetValue<int>("MaxRetries", 3);

        var httpClient = new HttpClient
        {
            BaseAddress = new Uri(baseUrl.TrimEnd('/') + '/'),
            Timeout     = TimeSpan.FromSeconds(timeoutSeconds)
        };

        var loggerFactory = (ILoggerFactory?)serviceProvider.GetService(typeof(ILoggerFactory))
            ?? NullLoggerFactory.Instance;

        var clientLogger    = loggerFactory.CreateLogger<RefinitivClient>();
        var connectorLogger = loggerFactory.CreateLogger<RefinitivConnector>();

        var client = new RefinitivClient(
            httpClient, username, password, clientId, clientSecret, clientLogger, maxRetries);

        _connector = new RefinitivConnector(client, connectorLogger);

        return Task.CompletedTask;
    }

    public IDataConnector GetConnector()
    {
        if (_connector == null)
            throw new InvalidOperationException("RefinitivPlugin has not been initialised. Call InitializeAsync first.");
        return _connector;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        _connector = null;
    }
}
