using Microsoft.Extensions.Logging;
using SecurityApp.Core.Plugins.Interfaces;
using SecurityApp.Core.Pricing.Interfaces;
using SecurityApp.Core.Pricing.Models;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Securities.Interfaces;
using SecurityApp.Core.Securities.Models;
using SecurityApp.Core.Shared.Enums;

namespace SecurityApp.Plugin.Refinitiv;

/// <summary>
/// Combined Refinitiv/LSEG connector implementing both ISecurityDataProvider and IPricingDataProvider.
/// Communicates with the Refinitiv EDP REST API via RefinitivClient.
///
/// A single instance is returned by RefinitivPlugin.GetConnector() and can be cast
/// to either interface by the DataProviderService.
/// </summary>
public class RefinitivConnector : ISecurityDataProvider, IPricingDataProvider
{
    private readonly RefinitivClient _client;
    private readonly ILogger<RefinitivConnector> _logger;

    // IDataConnector
    public DataSourceType SourceType => DataSourceType.Reuters;
    public string SourceName => "Refinitiv / LSEG";

    // Priority 2 — after Bloomberg (1), before remaining sources
    public int Priority => 2;

    public RefinitivConnector(RefinitivClient client, ILogger<RefinitivConnector> logger)
    {
        _client = client;
        _logger = logger;
    }

    // ── IDataConnector ────────────────────────────────────────────────────────

    public Task<bool> IsAvailableAsync(CancellationToken cancellationToken = default)
        => _client.IsAvailableAsync(cancellationToken);

    public async Task<HealthStatus> GetHealthStatusAsync(CancellationToken cancellationToken = default)
    {
        var available = await _client.IsAvailableAsync(cancellationToken);
        return new HealthStatus
        {
            IsHealthy = available,
            Message   = available
                ? "Refinitiv EDP API is reachable and authenticated."
                : "Refinitiv EDP API unavailable or authentication failed.",
            CheckedAt = DateTime.UtcNow
        };
    }

    // ── ISecurityDataProvider ─────────────────────────────────────────────────

    public bool SupportsIdentifierType(IdentifierType identifierType) =>
        identifierType is IdentifierType.ISIN
            or IdentifierType.CUSIP
            or IdentifierType.SEDOL
            or IdentifierType.Ticker
            or IdentifierType.Reuters
            or IdentifierType.Other;

    public async Task<ExternalSecurityData?> GetSecurityAsync(
        string identifierValue,
        IdentifierType identifierType,
        CancellationToken cancellationToken = default)
    {
        var data = await _client.GetReferenceDataAsync(
            identifierValue,
            identifierType.ToString(),
            cancellationToken);

        if (data == null)
        {
            _logger.LogWarning("Refinitiv: no reference data for {Type}={Value}", identifierType, identifierValue);
            return null;
        }

        return MapToExternalSecurityData(data, identifierType, identifierValue);
    }

    public async Task<IEnumerable<ExternalSecurityData>> SearchSecuritiesAsync(
        string keyword,
        CancellationToken cancellationToken = default)
    {
        var response = await _client.SearchAsync(keyword, cancellationToken);
        if (response?.Hits is not { Count: > 0 })
            return Enumerable.Empty<ExternalSecurityData>();

        return response.Hits
            .Where(h => h.Source != null)
            .Select(h => MapSearchHitToExternalSecurityData(h.Source!, keyword));
    }

    // ── IPricingDataProvider ──────────────────────────────────────────────────

    public async Task<ExternalPriceData?> GetCurrentPriceAsync(
        string symbol,
        CancellationToken cancellationToken = default)
    {
        // Try as RIC first, fall back to ISIN prefix notation
        var price = await _client.GetCurrentPriceAsync(symbol, "REUTERS", cancellationToken)
                 ?? await _client.GetCurrentPriceAsync(symbol, "ISIN",    cancellationToken);

        if (price == null)
        {
            _logger.LogWarning("Refinitiv: no current price for {Symbol}", symbol);
            return null;
        }

        return MapToExternalPriceData(price, symbol);
    }

    public async Task<IEnumerable<ExternalPriceData>> GetHistoricalPricesAsync(
        string symbol,
        DateTime fromDate,
        DateTime toDate,
        CancellationToken cancellationToken = default)
    {
        var bars = await _client.GetHistoricalPricesAsync(
            symbol, "REUTERS", fromDate, toDate, cancellationToken);

        if (bars.Count == 0)
        {
            _logger.LogWarning("Refinitiv: no historical prices for {Symbol} {From:d}–{To:d}",
                symbol, fromDate, toDate);
            return Enumerable.Empty<ExternalPriceData>();
        }

        var results = new List<ExternalPriceData>();

        foreach (var bar in bars)
        {
            if (!DateTime.TryParse(bar.Date, out var date))
                continue;

            _ = decimal.TryParse(bar.Close, System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out var close);
            _ = decimal.TryParse(bar.Open, System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out var open);
            _ = decimal.TryParse(bar.High, System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out var high);
            _ = decimal.TryParse(bar.Low, System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out var low);
            _ = long.TryParse(bar.Volume, out var volume);

            results.Add(new ExternalPriceData
            {
                Symbol    = symbol,
                Price     = close,
                PriceType = "Close",
                OpenPrice = open,
                HighPrice = high,
                LowPrice  = low,
                Volume    = volume,
                PriceDate = date,
                Source    = DataSourceType.Reuters
            });
        }

        return results.OrderByDescending(p => p.PriceDate);
    }

    // ── Mapping helpers ───────────────────────────────────────────────────────

    private ExternalSecurityData MapToExternalSecurityData(
        Models.RefinitivInstrumentData data,
        IdentifierType identifierType,
        string identifierValue)
    {
        // Flatten headers + data row into a field dictionary
        var fields = ExtractFields(data.Headers, data.Data);

        return new ExternalSecurityData
        {
            Symbol          = fields.GetValueOrDefault("TR.RIC") ?? identifierValue,
            Name            = fields.GetValueOrDefault("TR.CommonName")   ?? fields.GetValueOrDefault("TR.IssueName") ?? string.Empty,
            Description     = fields.GetValueOrDefault("TR.IssueName")    ?? string.Empty,
            IdentifierType  = identifierType,
            IdentifierValue = identifierValue,
            SecurityType    = MapSecurityType(fields.GetValueOrDefault("TR.AssetType")),
            Exchange        = fields.GetValueOrDefault("TR.ExchangeName") ?? fields.GetValueOrDefault("TR.ExchangeCode"),
            Currency        = fields.GetValueOrDefault("TR.Currency"),
            Country         = fields.GetValueOrDefault("TR.CountryCode"),
            Sector          = fields.GetValueOrDefault("TR.TRBCBusinessSector"),
            Industry        = fields.GetValueOrDefault("TR.TRBCIndustry"),
            Issuer          = fields.GetValueOrDefault("TR.CompanyName"),
            Source          = DataSourceType.Reuters,
            RawData         = new Dictionary<string, string?>
            {
                ["TR.CommonName"]       = fields.GetValueOrDefault("TR.CommonName"),
                ["TR.ISIN"]             = fields.GetValueOrDefault("TR.ISIN"),
                ["TR.CUSIP"]            = fields.GetValueOrDefault("TR.CUSIP"),
                ["TR.SEDOL"]            = fields.GetValueOrDefault("TR.SEDOL"),
                ["TR.RIC"]              = fields.GetValueOrDefault("TR.RIC"),
                ["TR.AssetType"]        = fields.GetValueOrDefault("TR.AssetType"),
                ["TR.CouponRate"]       = fields.GetValueOrDefault("TR.CouponRate"),
                ["TR.MaturityDate"]     = fields.GetValueOrDefault("TR.MaturityDate"),
                ["TR.FaceValue"]        = fields.GetValueOrDefault("TR.FaceValue"),
                ["TR.PEInclExtraItems"] = fields.GetValueOrDefault("TR.PEInclExtraItems"),
            }
        };
    }

    private ExternalSecurityData MapSearchHitToExternalSecurityData(
        Models.RefinitivSearchSource source,
        string keyword)
    {
        return new ExternalSecurityData
        {
            Symbol          = source.Ric ?? source.PrimaryRic ?? keyword,
            Name            = source.DocumentTitle ?? string.Empty,
            Description     = source.DocumentTitle ?? string.Empty,
            IdentifierType  = IdentifierType.Reuters,
            IdentifierValue = source.Ric ?? source.PrimaryRic ?? keyword,
            SecurityType    = MapSecurityType(source.RcsAssetCategoryLeaf),
            Exchange        = source.ExchangeName,
            Currency        = source.Currency,
            Country         = null,
            Source          = DataSourceType.Reuters,
            RawData         = new Dictionary<string, string?>
            {
                ["PermID"]       = source.PermId,
                ["RIC"]          = source.Ric,
                ["AssetClass"]   = source.AssetClass,
                ["AssetState"]   = source.AssetState,
                ["ISIN"]         = source.Isin,
                ["CUSIP"]        = source.Cusip,
                ["SEDOL"]        = source.Sedol,
            }
        };
    }

    private static ExternalPriceData MapToExternalPriceData(
        Models.RefinitivPricingData data,
        string symbol)
    {
        var fields = ExtractFields(data.Headers, data.Data);

        _ = decimal.TryParse(fields.GetValueOrDefault("TR.PriceLast"),
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture, out var last);
        _ = decimal.TryParse(fields.GetValueOrDefault("TR.PriceOpen"),
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture, out var open);
        _ = decimal.TryParse(fields.GetValueOrDefault("TR.PriceHigh"),
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture, out var high);
        _ = decimal.TryParse(fields.GetValueOrDefault("TR.PriceLow"),
            System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture, out var low);
        _ = long.TryParse(fields.GetValueOrDefault("TR.Volume"), out var volume);
        _ = DateTime.TryParse(fields.GetValueOrDefault("TR.CloseDate"), out var date);

        return new ExternalPriceData
        {
            Symbol    = data.Instrument ?? symbol,
            Price     = last,
            PriceType = "Last",
            OpenPrice = open,
            HighPrice = high,
            LowPrice  = low,
            Volume    = volume,
            PriceDate = date == default ? DateTime.UtcNow.Date : date,
            Source    = DataSourceType.Reuters
        };
    }

    /// <summary>
    /// Flattens the EDP tabular response (headers list + data row) into a string→string? dict.
    /// Only the first data row is used for snapshot/reference-data calls.
    /// </summary>
    private static Dictionary<string, string?> ExtractFields(
        List<Models.RefinitivHeader>? headers,
        List<Dictionary<string, object?>>? data)
    {
        var dict = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);
        if (headers == null || data == null || data.Count == 0)
            return dict;

        var row = data[0];
        foreach (var header in headers)
        {
            if (header.Name == null) continue;
            row.TryGetValue(header.Name, out var val);
            dict[header.Name] = val?.ToString();
        }

        return dict;
    }

    private static SecurityType MapSecurityType(string? assetType) =>
        assetType?.ToUpperInvariant() switch
        {
            "EQUITY" or "ORDINARYSHARES" or "PREFERREDSHARES" => SecurityType.Equity,
            "BOND" or "CORPBOND" or "CORPORATEBOND"           => SecurityType.CorporateBond,
            "GOVTBOND" or "GOVERNMENTBOND" or "SOVEREIGN"     => SecurityType.TreasuryBond,
            "MUNIBOND" or "MUNICIPALBOND"                      => SecurityType.MunicipalBond,
            "MTGE" or "MORTGAGEBOND"                          => SecurityType.Bond,
            "FUND" or "ETF" or "MUTUALFUND"                   => SecurityType.Other,
            _                                                  => SecurityType.Other
        };
}
