using System.Text.Json.Serialization;

namespace SecurityApp.Plugin.Bloomberg.Models;

// ── OAuth2 token response ─────────────────────────────────────────────────────

/// <summary>
/// Bloomberg BEAP OAuth2 client-credentials token response.
/// POST {host}/as/token.oauth2
/// </summary>
public class BloombergTokenResponse
{
    [JsonPropertyName("access_token")]
    public string AccessToken { get; set; } = string.Empty;

    [JsonPropertyName("token_type")]
    public string TokenType { get; set; } = "Bearer";

    [JsonPropertyName("expires_in")]
    public int ExpiresIn { get; set; } = 3600;
}

// ── Reference-data request / response ────────────────────────────────────────

/// <summary>
/// Bloomberg BEAP /eap/catalogs/bbg/datasets/securityMasterDataSet/snapshots request body.
/// Requests a set of fields for a list of identifiers.
/// </summary>
public class BloombergReferenceDataRequest
{
    [JsonPropertyName("universe")]
    public BloombergUniverse Universe { get; set; } = new();

    [JsonPropertyName("fieldList")]
    public BloombergFieldList FieldList { get; set; } = new();
}

public class BloombergUniverse
{
    [JsonPropertyName("contains")]
    public List<BloombergIdentifier> Contains { get; set; } = new();
}

public class BloombergIdentifier
{
    [JsonPropertyName("@type")]
    public string Type { get; set; } = "Identifier";

    [JsonPropertyName("identifierType")]
    public string IdentifierType { get; set; } = "TICKER";  // TICKER | ISIN | CUSIP | SEDOL | BB_GLOBAL

    [JsonPropertyName("identifierValue")]
    public string IdentifierValue { get; set; } = string.Empty;
}

public class BloombergFieldList
{
    [JsonPropertyName("contains")]
    public List<BloombergField> Contains { get; set; } = new();
}

public class BloombergField
{
    [JsonPropertyName("@type")]
    public string Type { get; set; } = "DataField";

    [JsonPropertyName("cleanName")]
    public string CleanName { get; set; } = string.Empty;
}

/// <summary>
/// Bloomberg BEAP snapshot/reference-data response envelope.
/// The actual data arrives asynchronously via a download URL in production;
/// this model covers the synchronous reply format used in emulated / sandbox mode.
/// </summary>
public class BloombergReferenceDataResponse
{
    [JsonPropertyName("data")]
    public List<BloombergSecurityData> Data { get; set; } = new();

    [JsonPropertyName("errors")]
    public List<BloombergError>? Errors { get; set; }
}

public class BloombergSecurityData
{
    [JsonPropertyName("identifier")]
    public BloombergIdentifier? Identifier { get; set; }

    [JsonPropertyName("fields")]
    public Dictionary<string, string?> Fields { get; set; } = new();
}

public class BloombergError
{
    [JsonPropertyName("identifier")]
    public BloombergIdentifier? Identifier { get; set; }

    [JsonPropertyName("code")]
    public string Code { get; set; } = string.Empty;

    [JsonPropertyName("message")]
    public string Message { get; set; } = string.Empty;
}

// ── Pricing request / response ────────────────────────────────────────────────

/// <summary>
/// Bloomberg BEAP /eap/catalogs/bbg/datasets/pricingSourceDataSet/snapshots request body.
/// </summary>
public class BloombergPricingRequest
{
    [JsonPropertyName("universe")]
    public BloombergUniverse Universe { get; set; } = new();

    [JsonPropertyName("pricingSourceOptions")]
    public BloombergPricingSourceOptions PricingSourceOptions { get; set; } = new();
}

public class BloombergPricingSourceOptions
{
    [JsonPropertyName("pricingSource")]
    public string PricingSource { get; set; } = "BGN";  // BGN | BVAL | COMPOSITE
}

public class BloombergPricingDataResponse
{
    [JsonPropertyName("data")]
    public List<BloombergPriceData> Data { get; set; } = new();

    [JsonPropertyName("errors")]
    public List<BloombergError>? Errors { get; set; }
}

public class BloombergPriceData
{
    [JsonPropertyName("identifier")]
    public BloombergIdentifier? Identifier { get; set; }

    [JsonPropertyName("date")]
    public string Date { get; set; } = string.Empty;          // ISO-8601 date

    [JsonPropertyName("pxLast")]
    public string? PxLast { get; set; }

    [JsonPropertyName("pxOpen")]
    public string? PxOpen { get; set; }

    [JsonPropertyName("pxHigh")]
    public string? PxHigh { get; set; }

    [JsonPropertyName("pxLow")]
    public string? PxLow { get; set; }

    [JsonPropertyName("volume")]
    public string? Volume { get; set; }

    [JsonPropertyName("currency")]
    public string? Currency { get; set; }
}

// ── Historical pricing ────────────────────────────────────────────────────────

public class BloombergHistoricalPricingResponse
{
    [JsonPropertyName("data")]
    public List<BloombergHistoricalPriceData> Data { get; set; } = new();
}

public class BloombergHistoricalPriceData
{
    [JsonPropertyName("identifier")]
    public BloombergIdentifier? Identifier { get; set; }

    [JsonPropertyName("timeSeries")]
    public List<BloombergOhlcv> TimeSeries { get; set; } = new();
}

public class BloombergOhlcv
{
    [JsonPropertyName("date")]
    public string Date { get; set; } = string.Empty;

    [JsonPropertyName("pxLast")]
    public string? PxLast { get; set; }

    [JsonPropertyName("pxOpen")]
    public string? PxOpen { get; set; }

    [JsonPropertyName("pxHigh")]
    public string? PxHigh { get; set; }

    [JsonPropertyName("pxLow")]
    public string? PxLow { get; set; }

    [JsonPropertyName("volume")]
    public string? Volume { get; set; }
}
