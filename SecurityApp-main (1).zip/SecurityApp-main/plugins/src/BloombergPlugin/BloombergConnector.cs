using Microsoft.Extensions.Logging;
using SecurityApp.Core.Plugins.Interfaces;
using SecurityApp.Core.Pricing.Interfaces;
using SecurityApp.Core.Pricing.Models;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Securities.Interfaces;
using SecurityApp.Core.Securities.Models;
using SecurityApp.Core.Shared.Enums;

namespace SecurityApp.Plugin.Bloomberg;

/// <summary>
/// Combined Bloomberg connector implementing both ISecurityDataProvider and IPricingDataProvider.
/// Communicates with the Bloomberg Enterprise Access Point (BEAP) REST API via BloombergClient.
///
/// A single instance is returned by BloombergPlugin.GetConnector() and can be cast
/// to either interface by the DataProviderService.
/// </summary>
public class BloombergConnector : ISecurityDataProvider, IPricingDataProvider
{
    private readonly BloombergClient _client;
    private readonly ILogger<BloombergConnector> _logger;

    // IDataConnector
    public DataSourceType SourceType => DataSourceType.Bloomberg;
    public string SourceName => "Bloomberg";

    // ISecurityDataProvider / IPricingDataProvider — Bloomberg is the highest-priority source
    public int Priority => 1;

    public BloombergConnector(BloombergClient client, ILogger<BloombergConnector> logger)
    {
        _client = client;
        _logger = logger;
    }

    // ── IDataConnector ────────────────────────────────────────────────────────

    public Task<bool> IsAvailableAsync(CancellationToken cancellationToken = default)
        => _client.IsAvailableAsync(cancellationToken);

    public async Task<HealthStatus> GetHealthStatusAsync(CancellationToken cancellationToken = default)
    {
        var available = await _client.IsAvailableAsync(cancellationToken);
        return new HealthStatus
        {
            IsHealthy = available,
            Message   = available
                ? "Bloomberg BEAP API is reachable and authenticated."
                : "Bloomberg BEAP API unavailable or authentication failed.",
            CheckedAt = DateTime.UtcNow
        };
    }

    // ── ISecurityDataProvider ─────────────────────────────────────────────────

    public bool SupportsIdentifierType(IdentifierType identifierType) =>
        identifierType is IdentifierType.ISIN
            or IdentifierType.CUSIP
            or IdentifierType.SEDOL
            or IdentifierType.Ticker
            or IdentifierType.Bloomberg
            or IdentifierType.Other;

    public async Task<ExternalSecurityData?> GetSecurityAsync(
        string identifierValue,
        IdentifierType identifierType,
        CancellationToken cancellationToken = default)
    {
        var data = await _client.GetReferenceDataAsync(
            identifierValue,
            identifierType.ToString(),
            cancellationToken);

        if (data == null)
        {
            _logger.LogWarning("Bloomberg: no reference data for {Type}={Value}", identifierType, identifierValue);
            return null;
        }

        return MapToExternalSecurityData(data, identifierType, identifierValue);
    }

    public async Task<IEnumerable<ExternalSecurityData>> SearchSecuritiesAsync(
        string keyword,
        CancellationToken cancellationToken = default)
    {
        var response = await _client.SearchAsync(keyword, cancellationToken);
        if (response?.Data is not { Count: > 0 })
            return Enumerable.Empty<ExternalSecurityData>();

        return response.Data
            .Select(d => MapToExternalSecurityData(d, IdentifierType.Bloomberg, keyword))
            .Where(s => !string.IsNullOrWhiteSpace(s.Name));
    }

    // ── IPricingDataProvider ──────────────────────────────────────────────────

    public async Task<ExternalPriceData?> GetCurrentPriceAsync(
        string symbol,
        CancellationToken cancellationToken = default)
    {
        // Symbol may be ISIN or Bloomberg ticker — resolve by trying both
        var price = await _client.GetLatestPriceAsync(symbol, "TICKER", cancellationToken)
                 ?? await _client.GetLatestPriceAsync(symbol, "ISIN",   cancellationToken);

        if (price == null)
        {
            _logger.LogWarning("Bloomberg: no latest price for {Symbol}", symbol);
            return null;
        }

        return MapToExternalPriceData(price, symbol);
    }

    public async Task<IEnumerable<ExternalPriceData>> GetHistoricalPricesAsync(
        string symbol,
        DateTime fromDate,
        DateTime toDate,
        CancellationToken cancellationToken = default)
    {
        var history = await _client.GetHistoricalPricesAsync(
            symbol, "TICKER", fromDate, toDate, cancellationToken);

        if (history?.TimeSeries is not { Count: > 0 })
        {
            _logger.LogWarning("Bloomberg: no historical prices for {Symbol} {From:d}–{To:d}",
                symbol, fromDate, toDate);
            return Enumerable.Empty<ExternalPriceData>();
        }

        var results = new List<ExternalPriceData>();

        foreach (var bar in history.TimeSeries)
        {
            if (!DateTime.TryParse(bar.Date, out var date))
                continue;

            _ = decimal.TryParse(bar.PxLast, System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out var close);
            _ = decimal.TryParse(bar.PxOpen, System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out var open);
            _ = decimal.TryParse(bar.PxHigh, System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out var high);
            _ = decimal.TryParse(bar.PxLow, System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out var low);
            _ = long.TryParse(bar.Volume, out var volume);

            results.Add(new ExternalPriceData
            {
                Symbol    = symbol,
                Price     = close,
                PriceType = "Close",
                OpenPrice = open,
                HighPrice = high,
                LowPrice  = low,
                Volume    = volume,
                PriceDate = date,
                Source    = DataSourceType.Bloomberg
            });
        }

        return results.OrderByDescending(p => p.PriceDate);
    }

    // ── Mapping helpers ───────────────────────────────────────────────────────

    private static ExternalSecurityData MapToExternalSecurityData(
        Models.BloombergSecurityData data,
        IdentifierType identifierType,
        string identifierValue)
    {
        var f = data.Fields;

        return new ExternalSecurityData
        {
            Symbol          = f.GetValueOrDefault("ID_BB_GLOBAL") ?? identifierValue,
            Name            = f.GetValueOrDefault("NAME")         ?? string.Empty,
            Description     = f.GetValueOrDefault("SECURITY_DES") ?? string.Empty,
            IdentifierType  = identifierType,
            IdentifierValue = identifierValue,
            SecurityType    = MapSecurityType(f.GetValueOrDefault("SECURITY_TYP")),
            Exchange        = f.GetValueOrDefault("EXCH_CODE"),
            Currency        = f.GetValueOrDefault("CRNCY"),
            Country         = f.GetValueOrDefault("COUNTRY"),
            Sector          = f.GetValueOrDefault("INDUSTRY_SECTOR"),
            Industry        = f.GetValueOrDefault("INDUSTRY_GROUP"),
            Issuer          = f.GetValueOrDefault("ISSUER") ?? f.GetValueOrDefault("LONG_COMP_NAME"),
            Source          = DataSourceType.Bloomberg,
            RawData         = new Dictionary<string, string?>
            {
                ["NAME"]             = f.GetValueOrDefault("NAME"),
                ["SECURITY_TYP"]     = f.GetValueOrDefault("SECURITY_TYP"),
                ["ASSET_CLASS"]      = f.GetValueOrDefault("ASSET_CLASS"),
                ["EXCH_CODE"]        = f.GetValueOrDefault("EXCH_CODE"),
                ["INDUSTRY_SECTOR"]  = f.GetValueOrDefault("INDUSTRY_SECTOR"),
                ["ID_ISIN"]          = f.GetValueOrDefault("ID_ISIN"),
                ["ID_CUSIP"]         = f.GetValueOrDefault("ID_CUSIP"),
                ["ID_SEDOL1"]        = f.GetValueOrDefault("ID_SEDOL1"),
                ["MATURITY"]         = f.GetValueOrDefault("MATURITY"),
                ["COUPON"]           = f.GetValueOrDefault("COUPON"),
                ["PAR_AMT"]          = f.GetValueOrDefault("PAR_AMT"),
                ["SERIES"]           = f.GetValueOrDefault("SERIES"),
            }
        };
    }

    private static ExternalPriceData MapToExternalPriceData(
        Models.BloombergPriceData price,
        string symbol)
    {
        _ = decimal.TryParse(price.PxLast, System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture, out var last);
        _ = decimal.TryParse(price.PxOpen, System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture, out var open);
        _ = decimal.TryParse(price.PxHigh, System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture, out var high);
        _ = decimal.TryParse(price.PxLow, System.Globalization.NumberStyles.Any,
            System.Globalization.CultureInfo.InvariantCulture, out var low);
        _ = long.TryParse(price.Volume, out var volume);
        _ = DateTime.TryParse(price.Date, out var date);

        return new ExternalPriceData
        {
            Symbol    = price.Identifier?.IdentifierValue ?? symbol,
            Price     = last,
            PriceType = "Last",
            OpenPrice = open,
            HighPrice = high,
            LowPrice  = low,
            Volume    = volume,
            PriceDate = date == default ? DateTime.UtcNow.Date : date,
            Source    = DataSourceType.Bloomberg
        };
    }

    private static SecurityType MapSecurityType(string? bloombergType) =>
        bloombergType?.ToUpperInvariant() switch
        {
            "CORP"  => SecurityType.CorporateBond,
            "GOVT"  => SecurityType.TreasuryBond,
            "MUNI"  => SecurityType.MunicipalBond,
            "MTGE"  => SecurityType.Bond,
            "M-MKT" => SecurityType.Bond,
            "EQUITY" or "EQ"                    => SecurityType.Equity,
            "INDEX"                             => SecurityType.Other,
            "CURNCY" or "CURRENCY" or "FX"      => SecurityType.Other,
            "CMDTY" or "COMMODITY"              => SecurityType.Other,
            _                                   => SecurityType.Other
        };
}
