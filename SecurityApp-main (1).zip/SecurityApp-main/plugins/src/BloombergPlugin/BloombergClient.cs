using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using SecurityApp.Plugin.Bloomberg.Models;

namespace SecurityApp.Plugin.Bloomberg;

/// <summary>
/// Low-level HTTP client for the Bloomberg Enterprise Access Point (BEAP) REST API.
///
/// Authentication: OAuth2 client-credentials flow.
///   POST {host}/as/token.oauth2 → Bearer token (1-hour lifetime, auto-refreshed).
///
/// Key endpoints used:
///   POST /eap/catalogs/bbg/datasets/securityMasterDataSet/snapshots  → reference data
///   POST /eap/catalogs/bbg/datasets/pricingSourceDataSet/snapshots    → latest prices
///   POST /eap/catalogs/bbg/datasets/pricingSourceDataSet/history      → historical prices
///
/// In sandbox / developer mode the host is typically https://api.bloomberg.com.
/// </summary>
public class BloombergClient
{
    private readonly HttpClient _httpClient;
    private readonly string _clientId;
    private readonly string _clientSecret;
    private readonly ILogger<BloombergClient> _logger;
    private readonly int _maxRetries;

    private string? _accessToken;
    private DateTime _tokenExpiresAt = DateTime.MinValue;

    private static readonly JsonSerializerOptions _json = new(JsonSerializerDefaults.Web);

    // Bloomberg reference-data fields requested for every security lookup
    private static readonly string[] SecurityFields =
    [
        "NAME", "SHORT_NAME", "SECURITY_TYP", "ASSET_CLASS", "CRNCY",
        "COUNTRY", "EXCH_CODE", "INDUSTRY_SECTOR", "INDUSTRY_GROUP",
        "ISSUER", "ID_ISIN", "ID_CUSIP", "ID_SEDOL1",
        "MATURITY", "COUPON", "PAR_AMT", "SERIES",
        "SECURITY_DES", "LONG_COMP_NAME"
    ];

    public BloombergClient(
        HttpClient httpClient,
        string clientId,
        string clientSecret,
        ILogger<BloombergClient> logger,
        int maxRetries = 3)
    {
        _httpClient  = httpClient;
        _clientId    = clientId;
        _clientSecret = clientSecret;
        _logger      = logger;
        _maxRetries  = maxRetries;
    }

    // ── Auth ──────────────────────────────────────────────────────────────────

    private async Task EnsureTokenAsync(CancellationToken ct)
    {
        if (_accessToken != null && DateTime.UtcNow < _tokenExpiresAt.AddSeconds(-60))
            return;

        _logger.LogDebug("Bloomberg BEAP: refreshing OAuth2 token");

        var form = new Dictionary<string, string>
        {
            ["grant_type"]    = "client_credentials",
            ["client_id"]     = _clientId,
            ["client_secret"] = _clientSecret
        };

        using var req = new HttpRequestMessage(HttpMethod.Post, "as/token.oauth2")
        {
            Content = new FormUrlEncodedContent(form)
        };

        var resp = await SendWithRetryAsync(req, ct);
        resp.EnsureSuccessStatusCode();

        var token = await resp.Content.ReadFromJsonAsync<BloombergTokenResponse>(_json, ct)
            ?? throw new InvalidOperationException("Bloomberg BEAP: empty token response.");

        _accessToken    = token.AccessToken;
        _tokenExpiresAt = DateTime.UtcNow.AddSeconds(token.ExpiresIn);
    }

    // ── Reference data ────────────────────────────────────────────────────────

    /// <summary>
    /// Fetches reference (static) data for a single identifier.
    /// Returns null when the identifier is not found or returns an error.
    /// </summary>
    public async Task<BloombergSecurityData?> GetReferenceDataAsync(
        string identifierValue,
        string identifierType,
        CancellationToken ct = default)
    {
        await EnsureTokenAsync(ct);

        var body = new BloombergReferenceDataRequest
        {
            Universe = new BloombergUniverse
            {
                Contains =
                [
                    new BloombergIdentifier
                    {
                        IdentifierType  = NormaliseIdentifierType(identifierType),
                        IdentifierValue = identifierValue
                    }
                ]
            },
            FieldList = new BloombergFieldList
            {
                Contains = SecurityFields
                    .Select(f => new BloombergField { CleanName = f })
                    .ToList()
            }
        };

        _logger.LogDebug("Bloomberg BEAP reference-data: {Type}={Value}", identifierType, identifierValue);

        var response = await PostAsync<BloombergReferenceDataRequest, BloombergReferenceDataResponse>(
            "eap/catalogs/bbg/datasets/securityMasterDataSet/snapshots", body, ct);

        if (response?.Data is not { Count: > 0 })
        {
            _logger.LogWarning("Bloomberg BEAP: no reference data for {Type}={Value}", identifierType, identifierValue);
            return null;
        }

        if (response.Errors is { Count: > 0 })
        {
            foreach (var err in response.Errors)
                _logger.LogWarning("Bloomberg BEAP error [{Code}]: {Message}", err.Code, err.Message);
        }

        return response.Data[0];
    }

    /// <summary>
    /// Searches Bloomberg for securities matching a keyword (uses TICKER lookup).
    /// </summary>
    public async Task<BloombergReferenceDataResponse?> SearchAsync(
        string keyword,
        CancellationToken ct = default)
    {
        await EnsureTokenAsync(ct);

        // Bloomberg BEAP does not have a free-text search in the standard dataset;
        // we do a ticker-based lookup and fall back to ISIN.
        var body = new BloombergReferenceDataRequest
        {
            Universe = new BloombergUniverse
            {
                Contains =
                [
                    new BloombergIdentifier
                    {
                        IdentifierType  = "TICKER",
                        IdentifierValue = keyword.ToUpperInvariant()
                    }
                ]
            },
            FieldList = new BloombergFieldList
            {
                Contains = SecurityFields
                    .Select(f => new BloombergField { CleanName = f })
                    .ToList()
            }
        };

        _logger.LogDebug("Bloomberg BEAP search: {Keyword}", keyword);

        return await PostAsync<BloombergReferenceDataRequest, BloombergReferenceDataResponse>(
            "eap/catalogs/bbg/datasets/securityMasterDataSet/snapshots", body, ct);
    }

    // ── Pricing ───────────────────────────────────────────────────────────────

    /// <summary>
    /// Fetches the latest price for a single identifier using the BGN pricing source.
    /// </summary>
    public async Task<BloombergPriceData?> GetLatestPriceAsync(
        string identifierValue,
        string identifierType,
        CancellationToken ct = default)
    {
        await EnsureTokenAsync(ct);

        var body = new BloombergPricingRequest
        {
            Universe = new BloombergUniverse
            {
                Contains =
                [
                    new BloombergIdentifier
                    {
                        IdentifierType  = NormaliseIdentifierType(identifierType),
                        IdentifierValue = identifierValue
                    }
                ]
            }
        };

        _logger.LogDebug("Bloomberg BEAP latest price: {Type}={Value}", identifierType, identifierValue);

        var response = await PostAsync<BloombergPricingRequest, BloombergPricingDataResponse>(
            "eap/catalogs/bbg/datasets/pricingSourceDataSet/snapshots", body, ct);

        if (response?.Data is not { Count: > 0 })
        {
            _logger.LogWarning("Bloomberg BEAP: no price for {Type}={Value}", identifierType, identifierValue);
            return null;
        }

        return response.Data[0];
    }

    /// <summary>
    /// Fetches OHLCV history for the given date range.
    /// </summary>
    public async Task<BloombergHistoricalPriceData?> GetHistoricalPricesAsync(
        string identifierValue,
        string identifierType,
        DateTime fromDate,
        DateTime toDate,
        CancellationToken ct = default)
    {
        await EnsureTokenAsync(ct);

        var body = new
        {
            universe = new
            {
                contains = new[]
                {
                    new
                    {
                        type             = "Identifier",
                        identifierType   = NormaliseIdentifierType(identifierType),
                        identifierValue  = identifierValue
                    }
                }
            },
            startDate = fromDate.ToString("yyyy-MM-dd"),
            endDate   = toDate.ToString("yyyy-MM-dd"),
            interval  = "DAILY"
        };

        _logger.LogDebug("Bloomberg BEAP historical: {Type}={Value} {From}–{To}",
            identifierType, identifierValue,
            fromDate.ToString("yyyy-MM-dd"), toDate.ToString("yyyy-MM-dd"));

        var response = await PostAsync<object, BloombergHistoricalPricingResponse>(
            "eap/catalogs/bbg/datasets/pricingSourceDataSet/history", body, ct);

        return response?.Data?.FirstOrDefault();
    }

    // ── Health ────────────────────────────────────────────────────────────────

    /// <summary>
    /// Validates connectivity by requesting a token. Returns true if the token exchange succeeds.
    /// </summary>
    public async Task<bool> IsAvailableAsync(CancellationToken ct = default)
    {
        try
        {
            await EnsureTokenAsync(ct);
            return _accessToken != null;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Bloomberg BEAP health check failed");
            return false;
        }
    }

    // ── Internals ─────────────────────────────────────────────────────────────

    private async Task<TResponse?> PostAsync<TRequest, TResponse>(
        string path,
        TRequest payload,
        CancellationToken ct)
    {
        var json    = JsonSerializer.Serialize(payload, _json);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        using var req = new HttpRequestMessage(HttpMethod.Post, path) { Content = content };
        if (_accessToken != null)
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _accessToken);

        var resp = await SendWithRetryAsync(req, ct);

        if (!resp.IsSuccessStatusCode)
        {
            var body = await resp.Content.ReadAsStringAsync(ct);
            _logger.LogWarning("Bloomberg BEAP {Path} → {Status}: {Body}", path, (int)resp.StatusCode, body);
            return default;
        }

        return await resp.Content.ReadFromJsonAsync<TResponse>(_json, ct);
    }

    private async Task<HttpResponseMessage> SendWithRetryAsync(HttpRequestMessage req, CancellationToken ct)
    {
        var delay = TimeSpan.FromSeconds(2);

        for (int attempt = 1; attempt <= _maxRetries; attempt++)
        {
            try
            {
                // Clone the request on retry (HttpRequestMessage is not reusable)
                var clone = await CloneRequestAsync(req);
                var response = await _httpClient.SendAsync(clone, ct);

                if ((int)response.StatusCode == 429 && attempt < _maxRetries)
                {
                    _logger.LogWarning("Bloomberg BEAP rate-limited (attempt {Attempt}/{Max}), backing off {Delay}",
                        attempt, _maxRetries, delay);
                    await Task.Delay(delay, ct);
                    delay *= 2;
                    continue;
                }

                return response;
            }
            catch (HttpRequestException ex) when (attempt < _maxRetries)
            {
                _logger.LogWarning(ex, "Bloomberg BEAP request failed (attempt {Attempt}/{Max})", attempt, _maxRetries);
                await Task.Delay(delay, ct);
                delay *= 2;
            }
        }

        // Final attempt — let exceptions propagate
        return await _httpClient.SendAsync(req, ct);
    }

    private static async Task<HttpRequestMessage> CloneRequestAsync(HttpRequestMessage req)
    {
        var clone = new HttpRequestMessage(req.Method, req.RequestUri);

        foreach (var header in req.Headers)
            clone.Headers.TryAddWithoutValidation(header.Key, header.Value);

        if (req.Content != null)
        {
            var body = await req.Content.ReadAsStringAsync();
            clone.Content = new StringContent(body, Encoding.UTF8,
                req.Content.Headers.ContentType?.MediaType ?? "application/json");
        }

        return clone;
    }

    private static string NormaliseIdentifierType(string identifierType) =>
        identifierType.ToUpperInvariant() switch
        {
            "ISIN"             => "ISIN",
            "CUSIP"            => "CUSIP",
            "SEDOL"            => "SEDOL1",
            "BLOOMBERG_TICKER" => "TICKER",
            "TICKER"           => "TICKER",
            "BB_GLOBAL"        => "BB_GLOBAL",
            _                  => "TICKER"
        };
}
