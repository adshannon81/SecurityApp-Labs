using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using SecurityApp.Core.Plugins.Interfaces;
using SecurityApp.Core.Shared.Enums;

namespace SecurityApp.Plugin.Bloomberg;

/// <summary>
/// Plugin entry point for the Bloomberg BEAP connector.
/// The PluginLoader discovers this class by scanning for IConnectorPlugin implementations.
///
/// Required configuration (appsettings / env / Vault):
///   DataConnectors:Bloomberg:BaseUrl      — e.g. https://api.bloomberg.com/
///   DataConnectors:Bloomberg:ClientId     — BEAP OAuth2 client ID
///   DataConnectors:Bloomberg:ClientSecret — BEAP OAuth2 client secret (inject from Vault in prod)
///   DataConnectors:Bloomberg:TimeoutSeconds (optional, default 30)
///   DataConnectors:Bloomberg:MaxRetries   (optional, default 3)
/// </summary>
public sealed class BloombergPlugin : IConnectorPlugin
{
    private BloombergConnector? _connector;
    private bool _disposed;

    public PluginMetadata Metadata => new()
    {
        Name          = "Bloomberg",
        Version       = "1.0.0",
        Author        = "SecurityApp",
        Description   = "Bloomberg Enterprise Access Point (BEAP) connector for security reference data and pricing.",
        ConnectorType = DataSourceType.Bloomberg
    };

    public bool IsCompatible() => true;

    public Task InitializeAsync(IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        var config = (IConfiguration?)serviceProvider.GetService(typeof(IConfiguration))
            ?? throw new InvalidOperationException("IConfiguration not available in plugin service provider.");

        var section = config.GetSection("DataConnectors:Bloomberg");

        var baseUrl = section["BaseUrl"];
        if (string.IsNullOrEmpty(baseUrl))
            throw new InvalidOperationException(
                "DataConnectors:Bloomberg:BaseUrl is required. " +
                "Expected value: https://api.bloomberg.com/");

        var clientId = section["ClientId"];
        if (string.IsNullOrEmpty(clientId))
            throw new InvalidOperationException(
                "DataConnectors:Bloomberg:ClientId is required. " +
                "Obtain from the Bloomberg BEAP developer portal.");

        var clientSecret = section["ClientSecret"];
        if (string.IsNullOrEmpty(clientSecret))
            throw new InvalidOperationException(
                "DataConnectors:Bloomberg:ClientSecret is required. " +
                "Store in Vault: DataConnectors__Bloomberg__ClientSecret");

        var timeoutSeconds = section.GetValue<int>("TimeoutSeconds", 30);
        var maxRetries     = section.GetValue<int>("MaxRetries", 3);

        var httpClient = new HttpClient
        {
            BaseAddress = new Uri(baseUrl.TrimEnd('/') + '/'),
            Timeout     = TimeSpan.FromSeconds(timeoutSeconds)
        };

        var loggerFactory = (ILoggerFactory?)serviceProvider.GetService(typeof(ILoggerFactory))
            ?? NullLoggerFactory.Instance;

        var clientLogger    = loggerFactory.CreateLogger<BloombergClient>();
        var connectorLogger = loggerFactory.CreateLogger<BloombergConnector>();

        var client = new BloombergClient(httpClient, clientId, clientSecret, clientLogger, maxRetries);
        _connector = new BloombergConnector(client, connectorLogger);

        return Task.CompletedTask;
    }

    public IDataConnector GetConnector()
    {
        if (_connector == null)
            throw new InvalidOperationException("BloombergPlugin has not been initialised. Call InitializeAsync first.");
        return _connector;
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        // HttpClient inside BloombergClient is owned here — nothing extra to dispose.
    }
}
