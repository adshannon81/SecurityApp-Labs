﻿using System.Text.Json;
using Microsoft.Extensions.Logging;
using SecurityApp.Core.Securities.Interfaces;
using SecurityApp.Core.Import.Entities;
using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Core.Shared.Enums;
using SecurityApp.Core.Plugins.Interfaces;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Securities.Models;
using SecurityApp.Core.Import.Models;
using SecurityApp.Plugin.FlatFile.Transport;

namespace SecurityApp.Plugin.FlatFile;

/// <summary>
/// Reads security reference data from JSON files in a configured directory.
///
/// Multiple named profiles can be configured; each has a <c>FilePattern</c> glob matched
/// against the file name. The first matching profile wins; falls back to defaults when none match.
///
/// Supported JSONPath in <c>RecordsPath</c>:
///   <c>"$[*]"</c>            - root array
///   <c>"$.securities[*]"</c> - named array property at root
///   <c>"$.a.b[*]"</c>        - nested path to array
/// </summary>
public class JsonFileConnector : ISecurityDataProvider
{
    private readonly string _importDirectory;
    private readonly IReadOnlyDictionary<string, JsonImportProfile> _profiles;
    private readonly IReadOnlyDictionary<string, ImportProfile> _dbProfileMap;
    private readonly IImportValidationRunner? _validationRunner;
    private readonly ISecretResolver _resolver;
    private readonly ILogger<JsonFileConnector> _logger;

    private static readonly JsonImportProfile _defaultProfile = new();

    // -- IDataConnector ---------------------------------------------
    public DataSourceType SourceType => DataSourceType.JsonFile;
    public string SourceName => "JsonFile";
    public int Priority => 100;

    public JsonFileConnector(
        string importDirectory,
        IReadOnlyDictionary<string, JsonImportProfile> profiles,
        IReadOnlyList<ImportProfile>? dbProfiles,
        IImportValidationRunner? validationRunner,
        ISecretResolver resolver,
        ILogger<JsonFileConnector> logger)
    {
        _importDirectory  = importDirectory;
        _profiles         = profiles;
        _validationRunner = validationRunner;
        _resolver         = resolver;
        _logger           = logger;
        _dbProfileMap = dbProfiles != null
            ? dbProfiles.ToDictionary(p => p.Name, p => p, StringComparer.OrdinalIgnoreCase)
            : new Dictionary<string, ImportProfile>(StringComparer.OrdinalIgnoreCase);
    }

    // -- IDataConnector ---------------------------------------------

    public Task<bool> IsAvailableAsync(CancellationToken cancellationToken = default)
        => Task.FromResult(Directory.Exists(_importDirectory));

    public Task<HealthStatus> GetHealthStatusAsync(CancellationToken cancellationToken = default)
    {
        var exists = Directory.Exists(_importDirectory);
        return Task.FromResult(new HealthStatus
        {
            IsHealthy = exists,
            Message = exists
                ? $"Import directory '{_importDirectory}' found."
                : $"Import directory '{_importDirectory}' not found.",
            CheckedAt = DateTime.UtcNow
        });
    }

    // -- ISecurityDataProvider --------------------------------------

    public bool SupportsIdentifierType(IdentifierType identifierType) => true;

    public async Task<ExternalSecurityData?> GetSecurityAsync(
        string identifierValue,
        IdentifierType identifierType,
        CancellationToken cancellationToken = default)
    {
        var records = await ReadAllSecuritiesAsync(cancellationToken);
        return records.FirstOrDefault(r =>
            string.Equals(r.IdentifierValue, identifierValue, StringComparison.OrdinalIgnoreCase));
    }

    public async Task<IEnumerable<ExternalSecurityData>> SearchSecuritiesAsync(
        string keyword,
        CancellationToken cancellationToken = default)
    {
        var records = await ReadAllSecuritiesAsync(cancellationToken);
        return records.Where(r =>
            r.Symbol.Contains(keyword, StringComparison.OrdinalIgnoreCase) ||
            r.Name.Contains(keyword, StringComparison.OrdinalIgnoreCase) ||
            r.IdentifierValue.Contains(keyword, StringComparison.OrdinalIgnoreCase));
    }

    // -- File dispatch ----------------------------------------------

    private async Task<List<ExternalSecurityData>> ReadAllSecuritiesAsync(CancellationToken ct)
    {
        var results = new List<ExternalSecurityData>();

        foreach (var (profileName, profile) in ProfilesOrDefault())
        {
            await using var transport = FileTransportFactory.Create(profile.Transport, _resolver);
            var folder = await transport.AcquireLocalFolderAsync(
                ResolveFolder(profile.Folder), profile.FilePattern, ct);

            if (!Directory.Exists(folder)) continue;

            _dbProfileMap.TryGetValue(profileName, out var dbProfile);

            foreach (var file in Directory.GetFiles(folder, profile.FilePattern))
            {
                try { results.AddRange(await ParseFileAsync(file, profile, dbProfile, ct)); }
                catch (Exception ex) { _logger.LogError(ex, "Error parsing JSON file: {File}", file); }
            }
        }

        return results;
    }

    // -- Parser ----------------------------------------------------

    private async Task<IEnumerable<ExternalSecurityData>> ParseFileAsync(
        string filePath, JsonImportProfile profile, ImportProfile? dbProfile, CancellationToken ct)
    {
        var columnMap = SecurityMapper.BuildLookup(profile.Columns);

        var json = await File.ReadAllTextAsync(filePath, ct);
        using var doc = JsonDocument.Parse(json);

        var elements = SelectElements(doc.RootElement, profile.RecordsPath).ToList();
        var results  = new List<ExternalSecurityData>(elements.Count);
        int rowNo    = 1;

        foreach (var el in elements)
        {
            var row = JsonElementToRow(el);

            var validationErrors = new List<ImportValidationError>();
            if (dbProfile != null && _validationRunner != null &&
                (dbProfile.Columns.Any(c => c.Validations.Count > 0) ||
                 dbProfile.RowValidations.Count > 0))
            {
                // For JSON, row keys already match property names (target fields or source names)
                validationErrors = await _validationRunner.ValidateRowAsync(dbProfile, row, rowNo, ct);
            }

            var record = SecurityMapper.MapSecurity(row, columnMap);
            record.RowNumber       = rowNo;
            record.ValidationErrors = validationErrors;
            results.Add(record);
            rowNo++;
        }

        return results;
    }

    // -- Helpers ---------------------------------------------------

    private string ResolveFolder(string? profileFolder)
        => string.IsNullOrEmpty(profileFolder)
            ? _importDirectory
            : Path.Combine(_importDirectory, profileFolder);

    /// Returns the configured profiles, or a single default profile when none are configured.
    private IEnumerable<KeyValuePair<string, JsonImportProfile>> ProfilesOrDefault()
        => _profiles.Count > 0
            ? _profiles
            : new Dictionary<string, JsonImportProfile> { ["Default"] = _defaultProfile };

    // -- JSONPath resolver -----------------------------------------

    /// <summary>
    /// Lightweight JSONPath resolver. Supports:
    ///   <c>$[*]</c>          root array
    ///   <c>$.prop[*]</c>     root - named array property
    ///   <c>$.a.b[*]</c>      nested path - array
    ///   <c>$.a.b</c>         single object (returned as one-element sequence)
    /// </summary>
    private static IEnumerable<JsonElement> SelectElements(JsonElement root, string path)
    {
        var cursor = root;
        var segments = path.TrimStart('$').TrimStart('.').Split('.');

        foreach (var segment in segments)
        {
            if (string.IsNullOrEmpty(segment)) continue;

            var propName = segment.Contains('[') ? segment[..segment.IndexOf('[')] : segment;

            if (string.IsNullOrEmpty(propName))
            {
                return cursor.ValueKind == JsonValueKind.Array
                    ? cursor.EnumerateArray()
                    : [];
            }

            if (cursor.ValueKind == JsonValueKind.Object &&
                cursor.TryGetProperty(propName, out var child))
                cursor = child;
            else
                return [];
        }

        return cursor.ValueKind == JsonValueKind.Array
            ? cursor.EnumerateArray()
            : [cursor];
    }

    private static Dictionary<string, string> JsonElementToRow(JsonElement element)
    {
        var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (element.ValueKind != JsonValueKind.Object) return row;

        foreach (var prop in element.EnumerateObject())
        {
            row[prop.Name] = prop.Value.ValueKind switch
            {
                JsonValueKind.String => prop.Value.GetString() ?? "",
                JsonValueKind.Number => prop.Value.GetRawText(),
                JsonValueKind.True   => "true",
                JsonValueKind.False  => "false",
                JsonValueKind.Null   => "",
                _                   => prop.Value.GetRawText()
            };
        }

        return row;
    }
}
