﻿using System.Globalization;
using System.Text.RegularExpressions;
using SecurityApp.Core.Import.Models;
using SecurityApp.Core.Securities.Models;
using SecurityApp.Core.Pricing.Models;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Shared.Enums;

namespace SecurityApp.Plugin.FlatFile;

/// <summary>
/// Shared mapping helpers used by FlatFileConnector, JsonFileConnector and XmlFileConnector.
/// Converts flat row dictionaries (source key - raw string value) to domain models.
/// </summary>
internal static class SecurityMapper
{
    /// <summary>
    /// Builds a target→source lookup so that <see cref="Resolve"/> can translate
    /// canonical target field names to actual source column names in the file.
    /// Returns an empty dictionary when no maps are configured (callers fall back to default names).
    /// </summary>
    internal static Dictionary<string, string> BuildLookup(List<ImportColumnMap> maps)
        => maps.ToDictionary(
               m => m.Target.ToLowerInvariant(),   // key:   canonical target field name
               m => m.Source.ToLowerInvariant(),   // value: source column / ordinal in file
               StringComparer.OrdinalIgnoreCase);

    /// <summary>
    /// Resolves a canonical field value from the row by consulting the column map.
    /// The map is keyed by canonical target field name; the value is the source column name.
    /// Falls back to looking up <paramref name="defaultKey"/> directly in the row
    /// when no mapping exists (i.e. the source column header already matches the target name).
    /// </summary>
    internal static string Resolve(
        Dictionary<string, string> row,
        Dictionary<string, string> columnMap,
        string defaultKey)
    {
        // columnMap: target → source
        if (columnMap.TryGetValue(defaultKey, out var sourceKey))
            return row.TryGetValue(sourceKey, out var mv) ? mv : string.Empty;

        // No explicit mapping — source header matches the canonical name directly
        return row.TryGetValue(defaultKey, out var v) ? v : string.Empty;
    }

    internal static ExternalSecurityData MapSecurity(
        Dictionary<string, string> row,
        Dictionary<string, string> columnMap)
    {
        string Get(string key) => Resolve(row, columnMap, key);

        _ = Enum.TryParse<SecurityType>(Get("securitytype"),     ignoreCase: true, out var secType);
        _ = Enum.TryParse<IdentifierType>(Get("identifiertype"), ignoreCase: true, out var idType);
        _ = decimal.TryParse(Get("couponrate"), NumberStyles.Any, CultureInfo.InvariantCulture, out var coupon);
        _ = DateTime.TryParse(Get("maturitydate"), out var maturity);

        var sourceRaw = NullIfEmpty(Get("datasource")) ?? NullIfEmpty(Get("provider"));
        var source = Enum.TryParse<DataSourceType>(sourceRaw, ignoreCase: true, out var parsedSource)
            ? parsedSource
            : DataSourceType.FlatFile;

        return new ExternalSecurityData
        {
            Symbol          = Get("symbol"),
            Name            = Get("name"),
            SecurityType    = secType,
            IdentifierType  = idType,
            IdentifierValue = Get("identifiervalue"),
            Currency        = NullIfEmpty(Get("currency")),
            Exchange        = NullIfEmpty(Get("exchange")),
            Country         = NullIfEmpty(Get("country")),
            Sector          = NullIfEmpty(Get("sector")),
            Industry        = NullIfEmpty(Get("industry")),
            Issuer          = NullIfEmpty(Get("issuer")),
            CouponRate      = coupon == 0 ? null : coupon,
            MaturityDate    = maturity == default ? null : maturity,
            Source          = source
        };
    }

    internal static ExternalPriceData MapPrice(
        Dictionary<string, string> row,
        Dictionary<string, string> columnMap)
    {
        string Get(string key) => Resolve(row, columnMap, key);

        _ = decimal.TryParse(Get("price"),     NumberStyles.Any, CultureInfo.InvariantCulture, out var price);
        _ = decimal.TryParse(Get("bidprice"),  NumberStyles.Any, CultureInfo.InvariantCulture, out var bid);
        _ = decimal.TryParse(Get("askprice"),  NumberStyles.Any, CultureInfo.InvariantCulture, out var ask);
        _ = decimal.TryParse(Get("openprice"), NumberStyles.Any, CultureInfo.InvariantCulture, out var open);
        _ = decimal.TryParse(Get("highprice"), NumberStyles.Any, CultureInfo.InvariantCulture, out var high);
        _ = decimal.TryParse(Get("lowprice"),  NumberStyles.Any, CultureInfo.InvariantCulture, out var low);
        _ = long.TryParse(Get("volume"),       out var volume);
        _ = DateTime.TryParse(Get("pricedate"), out var priceDate);

        var sourceRaw = NullIfEmpty(Get("datasource")) ?? NullIfEmpty(Get("provider"));
        var source = Enum.TryParse<DataSourceType>(sourceRaw, ignoreCase: true, out var parsedSource)
            ? parsedSource
            : DataSourceType.FlatFile;

        return new ExternalPriceData
        {
            Symbol    = Get("symbol"),
            Price     = price,
            PriceType = NullIfEmpty(Get("pricetype")) ?? "Close",
            BidPrice  = bid  == 0 ? null : bid,
            AskPrice  = ask  == 0 ? null : ask,
            OpenPrice = open == 0 ? null : open,
            HighPrice = high == 0 ? null : high,
            LowPrice  = low  == 0 ? null : low,
            Volume    = volume == 0 ? null : volume,
            PriceDate = priceDate == default ? DateTime.UtcNow.Date : priceDate,
            Currency  = NullIfEmpty(Get("currency")),
            Source    = source
        };
    }

    /// <summary>
    /// Matches a file name against a glob pattern.
    /// Supports <c>*</c> (any substring) and <c>?</c> (any single character).
    /// </summary>
    internal static bool GlobMatch(string fileName, string pattern)
    {
        if (string.IsNullOrEmpty(pattern) || pattern == "*") return true;
        var regex = "^" + Regex.Escape(pattern)
                                .Replace(@"\*", ".*")
                                .Replace(@"\?", ".") + "$";
        return Regex.IsMatch(fileName, regex, RegexOptions.IgnoreCase);
    }

    internal static string? NullIfEmpty(string? value)
        => string.IsNullOrWhiteSpace(value) ? null : value;
}
