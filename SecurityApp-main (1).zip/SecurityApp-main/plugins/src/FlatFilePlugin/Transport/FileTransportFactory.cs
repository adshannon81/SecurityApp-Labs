using SecurityApp.Core.Import.Enums;
using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Core.Import.Models;
using SecurityApp.Core.Import.Services;

namespace SecurityApp.Plugin.FlatFile.Transport;

/// <summary>
/// Creates the appropriate <see cref="IFileTransport"/> implementation
/// for a given <see cref="TransportConfig"/>.
/// </summary>
internal static class FileTransportFactory
{
    /// <summary>
    /// Returns an <see cref="IFileTransport"/> for the given config.
    /// Returns <see cref="LocalFileTransport"/> when <paramref name="config"/> is null
    /// or its <see cref="TransportConfig.Type"/> is <see cref="TransportType.Local"/>.
    /// Supply an <see cref="ISecretResolver"/> so that remote transport credentials
    /// stored as Vault path references are resolved at connection time.
    /// Defaults to <see cref="LiteralSecretResolver"/> when <paramref name="resolver"/> is null.
    /// </summary>
    public static IFileTransport Create(TransportConfig? config, ISecretResolver? resolver = null)
    {
        if (config == null || config.Type == TransportType.Local)
            return new LocalFileTransport();

        resolver ??= new LiteralSecretResolver();

        return config.Type switch
        {
            TransportType.Sftp  => new SftpTransport(config, resolver),
            TransportType.Ftps  => new FtpsTransport(config, resolver),
            TransportType.Ftp   => new FtpTransport(config, resolver),
            TransportType.Https => new HttpsTransport(config, resolver),
            _                   => new LocalFileTransport()
        };
    }
}
