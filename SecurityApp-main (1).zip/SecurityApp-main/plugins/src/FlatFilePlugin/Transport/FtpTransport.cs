using System.Net;
using FluentFTP;
using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Core.Import.Models;

namespace SecurityApp.Plugin.FlatFile.Transport;

/// <summary>
/// Downloads files from a remote FTP server (unencrypted) into a temp directory.
/// Prefer <see cref="FtpsTransport"/> on any non-trusted network.
/// </summary>
internal sealed class FtpTransport : IFileTransport
{
    private readonly TransportConfig _config;
    private readonly ISecretResolver _resolver;
    private string? _tempDir;

    public FtpTransport(TransportConfig config, ISecretResolver resolver)
    {
        _config   = config;
        _resolver = resolver;
    }

    public async Task<string> AcquireLocalFolderAsync(
        string localSourcePath,
        string filePattern,
        CancellationToken ct = default)
    {
        var host       = await _resolver.ResolveAsync(_config.Host, ct);
        var username   = await _resolver.ResolveAsync(_config.Username, ct);
        var password   = await _resolver.ResolveAsync(_config.PasswordSecret, ct);
        var port       = _config.Port       ?? 21;
        var remotePath = _config.RemotePath ?? "/";

        if (string.IsNullOrEmpty(host))     throw new InvalidOperationException("FTP transport requires Host.");
        if (string.IsNullOrEmpty(username)) throw new InvalidOperationException("FTP transport requires Username.");

        _tempDir = Path.Combine(Path.GetTempPath(), $"ftp_{Guid.NewGuid():N}");
        Directory.CreateDirectory(_tempDir);

        var client = new AsyncFtpClient(host, new NetworkCredential(username, password), port);
        client.Config.EncryptionMode = FtpEncryptionMode.None;

        await using (client.ConfigureAwait(false))
        {
            await client.Connect(ct);
            var listing = await client.GetListing(remotePath, ct);
            foreach (var item in listing)
            {
                ct.ThrowIfCancellationRequested();
                if (item.Type != FtpObjectType.File) continue;
                if (!System.IO.Enumeration.FileSystemName.MatchesSimpleExpression(
                        filePattern, item.Name, ignoreCase: true)) continue;

                var dest = Path.Combine(_tempDir, item.Name);
                await client.DownloadFile(dest, item.FullName, token: ct);
            }
        }

        return _tempDir;
    }

    public async ValueTask DisposeAsync()
    {
        if (_tempDir != null && Directory.Exists(_tempDir))
        {
            await Task.Run(() => Directory.Delete(_tempDir, recursive: true));
            _tempDir = null;
        }
    }
}
