using Renci.SshNet;
using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Core.Import.Models;

namespace SecurityApp.Plugin.FlatFile.Transport;

/// <summary>
/// Downloads files from a remote SFTP server into a temporary local directory.
/// Uses SSH.NET. Password authentication only; key-based auth can be added by
/// substituting <see cref="PrivateKeyAuthenticationMethod"/> for <see cref="PasswordAuthenticationMethod"/>.
/// </summary>
internal sealed class SftpTransport : IFileTransport
{
    private readonly TransportConfig  _config;
    private readonly ISecretResolver  _resolver;
    private string? _tempDir;

    public SftpTransport(TransportConfig config, ISecretResolver resolver)
    {
        _config   = config;
        _resolver = resolver;
    }

    public async Task<string> AcquireLocalFolderAsync(
        string localSourcePath,
        string filePattern,
        CancellationToken ct = default)
    {
        var host     = await _resolver.ResolveAsync(_config.Host, ct);
        var username = await _resolver.ResolveAsync(_config.Username, ct);
        var password = await _resolver.ResolveAsync(_config.PasswordSecret, ct);
        var port     = _config.Port ?? 22;
        var remotePath = _config.RemotePath ?? "/";

        if (string.IsNullOrEmpty(host))     throw new InvalidOperationException("SFTP transport requires Host.");
        if (string.IsNullOrEmpty(username)) throw new InvalidOperationException("SFTP transport requires Username.");

        _tempDir = Path.Combine(Path.GetTempPath(), $"sftp_{Guid.NewGuid():N}");
        Directory.CreateDirectory(_tempDir);

        var auth = new PasswordAuthenticationMethod(username, password);
        var connectionInfo = new ConnectionInfo(host, port, username, auth);

        using var client = new SftpClient(connectionInfo);
        await Task.Run(() => client.Connect(), ct);
        try
        {
            // Translate glob to a simple prefix/suffix filter (SFTP has no native glob)
            var remoteFiles = await Task.Run(() => client.ListDirectory(remotePath), ct);
            foreach (var entry in remoteFiles)
            {
                ct.ThrowIfCancellationRequested();
                if (!entry.IsRegularFile) continue;
                if (!GlobMatches(entry.Name, filePattern)) continue;

                var localFile = Path.Combine(_tempDir, entry.Name);
                using var fs = File.Create(localFile);
                await Task.Run(() => client.DownloadFile(entry.FullName, fs), ct);
            }
        }
        finally
        {
            await Task.Run(() => client.Disconnect(), ct);
        }

        return _tempDir;
    }

    public async ValueTask DisposeAsync()
    {
        if (_tempDir != null && Directory.Exists(_tempDir))
        {
            await Task.Run(() => Directory.Delete(_tempDir, recursive: true));
            _tempDir = null;
        }
    }

    // Translates a simple glob ("*.csv", "bloomberg_*.csv") to a regex-free match.
    private static bool GlobMatches(string fileName, string pattern)
    {
        // Use .NET's own glob via FileSystemName if available, otherwise manual
        return System.IO.Enumeration.FileSystemName.MatchesSimpleExpression(pattern, fileName,
            ignoreCase: true);
    }
}
