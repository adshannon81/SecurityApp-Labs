using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Core.Import.Models;

namespace SecurityApp.Plugin.FlatFile.Transport;

/// <summary>
/// Downloads a single file via HTTPS GET into a temporary local directory.
/// The URL is taken from <see cref="TransportConfig.RemotePath"/>.
/// <see cref="TransportConfig.FilePattern"/> is not used for listing — the downloaded
/// file must match the profile's <c>FilePattern</c> at parse time.
/// </summary>
internal sealed class HttpsTransport : IFileTransport
{
    private static readonly HttpClient _defaultHttp = new();

    private readonly HttpClient _http;
    private readonly TransportConfig _config;
    private readonly ISecretResolver _resolver;
    private string? _tempDir;

    public HttpsTransport(TransportConfig config, ISecretResolver resolver, HttpClient? httpClient = null)
    {
        _config   = config;
        _resolver = resolver;
        _http     = httpClient ?? _defaultHttp;
    }

    public async Task<string> AcquireLocalFolderAsync(
        string localSourcePath,
        string filePattern,
        CancellationToken ct = default)
    {
        var url = await _resolver.ResolveAsync(_config.RemotePath, ct);
        if (string.IsNullOrEmpty(url))
            throw new InvalidOperationException("HTTPS transport requires RemotePath (the download URL).");

        _tempDir = Path.Combine(Path.GetTempPath(), $"https_{Guid.NewGuid():N}");
        Directory.CreateDirectory(_tempDir);

        // Derive a local filename from the URL path; fall back to "download"
        var uriPath  = new Uri(url).AbsolutePath;
        var fileName = Path.GetFileName(uriPath);
        if (string.IsNullOrEmpty(fileName)) fileName = "download";

        var localFile = Path.Combine(_tempDir, fileName);

        var maxAttempts = _config.RetryCount;
        var delay = TimeSpan.FromSeconds(2);
        Exception? lastException = null;

        for (int attempt = 1; attempt <= maxAttempts; attempt++)
        {
            try
            {
                using var response = await _http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, ct);
                response.EnsureSuccessStatusCode();

                await using var fs     = File.Create(localFile);
                await using var stream = await response.Content.ReadAsStreamAsync(ct);
                await stream.CopyToAsync(fs, ct);

                return _tempDir;
            }
            catch (HttpRequestException ex)
            {
                lastException = ex;
                if (attempt < maxAttempts)
                {
                    var baseDelay = TimeSpan.FromTicks(delay.Ticks * (1L << (attempt - 1)));
                    var jitter    = TimeSpan.FromMilliseconds(Random.Shared.Next(0, (int)(baseDelay.TotalMilliseconds * 0.5)));
                    await Task.Delay(baseDelay + jitter, ct);
                }
            }
        }

        throw new HttpRequestException(
            $"HTTPS download failed after {maxAttempts} attempts: {url}", lastException);
    }

    public async ValueTask DisposeAsync()
    {
        if (_tempDir != null && Directory.Exists(_tempDir))
        {
            await Task.Run(() => Directory.Delete(_tempDir, recursive: true));
            _tempDir = null;
        }
    }
}
