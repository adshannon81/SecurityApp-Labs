using SecurityApp.Core.Import.Interfaces;

namespace SecurityApp.Plugin.FlatFile.Transport;

/// <summary>
/// Passthrough transport for files already on the local filesystem.
/// <see cref="AcquireLocalFolderAsync"/> returns <paramref name="localSourcePath"/> unchanged.
/// </summary>
internal sealed class LocalFileTransport : IFileTransport
{
    public Task<string> AcquireLocalFolderAsync(
        string localSourcePath,
        string filePattern,
        CancellationToken ct = default)
        => Task.FromResult(localSourcePath);

    public ValueTask DisposeAsync() => ValueTask.CompletedTask;
}
