﻿using System.Globalization;
using Microsoft.Extensions.Logging;
using SecurityApp.Core.Securities.Interfaces;
using SecurityApp.Core.Pricing.Interfaces;
using SecurityApp.Core.Import.Models;
using SecurityApp.Core.Import.Entities;
using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Core.Shared.Enums;
using SecurityApp.Core.Plugins.Interfaces;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Securities.Models;
using SecurityApp.Core.Pricing.Models;
using SecurityApp.Plugin.FlatFile.Transport;

namespace SecurityApp.Plugin.FlatFile;

/// <summary>
/// Reads security reference data and price history from delimiter-separated text files
/// (CSV, TSV, pipe-delimited, or any single-character separator) in a configured directory.
///
/// Multiple named profiles can be configured; each profile has a <c>FilePattern</c> glob
/// that is matched against incoming file names. The first matching profile wins.
/// Falls back to default settings (comma delimiter, double-quote qualifier) when no profile matches.
///
/// Default security header (case-insensitive):
///   Symbol, Name, SecurityType, IdentifierType, IdentifierValue, Currency, Exchange,
///   Country, Sector, Industry, Issuer, CouponRate, MaturityDate
///
/// Price files must be named <c>prices_*.csv</c> (or .tsv).
/// Default price header (case-insensitive):
///   Symbol, Price, PriceType, BidPrice, AskPrice, OpenPrice, HighPrice, LowPrice,
///   Volume, PriceDate, Currency
///
/// Delimiter / TextQualifier are the actual character(s) --- NOT words:
///   e.g. <c>","</c> not <c>"comma"</c>, <c>"\t"</c> for tab, <c>""</c> for no qualifier.
/// </summary>
public class FlatFileConnector : ISecurityDataProvider, IPricingDataProvider
{
    private readonly string _importDirectory;
    private readonly IReadOnlyDictionary<string, FlatFileImportProfile> _profiles;
    private readonly IReadOnlyDictionary<string, ImportProfile> _dbProfileMap;
    private readonly IImportValidationRunner? _validationRunner;
    private readonly ISecretResolver _resolver;
    private readonly ILogger<FlatFileConnector> _logger;

    private static readonly FlatFileImportProfile _defaultProfile = new();

    // ------ IDataConnector ---------------------------------------------------------------------------------------------------------------------------------------
    public DataSourceType SourceType => DataSourceType.FlatFile;
    public string SourceName => "FlatFile";
    public int Priority => 100;

    public FlatFileConnector(
        string importDirectory,
        IReadOnlyDictionary<string, FlatFileImportProfile> profiles,
        IReadOnlyList<ImportProfile>? dbProfiles,
        IImportValidationRunner? validationRunner,
        ISecretResolver resolver,
        ILogger<FlatFileConnector> logger)
    {
        _importDirectory   = importDirectory;
        _profiles          = profiles;
        _validationRunner  = validationRunner;
        _resolver          = resolver;
        _logger            = logger;

        _dbProfileMap = dbProfiles != null
            ? dbProfiles.ToDictionary(p => p.Name, p => p, StringComparer.OrdinalIgnoreCase)
            : new Dictionary<string, ImportProfile>(StringComparer.OrdinalIgnoreCase);
    }

    // ------ IDataConnector ------------------------------------------------------------------------------------------------------------------------------------ 

    public Task<bool> IsAvailableAsync(CancellationToken cancellationToken = default)
        => Task.FromResult(Directory.Exists(_importDirectory));

    public Task<HealthStatus> GetHealthStatusAsync(CancellationToken cancellationToken = default)
    {
        var exists = Directory.Exists(_importDirectory);
        return Task.FromResult(new HealthStatus
        {
            IsHealthy = exists,
            Message = exists
                ? $"Import directory '{_importDirectory}' found."
                : $"Import directory '{_importDirectory}' not found.",
            CheckedAt = DateTime.UtcNow
        });
    }

    // ------ ISecurityDataProvider ------------------------------------------------------------------------------------------------------------------

    public bool SupportsIdentifierType(IdentifierType identifierType) => true;

    public async Task<ExternalSecurityData?> GetSecurityAsync(
        string identifierValue,
        IdentifierType identifierType,
        CancellationToken cancellationToken = default)
    {
        var records = await ReadAllSecuritiesAsync(cancellationToken);
        return records.FirstOrDefault(r =>
            string.Equals(r.IdentifierValue, identifierValue, StringComparison.OrdinalIgnoreCase));
    }

    public async Task<IEnumerable<ExternalSecurityData>> SearchSecuritiesAsync(
        string keyword,
        CancellationToken cancellationToken = default)
    {
        var records = await ReadAllSecuritiesAsync(cancellationToken);
        return records.Where(r =>
            r.Symbol.Contains(keyword, StringComparison.OrdinalIgnoreCase) ||
            r.Name.Contains(keyword, StringComparison.OrdinalIgnoreCase) ||
            r.IdentifierValue.Contains(keyword, StringComparison.OrdinalIgnoreCase));
    }

    // ------ IPricingDataProvider ---------------------------------------------------------------------------------------------------------------------

    public async Task<ExternalPriceData?> GetCurrentPriceAsync(
        string symbol,
        CancellationToken cancellationToken = default)
    {
        var all = await ReadAllPricesAsync(cancellationToken);
        return all
            .Where(p => string.Equals(p.Symbol, symbol, StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(p => p.PriceDate)
            .FirstOrDefault();
    }

    public async Task<IEnumerable<ExternalPriceData>> GetHistoricalPricesAsync(
        string symbol,
        DateTime fromDate,
        DateTime toDate,
        CancellationToken cancellationToken = default)
    {
        var all = await ReadAllPricesAsync(cancellationToken);
        return all
            .Where(p => string.Equals(p.Symbol, symbol, StringComparison.OrdinalIgnoreCase)
                        && p.PriceDate >= fromDate
                        && p.PriceDate <= toDate)
            .OrderByDescending(p => p.PriceDate);
    }

    // ------ File dispatch ------------------------------------------------------------------------------------------------------------------------------------------

    private async Task<List<ExternalSecurityData>> ReadAllSecuritiesAsync(CancellationToken ct)
    {
        var results = new List<ExternalSecurityData>();

        foreach (var (profileName, profile) in ProfilesOrDefault())
        {
            await using var transport = FileTransportFactory.Create(profile.Transport, _resolver);
            var folder = await transport.AcquireLocalFolderAsync(
                ResolveFolder(profile.Folder), profile.FilePattern, ct);

            if (!Directory.Exists(folder)) continue;

            _dbProfileMap.TryGetValue(profileName, out var dbProfile);

            foreach (var file in Directory.GetFiles(folder, profile.FilePattern)
                         .Where(f => !IsPriceFile(f)))
            {
                try { results.AddRange(await ParseSecuritiesAsync(file, profile, dbProfile, ct)); }
                catch (Exception ex) { _logger.LogError(ex, "Error parsing securities file: {File}", file); }
            }
        }

        return results;
    }

    private async Task<List<ExternalPriceData>> ReadAllPricesAsync(CancellationToken ct)
    {
        var results = new List<ExternalPriceData>();

        // Price files are discovered in every profile folder (and the root).
        // For remote transports we acquire a local copy per profile first.
        foreach (var (_, profile) in ProfilesOrDefault())
        {
            await using var transport = FileTransportFactory.Create(profile.Transport, _resolver);
            var folder = await transport.AcquireLocalFolderAsync(
                ResolveFolder(profile.Folder), "prices_*.csv", ct);

            if (!Directory.Exists(folder)) continue;

            foreach (var file in Directory.GetFiles(folder, "prices_*.csv")
                         .Concat(Directory.GetFiles(folder, "prices_*.tsv")))
            {
                try { results.AddRange(await ParsePricesAsync(file, profile, ct)); }
                catch (Exception ex) { _logger.LogError(ex, "Error parsing prices file: {File}", file); }
            }
        }

        // Also scan the root import directory with the default profile (Local only, no duplicate download)
        if (!string.IsNullOrEmpty(_importDirectory) && Directory.Exists(_importDirectory))
        {
            foreach (var file in Directory.GetFiles(_importDirectory, "prices_*.csv")
                         .Concat(Directory.GetFiles(_importDirectory, "prices_*.tsv")))
            {
                if (results.Any(p => p.Symbol == Path.GetFileNameWithoutExtension(file))) continue;
                try { results.AddRange(await ParsePricesAsync(file, _defaultProfile, ct)); }
                catch (Exception ex) { _logger.LogError(ex, "Error parsing prices file: {File}", file); }
            }
        }

        return results;
    }

    // ------ Parser ------------------------------------------------------------------------------------------------------------------------------------------------------------

    private async Task<IEnumerable<ExternalSecurityData>> ParseSecuritiesAsync(
        string filePath, FlatFileImportProfile profile, ImportProfile? dbProfile, CancellationToken ct)
    {
        var delimiter  = ParseDelimiterChar(profile.Delimiter);
        var qualifier  = ParseQualifierChar(profile.TextQualifier);
        var columnMap  = SecurityMapper.BuildLookup(profile.Columns);

        var lines = await File.ReadAllLinesAsync(filePath, ct);
        if (lines.Length == 0) return [];

        string[] headers;
        int startLine;

        if (profile.HasHeader)
        {
            headers   = SplitLine(lines[0], delimiter, qualifier)
                            .Select(h => h.ToLowerInvariant()).ToArray();
            startLine = 1 + profile.SkipRows;
        }
        else
        {
            // No header: use ordinal indices ("0", "1", ...) as column keys
            var firstFields = SplitLine(lines[0], delimiter, qualifier);
            headers   = Enumerable.Range(0, firstFields.Count).Select(i => i.ToString()).ToArray();
            startLine = profile.SkipRows;
        }

        var results = new List<ExternalSecurityData>();
        for (int i = startLine; i < lines.Length; i++)
        {
            if (string.IsNullOrWhiteSpace(lines[i])) continue;
            var row   = BuildRow(headers, SplitLine(lines[i], delimiter, qualifier));
            var rowNo = i + 1;  // 1-based

            // Build target-keyed row for validation (source keys → target field names)
            var targetRow = BuildTargetRow(row, profile.Columns);

            // Run validation if a DB profile with rules is available
            var validationErrors = new List<ImportValidationError>();
            if (dbProfile != null && _validationRunner != null &&
                (dbProfile.Columns.Any(c => c.Validations.Count > 0) ||
                 dbProfile.RowValidations.Count > 0))
            {
                validationErrors = await _validationRunner.ValidateRowAsync(dbProfile, targetRow, rowNo, ct);

                // Apply any transforms back to the original row (targetRow was mutated)
                foreach (var col in dbProfile.Columns)
                {
                    if (targetRow.TryGetValue(col.TargetField.ToLowerInvariant(), out var tv))
                        row[col.SourceColumn.ToLowerInvariant()] = tv;
                }
            }

            var record = SecurityMapper.MapSecurity(row, columnMap);
            record.RowNumber       = rowNo;
            record.ValidationErrors = validationErrors;
            results.Add(record);
        }

        return results;
    }

    private async Task<IEnumerable<ExternalPriceData>> ParsePricesAsync(
        string filePath, FlatFileImportProfile profile, CancellationToken ct)
    {
        var delimiter = ParseDelimiterChar(profile.Delimiter);
        var qualifier = ParseQualifierChar(profile.TextQualifier);
        var columnMap = SecurityMapper.BuildLookup(profile.Columns);

        var lines = await File.ReadAllLinesAsync(filePath, ct);
        if (lines.Length == 0) return [];

        var headers = SplitLine(lines[0], delimiter, qualifier)
                          .Select(h => h.ToLowerInvariant()).ToArray();

        var results = new List<ExternalPriceData>();
        for (int i = 1 + profile.SkipRows; i < lines.Length; i++)
        {
            if (string.IsNullOrWhiteSpace(lines[i])) continue;
            var row = BuildRow(headers, SplitLine(lines[i], delimiter, qualifier));
            results.Add(SecurityMapper.MapPrice(row, columnMap));
        }

        return results;
    }

    // ------ Helpers ---------------------------------------------------------------------------------------------------------------------------------------------------------

    private string ResolveFolder(string? profileFolder)
        => string.IsNullOrEmpty(profileFolder)
            ? _importDirectory
            : Path.Combine(_importDirectory, profileFolder);

    private static bool IsPriceFile(string path)
        => Path.GetFileName(path).StartsWith("prices_", StringComparison.OrdinalIgnoreCase);

    /// Returns the configured profiles, or a single default profile when none are configured.
    private IEnumerable<KeyValuePair<string, FlatFileImportProfile>> ProfilesOrDefault()
        => _profiles.Count > 0
            ? _profiles
            : new Dictionary<string, FlatFileImportProfile> { ["Default"] = _defaultProfile };

    // ------ RFC-4180 parser ---------------------------------------------------------------------------------------------------------------------------------

    /// <summary>
    /// Splits one text line respecting an optional text qualifier.
    /// Doubled quotes inside a qualified field are treated as an escaped quote.
    /// </summary>
    internal static List<string> SplitLine(string line, char delimiter, char? qualifier)
    {
        var fields = new List<string>();

        if (qualifier is null)
        {
            foreach (var f in line.Split(delimiter))
                fields.Add(f.Trim());
            return fields;
        }

        char q = qualifier.Value;
        var field = new System.Text.StringBuilder();
        bool inQuoted = false;
        int i = 0;

        while (i < line.Length)
        {
            char c = line[i];
            if (inQuoted)
            {
                if (c == q && i + 1 < line.Length && line[i + 1] == q)
                    { field.Append(q); i += 2; }
                else if (c == q)
                    { inQuoted = false; i++; }
                else
                    { field.Append(c); i++; }
            }
            else
            {
                if (c == q)          { inQuoted = true; i++; }
                else if (c == delimiter) { fields.Add(field.ToString().Trim()); field.Clear(); i++; }
                else                 { field.Append(c); i++; }
            }
        }

        fields.Add(field.ToString().Trim());
        return fields;
    }


    // ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    // Utilities
    // ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    private static Dictionary<string, string> BuildRow(string[] headers, List<string> fields)
    {
        var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        for (int j = 0; j < headers.Length && j < fields.Count; j++)
            row[headers[j]] = fields[j];
        return row;
    }

    /// <summary>
    /// Builds a target-keyed dictionary (lower-case target field names → raw values)
    /// from a row keyed by source headers. Used as input to <see cref="IImportValidationRunner"/>.
    /// </summary>
    private static Dictionary<string, string> BuildTargetRow(
        Dictionary<string, string> sourceRow, List<ImportColumnMap> columns)
    {
        var target = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var map in columns)
        {
            var sourceKey = map.Source.ToLowerInvariant();
            var targetKey = map.Target.ToLowerInvariant();
            if (sourceRow.TryGetValue(sourceKey, out var val))
                target[targetKey] = val;
        }
        // Also carry over any unmapped fields by their source key so row-level NCalc
        // expressions can reference all available columns.
        foreach (var kv in sourceRow)
        {
            if (!target.ContainsKey(kv.Key))
                target[kv.Key] = kv.Value;
        }
        return target;
    }

    /// <summary>
    /// Parses a delimiter string into its actual <see cref="char"/>.
    /// Supports escape sequences: <c>"\t"</c> --- tab.
    /// </summary>
    internal static char ParseDelimiterChar(string delimiter)
    {
        if (string.IsNullOrEmpty(delimiter)) return ',';
        if (delimiter == "\\t") return '\t';
        if (delimiter == "\\n") return '\n';
        return delimiter[0];
    }

    /// <summary>
    /// Parses a text qualifier string into its actual <see cref="char"/>, or <c>null</c> for no qualifier.
    /// </summary>
    internal static char? ParseQualifierChar(string qualifier)
    {
        if (string.IsNullOrEmpty(qualifier)) return null;
        if (qualifier == "\\\"") return '"';
        return qualifier[0];
    }

    private static string? NullIfEmpty(string? value)
        => string.IsNullOrWhiteSpace(value) ? null : value;
}
