﻿using System.Xml.XPath;
using Microsoft.Extensions.Logging;
using SecurityApp.Core.Securities.Interfaces;
using SecurityApp.Core.Import.Entities;
using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Core.Shared.Enums;
using SecurityApp.Core.Plugins.Interfaces;
using SecurityApp.Core.Securities.Enums;
using SecurityApp.Core.Securities.Models;
using SecurityApp.Core.Import.Models;
using SecurityApp.Plugin.FlatFile.Transport;

namespace SecurityApp.Plugin.FlatFile;

/// <summary>
/// Reads security reference data from XML files in a configured directory.
///
/// Multiple named profiles can be configured; each has a <c>FilePattern</c> glob matched
/// against the file name. The first matching profile wins; falls back to defaults when none match.
///
/// The <c>RecordsXPath</c> XPath expression selects individual record elements, e.g.:
///   <c>"//Securities/Security"</c>
///   <c>"//items/item"</c>
///
/// Each selected element's child elements and attributes are mapped to a flat row dictionary.
/// </summary>
public class XmlFileConnector : ISecurityDataProvider
{
    private readonly string _importDirectory;
    private readonly IReadOnlyDictionary<string, XmlImportProfile> _profiles;
    private readonly IReadOnlyDictionary<string, ImportProfile> _dbProfileMap;
    private readonly IImportValidationRunner? _validationRunner;
    private readonly ISecretResolver _resolver;
    private readonly ILogger<XmlFileConnector> _logger;

    private static readonly XmlImportProfile _defaultProfile = new();

    // -- IDataConnector ---------------------------------------------
    public DataSourceType SourceType => DataSourceType.XmlFile;
    public string SourceName => "XmlFile";
    public int Priority => 100;

    public XmlFileConnector(
        string importDirectory,
        IReadOnlyDictionary<string, XmlImportProfile> profiles,
        IReadOnlyList<ImportProfile>? dbProfiles,
        IImportValidationRunner? validationRunner,
        ISecretResolver resolver,
        ILogger<XmlFileConnector> logger)
    {
        _importDirectory  = importDirectory;
        _profiles         = profiles;
        _validationRunner = validationRunner;
        _resolver         = resolver;
        _logger           = logger;
        _dbProfileMap = dbProfiles != null
            ? dbProfiles.ToDictionary(p => p.Name, p => p, StringComparer.OrdinalIgnoreCase)
            : new Dictionary<string, ImportProfile>(StringComparer.OrdinalIgnoreCase);
    }

    // -- IDataConnector ---------------------------------------------

    public Task<bool> IsAvailableAsync(CancellationToken cancellationToken = default)
        => Task.FromResult(Directory.Exists(_importDirectory));

    public Task<HealthStatus> GetHealthStatusAsync(CancellationToken cancellationToken = default)
    {
        var exists = Directory.Exists(_importDirectory);
        return Task.FromResult(new HealthStatus
        {
            IsHealthy = exists,
            Message = exists
                ? $"Import directory '{_importDirectory}' found."
                : $"Import directory '{_importDirectory}' not found.",
            CheckedAt = DateTime.UtcNow
        });
    }

    // -- ISecurityDataProvider --------------------------------------

    public bool SupportsIdentifierType(IdentifierType identifierType) => true;

    public async Task<ExternalSecurityData?> GetSecurityAsync(
        string identifierValue,
        IdentifierType identifierType,
        CancellationToken cancellationToken = default)
    {
        var records = await ReadAllSecuritiesAsync(cancellationToken);
        return records.FirstOrDefault(r =>
            string.Equals(r.IdentifierValue, identifierValue, StringComparison.OrdinalIgnoreCase));
    }

    public async Task<IEnumerable<ExternalSecurityData>> SearchSecuritiesAsync(
        string keyword,
        CancellationToken cancellationToken = default)
    {
        var records = await ReadAllSecuritiesAsync(cancellationToken);
        return records.Where(r =>
            r.Symbol.Contains(keyword, StringComparison.OrdinalIgnoreCase) ||
            r.Name.Contains(keyword, StringComparison.OrdinalIgnoreCase) ||
            r.IdentifierValue.Contains(keyword, StringComparison.OrdinalIgnoreCase));
    }

    // -- File dispatch ----------------------------------------------

    private async Task<List<ExternalSecurityData>> ReadAllSecuritiesAsync(CancellationToken ct)
    {
        var results = new List<ExternalSecurityData>();

        foreach (var (profileName, profile) in ProfilesOrDefault())
        {
            await using var transport = FileTransportFactory.Create(profile.Transport, _resolver);
            var folder = await transport.AcquireLocalFolderAsync(
                ResolveFolder(profile.Folder), profile.FilePattern, ct);

            if (!Directory.Exists(folder)) continue;

            _dbProfileMap.TryGetValue(profileName, out var dbProfile);

            foreach (var file in Directory.GetFiles(folder, profile.FilePattern))
            {
                try { results.AddRange(await ParseFileAsync(file, profile, dbProfile, ct)); }
                catch (Exception ex) { _logger.LogError(ex, "Error parsing XML file: {File}", file); }
            }
        }

        return results;
    }

    // -- Parser ----------------------------------------------------

    private async Task<IEnumerable<ExternalSecurityData>> ParseFileAsync(
        string filePath, XmlImportProfile profile, ImportProfile? dbProfile, CancellationToken ct)
    {
        var columnMap = SecurityMapper.BuildLookup(profile.Columns);

        var xml = await File.ReadAllTextAsync(filePath, ct);
        var doc = new XPathDocument(new System.IO.StringReader(xml));
        var nav = doc.CreateNavigator();

        var results = new List<ExternalSecurityData>();
        var nodes   = nav.Select(profile.RecordsXPath);
        int rowNo   = 1;

        while (nodes.MoveNext())
        {
            var row = XPathNodeToRow(nodes.Current!);

            var validationErrors = new List<ImportValidationError>();
            if (dbProfile != null && _validationRunner != null &&
                (dbProfile.Columns.Any(c => c.Validations.Count > 0) ||
                 dbProfile.RowValidations.Count > 0))
            {
                validationErrors = await _validationRunner.ValidateRowAsync(dbProfile, row, rowNo, ct);
            }

            var record = SecurityMapper.MapSecurity(row, columnMap);
            record.RowNumber        = rowNo;
            record.ValidationErrors = validationErrors;
            results.Add(record);
            rowNo++;
        }

        return results;
    }

    // -- Helpers ---------------------------------------------------

    private string ResolveFolder(string? profileFolder)
        => string.IsNullOrEmpty(profileFolder)
            ? _importDirectory
            : Path.Combine(_importDirectory, profileFolder);

    /// Returns the configured profiles, or a single default profile when none are configured.
    private IEnumerable<KeyValuePair<string, XmlImportProfile>> ProfilesOrDefault()
        => _profiles.Count > 0
            ? _profiles
            : new Dictionary<string, XmlImportProfile> { ["Default"] = _defaultProfile };

    // -- XML - row -------------------------------------------------

    /// <summary>
    /// Converts an XML element to a flat key-value dictionary.
    /// Attributes - key = attribute local-name.
    /// Child element text content - key = element local-name.
    /// </summary>
    private static Dictionary<string, string> XPathNodeToRow(XPathNavigator node)
    {
        var row = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        if (node.MoveToFirstAttribute())
        {
            do { row[node.LocalName] = node.Value; }
            while (node.MoveToNextAttribute());
            node.MoveToParent();
        }

        var children = node.SelectChildren(XPathNodeType.Element);
        while (children.MoveNext())
        {
            var child = children.Current!;
            row[child.LocalName] = child.Value;
        }

        return row;
    }
}
