﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using SecurityApp.Core.Plugins.Interfaces;
using SecurityApp.Core.Import.Entities;
using SecurityApp.Core.Import.Models;
using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Core.Import.Enums;
using SecurityApp.Core.Import.Services;
using SecurityApp.Core.Shared.Enums;

namespace SecurityApp.Plugin.FlatFile;

/// <summary>
/// Plugin entry point for the XML file connector.
/// Loaded at runtime by PluginLoader from the /plugins/ directory alongside FlatFilePlugin.
///
/// Profile resolution order:
///   1. Active profiles from the database (via IImportProfileService).
///   2. Falls back to appsettings.json profiles when the database has none for SourceType "XmlFile".
/// </summary>
public class XmlFilePlugin : IConnectorPlugin
{
    private XmlFileConnector? _connector;
    private bool _disposed;

    public PluginMetadata Metadata => new()
    {
        Name = "XmlFile",
        Version = "1.0.0",
        Author = "SecurityApp",
        Description = "XML file data connector - security reference data from structured XML files.",
        ConnectorType = DataSourceType.XmlFile
    };

    public bool IsCompatible() => true;

    public async Task InitializeAsync(IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        var config = (IConfiguration?)serviceProvider.GetService(typeof(IConfiguration))
                     ?? throw new InvalidOperationException("IConfiguration not available in plugin service provider.");

        var loggerFactory = (ILoggerFactory?)serviceProvider.GetService(typeof(ILoggerFactory))
                            ?? NullLoggerFactory.Instance;

        var importDirectory = config["DataConnectors:XmlFile:ImportDirectory"] ?? "./imports";
        var httpsRetryCount = config.GetValue<int>("Resilience:HttpsDownloadMaxRetryCount", 3);

        var dbProfiles = await LoadDbProfilesAsync(serviceProvider, cancellationToken);

        IReadOnlyDictionary<string, XmlImportProfile> profiles;
        IReadOnlyList<ImportProfile>? dbProfileEntities;

        if (dbProfiles.Count > 0)
        {
            profiles          = ConvertDbProfiles(dbProfiles, httpsRetryCount);
            dbProfileEntities = dbProfiles;
        }
        else
        {
            profiles          = ReadConfigProfiles(config.GetSection("DataConnectors:XmlFile:Profiles"));
            dbProfileEntities = null;
        }

        var validationRunner = serviceProvider.GetService(typeof(IImportValidationRunner)) as IImportValidationRunner;

        var resolver = serviceProvider.GetService(typeof(ISecretResolver)) as ISecretResolver
                       ?? new LiteralSecretResolver();

        var logger = loggerFactory.CreateLogger<XmlFileConnector>();
        _connector = new XmlFileConnector(importDirectory, profiles, dbProfileEntities, validationRunner, resolver, logger);
    }

    public IDataConnector GetConnector()
    {
        if (_connector == null)
            throw new InvalidOperationException("XmlFilePlugin has not been initialized. Call InitializeAsync first.");
        return _connector;
    }

    public void Dispose() => _disposed = true;

    private static async Task<IReadOnlyList<ImportProfile>> LoadDbProfilesAsync(
        IServiceProvider serviceProvider, CancellationToken ct)
    {
        using var scope = ((IServiceScopeFactory?)serviceProvider
                .GetService(typeof(IServiceScopeFactory)))
                ?.CreateScope();
        if (scope == null) return [];
        var svc = scope.ServiceProvider.GetService(typeof(IImportProfileService)) as IImportProfileService;
        if (svc == null) return [];
        try { return await svc.GetActiveProfilesAsync("XmlFile", ct); }
        catch { return []; }
    }

    private static IReadOnlyDictionary<string, XmlImportProfile> ConvertDbProfiles(
        IReadOnlyList<ImportProfile> dbProfiles, int httpsRetryCount = 3)
    {
        var result = new Dictionary<string, XmlImportProfile>(StringComparer.OrdinalIgnoreCase);
        foreach (var p in dbProfiles)
        {
            result[p.Name] = new XmlImportProfile
            {
                Folder       = p.Folder       ?? string.Empty,
                FilePattern  = p.FilePattern,
                RecordsXPath = p.RecordsXPath ?? "//Security",
                Columns      = p.Columns.Select(c => new ImportColumnMap { Source = c.SourceColumn, Target = c.TargetField }).ToList(),
                Transport    = BuildTransportConfig(p, httpsRetryCount)
            };
        }
        return result;
    }

    private static TransportConfig? BuildTransportConfig(ImportProfile p, int httpsRetryCount = 3)
    {
        if (!Enum.TryParse<TransportType>(p.TransportType, ignoreCase: true, out var type) ||
            type == TransportType.Local)
            return null;

        return new TransportConfig
        {
            Type           = type,
            Host           = p.TransportHost,
            Port           = p.TransportPort,
            Username       = p.TransportUsername,
            PasswordSecret = p.TransportPasswordSecret,
            RemotePath     = p.TransportRemotePath,
            TlsThumbprint  = p.TransportTlsThumbprint,
            RetryCount     = httpsRetryCount
        };
    }

    private static IReadOnlyDictionary<string, XmlImportProfile> ReadConfigProfiles(
        IConfigurationSection section)
    {
        var profiles = new Dictionary<string, XmlImportProfile>(StringComparer.OrdinalIgnoreCase);

        foreach (var child in section.GetChildren())
        {
            var profile = new XmlImportProfile
            {
                Folder       = child["Folder"]       ?? string.Empty,
                FilePattern  = child["FilePattern"]  ?? "*.xml",
                RecordsXPath = child["RecordsXPath"] ?? "//Security"
            };

            foreach (var col in child.GetSection("Columns").GetChildren())
            {
                var source = col["Source"];
                var target = col["Target"];
                if (!string.IsNullOrEmpty(source) && !string.IsNullOrEmpty(target))
                    profile.Columns.Add(new ImportColumnMap { Source = source, Target = target });
            }

            profiles[child.Key] = profile;
        }

        return profiles;
    }
}

