﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using SecurityApp.Core.Plugins.Interfaces;
using SecurityApp.Core.Import.Entities;
using SecurityApp.Core.Import.Models;
using SecurityApp.Core.Import.Interfaces;
using SecurityApp.Core.Import.Enums;
using SecurityApp.Core.Import.Services;
using SecurityApp.Core.Shared.Enums;

namespace SecurityApp.Plugin.FlatFile;

/// <summary>
/// Plugin entry point for the flat-file CSV/TSV connector.
/// Loaded at runtime by PluginLoader from the /plugins/ directory.
///
/// Profile resolution order:
///   1. Active profiles from the database (via IImportProfileService).
///   2. If the database has no active profiles for SourceType "FlatFile",
///      falls back to profiles from appsettings.json.
/// </summary>
public class FlatFilePlugin : IConnectorPlugin
{
    private FlatFileConnector? _connector;
    private bool _disposed;

    public PluginMetadata Metadata => new()
    {
        Name = "FlatFile",
        Version = "1.0.0",
        Author = "SecurityApp",
        Description = "Flat-file (CSV/TSV) data connector - security reference data and price history from delimiter-separated text files.",
        ConnectorType = DataSourceType.FlatFile
    };

    public bool IsCompatible() => true;

    public async Task InitializeAsync(IServiceProvider serviceProvider, CancellationToken cancellationToken = default)
    {
        var config = (IConfiguration?)serviceProvider.GetService(typeof(IConfiguration))
                     ?? throw new InvalidOperationException("IConfiguration not available in plugin service provider.");

        var loggerFactory = (ILoggerFactory?)serviceProvider.GetService(typeof(ILoggerFactory))
                            ?? NullLoggerFactory.Instance;

        var importDirectory = config["DataConnectors:FlatFile:ImportDirectory"] ?? "./imports";
        var httpsRetryCount = config.GetValue<int>("Resilience:HttpsDownloadMaxRetryCount", 3);

        // Attempt to load profiles from the database first
        var dbProfiles = await LoadDbProfilesAsync(serviceProvider, cancellationToken);

        IReadOnlyDictionary<string, FlatFileImportProfile> profiles;
        IReadOnlyList<ImportProfile>? dbProfileEntities;

        if (dbProfiles.Count > 0)
        {
            // DB profiles available — convert to FlatFileImportProfile for the connector
            profiles = ConvertDbProfiles(dbProfiles, httpsRetryCount);
            dbProfileEntities = dbProfiles;
        }
        else
        {
            // Fall back to appsettings.json profiles
            profiles = ReadConfigProfiles(config.GetSection("DataConnectors:FlatFile:Profiles"));
            dbProfileEntities = null;
        }

        // Resolve the optional validation runner (Singleton in host; null in isolated tests)
        var validationRunner = serviceProvider.GetService(typeof(IImportValidationRunner)) as IImportValidationRunner;

        var resolver = serviceProvider.GetService(typeof(ISecretResolver)) as ISecretResolver
                       ?? new LiteralSecretResolver();

        var logger = loggerFactory.CreateLogger<FlatFileConnector>();
        _connector = new FlatFileConnector(importDirectory, profiles, dbProfileEntities, validationRunner, resolver, logger);
    }

    public IDataConnector GetConnector()
    {
        if (_connector == null)
            throw new InvalidOperationException("FlatFilePlugin has not been initialized. Call InitializeAsync first.");
        return _connector;
    }

    public void Dispose() => _disposed = true;

    // ── DB profile loading ────────────────────────────────────────────────────

    private static async Task<IReadOnlyList<ImportProfile>> LoadDbProfilesAsync(
        IServiceProvider serviceProvider, CancellationToken ct)
    {
        // IImportProfileService is Scoped — create a short-lived scope for the read
        using var scope = ((IServiceScopeFactory?)serviceProvider
                .GetService(typeof(IServiceScopeFactory)))
                ?.CreateScope();

        if (scope == null) return [];

        var profileService = scope.ServiceProvider.GetService(typeof(IImportProfileService))
            as IImportProfileService;

        if (profileService == null) return [];

        try
        {
            return await profileService.GetActiveProfilesAsync("FlatFile", ct);
        }
        catch
        {
            return [];  // DB unavailable at startup — fall back to config
        }
    }

    private static IReadOnlyDictionary<string, FlatFileImportProfile> ConvertDbProfiles(
        IReadOnlyList<ImportProfile> dbProfiles, int httpsRetryCount = 3)
    {
        var result = new Dictionary<string, FlatFileImportProfile>(StringComparer.OrdinalIgnoreCase);
        foreach (var p in dbProfiles)
        {
            result[p.Name] = new FlatFileImportProfile
            {
                Folder        = p.Folder        ?? string.Empty,
                FilePattern   = p.FilePattern,
                Delimiter     = p.Delimiter     ?? ",",
                TextQualifier = p.TextQualifier ?? "\"",
                SkipRows      = p.SkipRows,
                HasHeader     = p.HasHeader,
                Columns       = p.Columns.Select(c => new ImportColumnMap
                {
                    Source = c.SourceColumn,
                    Target = c.TargetField
                }).ToList(),
                Transport     = BuildTransportConfig(p, httpsRetryCount)
            };
        }
        return result;
    }

    // ── Config profile loading ────────────────────────────────────────────────

    private static IReadOnlyDictionary<string, FlatFileImportProfile> ReadConfigProfiles(
        IConfigurationSection section)
    {
        var profiles = new Dictionary<string, FlatFileImportProfile>(StringComparer.OrdinalIgnoreCase);

        foreach (var child in section.GetChildren())
        {
            var profile = new FlatFileImportProfile
            {
                Folder        = child["Folder"]        ?? string.Empty,
                FilePattern   = child["FilePattern"]   ?? "*.csv",
                Delimiter     = child["Delimiter"]     ?? ",",
                TextQualifier = child["TextQualifier"] ?? "\"",
                SkipRows      = child.GetValue<int>("SkipRows", 0),
                HasHeader     = child.GetValue<bool>("HasHeader", true)
            };

            foreach (var col in child.GetSection("Columns").GetChildren())
            {
                var source = col["Source"];
                var target = col["Target"];
                if (!string.IsNullOrEmpty(source) && !string.IsNullOrEmpty(target))
                    profile.Columns.Add(new ImportColumnMap { Source = source, Target = target });
            }

            profiles[child.Key] = profile;
        }

        return profiles;
    }

    private static TransportConfig? BuildTransportConfig(ImportProfile p, int httpsRetryCount = 3)
    {
        if (!Enum.TryParse<TransportType>(p.TransportType, ignoreCase: true, out var type) ||
            type == TransportType.Local)
            return null;

        return new TransportConfig
        {
            Type                 = type,
            Host                 = p.TransportHost,
            Port                 = p.TransportPort,
            Username             = p.TransportUsername,
            PasswordSecret       = p.TransportPasswordSecret,
            RemotePath           = p.TransportRemotePath,
            TlsThumbprint        = p.TransportTlsThumbprint,
            RetryCount           = httpsRetryCount
        };
    }
}


