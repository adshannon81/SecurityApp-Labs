using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Quartz;

namespace AuditArchiveJobPlugin;

/// <summary>
/// Monthly job that archives <c>audit_log</c> rows older than the configured
/// retention period into <c>audit_log_archive</c>, then removes them from the
/// live table.  Runs a partition-boundary extension so the archive table always
/// has at least 12 months of future boundaries available.
///
/// Configuration keys (all optional):
///   AuditArchive:RetentionDays   — rows older than this are archived  (default 90)
///   AuditArchive:BatchSize       — rows moved per transaction          (default 10000)
///   ConnectionStrings:SqlServer  — connection string used for raw ADO  (required)
/// </summary>
[DisallowConcurrentExecution]
public sealed class AuditArchiveJob(
    IConfiguration                  config,
    ILogger<AuditArchiveJob>        logger) : IJob
{
    public async Task Execute(IJobExecutionContext context)
    {
        var ct = context.CancellationToken;

        var cs = config.GetConnectionString("SqlServer")
            ?? throw new InvalidOperationException(
                "AuditArchiveJob: ConnectionStrings:SqlServer is not configured.");

        if (!int.TryParse(config["AuditArchive:RetentionDays"], out var retentionDays)
            || retentionDays < 1)
            retentionDays = 90;

        if (!int.TryParse(config["AuditArchive:BatchSize"], out var batchSize)
            || batchSize < 1)
            batchSize = 10_000;

        var cutoff = DateTime.UtcNow.AddDays(-retentionDays);

        logger.LogInformation(
            "AuditArchiveJob starting: archiving rows older than {Cutoff:u} ({Days} days), batchSize={Batch}",
            cutoff, retentionDays, batchSize);

        try
        {
            await using var conn = new SqlConnection(cs);
            await conn.OpenAsync(ct);

            var totalArchived = await ArchiveBatchesAsync(conn, cutoff, batchSize, ct);

            await ExtendPartitionBoundariesAsync(conn, ct);

            logger.LogInformation(
                "AuditArchiveJob completed: {Total} rows archived", totalArchived);
        }
        catch (OperationCanceledException)
        {
            logger.LogWarning("AuditArchiveJob was cancelled");
            throw;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "AuditArchiveJob failed");
            throw new JobExecutionException(ex) { RefireImmediately = false };
        }
    }

    // ── Archive in batches ────────────────────────────────────────────────────

    private static async Task<long> ArchiveBatchesAsync(
        SqlConnection conn,
        DateTime      cutoff,
        int           batchSize,
        CancellationToken ct)
    {
        long total = 0;
        int  moved;

        do
        {
            ct.ThrowIfCancellationRequested();

            await using var tx  = conn.BeginTransaction();
            await using var cmd = conn.CreateCommand();
            cmd.Transaction = tx;
            cmd.CommandText = """
                DECLARE @inserted INT;

                -- Insert eligible rows into archive
                WITH cte AS (
                    SELECT TOP (@BatchSize)
                        id, entity_type, action, user_id, user_name, details,
                        ip_address, entity_id, before_state, after_state,
                        changed_fields, correlation_id, causation_id, source, created_at
                    FROM dbo.audit_log WITH (ROWLOCK, READPAST)
                    WHERE created_at < @Cutoff
                    ORDER BY created_at
                )
                INSERT INTO dbo.audit_log_archive
                    (id, entity_type, action, user_id, user_name, details,
                     ip_address, entity_id, before_state, after_state,
                     changed_fields, correlation_id, causation_id, source, created_at, archived_at)
                SELECT
                    id, entity_type, action, user_id, user_name, details,
                    ip_address, entity_id, before_state, after_state,
                    changed_fields, correlation_id, causation_id, source, created_at, GETUTCDATE()
                FROM cte;

                SET @inserted = @@ROWCOUNT;

                -- Delete the same rows from the live table
                DELETE FROM dbo.audit_log WITH (ROWLOCK)
                WHERE id IN (
                    SELECT TOP (@BatchSize) id
                    FROM dbo.audit_log WITH (ROWLOCK, READPAST)
                    WHERE created_at < @Cutoff
                    ORDER BY created_at
                );

                SELECT @inserted AS RowsMoved;
                """;
            cmd.Parameters.AddWithValue("@BatchSize", batchSize);
            cmd.Parameters.AddWithValue("@Cutoff",    cutoff);
            cmd.CommandTimeout = 300; // 5 minutes per batch

            moved = (int)(await cmd.ExecuteScalarAsync(ct) ?? 0);
            await tx.CommitAsync(ct);
            total += moved;
        }
        while (moved == batchSize);

        return total;
    }

    // ── Extend partition boundaries ───────────────────────────────────────────
    // Ensures pf_audit_log_monthly always has boundaries up to 12 months ahead.
    // Idempotent: ALTER PARTITION FUNCTION … SPLIT RANGE is a no-op if the
    // boundary already exists (we guard with a sys.partition_range_values check).

    private static async Task ExtendPartitionBoundariesAsync(
        SqlConnection conn,
        CancellationToken ct)
    {
        var horizon = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1)
                          .AddMonths(12);

        // Find the highest existing boundary
        await using var queryCmd = conn.CreateCommand();
        queryCmd.CommandText = """
            SELECT CAST(MAX(prv.value) AS DATETIME2)
            FROM   sys.partition_functions   pf
            JOIN   sys.partition_range_values prv ON prv.function_id = pf.function_id
            WHERE  pf.name = 'pf_audit_log_monthly';
            """;

        var maxBoundaryObj = await queryCmd.ExecuteScalarAsync(ct);
        var maxBoundary    = maxBoundaryObj is DBNull or null
            ? DateTime.UtcNow
            : (DateTime)maxBoundaryObj;

        var next = new DateTime(maxBoundary.Year, maxBoundary.Month, 1).AddMonths(1);

        while (next <= horizon)
        {
            await using var splitCmd = conn.CreateCommand();
            splitCmd.CommandText = "ALTER PARTITION FUNCTION pf_audit_log_monthly() SPLIT RANGE (@Boundary);";
            splitCmd.Parameters.AddWithValue("@Boundary", next);
            await splitCmd.ExecuteNonQueryAsync(ct);
            next = next.AddMonths(1);
        }
    }
}
