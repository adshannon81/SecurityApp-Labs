using SecurityApp.Core.Plugins.Interfaces;

namespace AuditArchiveJobPlugin;

public sealed class AuditArchiveJobPlugin : IJobPlugin
{
    public Type    JobType     => typeof(AuditArchiveJob);
    public string  Name        => "audit-archive";
    public string  Group       => "maintenance";
    public string? DefaultCron => "0 0 2 1 * ?";   // 02:00 UTC on the 1st of each month
    public string  Description =>
        "Archives audit_log rows older than the configured retention period " +
        "(AuditArchive:RetentionDays, default 90 days) into audit_log_archive, " +
        "then extends the monthly partition boundaries 12 months ahead.";
}
