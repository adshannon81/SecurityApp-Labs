﻿using Microsoft.Extensions.Logging;
using Quartz;
using IJobExecutionContext = Quartz.IJobExecutionContext;
using SecurityApp.Core.Shared.Interfaces;
using SecurityApp.Core.Pricing.Entities;

namespace SecurityUpdateJobPlugin;

[DisallowConcurrentExecution]
public sealed class SecurityUpdateJob(
    IUnitOfWork                unitOfWork,
    IDataProviderService       dataProviderService,
    ILogger<SecurityUpdateJob> logger) : IJob
{
    public async Task Execute(IJobExecutionContext context)
    {
        var ct = context.CancellationToken;
        logger.LogInformation("Security update job started at {Time}", DateTimeOffset.UtcNow);

        try
        {
            var securities = (await unitOfWork.Securities.FindAsync(
                s => s.HasOpenPosition && s.IsCurrent && !s.IsDeleted, ct)).ToList();

            logger.LogInformation("Found {Count} open-position securities to update", securities.Count);

            if (securities.Count == 0) return;

            foreach (var security in securities)
            {
                try
                {
                    var identifiers = (await unitOfWork.SecurityIdentifiers.FindAsync(
                        si => si.SecurityId == security.Id && si.IsCurrent && !si.IsDeleted, ct)).ToList();
                    var primary = identifiers.FirstOrDefault(i => i.IsPrimary) ?? identifiers.FirstOrDefault();
                    if (primary is null) continue;

                    var priceData = await dataProviderService.GetCurrentPriceAsync(
                        primary.IdentifierValue, null, ct);

                    if (priceData is null) continue;

                    await unitOfWork.Prices.AddAsync(new Price
                    {
                        SecurityId = security.Id,
                        Value      = priceData.Price,
                        Source     = priceData.Source,
                        PriceDate  = priceData.PriceDate == default ? DateTime.UtcNow : priceData.PriceDate,
                        PriceType  = priceData.PriceType,
                        Currency   = priceData.Currency
                    }, ct);
                }
                catch (Exception ex)
                {
                    // Log and continue â€” one failure must not abort all others
                    logger.LogError(ex, "Failed to update prices for {SecurityId} ({Name})",
                        security.Id, security.Name);
                }
            }

            await unitOfWork.SaveChangesAsync(ct);
            logger.LogInformation("Security update job completed at {Time}", DateTimeOffset.UtcNow);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Security update job failed");
            throw new JobExecutionException(ex) { RefireImmediately = false };
        }
    }
}
