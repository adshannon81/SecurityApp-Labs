﻿using SecurityApp.Core.Plugins.Interfaces;


namespace SecurityUpdateJobPlugin;

public sealed class SecurityUpdateJobPlugin : IJobPlugin
{
    public Type   JobType     => typeof(SecurityUpdateJob);
    public string Name        => "nightly-security-update";
    public string Group       => "security-jobs";
    public string? DefaultCron => "0 0 0 * * ?";   // Daily at midnight UTC
    public string Description => "Nightly price update for all open-position securities.";
}
