using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Quartz;
using IJobExecutionContext = Quartz.IJobExecutionContext;

namespace SecurityApp.Plugin.MacroRisk;

/// <summary>
/// Quartz job that fetches the latest GDP growth rate and unemployment rate
/// from the FRED API and updates <see cref="MacroRiskDataCache"/>.
///
/// FRED series used:
/// <list type="bullet">
///   <item><b>A191RL1Q225SBEA</b> — Real GDP, Percent Change from Preceding Period (SAAR, quarterly)</item>
///   <item><b>UNRATE</b> — Civilian Unemployment Rate (%, monthly)</item>
/// </list>
///
/// Configuration:
/// <list type="bullet">
///   <item><c>MacroRisk:FredApiKey</c> — FRED API key (free, from https://fred.stlouisfed.org/docs/api/api_key.html)</item>
///   <item><c>MacroRisk:GdpSeriesId</c> — Override the GDP series (default: A191RL1Q225SBEA)</item>
///   <item><c>MacroRisk:UnrateSeriesId</c> — Override the unemployment series (default: UNRATE)</item>
/// </list>
///
/// If the API key is absent or a FRED call fails, the cache retains its previous values
/// (or the hardcoded defaults) so that formula evaluation is never blocked.
/// </summary>
[DisallowConcurrentExecution]
public sealed class MacroRiskDataJob(
    FredConnector                  fred,
    IConfiguration                 config,
    ILogger<MacroRiskDataJob>      logger) : IJob
{
    // Default FRED series IDs — can be overridden via configuration.
    private const string DefaultGdpSeries   = "A191RL1Q225SBEA";
    private const string DefaultUnrateSeries = "UNRATE";

    public async Task Execute(IJobExecutionContext context)
    {
        var ct = context.CancellationToken;

        var gdpSeries   = config["MacroRisk:GdpSeriesId"]   ?? DefaultGdpSeries;
        var unrateSeries = config["MacroRisk:UnrateSeriesId"] ?? DefaultUnrateSeries;

        logger.LogInformation(
            "MacroRiskDataJob starting: fetching {GdpSeries} and {UnrateSeries} from FRED",
            gdpSeries, unrateSeries);

        // Fetch both series concurrently.
        var gdpTask   = fred.GetLatestObservationAsync(gdpSeries,   ct);
        var unrateTask = fred.GetLatestObservationAsync(unrateSeries, ct);

        FredObservation? gdp   = null;
        FredObservation? unrate = null;

        try
        {
            await Task.WhenAll(gdpTask, unrateTask);
            gdp    = gdpTask.Result;
            unrate = unrateTask.Result;
        }
        catch (Exception ex)
        {
            // WhenAll aggregates; individual connector errors are already logged.
            logger.LogWarning(ex, "One or more FRED series fetches failed; cache will retain previous values");
        }

        if (gdp is null && unrate is null)
        {
            logger.LogWarning(
                "MacroRiskDataJob: both FRED fetches returned no data; cache unchanged (GDP={GdpGrowth}, Unrate={Unrate})",
                MacroRiskDataCache.GdpGrowthPct, MacroRiskDataCache.UnemploymentRatePct);
            return;
        }

        // Apply whichever values were successfully fetched; keep existing cache value for any that failed.
        var newGdp    = gdp?.Value    ?? MacroRiskDataCache.GdpGrowthPct;
        var newUnrate = unrate?.Value ?? MacroRiskDataCache.UnemploymentRatePct;

        MacroRiskDataCache.Update(newGdp, newUnrate);

        logger.LogInformation(
            "MacroRiskDataCache updated — GDP growth: {Gdp}% (as of {GdpDate}), " +
            "Unemployment: {Unrate}% (as of {UnrateDate})",
            newGdp,
            gdp?.Date.ToString("yyyy-MM-dd") ?? "unchanged",
            newUnrate,
            unrate?.Date.ToString("yyyy-MM-dd") ?? "unchanged");
    }
}
