using SecurityApp.Core.Plugins.Interfaces;

namespace SecurityApp.Plugin.MacroRisk;

/// <summary>
/// Registers <see cref="MacroRiskDataJob"/> with the host's Quartz scheduler.
///
/// The job runs once per day at 05:00 UTC — before market opens in most time zones —
/// so that formula evaluations during the trading day have fresh FRED data.
///
/// Override the schedule via <c>Jobs:MacroRiskDataFetch:Cron</c> in appsettings.
/// </summary>
public sealed class MacroRiskJobPlugin : IJobPlugin
{
    public Type    JobType     => typeof(MacroRiskDataJob);
    public string  Name        => "macro-risk-data-fetch";
    public string  Group       => "macro-risk";
    public string? DefaultCron => "0 0 5 * * ?";  // 05:00 UTC daily
    public string  Description =>
        "Fetches the latest GDP growth rate (A191RL1Q225SBEA) and unemployment rate (UNRATE) " +
        "from the FRED API and updates the in-process MacroRiskDataCache. " +
        "Requires MacroRisk:FredApiKey in configuration. " +
        "The cached values feed the no-argument form of RecessionRisk() in NCalc formulas.";
}
