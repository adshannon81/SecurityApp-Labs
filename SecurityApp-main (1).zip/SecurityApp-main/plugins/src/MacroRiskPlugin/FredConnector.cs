using System.Text.Json;
using System.Text.Json.Serialization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace SecurityApp.Plugin.MacroRisk;

/// <summary>
/// A single FRED series observation (date + value).
/// </summary>
public sealed record FredObservation(DateOnly Date, double Value);

/// <summary>
/// Lightweight HTTP client for the FRED REST API.
/// Fetches series observations and returns the latest non-missing value.
///
/// Configuration key: <c>MacroRisk:FredApiKey</c>
/// Base URL:          <c>https://api.stlouisfed.org/fred</c>
/// </summary>
public sealed class FredConnector
{
    // Shared static client — safe for background job use; avoids socket exhaustion.
    private static readonly HttpClient _http = new()
    {
        BaseAddress = new Uri("https://api.stlouisfed.org/fred/"),
        Timeout     = TimeSpan.FromSeconds(30),
    };

    private readonly string  _apiKey;
    private readonly ILogger _logger;

    public FredConnector(IConfiguration config, ILogger<FredConnector> logger)
    {
        _apiKey = config["MacroRisk:FredApiKey"] ?? string.Empty;
        _logger = logger;

        if (string.IsNullOrWhiteSpace(_apiKey))
            _logger.LogWarning(
                "MacroRisk:FredApiKey is not configured. " +
                "FRED data will not be fetched; fallback values will be used.");
    }

    /// <summary>
    /// Returns the most recent non-missing observation for a FRED series.
    /// Returns <c>null</c> if the API key is absent or the request fails.
    /// </summary>
    public async Task<FredObservation?> GetLatestObservationAsync(
        string seriesId, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(_apiKey))
            return null;

        var url = $"series/observations" +
                  $"?series_id={Uri.EscapeDataString(seriesId)}" +
                  $"&api_key={Uri.EscapeDataString(_apiKey)}" +
                  $"&sort_order=desc" +
                  $"&limit=10" +         // fetch a few in case the latest is a "." (missing)
                  $"&file_type=json";

        try
        {
            var json = await _http.GetStringAsync(url, ct);
            using var doc = JsonDocument.Parse(json);

            if (!doc.RootElement.TryGetProperty("observations", out var obs))
            {
                _logger.LogWarning("FRED response for {Series} missing 'observations' array", seriesId);
                return null;
            }

            foreach (var item in obs.EnumerateArray())
            {
                var rawDate  = item.GetProperty("date").GetString() ?? "";
                var rawValue = item.GetProperty("value").GetString() ?? ".";

                // FRED uses "." as a sentinel for missing data
                if (rawValue == "." || string.IsNullOrWhiteSpace(rawValue))
                    continue;

                if (!double.TryParse(rawValue,
                        System.Globalization.NumberStyles.Float,
                        System.Globalization.CultureInfo.InvariantCulture,
                        out var value))
                    continue;

                if (!DateOnly.TryParse(rawDate, out var date))
                    continue;

                _logger.LogInformation(
                    "FRED {Series}: latest observation {Date} = {Value}", seriesId, date, value);
                return new FredObservation(date, value);
            }

            _logger.LogWarning("FRED {Series}: no non-missing observations in the last 10 records", seriesId);
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FRED request failed for series {Series}", seriesId);
            return null;
        }
    }
}
