﻿using SecurityApp.Core.Ratings.Interfaces;

namespace SecurityApp.Plugin.MacroRisk;

// -------------------------------------------------------------------------------
// MacroRiskPlugin
//
// A drop-in NCalc-only plugin â€” no data connector, pure formula functions.
//
// Purpose
// -------
// Demonstrates cross-plugin composition via the shared NCalcFunctionRegistry.
// The function registered here (RecessionRisk) produces a raw risk value that
// is intentionally unit-less â€” it is designed to be piped into Normalize()
// from CreditFunctionsPlugin to produce a credit score:
//
//   Normalize(RecessionRisk([gdpGrowth], [unemploymentRate]), -5.0, 5.0, 1.0, 21.0)
//
// Neither plugin's C# code knows about the other.  The composition lives
// entirely in the @MacroRiskScore formula macro row in the FormulaMacros table.
//
// Functions provided by this plugin
// ----------------------------------
//   RecessionRisk(gdpGrowthPct, unemploymentRatePct)
//     -> Raw macro-economic risk score (approximately [-5, +5]).
//        Higher values mean more risk (worse economic conditions).
//        Designed to feed directly into Normalize() for final scoring.
//
// Cross-plugin interaction example
// ---------------------------------
//   DB macro row (FormulaMacros table):
//     Name:       MacroRiskScore
//     Expression: Normalize(RecessionRisk([gdpGrowth], [unemploymentRate]), -5.0, 5.0, 1.0, 21.0)
//     Scope:      Macro
//
//   Evaluation chain at runtime:
//     1. @MacroRiskScore is expanded by IFormulaMacroService (Layer 3)
//     2. RecessionRisk(...)  â†’ MacroRiskPlugin     (Layer 2)
//     3. Normalize(...)      â†’ CreditFunctionsPlugin (Layer 2)
//     4. Result feeds into any formula referencing @MacroRiskScore
//
// Deployment
// ----------
//   1. Run Build-Plugins.ps1 to compile and stage the DLL under
//      plugins/bin/MacroRiskPlugin/.
//   2. The API auto-discovers and registers RecessionRisk at startup.
//   3. Insert the MacroRiskScore macro row (see migration 007) to activate
//      the cross-plugin composition.
//
// -------------------------------------------------------------------------------

// --- RecessionRiskFunction ----------------------------------------------------

/// <summary>
/// Computes a raw macro-economic risk score from GDP growth rate and unemployment
/// rate, returning a value approximately in [-5, +5] for use with
/// <c>Normalize()</c> from CreditFunctionsPlugin.
///
/// Signature: <c>RecessionRisk(gdpGrowthPct, unemploymentRatePct)</c>
///
/// Model: <c>rawRisk = gdpGrowthPct Ã— -0.8 + unemploymentRatePct Ã— 0.6</c>
/// <list type="bullet">
///   <item>GDP coefficient (-0.8): higher growth reduces risk.</item>
///   <item>Unemployment coefficient (+0.6): higher unemployment increases risk.</item>
/// </list>
///
/// Reference calibration:
/// <list type="table">
///   <listheader><term>Conditions</term><description>Raw risk</description></listheader>
///   <item><term>GDP +5%, unemployment 2%</term><description>-2.8 (low risk)</description></item>
///   <item><term>GDP +2%, unemployment 5%</term><description> 1.4 (moderate)</description></item>
///   <item><term>GDP -1%, unemployment 9%</term><description> 6.2 â†’ clamped to 5 by Normalize</description></item>
/// </list>
///
/// Typical composition (via the <c>@MacroRiskScore</c> DB macro):
/// <code>Normalize(RecessionRisk([gdpGrowth], [unemploymentRate]), -5.0, 5.0, 1.0, 21.0)</code>
/// </summary>
public sealed class RecessionRiskFunction : INCalcFunction
{
    public string Name => "RecessionRisk";

    public ValueTask<object?> EvaluateAsync(object?[] args)
    {
        double gdp, unemployment;

        switch (args.Length)
        {
            case 0:
                // Read from live cache populated by MacroRiskDataJob (FRED API fetch).
                gdp          = MacroRiskDataCache.GdpGrowthPct;
                unemployment = MacroRiskDataCache.UnemploymentRatePct;
                break;

            case 2:
                gdp          = Convert.ToDouble(args[0]);
                unemployment = Convert.ToDouble(args[1]);
                break;

            default:
                throw new ArgumentException(
                    "RecessionRisk() accepts 0 arguments (live FRED cache) " +
                    "or 2 arguments (gdpGrowthPct, unemploymentRatePct).");
        }

        double rawRisk = gdp * -0.8 + unemployment * 0.6;
        return new ValueTask<object?>((object?)rawRisk);
    }
}
