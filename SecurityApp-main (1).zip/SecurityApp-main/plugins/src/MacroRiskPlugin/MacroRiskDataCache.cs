namespace SecurityApp.Plugin.MacroRisk;

/// <summary>
/// Thread-safe in-process cache for the latest FRED macro data values.
///
/// Updated by <see cref="MacroRiskDataJob"/> on its scheduled interval.
/// Read by <see cref="RecessionRiskFunction"/> when called with zero arguments.
///
/// Defaults are chosen to represent a stable, moderate economic environment
/// so that formulas produce reasonable scores before the first FRED fetch.
/// </summary>
public static class MacroRiskDataCache
{
    // FRED series: A191RL1Q225SBEA — Real GDP, Percent Change from Preceding Period (SAAR)
    // Positive = growth, negative = contraction.  Typical healthy range: 2–4 %.
    private static double _gdpGrowthPct = 2.0;

    // FRED series: UNRATE — Civilian Unemployment Rate (%)
    // Typical full-employment range: 3.5–5 %.
    private static double _unemploymentRatePct = 5.0;

    private static DateTime _lastUpdatedUtc = DateTime.MinValue;

    /// <summary>GDP growth rate, percent change at annual rate (e.g. 2.5 for 2.5 %).</summary>
    public static double GdpGrowthPct
    {
        get => Volatile.Read(ref _gdpGrowthPct);
        private set => Volatile.Write(ref _gdpGrowthPct, value);
    }

    /// <summary>Civilian unemployment rate in percent (e.g. 4.1 for 4.1 %).</summary>
    public static double UnemploymentRatePct
    {
        get => Volatile.Read(ref _unemploymentRatePct);
        private set => Volatile.Write(ref _unemploymentRatePct, value);
    }

    /// <summary>UTC timestamp of the last successful FRED data update.</summary>
    public static DateTime LastUpdatedUtc => _lastUpdatedUtc;

    /// <summary>Whether the cache has been populated by a live FRED fetch.</summary>
    public static bool HasRealData => _lastUpdatedUtc != DateTime.MinValue;

    /// <summary>
    /// Updates the cache with fresh FRED observations.
    /// Called by <see cref="MacroRiskDataJob"/> after a successful fetch.
    /// </summary>
    internal static void Update(double gdpGrowthPct, double unemploymentRatePct)
    {
        GdpGrowthPct       = gdpGrowthPct;
        UnemploymentRatePct = unemploymentRatePct;
        _lastUpdatedUtc    = DateTime.UtcNow;
    }
}
