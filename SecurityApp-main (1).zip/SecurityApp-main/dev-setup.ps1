﻿# dev-setup.ps1 — Developer environment reset
# ─────────────────────────────────────────────────────────────────────────────
# Tears down any running containers, starts infrastructure in the correct order,
# applies DB schema + seed data, then builds the .NET solution so you are ready
# to run `dotnet run` immediately.
#
# Requires .env and docker-compose.override.yml to already exist.
# Run deploy.ps1 once on a fresh machine to generate those files.
#
# Usage:
#   .\dev-setup.ps1
#   .\dev-setup.ps1 -DatabaseProvider SqlServer
#   .\dev-setup.ps1 -DatabaseProvider PostgreSQL
#
param(
    [ValidateSet('', 'PostgreSQL', 'SqlServer', 'MySql')]
    [string]$DatabaseProvider = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot

# ── Helpers ───────────────────────────────────────────────────────────────────
function Write-Step([string]$n, [string]$msg) { Write-Host "`nStep $n`: $msg" -ForegroundColor Cyan }
function Write-OK([string]$msg)   { Write-Host "  [OK]   $msg" -ForegroundColor Green  }
function Write-Warn([string]$msg) { Write-Host "  [WARN] $msg" -ForegroundColor Yellow }
function Write-Fail([string]$msg) { Write-Host "  [FAIL] $msg" -ForegroundColor Red; exit 1 }

function Wait-ContainerHealthy([string]$Name, [int]$TimeoutSec = 120, [int]$PollSec = 3) {
    $waited = 0
    do {
        Start-Sleep -Seconds $PollSec
        $waited += $PollSec
        $health = docker inspect --format='{{.State.Health.Status}}' $Name 2>&1
        Write-Host "  (${waited}s) $Name`: $health" -ForegroundColor DarkGray
        if ($waited -gt $TimeoutSec) { return $false }
    } until ($health -eq 'healthy')
    return $true
}

# ── Read .env ─────────────────────────────────────────────────────────────────
$EnvFile = Join-Path $Root ".env"
if (-not (Test-Path $EnvFile)) {
    Write-Fail ".env not found. Run .\deploy.ps1 first to generate credentials and config files."
}

$EnvVars = @{}
Get-Content $EnvFile | ForEach-Object {
    if ($_ -match '^\s*([A-Z_]+)\s*=\s*"?([^"#\r\n]*)"?') {
        $EnvVars[$Matches[1]] = $Matches[2].Trim()
    }
}
function Get-EnvVar([string]$Name) {
    if ($EnvVars.ContainsKey($Name)) { return $EnvVars[$Name] }
    return [System.Environment]::GetEnvironmentVariable($Name)
}

# ── Resolve DatabaseProvider ───────────────────────────────────────────────────
if (-not $DatabaseProvider) {
    $profiles = Get-EnvVar "COMPOSE_PROFILES"
    if ($profiles -match 'sqlserver') { $DatabaseProvider = 'SqlServer' }
    elseif ($profiles -match 'postgres') { $DatabaseProvider = 'PostgreSQL' }
    elseif ($profiles -match 'mysql') { $DatabaseProvider = 'MySql' }
    else {
        $appSettings = Join-Path $Root "src/SecurityApp.API/appsettings.json"
        if (Test-Path $appSettings) {
            $json = (Get-Content $appSettings -Raw) -replace '(?m)^\s*//.*$', '' -replace '/\*.*?\*/', ''
            try {
                $s = $json | ConvertFrom-Json -ErrorAction Stop
                if ($s.DatabaseProvider) { $DatabaseProvider = $s.DatabaseProvider }
            } catch {}
        }
        if (-not $DatabaseProvider) { $DatabaseProvider = 'SqlServer' }
    }
}
Write-Host "`n=== SecurityApp Dev Setup  [Database: $DatabaseProvider] ===" -ForegroundColor Cyan

# ── Step 1: Prerequisites ──────────────────────────────────────────────────────
Write-Step 1 "Checking prerequisites"
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { Write-Fail ".NET SDK not found." }
Write-OK ".NET SDK $(dotnet --version)"
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { Write-Fail "Docker not found." }
$dockerInfo = docker info 2>&1
if ($LASTEXITCODE -ne 0) { Write-Fail "Docker Desktop is not running." }
Write-OK "Docker Desktop is running."

# Trust dev HTTPS cert (non-fatal)
dotnet dev-certs https --trust 2>&1 | Out-Null
if ($LASTEXITCODE -eq 0) { Write-OK "HTTPS dev certificate trusted." }

# ── Step 2: Tear down existing containers ─────────────────────────────────────
Write-Step 2 "Tearing down existing containers"
docker compose down --remove-orphans 2>&1 | Out-Null
Write-OK "Containers removed."

# ── Step 3: Start infrastructure ──────────────────────────────────────────────
Write-Step 3 "Starting infrastructure services"
$infraServices = switch ($DatabaseProvider) {
    'SqlServer'  { @('sqlserver',  'redis', 'rabbitmq', 'vault', 'azurite') }
    'PostgreSQL' { @('postgres',   'redis', 'rabbitmq', 'vault', 'azurite') }
    'MySql'      { @('mysql',      'redis', 'rabbitmq', 'vault', 'azurite') }
}
docker compose up -d @infraServices
if ($LASTEXITCODE -ne 0) { Write-Fail "Failed to start infrastructure." }
Write-OK "Infrastructure containers started."

# ── Step 4: Wait for DB ────────────────────────────────────────────────────────
Write-Step 4 "Waiting for database and Vault to be ready"
$dbContainer = switch ($DatabaseProvider) {
    'SqlServer'  { 'securityapp-sqlserver' }
    'PostgreSQL' { 'securityapp-postgres'  }
    'MySql'      { 'securityapp-mysql'     }
}
if (-not (Wait-ContainerHealthy $dbContainer -TimeoutSec 120)) {
    Write-Fail "Database did not become healthy within 2 minutes."
}
Write-OK "Database is healthy."
if (-not (Wait-ContainerHealthy 'securityapp-vault' -TimeoutSec 60)) {
    Write-Warn "Vault did not become healthy within 1 minute - migration may fall back to Vault lookup."
} else {
    Write-OK "Vault is healthy."
}

# ── Step 5: Apply schema + seed data ──────────────────────────────────────────
Write-Step 5 "Applying database schema and seed data"
$migrationScript = switch ($DatabaseProvider) {
    'SqlServer'  { Join-Path $Root 'database\scripts\sqlserver\Apply-Migrations-SqlServer.ps1' }
    'PostgreSQL' { Join-Path $Root 'database\scripts\postgresql\Apply-Migrations-PostgreSQL.ps1' }
    'MySql'      { Join-Path $Root 'database\scripts\mysql\Apply-Migrations-MySQL.ps1' }
}
if (-not (Test-Path $migrationScript)) { Write-Fail "Migration script not found: $migrationScript" }

# Read the app DB password from Vault (set during deploy.ps1 - root token needed)
$appDbPass = ''
if ($DatabaseProvider -eq 'SqlServer') {
    $vaultRoot = docker exec securityapp-vault cat /vault/data/.init.json 2>&1 |
        Select-String '"root_token"' |
        ForEach-Object { if ($_ -match '"root_token"\s*:\s*"([^"]+)"') { $Matches[1] } }
    if ($vaultRoot) {
        $appDbPass = docker exec -e "VAULT_TOKEN=$vaultRoot" securityapp-vault `
            vault kv get -field='ConnectionStrings__SqlServer' secret/securityapp 2>&1
        if ($LASTEXITCODE -ne 0) { $appDbPass = '' }
        else {
            # Extract password from connection string: ...Password=<val>;...
            if ($appDbPass -match 'Password=([^;]+)') { $appDbPass = $Matches[1].Trim() }
            else { $appDbPass = '' }
        }
    }
    if ([string]::IsNullOrWhiteSpace($appDbPass)) {
        Write-Warn "Could not read app DB password from Vault. Migration will skip app login creation."
        & $migrationScript
    } else {
        & $migrationScript -AppDbPassword $appDbPass
    }
} else {
    & $migrationScript
}
if ($LASTEXITCODE -ne 0) { Write-Fail "Database migration failed." }
Write-OK "Schema and seed data applied."

# ── Step 6: Start Keycloak ────────────────────────────────────────────────────
Write-Step 6 "Starting Keycloak"
docker compose up -d keycloak
if ($LASTEXITCODE -ne 0) { Write-Fail "Failed to start Keycloak." }
Write-Host "  (First boot runs Liquibase migrations — allow ~2 minutes)" -ForegroundColor DarkGray
if (-not (Wait-ContainerHealthy 'securityapp-keycloak' -TimeoutSec 240 -PollSec 5)) {
    Write-Warn "Keycloak taking longer than expected. Check: docker logs securityapp-keycloak"
}
Write-OK "Keycloak is healthy."

# ── Step 7: Refresh Vault AppRole credentials in .env ────────────────────────
# RoleID is permanent — already written by deploy.ps1 and does not change.
# SecretID is single-use (10 min TTL) — generate a fresh one now so the API
# can exchange it for a 1-hour Vault token when it starts.
Write-Step 7 "Refreshing Vault AppRole SecretID"

if (-not (Wait-ContainerHealthy 'securityapp-vault' -TimeoutSec 60 -PollSec 3)) {
    Write-Warn "Vault not healthy — continuing, but AppRole SecretID may be stale."
}

# Read existing RoleID from .env (written by deploy.ps1 once)
$existingRoleId = Get-EnvVar "VAULT_ROLE_ID"
if ([string]::IsNullOrWhiteSpace($existingRoleId)) {
    # Fallback: read from vault volume in case .env was partially generated
    $existingRoleId = docker exec securityapp-vault cat /vault/data/approle.roleid 2>&1
    if ($LASTEXITCODE -ne 0) { $existingRoleId = '' }
    else { $existingRoleId = $existingRoleId.Trim() }
}
if ([string]::IsNullOrWhiteSpace($existingRoleId)) {
    Write-Fail "VAULT_ROLE_ID not found in .env and /vault/data/approle.roleid unreadable.`n  Re-run deploy.ps1 to reinitialise Vault."
}
Write-OK "RoleID: $existingRoleId"

# Read root token to generate SecretID (root token has permission to write secret-id)
$rootToken = docker exec securityapp-vault cat /vault/data/.init.json 2>&1 |
    Select-String '"root_token"' |
    ForEach-Object { if ($_ -match '"root_token"\s*:\s*"([^"]+)"') { $Matches[1] } }
if ([string]::IsNullOrWhiteSpace($rootToken)) {
    Write-Fail "Could not read Vault root token from /vault/data/.init.json."
}

$secretIdJson = docker exec -e "VAULT_TOKEN=$rootToken" `
    securityapp-vault vault write -f auth/approle/role/securityapp-api/secret-id -format=json 2>&1 | Out-String
$newSecretId = ''
try   { $newSecretId = ($secretIdJson | ConvertFrom-Json).data.secret_id }
catch { if ($secretIdJson -match '"secret_id"\s*:\s*"([^"]+)"') { $newSecretId = $Matches[1] } }

if ([string]::IsNullOrWhiteSpace($newSecretId)) {
    Write-Fail "Failed to generate AppRole SecretID. Check: docker logs securityapp-vault"
}
Write-OK "Fresh single-use SecretID generated (10 min TTL — consumed by API on startup)."

$envContent = Get-Content $EnvFile -Raw
# Ensure both keys are present (add if missing — handles .env from older deploy)
if ($envContent -notmatch '(?m)^VAULT_ROLE_ID=') {
    $envContent += "`nVAULT_ROLE_ID=$existingRoleId`n"
} else {
    $envContent = $envContent -replace '(?m)^VAULT_ROLE_ID=.*$', "VAULT_ROLE_ID=$existingRoleId"
}
if ($envContent -notmatch '(?m)^VAULT_SECRET_ID=') {
    $envContent += "VAULT_SECRET_ID=$newSecretId`n"
} else {
    $envContent = $envContent -replace '(?m)^VAULT_SECRET_ID=.*$', "VAULT_SECRET_ID=$newSecretId"
}
# Remove old SA token key if still present from a pre-AppRole .env
$envContent = $envContent -replace '(?m)^VAULT_SERVICE_ACCOUNT_TOKEN=.*\r?\n?', ''
Set-Content -Path $EnvFile -Value $envContent -Encoding UTF8
Write-OK "VAULT_ROLE_ID and VAULT_SECRET_ID written to .env. API will use AppRole auth."

# ── Step 8: dotnet restore + build ────────────────────────────────────────────
Write-Step 8 "Restoring NuGet packages"
dotnet restore (Join-Path $Root 'SecurityApp.slnx') | Out-Null
if ($LASTEXITCODE -ne 0) { Write-Fail "dotnet restore failed." }
Write-OK "Packages restored."

Write-Step 9 "Building solution"
$buildOut = dotnet build (Join-Path $Root 'SecurityApp.slnx') -v q 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host ($buildOut -join "`n") -ForegroundColor Red
    Write-Fail "Build failed."
}
Write-OK "Build succeeded."

# ── Done ──────────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "+================================================================+" -ForegroundColor Green
Write-Host "|              Dev environment ready!                            |" -ForegroundColor Green
Write-Host "+================================================================+" -ForegroundColor Green
Write-Host ""
Write-Host "  Start the API (in a separate terminal):" -ForegroundColor White
Write-Host "    dotnet run --project src/SecurityApp.API" -ForegroundColor Yellow
Write-Host ""
Write-Host "  Or start all containers (API + UI) in Docker:" -ForegroundColor White
Write-Host "    docker compose up -d api ui" -ForegroundColor Yellow
Write-Host ""
Write-Host "  URLs:" -ForegroundColor Cyan
Write-Host "    API Swagger  http://localhost:8080/swagger" -ForegroundColor Gray
Write-Host "    UI           http://localhost:4200" -ForegroundColor Gray
Write-Host "    Keycloak     http://localhost:8180/admin" -ForegroundColor Gray
Write-Host "    RabbitMQ     http://localhost:15673" -ForegroundColor Gray
Write-Host "    Vault        http://localhost:8200/ui" -ForegroundColor Gray
Write-Host ""
  Write-Host "  App logins (see credentials.txt for generated passwords):" -ForegroundColor Cyan
  Write-Host "    admin-dev       (Admin role)" -ForegroundColor Gray
  Write-Host "    contributor-dev (Contributor role)" -ForegroundColor Gray
  Write-Host "    viewer-dev      (Viewer role)" -ForegroundColor Gray
Write-Host ""
Write-Host "  Credentials for infra are in: .env and docker-compose.override.yml" -ForegroundColor DarkGray
Write-Host ""
