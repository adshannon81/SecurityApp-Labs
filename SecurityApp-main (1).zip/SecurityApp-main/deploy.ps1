﻿# deploy.ps1 - Customer First-Time Installation
# -----------------------------------------------------------------------------
# SecurityApp - Run this once after receiving/downloading the application package.
#
# Usage:
#   .\.deploy.ps1
#   .\deploy.ps1 -Database postgres      # choose PostgreSQL instead of SQL Server
#   .\deploy.ps1 -NonInteractive         # use defaults / pre-set env vars (unattended)
#   .\deploy.ps1 -Resume                 # retry a failed deploy reusing existing passwords
#   .\deploy.ps1 -Observability          # also start Prometheus + Grafana
#
# What this script does:
#   1.  Verifies prerequisites (Docker Desktop)
#   2.  Asks you to choose a database backend (SQL Server or PostgreSQL)
#   3.  Prompts for passwords -- generates secure random ones if you press Enter
#       (-Resume: reads existing passwords back from docker-compose.override.yml)
#   4.  Writes .env and docker-compose.override.yml from the included templates
#       (-Resume: skips -- existing config files are reused as-is)
#   5.  Pulls Docker images  (-Resume: skips)
#   6.  Starts infrastructure (DB, Redis, RabbitMQ, Vault, Azurite)
#   7.  Waits for DB to be healthy
#   8.  Applies the database schema and seed data
#   9.  Starts Keycloak, waits for healthy, then applies client roles & permissions-mapper
#   10. Randomises Keycloak app-user passwords via Admin REST API
#   11. Reads the Vault service-account token and writes it to .env
#   12. Starts API and waits for healthy
#   13. Starts UI
#   13b.(Optional, -Observability) Starts Prometheus + Grafana
#   14. Prints ALL URLs and credentials for the administrator
#
# To create an infrastructure admin account (Vault / RabbitMQ / SQL Server / Keycloak):
#   .\add-admin.ps1 -AdminName alice
#
# To UNINSTALL:
#   docker compose down -v     <- removes containers AND all data volumes
#   Remove-Item .env, docker-compose.override.yml, credentials.txt
#
# -----------------------------------------------------------------------------

param(
    [ValidateSet('sqlserver', 'postgres')]
    [string]$Database = 'sqlserver',

    [switch]$NonInteractive,

    # Auto-generate all passwords with no prompts.  Equivalent to pressing
    # Enter at every password prompt.  Useful for dev/CI without env vars.
    [switch]$AutoGenerate,

    # Resume a previously failed deploy:
    # Reads all passwords back from the existing docker-compose.override.yml
    # and skips Steps 4-5 (config rewrite + image pull).
    [switch]$Resume,

    # Also start Prometheus + Grafana (observability profile).
    [switch]$Observability,

    # Domain name for TLS (e.g. app.example.com).  When set, deploy.ps1 writes
    # TLS_CERT_PATH and TLS_KEY_PATH pointing to /etc/letsencrypt/live/<domain>/.
    [string]$Domain = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$Root = $PSScriptRoot

# -- Helpers ------------------------------------------------------------------
function Write-Step([string]$n, [string]$msg) {
    Write-Host "`nStep $n`: $msg" -ForegroundColor Cyan
}
function Write-OK([string]$msg)   { Write-Host "  [OK]   $msg" -ForegroundColor Green  }
function Write-Warn([string]$msg) { Write-Host "  [WARN] $msg" -ForegroundColor Yellow }
function Write-Fail([string]$msg) { Write-Host "  [FAIL] $msg" -ForegroundColor Red; exit 1 }

# Reads a key=value from docker-compose.override.yml (quoted values only).
# Used by -Resume to recover passwords without prompting.
function Read-OverrideValue([string]$Key) {
    $overrideFile = Join-Path $Root 'docker-compose.override.yml'
    if (-not (Test-Path $overrideFile)) { return $null }
    $content = Get-Content $overrideFile -Raw
    if ($content -match "(?m)^\s+${Key}:\s+`"([^`"]+)`"") { return $Matches[1] }
    return $null
}

function New-RandomPassword([int]$Length = 24) {
    $upper   = 'ABCDEFGHJKLMNPQRSTUVWXYZ'
    $lower   = 'abcdefghjkmnpqrstuvwxyz'
    $digits  = '123456789'
    $special = '!^*()-_=+:;<>,.?'       # % excluded: mangled by JDBC/URL percent-decoding
                                             # # excluded: comment character in .env files
    $all     = $upper + $lower + $digits + $special
    $rng     = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    do {
        $bytes = New-Object byte[] $Length
        $rng.GetBytes($bytes)
        $chars = $bytes | ForEach-Object { $all[$_ % $all.Length] }
        $pwd   = -join $chars
    } until (
        ($pwd -cmatch '[A-Z]') -and ($pwd -cmatch '[a-z]') -and
        ($pwd -match '\d')     -and ($pwd -match '[!^*()\-_=+:;<>,.?]')
    )
    return $pwd
}

# Safe password for values injected via .env variable substitution.
# Excludes only '$' (Compose expands it) and newline (terminates .env values).
# All other special chars are safe with exec-form array command.
function New-SafePassword([int]$Length = 32) {
    $upper   = 'ABCDEFGHJKLMNPQRSTUVWXYZ'
    $lower   = 'abcdefghjkmnpqrstuvwxyz'
    $digits  = '23456789'
    $special = '!^*()-_=+:;<>.?'            # comma excluded: delimiter in Redis/AMQP connection strings
                                             # # excluded: comment character in .env files
                                             # @ excluded: Vault CLI treats values starting with @ as file paths
                                             # % excluded: mangled by JDBC/URL percent-decoding
                                             # {}[] excluded: shell/YAML quoting issues
    $all     = $upper + $lower + $digits + $special
    $rng     = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    do {
        $bytes = New-Object byte[] $Length
        $rng.GetBytes($bytes)
        $chars = $bytes | ForEach-Object { $all[$_ % $all.Length] }
        $pwd   = -join $chars
    } until (
        ($pwd -cmatch '[A-Z]') -and ($pwd -cmatch '[a-z]') -and
        ($pwd -match '\d')     -and ($pwd -match '[!^*()\-_=+:;<>.?]')
    )
    return $pwd
}

function New-RandomBase64([int]$Bytes = 32) {
    $b = New-Object byte[] $Bytes
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b)
    return [Convert]::ToBase64String($b)
}

function Read-Password([string]$Prompt, [string]$EnvFallback, [int]$MinLength = 12) {
    $fromEnv = [System.Environment]::GetEnvironmentVariable($EnvFallback)
    if ($NonInteractive) {
        if (-not $fromEnv) { Write-Fail "$EnvFallback must be set when using -NonInteractive." }
        return $fromEnv
    }
    if ($fromEnv) { return $fromEnv }
    $generated = New-RandomPassword
    if ($AutoGenerate) {
        Write-OK "Auto-generated secure password for: $Prompt"
        return $generated
    }
    Write-Host "  $Prompt" -ForegroundColor Gray
    Write-Host "  (press Enter to use a generated secure password)" -ForegroundColor DarkGray
    $userInput = Read-Host "  Password"
    if ([string]::IsNullOrWhiteSpace($userInput)) {
        Write-OK "Generated secure password."
        return $generated
    }
    if ($userInput.Length -lt $MinLength) { Write-Fail "Password must be at least $MinLength characters." }
    return $userInput
}

function Wait-ContainerHealthy([string]$Name, [int]$TimeoutSec = 120, [int]$PollSec = 3) {
    $waited = 0
    do {
        Start-Sleep -Seconds $PollSec
        $waited += $PollSec
        $health = docker inspect --format='{{.State.Health.Status}}' $Name 2>&1
        Write-Host "  (${waited}s) ${Name}: $health" -ForegroundColor DarkGray
        if ($waited -gt $TimeoutSec) { return $false }
    } until ($health -eq 'healthy')
    return $true
}

# Generates the credentials report from whatever data is available so far.
# Called incrementally so credentials.txt is always up-to-date.
function Write-CredentialsFile([switch]$PrintToConsole) {
    $credPath = Join-Path $Root 'credentials.txt'
    $ln  = "=" * 65
    $ln2 = "-" * 65
    $pending = '(pending - will be set in a later step)'

    $rpt  = "`n$ln`n"
    $rpt += " SecurityApp - Administrator Credentials Report`n"
    $rpt += " Generated by deploy.ps1 on $(Get-Date -Format 'yyyy-MM-dd HH:mm')`n"
    $rpt += " KEEP THIS FILE PRIVATE. Do NOT share or commit it.`n"
    $rpt += "$ln`n"

    $rpt += "`n--- APPLICATION USERS (login via the UI or API) ---`n"
    $rpt += "$ln2`n"
    $rpt += " These accounts exist in Keycloak - passwords are randomised on each fresh deploy.`n`n"
    $rpt += "  URL:         http://localhost:4200`n`n"
    $rpt += "  Email:       admin@securityapp.local`n"
    $rpt += "  Password:    $($Creds.APP_PASS_ADMIN)`n"
    $rpt += "  Role:        Admin (full access)`n`n"
    $rpt += "  Email:       contributor@securityapp.local`n"
    $rpt += "  Password:    $($Creds.APP_PASS_CONTRIBUTOR)`n"
    $rpt += "  Role:        Contributor (read + write)`n`n"
    $rpt += "  Email:       viewer@securityapp.local`n"
    $rpt += "  Password:    $($Creds.APP_PASS_VIEWER)`n"
    $rpt += "  Role:        Viewer (read-only)`n"

    $rpt += "`n--- MAILPIT (local email catcher) ---`n$ln2`n"
    $rpt += "  Web UI:  http://localhost:8025`n"
    $rpt += "  SMTP:    localhost:1025 (internal: mailpit:1025)`n"
    $rpt += "  All outbound emails (password resets etc.) are captured here.`n"
    $rpt += "  No emails leave the machine.`n"

    $rpt += "`n--- OPENLDAP ---`n$ln2`n"
    $rpt += "  LDAP URL:    ldap://localhost:10389`n"
    $rpt += "  Admin DN:    cn=admin,dc=securityapp,dc=local`n"
    $rpt += "  Admin pass:  $($Creds.LDAP_ADMIN_PASS)`n"
    $rpt += "  Users DN:    ou=Users,dc=securityapp,dc=local`n"
    $rpt += "  Groups DN:   ou=Groups,dc=securityapp,dc=local`n"
    $rpt += "  LAM GUI:     http://localhost:8090  (login DN: cn=admin,dc=securityapp,dc=local)`n"

    $rpt += "`n--- KEYCLOAK ADMIN CONSOLE ---`n$ln2`n"
    $rpt += "  URL:         http://localhost:4200/auth/admin`n"
    $rpt += "  Username:    admin`n"
    $rpt += "  Password:    ${kcAdminPass}`n"
    $rpt += "  Purpose:     Manage users, roles, clients, realm settings`n"

    $rpt += "`n--- API ---`n$ln2`n"
    $rpt += "  Swagger UI:  http://localhost:8080/swagger`n"
    $rpt += "  Health:      http://localhost:8080/api/health`n"
    $rpt += "  Auth:        Bearer token (obtain via Keycloak login)`n"

    if ($Database -eq 'sqlserver') {
        $rpt += "`n--- SQL SERVER ---`n$ln2`n"
        $rpt += "  Host:          localhost,1433`n"
        $rpt += "  Admin login:   sa  /  ${mssqlPass}  (schema migrations, DBA access)`n"
        $rpt += "  App login:     securityapp  /  ${appDbPass}  (used by API - least privilege)`n"
        $rpt += "  KC login:      keycloak  /  ${kcDbPass}  (used by Keycloak - db_owner on keycloak_db only)`n"
        $rpt += "  App DB:        securityapp_db`n"
        $rpt += "  Keycloak DB:   keycloak_db`n"
    } else {
        $rpt += "`n--- POSTGRESQL ---`n$ln2`n"
        $rpt += "  Host:        localhost:5432`n"
        $rpt += "  Username:    ${pgUser}`n"
        $rpt += "  Password:    ${pgPass}`n"
        $rpt += "  App DB:      securityapp_db`n"
        $rpt += "  Keycloak DB: keycloak_db`n"
    }

    $rpt += "`n--- RABBITMQ ---`n$ln2`n"
    $rpt += "  Management:  http://localhost:15673`n"
    $rpt += "  Username:    securityapp`n"
    $rpt += "  Password:    ${rabbitmqPass}`n"
    $rpt += "  Erlang cookie (clustering): ${erlangCookie}`n"

    $rpt += "`n--- VAULT ---`n$ln2`n"
    $rpt += "  UI:               http://localhost:8200/ui`n"
    $rpt += "  Login method:     LDAP`n"
    $rpt += "  Admin username:   admin@securityapp.local`n"
    $rpt += "  Admin password:   $($Creds.APP_PASS_ADMIN)  (same as app login)`n"
    $rpt += "  Note:             Select the 'LDAP' method on the Vault UI login screen`n"
    if ($vaultRootToken) {
        $rpt += "  Root token:       ${vaultRootToken}`n"
        $rpt += "  NOTE: Root token is for emergency/first-boot use only.`n"
        $rpt += "        Run vault-rotate.ps1 -Action RevokeRootToken after first login.`n"
    } else {
        $rpt += "  Root token:       ${pending}`n"
    }
    if ($vaultRoleId) {
        $rpt += "  RoleID:           ${vaultRoleId}  (non-secret; identifies the API to Vault)`n"
    } else {
        $rpt += "  RoleID:           ${pending}`n"
    }
    if ($vaultWrapToken) {
        $rpt += "  WrapToken:        ${vaultWrapToken}  (single-use, 5-min — consumed by API on startup)`n"
    } else {
        $rpt += "  WrapToken:        ${pending}`n"
    }
    $rpt += "`n"
    $rpt += "  AppRole flow: RoleID + WrapToken -> unwrap -> SecretID -> 30m Vault token`n"
    $rpt += "  DB creds:     ephemeral SQL Server login, 30m lease, auto-renewed at 22min`n"
    $rpt += "  MQ creds:     ephemeral RabbitMQ user, 30m lease, auto-renewed at 22min`n`n"
    $rpt += "  To restart API:  .\scripts\vault-rotate.ps1 -Action RefreshSecretId`n"
    $rpt += "  Rotate KC DB:    .\scripts\vault-rotate.ps1 -Action RotateKcDbPassword`n"
    $rpt += "  Update secret:   .\scripts\vault-rotate.ps1 -Action UpdateSecret`n"
    $rpt += "  Revoke root:     .\scripts\vault-rotate.ps1 -Action RevokeRootToken`n"

    $rpt += "`n--- GRAFANA (Observability) ---`n$ln2`n"
    $rpt += "  URL:         http://localhost:3000`n"
    $rpt += "  Username:    admin@securityapp.local  (LDAP login)`n"
    $rpt += "  Password:    $($Creds.APP_PASS_ADMIN)  (same as app login)`n"
    $rpt += "  Note:        GF_SECURITY_ADMIN_PASSWORD is the bootstrap fallback only`n"
    $rpt += "  Note:        Start with: docker compose --profile observability up -d prometheus grafana`n"

    $rpt += "`n--- INTERNAL / INFRASTRUCTURE ---`n$ln2`n"
    $rpt += "  Redis:                 redis:6379  (password-protected, internal only)`n"
    $rpt += "  Azurite (blob/queue):  localhost:10000-10002`n"
    $rpt += "  Vault SA secret:       ${vaultSaSecret}  (Keycloak->Vault auth)`n"

    $rpt += "`n$ln`n"
    $rpt += " To restart:           docker compose up -d`n"
    $rpt += " To stop:              docker compose down`n"
    $rpt += " To uninstall+wipe:    docker compose down -v`n"
    $rpt += " Config files (keep):  .env  docker-compose.override.yml`n"
    $rpt += "$ln`n"

    Set-Content -Path $credPath -Value $rpt -Encoding UTF8
    if ($PrintToConsole) {
        Write-Host $rpt -ForegroundColor White
        Write-Host "  Saved to: credentials.txt" -ForegroundColor Yellow
    } else {
        Write-Host "  [OK]   credentials.txt updated." -ForegroundColor Green
    }
}

# Vault variables — populated in Step 11, used by Write-CredentialsFile
$vaultRoleId    = ''
$vaultWrapToken = ''
$vaultRootToken = ''

# =============================================================================
Write-Host ""
Write-Host "+================================================================+" -ForegroundColor Cyan
Write-Host "|           SecurityApp - Installation                           |" -ForegroundColor Cyan
Write-Host "+================================================================+" -ForegroundColor Cyan
Write-Host ""

# -- Step 1: Prerequisites ----------------------------------------------------
Write-Step 1 "Checking prerequisites"

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Write-Fail "Docker Desktop is not installed or not in PATH.`n  Download: https://www.docker.com/products/docker-desktop"
}
$dockerInfo = docker info 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Fail "Docker Desktop is installed but not running. Please start it and re-run this script."
}
Write-OK "Docker Desktop is running."

$ImageTar  = Join-Path $Root 'securityapp-api.tar'
$IsRelease = Test-Path $ImageTar
Write-OK "Docker Compose v2 found."

# -- Step 2: Choose database --------------------------------------------------
Write-Step 2 "Database backend: $Database"

if (-not $NonInteractive -and -not $AutoGenerate -and -not $PSBoundParameters.ContainsKey('Database')) {
    Write-Host "  Which database should SecurityApp use?" -ForegroundColor Gray
    Write-Host "  [1] SQL Server 2022  (default)" -ForegroundColor Gray
    Write-Host "  [2] PostgreSQL 16" -ForegroundColor Gray
    $choice = Read-Host "  Enter 1 or 2 (or press Enter for SQL Server)"
    if ($choice -eq '2') { $Database = 'postgres' }
}
Write-OK "Using: $Database"

# -- Step 3: Collect credentials ----------------------------------------------
if ($Resume) {
    Write-Step 3 "Reading existing credentials from docker-compose.override.yml"

    $overrideFile = Join-Path $Root 'docker-compose.override.yml'
    if (-not (Test-Path $overrideFile)) {
        Write-Fail "docker-compose.override.yml not found. Cannot resume.`n  Run .\deploy.ps1 without -Resume for a fresh deployment."
    }

    $Creds = @{}

    if ($Database -eq 'sqlserver') {
        $Creds.MSSQL_SA_PASSWORD = Read-OverrideValue 'ADMIN_SA_PASSWORD'
        if ([string]::IsNullOrWhiteSpace($Creds.MSSQL_SA_PASSWORD)) {
            $Creds.MSSQL_SA_PASSWORD = Read-OverrideValue 'MSSQL_SA_PASSWORD'
        }
    } else {
        $Creds.POSTGRES_USER = 'securityapp'
        $connStrPg = Read-OverrideValue 'CONNECTION_STRINGS__POSTGRESQL'
        if ($connStrPg -match 'Password=([^;]+)') { $Creds.POSTGRES_PASSWORD = $Matches[1] }
    }

    $Creds.RABBITMQ_PASS      = Read-OverrideValue 'RABBITMQ_DEFAULT_PASS'
    $Creds.KC_ADMIN_PASS      = Read-OverrideValue 'KC_BOOTSTRAP_ADMIN_PASSWORD'
    $Creds.VAULT_SA_SECRET    = Read-OverrideValue 'VAULT_SERVICE_ACCOUNT_SECRET'
    $Creds.KC_DB_PASSWORD     = Read-OverrideValue 'KC_DB_PASSWORD'
    $Creds.ERLANG_COOKIE      = Read-OverrideValue 'RABBITMQ_ERLANG_COOKIE'
    $Creds.GRAFANA_ADMIN_PASS  = Read-OverrideValue 'GF_SECURITY_ADMIN_PASSWORD'
    if ([string]::IsNullOrWhiteSpace($Creds.GRAFANA_ADMIN_PASS)) { $Creds.GRAFANA_ADMIN_PASS = New-RandomPassword }
    $Creds.LDAP_ADMIN_PASS = Read-OverrideValue 'LDAP_ADMIN_PASSWORD'

    # App DB password is embedded in the connection string
    $connStrSql = Read-OverrideValue 'CONNECTION_STRINGS__SQLSERVER'
    if ($connStrSql -match 'Password=([^;]+)') { $Creds.APP_DB_PASSWORD = $Matches[1] }

    # App-user passwords cannot be recovered — regenerate and reset via Keycloak API
    $Creds.APP_PASS_ADMIN       = New-RandomPassword
    $Creds.APP_PASS_CONTRIBUTOR = New-RandomPassword
    $Creds.APP_PASS_VIEWER      = New-RandomPassword

    # Validate nothing critical is missing
    $missing = @()
    if ($Database -eq 'sqlserver' -and [string]::IsNullOrWhiteSpace($Creds.MSSQL_SA_PASSWORD)) { $missing += 'MSSQL_SA_PASSWORD' }
    if ($Database -eq 'postgres'  -and [string]::IsNullOrWhiteSpace($Creds.POSTGRES_PASSWORD)) { $missing += 'POSTGRES_PASSWORD' }
    if ([string]::IsNullOrWhiteSpace($Creds.RABBITMQ_PASS))   { $missing += 'RABBITMQ_DEFAULT_PASS' }
    if ([string]::IsNullOrWhiteSpace($Creds.KC_ADMIN_PASS))   { $missing += 'KC_BOOTSTRAP_ADMIN_PASSWORD' }
    if ([string]::IsNullOrWhiteSpace($Creds.APP_DB_PASSWORD)) { $missing += 'APP_DB_PASSWORD (from CONNECTION_STRINGS__SQLSERVER)' }
    if ([string]::IsNullOrWhiteSpace($Creds.KC_DB_PASSWORD))  { $missing += 'KC_DB_PASSWORD' }
    if ($missing.Count -gt 0) {
        Write-Fail "Could not read the following credentials from docker-compose.override.yml:`n  $($missing -join ', ')`n  Run .\deploy.ps1 without -Resume for a fresh deployment."
    }

    Write-OK "All credentials read from existing docker-compose.override.yml."
} else {
    Write-Step 3 "Setting up credentials"
    Write-Host "  You can type your own passwords or press Enter to auto-generate secure ones." -ForegroundColor DarkGray

    $Creds = @{}

    if ($Database -eq 'sqlserver') {
        $Creds.MSSQL_SA_PASSWORD = Read-Password `
            "SQL Server SA password  (8+ chars, upper+lower+digit+symbol)" `
            'MSSQL_SA_PASSWORD' -MinLength 8
    } else {
        $Creds.POSTGRES_USER     = 'securityapp'
        $Creds.POSTGRES_PASSWORD = Read-Password `
            "PostgreSQL password for user 'securityapp'" `
            'POSTGRES_PASSWORD'
    }

    $Creds.LDAP_ADMIN_PASS = Read-Password "OpenLDAP admin password" 'LDAP_ADMIN_PASSWORD'
    $Creds.RABBITMQ_PASS      = Read-Password "RabbitMQ password" 'RABBITMQ_DEFAULT_PASS'
    $Creds.KC_ADMIN_PASS      = Read-Password "Keycloak admin console password" 'KC_ADMIN_PASSWORD'
    $Creds.VAULT_SA_SECRET    = Read-Password "Vault service-account secret (internal)" 'VAULT_SERVICE_ACCOUNT_SECRET'
    # Grafana password is always auto-generated (observability stack is optional/profile-gated)
    $Creds.GRAFANA_ADMIN_PASS = New-RandomPassword

    # App DB login password - always auto-generated (used by the API, not for admin access)
    $Creds.APP_DB_PASSWORD = New-RandomPassword

    # Keycloak DB login password - auto-generated (db_owner on keycloak_db only, not accessible by API)
    $Creds.KC_DB_PASSWORD  = New-RandomPassword

    # Redis password - auto-generated (internal only, never exposed outside Docker network)
    $Creds.REDIS_PASSWORD  = New-SafePassword

    # App-user passwords are always auto-generated (not prompted - they are set via Keycloak API)
    $Creds.APP_PASS_ADMIN       = New-RandomPassword
    $Creds.APP_PASS_CONTRIBUTOR = New-RandomPassword
    $Creds.APP_PASS_VIEWER      = New-RandomPassword

    Write-OK "All credentials collected."
}

# -- Step 4: Write .env -------------------------------------------------------
# Derive working variables from $Creds (needed in both fresh and -Resume modes)
$mssqlPass    = if ($Creds.ContainsKey('MSSQL_SA_PASSWORD')) { $Creds.MSSQL_SA_PASSWORD } else { '' }
$appDbPass    = $Creds.APP_DB_PASSWORD
$kcDbPass     = $Creds.KC_DB_PASSWORD
$pgUser       = if ($Creds.ContainsKey('POSTGRES_USER'))     { $Creds.POSTGRES_USER }     else { 'securityapp' }
$pgPass       = if ($Creds.ContainsKey('POSTGRES_PASSWORD')) { $Creds.POSTGRES_PASSWORD } else { '' }
$erlangCookie = if ($Creds.ContainsKey('ERLANG_COOKIE') -and $Creds.ERLANG_COOKIE) { $Creds.ERLANG_COOKIE } else { New-RandomBase64 24 }
$rabbitmqPass = $Creds.RABBITMQ_PASS
$kcAdminPass  = $Creds.KC_ADMIN_PASS
$vaultSaSecret= $Creds.VAULT_SA_SECRET
$redisPass    = if ($Creds.ContainsKey('REDIS_PASSWORD') -and $Creds.REDIS_PASSWORD) { $Creds.REDIS_PASSWORD } else { New-SafePassword }
# SA connection string - used only by migration scripts (admin)
$dbConnStrSqlSa  = "Server=sqlserver,1433;Database=securityapp_db;User Id=sa;Password=${mssqlPass};TrustServerCertificate=True;"
# App login connection string - stored in Vault, used by the API at runtime (least privilege)
$dbConnStrSql    = "Server=sqlserver,1433;Database=securityapp_db;User Id=securityapp;Password=${appDbPass};TrustServerCertificate=True;"
$dbConnStrPg     = "Host=postgres;Port=5432;Database=securityapp_db;Username=${pgUser};Password=${pgPass};"

if ($Resume) {
    Write-Step 4 "Skipping config file rewrite (resume mode — reusing existing .env and docker-compose.override.yml)"
    # Still need COMPOSE_FILE resolved for docker compose calls below
    $profileFile = if ($Database -eq 'sqlserver') { 'docker-compose.sqlserver.yml' } else { 'docker-compose.postgres.yml' }
} else {
    Write-Step 4 "Writing configuration files"

$profileFile = if ($Database -eq 'sqlserver') {
    'docker-compose.sqlserver.yml'
} else {
    'docker-compose.postgres.yml'
}

$sep = if ($IsWindows) { ';' } else { ':' }  # COMPOSE_FILE path separator (Windows=; Linux=:)

$releaseOverride = if ($IsRelease -and (Test-Path (Join-Path $Root 'docker-compose.release.yml'))) {
    "${sep}docker-compose.release.yml"
} else { '' }

# Derive the canonical public base URL from -Domain (or fall back to localhost)
$domainUrl = if ($Domain) { "https://${Domain}" } else { 'https://localhost' }

$envContent  = "# SecurityApp .env - generated by deploy.ps1 on $(Get-Date -Format 'yyyy-MM-dd HH:mm')`n"
$envContent += "# Keep this file private. Do NOT share or commit it.`n"
$envContent += "# To reconfigure, re-run deploy.ps1.`n"
$envContent += "`n"
$envContent += "COMPOSE_FILE=docker-compose.yml${releaseOverride}${sep}${profileFile}${sep}docker-compose.override.yml`n"
$profiles = $Database
if ($Observability) { $profiles += ",observability" }
$envContent += "COMPOSE_PROFILES=${profiles}`n"
$envContent += "REDIS_PASSWORD=${redisPass}`n"
$envContent += "`n"

if ($Database -eq 'sqlserver') {
    # Note: password is written directly into docker-compose.override.yml sqlserver
    # service block and also stored in Vault at secret/admin/database.
    # It is NOT stored in .env - docker compose reads it from the override file.
    $envContent += "# DB admin password is in Vault (secret/admin/database) and docker-compose.override.yml`n"
    $envContent += "# NOT stored here - the sqlserver container reads it from the override file.`n"
} else {
    $envContent += "# DB credentials - also written to docker-compose.override.yml for the container`n"
    $envContent += "POSTGRES_USER=${pgUser}`n"
    $envContent += "POSTGRES_PASSWORD=${pgPass}`n"
}

$envContent += "`n"
$envContent += "# Public base URL — drives Keycloak external authority, redirect URIs, TLS cert paths`n"
$envContent += "APP_DOMAIN_URL=${domainUrl}`n"
if ($Domain) {
    $certBase = "/etc/letsencrypt/live/${Domain}"
    $envContent += "TLS_CERT_PATH=${certBase}/fullchain.pem`n"
    $envContent += "TLS_KEY_PATH=${certBase}/privkey.pem`n"
}
$envContent += "# Vault AppRole credentials - written automatically in Step 11`n"
$envContent += "# RoleID is non-secret (like a username). WrapToken is single-use, 5-min, generated per deployment.`n"
$envContent += "VAULT_ROLE_ID=`n"
$envContent += "VAULT_WRAP_TOKEN=`n"

Set-Content -Path (Join-Path $Root '.env') -Value $envContent -Encoding UTF8
Write-OK ".env written."

# -- Write docker-compose.override.yml --------------------------------
    if ($Database -eq 'sqlserver') {
    $dbServiceBlock  = "  sqlserver:`n"
    $dbServiceBlock += "    environment:`n"
    $dbServiceBlock += "      MSSQL_SA_PASSWORD: `"${mssqlPass}`"`n"
} else {
    $dbServiceBlock  = "  postgres:`n"
    $dbServiceBlock += "    environment:`n"
    $dbServiceBlock += "      POSTGRES_USER:     `"${pgUser}`"`n"
    $dbServiceBlock += "      POSTGRES_PASSWORD: `"${pgPass}`"`n"
}

$ts = Get-Date -Format 'yyyy-MM-dd HH:mm'

$overrideContent  = "# docker-compose.override.yml - generated by deploy.ps1 on ${ts}`n"
$overrideContent += "# Keep this file private. Do NOT share or commit it.`n"
$overrideContent += "services:`n"
$overrideContent += "`n"
$overrideContent += "${dbServiceBlock}`n"
$overrideContent += "  rabbitmq:`n"
$overrideContent += "    environment:`n"
$overrideContent += "      RABBITMQ_DEFAULT_USER:  `"securityapp`"`n"
$overrideContent += "      RABBITMQ_DEFAULT_PASS:  `"${rabbitmqPass}`"`n"
$overrideContent += "      RABBITMQ_ERLANG_COOKIE: `"${erlangCookie}`"`n"
$overrideContent += "    ports:`n"
$overrideContent += "      - `"5673:5672`"`n"
$overrideContent += "      - `"15673:15672`"`n"
$overrideContent += "`n"
$overrideContent += "  redis:`n"
$overrideContent += "    environment:`n"
$overrideContent += "      REDIS_PASSWORD: `"${redisPass}`"`n"
$overrideContent += "`n"
$overrideContent += "  api:`n"
$overrideContent += "    environment:`n"
$dbProviderValue = if ($Database -eq 'postgres') { 'PostgreSQL' } else { 'SqlServer' }
$overrideContent += "      DatabaseProvider: $dbProviderValue`n"
$overrideContent += "      ConnectionStrings__Redis:    `"redis:6379,password=${redisPass}`"`n"
$overrideContent += "      Keycloak__Authority:         `"http://keycloak:8080/auth/realms/securityapp`"`n"
$overrideContent += "      Keycloak__ExternalAuthority: `"${domainUrl}/auth/realms/securityapp`"`n"
if ($Domain) {
    $overrideContent += "      Cors__AllowedOrigins__0:     `"${domainUrl}`"`n"
}
$overrideContent += "      RabbitMQ__Username:                     `"securityapp`"`n"
$overrideContent += "      RabbitMQ__Password:                     `"${rabbitmqPass}`"`n"
$overrideContent += "      SecretProviders__EnableHashiCorpVault:  `"true`"`n"
$overrideContent += "      SecretProviders__VaultAddress:          `"http://vault:8200`"`n"
$overrideContent += "      SecretProviders__EnableAppRoleAuth:     `"true`"`n"
$overrideContent += "      SecretProviders__VaultRoleId:           `"`${VAULT_ROLE_ID}`"`n"
$overrideContent += "      SecretProviders__VaultWrapToken:        `"`${VAULT_WRAP_TOKEN}`"`n"
$overrideContent += "      SecretProviders__VaultDatabaseRole:           `"securityapp-api-db`"`n"
$overrideContent += "      SecretProviders__VaultRabbitMqRole:           `"securityapp-api`"`n"
if ($Database -eq 'sqlserver') {
    $overrideContent += "      SecretProviders__VaultDatabaseProvider:       `"sqlserver`"`n"
    $overrideContent += "      SecretProviders__VaultDatabaseConnectionBase: `"Server=sqlserver,1433;Database=securityapp_db;TrustServerCertificate=True`"`n"
} else {
    $overrideContent += "      SecretProviders__VaultDatabaseProvider:       `"postgresql`"`n"
    $overrideContent += "      SecretProviders__VaultDatabaseConnectionBase: `"Host=postgres;Port=5432;Database=securityapp_db`"`n"
}
$overrideContent += "`n"
$overrideContent += "  openldap:`n"
$overrideContent += "    environment:`n"
$overrideContent += "      LDAP_ADMIN_PASSWORD: `"$($Creds.LDAP_ADMIN_PASS)`"`n"
$overrideContent += "`n"
$overrideContent += "  keycloak:`n"
$overrideContent += "    environment:`n"
$overrideContent += "      KC_BOOTSTRAP_ADMIN_USERNAME: `"admin`"`n"
$overrideContent += "      KC_BOOTSTRAP_ADMIN_PASSWORD: `"${kcAdminPass}`"`n"
if ($Database -eq 'sqlserver') {
    # Override the KC_DB_PASSWORD set in docker-compose.sqlserver.yml
    # with the dedicated keycloak login rather than sa
    $overrideContent += "      KC_DB_USERNAME: `"keycloak`"`n"
    $overrideContent += "      KC_DB_PASSWORD: `"${kcDbPass}`"`n"
}
$overrideContent += "`n"
$overrideContent += "  vault:`n"
$overrideContent += "    user: root`n"
$overrideContent += "    environment:`n"
$overrideContent += "      CONNECTION_STRINGS__SQLSERVER:  `"${dbConnStrSql}`"`n"
$overrideContent += "      CONNECTION_STRINGS__POSTGRESQL: `"${dbConnStrPg}`"`n"
$overrideContent += "      CONNECTION_STRINGS__REDIS:      `"redis:6379,password=${redisPass}`"`n"
$overrideContent += "      RABBITMQ_DEFAULT_USER:          `"securityapp`"`n"
$overrideContent += "      RABBITMQ_DEFAULT_PASS:          `"${rabbitmqPass}`"`n"
$overrideContent += "      VAULT_SERVICE_ACCOUNT_SECRET:   `"${vaultSaSecret}`"`n"
$overrideContent += "      ADMIN_SA_PASSWORD:              `"${mssqlPass}`"`n"
$overrideContent += "      ADMIN_PG_PASSWORD:              `"${pgPass}`"`n"
$overrideContent += "      ADMIN_KC_DB_PASSWORD:           `"${kcDbPass}`"`n"
$overrideContent += "      LDAP_ADMIN_PASSWORD:            `"$($Creds.LDAP_ADMIN_PASS)`"`n"
$overrideContent += "`n"
$kcPublicUrl = if ($Domain) { "${domainUrl}/auth" } else { "http://localhost:4200/auth" }
$overrideContent += "  ui:`n"
$overrideContent += "    environment:`n"
$overrideContent += "      API_URL:            `"`"`n"
$overrideContent += "      KEYCLOAK_URL:       `"${kcPublicUrl}`"`n"
$overrideContent += "      KEYCLOAK_REALM:     `"securityapp`"`n"
$overrideContent += "      KEYCLOAK_CLIENT_ID: `"securityapp-ui`"`n"
$overrideContent += "`n"
$overrideContent += "  grafana:`n"
$overrideContent += "    environment:`n"
$overrideContent += "      GF_SECURITY_ADMIN_PASSWORD: `"$($Creds.GRAFANA_ADMIN_PASS)`"`n"
$overrideContent += "      LDAP_ADMIN_PASSWORD:        `"$($Creds.LDAP_ADMIN_PASS)`"`n"
$overrideContent += "`n"
$overrideContent += "  lam:`n"
$overrideContent += "    environment:`n"
$overrideContent += "      LDAP_ADMIN_PASSWORD: `"$($Creds.LDAP_ADMIN_PASS)`"`n"

Set-Content -Path (Join-Path $Root 'docker-compose.override.yml') -Value $overrideContent -Encoding UTF8
Write-OK "docker-compose.override.yml written."
} # end if (-not $Resume) for Steps 4a+4b

# First credentials.txt write — captures all passwords known so far
Write-CredentialsFile

# Expose SA password to the current process so Docker Compose can interpolate
# ${MSSQL_SA_PASSWORD} in docker-compose.sqlserver.yml (sqlserver-init command).
# It is never written to .env — it lives only in this process and the override file.
if ($Database -eq 'sqlserver') {
    $env:MSSQL_SA_PASSWORD = $mssqlPass
}

# -- Step 5: Pull / load images -----------------------------------------------
if ($Resume) {
    Write-Step 5 "Skipping image pull (resume mode)"
} elseif ($IsRelease) {
    Write-Step 5 "Loading pre-built images from tar files"
    docker load -i $ImageTar 2>&1 | ForEach-Object { Write-Host "  $_" -ForegroundColor DarkGray }
    if ($LASTEXITCODE -ne 0) { Write-Fail "Failed to load API image. The tar file may be corrupt." }
    Write-OK "API image loaded."
    $UiImageTar = Join-Path $Root 'securityapp-ui.tar'
    if (Test-Path $UiImageTar) {
        docker load -i $UiImageTar 2>&1 | ForEach-Object { Write-Host "  $_" -ForegroundColor DarkGray }
        if ($LASTEXITCODE -ne 0) { Write-Fail "Failed to load UI image. The tar file may be corrupt." }
        Write-OK "UI image loaded."
    }
    docker compose pull --ignore-buildable
} else {
    Write-Step 5 "Pulling Docker images (this may take a few minutes on first run)"
    docker compose pull --ignore-buildable
    if ($LASTEXITCODE -ne 0) { Write-Fail "Failed to pull one or more Docker images. Check your internet connection or registry credentials." }
}

# -- Step 6: Start infrastructure (DB, cache, messaging, vault) ---------------
Write-Step 6 "Starting infrastructure services"

# Postgres container runs as non-root (uid 70) and reads /docker-entrypoint-initdb.d/
# via the host-mounted volume. If the directory is not world-readable the container
# logs "can't open '/docker-entrypoint-initdb.d/': Permission denied" and stays unhealthy.
if ($IsLinux -or $IsMacOS) {
    $pgInitDir = Join-Path $Root 'database' 'scripts' 'postgresql' 'init'
    if (Test-Path $pgInitDir) { chmod -R 755 $pgInitDir | Out-Null }
}

# Guard: SQL Server/Postgres only reads the SA/superuser password from the env var
# during FIRST volume initialisation.  If a data volume already exists from a
# previous (possibly failed) deploy and we are running fresh (not -Resume), the new
# randomly-generated password will be written to the override file but SQL Server
# will keep using the old password from the volume → healthcheck fails.
# Detect this and fail fast with a clear message rather than waiting 2 minutes.
if (-not $Resume) {
    $dbVolumeName = if ($Database -eq 'sqlserver') { 'securityapp_sqlserver_data' } else { 'securityapp_postgres_data' }
    $existingVolume = docker volume ls --quiet --filter "name=^${dbVolumeName}$" 2>$null
    if ($existingVolume) {
        Write-Fail @"
A database volume '$dbVolumeName' already exists from a previous deployment.
SQL Server/Postgres only sets the admin password on the FIRST volume initialisation,
so running a fresh deploy will produce a password mismatch and an unhealthy container.

You have two options:

  Option A — Keep existing data (reuse old passwords):
    .\deploy.ps1 -Resume

  Option B — Wipe everything and start clean:
    docker compose down -v
    .\deploy.ps1
"@
    }
}

$infraServices = if ($Database -eq 'sqlserver') {
    @('sqlserver', 'redis', 'rabbitmq', 'vault', 'azurite', 'mailpit', 'openldap')
} else {
    @('postgres', 'redis', 'rabbitmq', 'vault', 'azurite', 'mailpit', 'openldap')
}
docker compose up -d @infraServices
if ($LASTEXITCODE -ne 0) { Write-Fail "Failed to start infrastructure. Run 'docker compose logs' for details." }
Write-OK "Infrastructure containers started."

# Wait for Mailpit — Keycloak depends on it for SMTP (password reset emails)
Write-Host "  Waiting for Mailpit to be ready..." -ForegroundColor DarkGray
if (-not (Wait-ContainerHealthy 'securityapp-mailpit' -TimeoutSec 30 -PollSec 3)) {
    Write-Warn "Mailpit did not become healthy within 30s. Check: docker logs securityapp-mailpit"
}
Write-OK "Mailpit is healthy."

# Wait for OpenLDAP — Keycloak and RabbitMQ both depend on it for LDAP auth
Write-Host "  Waiting for OpenLDAP to be ready..." -ForegroundColor DarkGray
if (-not (Wait-ContainerHealthy 'securityapp-openldap' -TimeoutSec 60 -PollSec 5)) {
    Write-Warn "OpenLDAP did not become healthy within 60s. Check: docker logs securityapp-openldap"
    Write-Warn "Keycloak and RabbitMQ LDAP auth may fail if OpenLDAP is not ready."
}
Write-OK "OpenLDAP is healthy."

# Import LDAP seed data via ldapadd.
# We avoid LDAP_CUSTOM_LDIF_DIR (Docker bind-mount timing/overlay issues).
# Instead we write the LDIF into the container and run ldapadd after startup.
Write-Host "  Importing LDAP seed data..." -ForegroundColor DarkGray
$seedPath = Join-Path $Root 'ldap' 'seed.ldif'
if (Test-Path $seedPath) {
    try {
        $seedContent = [System.IO.File]::ReadAllText($seedPath)
        # Normalise to LF — LDIF parsers require LF, not CRLF
        $seedContent = $seedContent -replace "`r`n", "`n" -replace "`r", "`n"
        $seedB64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($seedContent))
        docker exec securityapp-openldap sh -c "printf '%s' '$seedB64' | base64 -d > /tmp/seed.ldif" | Out-Null

        # -c = continue on error (skip entries that already exist, e.g. root DC)
        $addResult = docker exec securityapp-openldap ldapadd `
            -x `
            -H ldap://localhost:10389 `
            -D "cn=admin,dc=securityapp,dc=local" `
            -w $Creds.LDAP_ADMIN_PASS `
            -c `
            -f /tmp/seed.ldif 2>&1
        if ($LASTEXITCODE -ne 0 -and $LASTEXITCODE -ne 68) {
            throw "ldapadd exited $LASTEXITCODE`: $addResult"
        }
        Write-OK "LDAP seed data imported."
    } catch {
        Write-Warn "LDAP seed import failed: $($_.Exception.Message)"
        Write-Warn "LDAP password changes and sync may fail."
    }
} else {
    Write-Warn "ldap/seed.ldif not found — LDAP will have no users."
}

# -- Step 7: Wait for DB to be healthy ----------------------------------------
Write-Step 7 "Waiting for database to be ready"
$dbContainer = if ($Database -eq 'sqlserver') { 'securityapp-sqlserver' } else { 'securityapp-postgres' }
if (-not (Wait-ContainerHealthy $dbContainer -TimeoutSec 120)) {
    Write-Fail @"
Database container '$dbContainer' did not become healthy within 2 minutes.
Run the following to see why:
  docker logs $dbContainer --tail 50
  docker inspect --format='{{range .State.Health.Log}}{{.Output}}{{end}}' $dbContainer
"@
}
Write-OK "Database is healthy."

# -- Step 8: Apply schema & seed data -----------------------------------------
Write-Step 8 "Applying database schema and seed data"

$migrationScript = if ($Database -eq 'sqlserver') {
    Join-Path $Root 'database\scripts\sqlserver\Apply-Migrations-SqlServer.ps1'
} else {
    Join-Path $Root 'database\scripts\postgresql\Apply-Migrations-PostgreSQL.ps1'
}

if (-not (Test-Path $migrationScript)) {
    Write-Fail "Migration script not found: $migrationScript"
}

& $migrationScript -SaPassword $mssqlPass -AppDbPassword $appDbPass -KcDbPassword $kcDbPass
if ($LASTEXITCODE -ne 0) { Write-Fail "Database migration failed. See output above." }
Write-OK "Schema and seed data applied."

# -- Step 9: Start Keycloak ---------------------------------------------------
Write-Step 9 "Starting Keycloak"
# Keycloak container runs as non-root (uid 1000) and uses File.listFiles() to
# scan the import directory — if the directory is not world-readable it returns
# null and Keycloak crashes with "directory not found".
if ($IsLinux -or $IsMacOS) {
    chmod -R 755 (Join-Path $Root 'keycloak') | Out-Null
}
docker compose up -d keycloak
if ($LASTEXITCODE -ne 0) { Write-Fail "Failed to start Keycloak." }
Write-Host "  (First boot runs Liquibase migrations - allow ~2 minutes)" -ForegroundColor DarkGray
if (-not (Wait-ContainerHealthy 'securityapp-keycloak' -TimeoutSec 240 -PollSec 5)) {
    Write-Warn "Keycloak is taking longer than expected. Check: docker logs securityapp-keycloak"
}
Write-OK "Keycloak is healthy."

# -- Step 9b: Apply Keycloak client roles, composites & permissions-mapper ----
Write-Host "  Applying client roles and permissions mapper..." -ForegroundColor DarkGray
try {
    $applyPermScript = Join-Path $Root 'keycloak' 'apply-permissions.ps1'
    & $applyPermScript `
        -AdminPassword $kcAdminPass `
        -KeycloakUrl   'http://localhost:8180/auth'
    Write-OK "Client roles, composite mappings, and permissions-mapper applied."
} catch {
    Write-Warn "apply-permissions.ps1 failed: $($_.Exception.Message)"
    Write-Warn "Run manually after deploy: .\keycloak\apply-permissions.ps1 -AdminPassword '<kc-admin-pass>' -KeycloakUrl 'http://localhost:8180/auth'"
}

# -- Step 9b2: Patch LDAP bind credential in Keycloak -------------------------
# realm-export.json uses ${env.LDAP_ADMIN_PASSWORD} for bindCredential, but
# Keycloak does not resolve env vars in bindCredential at realm import time —
# it stores the literal placeholder or an empty string, causing all LDAP binds
# to fail with ERR_229. We patch the stored credential via the Admin API here.
Write-Host "  Patching LDAP bind credential in Keycloak..." -ForegroundColor DarkGray
try {
    $kcEp = [Uri]::EscapeDataString($kcAdminPass)
    $kcTok = (Invoke-RestMethod -Uri 'http://localhost:8180/auth/realms/master/protocol/openid-connect/token' `
        -Method Post -ContentType 'application/x-www-form-urlencoded' `
        -Body "grant_type=password&client_id=admin-cli&username=admin&password=$kcEp").access_token
    $kcH = @{ Authorization = "Bearer $kcTok"; 'Content-Type' = 'application/json' }

    # Find the LDAP UserStorageProvider component
    $comps    = Invoke-RestMethod -Uri 'http://localhost:8180/auth/admin/realms/securityapp/components?type=org.keycloak.storage.UserStorageProvider' -Headers $kcH
    $ldapComp = $comps | Where-Object { $_.providerId -eq 'ldap' } | Select-Object -First 1
    if ($ldapComp) {
        # Set bindCredential to the actual OpenLDAP admin password
        $ldapComp.config.bindCredential = @($Creds.LDAP_ADMIN_PASS)
        $body = $ldapComp | ConvertTo-Json -Depth 10 -Compress
        Invoke-RestMethod -Uri "http://localhost:8180/auth/admin/realms/securityapp/components/$($ldapComp.id)" `
            -Method Put -Headers $kcH -Body $body | Out-Null
        Write-OK "LDAP bind credential patched."
    } else {
        Write-Warn "No LDAP UserStorageProvider found in realm — skipped."
    }
} catch {
    Write-Warn "Failed to patch LDAP bind credential: $($_.Exception.Message)"
    Write-Warn "Users may not be able to log in. Re-run deploy or patch manually via Keycloak Admin Console."
}

# Allow Keycloak to fully commit the bind credential before syncing
Start-Sleep -Seconds 5

# -- Step 9b3: Trigger Keycloak LDAP full sync --------------------------------
# Ensures all LDAP users are imported into Keycloak before we try to assign roles.
Write-Host "  Triggering Keycloak LDAP full sync..." -ForegroundColor DarkGray
try {
    $kcEp3   = [Uri]::EscapeDataString($kcAdminPass)
    $kcTok3  = (Invoke-RestMethod -Uri 'http://localhost:8180/auth/realms/master/protocol/openid-connect/token' `
        -Method Post -ContentType 'application/x-www-form-urlencoded' `
        -Body "grant_type=password&client_id=admin-cli&username=admin&password=$kcEp3").access_token
    $kcH3    = @{ Authorization = "Bearer $kcTok3"; 'Content-Type' = 'application/json' }
    $comps3  = Invoke-RestMethod -Uri 'http://localhost:8180/auth/admin/realms/securityapp/components?type=org.keycloak.storage.UserStorageProvider' -Headers $kcH3
    $ldapId3 = ($comps3 | Where-Object { $_.providerId -eq 'ldap' } | Select-Object -First 1).id
    if ($ldapId3) {
        $sync3 = Invoke-RestMethod -Uri "http://localhost:8180/auth/admin/realms/securityapp/user-storage/$ldapId3/sync?action=triggerFullSync" -Method Post -Headers $kcH3
        Write-OK "LDAP sync complete — added=$($sync3.added) updated=$($sync3.updated)."
    } else {
        Write-Warn "No LDAP UserStorageProvider found — sync skipped."
    }
} catch {
    Write-Warn "LDAP sync failed: $($_.Exception.Message)"
    Write-Warn "Users may not be visible in Keycloak. Trigger manually: Admin Console > User Federation > Synchronize."
}

# -- Step 9c: Set app-user passwords directly in OpenLDAP --------------------
Write-Host ""
Write-Host "  Step 9c: Setting app-user passwords in OpenLDAP" -ForegroundColor Cyan

$ldapUsers = @(
    @{ dn = "uid=admin@securityapp.local,ou=Users,dc=securityapp,dc=local";       password = $Creds.APP_PASS_ADMIN       },
    @{ dn = "uid=contributor@securityapp.local,ou=Users,dc=securityapp,dc=local"; password = $Creds.APP_PASS_CONTRIBUTOR },
    @{ dn = "uid=viewer@securityapp.local,ou=Users,dc=securityapp,dc=local";      password = $Creds.APP_PASS_VIEWER      }
)

foreach ($lu in $ldapUsers) {
    # Build LDIF for a password change.
    # On Windows, PowerShell piping to 'docker exec -i ... -f -' (stdin) is unreliable.
    # Instead we write the LDIF to a temp file, docker-cp it into the container, and
    # reference it by path — this works on all platforms.
    $ldif = "dn: $($lu.dn)`nchangetype: modify`nreplace: userPassword`nuserPassword: $($lu.password)`n"
    try {
        # Write via base64 through docker exec so the file is owned by uid 1001 (Bitnami container
        # user), not root. docker cp writes as root and the container user cannot chmod or read it.
        $ldifB64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($ldif))
        docker exec securityapp-openldap sh -c "printf '%s' '$ldifB64' | base64 -d > /tmp/pw_change.ldif" | Out-Null

        $result = docker exec securityapp-openldap ldapmodify `
            -x `
            -H ldap://localhost:10389 `
            -D "cn=admin,dc=securityapp,dc=local" `
            -w $Creds.LDAP_ADMIN_PASS `
            -f /tmp/pw_change.ldif 2>&1
        $ldapExitCode = $LASTEXITCODE
        if ($ldapExitCode -ne 0) { throw "ldapmodify exited $ldapExitCode`: $result" }

        Write-OK "Password updated in OpenLDAP: $($lu.dn)"
    } catch {
        Write-Warn "Failed to update password for '$($lu.dn)': $($_.Exception.Message)"
        Write-Warn "User will fall back to seed password until corrected manually."
    }
}

# -- Step 10: Set Keycloak app-user passwords via Admin REST API --------------
Write-Step 10 "Setting Keycloak application user passwords"

# Get an admin token from Keycloak master realm
# Keycloak is configured with KC_HTTP_RELATIVE_PATH=/auth, so all endpoints are under /auth/
$kcBase    = 'http://localhost:8180/auth'
$kcTokenUrl = "$kcBase/realms/master/protocol/openid-connect/token"
$kcTokenBody = "grant_type=password&client_id=admin-cli&username=admin&password=$([System.Uri]::EscapeDataString($kcAdminPass))"
$kcToken = $null
try {
    $kcResp  = Invoke-RestMethod -Uri $kcTokenUrl -Method Post `
                   -ContentType 'application/x-www-form-urlencoded' `
                   -Body $kcTokenBody
    $kcToken = $kcResp.access_token
} catch {
    Write-Warn "Could not obtain Keycloak admin token: $($_.Exception.Message)"
    Write-Warn "App-user passwords will not be randomised. Change them manually in the Keycloak admin console."
}

if ($kcToken) {
    $kcHeaders = @{ Authorization = "Bearer $kcToken"; 'Content-Type' = 'application/json' }

    $appUsers = @(
        @{ username = 'admin@securityapp.local';       password = $Creds.APP_PASS_ADMIN;       role = 'Admin'       },
        @{ username = 'contributor@securityapp.local'; password = $Creds.APP_PASS_CONTRIBUTOR; role = 'Contributor' },
        @{ username = 'viewer@securityapp.local';      password = $Creds.APP_PASS_VIEWER;      role = 'Viewer'      }
    )

    # Cache realm roles once (id lookup needed for role assignment API)
    $realmRoles = @{}
    try {
        (Invoke-RestMethod -Uri "$kcBase/admin/realms/securityapp/roles" -Headers $kcHeaders) |
            ForEach-Object { $realmRoles[$_.name] = $_ }
    } catch {
        Write-Warn "Could not fetch realm roles: $($_.Exception.Message)"
    }

    foreach ($u in $appUsers) {
        try {
            # Lookup user ID
            $usersUrl = "$kcBase/admin/realms/securityapp/users?username=$($u.username)&exact=true"
            $found    = Invoke-RestMethod -Uri $usersUrl -Method Get -Headers $kcHeaders
            if (-not $found -or $found.Count -eq 0) {
                Write-Warn "User '$($u.username)' not found in Keycloak realm 'securityapp' - skipped."
                continue
            }
            $userId = $found[0].id

            # Fetch the full user representation — the list endpoint omits federationLink.
            $fullUser       = Invoke-RestMethod -Uri "$kcBase/admin/realms/securityapp/users/$userId" -Method Get -Headers $kcHeaders
            $federationLink = $fullUser.federationLink

            # Skip LDAP-federated users — passwords are managed by OpenLDAP (Step 9c).
            # Keycloak with editMode=WRITABLE refuses admin API password resets for these users.
            # federationLink is set once Keycloak has synced/discovered the LDAP user.
            # Even if federationLink is null (not yet synced), a reset-password attempt will
            # return 400 for LDAP-backed users — we catch and suppress that below.
            if (-not $federationLink) {
                $resetUrl  = "$kcBase/admin/realms/securityapp/users/$userId/reset-password"
                $resetBody = @{ type = 'password'; value = $u.password; temporary = $false } | ConvertTo-Json
                try {
                    Invoke-RestMethod -Uri $resetUrl -Method Put -Headers $kcHeaders -Body $resetBody | Out-Null
                    Write-OK "Password set for '$($u.username)'."
                } catch {
                    # Null-safe status code check (PS 5.1 and PS 7 differ in exception types)
                    $status = 0
                    try { $status = [int]$_.Exception.Response.StatusCode } catch {}
                    if ($status -eq 400) {
                        # 400 = LDAP-federated user despite empty federationLink.
                        # Password already set in Step 9c; this is expected.
                        Write-Host "  [INFO] Skipping '$($u.username)' — LDAP-federated (password managed in OpenLDAP)." -ForegroundColor DarkGray
                    } else {
                        Write-Warn "Failed to set password for '$($u.username)': $($_.Exception.Message)"
                    }
                }
            } else {
                Write-Host "  [INFO] Skipping '$($u.username)' — LDAP-federated (password managed in OpenLDAP)." -ForegroundColor DarkGray
            }

            # Assign realm role (idempotent — Keycloak silently ignores duplicates)
            if ($realmRoles.ContainsKey($u.role)) {
                $roleObj  = $realmRoles[$u.role]
                $roleBody = ConvertTo-Json @(@{ id = $roleObj.id; name = $roleObj.name }) -Compress
                Invoke-RestMethod -Uri "$kcBase/admin/realms/securityapp/users/$userId/role-mappings/realm" `
                    -Method Post -Headers $kcHeaders -Body $roleBody | Out-Null
                Write-OK "Role '$($u.role)' assigned to '$($u.username)'."
            } else {
                Write-Warn "Role '$($u.role)' not found in realm — skipped for '$($u.username)'."
            }
        } catch {
            Write-Warn "Failed to configure '$($u.username)': $($_.Exception.Message)"
        }
    }

    # -- Step 10b: Add production domain to Keycloak client redirect URIs -----
    if ($Domain) {
        Write-Host ""
        Write-Host "  Step 10b: Patching Keycloak client redirect URIs for domain '$Domain'" -ForegroundColor Cyan
        $domainOrigin   = "https://${Domain}"
        $domainWildcard = "https://${Domain}/*"
        try {
            $clientsUrl = "$kcBase/admin/realms/securityapp/clients"
            $allClients = Invoke-RestMethod -Uri $clientsUrl -Headers $kcHeaders
            foreach ($clientId in @('securityapp-ui', 'securityapp-api')) {
                $client = $allClients | Where-Object { $_.clientId -eq $clientId } | Select-Object -First 1
                if (-not $client) { Write-Warn "Client '$clientId' not found — skipped."; continue }
                $fullClient = Invoke-RestMethod -Uri "$clientsUrl/$($client.id)" -Headers $kcHeaders
                # Add domain to redirectUris and webOrigins if not already present
                $newRedirects = @($fullClient.redirectUris) + @($domainWildcard) | Select-Object -Unique
                $newOrigins   = @($fullClient.webOrigins)   + @($domainOrigin)   | Select-Object -Unique
                $fullClient.redirectUris = $newRedirects
                $fullClient.webOrigins   = $newOrigins
                # Also update post.logout.redirect.uris attribute
                if ($clientId -eq 'securityapp-ui') {
                    $existingLogout = $fullClient.attributes.'post.logout.redirect.uris'
                    if ($existingLogout -and $existingLogout -notlike "*${domainWildcard}*") {
                        $fullClient.attributes.'post.logout.redirect.uris' = $existingLogout + "##${domainWildcard}"
                    }
                }
                $putBody = $fullClient | ConvertTo-Json -Depth 20 -Compress
                Invoke-RestMethod -Uri "$clientsUrl/$($client.id)" -Method Put -Headers $kcHeaders -Body $putBody | Out-Null
                Write-OK "Client '$clientId': added '$domainWildcard' to redirectUris and webOrigins."
            }
        } catch {
            Write-Warn "Failed to patch client redirect URIs: $($_.Exception.Message)"
            Write-Warn "Add 'https://${Domain}/*' manually in Keycloak Admin Console > Clients > [client] > Valid redirect URIs."
        }
    }
}

# -- Step 11: Inject Vault AppRole credentials into .env ---------------------
# RoleID is permanent and non-secret — written once and reused across deployments.
# WrapToken is a single-use, 5-minute response-wrapping token that conceals the real
# SecretID until the API unwraps it on first startup.  Every restart of the API requires
# a fresh WrapToken (run deploy.ps1 or vault-rotate.ps1 -Action RefreshSecretId).
# This ensures every deployment is a distinct, auditable Vault event.
Write-Step 11 "Injecting Vault AppRole credentials (wrapped SecretID)"

# Wait for vault-init.sh to write approle.roleid.
# The vault healthcheck (with Fix 4 applied) now gates on this file too,
# but we poll here as a belt-and-suspenders safety net.
$vaultRoleId = $null
$vaultTimeout = 120
$vaultPoll    = 5
Write-Host "  Waiting for Vault AppRole seeding..." -ForegroundColor DarkGray
for ($elapsed = 0; $elapsed -lt $vaultTimeout; $elapsed += $vaultPoll) {
    $raw = docker exec securityapp-vault cat /vault/data/approle.roleid 2>&1
    if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrWhiteSpace($raw)) {
        $vaultRoleId = $raw.Trim()
        break
    }
    if ($elapsed -gt 0) {
        Write-Host "  Still waiting... ($elapsed s)" -ForegroundColor DarkGray
    }
    Start-Sleep -Seconds $vaultPoll
}

if ([string]::IsNullOrWhiteSpace($vaultRoleId)) {
    Write-Fail @"
Vault AppRole seeding did not complete within ${vaultTimeout}s.
Check vault logs for errors:
  docker logs securityapp-vault --tail 60
"@
}
Write-OK "RoleID read from Vault volume: $vaultRoleId"

# Generate a response-wrapped SecretID (single-use wrapping token, 5-min TTL)
$rootTokenRaw = docker exec securityapp-vault cat /vault/data/.init.json 2>&1 | Out-String
$vaultRootToken = ''
if ($rootTokenRaw -match '"root_token"\s*:\s*"([^"]+)"') { $vaultRootToken = $Matches[1] }
if ([string]::IsNullOrWhiteSpace($vaultRootToken)) {
    Write-Fail "Could not read Vault root token. Check: docker logs securityapp-vault"
}

$wrapJson = docker exec -e "VAULT_TOKEN=$vaultRootToken" `
    securityapp-vault vault write -wrap-ttl=5m -f auth/approle/role/securityapp-api/secret-id -format=json 2>&1 | Out-String

$vaultWrapToken = ''
try   { $vaultWrapToken = ($wrapJson | ConvertFrom-Json).wrap_info.token }
catch { if ($wrapJson -match '"token"\s*:\s*"([^"]+)"') { $vaultWrapToken = $Matches[1] } }

if ([string]::IsNullOrWhiteSpace($vaultWrapToken)) {
    Write-Fail "Could not generate wrapped SecretID. Check: docker logs securityapp-vault"
}
Write-OK "Wrapped SecretID generated (single-use, 5-min TTL — consumed by the API on first startup)."

$envFilePath    = Join-Path $Root '.env'
$envFileContent = Get-Content $envFilePath -Raw
$envFileContent = $envFileContent -replace '(?m)^VAULT_ROLE_ID=.*$',    "VAULT_ROLE_ID=$vaultRoleId"
$envFileContent = $envFileContent -replace '(?m)^VAULT_WRAP_TOKEN=.*$', "VAULT_WRAP_TOKEN=$vaultWrapToken"
Set-Content -Path $envFilePath -Value $envFileContent -Encoding UTF8
Write-OK "VAULT_ROLE_ID and VAULT_WRAP_TOKEN written to .env."

# Update credentials.txt now that Vault details are known
Write-CredentialsFile

# -- Step 12: Start API -------------------------------------------------------
Write-Step 12 "Starting API"
docker compose up -d --build api
if ($LASTEXITCODE -ne 0) { Write-Fail "Failed to start API." }
if (-not (Wait-ContainerHealthy 'securityapp-api' -TimeoutSec 180 -PollSec 5)) {
    Write-Warn "API is taking longer than expected. Check: docker logs securityapp-api"
}
Write-OK "API is healthy."

# -- Step 13: Start UI --------------------------------------------------------
Write-Step 13 "Starting UI"
docker compose up -d --build ui
if ($LASTEXITCODE -ne 0) { Write-Fail "Failed to start UI." }
Write-OK "UI started."

# -- Step 13b: Start observability stack (optional) ---------------------------
if ($Observability) {
    Write-Step '13b' "Starting Prometheus + Grafana (observability)"
    docker compose up -d prometheus grafana
    if ($LASTEXITCODE -ne 0) { Write-Warn "Failed to start observability stack. Check: docker compose logs prometheus grafana" }
    else { Write-OK "Prometheus (http://localhost:9090) and Grafana (http://localhost:3000) started." }
}

# -- Get Vault root token for admin to record ---------------------------------
$vaultRootToken = docker exec securityapp-vault cat /vault/data/.init.json 2>&1 |
    Select-String '"root_token"' |
    ForEach-Object { if ($_ -match '"root_token"\s*:\s*"([^"]+)"') { $Matches[1] } }

# =============================================================================
# Step 14: Final credentials report (print to console + save)
# =============================================================================
Write-Step 14 "Generating credentials report"
Write-CredentialsFile -PrintToConsole

Write-Host ""
Write-Host "+================================================================+" -ForegroundColor Green
Write-Host "|              Installation Complete!                            |" -ForegroundColor Green
Write-Host "+================================================================+" -ForegroundColor Green
Write-Host ""

# Clear SA password from process environment — it was only needed for Docker Compose interpolation
if ($Database -eq 'sqlserver') { Remove-Item Env:MSSQL_SA_PASSWORD -ErrorAction SilentlyContinue }
